import H12CloudChart1Data209

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound53179 : H12AffineFastState.Bounded env53179 := by
  intro p hp
  have h : env53179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53178_53179 : H12AffineEnvironment.transform 8 1 env53178 = env53179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53178 == env53179) = true)

theorem identity53179 : scanCanonicalize (H12AffineFastState.compose env53179 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound53179 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53180 : List Nat := [2,4,8,0,1,1,9,5,1,4,1,0,8,0,1,2,0,1,4,0,1,1,0,3,9,0,0,1,1,1,5,0,5,0,1,0]

theorem envBound53180 : H12AffineFastState.Bounded env53180 := by
  intro p hp
  have h : env53180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53179_53180 : H12AffineEnvironment.transform 9 4 env53179 = env53180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env53179 == env53180) = true)

def env53181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,21763,8328,65,215367,115151,396525,35325,497902,243002,256,509971,469430,442169]

theorem envBound53181 : H12AffineFastState.Bounded env53181 := by
  intro p hp
  have h : env53181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53151_53181 : H12AffineEnvironment.transform 20 4161 env53151 = env53181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53151 == env53181) = true)

theorem identity53181 : scanCanonicalize (H12AffineFastState.compose env53181 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound53181 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,156012,412156,21763,8328,65,215367,79131,396525,32041,486458,213486,256,474311,469430,412653]

theorem envBound53182 : H12AffineFastState.Bounded env53182 := by
  intro p hp
  have h : env53182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53181_53182 : H12AffineEnvironment.transform 14 29908 env53181 = env53182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env53181 == env53182) = true)

def env53183 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4113,155964,412076,21763,8328,17,215319,79131,396477,32041,486458,213438,256,474263,469430,412605]

theorem envBound53183 : H12AffineFastState.Bounded env53183 := by
  intro p hp
  have h : env53183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53183 : H12AffineEnvironment.transform 5 16 env53182 = env53183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53182 == env53183) = true)

theorem identity53183 : scanCanonicalize (H12AffineFastState.compose env53183 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound53183 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env53184 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,157753,1024,29829,4113,155964,8597,21763,8328,17,215319,79131,25732,32041,66563,213438,256,87214,82319,9092]

theorem envBound53184 : H12AffineFastState.Bounded env53184 := by
  intro p hp
  have h : env53184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53183_53184 : H12AffineEnvironment.transform 17 157753 env53183 = env53184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env53183 == env53184) = true)

theorem identity53184 : scanCanonicalize (H12AffineFastState.compose env53184 (packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound53184 : packedSelected [0,1,9,10,16,18,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53185 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,262,131072,157753,1024,29829,4113,155964,8597,21763,8328,17,149521,13341,25732,32041,1285,147640,256,21928,16521,9092]

theorem envBound53185 : H12AffineFastState.Bounded env53185 := by
  intro p hp
  have h : env53185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53184_53185 : H12AffineEnvironment.transform 15 262 env53184 = env53185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env53184 == env53185) = true)

theorem identity53185 : scanCanonicalize (H12AffineFastState.compose env53185 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound53185 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env53186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,262,131072,146865,1024,8461,4113,144564,8597,139,8328,17,138649,13341,12556,10401,1285,136496,256,32,5377,9092]

theorem envBound53186 : H12AffineFastState.Bounded env53186 := by
  intro p hp
  have h : env53186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53185_53186 : H12AffineEnvironment.transform 13 5512 env53185 = env53186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env53185 == env53186) = true)

theorem identity53186 : scanCanonicalize (H12AffineFastState.compose env53186 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53186 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,262,5393,10400,1024,8461,4113,8613,8597,139,8328,17,2184,13341,12556,10401,1285,33,256,32,5377,9092]

theorem envBound53187 : H12AffineFastState.Bounded env53187 := by
  intro p hp
  have h : env53187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53186_53187 : H12AffineEnvironment.transform 16 5393 env53186 = env53187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53186 == env53187) = true)

theorem identity53187 : scanCanonicalize (H12AffineFastState.compose env53187 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound53187 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2200,8192,3344,8460,262,3465,10400,1024,8461,2185,8613,8597,139,8328,17,2184,11397,10644,10401,1285,33,256,32,3481,9092]

theorem envBound53188 : H12AffineFastState.Bounded env53188 := by
  intro p hp
  have h : env53188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53187_53188 : H12AffineEnvironment.transform 11 2200 env53187 = env53188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env53187 == env53188) = true)

theorem identity53188 : scanCanonicalize (H12AffineFastState.compose env53188 (packedSelected [0,3,4,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53188 : packedSelected [0,3,4,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53189 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,153,8192,1297,8460,262,1416,8353,1024,8461,136,8613,8597,139,8328,17,137,9348,8597,8352,1285,33,256,32,1432,9092]

theorem envBound53189 : H12AffineFastState.Bounded env53189 := by
  intro p hp
  have h : env53189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53188_53189 : H12AffineEnvironment.transform 10 1 env53188 = env53189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53188 == env53189) = true)

theorem identity53189 : scanCanonicalize (H12AffineFastState.compose env53189 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound53189 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env53190 : List Nat := [2,4,8,16,32,16,128,256,512,189,1,153,8192,428,8460,262,309,8353,189,8461,136,8613,8597,139,8328,17,137,8249,8597,8352,440,33,256,32,293,9092]

theorem envBound53190 : H12AffineFastState.Bounded env53190 := by
  intro p hp
  have h : env53190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53189_53190 : H12AffineEnvironment.transform 9 189 env53189 = env53190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env53189 == env53190) = true)

theorem identity53190 : scanCanonicalize (H12AffineFastState.compose env53190 (packedSelected [0,1,3,4,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53190 : packedSelected [0,1,3,4,15] rootPS < 2^1333 := by decide +kernel

def env53191 : List Nat := [2,4,8,16,32,16,128,256,512,189,1,153,269,428,1,262,309,428,189,0,136,168,152,139,389,17,137,308,152,429,440,33,256,32,293,649]

theorem envBound53191 : H12AffineFastState.Bounded env53191 := by
  intro p hp
  have h : env53191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53190_53191 : H12AffineEnvironment.transform 12 269 env53190 = env53191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53190 == env53191) = true)

theorem identity53191 : scanCanonicalize (H12AffineFastState.compose env53191 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound53191 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53192 : List Nat := [2,4,8,16,32,16,128,172,512,189,1,153,161,0,1,170,153,0,189,0,136,168,152,139,41,17,137,152,152,1,20,33,172,32,137,649]

theorem envBound53192 : H12AffineFastState.Bounded env53192 := by
  intro p hp
  have h : env53192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53191_53192 : H12AffineEnvironment.transform 7 172 env53191 = env53192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53191 == env53192) = true)

def env53193 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4112,155965,412077,21763,8328,16,215318,79131,396476,32041,486458,213439,256,474262,469430,412604]

theorem envBound53193 : H12AffineFastState.Bounded env53193 := by
  intro p hp
  have h : env53193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53182_53193 : H12AffineEnvironment.transform 5 17 env53182 = env53193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53182 == env53193) = true)

theorem identity53193 : scanCanonicalize (H12AffineFastState.compose env53193 (packedSelected [10,12,14,31,35,41] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound53193 : packedSelected [10,12,14,31,35,41] rootPS < 2^1333 := by decide +kernel

def env53194 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21647,131072,262144,1024,29828,4112,155965,412077,21763,8328,16,138649,24980,396476,32041,407733,136496,256,419865,425273,412604]

theorem envBound53194 : H12AffineFastState.Bounded env53194 := by
  intro p hp
  have h : env53194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53193_53194 : H12AffineEnvironment.transform 15 21647 env53193 = env53194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env53193 == env53194) = true)

theorem identity53194 : scanCanonicalize (H12AffineFastState.compose env53194 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound53194 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53195 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21647,131072,138293,1024,29828,4112,155965,21912,21763,8328,16,138649,24980,4233,32041,9344,136496,256,29740,24844,22409]

theorem envBound53195 : H12AffineFastState.Bounded env53195 := by
  intro p hp
  have h : env53195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53194_53195 : H12AffineEnvironment.transform 17 138293 env53194 = env53195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env53194 == env53195) = true)

theorem identity53195 : scanCanonicalize (H12AffineFastState.compose env53195 (packedSelected [1,3,4,5,8,9,11,12,14,15,16,17,18,20,35] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound53195 : packedSelected [1,3,4,5,8,9,11,12,14,15,16,17,18,20,35] rootPS < 2^1333 := by decide +kernel

def env53196 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,21647,24861,32040,1024,29828,4112,32,21912,21763,8328,16,31876,24980,4233,32041,9344,29741,256,29740,24844,22409]

theorem envBound53196 : H12AffineFastState.Bounded env53196 := by
  intro p hp
  have h : env53196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53195_53196 : H12AffineEnvironment.transform 16 24861 env53195 = env53196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env53195 == env53196) = true)

theorem identity53196 : scanCanonicalize (H12AffineFastState.compose env53196 (packedSelected [2,6,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53196 : packedSelected [2,6,11,15] rootPS < 2^1333 := by decide +kernel

def env53197 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21897,21647,16401,23588,1024,21896,4112,32,21912,21763,388,16,23944,16536,4233,23589,1420,21793,256,21792,16384,22409]

theorem envBound53197 : H12AffineFastState.Bounded env53197 := by
  intro p hp
  have h : env53197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53196_53197 : H12AffineEnvironment.transform 12 268 env53196 = env53197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53196 == env53197) = true)

theorem identity53197 : scanCanonicalize (H12AffineFastState.compose env53197 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53197 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env53198 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,16384,20633,20895,16401,22836,272,20632,4112,32,20616,20499,388,16,22680,16536,4233,22837,156,20529,256,20528,16384,21145]

theorem envBound53198 : H12AffineFastState.Bounded env53198 := by
  intro p hp
  have h : env53198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53197_53198 : H12AffineEnvironment.transform 9 272 env53197 = env53198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53197 == env53198) = true)

theorem identity53198 : scanCanonicalize (H12AffineFastState.compose env53198 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound53198 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env53199 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,4405,428,170,4388,2049,272,429,4112,32,445,294,388,16,2477,4525,4233,2048,156,260,256,261,4405,940]

theorem envBound53199 : H12AffineFastState.Bounded env53199 := by
  intro p hp
  have h : env53199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53198_53199 : H12AffineEnvironment.transform 13 4405 env53198 = env53199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env53198 == env53199) = true)

theorem identity53199 : scanCanonicalize (H12AffineFastState.compose env53199 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53199 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env53200 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,4096,41,4112,137,170,4097,2049,53,136,4112,32,152,3,161,16,2184,4232,4233,2048,156,33,37,32,4112,649]

theorem envBound53200 : H12AffineFastState.Bounded env53200 := by
  intro p hp
  have h : env53200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53199_53200 : H12AffineEnvironment.transform 7 37 env53199 = env53200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53199 == env53200) = true)

theorem identity53200 : scanCanonicalize (H12AffineFastState.compose env53200 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound53200 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53201 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,2576,41,2560,137,170,2577,2049,53,136,2560,32,152,3,161,16,2184,2712,2713,2048,156,33,37,32,2560,649]

theorem envBound53201 : H12AffineFastState.Bounded env53201 := by
  intro p hp
  have h : env53201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53200_53201 : H12AffineEnvironment.transform 11 2576 env53200 = env53201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env53200 == env53201) = true)

theorem identity53201 : scanCanonicalize (H12AffineFastState.compose env53201 (packedSelected [2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53201 : packedSelected [2,4,11] rootPS < 2^1333 := by decide +kernel

def env53202 : List Nat := [2,4,8,16,32,17,128,37,0,53,2048,2064,41,2048,137,170,2065,2049,53,136,2048,32,152,3,161,16,2184,2200,2201,2048,156,33,37,32,2048,137]

theorem envBound53202 : H12AffineFastState.Bounded env53202 := by
  intro p hp
  have h : env53202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53201_53202 : H12AffineEnvironment.transform 8 0 env53201 = env53202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53201 == env53202) = true)

theorem identity53202 : scanCanonicalize (H12AffineFastState.compose env53202 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53202 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53203 : List Nat := [2,4,8,16,32,17,8,37,0,53,2048,2064,41,2048,1,34,2065,2049,53,0,2048,32,16,3,41,16,2048,2064,2065,2048,20,33,37,32,2048,1]

theorem envBound53203 : H12AffineFastState.Bounded env53203 := by
  intro p hp
  have h : env53203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53202_53203 : H12AffineEnvironment.transform 6 8 env53202 = env53203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53202 == env53203) = true)

def env53204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412157,2114883,8328,65,6409406,115150,2497709,35324,2590895,4268163,256,509971,469430,2535288]

theorem envBound53204 : H12AffineFastState.Bounded env53204 := by
  intro p hp
  have h : env53204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53066_53204 : H12AffineEnvironment.transform 22 412157 env53066 = env53204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412157 env53066 == env53204) = true)

def env53205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262520,412157,2114883,8328,65,215366,115150,2497709,35324,2590895,2336123,256,509971,469430,2535288]

theorem envBound53205 : H12AffineFastState.Bounded env53205 := by
  intro p hp
  have h : env53205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53204_53205 : H12AffineEnvironment.transform 21 2262520 env53204 = env53205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262520 env53204 == env53205) = true)

def env53206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,21763,8328,65,215366,115150,396525,35324,497903,243003,256,509971,469430,442168]

theorem envBound53206 : H12AffineFastState.Bounded env53206 := by
  intro p hp
  have h : env53206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53205_53206 : H12AffineEnvironment.transform 20 4160 env53205 = env53206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53205 == env53206) = true)

theorem identity53206 : scanCanonicalize (H12AffineFastState.compose env53206 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound53206 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,169400,412157,21763,8328,65,171417,5393,396525,35324,412720,156132,256,400588,458089,442168]

theorem envBound53207 : H12AffineFastState.Bounded env53207 := by
  intro p hp
  have h : env53207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53206_53207 : H12AffineEnvironment.transform 15 54495 env53206 = env53207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env53206 == env53207) = true)

def env53208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4112,169400,412077,21763,8328,17,171417,5393,396477,35244,412720,156084,256,400540,458041,442168]

theorem envBound53208 : H12AffineFastState.Bounded env53208 := by
  intro p hp
  have h : env53208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53207_53208 : H12AffineEnvironment.transform 5 16 env53207 = env53208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53207 == env53208) = true)

theorem identity53208 : scanCanonicalize (H12AffineFastState.compose env53208 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound53208 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env53209 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,23589,1024,32769,4112,169400,136584,21763,8328,17,171417,5393,151704,35244,135189,156084,256,147641,172316,189213]

theorem envBound53209 : H12AffineFastState.Bounded env53209 := by
  intro p hp
  have h : env53209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53208_53209 : H12AffineEnvironment.transform 17 23589 env53208 = env53209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env53208 == env53209) = true)

theorem identity53209 : scanCanonicalize (H12AffineFastState.compose env53209 (packedSelected [0,5,8,9,10,16,18,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53209 : packedSelected [0,5,8,9,10,16,18,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53210 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33167,131072,2341,1024,32769,4112,169400,136584,3,8328,17,171417,5393,132504,35244,135189,144564,256,136633,172316,177693]

theorem envBound53210 : H12AffineFastState.Bounded env53210 := by
  intro p hp
  have h : env53210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53209_53210 : H12AffineEnvironment.transform 13 5376 env53209 = env53210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53209 == env53210) = true)

theorem identity53210 : scanCanonicalize (H12AffineFastState.compose env53210 (packedSelected [0,1,3,4,5,7,8,10,16,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound53210 : packedSelected [0,1,3,4,5,7,8,10,16,20,22,26] rootPS < 2^1333 := by decide +kernel

def env53211 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33167,46108,2341,1024,32769,4112,8612,41364,3,8328,17,10629,5393,45444,35244,41993,32936,256,41381,5376,513]

theorem envBound53211 : H12AffineFastState.Bounded env53211 := by
  intro p hp
  have h : env53211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53210_53211 : H12AffineEnvironment.transform 16 46108 env53210 = env53211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env53210 == env53211) = true)

theorem identity53211 : scanCanonicalize (H12AffineFastState.compose env53211 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound53211 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env53212 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5376,32768,33167,38297,2341,1024,32769,4112,33,32785,3,269,17,2048,5393,36865,35244,34188,32936,256,32800,5376,513]

theorem envBound53212 : H12AffineFastState.Bounded env53212 := by
  intro p hp
  have h : env53212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53211_53212 : H12AffineEnvironment.transform 12 389 env53211 = env53212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env53211 == env53212) = true)

theorem identity53212 : scanCanonicalize (H12AffineFastState.compose env53212 (packedSelected [4,9,10,11,15,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53212 : packedSelected [4,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env53213 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,32768,33030,38160,2341,1024,32769,4112,33,32785,3,269,17,2048,5393,36865,35109,34053,32801,256,32800,5376,513]

theorem envBound53213 : H12AffineFastState.Bounded env53213 := by
  intro p hp
  have h : env53213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53212_53213 : H12AffineEnvironment.transform 6 9 env53212 = env53213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53212 == env53213) = true)

theorem identity53213 : scanCanonicalize (H12AffineFastState.compose env53213 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53213 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env53214 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1024,1,4112,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound53214 : H12AffineFastState.Bounded env53214 := by
  intro p hp
  have h : env53214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53213_53214 : H12AffineEnvironment.transform 14 0 env53213 = env53214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53213 == env53214) = true)

theorem identity53214 : scanCanonicalize (H12AffineFastState.compose env53214 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53214 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53215 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,0,35,5173,2048,1024,1,4112,33,17,3,40,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound53215 : H12AffineFastState.Bounded env53215 := by
  intro p hp
  have h : env53215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53214_53215 : H12AffineEnvironment.transform 7 37 env53214 = env53215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53214 == env53215) = true)

def env53216 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,0,35,1029,2048,1024,1,32,33,17,3,40,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound53216 : H12AffineFastState.Bounded env53216 := by
  intro p hp
  have h : env53216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53215_53216 : H12AffineEnvironment.transform 11 48 env53215 = env53216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53215 == env53216) = true)

theorem identity53216 : scanCanonicalize (H12AffineFastState.compose env53216 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound53216 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53217 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,48,41,1045,0,35,1029,560,1024,1,32,33,17,3,40,17,560,1028,49,560,1056,33,37,32,1045,513]

theorem envBound53217 : H12AffineFastState.Bounded env53217 := by
  intro p hp
  have h : env53217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53216_53217 : H12AffineEnvironment.transform 10 560 env53216 = env53217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env53216 == env53217) = true)

def env53218 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,48,41,33,0,35,49,560,52,1,32,33,17,3,40,17,560,48,49,560,20,33,37,32,33,513]

theorem envBound53218 : H12AffineFastState.Bounded env53218 := by
  intro p hp
  have h : env53218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53217_53218 : H12AffineEnvironment.transform 9 52 env53217 = env53218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53217 == env53218) = true)

theorem identity53218 : scanCanonicalize (H12AffineFastState.compose env53218 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound53218 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53219 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,48,41,33,0,35,49,32,52,1,32,33,17,3,40,17,32,48,49,32,20,33,37,32,33,17]

theorem envBound53219 : H12AffineFastState.Bounded env53219 := by
  intro p hp
  have h : env53219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53218_53219 : H12AffineEnvironment.transform 8 16 env53218 = env53219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env53218 == env53219) = true)

def leafEnv53219 : List Nat := [2,4,8,16,32,16,9,37,16,52,32,48,41,33,0,35,49,32,52,1,32,33,17,3,20,40,1,17,32,48,49,32,20,33,37,32,4,34,33,17,1,32,0]

def active53219 : List Nat := [0,1,2,3,4]

def tree53219 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53219 : H12WitnessSearch.Good tree53219 := H12GlobalWitnessIndex.good

theorem leafIdentity53219 : H12AffineFastState.composeSystem env53219 rootObs = leafEnv53219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53219 rootObs == leafEnv53219) = true)

theorem terminalChecked53219 : H12PackedTerminal.terminalCheckFast leafEnv53219 active53219 tree53219 = true := by decide +kernel

def env53220 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,41,32,0,35,48,560,53,1,32,33,17,3,40,17,560,49,49,560,21,33,37,32,32,513]

theorem envBound53220 : H12AffineFastState.Bounded env53220 := by
  intro p hp
  have h : env53220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53217_53220 : H12AffineEnvironment.transform 9 53 env53217 = env53220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53217 == env53220) = true)

theorem identity53220 : scanCanonicalize (H12AffineFastState.compose env53220 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53221 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,11,18,27,0,24,11,523,14,1,27,26,17,3,19,17,523,10,10,523,21,26,30,27,27,513]

theorem envBound53221 : H12AffineFastState.Bounded env53221 := by
  intro p hp
  have h : env53221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53220_53221 : H12AffineEnvironment.transform 4 27 env53220 = env53221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53220 == env53221) = true)

def leafEnv53221 : List Nat := [2,4,8,16,27,16,9,30,512,14,523,11,18,27,0,24,11,523,14,1,27,26,17,3,21,19,1,17,523,10,10,523,21,26,30,27,4,25,27,513,1,27,0]

def active53221 : List Nat := [0,1,2,3,8]

def tree53221 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53221 : H12WitnessSearch.Good tree53221 := H12GlobalWitnessIndex.good

theorem leafIdentity53221 : H12AffineFastState.composeSystem env53221 rootObs = leafEnv53221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53221 rootObs == leafEnv53221) = true)

theorem terminalChecked53221 : H12PackedTerminal.terminalCheckFast leafEnv53221 active53221 tree53221 = true := by decide +kernel

def env53222 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,0,35,1028,2048,1024,1,33,33,17,3,40,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound53222 : H12AffineFastState.Bounded env53222 := by
  intro p hp
  have h : env53222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53215_53222 : H12AffineEnvironment.transform 11 49 env53215 = env53222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53215 == env53222) = true)

theorem identity53222 : scanCanonicalize (H12AffineFastState.compose env53222 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound53222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53223 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1540,49,41,1044,0,35,1028,1540,1024,1,33,33,17,3,40,17,1540,1029,48,1540,1056,33,37,32,1044,513]

theorem envBound53223 : H12AffineFastState.Bounded env53223 := by
  intro p hp
  have h : env53223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53222_53223 : H12AffineEnvironment.transform 10 1540 env53222 = env53223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env53222 == env53223) = true)

def env53224 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,41,32,0,35,48,560,52,1,33,33,17,3,40,17,560,49,48,560,20,33,37,32,32,513]

theorem envBound53224 : H12AffineFastState.Bounded env53224 := by
  intro p hp
  have h : env53224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53223_53224 : H12AffineEnvironment.transform 9 52 env53223 = env53224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53223 == env53224) = true)

theorem identity53224 : scanCanonicalize (H12AffineFastState.compose env53224 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound53224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53225 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,49,41,32,0,35,48,33,52,1,33,33,17,3,40,17,33,49,48,33,20,33,37,32,32,16]

theorem envBound53225 : H12AffineFastState.Bounded env53225 := by
  intro p hp
  have h : env53225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53224_53225 : H12AffineEnvironment.transform 8 17 env53224 = env53225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env53224 == env53225) = true)

def leafEnv53225 : List Nat := [2,4,8,16,32,16,9,37,17,52,33,49,41,32,0,35,48,33,52,1,33,33,17,3,20,40,1,17,33,49,48,33,20,33,37,32,4,34,32,16,1,33,0]

def active53225 : List Nat := [0,1,2,3,4]

def tree53225 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53225 : H12WitnessSearch.Good tree53225 := H12GlobalWitnessIndex.good

theorem leafIdentity53225 : H12AffineFastState.composeSystem env53225 rootObs = leafEnv53225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53225 rootObs == leafEnv53225) = true)

theorem terminalChecked53225 : H12PackedTerminal.terminalCheckFast leafEnv53225 active53225 tree53225 = true := by decide +kernel

def env53226 : List Nat := [2,4,8,16,32,16,9,37,512,53,561,49,41,33,0,35,49,561,53,1,33,33,17,3,40,17,561,48,48,561,21,33,37,32,33,513]

theorem envBound53226 : H12AffineFastState.Bounded env53226 := by
  intro p hp
  have h : env53226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53223_53226 : H12AffineEnvironment.transform 9 53 env53223 = env53226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53223 == env53226) = true)

theorem identity53226 : scanCanonicalize (H12AffineFastState.compose env53226 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound53226 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53227 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,11,19,27,0,25,11,523,15,1,27,27,17,3,18,17,523,10,10,523,21,27,31,26,27,513]

theorem envBound53227 : H12AffineFastState.Bounded env53227 := by
  intro p hp
  have h : env53227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53226_53227 : H12AffineEnvironment.transform 4 26 env53226 = env53227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env53226 == env53227) = true)

def leafEnv53227 : List Nat := [2,4,8,16,26,16,9,31,512,15,523,11,19,27,0,25,11,523,15,1,27,27,17,3,21,18,1,17,523,10,10,523,21,27,31,26,4,24,27,513,1,27,0]

def active53227 : List Nat := [0,1,2,3,8]

def tree53227 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53227 : H12WitnessSearch.Good tree53227 := H12GlobalWitnessIndex.good

theorem leafIdentity53227 : H12AffineFastState.composeSystem env53227 rootObs = leafEnv53227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53227 rootObs == leafEnv53227) = true)

theorem terminalChecked53227 : H12PackedTerminal.terminalCheckFast leafEnv53227 active53227 tree53227 = true := by decide +kernel

def env53228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4113,169400,412076,21763,8328,16,171417,5393,396476,35245,412720,156085,256,400541,458040,442168]

theorem envBound53228 : H12AffineFastState.Bounded env53228 := by
  intro p hp
  have h : env53228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53207_53228 : H12AffineEnvironment.transform 5 17 env53207 = env53228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53207 == env53228) = true)

theorem identity53228 : scanCanonicalize (H12AffineFastState.compose env53228 (packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound53228 : packedSelected [1,4,7,9,12,15,16,17,18,20,23,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env53229 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21760,398,131072,262144,1024,21761,4113,147640,412076,21763,8328,16,149657,5393,396476,23725,412720,156085,256,400541,403512,420408]

theorem envBound53229 : H12AffineFastState.Bounded env53229 := by
  intro p hp
  have h : env53229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53228_53229 : H12AffineEnvironment.transform 14 21760 env53228 = env53229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env53228 == env53229) = true)

theorem identity53229 : scanCanonicalize (H12AffineFastState.compose env53229 (packedSelected [1,3,5,8,10,18,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53229 : packedSelected [1,3,5,8,10,18,23,26] rootPS < 2^1333 := by decide +kernel

def env53230 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21760,398,131072,262144,1024,21761,4113,147640,412076,21763,388,16,149657,5393,396476,23725,412720,147641,256,400541,395572,412468]

theorem envBound53230 : H12AffineFastState.Bounded env53230 := by
  intro p hp
  have h : env53230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53229_53230 : H12AffineEnvironment.transform 12 268 env53229 = env53230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53229 == env53230) = true)

theorem identity53230 : scanCanonicalize (H12AffineFastState.compose env53230 (packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound53230 : packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env53231 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21760,398,5392,262144,1024,21761,4113,21928,285884,21763,388,16,23945,5393,268716,23725,284960,21929,256,264589,269348,286244]

theorem envBound53231 : H12AffineFastState.Bounded env53231 := by
  intro p hp
  have h : env53231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53230_53231 : H12AffineEnvironment.transform 16 5392 env53230 = env53231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env53230 == env53231) = true)

theorem identity53231 : scanCanonicalize (H12AffineFastState.compose env53231 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound53231 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53232 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21760,398,5392,23589,1024,21761,4113,21928,153,21763,388,16,23945,5393,17801,23725,1285,21929,256,21928,16385,513]

theorem envBound53232 : H12AffineFastState.Bounded env53232 := by
  intro p hp
  have h : env53232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53231_53232 : H12AffineEnvironment.transform 17 23589 env53231 = env53232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env53231 == env53232) = true)

theorem identity53232 : scanCanonicalize (H12AffineFastState.compose env53232 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53232 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5376,0,398,5392,2341,1024,1,4113,168,153,3,388,16,2185,5393,4233,2477,1285,169,256,168,5377,513]

theorem envBound53233 : H12AffineFastState.Bounded env53233 := by
  intro p hp
  have h : env53233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53232_53233 : H12AffineEnvironment.transform 13 5376 env53232 = env53233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53232 == env53233) = true)

theorem identity53233 : scanCanonicalize (H12AffineFastState.compose env53233 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53233 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53234 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4113,33,16,3,269,16,2048,5393,4096,2340,1285,32,256,33,5377,513]

theorem envBound53234 : H12AffineFastState.Bounded env53234 := by
  intro p hp
  have h : env53234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53233_53234 : H12AffineEnvironment.transform 6 9 env53233 = env53234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53233 == env53234) = true)

theorem identity53234 : scanCanonicalize (H12AffineFastState.compose env53234 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound53234 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53235 : List Nat := [2,4,8,16,32,17,9,256,512,5,2048,4096,268,4357,0,263,4373,2341,5,1,4113,33,16,3,269,16,2048,4372,4096,2340,256,32,256,33,4356,513]

theorem envBound53235 : H12AffineFastState.Bounded env53235 := by
  intro p hp
  have h : env53235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53234_53235 : H12AffineEnvironment.transform 9 5 env53234 = env53235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env53234 == env53235) = true)

theorem identity53235 : scanCanonicalize (H12AffineFastState.compose env53235 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2367) := by decide +kernel

theorem selectedBound53235 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53236 : List Nat := [2,4,8,16,32,17,9,256,512,5,2048,2367,268,2106,0,263,2090,2341,5,1,2350,33,16,3,269,16,2048,2091,2367,2340,256,32,256,33,2107,513]

theorem envBound53236 : H12AffineFastState.Bounded env53236 := by
  intro p hp
  have h : env53236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53235_53236 : H12AffineEnvironment.transform 11 2367 env53235 = env53236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2367 env53235 == env53236) = true)

theorem identity53236 : scanCanonicalize (H12AffineFastState.compose env53236 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound53236 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53237 : List Nat := [2,4,8,16,32,17,9,256,512,5,528,815,268,554,0,263,570,821,5,1,830,33,16,3,269,16,528,571,815,820,256,32,256,33,555,513]

theorem envBound53237 : H12AffineFastState.Bounded env53237 := by
  intro p hp
  have h : env53237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53236_53237 : H12AffineEnvironment.transform 10 528 env53236 = env53237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env53236 == env53237) = true)

theorem identity53237 : scanCanonicalize (H12AffineFastState.compose env53237 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound53237 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53238 : List Nat := [2,4,8,16,27,17,9,256,512,5,528,788,268,529,0,263,513,782,5,1,773,26,16,3,269,16,528,512,788,783,256,27,256,26,528,513]

theorem envBound53238 : H12AffineFastState.Bounded env53238 := by
  intro p hp
  have h : env53238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53237_53238 : H12AffineEnvironment.transform 4 27 env53237 = env53238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env53237 == env53238) = true)

theorem identity53238 : scanCanonicalize (H12AffineFastState.compose env53238 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53238 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53239 : List Nat := [2,4,8,10,1,11,9,256,512,5,522,782,268,523,0,263,513,782,5,1,773,0,10,3,269,10,522,512,782,783,256,1,256,0,522,513]

theorem envBound53239 : H12AffineFastState.Bounded env53239 := by
  intro p hp
  have h : env53239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53238_53239 : H12AffineEnvironment.transform 3 10 env53238 = env53239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53238 == env53239) = true)

theorem identity53239 : scanCanonicalize (H12AffineFastState.compose env53239 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53239 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53240 : List Nat := [2,4,8,10,1,11,9,4,512,5,522,522,8,523,0,3,513,522,5,1,513,0,10,3,9,10,522,512,522,523,4,1,4,0,522,513]

theorem envBound53240 : H12AffineFastState.Bounded env53240 := by
  intro p hp
  have h : env53240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53239_53240 : H12AffineEnvironment.transform 7 4 env53239 = env53240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53239 == env53240) = true)

theorem identity53240 : scanCanonicalize (H12AffineFastState.compose env53240 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53240 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53241 : List Nat := [2,4,4,6,1,7,5,4,512,5,518,518,4,519,0,3,513,518,5,1,513,0,6,3,5,6,518,512,518,519,4,1,4,0,518,513]

theorem envBound53241 : H12AffineFastState.Bounded env53241 := by
  intro p hp
  have h : env53241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53240_53241 : H12AffineEnvironment.transform 2 4 env53240 = env53241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53240 == env53241) = true)

def env53242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,21762,8328,65,215366,115150,396524,35324,497902,243002,256,509971,469430,442169]

theorem envBound53242 : H12AffineFastState.Bounded env53242 := by
  intro p hp
  have h : env53242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53205_53242 : H12AffineEnvironment.transform 20 4161 env53205 = env53242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53205 == env53242) = true)

theorem identity53242 : scanCanonicalize (H12AffineFastState.compose env53242 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound53242 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,169401,73755,21762,8328,65,215366,115150,91402,35324,61704,243002,256,41461,16464,120543]

theorem envBound53243 : H12AffineFastState.Bounded env53243 := by
  intro p hp
  have h : env53243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53242_53243 : H12AffineEnvironment.transform 17 223718 env53242 = env53243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env53242 == env53243) = true)

def env53244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67754,1024,32769,4161,62709,73755,21762,8328,65,75786,115150,91402,35324,61704,119926,256,41461,16464,120543]

theorem envBound53244 : H12AffineFastState.Bounded env53244 := by
  intro p hp
  have h : env53244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53243_53244 : H12AffineEnvironment.transform 16 24908 env53243 = env53244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env53243 == env53244) = true)

theorem identity53244 : scanCanonicalize (H12AffineFastState.compose env53244 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound53244 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env53245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,24908,43049,1024,32769,4161,62709,32920,21762,8328,65,34953,24909,50569,35324,61704,29941,256,41461,16464,30300]

theorem envBound53245 : H12AffineFastState.Bounded env53245 := by
  intro p hp
  have h : env53245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53244_53245 : H12AffineEnvironment.transform 15 41091 env53244 = env53245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env53244 == env53245) = true)

theorem identity53245 : scanCanonicalize (H12AffineFastState.compose env53245 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound53245 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env53246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8323,24908,10281,1024,1,4161,29941,152,21762,8328,65,2185,24909,17801,2556,28936,29941,256,8693,16464,30300]

theorem envBound53246 : H12AffineFastState.Bounded env53246 := by
  intro p hp
  have h : env53246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53245_53246 : H12AffineEnvironment.transform 14 0 env53245 = env53246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env53245 == env53246) = true)

theorem identity53246 : scanCanonicalize (H12AffineFastState.compose env53246 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound53246 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env53247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,0,8323,5393,10281,1024,1,4161,168,152,8543,8328,65,2185,5392,12756,2556,1365,168,256,8693,13325,513]

theorem envBound53247 : H12AffineFastState.Bounded env53247 := by
  intro p hp
  have h : env53247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53246_53247 : H12AffineEnvironment.transform 13 13405 env53246 = env53247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env53246 == env53247) = true)

theorem identity53247 : scanCanonicalize (H12AffineFastState.compose env53247 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound53247 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env53248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,0,342,5393,2556,1024,1,4161,168,152,138,349,65,2185,5392,4097,2556,1365,168,256,32,5592,513]

theorem envBound53248 : H12AffineFastState.Bounded env53248 := by
  intro p hp
  have h : env53248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53247_53248 : H12AffineEnvironment.transform 12 469 env53247 = env53248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env53247 == env53248) = true)

theorem identity53248 : scanCanonicalize (H12AffineFastState.compose env53248 (packedSelected [5,8,11,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound53248 : packedSelected [5,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env53249 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,0,342,5393,2341,1024,1,4161,113,65,83,349,65,2128,5392,4097,2341,1365,113,256,32,5377,513]

theorem envBound53249 : H12AffineFastState.Bounded env53249 := by
  intro p hp
  have h : env53249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53248_53249 : H12AffineEnvironment.transform 6 89 env53248 = env53249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env53248 == env53249) = true)

theorem identity53249 : scanCanonicalize (H12AffineFastState.compose env53249 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound53249 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env53250 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,120,5157,0,34,5221,2129,1024,1,4161,113,65,83,41,65,2128,5220,4097,2129,1057,113,116,32,5237,513]

theorem envBound53250 : H12AffineFastState.Bounded env53250 := by
  intro p hp
  have h : env53250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53249_53250 : H12AffineEnvironment.transform 7 116 env53249 = env53250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env53249 == env53250) = true)

theorem identity53250 : scanCanonicalize (H12AffineFastState.compose env53250 (packedSelected [1,3,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound53250 : packedSelected [1,3,14] rootPS < 2^1333 := by decide +kernel

def env53251 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,0,34,5173,2049,1024,1,4113,33,17,3,41,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound53251 : H12AffineFastState.Bounded env53251 := by
  intro p hp
  have h : env53251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53250_53251 : H12AffineEnvironment.transform 5 16 env53250 = env53251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53250 == env53251) = true)

def env53252 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,0,34,1029,2049,1024,1,33,33,17,3,41,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound53252 : H12AffineFastState.Bounded env53252 := by
  intro p hp
  have h : env53252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53251_53252 : H12AffineEnvironment.transform 11 48 env53251 = env53252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53251 == env53252) = true)

theorem identity53252 : scanCanonicalize (H12AffineFastState.compose env53252 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53253 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,48,40,0,0,34,16,2049,21,1,33,33,17,3,41,17,2048,17,49,2049,52,33,36,32,0,513]

theorem envBound53253 : H12AffineFastState.Bounded env53253 := by
  intro p hp
  have h : env53253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53252_53253 : H12AffineEnvironment.transform 9 21 env53252 = env53253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53252 == env53253) = true)

def env53254 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,8,0,0,2,16,2049,21,1,1,1,17,3,9,17,2048,17,17,2049,20,1,4,0,0,513]

theorem envBound53254 : H12AffineFastState.Bounded env53254 := by
  intro p hp
  have h : env53254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53253_53254 : H12AffineEnvironment.transform 4 0 env53253 = env53254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53253 == env53254) = true)

theorem identity53254 : scanCanonicalize (H12AffineFastState.compose env53254 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound53254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53255 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,16,8,0,0,2,16,523,21,1,1,1,17,3,9,17,522,17,17,523,20,1,4,0,0,513]

theorem envBound53255 : H12AffineFastState.Bounded env53255 := by
  intro p hp
  have h : env53255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53254_53255 : H12AffineEnvironment.transform 10 522 env53254 = env53255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env53254 == env53255) = true)

def leafEnv53255 : List Nat := [2,4,8,16,0,16,9,4,512,21,522,16,8,0,0,2,16,523,21,1,1,1,17,3,20,9,1,17,522,17,17,523,20,1,4,0,4,3,0,513,1,1,0]

def active53255 : List Nat := [0,1,2,3,8]

def tree53255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53255 : H12WitnessSearch.Good tree53255 := H12GlobalWitnessIndex.good

theorem leafIdentity53255 : H12AffineFastState.composeSystem env53255 rootObs = leafEnv53255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53255 rootObs == leafEnv53255) = true)

theorem terminalChecked53255 : H12PackedTerminal.terminalCheckFast leafEnv53255 active53255 tree53255 = true := by decide +kernel

def env53256 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,9,0,0,3,16,2049,21,1,0,0,17,3,8,17,2048,17,16,2049,21,0,5,1,0,513]

theorem envBound53256 : H12AffineFastState.Bounded env53256 := by
  intro p hp
  have h : env53256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53253_53256 : H12AffineEnvironment.transform 4 1 env53253 = env53256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53253 == env53256) = true)

theorem identity53256 : scanCanonicalize (H12AffineFastState.compose env53256 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53257 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,0,0,3,16,0,21,1,0,0,17,3,8,17,1,17,16,0,21,0,5,1,0,513]

theorem envBound53257 : H12AffineFastState.Bounded env53257 := by
  intro p hp
  have h : env53257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53256_53257 : H12AffineEnvironment.transform 10 1 env53256 = env53257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53256 == env53257) = true)

def leafEnv53257 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,0,0,3,16,0,21,1,0,0,17,3,21,8,1,17,1,17,16,0,21,0,5,1,4,2,0,513,1,0,0]

def active53257 : List Nat := [0,1,2,3,8]

def tree53257 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53257 : H12WitnessSearch.Good tree53257 := H12GlobalWitnessIndex.good

theorem leafIdentity53257 : H12AffineFastState.composeSystem env53257 rootObs = leafEnv53257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53257 rootObs == leafEnv53257) = true)

theorem terminalChecked53257 : H12PackedTerminal.terminalCheckFast leafEnv53257 active53257 tree53257 = true := by decide +kernel

def env53258 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,0,34,1028,2049,1024,1,32,33,17,3,41,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound53258 : H12AffineFastState.Bounded env53258 := by
  intro p hp
  have h : env53258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53251_53258 : H12AffineEnvironment.transform 11 49 env53251 = env53258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53251 == env53258) = true)

theorem identity53258 : scanCanonicalize (H12AffineFastState.compose env53258 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53259 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,16,9,1044,0,3,1028,2049,1024,1,1,0,17,3,8,17,2048,1029,17,2049,1024,0,5,1,1044,513]

theorem envBound53259 : H12AffineFastState.Bounded env53259 := by
  intro p hp
  have h : env53259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53258_53259 : H12AffineEnvironment.transform 4 1 env53258 = env53259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53258 == env53259) = true)

def env53260 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,9,0,0,3,16,2049,20,1,1,0,17,3,8,17,2048,17,17,2049,20,0,5,1,0,513]

theorem envBound53260 : H12AffineFastState.Bounded env53260 := by
  intro p hp
  have h : env53260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53259_53260 : H12AffineEnvironment.transform 9 20 env53259 = env53260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env53259 == env53260) = true)

theorem identity53260 : scanCanonicalize (H12AffineFastState.compose env53260 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound53260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53261 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,16,9,0,0,3,16,523,20,1,1,0,17,3,8,17,522,17,17,523,20,0,5,1,0,513]

theorem envBound53261 : H12AffineFastState.Bounded env53261 := by
  intro p hp
  have h : env53261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53260_53261 : H12AffineEnvironment.transform 10 522 env53260 = env53261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env53260 == env53261) = true)

def leafEnv53261 : List Nat := [2,4,8,16,1,16,9,5,512,20,522,16,9,0,0,3,16,523,20,1,1,0,17,3,20,8,1,17,522,17,17,523,20,0,5,1,4,2,0,513,1,1,0]

def active53261 : List Nat := [0,1,2,3,8]

def tree53261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53261 : H12WitnessSearch.Good tree53261 := H12GlobalWitnessIndex.good

theorem leafIdentity53261 : H12AffineFastState.composeSystem env53261 rootObs = leafEnv53261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53261 rootObs == leafEnv53261) = true)

theorem terminalChecked53261 : H12PackedTerminal.terminalCheckFast leafEnv53261 active53261 tree53261 = true := by decide +kernel

def env53262 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,9,1,0,3,17,2049,21,1,1,0,17,3,8,17,2048,16,17,2049,21,0,5,1,1,513]

theorem envBound53262 : H12AffineFastState.Bounded env53262 := by
  intro p hp
  have h : env53262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53259_53262 : H12AffineEnvironment.transform 9 21 env53259 = env53262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53259 == env53262) = true)

theorem identity53262 : scanCanonicalize (H12AffineFastState.compose env53262 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound53262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53263 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,9,1,0,3,17,1,21,1,1,0,17,3,8,17,0,16,17,1,21,0,5,1,1,513]

theorem envBound53263 : H12AffineFastState.Bounded env53263 := by
  intro p hp
  have h : env53263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53262_53263 : H12AffineEnvironment.transform 10 0 env53262 = env53263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env53262 == env53263) = true)

def leafEnv53263 : List Nat := [2,4,8,16,1,16,9,5,512,21,0,16,9,1,0,3,17,1,21,1,1,0,17,3,21,8,1,17,0,16,17,1,21,0,5,1,4,2,1,513,1,1,0]

def active53263 : List Nat := [0,1,2,3,8]

def tree53263 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53263 : H12WitnessSearch.Good tree53263 := H12GlobalWitnessIndex.good

theorem leafIdentity53263 : H12AffineFastState.composeSystem env53263 rootObs = leafEnv53263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53263 rootObs == leafEnv53263) = true)

theorem terminalChecked53263 : H12PackedTerminal.terminalCheckFast leafEnv53263 active53263 tree53263 = true := by decide +kernel

def env53264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67755,1024,32769,4161,62708,73755,21762,8328,65,75787,115150,91402,35324,61704,119927,256,41461,16464,120543]

theorem envBound53264 : H12AffineFastState.Bounded env53264 := by
  intro p hp
  have h : env53264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53243_53264 : H12AffineEnvironment.transform 16 24909 env53243 = env53264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env53243 == env53264) = true)

theorem identity53264 : scanCanonicalize (H12AffineFastState.compose env53264 (packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound53264 : packedSelected [4,7,9,11,14,17,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env53265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21590,24909,23805,1024,32769,4161,62708,29773,21762,8328,65,31837,38296,12636,35324,61704,32801,256,41461,16464,33417]

theorem envBound53265 : H12AffineFastState.Bounded env53265 := by
  intro p hp
  have h : env53265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53264_53265 : H12AffineEnvironment.transform 15 21590 env53264 = env53265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env53264 == env53265) = true)

theorem identity53265 : scanCanonicalize (H12AffineFastState.compose env53265 (packedSelected [3,10,11,17,18,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound53265 : packedSelected [3,10,11,17,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env53266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,21590,24909,23805,1024,0,4161,29941,29773,21762,8328,65,31837,5529,12636,2557,28937,32,256,8692,16464,648]

theorem envBound53266 : H12AffineFastState.Bounded env53266 := by
  intro p hp
  have h : env53266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53265_53266 : H12AffineEnvironment.transform 14 1 env53265 = env53266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env53265 == env53266) = true)

theorem identity53266 : scanCanonicalize (H12AffineFastState.compose env53266 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53266 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env53267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,24909,23668,1024,0,4161,29820,29773,21762,8193,65,31837,5392,12636,2420,28937,32,256,8573,16464,513]

theorem envBound53267 : H12AffineFastState.Bounded env53267 := by
  intro p hp
  have h : env53267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53266_53267 : H12AffineEnvironment.transform 6 9 env53266 = env53267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53266 == env53267) = true)

theorem identity53267 : scanCanonicalize (H12AffineFastState.compose env53267 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53267 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env53268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,16401,23668,1024,0,4161,21792,21777,21762,349,65,23809,5392,4096,2420,20565,32,256,33,16464,513]

theorem envBound53268 : H12AffineFastState.Bounded env53268 := by
  intro p hp
  have h : env53268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53267_53268 : H12AffineEnvironment.transform 12 348 env53267 = env53268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53267 == env53268) = true)

theorem identity53268 : scanCanonicalize (H12AffineFastState.compose env53268 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound53268 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5392,2421,1024,0,4161,33,16,3,349,65,2048,5392,4096,2420,1364,32,256,33,5457,513]

theorem envBound53269 : H12AffineFastState.Bounded env53269 := by
  intro p hp
  have h : env53269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53268_53269 : H12AffineEnvironment.transform 13 5377 env53268 = env53269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env53268 == env53269) = true)

theorem identity53269 : scanCanonicalize (H12AffineFastState.compose env53269 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound53269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,1,343,1141,2421,1024,0,292,33,16,3,349,65,2048,1141,357,2420,1364,32,256,33,1076,513]

theorem envBound53270 : H12AffineFastState.Bounded env53270 := by
  intro p hp
  have h : env53270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53269_53270 : H12AffineEnvironment.transform 11 357 env53269 = env53270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env53269 == env53270) = true)

theorem identity53270 : scanCanonicalize (H12AffineFastState.compose env53270 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound53270 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,357,348,1124,1,343,1141,1,1024,0,292,33,16,3,349,65,372,1141,357,0,1364,32,256,33,1076,513]

theorem envBound53271 : H12AffineFastState.Bounded env53271 := by
  intro p hp
  have h : env53271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53270_53271 : H12AffineEnvironment.transform 10 372 env53270 = env53271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env53270 == env53271) = true)

theorem identity53271 : scanCanonicalize (H12AffineFastState.compose env53271 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound53271 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env53272 : List Nat := [2,4,8,16,32,64,9,256,512,517,372,357,348,609,1,343,624,1,517,0,292,33,16,3,349,65,372,624,357,0,849,32,256,33,561,513]

theorem envBound53272 : H12AffineFastState.Bounded env53272 := by
  intro p hp
  have h : env53272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53271_53272 : H12AffineEnvironment.transform 9 517 env53271 = env53272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env53271 == env53272) = true)

theorem identity53272 : scanCanonicalize (H12AffineFastState.compose env53272 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 340) := by decide +kernel

theorem selectedBound53272 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53273 : List Nat := [2,4,8,16,32,64,9,256,340,337,372,357,348,309,1,343,292,1,337,0,292,33,16,3,349,65,372,292,357,0,5,32,256,33,357,341]

theorem envBound53273 : H12AffineFastState.Bounded env53273 := by
  intro p hp
  have h : env53273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53272_53273 : H12AffineEnvironment.transform 8 340 env53272 = env53273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53272 == env53273) = true)

theorem identity53273 : scanCanonicalize (H12AffineFastState.compose env53273 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53273 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env53274 : List Nat := [2,4,8,16,0,64,9,256,340,337,340,325,348,277,1,343,260,1,337,0,260,1,16,3,349,65,340,260,325,0,5,0,256,1,325,341]

theorem envBound53274 : H12AffineFastState.Bounded env53274 := by
  intro p hp
  have h : env53274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53273_53274 : H12AffineEnvironment.transform 4 0 env53273 = env53274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53273 == env53274) = true)

theorem identity53274 : scanCanonicalize (H12AffineFastState.compose env53274 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53274 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53275 : List Nat := [2,4,8,16,0,0,9,256,276,273,276,261,284,277,1,279,260,1,273,0,260,1,16,3,285,1,276,260,261,0,5,0,256,1,261,277]

theorem envBound53275 : H12AffineFastState.Bounded env53275 := by
  intro p hp
  have h : env53275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53274_53275 : H12AffineEnvironment.transform 5 0 env53274 = env53275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53274 == env53275) = true)

theorem identity53275 : scanCanonicalize (H12AffineFastState.compose env53275 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound53275 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53276 : List Nat := [2,4,8,16,0,0,9,14,26,31,26,11,18,27,1,25,10,1,31,0,10,1,16,3,19,1,26,10,11,0,5,0,14,1,11,27]

theorem envBound53276 : H12AffineFastState.Bounded env53276 := by
  intro p hp
  have h : env53276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53275_53276 : H12AffineEnvironment.transform 7 14 env53275 = env53276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env53275 == env53276) = true)

theorem identity53276 : scanCanonicalize (H12AffineFastState.compose env53276 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53276 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env53277 : List Nat := [2,4,8,0,0,0,9,14,10,15,10,11,2,11,1,9,10,1,15,0,10,1,0,3,3,1,10,10,11,0,5,0,14,1,11,11]

theorem envBound53277 : H12AffineFastState.Bounded env53277 := by
  intro p hp
  have h : env53277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53276_53277 : H12AffineEnvironment.transform 3 0 env53276 = env53277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53276 == env53277) = true)

def env53278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412157,2114883,8328,65,215367,115150,2497709,35324,2590895,2336122,256,509971,469430,2535288]

theorem envBound53278 : H12AffineFastState.Bounded env53278 := by
  intro p hp
  have h : env53278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53204_53278 : H12AffineEnvironment.transform 21 2262521 env53204 = env53278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env53204 == env53278) = true)

def env53279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,21763,8328,65,215367,115150,396525,35324,497903,243002,256,509971,469430,442168]

theorem envBound53279 : H12AffineFastState.Bounded env53279 := by
  intro p hp
  have h : env53279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53278_53279 : H12AffineEnvironment.transform 20 4160 env53278 = env53279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env53278 == env53279) = true)

theorem identity53279 : scanCanonicalize (H12AffineFastState.compose env53279 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236850) := by decide +kernel

theorem selectedBound53279 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236850,1024,32769,4160,169401,120015,21763,8328,65,215367,115150,102879,35324,1501,243002,256,21793,46212,74250]

theorem envBound53280 : H12AffineFastState.Bounded env53280 := by
  intro p hp
  have h : env53280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53279_53280 : H12AffineEnvironment.transform 17 236850 env53279 = env53280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236850 env53279 == env53280) = true)

def env53281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62709,120015,21763,8328,65,75787,115150,102879,35324,1501,119926,256,21793,46212,74250]

theorem envBound53281 : H12AffineFastState.Bounded env53281 := by
  intro p hp
  have h : env53281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53280_53281 : H12AffineEnvironment.transform 16 24908 env53280 = env53281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env53280 == env53281) = true)

def env53282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62589,119879,21763,8192,65,75787,115014,102743,35188,1365,119926,256,21793,46092,74250]

theorem envBound53282 : H12AffineFastState.Bounded env53282 := by
  intro p hp
  have h : env53282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53281_53282 : H12AffineEnvironment.transform 6 8 env53281 = env53282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53281 == env53282) = true)

theorem identity53282 : scanCanonicalize (H12AffineFastState.compose env53282 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound53282 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,24908,35188,1024,32769,4160,62589,41293,21763,8192,65,23809,46156,58461,35188,1365,41340,256,21793,46092,22272]

theorem envBound53283 : H12AffineFastState.Bounded env53283 := by
  intro p hp
  have h : env53283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53282_53283 : H12AffineEnvironment.transform 15 29962 env53282 = env53283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env53282 == env53283) = true)

theorem identity53283 : scanCanonicalize (H12AffineFastState.compose env53283 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound53283 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env53284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,29962,24908,23589,1024,21840,4160,8492,29724,21763,8192,65,23809,24861,12556,23589,1365,29741,256,21793,24925,22272]

theorem envBound53284 : H12AffineFastState.Bounded env53284 := by
  intro p hp
  have h : env53284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53283_53284 : H12AffineEnvironment.transform 14 21841 env53283 = env53284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env53283 == env53284) = true)

theorem identity53284 : scanCanonicalize (H12AffineFastState.compose env53284 (packedSelected [3,5,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 15453) := by decide +kernel

theorem selectedBound53284 : packedSelected [3,5,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env53285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15453,10508,2391,7441,8312,1024,10509,4160,8492,2113,10590,8192,65,8540,7488,12556,8312,1365,2160,256,10620,7424,11101]

theorem envBound53285 : H12AffineFastState.Bounded env53285 := by
  intro p hp
  have h : env53285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53284_53285 : H12AffineEnvironment.transform 13 15453 env53284 = env53285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15453 env53284 == env53285) = true)

theorem identity53285 : scanCanonicalize (H12AffineFastState.compose env53285 (packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound53285 : packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env53286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,8192,13688,8233,114,5172,8312,1024,8232,4160,8492,356,8315,8192,65,8540,5221,12556,8312,1365,341,256,8281,5157,8824]

theorem envBound53286 : H12AffineFastState.Bounded env53286 := by
  intro p hp
  have h : env53286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53285_53286 : H12AffineEnvironment.transform 10 293 env53285 = env53286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env53285 == env53286) = true)

theorem identity53286 : scanCanonicalize (H12AffineFastState.compose env53286 (packedSelected [2,3,5,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53286 : packedSelected [2,3,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env53287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,348,5156,373,114,5172,292,1024,372,4160,112,356,295,348,65,0,5221,4176,292,1365,341,256,261,5157,804]

theorem envBound53287 : H12AffineFastState.Bounded env53287 := by
  intro p hp
  have h : env53287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53286_53287 : H12AffineEnvironment.transform 12 348 env53286 = env53287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53286 == env53287) = true)

theorem identity53287 : scanCanonicalize (H12AffineFastState.compose env53287 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53287 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env53288 : List Nat := [2,4,8,16,32,64,8,4,512,1024,33,4096,88,5156,113,114,5172,32,1024,112,4160,112,96,35,88,65,0,5221,4176,32,1105,81,4,1,5157,544]

theorem envBound53288 : H12AffineFastState.Bounded env53288 := by
  intro p hp
  have h : env53288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53287_53288 : H12AffineEnvironment.transform 7 4 env53287 = env53288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53287 == env53288) = true)

theorem identity53288 : scanCanonicalize (H12AffineFastState.compose env53288 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53288 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53289 : List Nat := [2,4,8,16,32,17,8,4,512,1024,33,4096,9,5156,32,35,5172,32,1024,33,4113,33,49,35,9,16,0,5172,4097,32,1024,0,4,1,5157,544]

theorem envBound53289 : H12AffineFastState.Bounded env53289 := by
  intro p hp
  have h : env53289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53288_53289 : H12AffineEnvironment.transform 5 17 env53288 = env53289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53288 == env53289) = true)

theorem identity53289 : scanCanonicalize (H12AffineFastState.compose env53289 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound53289 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53290 : List Nat := [2,4,8,16,32,17,8,4,512,15,33,4096,9,4139,32,35,4155,32,15,33,4113,33,49,35,9,16,0,4155,4097,32,15,0,4,1,4138,544]

theorem envBound53290 : H12AffineFastState.Bounded env53290 := by
  intro p hp
  have h : env53290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53289_53290 : H12AffineEnvironment.transform 9 15 env53289 = env53290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env53289 == env53290) = true)

def env53291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130174,1024,32769,4160,62588,119878,21763,8193,65,75787,115015,102742,35189,1364,119926,256,21793,46093,74250]

theorem envBound53291 : H12AffineFastState.Bounded env53291 := by
  intro p hp
  have h : env53291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53281_53291 : H12AffineEnvironment.transform 6 9 env53281 = env53291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53281 == env53291) = true)

theorem identity53291 : scanCanonicalize (H12AffineFastState.compose env53291 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound53291 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24908,10281,1024,32769,4160,62588,17,21763,8193,65,64604,5392,17665,35189,1364,33,256,21793,46093,63069]

theorem envBound53292 : H12AffineFastState.Bounded env53292 := by
  intro p hp
  have h : env53292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53291_53292 : H12AffineEnvironment.transform 15 54359 env53291 = env53292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env53291 == env53292) = true)

theorem identity53292 : scanCanonicalize (H12AffineFastState.compose env53292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound53292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,343,24908,10281,1024,21761,4160,8572,17,21763,8193,65,10588,5392,17665,23669,1364,33,256,21793,24845,9053]

theorem envBound53293 : H12AffineFastState.Bounded env53293 := by
  intro p hp
  have h : env53293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53292_53293 : H12AffineEnvironment.transform 14 21760 env53292 = env53293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env53292 == env53293) = true)

theorem identity53293 : scanCanonicalize (H12AffineFastState.compose env53293 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53293 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,343,16400,2421,1024,21761,4160,32,17,21763,349,65,2048,5392,17665,23669,1364,33,256,21793,16465,513]

theorem envBound53294 : H12AffineFastState.Bounded env53294 := by
  intro p hp
  have h : env53294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53293_53294 : H12AffineEnvironment.transform 12 348 env53293 = env53294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53293 == env53294) = true)

theorem identity53294 : scanCanonicalize (H12AffineFastState.compose env53294 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53294 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53295 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21760,262,16400,2340,1024,21761,4113,32,17,21763,268,16,2048,5392,17665,23588,1285,33,256,21793,16384,513]

theorem envBound53295 : H12AffineFastState.Bounded env53295 := by
  intro p hp
  have h : env53295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53294_53295 : H12AffineEnvironment.transform 5 17 env53294 = env53295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53294 == env53295) = true)

theorem identity53295 : scanCanonicalize (H12AffineFastState.compose env53295 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound53295 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53296 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,269,16384,16385,262,16400,2340,1024,16384,1296,32,17,16386,268,16,2048,17,17665,18725,1285,33,256,16416,16384,513]

theorem envBound53296 : H12AffineFastState.Bounded env53296 := by
  intro p hp
  have h : env53296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53295_53296 : H12AffineEnvironment.transform 11 1281 env53295 = env53296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env53295 == env53296) = true)

theorem identity53296 : scanCanonicalize (H12AffineFastState.compose env53296 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 2602) := by decide +kernel

theorem selectedBound53296 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53297 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,269,2602,2603,262,2618,2340,1024,2602,1296,32,17,2600,268,16,2048,17,3883,783,1285,33,256,2570,2602,513]

theorem envBound53297 : H12AffineFastState.Bounded env53297 := by
  intro p hp
  have h : env53297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53296_53297 : H12AffineEnvironment.transform 13 2602 env53296 = env53297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2602 env53296 == env53297) = true)

theorem identity53297 : scanCanonicalize (H12AffineFastState.compose env53297 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound53297 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env53298 : List Nat := [2,4,8,16,32,17,9,256,512,575,2048,830,269,2602,2603,262,2618,2340,575,2602,815,32,17,2600,268,16,2048,17,2324,783,826,33,256,2570,2602,513]

theorem envBound53298 : H12AffineFastState.Bounded env53298 := by
  intro p hp
  have h : env53298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53297_53298 : H12AffineEnvironment.transform 9 575 env53297 = env53298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env53297 == env53298) = true)

theorem identity53298 : scanCanonicalize (H12AffineFastState.compose env53298 (packedSelected [0,2,9] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound53298 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env53299 : List Nat := [2,4,8,16,32,17,9,256,271,304,2048,49,269,2341,2340,262,2357,2340,304,2341,32,32,17,2343,268,16,2048,17,2324,0,53,33,256,2309,2341,270]

theorem envBound53299 : H12AffineFastState.Bounded env53299 := by
  intro p hp
  have h : env53299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53298_53299 : H12AffineEnvironment.transform 8 271 env53298 = env53299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env53298 == env53299) = true)

theorem identity53299 : scanCanonicalize (H12AffineFastState.compose env53299 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53299 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53300 : List Nat := [2,4,8,16,32,17,9,256,271,304,1,49,269,292,293,262,308,293,304,292,32,32,17,294,268,16,1,17,277,0,53,33,256,260,292,270]

theorem envBound53300 : H12AffineFastState.Bounded env53300 := by
  intro p hp
  have h : env53300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53299_53300 : H12AffineEnvironment.transform 10 1 env53299 = env53300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53299 == env53300) = true)

theorem identity53300 : scanCanonicalize (H12AffineFastState.compose env53300 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 55) := by decide +kernel

theorem selectedBound53300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53301 : List Nat := [2,4,8,16,32,17,9,55,56,7,1,49,58,19,18,49,3,18,7,19,32,32,17,17,59,16,1,17,34,0,53,33,55,51,19,57]

theorem envBound53301 : H12AffineFastState.Bounded env53301 := by
  intro p hp
  have h : env53301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53300_53301 : H12AffineEnvironment.transform 7 55 env53300 = env53301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 55 env53300 == env53301) = true)

theorem identity53301 : scanCanonicalize (H12AffineFastState.compose env53301 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound53301 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53302 : List Nat := [2,4,8,3,32,2,9,36,43,7,1,34,41,0,1,34,3,1,7,0,32,32,2,2,40,3,1,2,34,0,38,33,36,32,0,42]

theorem envBound53302 : H12AffineFastState.Bounded env53302 := by
  intro p hp
  have h : env53302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53301_53302 : H12AffineEnvironment.transform 3 3 env53301 = env53302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env53301 == env53302) = true)

theorem identity53302 : scanCanonicalize (H12AffineFastState.compose env53302 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound53302 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53303 : List Nat := [2,4,6,3,32,2,7,36,37,7,1,34,39,0,1,34,3,1,7,0,32,32,2,2,38,3,1,2,34,0,38,33,36,32,0,36]

theorem envBound53303 : H12AffineFastState.Bounded env53303 := by
  intro p hp
  have h : env53303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53302_53303 : H12AffineEnvironment.transform 2 6 env53302 = env53303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env53302 == env53303) = true)

theorem identity53303 : scanCanonicalize (H12AffineFastState.compose env53303 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53304 : List Nat := [2,4,6,3,0,2,7,4,5,7,1,2,7,0,1,2,3,1,7,0,0,0,2,2,6,3,1,2,2,0,6,1,4,0,0,4]

theorem envBound53304 : H12AffineFastState.Bounded env53304 := by
  intro p hp
  have h : env53304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53303_53304 : H12AffineEnvironment.transform 4 0 env53303 = env53304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53303 == env53304) = true)

def env53305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62708,120015,21763,8328,65,75786,115150,102879,35324,1501,119927,256,21793,46212,74250]

theorem envBound53305 : H12AffineFastState.Bounded env53305 := by
  intro p hp
  have h : env53305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53280_53305 : H12AffineEnvironment.transform 16 24909 env53280 = env53305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env53280 == env53305) = true)

def env53306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62588,119879,21763,8192,65,75786,115014,102743,35188,1365,119927,256,21793,46092,74250]

theorem envBound53306 : H12AffineFastState.Bounded env53306 := by
  intro p hp
  have h : env53306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53305_53306 : H12AffineEnvironment.transform 6 8 env53305 = env53306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53305 == env53306) = true)

theorem identity53306 : scanCanonicalize (H12AffineFastState.compose env53306 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53306 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24909,89379,1024,8541,4160,21792,95515,21763,8192,65,75786,90138,77835,10280,1365,95531,256,21793,5456,74250]

theorem envBound53307 : H12AffineFastState.Bounded env53307 := by
  intro p hp
  have h : env53307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53306_53307 : H12AffineEnvironment.transform 14 8540 env53306 = env53307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53306 == env53307) = true)

def env53308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130175,1024,32769,4160,62589,119878,21763,8193,65,75786,115015,102742,35189,1364,119927,256,21793,46093,74250]

theorem envBound53308 : H12AffineFastState.Bounded env53308 := by
  intro p hp
  have h : env53308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53305_53308 : H12AffineEnvironment.transform 6 9 env53305 = env53308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53305 == env53308) = true)

theorem identity53308 : scanCanonicalize (H12AffineFastState.compose env53308 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound53308 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env53309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,24909,64809,1024,32769,4160,62589,54544,21763,8193,65,10588,49169,36864,35189,1364,54561,256,21793,46093,9052]

theorem envBound53309 : H12AffineFastState.Bounded env53309 := by
  intro p hp
  have h : env53309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53308_53309 : H12AffineEnvironment.transform 15 342 env53308 = env53309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env53308 == env53309) = true)

theorem identity53309 : scanCanonicalize (H12AffineFastState.compose env53309 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound53309 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env53310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,24909,2420,1024,29788,4160,32,8525,21763,8193,65,10588,13388,25693,32040,1364,8572,256,21793,16464,9052]

theorem envBound53310 : H12AffineFastState.Bounded env53310 := by
  intro p hp
  have h : env53310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53309_53310 : H12AffineEnvironment.transform 14 29789 env53309 = env53310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env53309 == env53310) = true)

theorem identity53310 : scanCanonicalize (H12AffineFastState.compose env53310 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53310 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env53311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,342,13389,2420,1024,8540,4160,32,8525,3,8193,65,10588,13388,12637,10280,1364,8572,256,33,5456,9052]

theorem envBound53311 : H12AffineFastState.Bounded env53311 := by
  intro p hp
  have h : env53311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53310_53311 : H12AffineEnvironment.transform 13 5376 env53310 = env53311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53310 == env53311) = true)

theorem identity53311 : scanCanonicalize (H12AffineFastState.compose env53311 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53311 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env53312 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8232,35,13389,2049,1024,8233,4160,32,8248,3,8193,65,10281,13388,12328,10280,1057,8201,117,33,5157,8745]

theorem envBound53312 : H12AffineFastState.Bounded env53312 := by
  intro p hp
  have h : env53312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53311_53312 : H12AffineEnvironment.transform 7 117 env53311 = env53312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53311 == env53312) = true)

theorem identity53312 : scanCanonicalize (H12AffineFastState.compose env53312 (packedSelected [0,3,4,5,6,7,9,10,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53312 : packedSelected [0,3,4,5,6,7,9,10,11,23] rootPS < 2^1333 := by decide +kernel

def env53313 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,1,35,5220,2049,1024,0,4160,32,17,3,40,65,2048,5221,4097,2049,1057,32,117,33,5157,512]

theorem envBound53313 : H12AffineFastState.Bounded env53313 := by
  intro p hp
  have h : env53313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53312_53313 : H12AffineEnvironment.transform 12 41 env53312 = env53313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53312 == env53313) = true)

theorem identity53313 : scanCanonicalize (H12AffineFastState.compose env53313 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound53313 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53314 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,41,5125,1,35,5140,2049,1024,0,4144,32,17,3,40,49,2048,5141,4097,2049,1057,32,5,33,5157,512]

theorem envBound53314 : H12AffineFastState.Bounded env53314 := by
  intro p hp
  have h : env53314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53313_53314 : H12AffineEnvironment.transform 5 48 env53313 = env53314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env53313 == env53314) = true)

theorem identity53314 : scanCanonicalize (H12AffineFastState.compose env53314 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53314 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53315 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,1,2,5140,2049,1024,0,4113,1,17,3,9,16,2048,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound53315 : H12AffineFastState.Bounded env53315 := by
  intro p hp
  have h : env53315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53314_53315 : H12AffineEnvironment.transform 4 1 env53314 = env53315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53314 == env53315) = true)

theorem identity53315 : scanCanonicalize (H12AffineFastState.compose env53315 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound53315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53316 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3076,8,2049,1,2,2064,2049,1024,0,3093,1,17,3,9,16,2048,2065,3077,2049,1024,1,5,0,2048,512]

theorem envBound53316 : H12AffineFastState.Bounded env53316 := by
  intro p hp
  have h : env53316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53315_53316 : H12AffineEnvironment.transform 11 3076 env53315 = env53316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env53315 == env53316) = true)

theorem identity53316 : scanCanonicalize (H12AffineFastState.compose env53316 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound53316 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53317 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,1,2,2064,2049,21,0,2048,1,17,3,9,16,2048,2065,2064,2049,21,1,5,0,2048,512]

theorem envBound53317 : H12AffineFastState.Bounded env53317 := by
  intro p hp
  have h : env53317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53316_53317 : H12AffineEnvironment.transform 9 21 env53316 = env53317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env53316 == env53317) = true)

def env53318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,21762,8328,65,215367,115150,396524,35324,497902,243003,256,509971,469430,442169]

theorem envBound53318 : H12AffineFastState.Bounded env53318 := by
  intro p hp
  have h : env53318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53278_53318 : H12AffineEnvironment.transform 20 4161 env53278 = env53318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env53278 == env53318) = true)

theorem identity53318 : scanCanonicalize (H12AffineFastState.compose env53318 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53318 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,169400,412157,21762,8328,65,158028,57797,396524,35324,440549,169264,256,452632,395709,442169]

theorem envBound53319 : H12AffineFastState.Bounded env53319 := by
  intro p hp
  have h : env53319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53318_53319 : H12AffineEnvironment.transform 15 8203 env53318 = env53319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53318 == env53319) = true)

theorem identity53319 : scanCanonicalize (H12AffineFastState.compose env53319 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound53319 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env53320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179512,1024,32769,4161,169400,62661,21762,8328,65,158028,57797,45524,35324,1501,169264,256,21792,46213,513]

theorem envBound53320 : H12AffineFastState.Bounded env53320 := by
  intro p hp
  have h : env53320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53319_53320 : H12AffineEnvironment.transform 17 179512 env53319 = env53320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env53319 == env53320) = true)

theorem identity53320 : scanCanonicalize (H12AffineFastState.compose env53320 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound53320 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env53321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8203,131072,157872,1024,21897,4161,147504,8525,21762,8328,65,158028,13389,25692,23668,1501,147640,256,21792,24845,513]

theorem envBound53321 : H12AffineFastState.Bounded env53321 := by
  intro p hp
  have h : env53321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53320_53321 : H12AffineEnvironment.transform 14 21896 env53320 = env53321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env53320 == env53321) = true)

theorem identity53321 : scanCanonicalize (H12AffineFastState.compose env53321 (packedSelected [1,2,5,6,7,8,14,15,16,17,18,23,24,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound53321 : packedSelected [1,2,5,6,7,8,14,15,16,17,18,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env53322 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21840,8203,131072,157800,1024,21841,4161,147504,8525,21762,8272,65,158028,13389,25692,23668,1285,147552,256,21792,24845,513]

theorem envBound53322 : H12AffineFastState.Bounded env53322 := by
  intro p hp
  have h : env53322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53321_53322 : H12AffineEnvironment.transform 6 88 env53321 = env53322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env53321 == env53322) = true)

theorem identity53322 : scanCanonicalize (H12AffineFastState.compose env53322 (packedSelected [2,6,17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound53322 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env53323 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21840,8203,24908,2340,1024,21841,4161,8572,8525,21762,8272,65,2048,13389,25692,23668,1285,8492,256,21792,24845,513]

theorem envBound53323 : H12AffineFastState.Bounded env53323 := by
  intro p hp
  have h : env53323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53322_53323 : H12AffineEnvironment.transform 16 24908 env53322 = env53323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env53322 == env53323) = true)

theorem identity53323 : scanCanonicalize (H12AffineFastState.compose env53323 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53323 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env53324 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21840,342,16401,2340,1024,21841,4161,33,16,21762,269,65,2048,5392,17665,23668,1285,113,256,21792,16464,513]

theorem envBound53324 : H12AffineFastState.Bounded env53324 := by
  intro p hp
  have h : env53324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53323_53324 : H12AffineEnvironment.transform 12 349 env53323 = env53324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53323 == env53324) = true)

theorem identity53324 : scanCanonicalize (H12AffineFastState.compose env53324 (packedSelected [2,5,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound53324 : packedSelected [2,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env53325 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,349,16384,20789,342,16401,2340,101,20788,4161,33,16,20839,269,65,2048,4469,16740,22545,352,113,256,20805,16464,513]

theorem envBound53325 : H12AffineFastState.Bounded env53325 := by
  intro p hp
  have h : env53325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53324_53325 : H12AffineEnvironment.transform 9 101 env53324 = env53325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env53324 == env53325) = true)

theorem identity53325 : scanCanonicalize (H12AffineFastState.compose env53325 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound53325 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53326 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,349,80,4453,342,65,2340,101,4452,4161,33,16,4407,269,65,2048,4469,308,6209,352,113,256,4373,0,513]

theorem envBound53326 : H12AffineFastState.Bounded env53326 := by
  intro p hp
  have h : env53326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53325_53326 : H12AffineEnvironment.transform 13 80 env53325 = env53326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env53325 == env53326) = true)

theorem identity53326 : scanCanonicalize (H12AffineFastState.compose env53326 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53326 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env53327 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,1,4404,263,16,2340,52,4405,4112,33,16,4407,269,16,2048,4388,308,6160,305,32,256,4373,0,513]

theorem envBound53327 : H12AffineFastState.Bounded env53327 := by
  intro p hp
  have h : env53327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53326_53327 : H12AffineEnvironment.transform 5 17 env53326 = env53327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53326 == env53327) = true)

def env53328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound53328 : H12AffineFastState.Bounded env53328 := by
  intro p hp
  have h : env53328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53064_53328 : H12AffineEnvironment.transform 18 1025 env53064 = env53328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env53064 == env53328) = true)

theorem identity53328 : scanCanonicalize (H12AffineFastState.compose env53328 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound53328 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env53329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,4194304,8388608,16777216,8328,65,29868033,17066162,8763758,8830976,25265169,21268990,257,25438354,25479478,25207751]

theorem envBound53329 : H12AffineFastState.Bounded env53329 := by
  intro p hp
  have h : env53329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53328_53329 : H12AffineEnvironment.transform 20 388158 env53328 = env53329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env53328 == env53329) = true)

def env53330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,4194304,8388608,351656,8328,65,12754345,79130,8763758,8830976,8706489,4314198,257,8484154,8492190,8781423]

theorem envBound53330 : H12AffineFastState.Bounded env53330 := by
  intro p hp
  have h : env53330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53329_53330 : H12AffineEnvironment.transform 23 351656 env53329 = env53330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351656 env53329 == env53330) = true)

def env53331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,4194304,8388608,95496,8328,65,12754345,79130,8491470,8579232,8450329,4314198,257,8484154,8492190,8509135]

theorem envBound53331 : H12AffineFastState.Bounded env53331 := by
  intro p hp
  have h : env53331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53330_53331 : H12AffineEnvironment.transform 17 10400 env53330 = env53331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env53330 == env53331) = true)

def env53332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,32,8388608,95496,8328,65,8560009,79130,8491470,8579232,8450329,119926,257,8484154,8492190,8509135]

theorem envBound53332 : H12AffineFastState.Bounded env53332 := by
  intro p hp
  have h : env53332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53331_53332 : H12AffineEnvironment.transform 21 32 env53331 = env53332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53331 == env53332) = true)

theorem identity53332 : scanCanonicalize (H12AffineFastState.compose env53332 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53332 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58517,32,8388608,21763,8328,65,8560009,5393,8434117,8579232,8450329,62589,257,8410417,8434837,8451780]

theorem envBound53333 : H12AffineFastState.Bounded env53333 := by
  intro p hp
  have h : env53333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53332_53333 : H12AffineEnvironment.transform 15 8203 env53332 = env53333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53332 == env53333) = true)

def env53334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58397,32,8388608,21763,8192,65,8559873,5393,8433997,8579112,8450329,62589,257,8410417,8434717,8451660]

theorem envBound53334 : H12AffineFastState.Bounded env53334 := by
  intro p hp
  have h : env53334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53333_53334 : H12AffineEnvironment.transform 6 8 env53333 = env53334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53333 == env53334) = true)

theorem identity53334 : scanCanonicalize (H12AffineFastState.compose env53334 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound53334 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58397,32,17,21763,8192,65,171280,5393,45404,190521,61704,62589,257,21792,46092,63069]

theorem envBound53335 : H12AffineFastState.Bounded env53335 := by
  intro p hp
  have h : env53335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53334_53335 : H12AffineEnvironment.transform 22 17 env53334 = env53335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env53334 == env53335) = true)

theorem identity53335 : scanCanonicalize (H12AffineFastState.compose env53335 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 16692) := by decide +kernel

theorem selectedBound53335 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env53336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16692,10280,1025,32769,58397,32,17,21763,8192,65,56356,5393,45404,43277,61704,62589,257,21792,46092,63069]

theorem envBound53336 : H12AffineFastState.Bounded env53336 := by
  intro p hp
  have h : env53336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53335_53336 : H12AffineEnvironment.transform 16 16692 env53335 = env53336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16692 env53335 == env53336) = true)

theorem identity53336 : scanCanonicalize (H12AffineFastState.compose env53336 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound53336 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env53337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8203,16692,10280,1025,80,25676,32,17,21763,8192,65,23669,5393,12557,10588,29017,29740,257,21792,13405,30220]

theorem envBound53337 : H12AffineFastState.Bounded env53337 := by
  intro p hp
  have h : env53337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53336_53337 : H12AffineEnvironment.transform 14 81 env53336 = env53337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env53336 == env53337) = true)

theorem identity53337 : scanCanonicalize (H12AffineFastState.compose env53337 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound53337 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env53338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,81,8203,4096,10280,1025,80,13688,32,17,1079,8192,65,3393,5393,12557,10588,8301,9496,257,1044,13405,10040]

theorem envBound53338 : H12AffineFastState.Bounded env53338 := by
  intro p hp
  have h : env53338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53337_53338 : H12AffineEnvironment.transform 13 4404 env53337 = env53338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env53337 == env53338) = true)

theorem identity53338 : scanCanonicalize (H12AffineFastState.compose env53338 (packedSelected [1,3,5,6,7,8,9,11,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound53338 : packedSelected [1,3,5,6,7,8,9,11,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env53339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4404,81,1047,4096,3124,1025,80,4452,32,17,1079,1052,65,3393,5393,5393,3392,1137,260,257,1044,4161,804]

theorem envBound53339 : H12AffineFastState.Bounded env53339 := by
  intro p hp
  have h : env53339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53338_53339 : H12AffineEnvironment.transform 12 1052 env53338 = env53339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env53338 == env53339) = true)

theorem identity53339 : scanCanonicalize (H12AffineFastState.compose env53339 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53339 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53340 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,269,4404,81,262,4096,2341,272,80,4452,32,17,294,269,65,2128,4096,4096,2129,352,260,257,261,4161,804]

theorem envBound53340 : H12AffineFastState.Bounded env53340 := by
  intro p hp
  have h : env53340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53339_53340 : H12AffineEnvironment.transform 9 273 env53339 = env53340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53339 == env53340) = true)

theorem identity53340 : scanCanonicalize (H12AffineFastState.compose env53340 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound53340 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env53341 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2405,269,2129,81,262,2405,2341,272,80,2049,32,17,294,269,65,2128,2405,2405,2129,352,260,257,261,2340,804]

theorem envBound53341 : H12AffineFastState.Bounded env53341 := by
  intro p hp
  have h : env53341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53340_53341 : H12AffineEnvironment.transform 11 2405 env53340 = env53341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env53340 == env53341) = true)

theorem identity53341 : scanCanonicalize (H12AffineFastState.compose env53341 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53341 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53342 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2113,41,2129,81,34,2113,2049,52,80,2049,32,17,2,41,65,2128,2113,2113,2129,68,32,37,33,2048,512]

theorem envBound53342 : H12AffineFastState.Bounded env53342 := by
  intro p hp
  have h : env53342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53341_53342 : H12AffineEnvironment.transform 7 36 env53341 = env53342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53341 == env53342) = true)

theorem identity53342 : scanCanonicalize (H12AffineFastState.compose env53342 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound53342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53343 : List Nat := [2,4,8,16,32,49,8,36,512,53,2048,2096,41,2080,32,34,2096,2049,52,33,2049,32,17,2,41,48,2081,2096,2096,2080,53,32,37,33,2048,512]

theorem envBound53343 : H12AffineFastState.Bounded env53343 := by
  intro p hp
  have h : env53343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53342_53343 : H12AffineEnvironment.transform 5 49 env53342 = env53343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env53342 == env53343) = true)

theorem identity53343 : scanCanonicalize (H12AffineFastState.compose env53343 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53343 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53344 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,2065,8,2049,1,3,2065,2049,21,0,2049,1,17,2,8,17,2048,2065,2065,2049,20,1,4,0,2048,512]

theorem envBound53344 : H12AffineFastState.Bounded env53344 := by
  intro p hp
  have h : env53344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53343_53344 : H12AffineEnvironment.transform 4 1 env53343 = env53344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53343 == env53344) = true)

theorem identity53344 : scanCanonicalize (H12AffineFastState.compose env53344 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53345 : List Nat := [2,4,8,16,1,16,8,5,1,20,2048,2065,8,2049,1,3,2065,2049,21,0,2049,1,17,2,8,17,2048,2065,2065,2049,20,1,4,0,2048,1]

theorem envBound53345 : H12AffineFastState.Bounded env53345 := by
  intro p hp
  have h : env53345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53344_53345 : H12AffineEnvironment.transform 8 1 env53344 = env53345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53344 == env53345) = true)

theorem identity53345 : scanCanonicalize (H12AffineFastState.compose env53345 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound53345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53346 : List Nat := [2,4,8,4,1,4,8,5,1,0,2048,2053,8,2049,1,3,2053,2049,1,0,2049,1,5,2,8,5,2048,2053,2053,2049,0,1,4,0,2048,1]

theorem envBound53346 : H12AffineFastState.Bounded env53346 := by
  intro p hp
  have h : env53346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53345_53346 : H12AffineEnvironment.transform 3 4 env53345 = env53346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env53345 == env53346) = true)

def leafEnv53346 : List Nat := [2,4,8,4,1,4,8,5,1,0,2048,2053,8,2049,1,3,2053,2049,1,0,2049,1,5,2,1,8,1,5,2048,2053,2053,2049,0,1,4,0,5,3,2048,1,1,2048,0]

def active53346 : List Nat := [0,1,2,10]

def tree53346 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53346 : H12WitnessSearch.Good tree53346 := H12GlobalWitnessIndex.good

theorem leafIdentity53346 : H12AffineFastState.composeSystem env53346 rootObs = leafEnv53346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53346 rootObs == leafEnv53346) = true)

theorem terminalChecked53346 : H12PackedTerminal.terminalCheckFast leafEnv53346 active53346 tree53346 = true := by decide +kernel

def env53347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58396,32,8388608,21763,8193,65,8559872,5393,8433996,8579113,8450329,62589,257,8410417,8434716,8451661]

theorem envBound53347 : H12AffineFastState.Bounded env53347 := by
  intro p hp
  have h : env53347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53333_53347 : H12AffineEnvironment.transform 6 9 env53333 = env53347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53333 == env53347) = true)

theorem identity53347 : scanCanonicalize (H12AffineFastState.compose env53347 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound53347 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58396,32,41292,21763,8193,65,146508,5393,4096,149861,20565,62589,257,62589,5456,22273]

theorem envBound53348 : H12AffineFastState.Bounded env53348 := by
  intro p hp
  have h : env53348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53347_53348 : H12AffineEnvironment.transform 22 41292 env53347 = env53348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env53347 == env53348) = true)

theorem identity53348 : scanCanonicalize (H12AffineFastState.compose env53348 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(16+1) ^^^ 57448) := by decide +kernel

theorem selectedBound53348 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env53349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57448,10281,1025,32769,58396,32,41292,21763,8193,65,56356,5393,4096,43277,20565,62589,257,62589,5456,22273]

theorem envBound53349 : H12AffineFastState.Bounded env53349 := by
  intro p hp
  have h : env53349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53348_53349 : H12AffineEnvironment.transform 16 57448 env53348 = env53349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57448 env53348 == env53349) = true)

theorem identity53349 : scanCanonicalize (H12AffineFastState.compose env53349 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound53349 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env53350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,8203,46108,10281,1025,32769,45160,32,41292,375,8193,65,34896,5393,4096,43277,1057,40969,257,40969,5456,885]

theorem envBound53350 : H12AffineFastState.Bounded env53350 := by
  intro p hp
  have h : env53350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53349_53350 : H12AffineEnvironment.transform 13 5236 env53349 = env53350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env53349 == env53350) = true)

theorem identity53350 : scanCanonicalize (H12AffineFastState.compose env53350 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound53350 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env53351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8313,8203,5221,10281,1025,8312,4113,32,309,375,8193,65,10281,5393,4096,2420,1057,112,257,112,5456,885]

theorem envBound53351 : H12AffineFastState.Bounded env53351 := by
  intro p hp
  have h : env53351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53350_53351 : H12AffineEnvironment.transform 14 8313 env53350 = env53351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env53350 == env53351) = true)

theorem identity53351 : scanCanonicalize (H12AffineFastState.compose env53351 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53351 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5236,293,343,5221,2421,1025,292,4113,32,309,375,349,65,2421,5393,4096,2420,1057,112,257,112,5456,885]

theorem envBound53352 : H12AffineFastState.Bounded env53352 := by
  intro p hp
  have h : env53352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53351_53352 : H12AffineEnvironment.transform 12 348 env53351 = env53352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53351 == env53352) = true)

theorem identity53352 : scanCanonicalize (H12AffineFastState.compose env53352 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound53352 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env53353 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,80,34,5221,2048,1025,81,4113,32,64,2,40,65,2048,5220,4096,2049,1057,112,116,112,5157,512]

theorem envBound53353 : H12AffineFastState.Bounded env53353 := by
  intro p hp
  have h : env53353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53352_53353 : H12AffineEnvironment.transform 7 117 env53352 = env53353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env53352 == env53353) = true)

theorem identity53353 : scanCanonicalize (H12AffineFastState.compose env53353 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53353 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53354 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,9,5204,80,2,5189,2048,1025,81,4113,0,64,2,8,65,2048,5188,4096,2049,1025,80,84,80,5125,512]

theorem envBound53354 : H12AffineFastState.Bounded env53354 := by
  intro p hp
  have h : env53354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53353_53354 : H12AffineEnvironment.transform 4 0 env53353 = env53354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53353 == env53354) = true)

theorem identity53354 : scanCanonicalize (H12AffineFastState.compose env53354 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound53354 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env53355 : List Nat := [2,4,8,16,0,64,9,85,512,1024,80,4096,9,5204,80,2,5189,80,1025,81,4113,0,64,2,8,65,80,5188,4096,81,1025,80,84,80,5125,512]

theorem envBound53355 : H12AffineFastState.Bounded env53355 := by
  intro p hp
  have h : env53355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53354_53355 : H12AffineEnvironment.transform 10 80 env53354 = env53355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env53354 == env53355) = true)

theorem identity53355 : scanCanonicalize (H12AffineFastState.compose env53355 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound53355 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53356 : List Nat := [2,4,8,16,0,64,9,85,512,1024,80,1028,9,80,80,2,65,80,1025,81,1045,0,64,2,8,65,80,64,1028,81,1025,80,84,80,1,512]

theorem envBound53356 : H12AffineFastState.Bounded env53356 := by
  intro p hp
  have h : env53356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53355_53356 : H12AffineEnvironment.transform 11 1028 env53355 = env53356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env53355 == env53356) = true)

theorem identity53356 : scanCanonicalize (H12AffineFastState.compose env53356 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53357 : List Nat := [2,4,8,16,0,17,9,4,512,1024,1,1028,9,1,1,2,16,1,1025,0,1045,0,17,2,8,16,1,17,1028,0,1025,1,5,1,1,512]

theorem envBound53357 : H12AffineFastState.Bounded env53357 := by
  intro p hp
  have h : env53357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53356_53357 : H12AffineEnvironment.transform 5 17 env53356 = env53357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53356 == env53357) = true)

theorem identity53357 : scanCanonicalize (H12AffineFastState.compose env53357 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 512) := by decide +kernel

theorem selectedBound53357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53358 : List Nat := [2,4,8,16,0,17,9,4,512,512,1,516,9,1,1,2,16,1,513,0,533,0,17,2,8,16,1,17,516,0,513,1,5,1,1,512]

theorem envBound53358 : H12AffineFastState.Bounded env53358 := by
  intro p hp
  have h : env53358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53357_53358 : H12AffineEnvironment.transform 9 512 env53357 = env53358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 512 env53357 == env53358) = true)

theorem identity53358 : scanCanonicalize (H12AffineFastState.compose env53358 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound53358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53359 : List Nat := [2,4,8,16,0,17,9,4,5,5,1,1,9,1,1,2,16,1,4,0,16,0,17,2,8,16,1,17,1,0,4,1,5,1,1,5]

theorem envBound53359 : H12AffineFastState.Bounded env53359 := by
  intro p hp
  have h : env53359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53358_53359 : H12AffineEnvironment.transform 8 5 env53358 = env53359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env53358 == env53359) = true)

theorem identity53359 : scanCanonicalize (H12AffineFastState.compose env53359 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53359 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53360 : List Nat := [2,4,8,11,0,10,9,4,5,5,1,1,9,1,1,2,11,1,4,0,11,0,10,2,8,11,1,10,1,0,4,1,5,1,1,5]

theorem envBound53360 : H12AffineFastState.Bounded env53360 := by
  intro p hp
  have h : env53360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53359_53360 : H12AffineEnvironment.transform 3 11 env53359 = env53360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53359 == env53360) = true)

def env53361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,33,8388608,95496,8328,65,8560008,79130,8491470,8579232,8450329,119927,257,8484154,8492190,8509135]

theorem envBound53361 : H12AffineFastState.Bounded env53361 := by
  intro p hp
  have h : env53361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53331_53361 : H12AffineEnvironment.transform 21 33 env53331 = env53361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env53331 == env53361) = true)

theorem identity53361 : scanCanonicalize (H12AffineFastState.compose env53361 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound53361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,33,73754,95496,8328,65,245138,79130,45524,247994,119043,119927,257,21792,46212,63189]

theorem envBound53362 : H12AffineFastState.Bounded env53362 := by
  intro p hp
  have h : env53362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53361_53362 : H12AffineEnvironment.transform 22 73754 env53361 = env53362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env53361 == env53362) = true)

def env53363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,33,73754,95496,8192,65,245018,79130,45404,247858,119043,119927,257,21792,46092,63069]

theorem envBound53363 : H12AffineFastState.Bounded env53363 := by
  intro p hp
  have h : env53363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53362_53363 : H12AffineEnvironment.transform 6 8 env53362 = env53363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53362 == env53363) = true)

theorem identity53363 : scanCanonicalize (H12AffineFastState.compose env53363 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound53363 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58397,33,17,21763,8192,65,171281,5393,45404,190521,61704,62588,257,21792,46092,63069]

theorem envBound53364 : H12AffineFastState.Bounded env53364 := by
  intro p hp
  have h : env53364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53363_53364 : H12AffineEnvironment.transform 15 8203 env53363 = env53364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env53363 == env53364) = true)

theorem identity53364 : scanCanonicalize (H12AffineFastState.compose env53364 (packedSelected [2,4,6,11,16,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound53364 : packedSelected [2,4,6,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env53365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,8203,131072,10280,1025,293,25913,33,17,21763,8192,65,138293,5393,12408,157981,28716,30040,257,21792,13608,30585]

theorem envBound53365 : H12AffineFastState.Bounded env53365 := by
  intro p hp
  have h : env53365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53364_53365 : H12AffineEnvironment.transform 14 292 env53364 = env53365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env53364 == env53365) = true)

theorem identity53365 : scanCanonicalize (H12AffineFastState.compose env53365 (packedSelected [0,1,2,5,6,7,8,11,18,19,20,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound53365 : packedSelected [0,1,2,5,6,7,8,11,18,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env53366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,8203,16401,10280,1025,293,25913,33,17,21763,8192,65,23588,5393,12408,10508,28716,30040,257,21792,13608,30585]

theorem envBound53366 : H12AffineFastState.Bounded env53366 := by
  intro p hp
  have h : env53366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53365_53366 : H12AffineEnvironment.transform 16 16401 env53365 = env53366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53365 == env53366) = true)

theorem identity53366 : scanCanonicalize (H12AffineFastState.compose env53366 (packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound53366 : packedSelected [0,1,4,6,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env53367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,16384,292,83,16401,2160,1025,293,17761,33,17,21763,88,65,23588,5393,4128,2388,20596,21760,257,21792,5488,22305]

theorem envBound53367 : H12AffineFastState.Bounded env53367 := by
  intro p hp
  have h : env53367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53366_53367 : H12AffineEnvironment.transform 12 88 env53366 = env53367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env53366 == env53367) = true)

theorem identity53367 : scanCanonicalize (H12AffineFastState.compose env53367 (packedSelected [0,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53367 : packedSelected [0,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env53368 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,16384,292,2,16401,2081,1025,293,17712,33,17,21763,9,16,23588,5393,4128,2309,20517,21760,257,21792,5409,22305]

theorem envBound53368 : H12AffineFastState.Bounded env53368 := by
  intro p hp
  have h : env53368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53367_53368 : H12AffineEnvironment.transform 5 17 env53367 = env53368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53367 == env53368) = true)

theorem identity53368 : scanCanonicalize (H12AffineFastState.compose env53368 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound53368 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53369 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,9,16384,292,2,16401,2081,305,293,16384,33,17,20531,9,16,22804,4129,4128,2309,20517,20528,257,20496,4113,21009]

theorem envBound53369 : H12AffineFastState.Bounded env53369 := by
  intro p hp
  have h : env53369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53368_53369 : H12AffineEnvironment.transform 9 304 env53368 = env53369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env53368 == env53369) = true)

theorem identity53369 : scanCanonicalize (H12AffineFastState.compose env53369 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound53369 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env53370 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,9,4144,292,2,4129,2081,305,293,4144,33,17,3,9,16,2340,4129,4128,2309,21,0,257,32,4113,545]

theorem envBound53370 : H12AffineFastState.Bounded env53370 := by
  intro p hp
  have h : env53370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53369_53370 : H12AffineEnvironment.transform 13 4144 env53369 = env53370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env53369 == env53370) = true)

theorem identity53370 : scanCanonicalize (H12AffineFastState.compose env53370 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53370 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53371 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,9,4144,32,2,4129,2081,53,33,4144,33,17,3,9,16,2080,4129,4128,2049,21,0,5,32,4113,545]

theorem envBound53371 : H12AffineFastState.Bounded env53371 := by
  intro p hp
  have h : env53371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53370_53371 : H12AffineEnvironment.transform 7 4 env53370 = env53371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53370 == env53371) = true)

theorem identity53371 : scanCanonicalize (H12AffineFastState.compose env53371 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound53371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53372 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,529,9,545,32,2,560,2081,53,33,545,33,17,3,9,16,2080,560,561,2049,21,0,5,32,512,545]

theorem envBound53372 : H12AffineFastState.Bounded env53372 := by
  intro p hp
  have h : env53372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53371_53372 : H12AffineEnvironment.transform 11 529 env53371 = env53372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env53371 == env53372) = true)

theorem identity53372 : scanCanonicalize (H12AffineFastState.compose env53372 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound53372 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53373 : List Nat := [2,4,8,16,32,17,8,4,512,52,529,529,9,545,32,2,560,560,53,33,545,33,17,3,9,16,561,560,561,528,21,0,5,32,512,545]

theorem envBound53373 : H12AffineFastState.Bounded env53373 := by
  intro p hp
  have h : env53373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53372_53373 : H12AffineEnvironment.transform 10 529 env53372 = env53373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env53372 == env53373) = true)

theorem identity53373 : scanCanonicalize (H12AffineFastState.compose env53373 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53373 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env53374 : List Nat := [2,4,8,16,1,17,8,4,512,21,529,529,9,512,1,2,529,529,20,0,512,0,17,3,9,16,528,529,528,528,21,0,5,1,512,512]

theorem envBound53374 : H12AffineFastState.Bounded env53374 := by
  intro p hp
  have h : env53374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53373_53374 : H12AffineEnvironment.transform 4 1 env53373 = env53374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53373 == env53374) = true)

theorem identity53374 : scanCanonicalize (H12AffineFastState.compose env53374 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound53374 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53375 : List Nat := [2,4,8,16,1,17,8,4,4,21,21,21,9,4,1,2,21,21,20,0,4,0,17,3,9,16,20,21,20,20,21,0,5,1,4,4]

theorem envBound53375 : H12AffineFastState.Bounded env53375 := by
  intro p hp
  have h : env53375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53374_53375 : H12AffineEnvironment.transform 8 4 env53374 = env53375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env53374 == env53375) = true)

theorem identity53375 : scanCanonicalize (H12AffineFastState.compose env53375 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound53375 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53376 : List Nat := [2,4,8,13,1,12,8,4,4,8,8,8,9,4,1,2,8,8,9,0,4,0,12,3,9,13,9,8,9,9,8,0,5,1,4,4]

theorem envBound53376 : H12AffineFastState.Bounded env53376 := by
  intro p hp
  have h : env53376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53375_53376 : H12AffineEnvironment.transform 3 13 env53375 = env53376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env53375 == env53376) = true)

theorem identity53376 : scanCanonicalize (H12AffineFastState.compose env53376 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53376 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53377 : List Nat := [2,4,0,5,1,4,0,4,4,0,0,0,1,4,1,2,0,0,1,0,4,0,4,3,1,5,1,0,1,1,0,0,5,1,4,4]

theorem envBound53377 : H12AffineFastState.Bounded env53377 := by
  intro p hp
  have h : env53377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53376_53377 : H12AffineEnvironment.transform 2 0 env53376 = env53377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53376 == env53377) = true)

theorem identity53377 : scanCanonicalize (H12AffineFastState.compose env53377 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53377 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53378 : List Nat := [1,4,0,5,1,4,0,4,4,0,0,0,1,4,1,1,0,0,1,0,4,0,4,0,1,5,1,0,1,1,0,0,5,1,4,4]

theorem envBound53378 : H12AffineFastState.Bounded env53378 := by
  intro p hp
  have h : env53378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53377_53378 : H12AffineEnvironment.transform 0 1 env53377 = env53378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53377 == env53378) = true)

def env53379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,33,73754,95496,8193,65,245019,79130,45405,247859,119043,119927,257,21792,46093,63068]

theorem envBound53379 : H12AffineFastState.Bounded env53379 := by
  intro p hp
  have h : env53379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53362_53379 : H12AffineEnvironment.transform 6 9 env53362 = env53379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53362 == env53379) = true)

theorem identity53379 : scanCanonicalize (H12AffineFastState.compose env53379 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound53379 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10281,1025,32769,17729,33,41292,62558,8193,65,146509,46156,45405,149861,20565,21793,257,21792,46093,63068]

theorem envBound53380 : H12AffineFastState.Bounded env53380 := by
  intro p hp
  have h : env53380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53379_53380 : H12AffineEnvironment.transform 15 33110 env53379 = env53380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env53379 == env53380) = true)

theorem identity53380 : scanCanonicalize (H12AffineFastState.compose env53380 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound53380 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env53381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,5393,10281,1025,32769,17729,33,41292,62558,8193,65,10588,46156,45405,23668,20565,21793,257,21792,46093,63068]

theorem envBound53381 : H12AffineFastState.Bounded env53381 := by
  intro p hp
  have h : env53381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53380_53381 : H12AffineEnvironment.transform 16 5393 env53380 = env53381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env53380 == env53381) = true)

def env53382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,4194304,8388608,95497,8328,65,12754345,79130,8491471,8579233,8450328,4314198,257,8484154,8492190,8509134]

theorem envBound53382 : H12AffineFastState.Bounded env53382 := by
  intro p hp
  have h : env53382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53330_53382 : H12AffineEnvironment.transform 17 10401 env53330 = env53382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env53330 == env53382) = true)

def env53383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,32,8388608,95497,8328,65,8560009,79130,8491471,8579233,8450328,119926,257,8484154,8492190,8509134]

theorem envBound53383 : H12AffineFastState.Bounded env53383 := by
  intro p hp
  have h : env53383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53382_53383 : H12AffineEnvironment.transform 21 32 env53382 = env53383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env53382 == env53383) = true)

theorem identity53383 : scanCanonicalize (H12AffineFastState.compose env53383 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound53383 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,32,120015,95497,8328,65,215366,79130,17664,212078,75223,119926,257,41461,16465,513]

theorem envBound53384 : H12AffineFastState.Bounded env53384 := by
  intro p hp
  have h : env53384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53383_53384 : H12AffineEnvironment.transform 22 120015 env53383 = env53384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env53383 == env53384) = true)

def env53385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,32,119879,95497,8192,65,215366,79130,17664,212078,75103,119926,257,41341,16465,513]

theorem envBound53385 : H12AffineFastState.Bounded env53385 := by
  intro p hp
  have h : env53385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53384_53385 : H12AffineEnvironment.transform 6 8 env53384 = env53385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53384 == env53385) = true)

theorem identity53385 : scanCanonicalize (H12AffineFastState.compose env53385 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound53385 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53386 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1025,8461,91419,32,95563,95497,8192,65,215366,79130,17664,212078,75103,95610,257,113,16465,513]

theorem envBound53386 : H12AffineFastState.Bounded env53386 := by
  intro p hp
  have h : env53386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53385_53386 : H12AffineEnvironment.transform 14 8460 env53385 = env53386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env53385 == env53386) = true)

theorem identity53386 : scanCanonicalize (H12AffineFastState.compose env53386 (packedSelected [0,3,7,12,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound53386 : packedSelected [0,3,7,12,20,24] rootPS < 2^1333 := by decide +kernel

def env53387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,21511,131072,10281,1025,8461,12572,32,8524,8462,8192,65,138561,24861,17664,157801,29016,8573,257,113,16465,513]

theorem envBound53387 : H12AffineFastState.Bounded env53387 := by
  intro p hp
  have h : env53387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53386_53387 : H12AffineEnvironment.transform 15 21511 env53386 = env53387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env53386 == env53387) = true)

theorem identity53387 : scanCanonicalize (H12AffineFastState.compose env53387 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound53387 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env53388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,21511,13341,10281,1025,8461,12572,32,8524,8462,8192,65,10588,24861,17664,23668,29016,8573,257,113,16465,513]

theorem envBound53388 : H12AffineFastState.Bounded env53388 := by
  intro p hp
  have h : env53388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53387_53388 : H12AffineEnvironment.transform 16 13341 env53387 = env53388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env53387 == env53388) = true)

theorem identity53388 : scanCanonicalize (H12AffineFastState.compose env53388 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53388 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,21511,5392,2340,1025,0,4113,32,65,3,269,65,2129,16400,17664,23668,20565,112,257,113,16465,513]

theorem envBound53389 : H12AffineFastState.Bounded env53389 := by
  intro p hp
  have h : env53389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53388_53389 : H12AffineEnvironment.transform 12 269 env53388 = env53389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53388 == env53389) = true)

theorem identity53389 : scanCanonicalize (H12AffineFastState.compose env53389 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound53389 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,1,342,5392,2340,1025,0,4113,32,65,3,269,65,2129,5441,4177,2341,1284,112,257,113,5376,513]

theorem envBound53390 : H12AffineFastState.Bounded env53390 := by
  intro p hp
  have h : env53390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53389_53390 : H12AffineEnvironment.transform 13 5457 env53389 = env53390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env53389 == env53390) = true)

theorem identity53390 : scanCanonicalize (H12AffineFastState.compose env53390 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53390 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53391 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,4161,1,342,4096,2340,273,0,4113,32,65,3,269,65,2129,4177,4177,2341,20,112,257,113,4112,513]

theorem envBound53391 : H12AffineFastState.Bounded env53391 := by
  intro p hp
  have h : env53391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53390_53391 : H12AffineEnvironment.transform 9 272 env53390 = env53391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53390 == env53391) = true)

theorem identity53391 : scanCanonicalize (H12AffineFastState.compose env53391 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53391 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53392 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,269,4112,1,263,4096,2340,273,0,4113,32,16,3,269,16,2048,4096,4096,2341,20,33,257,32,4112,513]

theorem envBound53392 : H12AffineFastState.Bounded env53392 := by
  intro p hp
  have h : env53392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53391_53392 : H12AffineEnvironment.transform 5 17 env53391 = env53392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53391 == env53392) = true)

theorem identity53392 : scanCanonicalize (H12AffineFastState.compose env53392 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound53392 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53393 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,308,269,292,1,263,308,2340,273,0,293,32,16,3,269,16,2048,308,308,2341,20,33,257,32,292,513]

theorem envBound53393 : H12AffineFastState.Bounded env53393 := by
  intro p hp
  have h : env53393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53392_53393 : H12AffineEnvironment.transform 11 308 env53392 = env53393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env53392 == env53393) = true)

def env53394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,119878,95497,8193,65,215366,79130,17664,212078,75102,119926,257,41340,16465,513]

theorem envBound53394 : H12AffineFastState.Bounded env53394 := by
  intro p hp
  have h : env53394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53384_53394 : H12AffineEnvironment.transform 6 9 env53384 = env53394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53384 == env53394) = true)

theorem identity53394 : scanCanonicalize (H12AffineFastState.compose env53394 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53394 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env53395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1025,8540,91467,32,95515,95497,8193,65,215366,79130,17664,212078,75102,95531,257,33,16465,513]

theorem envBound53395 : H12AffineFastState.Bounded env53395 := by
  intro p hp
  have h : env53395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53394_53395 : H12AffineEnvironment.transform 14 8541 env53394 = env53395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53394 == env53395) = true)

theorem identity53395 : scanCanonicalize (H12AffineFastState.compose env53395 (packedSelected [0,1,7,8,10,11,12,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 89111) := by decide +kernel

theorem selectedBound53395 : packedSelected [0,1,7,8,10,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env53396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,89111,10280,1025,8540,91467,32,95515,95497,8193,65,5457,79130,17664,24697,75102,95531,257,33,16465,513]

theorem envBound53396 : H12AffineFastState.Bounded env53396 := by
  intro p hp
  have h : env53396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53395_53396 : H12AffineEnvironment.transform 16 89111 env53395 = env53396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 89111 env53395 == env53396) = true)

theorem identity53396 : scanCanonicalize (H12AffineFastState.compose env53396 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound53396 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env53397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7504,65536,89111,5157,1025,7505,88390,32,84246,84228,7180,65,5457,67863,17664,23668,72019,84262,257,33,16465,513]

theorem envBound53397 : H12AffineFastState.Bounded env53397 := by
  intro p hp
  have h : env53397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53396_53397 : H12AffineEnvironment.transform 12 7181 env53396 = env53397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env53396 == env53397) = true)

theorem identity53397 : scanCanonicalize (H12AffineFastState.compose env53397 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound53397 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env53398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,16384,7504,1378,22901,5157,1025,7505,23588,32,19572,19558,7180,65,5457,3189,17664,23668,7217,19524,257,33,16465,513]

theorem envBound53398 : H12AffineFastState.Bounded env53398 := by
  intro p hp
  have h : env53398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53397_53398 : H12AffineEnvironment.transform 15 1378 env53397 = env53398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env53397 == env53398) = true)

theorem identity53398 : scanCanonicalize (H12AffineFastState.compose env53398 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound53398 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env53399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7181,2128,7504,1378,4389,5157,1025,7505,5236,32,1060,1078,7180,65,5457,3189,3408,5156,7217,1044,257,33,2049,513]

theorem envBound53399 : H12AffineFastState.Bounded env53399 := by
  intro p hp
  have h : env53399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53398_53399 : H12AffineEnvironment.transform 13 2128 env53398 = env53399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env53398 == env53399) = true)

theorem identity53399 : scanCanonicalize (H12AffineFastState.compose env53399 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53399 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env53400 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,6429,2128,6208,114,4389,4405,273,6209,4452,32,308,294,6428,65,4161,2405,2112,4404,6433,260,257,33,2049,513]

theorem envBound53400 : H12AffineFastState.Bounded env53400 := by
  intro p hp
  have h : env53400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53399_53400 : H12AffineEnvironment.transform 9 272 env53399 = env53400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53399 == env53400) = true)

theorem identity53400 : scanCanonicalize (H12AffineFastState.compose env53400 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound53400 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env53401 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2405,120,2128,293,114,2112,2128,273,292,2049,32,308,294,121,65,2340,2405,2112,2129,68,260,257,33,2049,513]

theorem envBound53401 : H12AffineFastState.Bounded env53401 := by
  intro p hp
  have h : env53401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53400_53401 : H12AffineEnvironment.transform 11 2405 env53400 = env53401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env53400 == env53401) = true)

theorem identity53401 : scanCanonicalize (H12AffineFastState.compose env53401 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53401 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53402 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2112,120,2128,0,114,2112,2128,52,1,2049,32,17,3,121,65,2049,2112,2112,2129,68,33,36,33,2049,513]

theorem envBound53402 : H12AffineFastState.Bounded env53402 := by
  intro p hp
  have h : env53402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53401_53402 : H12AffineEnvironment.transform 7 37 env53401 = env53402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53401 == env53402) = true)

theorem identity53402 : scanCanonicalize (H12AffineFastState.compose env53402 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53402 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53403 : List Nat := [2,4,8,0,32,64,9,37,512,37,2048,2112,104,2112,0,98,2112,2112,36,1,2049,32,1,3,105,65,2049,2112,2112,2113,68,33,36,33,2049,513]

theorem envBound53403 : H12AffineFastState.Bounded env53403 := by
  intro p hp
  have h : env53403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53402_53403 : H12AffineEnvironment.transform 3 0 env53402 = env53403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53402 == env53403) = true)

theorem identity53403 : scanCanonicalize (H12AffineFastState.compose env53403 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound53403 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53404 : List Nat := [2,4,8,0,32,64,9,37,64,37,2048,2112,104,2112,0,98,2112,2112,36,1,2049,32,1,3,105,65,2049,2112,2112,2113,68,33,36,33,2049,65]

theorem envBound53404 : H12AffineFastState.Bounded env53404 := by
  intro p hp
  have h : env53404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53403_53404 : H12AffineEnvironment.transform 8 64 env53403 = env53404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env53403 == env53404) = true)

theorem identity53404 : scanCanonicalize (H12AffineFastState.compose env53404 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound53404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53405 : List Nat := [2,4,8,0,32,64,9,37,64,37,96,32,104,32,0,98,32,32,36,1,97,32,1,3,105,65,97,32,32,33,68,33,36,33,97,65]

theorem envBound53405 : H12AffineFastState.Bounded env53405 := by
  intro p hp
  have h : env53405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53404_53405 : H12AffineEnvironment.transform 10 96 env53404 = env53405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env53404 == env53405) = true)

theorem identity53405 : scanCanonicalize (H12AffineFastState.compose env53405 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound53405 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env53406 : List Nat := [2,4,8,0,32,33,9,37,33,37,1,32,9,32,0,3,32,32,36,1,0,32,1,3,8,32,0,32,32,33,37,33,36,33,0,32]

theorem envBound53406 : H12AffineFastState.Bounded env53406 := by
  intro p hp
  have h : env53406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53405_53406 : H12AffineEnvironment.transform 5 33 env53405 = env53406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env53405 == env53406) = true)

theorem identity53406 : scanCanonicalize (H12AffineFastState.compose env53406 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53406 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53407 : List Nat := [2,4,8,0,1,0,9,4,0,4,1,1,9,1,0,3,1,1,5,1,0,1,1,3,8,1,0,1,1,0,4,0,5,0,0,1]

theorem envBound53407 : H12AffineFastState.Bounded env53407 := by
  intro p hp
  have h : env53407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53406_53407 : H12AffineEnvironment.transform 4 1 env53406 = env53407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53406 == env53407) = true)

def env53408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,33,8388608,95497,8328,65,8560008,79130,8491471,8579233,8450328,119927,257,8484154,8492190,8509134]

theorem envBound53408 : H12AffineFastState.Bounded env53408 := by
  intro p hp
  have h : env53408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53382_53408 : H12AffineEnvironment.transform 21 33 env53382 = env53408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env53382 == env53408) = true)

theorem identity53408 : scanCanonicalize (H12AffineFastState.compose env53408 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound53408 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env53409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10401,1025,32769,4161,33,8388608,41431,8328,65,8560008,57796,8406289,8579233,8450328,169,257,8430052,8405056,8389136]

theorem envBound53409 : H12AffineFastState.Bounded env53409 := by
  intro p hp
  have h : env53409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53408_53409 : H12AffineEnvironment.transform 15 54494 env53408 = env53409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env53408 == env53409) = true)

def env53410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,33,8388608,41311,8192,65,8559872,57676,8406289,8579113,8450328,33,257,8429932,8405056,8389136]

theorem envBound53410 : H12AffineFastState.Bounded env53410 := by
  intro p hp
  have h : env53410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53409_53410 : H12AffineEnvironment.transform 6 8 env53409 = env53410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53409 == env53410) = true)

theorem identity53410 : scanCanonicalize (H12AffineFastState.compose env53410 (packedSelected [0,1,2,5,6,8,10,11,12,14,15,18,24,27,31] rootPS)) = affineNative (2^(22+1) ^^^ 147456) := by decide +kernel

theorem selectedBound53410 : packedSelected [0,1,2,5,6,8,10,11,12,14,15,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env53411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,33,147456,41311,8192,65,56576,57676,132369,43049,176408,33,257,188780,131136,147984]

theorem envBound53411 : H12AffineFastState.Bounded env53411 := by
  intro p hp
  have h : env53411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53410_53411 : H12AffineEnvironment.transform 22 147456 env53410 = env53411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env53410 == env53411) = true)

theorem identity53411 : scanCanonicalize (H12AffineFastState.compose env53411 (packedSelected [0,2,3,5,6,8,11,12,14,15,18,19,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound53411 : packedSelected [0,2,3,5,6,8,11,12,14,15,18,19,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1025,32769,4161,33,17,41311,8192,65,56576,57676,17664,43049,61705,33,257,41341,16465,513]

theorem envBound53412 : H12AffineFastState.Bounded env53412 := by
  intro p hp
  have h : env53412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53411_53412 : H12AffineEnvironment.transform 16 16401 env53411 = env53412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env53411 == env53412) = true)

theorem identity53412 : scanCanonicalize (H12AffineFastState.compose env53412 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound53412 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env53413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,10281,1025,32769,4161,33,17,41311,8192,65,34816,46156,4096,43049,41993,33,257,41341,5457,513]

theorem envBound53413 : H12AffineFastState.Bounded env53413 := by
  intro p hp
  have h : env53413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53412_53413 : H12AffineEnvironment.transform 13 5376 env53412 = env53413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env53412 == env53413) = true)

theorem identity53413 : scanCanonicalize (H12AffineFastState.compose env53413 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53413 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env53414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10281,1025,8540,4161,33,17,2,8192,65,10589,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound53414 : H12AffineFastState.Bounded env53414 := by
  intro p hp
  have h : env53414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53413_53414 : H12AffineEnvironment.transform 14 8541 env53413 = env53414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53413 == env53414) = true)

theorem identity53414 : scanCanonicalize (H12AffineFastState.compose env53414 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53414 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env53415 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10281,1025,8461,4112,33,17,2,8192,16,10508,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound53415 : H12AffineFastState.Bounded env53415 := by
  intro p hp
  have h : env53415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53414_53415 : H12AffineEnvironment.transform 5 17 env53414 = env53415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53414 == env53415) = true)

theorem identity53415 : scanCanonicalize (H12AffineFastState.compose env53415 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound53415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53416 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,8233,8203,5172,10281,1025,8232,4112,33,17,2,8192,16,10281,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound53416 : H12AffineFastState.Bounded env53416 := by
  intro p hp
  have h : env53416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53415_53416 : H12AffineEnvironment.transform 7 37 env53415 = env53416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env53415 == env53416) = true)

theorem identity53416 : scanCanonicalize (H12AffineFastState.compose env53416 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound53416 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env53417 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5172,2048,1025,1,4112,33,17,2,41,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound53417 : H12AffineFastState.Bounded env53417 := by
  intro p hp
  have h : env53417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53416_53417 : H12AffineEnvironment.transform 12 41 env53416 = env53417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env53416 == env53417) = true)

def env53418 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,0,34,1028,2048,1025,1,32,33,17,2,41,16,2048,1028,48,2048,1056,33,36,32,1045,513]

theorem envBound53418 : H12AffineFastState.Bounded env53418 := by
  intro p hp
  have h : env53418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53417_53418 : H12AffineEnvironment.transform 11 48 env53417 = env53418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53417 == env53418) = true)

theorem identity53418 : scanCanonicalize (H12AffineFastState.compose env53418 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound53418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53419 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1044,48,41,1045,0,34,1028,1044,1025,1,32,33,17,2,41,16,1044,1028,48,1044,1056,33,36,32,1045,513]

theorem envBound53419 : H12AffineFastState.Bounded env53419 := by
  intro p hp
  have h : env53419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53418_53419 : H12AffineEnvironment.transform 10 1044 env53418 = env53419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env53418 == env53419) = true)

def env53420 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,33,0,34,48,32,53,1,32,33,17,2,41,16,32,48,48,32,20,33,36,32,33,513]

theorem envBound53420 : H12AffineFastState.Bounded env53420 := by
  intro p hp
  have h : env53420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53419_53420 : H12AffineEnvironment.transform 9 52 env53419 = env53420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53419 == env53420) = true)

theorem identity53420 : scanCanonicalize (H12AffineFastState.compose env53420 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53421 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,8,0,0,3,17,1,20,1,1,0,17,2,8,16,1,17,17,1,20,0,5,1,0,513]

theorem envBound53421 : H12AffineFastState.Bounded env53421 := by
  intro p hp
  have h : env53421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53420_53421 : H12AffineEnvironment.transform 4 1 env53420 = env53421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53420 == env53421) = true)

def leafEnv53421 : List Nat := [2,4,8,16,1,17,8,4,512,21,1,17,8,0,0,3,17,1,20,1,1,0,17,2,21,8,1,16,1,17,17,1,20,0,5,1,5,3,0,513,1,1,0]

def active53421 : List Nat := [0,1,2,3,8]

def tree53421 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53421 : H12WitnessSearch.Good tree53421 := H12GlobalWitnessIndex.good

theorem leafIdentity53421 : H12AffineFastState.composeSystem env53421 rootObs = leafEnv53421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53421 rootObs == leafEnv53421) = true)

theorem terminalChecked53421 : H12PackedTerminal.terminalCheckFast leafEnv53421 active53421 tree53421 = true := by decide +kernel

def env53422 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,48,41,32,0,34,49,33,52,1,32,33,17,2,41,16,33,49,48,33,21,33,36,32,32,513]

theorem envBound53422 : H12AffineFastState.Bounded env53422 := by
  intro p hp
  have h : env53422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53419_53422 : H12AffineEnvironment.transform 9 53 env53419 = env53422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env53419 == env53422) = true)

theorem identity53422 : scanCanonicalize (H12AffineFastState.compose env53422 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound53422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53423 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,41,32,0,34,49,33,52,1,32,33,17,2,41,16,33,49,48,33,21,33,36,32,32,11]

theorem envBound53423 : H12AffineFastState.Bounded env53423 := by
  intro p hp
  have h : env53423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53422_53423 : H12AffineEnvironment.transform 8 10 env53422 = env53423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env53422 == env53423) = true)

def leafEnv53423 : List Nat := [2,4,8,16,32,17,8,37,10,53,33,48,41,32,0,34,49,33,52,1,32,33,17,2,20,41,1,16,33,49,48,33,21,33,36,32,5,34,32,11,1,32,0]

def active53423 : List Nat := [0,1,2,3,4]

def tree53423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood53423 : H12WitnessSearch.Good tree53423 := H12GlobalWitnessIndex.good

theorem leafIdentity53423 : H12AffineFastState.composeSystem env53423 rootObs = leafEnv53423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env53423 rootObs == leafEnv53423) = true)

theorem terminalChecked53423 : H12PackedTerminal.terminalCheckFast leafEnv53423 active53423 tree53423 = true := by decide +kernel

def env53424 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,0,34,1029,2048,1025,1,33,33,17,2,41,16,2048,1029,49,2048,1056,33,36,32,1044,513]

theorem envBound53424 : H12AffineFastState.Bounded env53424 := by
  intro p hp
  have h : env53424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53417_53424 : H12AffineEnvironment.transform 11 49 env53417 = env53424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env53417 == env53424) = true)

theorem identity53424 : scanCanonicalize (H12AffineFastState.compose env53424 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound53424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53425 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,49,41,1044,0,34,1029,32,1025,1,33,33,17,2,41,16,32,1029,49,32,1056,33,36,32,1044,513]

theorem envBound53425 : H12AffineFastState.Bounded env53425 := by
  intro p hp
  have h : env53425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53424_53425 : H12AffineEnvironment.transform 10 32 env53424 = env53425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env53424 == env53425) = true)

def env53426 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,49,41,32,0,34,49,32,53,1,33,33,17,2,41,16,32,49,49,32,20,33,36,32,32,513]

theorem envBound53426 : H12AffineFastState.Bounded env53426 := by
  intro p hp
  have h : env53426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53425_53426 : H12AffineEnvironment.transform 9 52 env53425 = env53426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env53425 == env53426) = true)

theorem identity53426 : scanCanonicalize (H12AffineFastState.compose env53426 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

end H12CloudChart1