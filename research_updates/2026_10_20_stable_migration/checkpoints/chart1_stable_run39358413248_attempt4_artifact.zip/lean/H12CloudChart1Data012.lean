import H12CloudChart1Data011

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans2937_2938 : H12AffineEnvironment.transform 16 28587 env2937 = env2938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 28587 env2937 == env2938) = true)

theorem identity2938 : scanCanonicalize (H12AffineFastState.compose env2938 (packedSelected [0,1,4,5,6,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 16242) := by decide +kernel

theorem selectedBound2938 : packedSelected [0,1,4,5,6,11,15] rootPS < 2^1333 := by decide +kernel

def env2939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16242,11853,12178,4313,12750,6531,11853,12523,33,4738,139,8329,4818,12474,15008,14969,2420,1365,341,7299,341,1993,513]

theorem envBound2939 : H12AffineFastState.Bounded env2939 := by
  intro p hp
  have h : env2939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2938_2939 : H12AffineEnvironment.transform 13 16242 env2938 = env2939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 16242 env2938 == env2939) = true)

theorem identity2939 : scanCanonicalize (H12AffineFastState.compose env2939 (packedSelected [1,5,6,10] rootPS)) = affineNative (2^(11+1) ^^^ 3971) := by decide +kernel

theorem selectedBound2939 : packedSelected [1,5,6,10] rootPS < 2^1333 := by decide +kernel

def env2940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3971,8192,8433,11853,12178,3930,11853,1536,11853,12136,33,3329,139,8329,3409,12089,9507,9722,2420,1365,341,768,341,1993,513]

theorem envBound2940 : H12AffineFastState.Bounded env2940 := by
  intro p hp
  have h : env2940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2939_2940 : H12AffineEnvironment.transform 11 3971 env2939 = env2940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3971 env2939 == env2940) = true)

theorem identity2940 : scanCanonicalize (H12AffineFastState.compose env2940 (packedSelected [1,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1945) := by decide +kernel

theorem selectedBound2940 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env2941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1945,26,8192,8433,8660,8203,195,8660,1536,8660,8433,33,664,139,8329,712,8352,9507,9722,1773,1365,341,768,341,1993,513]

theorem envBound2941 : H12AffineFastState.Bounded env2941 := by
  intro p hp
  have h : env2941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2940_2941 : H12AffineEnvironment.transform 10 1945 env2940 = env2941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1945 env2940 == env2941) = true)

theorem identity2941 : scanCanonicalize (H12AffineFastState.compose env2941 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1897) := by decide +kernel

theorem selectedBound2941 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env2942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1945,26,1897,1944,1725,1890,195,1725,1536,1725,1944,33,664,139,2016,712,1993,586,659,1773,1365,341,768,341,1993,513]

theorem envBound2942 : H12AffineFastState.Bounded env2942 := by
  intro p hp
  have h : env2942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2941_2942 : H12AffineEnvironment.transform 12 1897 env2941 = env2942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1897 env2941 == env2942) = true)

theorem identity2942 : scanCanonicalize (H12AffineFastState.compose env2942 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound2942 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env2943 : List Nat := [2,4,8,16,32,64,128,256,512,62,935,26,855,934,643,860,195,643,574,643,934,33,664,139,990,712,1015,586,659,723,363,341,768,341,1015,513]

theorem envBound2943 : H12AffineFastState.Bounded env2943 := by
  intro p hp
  have h : env2943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2942_2943 : H12AffineEnvironment.transform 9 62 env2942 = env2943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env2942 == env2943) = true)

theorem identity2943 : scanCanonicalize (H12AffineFastState.compose env2943 (packedSelected [1,3,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound2943 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env2944 : List Nat := [2,4,8,16,32,17,128,256,512,62,935,26,774,934,643,781,146,643,574,643,934,33,664,139,911,665,934,539,659,642,314,260,768,260,934,513]

theorem envBound2944 : H12AffineFastState.Bounded env2944 := by
  intro p hp
  have h : env2944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2943_2944 : H12AffineEnvironment.transform 5 17 env2943 = env2944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2943 == env2944) = true)

theorem identity2944 : scanCanonicalize (H12AffineFastState.compose env2944 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound2944 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env2945 : List Nat := [2,4,8,16,32,17,128,256,130,62,293,26,388,292,1,399,146,1,188,1,292,33,26,139,269,27,292,153,17,0,314,260,386,260,292,131]

theorem envBound2945 : H12AffineFastState.Bounded env2945 := by
  intro p hp
  have h : env2945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2944_2945 : H12AffineEnvironment.transform 8 130 env2944 = env2945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env2944 == env2945) = true)

theorem identity2945 : scanCanonicalize (H12AffineFastState.compose env2945 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound2945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env2946 : List Nat := [2,4,8,16,32,17,128,172,130,62,137,26,40,136,1,35,146,1,188,1,136,33,26,139,161,27,136,153,17,0,150,168,46,168,136,131]

theorem envBound2946 : H12AffineFastState.Bounded env2946 := by
  intro p hp
  have h : env2946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2945_2946 : H12AffineEnvironment.transform 7 172 env2945 = env2946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env2945 == env2946) = true)

theorem identity2946 : scanCanonicalize (H12AffineFastState.compose env2946 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound2946 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env2947 : List Nat := [2,4,8,10,32,11,128,172,130,36,137,0,40,136,1,35,136,1,166,1,136,33,0,139,161,1,136,131,11,0,140,168,46,168,136,131]

theorem envBound2947 : H12AffineFastState.Bounded env2947 := by
  intro p hp
  have h : env2947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2946_2947 : H12AffineEnvironment.transform 3 10 env2946 = env2947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env2946 == env2947) = true)

theorem identity2947 : scanCanonicalize (H12AffineFastState.compose env2947 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound2947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2948 : List Nat := [2,4,8,10,32,11,8,36,10,36,1,0,40,0,1,35,0,1,46,1,0,33,0,3,41,1,0,11,11,0,4,32,46,32,0,11]

theorem envBound2948 : H12AffineFastState.Bounded env2948 := by
  intro p hp
  have h : env2948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2947_2948 : H12AffineEnvironment.transform 6 8 env2947 = env2948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env2947 == env2948) = true)

theorem identity2948 : scanCanonicalize (H12AffineFastState.compose env2948 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound2948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env2949 : List Nat := [2,4,8,10,10,11,8,14,10,14,1,0,2,0,1,9,0,1,4,1,0,11,0,3,3,1,0,11,11,0,4,10,4,10,0,11]

theorem envBound2949 : H12AffineFastState.Bounded env2949 := by
  intro p hp
  have h : env2949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2948_2949 : H12AffineEnvironment.transform 4 10 env2948 = env2949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env2948 == env2949) = true)

theorem identity2949 : scanCanonicalize (H12AffineFastState.compose env2949 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound2949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env2950 : List Nat := [2,1,8,10,10,11,8,11,10,11,1,0,2,0,1,9,0,1,1,1,0,11,0,3,3,1,0,11,11,0,1,10,1,10,0,11]

theorem envBound2950 : H12AffineFastState.Bounded env2950 := by
  intro p hp
  have h : env2950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2949_2950 : H12AffineEnvironment.transform 1 1 env2949 = env2950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env2949 == env2950) = true)

def env2951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,268570625,151259274,92374096,164406727,525568,151257259,34359738368,25733062]

theorem envBound2951 : H12AffineFastState.Bounded env2951 := by
  intro p hp
  have h : env2951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2924_2951 : H12AffineEnvironment.transform 28 268570625 env2924 = env2951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env2924 == env2951) = true)

theorem identity2951 : scanCanonicalize (H12AffineFastState.compose env2951 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(23+1) ^^^ 176598) := by decide +kernel

theorem selectedBound2951 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env2952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,176598,8329,67108864,134217728,268435456,268570625,134658396,75707782,147723281,525568,134656381,34359738368,9049616]

theorem envBound2952 : H12AffineFastState.Bounded env2952 := by
  intro p hp
  have h : env2952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2951_2952 : H12AffineEnvironment.transform 23 176598 env2951 = env2952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 176598 env2951 == env2952) = true)

def env2953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,268435456,268435965,134523040,75572346,147588589,525568,134520961,34359738368,8914924]

theorem envBound2953 : H12AffineFastState.Bounded env2953 := by
  intro p hp
  have h : env2953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2952_2953 : H12AffineEnvironment.transform 16 4604 env2952 = env2953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4604 env2952 == env2953) = true)

theorem identity2953 : scanCanonicalize (H12AffineFastState.compose env2953 (packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS)) = affineNative (2^(34+1) ^^^ 203784470) := by decide +kernel

theorem selectedBound2953 : packedSelected [1,3,5,8,10,12,13,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env2954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,67108864,134217728,268435456,268435965,134523040,75572346,147588589,525568,134520961,203784470,8914924]

theorem envBound2954 : H12AffineFastState.Bounded env2954 := by
  intro p hp
  have h : env2954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2953_2954 : H12AffineEnvironment.transform 34 203784470 env2953 = env2954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 203784470 env2953 == env2954) = true)

def env2955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015248,134217728,268435456,268435965,134523040,2699306,147588589,525568,134520961,143496518,8914924]

theorem envBound2955 : H12AffineFastState.Bounded env2955 := by
  intro p hp
  have h : env2955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2954_2955 : H12AffineEnvironment.transform 25 11015248 env2954 = env2955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 11015248 env2954 == env2955) = true)

def env2956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015248,849104,268435456,268435965,547952,2699306,12644669,525568,545873,8479126,8914924]

theorem envBound2956 : H12AffineFastState.Bounded env2956 := by
  intro p hp
  have h : env2956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2955_2956 : H12AffineEnvironment.transform 26 849104 env2955 = env2956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849104 env2955 == env2956) = true)

def env2957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849104,268435456,268435965,547952,598058,12644669,525568,545873,8479126,8914924]

theorem envBound2957 : H12AffineFastState.Bounded env2957 := by
  intro p hp
  have h : env2957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2956_2957 : H12AffineEnvironment.transform 20 4096 env2956 = env2957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env2956 == env2957) = true)

def env2958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849104,16384,16893,547952,598058,12644669,525568,545873,8479126,8914924]

theorem envBound2958 : H12AffineFastState.Bounded env2958 := by
  intro p hp
  have h : env2958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2957_2958 : H12AffineEnvironment.transform 27 16384 env2957 = env2958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env2957 == env2958) = true)

def env2959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16893,22640,74794,12644669,256,20561,8479126,8389612]

theorem envBound2959 : H12AffineFastState.Bounded env2959 := by
  intro p hp
  have h : env2959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2958_2959 : H12AffineEnvironment.transform 18 1024 env2958 = env2959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env2958 == env2959) = true)

theorem identity2959 : scanCanonicalize (H12AffineFastState.compose env2959 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound2959 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env2960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1212,8192,16384,32768,65536,1344,262144,1024,32768,1212,4194304,8388608,41002,8329,8388688,320620,16384,16893,19660,74794,12641665,256,17645,8479126,8389612]

theorem envBound2960 : H12AffineFastState.Bounded env2960 := by
  intro p hp
  have h : env2960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2959_2960 : H12AffineEnvironment.transform 11 1212 env2959 = env2960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env2959 == env2960) = true)

def env2961 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,8388608,41002,8329,8388608,320572,16384,16813,19612,74794,12641665,256,17597,8479126,8389564]

theorem envBound2961 : H12AffineFastState.Bounded env2961 := by
  intro p hp
  have h : env2961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2960_2961 : H12AffineEnvironment.transform 5 16 env2960 = env2961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env2960 == env2961) = true)

theorem identity2961 : scanCanonicalize (H12AffineFastState.compose env2961 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound2961 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env2962 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,4194304,444,41002,8329,444,320572,16384,16813,19612,74794,4252733,256,17597,90154,512]

theorem envBound2962 : H12AffineFastState.Bounded env2962 := by
  intro p hp
  have h : env2962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2961_2962 : H12AffineEnvironment.transform 22 444 env2961 = env2962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env2961 == env2962) = true)

theorem identity2962 : scanCanonicalize (H12AffineFastState.compose env2962 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound2962 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2963 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,65536,1296,262144,1024,32768,1212,41349,444,41002,8329,444,320572,16384,16813,19612,74794,17848,256,17597,90154,512]

theorem envBound2963 : H12AffineFastState.Bounded env2963 := by
  intro p hp
  have h : env2963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2962_2963 : H12AffineEnvironment.transform 21 41349 env2962 = env2963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env2962 == env2963) = true)

theorem identity2963 : scanCanonicalize (H12AffineFastState.compose env2963 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound2963 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env2964 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,32768,33543,1296,262144,1024,32768,1212,41349,444,41002,8329,444,320572,16384,16813,19612,42797,17848,256,17597,58157,512]

theorem envBound2964 : H12AffineFastState.Bounded env2964 := by
  intro p hp
  have h : env2964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2963_2964 : H12AffineEnvironment.transform 15 33543 env2963 = env2964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env2963 == env2964) = true)

theorem identity2964 : scanCanonicalize (H12AffineFastState.compose env2964 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26425) := by decide +kernel

theorem selectedBound2964 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env2965 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,262144,1024,26425,1212,18108,444,18195,8329,444,262917,16384,16813,19612,16404,17848,256,17597,1044,512]

theorem envBound2965 : H12AffineFastState.Bounded env2965 := by
  intro p hp
  have h : env2965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2964_2965 : H12AffineEnvironment.transform 14 26425 env2964 = env2965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26425 env2964 == env2965) = true)

theorem identity2965 : scanCanonicalize (H12AffineFastState.compose env2965 (packedSelected [0,8,10,12,15,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound2965 : packedSelected [0,8,10,12,15,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env2966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1212,8192,16384,26425,25662,1296,20156,1024,26425,1212,18108,444,18195,8329,444,19897,16384,16813,19612,16404,17848,256,17597,1044,512]

theorem envBound2966 : H12AffineFastState.Bounded env2966 := by
  intro p hp
  have h : env2966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2965_2966 : H12AffineEnvironment.transform 17 20156 env2965 = env2966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env2965 == env2966) = true)

def env2967 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1212,8192,16384,32768,65536,1297,262144,1024,32768,1212,4194304,8388608,41002,8329,8388609,320573,16384,16812,19613,74794,12641665,256,17596,8479126,8389565]

theorem envBound2967 : H12AffineFastState.Bounded env2967 := by
  intro p hp
  have h : env2967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2960_2967 : H12AffineEnvironment.transform 5 17 env2960 = env2967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env2960 == env2967) = true)

def env2968 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1212,8192,16384,32768,65536,1197,262144,1024,32768,1212,4194304,8388608,41002,8329,8388609,320573,16384,16400,19613,74794,12641341,188,17596,8478762,8389121]

theorem envBound2968 : H12AffineFastState.Bounded env2968 := by
  intro p hp
  have h : env2968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2967_2968 : H12AffineEnvironment.transform 7 188 env2967 = env2968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env2967 == env2968) = true)

theorem identity2968 : scanCanonicalize (H12AffineFastState.compose env2968 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound2968 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2969 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1212,8192,16384,32768,65536,1197,262144,1024,32768,1212,4194304,4194353,41002,8329,4194352,320573,16384,16400,19613,74794,58380,188,17596,4284443,4194864]

theorem envBound2969 : H12AffineFastState.Bounded env2969 := by
  intro p hp
  have h : env2969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2968_2969 : H12AffineEnvironment.transform 22 4194353 env2968 = env2969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env2968 == env2969) = true)

def env2970 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,65536,1197,262144,1024,32768,1196,4194304,4194337,41002,8329,4194336,320557,16384,16384,19597,74794,58380,172,17580,4284427,4194848]

theorem envBound2970 : H12AffineFastState.Bounded env2970 := by
  intro p hp
  have h : env2970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2969_2970 : H12AffineEnvironment.transform 3 0 env2969 = env2970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env2969 == env2970) = true)

theorem identity2970 : scanCanonicalize (H12AffineFastState.compose env2970 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 50318) := by decide +kernel

theorem selectedBound2970 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env2971 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50318,1197,262144,1024,32768,1196,4194304,4194337,41002,8329,4194336,320557,16384,16384,19597,57508,58380,172,17580,4236421,4194848]

theorem envBound2971 : H12AffineFastState.Bounded env2971 := by
  intro p hp
  have h : env2971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2970_2971 : H12AffineEnvironment.transform 15 50318 env2970 = env2971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50318 env2970 == env2971) = true)

theorem identity2971 : scanCanonicalize (H12AffineFastState.compose env2971 (packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound2971 : packedSelected [0,5,7,9,17,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env2972 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50318,1197,19493,1024,32768,1196,4194304,4194337,41002,8329,4194336,43016,16384,16384,19597,57508,58380,172,17580,4236421,4194848]

theorem envBound2972 : H12AffineFastState.Bounded env2972 := by
  intro p hp
  have h : env2972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2971_2972 : H12AffineEnvironment.transform 17 19493 env2971 = env2972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env2971 == env2972) = true)

theorem identity2972 : scanCanonicalize (H12AffineFastState.compose env2972 (packedSelected [0,4,7,13,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound2972 : packedSelected [0,4,7,13,21,22] rootPS < 2^1333 := by decide +kernel

def env2973 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,16384,32768,50318,1197,19493,1024,32768,1196,41001,40968,41002,8329,40969,43016,16384,16384,19597,57508,58380,172,17580,1196,41481]

theorem envBound2973 : H12AffineFastState.Bounded env2973 := by
  intro p hp
  have h : env2973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2972_2973 : H12AffineEnvironment.transform 21 41001 env2972 = env2973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env2972 == env2973) = true)

theorem identity2973 : scanCanonicalize (H12AffineFastState.compose env2973 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound2973 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env2974 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,1676,32768,33282,1197,2729,1024,32768,1196,41001,40968,41002,8329,40969,43016,1676,1676,2561,42536,41600,172,544,1196,41481]

theorem envBound2974 : H12AffineFastState.Bounded env2974 := by
  intro p hp
  have h : env2974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2973_2974 : H12AffineEnvironment.transform 13 1676 env2973 = env2974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env2973 == env2974) = true)

theorem identity2974 : scanCanonicalize (H12AffineFastState.compose env2974 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound2974 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env2975 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,1029,8192,1573,32768,33282,1028,2560,1024,32768,1029,41001,40968,41002,8224,40969,43016,1573,1573,2561,42536,41513,5,544,1029,41481]

theorem envBound2975 : H12AffineFastState.Bounded env2975 := by
  intro p hp
  have h : env2975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2974_2975 : H12AffineEnvironment.transform 6 41 env2974 = env2975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env2974 == env2975) = true)

theorem identity2975 : scanCanonicalize (H12AffineFastState.compose env2975 (packedSelected [5,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 11815) := by decide +kernel

theorem selectedBound2975 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env2976 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,1029,8192,1573,11815,11301,1028,2560,1024,11815,1029,3598,3631,3597,8224,3630,1583,1573,1573,2561,2063,3086,5,544,1029,3118]

theorem envBound2976 : H12AffineFastState.Bounded env2976 := by
  intro p hp
  have h : env2976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2975_2976 : H12AffineEnvironment.transform 14 11815 env2975 = env2976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11815 env2975 == env2976) = true)

theorem identity2976 : scanCanonicalize (H12AffineFastState.compose env2976 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound2976 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env2977 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1071,1029,8192,1573,8712,8202,1028,1583,1024,8712,1029,545,512,546,8224,513,1583,1573,1573,1582,1056,33,5,544,1029,1]

theorem envBound2977 : H12AffineFastState.Bounded env2977 := by
  intro p hp
  have h : env2977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2976_2977 : H12AffineEnvironment.transform 10 1071 env2976 = env2977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env2976 == env2977) = true)

theorem identity2977 : scanCanonicalize (H12AffineFastState.compose env2977 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound2977 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env2978 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1071,1029,41,1573,545,35,1028,1583,1024,545,1029,545,512,546,9,513,1583,1573,1573,1582,1056,33,5,544,1029,1]

theorem envBound2978 : H12AffineFastState.Bounded env2978 := by
  intro p hp
  have h : env2978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2977_2978 : H12AffineEnvironment.transform 12 41 env2977 = env2978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env2977 == env2978) = true)

theorem identity2978 : scanCanonicalize (H12AffineFastState.compose env2978 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound2978 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env2979 : List Nat := [2,4,3,0,32,1,34,5,512,1024,1060,1029,34,1573,545,35,1028,1572,1024,545,1029,545,512,546,2,513,1572,1573,1573,1573,1056,33,5,544,1029,1]

theorem envBound2979 : H12AffineFastState.Bounded env2979 := by
  intro p hp
  have h : env2979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2978_2979 : H12AffineEnvironment.transform 2 3 env2978 = env2979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env2978 == env2979) = true)

def env2980 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,32768,65536,1197,262144,1024,32768,1197,4194304,4194336,41002,8329,4194337,320556,16384,16385,19596,74794,58380,173,17581,4284426,4194849]

theorem envBound2980 : H12AffineFastState.Bounded env2980 := by
  intro p hp
  have h : env2980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2969_2980 : H12AffineEnvironment.transform 3 1 env2969 = env2980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2969 == env2980) = true)

theorem identity2980 : scanCanonicalize (H12AffineFastState.compose env2980 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound2980 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env2981 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,65536,1197,262144,1024,8200,1197,4194304,4194336,34,8329,4194337,279588,16384,16385,19596,74794,17412,173,17581,4284426,4194849]

theorem envBound2981 : H12AffineFastState.Bounded env2981 := by
  intro p hp
  have h : env2981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2980_2981 : H12AffineEnvironment.transform 14 8200 env2980 = env2981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env2980 == env2981) = true)

theorem identity2981 : scanCanonicalize (H12AffineFastState.compose env2981 (packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 281772) := by decide +kernel

theorem selectedBound2981 : packedSelected [0,1,3,7,8,9,10,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env2982 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,65536,1197,262144,1024,8200,1197,281772,281740,34,8329,281741,279588,16384,16385,19596,74794,17412,173,17581,339110,282253]

theorem envBound2982 : H12AffineFastState.Bounded env2982 := by
  intro p hp
  have h : env2982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2981_2982 : H12AffineEnvironment.transform 21 281772 env2981 = env2982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281772 env2981 == env2982) = true)

theorem identity2982 : scanCanonicalize (H12AffineFastState.compose env2982 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound2982 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env2983 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,16384,8200,25734,1197,262144,1024,8200,1197,281772,281740,34,8329,281741,279588,16384,16385,19596,16556,17412,173,17581,280608,282253]

theorem envBound2983 : H12AffineFastState.Bounded env2983 := by
  intro p hp
  have h : env2983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2982_2983 : H12AffineEnvironment.transform 15 25734 env2982 = env2983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env2982 == env2983) = true)

theorem identity2983 : scanCanonicalize (H12AffineFastState.compose env2983 (packedSelected [1,3,4,5,6,8,9,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2211) := by decide +kernel

theorem selectedBound2983 : packedSelected [1,3,4,5,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env2984 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,2211,8200,11301,1197,262144,1024,8200,1197,263183,263215,34,8329,263214,265351,2211,2210,1071,2063,3239,173,3086,262275,263726]

theorem envBound2984 : H12AffineFastState.Bounded env2984 := by
  intro p hp
  have h : env2984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2983_2984 : H12AffineEnvironment.transform 13 2211 env2983 = env2984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2211 env2983 == env2984) = true)

theorem identity2984 : scanCanonicalize (H12AffineFastState.compose env2984 (packedSelected [2,10,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 11271) := by decide +kernel

theorem selectedBound2984 : packedSelected [2,10,15,17] rootPS < 2^1333 := by decide +kernel

def env2985 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1197,8192,2211,8200,11301,1197,11271,1024,8200,1197,10248,10280,34,8329,10281,8320,2211,2210,1071,2063,3239,173,3086,11396,10793]

theorem envBound2985 : H12AffineFastState.Bounded env2985 := by
  intro p hp
  have h : env2985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2984_2985 : H12AffineEnvironment.transform 17 11271 env2984 = env2985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11271 env2984 == env2985) = true)

theorem identity2985 : scanCanonicalize (H12AffineFastState.compose env2985 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound2985 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env2986 : List Nat := [2,4,8,1,32,0,128,173,0,1024,2048,1197,8192,2211,8200,11301,1197,11271,1024,8200,1197,10248,10280,34,8329,10281,8320,2211,2210,1071,2063,3239,173,3086,11396,10281]

theorem envBound2986 : H12AffineFastState.Bounded env2986 := by
  intro p hp
  have h : env2986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2985_2986 : H12AffineEnvironment.transform 8 0 env2985 = env2986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env2985 == env2986) = true)

theorem identity2986 : scanCanonicalize (H12AffineFastState.compose env2986 (packedSelected [0,1,2,3,5,8,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1159) := by decide +kernel

theorem selectedBound2986 : packedSelected [0,1,2,3,5,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env2987 : List Nat := [2,4,8,1,32,0,128,173,0,1024,1159,1197,8192,1060,8200,8354,1197,8320,1024,8200,1197,9359,9391,34,8329,9390,8320,1060,1061,1071,1160,32,173,137,8195,9390]

theorem envBound2987 : H12AffineFastState.Bounded env2987 := by
  intro p hp
  have h : env2987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2986_2987 : H12AffineEnvironment.transform 10 1159 env2986 = env2987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1159 env2986 == env2987) = true)

theorem identity2987 : scanCanonicalize (H12AffineFastState.compose env2987 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound2987 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env2988 : List Nat := [2,4,8,1,32,0,128,173,0,1024,1159,1197,1062,1060,1070,1156,1197,1190,1024,1070,1197,169,137,34,1199,136,1190,1060,1061,1071,1160,32,173,137,1061,136]

theorem envBound2988 : H12AffineFastState.Bounded env2988 := by
  intro p hp
  have h : env2988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2987_2988 : H12AffineEnvironment.transform 12 1062 env2987 = env2988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env2987 == env2988) = true)

theorem identity2988 : scanCanonicalize (H12AffineFastState.compose env2988 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound2988 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env2989 : List Nat := [2,4,8,1,32,0,128,173,0,4,131,169,34,32,42,128,169,162,4,42,169,169,137,34,171,136,162,32,33,43,140,32,173,137,33,136]

theorem envBound2989 : H12AffineFastState.Bounded env2989 := by
  intro p hp
  have h : env2989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2988_2989 : H12AffineEnvironment.transform 9 4 env2988 = env2989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env2988 == env2989) = true)

theorem identity2989 : scanCanonicalize (H12AffineFastState.compose env2989 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound2989 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env2990 : List Nat := [2,4,8,1,32,0,35,14,0,4,32,10,34,32,42,35,10,1,4,42,10,10,42,34,8,43,1,32,33,43,47,32,14,42,33,43]

theorem envBound2990 : H12AffineFastState.Bounded env2990 := by
  intro p hp
  have h : env2990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2989_2990 : H12AffineEnvironment.transform 6 35 env2989 = env2990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env2989 == env2990) = true)

theorem identity2990 : scanCanonicalize (H12AffineFastState.compose env2990 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound2990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env2991 : List Nat := [2,4,2,1,32,0,35,4,0,4,32,0,34,32,32,35,0,1,4,32,0,0,32,34,2,33,1,32,33,33,37,32,4,32,33,33]

theorem envBound2991 : H12AffineFastState.Bounded env2991 := by
  intro p hp
  have h : env2991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2990_2991 : H12AffineEnvironment.transform 2 2 env2990 = env2991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env2990 == env2991) = true)

def env2992 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,65536,1196,262144,1024,32768,1212,4194304,8388608,41002,8329,8388609,320573,16384,16401,19613,74794,12641340,189,17596,8478763,8389120]

theorem envBound2992 : H12AffineFastState.Bounded env2992 := by
  intro p hp
  have h : env2992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2967_2992 : H12AffineEnvironment.transform 7 189 env2967 = env2992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env2967 == env2992) = true)

theorem identity2992 : scanCanonicalize (H12AffineFastState.compose env2992 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50214) := by decide +kernel

theorem selectedBound2992 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env2993 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50214,1196,262144,1024,32768,1212,4194304,8388608,41002,8329,8388609,320573,16384,16401,19613,57356,12641340,189,17596,8430605,8389120]

theorem envBound2993 : H12AffineFastState.Bounded env2993 := by
  intro p hp
  have h : env2993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2992_2993 : H12AffineEnvironment.transform 15 50214 env2992 = env2993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50214 env2992 == env2993) = true)

def env2994 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50214,1196,262144,1024,32768,1212,4194304,4235392,41002,8329,4235393,320573,16384,16401,19613,57356,17596,189,17596,4195469,4235904]

theorem envBound2994 : H12AffineFastState.Bounded env2994 := by
  intro p hp
  have h : env2994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2993_2994 : H12AffineEnvironment.transform 22 4235392 env2993 = env2994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env2993 == env2994) = true)

theorem identity2994 : scanCanonicalize (H12AffineFastState.compose env2994 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound2994 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env2995 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,32768,50214,1044,262144,1024,32768,1028,4194304,4235320,41002,8241,4235321,320573,16384,16401,19493,57356,17412,5,17412,4195381,4235832]

theorem envBound2995 : H12AffineFastState.Bounded env2995 := by
  intro p hp
  have h : env2995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2994_2995 : H12AffineEnvironment.transform 6 56 env2994 = env2995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env2994 == env2995) = true)

theorem identity2995 : scanCanonicalize (H12AffineFastState.compose env2995 (packedSelected [5,13,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound2995 : packedSelected [5,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env2996 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,8216,25662,1044,262144,1024,8216,1028,4194304,4194336,50,8241,4194337,279589,16384,16401,19493,16404,17412,5,17412,4195381,4194848]

theorem envBound2996 : H12AffineFastState.Bounded env2996 := by
  intro p hp
  have h : env2996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2995_2996 : H12AffineEnvironment.transform 14 8216 env2995 = env2996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env2995 == env2996) = true)

theorem identity2996 : scanCanonicalize (H12AffineFastState.compose env2996 (packedSelected [0,2,4,6,7,9,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 2619) := by decide +kernel

theorem selectedBound2996 : packedSelected [0,2,4,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env2997 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1028,8192,16384,8216,25662,1044,2619,1024,8216,1028,4194304,4194336,50,8241,4194337,19998,16384,16401,19493,16404,17412,5,17412,4195381,4194848]

theorem envBound2997 : H12AffineFastState.Bounded env2997 := by
  intro p hp
  have h : env2997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2996_2997 : H12AffineEnvironment.transform 17 2619 env2996 = env2997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2619 env2996 == env2997) = true)

theorem identity2997 : scanCanonicalize (H12AffineFastState.compose env2997 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound2997 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env2998 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,8201,25647,1029,2602,1024,8201,1028,4194304,4194336,35,8224,4194337,19983,16384,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound2998 : H12AffineFastState.Bounded env2998 := by
  intro p hp
  have h : env2998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2997_2998 : H12AffineEnvironment.transform 3 1 env2997 = env2998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env2997 == env2998) = true)

theorem identity2998 : scanCanonicalize (H12AffineFastState.compose env2998 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 523) := by decide +kernel

theorem selectedBound2998 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env2999 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,16384,8201,25647,1029,2602,1024,8201,1028,523,555,35,8224,554,19983,16384,16384,19493,16389,17412,5,17412,1583,43]

theorem envBound2999 : H12AffineFastState.Bounded env2999 := by
  intro p hp
  have h : env2999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2998_2999 : H12AffineEnvironment.transform 21 523 env2998 = env2999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 523 env2998 == env2999) = true)

theorem identity2999 : scanCanonicalize (H12AffineFastState.compose env2999 (packedSelected [0,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 10787) := by decide +kernel

theorem selectedBound2999 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env3000 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,8192,10787,8201,3596,1029,2602,1024,8201,1028,523,555,35,8224,554,9260,10787,10787,9734,10790,11815,5,11815,1583,43]

theorem envBound3000 : H12AffineFastState.Bounded env3000 := by
  intro p hp
  have h : env3000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2999_3000 : H12AffineEnvironment.transform 13 10787 env2999 = env3000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10787 env2999 == env3000) = true)

theorem identity3000 : scanCanonicalize (H12AffineFastState.compose env3000 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound3000 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env3001 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1028,515,2080,522,3596,1029,2602,1024,522,1028,523,555,35,547,554,1583,2080,2080,1029,2085,3108,5,3108,1583,43]

theorem envBound3001 : H12AffineFastState.Bounded env3001 := by
  intro p hp
  have h : env3001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3000_3001 : H12AffineEnvironment.transform 12 515 env3000 = env3001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env3000 == env3001) = true)

theorem identity3001 : scanCanonicalize (H12AffineFastState.compose env3001 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound3001 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3002 : List Nat := [2,4,8,1,32,0,41,5,512,1024,1583,1028,515,1551,522,35,1029,1029,1024,522,1028,523,555,35,547,554,1583,1551,1551,1029,1546,523,5,523,1583,43]

theorem envBound3002 : H12AffineFastState.Bounded env3002 := by
  intro p hp
  have h : env3002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3001_3002 : H12AffineEnvironment.transform 10 1583 env3001 = env3002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env3001 == env3002) = true)

theorem identity3002 : scanCanonicalize (H12AffineFastState.compose env3002 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound3002 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3003 : List Nat := [2,4,8,1,32,0,41,5,512,526,33,522,515,1,522,35,523,523,526,522,522,523,555,35,547,554,33,1,1,523,4,523,5,523,33,43]

theorem envBound3003 : H12AffineFastState.Bounded env3003 := by
  intro p hp
  have h : env3003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3002_3003 : H12AffineEnvironment.transform 9 526 env3002 = env3003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env3002 == env3003) = true)

theorem identity3003 : scanCanonicalize (H12AffineFastState.compose env3003 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound3003 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3004 : List Nat := [2,4,8,1,10,0,3,5,512,526,11,522,515,1,522,9,523,523,526,522,522,523,513,9,521,512,11,1,1,523,4,523,5,523,11,1]

theorem envBound3004 : H12AffineFastState.Bounded env3004 := by
  intro p hp
  have h : env3004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3003_3004 : H12AffineEnvironment.transform 4 10 env3003 = env3004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env3003 == env3004) = true)

theorem identity3004 : scanCanonicalize (H12AffineFastState.compose env3004 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3005 : List Nat := [2,4,8,1,10,0,3,5,0,14,11,10,3,1,10,9,11,11,14,10,10,11,1,9,9,0,11,1,1,11,4,11,5,11,11,1]

theorem envBound3005 : H12AffineFastState.Bounded env3005 := by
  intro p hp
  have h : env3005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3004_3005 : H12AffineEnvironment.transform 8 0 env3004 = env3005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3004 == env3005) = true)

theorem identity3005 : scanCanonicalize (H12AffineFastState.compose env3005 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound3005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3006 : List Nat := [2,4,6,1,4,0,3,5,0,0,5,4,3,1,4,7,5,5,0,4,4,5,1,7,7,0,5,1,1,5,4,5,5,5,5,1]

theorem envBound3006 : H12AffineFastState.Bounded env3006 := by
  intro p hp
  have h : env3006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3005_3006 : H12AffineEnvironment.transform 2 6 env3005 = env3006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env3005 == env3006) = true)

def env3007 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1212,8192,16384,32768,50214,1196,262144,1024,32768,1212,4194304,4235393,41002,8329,4235392,320573,16384,16401,19613,57356,17597,189,17596,4195468,4235905]

theorem envBound3007 : H12AffineFastState.Bounded env3007 := by
  intro p hp
  have h : env3007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2993_3007 : H12AffineEnvironment.transform 22 4235393 env2993 = env3007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env2993 == env3007) = true)

theorem identity3007 : scanCanonicalize (H12AffineFastState.compose env3007 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3007 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env3008 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50214,1196,262144,1024,32768,1197,4194304,4235393,41002,8329,4235392,320556,16384,16384,19596,57356,17580,172,17581,4195468,4235905]

theorem envBound3008 : H12AffineFastState.Bounded env3008 := by
  intro p hp
  have h : env3008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3007_3008 : H12AffineEnvironment.transform 3 1 env3007 = env3008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3007 == env3008) = true)

theorem identity3008 : scanCanonicalize (H12AffineFastState.compose env3008 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound3008 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3009 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50214,1196,262144,1024,32768,1197,41001,168,41002,8329,169,320556,16384,16384,19596,57356,17580,172,17581,42149,680]

theorem envBound3009 : H12AffineFastState.Bounded env3009 := by
  intro p hp
  have h : env3009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3008_3009 : H12AffineEnvironment.transform 21 41001 env3008 = env3009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env3008 == env3009) = true)

theorem identity3009 : scanCanonicalize (H12AffineFastState.compose env3009 (packedSelected [0,3,5,7,10,17,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 19972) := by decide +kernel

theorem selectedBound3009 : packedSelected [0,3,5,7,10,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3010 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,32768,50214,1196,19972,1024,32768,1197,41001,168,41002,8329,169,43560,16384,16384,19596,57356,17580,172,17581,42149,680]

theorem envBound3010 : H12AffineFastState.Bounded env3010 := by
  intro p hp
  have h : env3010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3009_3010 : H12AffineEnvironment.transform 17 19972 env3009 = env3010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19972 env3009 == env3010) = true)

theorem identity3010 : scanCanonicalize (H12AffineFastState.compose env3010 (packedSelected [1,3,11,13,17,23] rootPS)) = affineNative (2^(14+1) ^^^ 8713) := by decide +kernel

theorem selectedBound3010 : packedSelected [1,3,11,13,17,23] rootPS < 2^1333 := by decide +kernel

def env3011 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,16384,8713,26159,1196,19972,1024,8713,1197,544,168,547,8329,169,2081,16384,16384,19596,16901,17580,172,17581,1708,680]

theorem envBound3011 : H12AffineFastState.Bounded env3011 := by
  intro p hp
  have h : env3011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3010_3011 : H12AffineEnvironment.transform 14 8713 env3010 = env3011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8713 env3010 == env3011) = true)

theorem identity3011 : scanCanonicalize (H12AffineFastState.compose env3011 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 1165) := by decide +kernel

theorem selectedBound3011 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env3012 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,8192,1165,8713,8866,1196,2697,1024,8713,1197,544,168,547,8329,169,2081,1165,1165,2049,1672,33,172,32,1708,680]

theorem envBound3012 : H12AffineFastState.Bounded env3012 := by
  intro p hp
  have h : env3012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3011_3012 : H12AffineEnvironment.transform 13 1165 env3011 = env3012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1165 env3011 == env3012) = true)

theorem identity3012 : scanCanonicalize (H12AffineFastState.compose env3012 (packedSelected [0,2,6] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound3012 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env3013 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1197,160,1165,681,514,1196,2697,1024,681,1197,544,168,547,41,169,2081,1165,1165,2049,1672,33,172,32,1708,680]

theorem envBound3013 : H12AffineFastState.Bounded env3013 := by
  intro p hp
  have h : env3013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3012_3013 : H12AffineEnvironment.transform 12 160 env3012 = env3013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env3012 == env3013) = true)

theorem identity3013 : scanCanonicalize (H12AffineFastState.compose env3013 (packedSelected [2,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 647) := by decide +kernel

theorem selectedBound3013 : packedSelected [2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3014 : List Nat := [2,4,8,1,32,0,128,172,512,647,2048,554,160,522,681,514,555,2697,647,681,554,544,168,547,41,169,2081,522,522,2049,15,33,172,32,43,680]

theorem envBound3014 : H12AffineFastState.Bounded env3014 := by
  intro p hp
  have h : env3014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3013_3014 : H12AffineEnvironment.transform 9 647 env3013 = env3014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 647 env3013 == env3014) = true)

theorem identity3014 : scanCanonicalize (H12AffineFastState.compose env3014 (packedSelected [0,1,2,3,4,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3014 : packedSelected [0,1,2,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env3015 : List Nat := [2,4,8,1,32,0,41,5,512,558,2048,554,9,522,512,514,555,2592,558,512,554,544,1,547,41,0,2081,522,522,2049,15,33,5,32,43,513]

theorem envBound3015 : H12AffineFastState.Bounded env3015 := by
  intro p hp
  have h : env3015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3014_3015 : H12AffineEnvironment.transform 6 41 env3014 = env3015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3014 == env3015) = true)

theorem identity3015 : scanCanonicalize (H12AffineFastState.compose env3015 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound3015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3016 : List Nat := [2,4,8,1,32,0,41,5,33,15,2048,11,9,43,33,35,10,2049,15,33,11,1,1,2,41,0,2081,43,43,2049,15,33,5,32,43,32]

theorem envBound3016 : H12AffineFastState.Bounded env3016 := by
  intro p hp
  have h : env3016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3015_3016 : H12AffineEnvironment.transform 8 33 env3015 = env3016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env3015 == env3016) = true)

def env3017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323793,16384,16893,22641,74795,12644669,257,20560,8479126,8389613]

theorem envBound3017 : H12AffineFastState.Bounded env3017 := by
  intro p hp
  have h : env3017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2958_3017 : H12AffineEnvironment.transform 18 1025 env2958 = env3017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env2958 == env3017) = true)

theorem identity3017 : scanCanonicalize (H12AffineFastState.compose env3017 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound3017 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,20925,41002,8329,20972,323793,16384,16893,22641,74795,4235392,257,20560,77867,21072]

theorem envBound3018 : H12AffineFastState.Bounded env3018 := by
  intro p hp
  have h : env3018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3017_3018 : H12AffineEnvironment.transform 22 20925 env3017 = env3018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env3017 == env3018) = true)

def env3019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4604,262144,1025,32768,4096,4194304,445,41002,8329,492,303313,4096,4605,2161,74795,4235392,257,80,77867,592]

theorem envBound3019 : H12AffineFastState.Bounded env3019 := by
  intro p hp
  have h : env3019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3018_3019 : H12AffineEnvironment.transform 13 4096 env3018 = env3019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env3018 == env3019) = true)

theorem identity3019 : scanCanonicalize (H12AffineFastState.compose env3019 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3019 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3020 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,4194304,445,41002,8329,444,303233,4096,4525,2081,74795,4235392,257,0,77867,512]

theorem envBound3020 : H12AffineFastState.Bounded env3020 := by
  intro p hp
  have h : env3020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3019_3020 : H12AffineEnvironment.transform 5 16 env3019 = env3020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3019 == env3020) = true)

theorem identity3020 : scanCanonicalize (H12AffineFastState.compose env3020 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound3020 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4096,41348,445,41002,8329,444,303233,4096,4525,2081,74795,260,257,0,77867,512]

theorem envBound3021 : H12AffineFastState.Bounded env3021 := by
  intro p hp
  have h : env3021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3020_3021 : H12AffineEnvironment.transform 21 41348 env3020 = env3021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env3020 == env3021) = true)

theorem identity3021 : scanCanonicalize (H12AffineFastState.compose env3021 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3021 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,38843,4524,262144,1025,32768,4096,41348,445,41002,8329,444,303233,4096,4525,2081,45968,260,257,0,42896,512]

theorem envBound3022 : H12AffineFastState.Bounded env3022 := by
  intro p hp
  have h : env3022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3021_3022 : H12AffineEnvironment.transform 15 38843 env3021 = env3022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3021 == env3022) = true)

theorem identity3022 : scanCanonicalize (H12AffineFastState.compose env3022 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound3022 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3023 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14137,8322,4524,262144,1025,14137,4096,5821,445,5907,8329,444,268216,4096,4525,2081,1193,260,257,0,4265,512]

theorem envBound3023 : H12AffineFastState.Bounded env3023 := by
  intro p hp
  have h : env3023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3022_3023 : H12AffineEnvironment.transform 14 14137 env3022 = env3023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env3022 == env3023) = true)

theorem identity3023 : scanCanonicalize (H12AffineFastState.compose env3023 (packedSelected [0,13,17,27] rootPS)) = affineNative (2^(17+1) ^^^ 7952) := by decide +kernel

theorem selectedBound3023 : packedSelected [0,13,17,27] rootPS < 2^1333 := by decide +kernel

def env3024 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,14137,8322,4524,7952,1025,14137,4096,5821,445,5907,8329,444,2216,4096,4525,2081,1193,260,257,0,4265,512]

theorem envBound3024 : H12AffineFastState.Bounded env3024 := by
  intro p hp
  have h : env3024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3023_3024 : H12AffineEnvironment.transform 17 7952 env3023 = env3024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7952 env3023 == env3024) = true)

theorem identity3024 : scanCanonicalize (H12AffineFastState.compose env3024 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound3024 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3025 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,4096,13972,8322,4097,7869,1025,13972,4096,5821,16,5822,8329,17,2216,4096,4096,2081,1193,169,172,0,4265,512]

theorem envBound3025 : H12AffineFastState.Bounded env3025 := by
  intro p hp
  have h : env3025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3024_3025 : H12AffineEnvironment.transform 7 173 env3024 = env3025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env3024 == env3025) = true)

theorem identity3025 : scanCanonicalize (H12AffineFastState.compose env3025 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound3025 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3026 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2195,8192,2195,11783,8322,2194,1582,1025,11783,2195,3630,16,3629,8329,17,2216,2195,2195,2081,1193,169,172,0,2106,512]

theorem envBound3026 : H12AffineFastState.Bounded env3026 := by
  intro p hp
  have h : env3026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3025_3026 : H12AffineEnvironment.transform 11 2195 env3025 = env3026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env3025 == env3026) = true)

def env3027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,4194304,444,41002,8329,493,303312,4097,4604,2160,74795,4235392,257,81,77867,593]

theorem envBound3027 : H12AffineFastState.Bounded env3027 := by
  intro p hp
  have h : env3027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3018_3027 : H12AffineEnvironment.transform 13 4097 env3018 = env3027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env3018 == env3027) = true)

def env3028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,41088,444,41002,8329,493,303312,4097,4604,2160,74795,0,257,81,77867,593]

theorem envBound3028 : H12AffineFastState.Bounded env3028 := by
  intro p hp
  have h : env3028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3027_3028 : H12AffineEnvironment.transform 21 41088 env3027 = env3028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env3027 == env3028) = true)

theorem identity3028 : scanCanonicalize (H12AffineFastState.compose env3028 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3028 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3029 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,65536,4344,262144,1025,32768,4096,41088,184,41002,8329,233,303312,4097,4344,2160,74795,0,5,81,77867,593]

theorem envBound3029 : H12AffineFastState.Bounded env3029 := by
  intro p hp
  have h : env3029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3028_3029 : H12AffineEnvironment.transform 7 4 env3028 = env3029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3028 == env3029) = true)

theorem identity3029 : scanCanonicalize (H12AffineFastState.compose env3029 (packedSelected [0,7,11,13,17,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 38591) := by decide +kernel

theorem selectedBound3029 : packedSelected [0,7,11,13,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env3030 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,38591,4344,262144,1025,32768,4096,41088,184,41002,8329,233,303312,4097,4344,2160,45716,0,5,81,42644,593]

theorem envBound3030 : H12AffineFastState.Bounded env3030 := by
  intro p hp
  have h : env3030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3029_3030 : H12AffineEnvironment.transform 15 38591 env3029 = env3030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38591 env3029 == env3030) = true)

def env3031 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,32768,38471,4096,262144,1025,32768,4096,41080,64,41002,8305,17,303144,4097,4096,2160,45676,0,5,81,42604,593]

theorem envBound3031 : H12AffineFastState.Bounded env3031 := by
  intro p hp
  have h : env3031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3030_3031 : H12AffineEnvironment.transform 6 120 env3030 = env3031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env3030 == env3031) = true)

theorem identity3031 : scanCanonicalize (H12AffineFastState.compose env3031 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7749) := by decide +kernel

theorem selectedBound3031 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3032 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,32768,38471,4096,7749,1025,32768,4096,41080,64,41002,8305,17,48749,4097,4096,2160,45676,0,5,81,42604,593]

theorem envBound3032 : H12AffineFastState.Bounded env3032 := by
  intro p hp
  have h : env3032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3031_3032 : H12AffineEnvironment.transform 17 7749 env3031 = env3032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7749 env3031 == env3032) = true)

theorem identity3032 : scanCanonicalize (H12AffineFastState.compose env3032 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13932) := by decide +kernel

theorem selectedBound3032 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env3033 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13932,8235,4096,7749,1025,13932,4096,5652,64,5702,8305,17,2049,4097,4096,2160,1024,0,5,81,4096,593]

theorem envBound3033 : H12AffineFastState.Bounded env3033 := by
  intro p hp
  have h : env3033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3032_3033 : H12AffineEnvironment.transform 14 13932 env3032 = env3033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13932 env3032 == env3033) = true)

theorem identity3033 : scanCanonicalize (H12AffineFastState.compose env3033 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound3033 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3034 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,1030,4097,4714,1069,4096,7749,1025,4714,4096,5652,64,5702,1143,17,2049,4097,4096,2160,1024,0,5,81,4096,593]

theorem envBound3034 : H12AffineFastState.Bounded env3034 := by
  intro p hp
  have h : env3034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3033_3034 : H12AffineEnvironment.transform 12 1030 env3033 = env3034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env3033 == env3034) = true)

theorem identity3034 : scanCanonicalize (H12AffineFastState.compose env3034 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3034 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3035 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,1030,4097,4666,1069,4096,7701,1025,4666,4096,5652,16,5654,1063,17,2049,4097,4096,2080,1024,0,5,1,4096,513]

theorem envBound3035 : H12AffineFastState.Bounded env3035 := by
  intro p hp
  have h : env3035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3034_3035 : H12AffineEnvironment.transform 5 16 env3034 = env3035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3034 == env3035) = true)

theorem identity3035 : scanCanonicalize (H12AffineFastState.compose env3035 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound3035 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3036 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,545,1030,544,27,1069,545,3124,1025,27,545,1077,16,1079,1063,17,2049,544,545,2080,1024,0,5,1,545,513]

theorem envBound3036 : H12AffineFastState.Bounded env3036 := by
  intro p hp
  have h : env3036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3035_3036 : H12AffineEnvironment.transform 11 545 env3035 = env3036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env3035 == env3036) = true)

theorem identity3036 : scanCanonicalize (H12AffineFastState.compose env3036 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound3036 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3037 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1551,545,1030,544,27,1069,545,571,1025,27,545,1077,16,1079,1063,17,1550,544,545,1583,1024,0,5,1,545,513]

theorem envBound3037 : H12AffineFastState.Bounded env3037 := by
  intro p hp
  have h : env3037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3036_3037 : H12AffineEnvironment.transform 10 1551 env3036 = env3037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env3036 == env3037) = true)

theorem identity3037 : scanCanonicalize (H12AffineFastState.compose env3037 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 560) := by decide +kernel

theorem selectedBound3037 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env3038 : List Nat := [2,4,8,16,32,16,40,4,512,560,63,545,566,544,27,541,545,571,561,27,545,517,16,519,535,17,62,544,545,31,560,0,5,1,545,513]

theorem envBound3038 : H12AffineFastState.Bounded env3038 := by
  intro p hp
  have h : env3038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3037_3038 : H12AffineEnvironment.transform 9 560 env3037 = env3038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 560 env3037 == env3038) = true)

theorem identity3038 : scanCanonicalize (H12AffineFastState.compose env3038 (packedSelected [3,7] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound3038 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env3039 : List Nat := [2,4,8,16,32,16,40,4,63,15,63,30,9,31,27,34,30,4,14,27,30,58,16,56,40,17,62,31,30,31,15,0,5,1,30,62]

theorem envBound3039 : H12AffineFastState.Bounded env3039 := by
  intro p hp
  have h : env3039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3038_3039 : H12AffineEnvironment.transform 8 63 env3038 = env3039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env3038 == env3039) = true)

theorem identity3039 : scanCanonicalize (H12AffineFastState.compose env3039 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3039 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env3040 : List Nat := [2,4,8,10,32,10,40,4,37,15,37,4,9,5,1,34,4,4,14,1,4,32,10,34,40,11,36,5,4,5,15,0,5,1,4,36]

theorem envBound3040 : H12AffineFastState.Bounded env3040 := by
  intro p hp
  have h : env3040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3039_3040 : H12AffineEnvironment.transform 3 10 env3039 = env3040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3039 == env3040) = true)

theorem identity3040 : scanCanonicalize (H12AffineFastState.compose env3040 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound3040 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env3041 : List Nat := [2,4,8,10,0,10,8,4,5,15,5,4,9,5,1,2,4,4,14,1,4,0,10,2,8,11,4,5,4,5,15,0,5,1,4,4]

theorem envBound3041 : H12AffineFastState.Bounded env3041 := by
  intro p hp
  have h : env3041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3040_3041 : H12AffineEnvironment.transform 4 0 env3040 = env3041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env3040 == env3041) = true)

theorem identity3041 : scanCanonicalize (H12AffineFastState.compose env3041 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3041 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3042 : List Nat := [2,4,3,1,0,1,3,4,5,4,5,4,2,5,1,2,4,4,5,1,4,0,1,2,3,0,4,5,4,5,4,0,5,1,4,4]

theorem envBound3042 : H12AffineFastState.Bounded env3042 := by
  intro p hp
  have h : env3042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3041_3042 : H12AffineEnvironment.transform 2 3 env3041 = env3042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3041 == env3042) = true)

def env3043 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,32768,38470,4097,262144,1025,32768,4096,41081,65,41002,8304,16,303145,4097,4097,2160,45677,0,5,81,42605,593]

theorem envBound3043 : H12AffineFastState.Bounded env3043 := by
  intro p hp
  have h : env3043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3030_3043 : H12AffineEnvironment.transform 6 121 env3030 = env3043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env3030 == env3043) = true)

theorem identity3043 : scanCanonicalize (H12AffineFastState.compose env3043 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 48668) := by decide +kernel

theorem selectedBound3043 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env3044 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,32768,38470,4097,48668,1025,32768,4096,41081,65,41002,8304,16,7733,4097,4097,2160,45677,0,5,81,42605,593]

theorem envBound3044 : H12AffineFastState.Bounded env3044 := by
  intro p hp
  have h : env3044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3043_3044 : H12AffineEnvironment.transform 17 48668 env3043 = env3044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48668 env3043 == env3044) = true)

theorem identity3044 : scanCanonicalize (H12AffineFastState.compose env3044 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13933) := by decide +kernel

theorem selectedBound3044 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env3045 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13933,8235,4097,2161,1025,13933,4096,5652,65,5703,8304,16,7733,4097,4097,2160,1024,0,5,81,4096,593]

theorem envBound3045 : H12AffineFastState.Bounded env3045 := by
  intro p hp
  have h : env3045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3044_3045 : H12AffineEnvironment.transform 14 13933 env3044 = env3045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13933 env3044 == env3045) = true)

theorem identity3045 : scanCanonicalize (H12AffineFastState.compose env3045 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 4627) := by decide +kernel

theorem selectedBound3045 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env3046 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,4627,4097,1150,4664,4097,2161,1025,1150,4096,5652,65,5703,4707,16,7733,4097,4097,2160,1024,0,5,81,4096,593]

theorem envBound3046 : H12AffineFastState.Bounded env3046 := by
  intro p hp
  have h : env3046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3045_3046 : H12AffineEnvironment.transform 12 4627 env3045 = env3046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4627 env3045 == env3046) = true)

theorem identity3046 : scanCanonicalize (H12AffineFastState.compose env3046 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3046 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3047 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,4627,4097,1070,4664,4097,2081,1025,1070,4096,5652,17,5655,4659,16,7733,4097,4097,2080,1024,0,5,1,4096,513]

theorem envBound3047 : H12AffineFastState.Bounded env3047 := by
  intro p hp
  have h : env3047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3046_3047 : H12AffineEnvironment.transform 5 16 env3046 = env3047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3046 == env3047) = true)

theorem identity3047 : scanCanonicalize (H12AffineFastState.compose env3047 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound3047 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env3048 : List Nat := [2,4,8,16,32,16,41,4,512,1024,538,4096,4627,4097,1070,4664,4097,571,1025,1070,4096,5652,17,5655,4659,16,5167,4097,4097,570,1024,0,5,1,4096,513]

theorem envBound3048 : H12AffineFastState.Bounded env3048 := by
  intro p hp
  have h : env3048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3047_3048 : H12AffineEnvironment.transform 10 538 env3047 = env3048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env3047 == env3048) = true)

theorem identity3048 : scanCanonicalize (H12AffineFastState.compose env3048 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound3048 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3049 : List Nat := [2,4,8,16,32,16,41,4,512,1024,538,545,50,544,1070,25,544,571,1025,1070,545,1077,17,1078,18,16,1550,544,544,570,1024,0,5,1,545,513]

theorem envBound3049 : H12AffineFastState.Bounded env3049 := by
  intro p hp
  have h : env3049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3048_3049 : H12AffineEnvironment.transform 11 545 env3048 = env3049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env3048 == env3049) = true)

theorem identity3049 : scanCanonicalize (H12AffineFastState.compose env3049 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound3049 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env3050 : List Nat := [2,4,8,16,32,16,41,4,4,1024,30,37,50,36,1070,25,36,63,1025,1070,37,1077,17,1078,18,16,1034,36,36,62,1024,0,5,1,37,5]

theorem envBound3050 : H12AffineFastState.Bounded env3050 := by
  intro p hp
  have h : env3050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3049_3050 : H12AffineEnvironment.transform 8 4 env3049 = env3050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env3049 == env3050) = true)

theorem identity3050 : scanCanonicalize (H12AffineFastState.compose env3050 (packedSelected [1,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound3050 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env3051 : List Nat := [2,4,8,16,32,16,41,4,4,46,30,37,50,36,0,25,36,63,47,0,37,27,17,24,18,16,36,36,36,62,46,0,5,1,37,5]

theorem envBound3051 : H12AffineFastState.Bounded env3051 := by
  intro p hp
  have h : env3051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3050_3051 : H12AffineEnvironment.transform 9 46 env3050 = env3051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env3050 == env3051) = true)

theorem identity3051 : scanCanonicalize (H12AffineFastState.compose env3051 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3051 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env3052 : List Nat := [2,4,8,16,26,16,19,4,4,20,30,31,8,30,0,25,30,5,21,0,31,27,17,24,18,16,30,30,30,4,20,0,5,1,31,5]

theorem envBound3052 : H12AffineFastState.Bounded env3052 := by
  intro p hp
  have h : env3052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3051_3052 : H12AffineEnvironment.transform 4 26 env3051 = env3052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3051 == env3052) = true)

theorem identity3052 : scanCanonicalize (H12AffineFastState.compose env3052 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound3052 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3053 : List Nat := [2,4,8,14,4,14,13,4,4,10,0,1,8,0,0,7,0,5,11,0,1,5,15,6,12,14,0,0,0,4,10,0,5,1,1,5]

theorem envBound3053 : H12AffineFastState.Bounded env3053 := by
  intro p hp
  have h : env3053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3052_3053 : H12AffineEnvironment.transform 3 14 env3052 = env3053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env3052 == env3053) = true)

theorem identity3053 : scanCanonicalize (H12AffineFastState.compose env3053 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3054 : List Nat := [2,4,2,4,4,4,7,4,4,0,0,1,2,0,0,7,0,5,1,0,1,5,5,6,6,4,0,0,0,4,0,0,5,1,1,5]

theorem envBound3054 : H12AffineFastState.Bounded env3054 := by
  intro p hp
  have h : env3054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3053_3054 : H12AffineEnvironment.transform 2 2 env3053 = env3054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3053 == env3054) = true)

theorem identity3054 : scanCanonicalize (H12AffineFastState.compose env3054 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3055 : List Nat := [2,0,2,0,0,0,3,0,0,0,0,1,2,0,0,3,0,1,1,0,1,1,1,2,2,0,0,0,0,0,0,0,1,1,1,1]

theorem envBound3055 : H12AffineFastState.Bounded env3055 := by
  intro p hp
  have h : env3055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3054_3055 : H12AffineEnvironment.transform 1 0 env3054 = env3055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3054 == env3055) = true)

def env3056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4604,262144,1025,32768,4096,41089,444,41002,8329,493,303312,4097,4604,2160,74795,1,257,81,77867,593]

theorem envBound3056 : H12AffineFastState.Bounded env3056 := by
  intro p hp
  have h : env3056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3027_3056 : H12AffineEnvironment.transform 21 41089 env3027 = env3056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env3027 == env3056) = true)

theorem identity3056 : scanCanonicalize (H12AffineFastState.compose env3056 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound3056 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3057 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4264,262144,1025,32768,4096,41089,232,41002,8329,185,303312,4097,4264,2160,74795,1,85,81,77867,593]

theorem envBound3057 : H12AffineFastState.Bounded env3057 := by
  intro p hp
  have h : env3057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3056_3057 : H12AffineEnvironment.transform 7 84 env3056 = env3057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env3056 == env3057) = true)

theorem identity3057 : scanCanonicalize (H12AffineFastState.compose env3057 (packedSelected [0,5,7,8,10,11,13,17,18,20,23,24,26,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 106039) := by decide +kernel

theorem selectedBound3057 : packedSelected [0,5,7,8,10,11,13,17,18,20,23,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env3058 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4264,106039,1025,32768,4096,41089,232,41002,8329,185,81639,4097,4264,2160,74795,1,85,81,77867,593]

theorem envBound3058 : H12AffineFastState.Bounded env3058 := by
  intro p hp
  have h : env3058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3057_3058 : H12AffineEnvironment.transform 17 106039 env3057 = env3058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106039 env3057 == env3058) = true)

def env3059 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,65536,4096,106039,1025,32768,4096,41001,64,41002,8225,17,81487,4097,4096,2160,74795,1,85,81,77867,593]

theorem envBound3059 : H12AffineFastState.Bounded env3059 := by
  intro p hp
  have h : env3059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3058_3059 : H12AffineEnvironment.transform 6 40 env3058 = env3059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3058 == env3059) = true)

theorem identity3059 : scanCanonicalize (H12AffineFastState.compose env3059 (packedSelected [0,7,17,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound3059 : packedSelected [0,7,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3060 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,32802,4096,7701,1025,32768,4096,41001,64,41002,8225,17,48749,4097,4096,2160,41993,1,85,81,45065,593]

theorem envBound3060 : H12AffineFastState.Bounded env3060 := by
  intro p hp
  have h : env3060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3059_3060 : H12AffineEnvironment.transform 15 32802 env3059 = env3060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env3059 == env3060) = true)

theorem identity3060 : scanCanonicalize (H12AffineFastState.compose env3060 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound3060 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3061 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13885,13855,4096,7701,1025,13885,4096,5652,64,5655,8225,17,2128,4097,4096,2160,4660,1,85,81,1588,593]

theorem envBound3061 : H12AffineFastState.Bounded env3061 := by
  intro p hp
  have h : env3061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3060_3061 : H12AffineEnvironment.transform 14 13885 env3060 = env3061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env3060 == env3061) = true)

theorem identity3061 : scanCanonicalize (H12AffineFastState.compose env3061 (packedSelected [0,1,2,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound3061 : packedSelected [0,1,2,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env3062 : List Nat := [2,4,8,16,32,10,40,30,512,1024,2048,4096,8192,4097,13885,13855,4096,7701,1025,13885,4096,5652,10,5655,8225,17,2074,4097,4096,2106,4660,1,31,27,1588,539]

theorem envBound3062 : H12AffineFastState.Bounded env3062 := by
  intro p hp
  have h : env3062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3061_3062 : H12AffineEnvironment.transform 5 10 env3061 = env3062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env3061 == env3062) = true)

theorem identity3062 : scanCanonicalize (H12AffineFastState.compose env3062 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound3062 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3063 : List Nat := [2,4,8,16,32,10,40,30,512,1024,2048,1589,8192,1588,8200,8234,1589,2080,1025,8200,1589,33,10,34,8225,17,2074,1588,1589,2106,1025,1,31,27,1588,539]

theorem envBound3063 : H12AffineFastState.Bounded env3063 := by
  intro p hp
  have h : env3063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3062_3063 : H12AffineEnvironment.transform 11 1589 env3062 = env3063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env3062 == env3063) = true)

theorem identity3063 : scanCanonicalize (H12AffineFastState.compose env3063 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound3063 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3064 : List Nat := [2,4,8,16,32,10,40,30,512,1024,1557,1589,8192,1588,8200,8234,1589,1589,1025,8200,1589,33,10,34,8225,17,1551,1588,1589,1583,1025,1,31,27,1588,539]

theorem envBound3064 : H12AffineFastState.Bounded env3064 := by
  intro p hp
  have h : env3064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3063_3064 : H12AffineEnvironment.transform 10 1557 env3063 = env3064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env3063 == env3064) = true)

theorem identity3064 : scanCanonicalize (H12AffineFastState.compose env3064 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3064 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3065 : List Nat := [2,4,8,10,32,10,40,4,512,1024,1551,1583,8192,1582,8200,8234,1583,1583,1025,8200,1583,33,10,34,8225,11,1551,1582,1583,1583,1025,1,5,1,1582,513]

theorem envBound3065 : H12AffineFastState.Bounded env3065 := by
  intro p hp
  have h : env3065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3064_3065 : H12AffineEnvironment.transform 3 10 env3064 = env3065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3064 == env3065) = true)

theorem identity3065 : scanCanonicalize (H12AffineFastState.compose env3065 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound3065 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env3066 : List Nat := [2,4,8,10,32,10,40,4,512,1024,1551,1583,1031,1582,1039,1069,1583,1583,1025,1039,1583,33,10,34,1062,11,1551,1582,1583,1583,1025,1,5,1,1582,513]

theorem envBound3066 : H12AffineFastState.Bounded env3066 := by
  intro p hp
  have h : env3066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3065_3066 : H12AffineEnvironment.transform 12 1031 env3065 = env3066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env3065 == env3066) = true)

theorem identity3066 : scanCanonicalize (H12AffineFastState.compose env3066 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound3066 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3067 : List Nat := [2,4,8,10,32,10,40,4,15,1024,1024,1056,1031,1057,1039,1069,1056,1056,1025,1039,1056,33,10,34,1062,11,1024,1057,1056,1056,1025,1,5,1,1057,14]

theorem envBound3067 : H12AffineFastState.Bounded env3067 := by
  intro p hp
  have h : env3067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3066_3067 : H12AffineEnvironment.transform 8 15 env3066 = env3067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env3066 == env3067) = true)

theorem identity3067 : scanCanonicalize (H12AffineFastState.compose env3067 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3067 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3068 : List Nat := [2,4,2,0,32,0,34,4,5,1024,1024,1056,1031,1057,1029,1063,1056,1056,1025,1029,1056,33,0,34,1062,1,1024,1057,1056,1056,1025,1,5,1,1057,4]

theorem envBound3068 : H12AffineFastState.Bounded env3068 := by
  intro p hp
  have h : env3068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3067_3068 : H12AffineEnvironment.transform 2 2 env3067 = env3068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3067 == env3068) = true)

theorem identity3068 : scanCanonicalize (H12AffineFastState.compose env3068 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound3068 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env3069 : List Nat := [2,1,2,0,32,0,34,1,0,1024,1024,1056,1026,1057,1024,1058,1056,1056,1025,1024,1056,33,0,34,1059,1,1024,1057,1056,1056,1025,1,0,1,1057,1]

theorem envBound3069 : H12AffineFastState.Bounded env3069 := by
  intro p hp
  have h : env3069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3068_3069 : H12AffineEnvironment.transform 1 1 env3068 = env3069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env3068 == env3069) = true)

theorem identity3069 : scanCanonicalize (H12AffineFastState.compose env3069 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound3069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3070 : List Nat := [2,1,2,0,32,0,34,1,0,32,32,0,34,1,32,2,0,0,33,32,0,33,0,34,3,1,32,1,0,0,33,1,0,1,1,1]

theorem envBound3070 : H12AffineFastState.Bounded env3070 := by
  intro p hp
  have h : env3070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3069_3070 : H12AffineEnvironment.transform 9 32 env3069 = env3070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env3069 == env3070) = true)

def leafEnv3070 : List Nat := [2,1,2,0,32,0,34,1,0,32,32,0,34,1,32,2,0,0,33,32,0,33,0,34,32,3,1,1,32,1,0,0,33,1,0,1,0,35,1,1,1,0,0]

def active3070 : List Nat := [0,4]

def tree3070 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3070 : H12WitnessSearch.Good tree3070 := H12GlobalWitnessIndex.good

theorem leafIdentity3070 : H12AffineFastState.composeSystem env3070 rootObs = leafEnv3070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3070 rootObs == leafEnv3070) = true)

theorem terminalChecked3070 : H12PackedTerminal.terminalCheckFast leafEnv3070 active3070 tree3070 = true := by decide +kernel

def env3071 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,65536,4097,106039,1025,32768,4096,41000,65,41002,8224,16,81486,4097,4097,2160,74795,1,85,81,77867,593]

theorem envBound3071 : H12AffineFastState.Bounded env3071 := by
  intro p hp
  have h : env3071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3058_3071 : H12AffineEnvironment.transform 6 41 env3058 = env3071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3058 == env3071) = true)

theorem identity3071 : scanCanonicalize (H12AffineFastState.compose env3071 (packedSelected [0,7,17,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound3071 : packedSelected [0,7,17,20,21] rootPS < 2^1333 := by decide +kernel

def env3072 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,8314,4097,48717,1025,32768,4096,41000,65,41002,8224,16,7732,4097,4097,2160,1105,1,85,81,4177,593]

theorem envBound3072 : H12AffineFastState.Bounded env3072 := by
  intro p hp
  have h : env3072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3071_3072 : H12AffineEnvironment.transform 15 8314 env3071 = env3072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env3071 == env3072) = true)

theorem identity3072 : scanCanonicalize (H12AffineFastState.compose env3072 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound3072 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env3073 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,8192,1637,32768,8314,1637,43049,1025,32768,1636,41000,65,41002,8224,16,2128,1637,1637,2160,1105,1,85,81,1589,593]

theorem envBound3073 : H12AffineFastState.Bounded env3073 := by
  intro p hp
  have h : env3073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3072_3073 : H12AffineEnvironment.transform 11 1636 env3072 = env3073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env3072 == env3073) = true)

theorem identity3073 : scanCanonicalize (H12AffineFastState.compose env3073 (packedSelected [6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8227) := by decide +kernel

theorem selectedBound3073 : packedSelected [6,10] rootPS < 2^1333 := by decide +kernel

def env3074 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,8192,1637,8227,8314,1637,2058,1025,8227,1636,11,65,9,8224,16,2128,1637,1637,2160,1105,1,85,81,1589,593]

theorem envBound3074 : H12AffineFastState.Bounded env3074 := by
  intro p hp
  have h : env3074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3073_3074 : H12AffineEnvironment.transform 14 8227 env3073 = env3074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8227 env3073 == env3074) = true)

theorem identity3074 : scanCanonicalize (H12AffineFastState.compose env3074 (packedSelected [2,3,5,6,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound3074 : packedSelected [2,3,5,6,11,18] rootPS < 2^1333 := by decide +kernel

def env3075 : List Nat := [2,4,8,16,32,43,41,63,512,1024,2048,1551,8192,1550,8227,8209,1550,2058,1025,8227,1551,11,42,9,8224,16,2107,1550,1550,2075,1082,1,62,58,1589,570]

theorem envBound3075 : H12AffineFastState.Bounded env3075 := by
  intro p hp
  have h : env3075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3074_3075 : H12AffineEnvironment.transform 5 43 env3074 = env3075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env3074 == env3075) = true)

theorem identity3075 : scanCanonicalize (H12AffineFastState.compose env3075 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound3075 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env3076 : List Nat := [2,4,8,16,11,0,2,20,512,1024,2048,1551,8192,1550,8200,8209,1550,2058,1025,8200,1551,11,1,9,8203,16,2064,1550,1550,2075,1041,1,21,17,1566,529]

theorem envBound3076 : H12AffineFastState.Bounded env3076 := by
  intro p hp
  have h : env3076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3075_3076 : H12AffineEnvironment.transform 4 11 env3075 = env3076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env3075 == env3076) = true)

theorem identity3076 : scanCanonicalize (H12AffineFastState.compose env3076 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound3076 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env3077 : List Nat := [2,4,8,16,11,0,2,20,512,1024,2048,1551,8,1550,0,25,1550,2058,1025,0,1551,11,1,9,3,16,2064,1550,1550,2075,1041,1,21,17,1566,529]

theorem envBound3077 : H12AffineFastState.Bounded env3077 := by
  intro p hp
  have h : env3077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3076_3077 : H12AffineEnvironment.transform 12 8 env3076 = env3077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env3076 == env3077) = true)

theorem identity3077 : scanCanonicalize (H12AffineFastState.compose env3077 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound3077 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env3078 : List Nat := [2,4,8,16,11,0,2,20,512,1024,513,1551,8,1550,0,25,1550,523,1025,0,1551,11,1,9,3,16,529,1550,1550,538,1041,1,21,17,1566,529]

theorem envBound3078 : H12AffineFastState.Bounded env3078 := by
  intro p hp
  have h : env3078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3077_3078 : H12AffineEnvironment.transform 10 513 env3077 = env3078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env3077 == env3078) = true)

theorem identity3078 : scanCanonicalize (H12AffineFastState.compose env3078 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3078 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env3079 : List Nat := [2,4,8,1,11,0,2,5,512,1024,513,1551,8,1550,0,8,1550,523,1025,0,1551,11,1,9,3,1,512,1550,1550,523,1024,1,4,0,1551,512]

theorem envBound3079 : H12AffineFastState.Bounded env3079 := by
  intro p hp
  have h : env3079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3078_3079 : H12AffineEnvironment.transform 3 1 env3078 = env3079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3078 == env3079) = true)

theorem identity3079 : scanCanonicalize (H12AffineFastState.compose env3079 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3079 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env3080 : List Nat := [2,4,8,1,11,0,2,5,0,1024,1,1039,8,1038,0,8,1038,11,1025,0,1039,11,1,9,3,1,0,1038,1038,11,1024,1,4,0,1039,0]

theorem envBound3080 : H12AffineFastState.Bounded env3080 := by
  intro p hp
  have h : env3080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3079_3080 : H12AffineEnvironment.transform 8 0 env3079 = env3080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3079 == env3080) = true)

theorem identity3080 : scanCanonicalize (H12AffineFastState.compose env3080 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3081 : List Nat := [2,4,2,1,1,0,2,5,0,1024,1,1029,2,1028,0,2,1028,1,1025,0,1029,1,1,3,3,1,0,1028,1028,1,1024,1,4,0,1029,0]

theorem envBound3081 : H12AffineFastState.Bounded env3081 := by
  intro p hp
  have h : env3081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3080_3081 : H12AffineEnvironment.transform 2 2 env3080 = env3081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3080 == env3081) = true)

def env3082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914000,849104,16385,16892,547952,598058,12644669,525568,545873,8479126,8914924]

theorem envBound3082 : H12AffineFastState.Bounded env3082 := by
  intro p hp
  have h : env3082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2957_3082 : H12AffineEnvironment.transform 27 16385 env2957 = env3082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env2957 == env3082) = true)

def env3083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,12644669,256,20561,8479126,8389612]

theorem envBound3083 : H12AffineFastState.Bounded env3083 := by
  intro p hp
  have h : env3083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3082_3083 : H12AffineEnvironment.transform 18 1024 env3082 = env3083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3082 == env3083) = true)

theorem identity3083 : scanCanonicalize (H12AffineFastState.compose env3083 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240429) := by decide +kernel

theorem selectedBound3083 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,4240429,41002,8329,4240509,323792,16385,16892,22640,74794,17680,256,20561,4314555,4241345]

theorem envBound3084 : H12AffineFastState.Bounded env3084 := by
  intro p hp
  have h : env3084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3083_3084 : H12AffineEnvironment.transform 22 4240429 env3083 = env3084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240429 env3083 == env3084) = true)

def env3085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46528,493,41002,8329,445,323792,16385,16892,22640,74794,17680,256,20561,90235,513]

theorem envBound3085 : H12AffineFastState.Bounded env3085 := by
  intro p hp
  have h : env3085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3084_3085 : H12AffineEnvironment.transform 21 46528 env3084 = env3085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env3084 == env3085) = true)

theorem identity3085 : scanCanonicalize (H12AffineFastState.compose env3085 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3085 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3086 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,46480,445,41002,8329,445,323712,16385,16812,22560,74794,17680,256,20481,90155,513]

theorem envBound3086 : H12AffineFastState.Bounded env3086 := by
  intro p hp
  have h : env3086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3085_3086 : H12AffineEnvironment.transform 5 16 env3085 = env3086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3085 == env3086) = true)

theorem identity3086 : scanCanonicalize (H12AffineFastState.compose env3086 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound3086 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3087 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1024,32768,4096,46228,185,41002,8329,185,323712,16385,16552,22560,74794,17428,4,20481,90155,513]

theorem envBound3087 : H12AffineFastState.Bounded env3087 := by
  intro p hp
  have h : env3087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3086_3087 : H12AffineEnvironment.transform 7 4 env3086 = env3087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env3086 == env3087) = true)

theorem identity3087 : scanCanonicalize (H12AffineFastState.compose env3087 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound3087 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env3088 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4264,262144,1024,32768,4096,46228,185,41002,8329,185,323712,16385,16552,22560,16405,17428,4,20481,1044,513]

theorem envBound3088 : H12AffineFastState.Bounded env3088 := by
  intro p hp
  have h : env3088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3087_3088 : H12AffineEnvironment.transform 15 25663 env3087 = env3088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env3087 == env3088) = true)

theorem identity3088 : scanCanonicalize (H12AffineFastState.compose env3088 (packedSelected [1,2,5,10,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 43137) := by decide +kernel

theorem selectedBound3088 : packedSelected [1,2,5,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env3089 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4264,43137,1024,32768,4096,46228,185,41002,8329,185,22529,16385,16552,22560,16405,17428,4,20481,1044,513]

theorem envBound3089 : H12AffineFastState.Bounded env3089 := by
  intro p hp
  have h : env3089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3088_3089 : H12AffineEnvironment.transform 17 43137 env3088 = env3089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43137 env3088 == env3089) = true)

theorem identity3089 : scanCanonicalize (H12AffineFastState.compose env3089 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound3089 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env3090 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,8192,16384,32768,25663,1045,43137,1024,32768,1213,41001,185,41002,8329,185,19644,16385,16552,19613,16405,17428,4,17596,1044,513]

theorem envBound3090 : H12AffineFastState.Bounded env3090 := by
  intro p hp
  have h : env3090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3089_3090 : H12AffineEnvironment.transform 11 1213 env3089 = env3090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env3089 == env3090) = true)

theorem identity3090 : scanCanonicalize (H12AffineFastState.compose env3090 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 2179) := by decide +kernel

theorem selectedBound3090 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env3091 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,8192,2179,32768,11452,1045,43137,1024,32768,1213,41001,185,41002,8329,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3091 : H12AffineFastState.Bounded env3091 := by
  intro p hp
  have h : env3091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3090_3091 : H12AffineEnvironment.transform 13 2179 env3090 = env3091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2179 env3090 == env3091) = true)

theorem identity3091 : scanCanonicalize (H12AffineFastState.compose env3091 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 2569) := by decide +kernel

theorem selectedBound3091 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env3092 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,2569,2179,32768,1717,1045,33416,1024,32768,1213,35360,185,35363,2688,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3092 : H12AffineFastState.Bounded env3092 := by
  intro p hp
  have h : env3092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3091_3092 : H12AffineEnvironment.transform 12 2569 env3091 = env3092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2569 env3091 == env3092) = true)

theorem identity3092 : scanCanonicalize (H12AffineFastState.compose env3092 (packedSelected [1,3,6,13] rootPS)) = affineNative (2^(14+1) ^^^ 2728) := by decide +kernel

theorem selectedBound3092 : packedSelected [1,3,6,13] rootPS < 2^1333 := by decide +kernel

def env3093 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1213,2569,2179,2728,1717,1045,2080,1024,2728,1213,136,185,139,2688,185,1087,2178,2091,1054,2198,3223,4,3135,1044,513]

theorem envBound3093 : H12AffineFastState.Bounded env3093 := by
  intro p hp
  have h : env3093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3092_3093 : H12AffineEnvironment.transform 14 2728 env3092 = env3093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2728 env3092 == env3093) = true)

theorem identity3093 : scanCanonicalize (H12AffineFastState.compose env3093 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound3093 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env3094 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1598,1213,1079,1725,1174,1717,1045,1566,1024,1174,1213,136,185,139,1214,185,1087,1724,1557,1054,1704,681,4,513,1044,513]

theorem envBound3094 : H12AffineFastState.Bounded env3094 := by
  intro p hp
  have h : env3094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3093_3094 : H12AffineEnvironment.transform 10 1598 env3093 = env3094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env3093 == env3094) = true)

theorem identity3094 : scanCanonicalize (H12AffineFastState.compose env3094 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound3094 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env3095 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1207,1213,1079,1076,1174,1084,1045,1175,1024,1174,1213,136,185,139,1214,185,1087,1077,1180,1054,1057,32,4,136,1044,136]

theorem envBound3095 : H12AffineFastState.Bounded env3095 := by
  intro p hp
  have h : env3095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3094_3095 : H12AffineEnvironment.transform 8 137 env3094 = env3095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env3094 == env3095) = true)

theorem identity3095 : scanCanonicalize (H12AffineFastState.compose env3095 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3095 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3096 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1055,1045,1079,1076,1086,1084,1045,1087,1024,1086,1045,32,17,35,1046,17,1087,1077,1076,1054,1057,32,4,32,1044,32]

theorem envBound3096 : H12AffineFastState.Bounded env3096 := by
  intro p hp
  have h : env3096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3095_3096 : H12AffineEnvironment.transform 6 40 env3095 = env3096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3095 == env3096) = true)

theorem identity3096 : scanCanonicalize (H12AffineFastState.compose env3096 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3097 : List Nat := [2,4,8,16,32,16,40,4,33,14,17,27,57,58,48,50,27,49,14,48,27,32,17,35,24,17,49,59,58,16,47,32,4,32,26,32]

theorem envBound3097 : H12AffineFastState.Bounded env3097 := by
  intro p hp
  have h : env3097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3096_3097 : H12AffineEnvironment.transform 9 14 env3096 = env3097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3096 == env3097) = true)

theorem identity3097 : scanCanonicalize (H12AffineFastState.compose env3097 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound3097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3098 : List Nat := [2,4,8,16,4,16,12,4,5,14,17,27,29,30,20,22,27,21,14,20,27,4,17,7,24,17,21,31,30,16,11,4,4,4,26,4]

theorem envBound3098 : H12AffineFastState.Bounded env3098 := by
  intro p hp
  have h : env3098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3097_3098 : H12AffineEnvironment.transform 4 4 env3097 = env3098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env3097 == env3098) = true)

theorem identity3098 : scanCanonicalize (H12AffineFastState.compose env3098 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound3098 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env3099 : List Nat := [2,4,8,11,4,11,12,4,5,14,10,0,6,5,15,13,0,14,14,15,0,4,10,7,3,10,14,4,5,11,11,4,4,4,1,4]

theorem envBound3099 : H12AffineFastState.Bounded env3099 := by
  intro p hp
  have h : env3099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3098_3099 : H12AffineEnvironment.transform 3 11 env3098 = env3099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env3098 == env3099) = true)

theorem identity3099 : scanCanonicalize (H12AffineFastState.compose env3099 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound3099 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env3100 : List Nat := [2,4,3,0,4,0,7,4,5,5,1,0,6,5,4,6,0,5,5,4,0,4,1,7,3,1,5,4,5,0,0,4,4,4,1,4]

theorem envBound3100 : H12AffineFastState.Bounded env3100 := by
  intro p hp
  have h : env3100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3099_3100 : H12AffineEnvironment.transform 2 3 env3099 = env3100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env3099 == env3100) = true)

def leafEnv3100 : List Nat := [2,4,3,0,4,0,7,4,5,5,1,0,6,5,4,6,0,5,5,4,0,4,1,7,1,3,1,1,5,4,5,0,0,4,4,4,5,2,1,4,1,5,0]

def active3100 : List Nat := [0,1]

def tree3100 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3100 : H12WitnessSearch.Good tree3100 := H12GlobalWitnessIndex.good

theorem leafIdentity3100 : H12AffineFastState.composeSystem env3100 rootObs = leafEnv3100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3100 rootObs == leafEnv3100) = true)

theorem terminalChecked3100 : H12PackedTerminal.terminalCheckFast leafEnv3100 active3100 tree3100 = true := by decide +kernel

def env3101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,46529,492,41002,8329,444,323792,16385,16892,22640,74794,17680,256,20561,90234,512]

theorem envBound3101 : H12AffineFastState.Bounded env3101 := by
  intro p hp
  have h : env3101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3084_3101 : H12AffineEnvironment.transform 21 46529 env3084 = env3101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env3084 == env3101) = true)

theorem identity3101 : scanCanonicalize (H12AffineFastState.compose env3101 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound3101 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,65536,1465,262144,1024,32768,1093,41348,492,41002,8329,444,320661,16385,16892,19509,74794,17680,256,17428,90234,512]

theorem envBound3102 : H12AffineFastState.Bounded env3102 := by
  intro p hp
  have h : env3102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3101_3102 : H12AffineEnvironment.transform 11 1093 env3101 = env3102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env3101 == env3102) = true)

theorem identity3102 : scanCanonicalize (H12AffineFastState.compose env3102 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33790) := by decide +kernel

theorem selectedBound3102 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,33790,1465,262144,1024,32768,1093,41348,492,41002,8329,444,320661,16385,16892,19509,42964,17680,256,17428,58244,512]

theorem envBound3103 : H12AffineFastState.Bounded env3103 := by
  intro p hp
  have h : env3103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3102_3103 : H12AffineEnvironment.transform 15 33790 env3102 = env3103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33790 env3102 == env3103) = true)

theorem identity3103 : scanCanonicalize (H12AffineFastState.compose env3103 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 26424) := by decide +kernel

theorem selectedBound3103 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26424,25798,1465,262144,1024,26424,1093,18108,492,18194,8329,444,263085,16385,16892,19509,16620,17680,256,17428,1212,512]

theorem envBound3104 : H12AffineFastState.Bounded env3104 := by
  intro p hp
  have h : env3104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3103_3104 : H12AffineEnvironment.transform 14 26424 env3103 = env3104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26424 env3103 == env3104) = true)

def env3105 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,1093,8192,16384,26424,25662,1345,262144,1024,26424,1093,17988,276,18194,8305,324,262997,16385,16644,19509,16404,17680,256,17428,1092,512]

theorem envBound3105 : H12AffineFastState.Bounded env3105 := by
  intro p hp
  have h : env3105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3104_3105 : H12AffineEnvironment.transform 6 120 env3104 = env3105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env3104 == env3105) = true)

theorem identity3105 : scanCanonicalize (H12AffineFastState.compose env3105 (packedSelected [0,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3105 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env3106 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,1093,8192,16384,26173,25662,1092,262144,1024,26173,1093,17988,17,17943,8305,65,262736,16385,16385,19509,16404,17429,5,17428,1092,512]

theorem envBound3106 : H12AffineFastState.Bounded env3106 := by
  intro p hp
  have h : env3106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3105_3106 : H12AffineEnvironment.transform 7 5 env3105 = env3106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3105 == env3106) = true)

theorem identity3106 : scanCanonicalize (H12AffineFastState.compose env3106 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16411) := by decide +kernel

theorem selectedBound3106 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3107 : List Nat := [2,4,8,16,32,64,120,5,512,1024,2048,1093,8192,16384,26173,25662,1092,16411,1024,26173,1093,17988,17,17943,8305,65,16971,16385,16385,19509,16404,17429,5,17428,1092,512]

theorem envBound3107 : H12AffineFastState.Bounded env3107 := by
  intro p hp
  have h : env3107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3106_3107 : H12AffineEnvironment.transform 17 16411 env3106 = env3107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16411 env3106 == env3107) = true)

theorem identity3107 : scanCanonicalize (H12AffineFastState.compose env3107 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound3107 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3108 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,16384,26173,25662,1044,16411,1024,26173,1045,17940,17,17943,8225,17,16923,16385,16385,19509,16404,17429,5,17428,1044,512]

theorem envBound3108 : H12AffineFastState.Bounded env3108 := by
  intro p hp
  have h : env3108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3107_3108 : H12AffineEnvironment.transform 5 16 env3107 = env3108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3107 == env3108) = true)

theorem identity3108 : scanCanonicalize (H12AffineFastState.compose env3108 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 11804) := by decide +kernel

theorem selectedBound3108 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env3109 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,8192,11804,2081,2594,1044,11783,1024,2081,1045,10248,17,10251,8225,17,11271,11805,11805,8745,11784,10761,5,10760,1044,512]

theorem envBound3109 : H12AffineFastState.Bounded env3109 := by
  intro p hp
  have h : env3109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3108_3109 : H12AffineEnvironment.transform 13 11804 env3108 = env3109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11804 env3108 == env3109) = true)

theorem identity3109 : scanCanonicalize (H12AffineFastState.compose env3109 (packedSelected [0,2,3,12] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound3109 : packedSelected [0,2,3,12] rootPS < 2^1333 := by decide +kernel

def env3110 : List Nat := [2,4,8,16,32,16,40,5,512,1024,2048,1045,1564,2048,2081,2594,1044,2075,1024,2081,1045,3604,17,3607,1597,17,2587,2049,2049,1077,2068,3093,5,3092,1044,512]

theorem envBound3110 : H12AffineFastState.Bounded env3110 := by
  intro p hp
  have h : env3110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3109_3110 : H12AffineEnvironment.transform 12 1564 env3109 = env3110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env3109 == env3110) = true)

theorem identity3110 : scanCanonicalize (H12AffineFastState.compose env3110 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound3110 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3111 : List Nat := [2,4,8,16,32,16,40,5,59,1024,2048,1045,1063,2048,2081,2073,1044,2075,1024,2081,1045,3119,17,3116,1030,17,2080,2049,2049,1077,2068,3093,5,3092,1044,59]

theorem envBound3111 : H12AffineFastState.Bounded env3111 := by
  intro p hp
  have h : env3111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3110_3111 : H12AffineEnvironment.transform 8 59 env3110 = env3111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env3110 == env3111) = true)

theorem identity3111 : scanCanonicalize (H12AffineFastState.compose env3111 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound3111 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env3112 : List Nat := [2,4,8,16,32,16,40,5,59,1024,1038,1045,1063,1038,1071,1047,1044,1045,1024,1071,1045,33,17,34,1030,17,1070,1039,1039,1077,1050,27,5,26,1044,59]

theorem envBound3112 : H12AffineFastState.Bounded env3112 := by
  intro p hp
  have h : env3112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3111_3112 : H12AffineEnvironment.transform 10 1038 env3111 = env3112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env3111 == env3112) = true)

theorem identity3112 : scanCanonicalize (H12AffineFastState.compose env3112 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3113 : List Nat := [2,4,8,16,26,16,18,5,1,1024,1038,1045,1053,1038,1045,1047,1044,1045,1024,1045,1045,27,17,24,1030,17,1044,1039,1039,1039,1050,27,5,26,1044,1]

theorem envBound3113 : H12AffineFastState.Bounded env3113 := by
  intro p hp
  have h : env3113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3112_3113 : H12AffineEnvironment.transform 4 26 env3112 = env3113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3112 == env3113) = true)

theorem identity3113 : scanCanonicalize (H12AffineFastState.compose env3113 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound3113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3114 : List Nat := [2,4,8,16,26,16,18,5,1,14,0,27,19,0,27,25,26,27,14,27,27,27,17,24,8,17,26,1,1,1,20,27,5,26,26,1]

theorem envBound3114 : H12AffineFastState.Bounded env3114 := by
  intro p hp
  have h : env3114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3113_3114 : H12AffineEnvironment.transform 9 14 env3113 = env3114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env3113 == env3114) = true)

theorem identity3114 : scanCanonicalize (H12AffineFastState.compose env3114 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound3114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3115 : List Nat := [2,4,8,10,0,10,8,5,1,14,0,1,9,0,1,3,0,1,14,1,1,1,11,2,8,11,0,1,1,1,14,1,5,0,0,1]

theorem envBound3115 : H12AffineFastState.Bounded env3115 := by
  intro p hp
  have h : env3115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3114_3115 : H12AffineEnvironment.transform 3 10 env3114 = env3115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env3114 == env3115) = true)

def env3116 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,1093,8192,16384,26424,25663,1344,262144,1024,26424,1093,17989,277,18194,8304,325,262996,16385,16645,19509,16405,17680,256,17428,1093,512]

theorem envBound3116 : H12AffineFastState.Bounded env3116 := by
  intro p hp
  have h : env3116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3104_3116 : H12AffineEnvironment.transform 6 121 env3104 = env3116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env3104 == env3116) = true)

def env3117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,12644669,257,20560,8479126,8389613]

theorem envBound3117 : H12AffineFastState.Bounded env3117 := by
  intro p hp
  have h : env3117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3082_3117 : H12AffineEnvironment.transform 18 1025 env3082 = env3117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env3082 == env3117) = true)

theorem identity3117 : scanCanonicalize (H12AffineFastState.compose env3117 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61741) := by decide +kernel

theorem selectedBound3117 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,61741,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,8388624,257,20560,8479126,8389613]

theorem envBound3118 : H12AffineFastState.Bounded env3118 := by
  intro p hp
  have h : env3118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3117_3118 : H12AffineEnvironment.transform 21 61741 env3117 = env3118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61741 env3117 == env3118) = true)

def env3119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61741,8388608,41002,8329,8388609,323713,16385,16812,22561,74795,8388624,257,20480,8479126,8389565]

theorem envBound3119 : H12AffineFastState.Bounded env3119 := by
  intro p hp
  have h : env3119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3118_3119 : H12AffineEnvironment.transform 5 16 env3118 = env3119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3118 == env3119) = true)

theorem identity3119 : scanCanonicalize (H12AffineFastState.compose env3119 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound3119 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,61741,445,41002,8329,444,323713,16385,16812,22561,74795,429,257,20480,90155,512]

theorem envBound3120 : H12AffineFastState.Bounded env3120 := by
  intro p hp
  have h : env3120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3119_3120 : H12AffineEnvironment.transform 22 445 env3119 = env3120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env3119 == env3120) = true)

theorem identity3120 : scanCanonicalize (H12AffineFastState.compose env3120 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3120 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1025,32768,4096,41349,445,41002,8329,444,303145,4265,4356,2185,74795,429,257,168,77955,512]

theorem envBound3121 : H12AffineFastState.Bounded env3121 := by
  intro p hp
  have h : env3121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3120_3121 : H12AffineEnvironment.transform 13 4264 env3120 = env3121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3120 == env3121) = true)

theorem identity3121 : scanCanonicalize (H12AffineFastState.compose env3121 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38843) := by decide +kernel

theorem selectedBound3121 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,38843,4524,262144,1025,32768,4096,41349,445,41002,8329,444,303145,4265,4356,2185,45968,429,257,168,42808,512]

theorem envBound3122 : H12AffineFastState.Bounded env3122 := by
  intro p hp
  have h : env3122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3121_3122 : H12AffineEnvironment.transform 15 38843 env3121 = env3122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38843 env3121 == env3122) = true)

theorem identity3122 : scanCanonicalize (H12AffineFastState.compose env3122 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3122 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8235,4524,262144,1025,14224,4096,5653,445,6074,8329,444,268217,4265,4356,2185,1024,429,257,168,4264,512]

theorem envBound3123 : H12AffineFastState.Bounded env3123 := by
  intro p hp
  have h : env3123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3122_3123 : H12AffineEnvironment.transform 14 14224 env3122 = env3123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3122 == env3123) = true)

theorem identity3123 : scanCanonicalize (H12AffineFastState.compose env3123 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2444) := by decide +kernel

theorem selectedBound3123 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8235,4524,2444,1025,14224,4096,5653,445,6074,8329,444,7733,4265,4356,2185,1024,429,257,168,4264,512]

theorem envBound3124 : H12AffineFastState.Bounded env3124 := by
  intro p hp
  have h : env3124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3123_3124 : H12AffineEnvironment.transform 17 2444 env3123 = env3124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2444 env3123 == env3124) = true)

theorem identity3124 : scanCanonicalize (H12AffineFastState.compose env3124 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound3124 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env3125 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4264,13884,8235,4096,2080,1025,13884,4096,5653,17,5654,8329,16,7733,4265,4264,2185,1024,1,173,168,4264,512]

theorem envBound3125 : H12AffineFastState.Bounded env3125 := by
  intro p hp
  have h : env3125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3124_3125 : H12AffineEnvironment.transform 7 172 env3124 = env3125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env3124 == env3125) = true)

theorem identity3125 : scanCanonicalize (H12AffineFastState.compose env3125 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound3125 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env3126 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,4096,8192,4264,13884,8235,4096,643,1025,13884,4096,5653,17,5654,8329,16,5270,4265,4264,554,1024,1,173,168,4264,512]

theorem envBound3126 : H12AffineFastState.Bounded env3126 := by
  intro p hp
  have h : env3126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3125_3126 : H12AffineEnvironment.transform 10 675 env3125 = env3126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env3125 == env3126) = true)

theorem identity3126 : scanCanonicalize (H12AffineFastState.compose env3126 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound3126 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3127 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,1693,8192,1589,8353,8235,1693,643,1025,8353,1693,136,17,139,8329,16,523,1588,1589,554,1024,1,173,168,1589,512]

theorem envBound3127 : H12AffineFastState.Bounded env3127 := by
  intro p hp
  have h : env3127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3126_3127 : H12AffineEnvironment.transform 11 1693 env3126 = env3127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env3126 == env3127) = true)

theorem identity3127 : scanCanonicalize (H12AffineFastState.compose env3127 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound3127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3128 : List Nat := [2,4,8,16,32,16,128,172,512,1024,675,1693,18,1589,179,57,1693,643,1025,179,1693,136,17,139,155,16,523,1588,1589,554,1024,1,173,168,1589,512]

theorem envBound3128 : H12AffineFastState.Bounded env3128 := by
  intro p hp
  have h : env3128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3127_3128 : H12AffineEnvironment.transform 12 18 env3127 = env3128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env3127 == env3128) = true)

theorem identity3128 : scanCanonicalize (H12AffineFastState.compose env3128 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3128 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env3129 : List Nat := [2,4,8,16,32,16,40,4,512,1024,523,1589,18,1589,27,57,1589,555,1025,27,1589,32,17,35,51,16,523,1588,1589,554,1024,1,5,0,1589,512]

theorem envBound3129 : H12AffineFastState.Bounded env3129 := by
  intro p hp
  have h : env3129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3128_3129 : H12AffineEnvironment.transform 6 40 env3128 = env3129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3128 == env3129) = true)

theorem identity3129 : scanCanonicalize (H12AffineFastState.compose env3129 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound3129 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env3130 : List Nat := [2,4,8,16,16,16,24,4,512,1024,523,1541,18,1541,27,9,1541,539,1025,27,1541,16,17,19,3,16,523,1540,1541,538,1024,1,5,0,1541,512]

theorem envBound3130 : H12AffineFastState.Bounded env3130 := by
  intro p hp
  have h : env3130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3129_3130 : H12AffineEnvironment.transform 4 16 env3129 = env3130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env3129 == env3130) = true)

theorem identity3130 : scanCanonicalize (H12AffineFastState.compose env3130 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3130 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env3131 : List Nat := [2,4,2,16,16,16,18,4,512,1024,513,1541,18,1541,17,3,1541,529,1025,17,1541,16,17,19,3,16,513,1540,1541,528,1024,1,5,0,1541,512]

theorem envBound3131 : H12AffineFastState.Bounded env3131 := by
  intro p hp
  have h : env3131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3130_3131 : H12AffineEnvironment.transform 2 2 env3130 = env3131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3130 == env3131) = true)

theorem identity3131 : scanCanonicalize (H12AffineFastState.compose env3131 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound3131 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env3132 : List Nat := [2,4,2,0,0,0,2,4,512,1024,513,1541,2,1541,1,3,1541,513,1025,1,1541,0,1,3,3,0,513,1540,1541,512,1024,1,5,0,1541,512]

theorem envBound3132 : H12AffineFastState.Bounded env3132 := by
  intro p hp
  have h : env3132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3131_3132 : H12AffineEnvironment.transform 3 0 env3131 = env3132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3131 == env3132) = true)

theorem identity3132 : scanCanonicalize (H12AffineFastState.compose env3132 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3133 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,2,1029,1,3,1029,1,1025,1,1029,0,1,3,3,0,1,1028,1029,0,1024,1,5,0,1029,0]

theorem envBound3133 : H12AffineFastState.Bounded env3133 := by
  intro p hp
  have h : env3133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3132_3133 : H12AffineEnvironment.transform 8 0 env3132 = env3133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3132 == env3133) = true)

def leafEnv3133 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,2,1029,1,3,1029,1,1025,1,1029,0,1,3,1025,3,1,0,1,1028,1029,0,1024,1,5,0,5,3,1029,0,1,1028,0]

def active3133 : List Nat := [0,1,9]

def tree3133 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3133 : H12WitnessSearch.Good tree3133 := H12GlobalWitnessIndex.good

theorem leafIdentity3133 : H12AffineFastState.composeSystem env3133 rootObs = leafEnv3133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3133 rootObs == leafEnv3133) = true)

theorem terminalChecked3133 : H12PackedTerminal.terminalCheckFast leafEnv3133 active3133 tree3133 = true := by decide +kernel

def env3134 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,61741,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3134 : H12AffineFastState.Bounded env3134 := by
  intro p hp
  have h : env3134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3118_3134 : H12AffineEnvironment.transform 5 17 env3118 = env3134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3118 == env3134) = true)

def env3135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,262144,1025,8352,4096,20877,8388608,138,8329,8388608,282656,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3135 : H12AffineFastState.Bounded env3135 := by
  intro p hp
  have h : env3135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3134_3135 : H12AffineEnvironment.transform 14 8352 env3134 = env3135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env3134 == env3135) = true)

theorem identity3135 : scanCanonicalize (H12AffineFastState.compose env3135 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound3135 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3136 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,96267,1025,8352,4096,20877,8388608,138,8329,8388608,75819,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3136 : H12AffineFastState.Bounded env3136 := by
  intro p hp
  have h : env3136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3135_3136 : H12AffineEnvironment.transform 17 96267 env3135 = env3136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env3135 == env3136) = true)

theorem identity3136 : scanCanonicalize (H12AffineFastState.compose env3136 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 28714) := by decide +kernel

theorem selectedBound3136 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env3137 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,28714,4525,2081,1025,8352,4096,20877,8388608,138,8329,8388608,22529,16385,16813,22560,21505,8388624,257,20481,8393148,8389564]

theorem envBound3137 : H12AffineFastState.Bounded env3137 := by
  intro p hp
  have h : env3137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3136_3137 : H12AffineEnvironment.transform 15 28714 env3136 = env3137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28714 env3136 == env3137) = true)

theorem identity3137 : scanCanonicalize (H12AffineFastState.compose env3137 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 7947) := by decide +kernel

theorem selectedBound3137 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env3138 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,7947,8352,12065,4525,2081,1025,8352,4096,3718,8388608,138,8329,8388608,1802,7946,7846,1835,2826,8388624,257,3850,8393148,8389564]

theorem envBound3138 : H12AffineFastState.Bounded env3138 := by
  intro p hp
  have h : env3138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3137_3138 : H12AffineEnvironment.transform 13 7947 env3137 = env3138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7947 env3137 == env3138) = true)

theorem identity3138 : scanCanonicalize (H12AffineFastState.compose env3138 (packedSelected [4,9,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound3138 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env3139 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,7694,8352,11812,4264,2081,1025,8352,4096,3718,8388608,138,8329,8388608,1551,7695,7846,1582,2575,8388624,4,3599,8392889,8389305]

theorem envBound3139 : H12AffineFastState.Bounded env3139 := by
  intro p hp
  have h : env3139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3138_3139 : H12AffineEnvironment.transform 7 5 env3138 = env3139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env3138 == env3139) = true)

theorem identity3139 : scanCanonicalize (H12AffineFastState.compose env3139 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound3139 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env3140 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7694,8200,11812,4096,2081,1025,8200,4096,3630,8388608,34,8225,8388608,1551,7695,7694,1582,2575,8388624,4,3599,8392721,8389137]

theorem envBound3140 : H12AffineFastState.Bounded env3140 := by
  intro p hp
  have h : env3140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3139_3140 : H12AffineEnvironment.transform 6 40 env3139 = env3140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env3139 == env3140) = true)

theorem identity3140 : scanCanonicalize (H12AffineFastState.compose env3140 (packedSelected [2,6] rootPS)) = affineNative (2^(22+1) ^^^ 3621) := by decide +kernel

theorem selectedBound3140 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env3141 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7694,8200,11812,4096,2081,1025,8200,4096,3630,3621,34,8225,3621,1551,7695,7694,1582,2575,3637,4,3599,7732,3124]

theorem envBound3141 : H12AffineFastState.Bounded env3141 := by
  intro p hp
  have h : env3141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3140_3141 : H12AffineEnvironment.transform 22 3621 env3140 = env3141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 3621 env3140 == env3141) = true)

theorem identity3141 : scanCanonicalize (H12AffineFastState.compose env3141 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound3141 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3142 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,8192,2106,8200,11812,1588,2081,1025,8200,1588,3630,3621,34,8225,3621,1551,2107,2106,1582,2575,3637,4,3599,2048,3124]

theorem envBound3142 : H12AffineFastState.Bounded env3142 := by
  intro p hp
  have h : env3142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3141_3142 : H12AffineEnvironment.transform 11 1588 env3141 = env3142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env3141 == env3142) = true)

theorem identity3142 : scanCanonicalize (H12AffineFastState.compose env3142 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound3142 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env3143 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1076,1588,8192,1038,8200,8720,1588,1045,1025,8200,1588,538,529,34,8225,529,1551,1039,1038,1582,1595,513,4,571,1076,0]

theorem envBound3143 : H12AffineFastState.Bounded env3143 := by
  intro p hp
  have h : env3143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3142_3143 : H12AffineEnvironment.transform 10 1076 env3142 = env3143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env3142 == env3143) = true)

theorem identity3143 : scanCanonicalize (H12AffineFastState.compose env3143 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound3143 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env3144 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1076,1588,1053,1038,1045,1549,1588,1045,1025,1045,1588,538,529,34,1084,529,1551,1039,1038,1582,1595,513,4,571,1076,0]

theorem envBound3144 : H12AffineFastState.Bounded env3144 := by
  intro p hp
  have h : env3144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3143_3144 : H12AffineEnvironment.transform 12 1053 env3143 = env3144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env3143 == env3144) = true)

theorem identity3144 : scanCanonicalize (H12AffineFastState.compose env3144 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3144 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env3145 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1038,1550,1053,1038,1045,1549,1550,1045,1025,1045,1550,538,529,24,1030,529,1551,1039,1038,1556,1537,513,4,513,1038,0]

theorem envBound3145 : H12AffineFastState.Bounded env3145 := by
  intro p hp
  have h : env3145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3144_3145 : H12AffineEnvironment.transform 4 26 env3144 = env3145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3144 == env3145) = true)

theorem identity3145 : scanCanonicalize (H12AffineFastState.compose env3145 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound3145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3146 : List Nat := [2,4,8,16,26,17,18,5,512,15,1,513,18,1,26,514,513,26,14,26,513,538,529,24,9,529,512,0,1,539,526,513,4,513,1,0]

theorem envBound3146 : H12AffineFastState.Bounded env3146 := by
  intro p hp
  have h : env3146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3145_3146 : H12AffineEnvironment.transform 9 15 env3145 = env3146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env3145 == env3146) = true)

def env3147 : List Nat := [2,4,8,16,26,17,18,5,0,15,1,1,18,1,26,2,1,26,14,26,1,26,17,24,9,17,0,0,1,27,14,1,4,1,1,0]

theorem envBound3147 : H12AffineFastState.Bounded env3147 := by
  intro p hp
  have h : env3147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3146_3147 : H12AffineEnvironment.transform 8 0 env3146 = env3147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3146 == env3147) = true)

def env3148 : List Nat := [2,4,8,16,26,17,18,5,1,15,1,0,18,1,26,3,0,26,14,26,0,27,16,24,9,16,1,0,1,26,15,0,4,0,1,0]

theorem envBound3148 : H12AffineFastState.Bounded env3148 := by
  intro p hp
  have h : env3148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3146_3148 : H12AffineEnvironment.transform 8 1 env3146 = env3148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env3146 == env3148) = true)

theorem identity3148 : scanCanonicalize (H12AffineFastState.compose env3148 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound3148 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env3149 : List Nat := [2,4,8,5,15,4,7,5,1,15,1,0,7,1,15,3,0,15,14,15,0,14,5,13,9,5,1,0,1,15,15,0,4,0,1,0]

theorem envBound3149 : H12AffineFastState.Bounded env3149 := by
  intro p hp
  have h : env3149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3148_3149 : H12AffineEnvironment.transform 3 5 env3148 = env3149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env3148 == env3149) = true)

theorem identity3149 : scanCanonicalize (H12AffineFastState.compose env3149 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound3149 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env3150 : List Nat := [2,0,8,1,11,0,3,1,1,11,1,0,3,1,11,3,0,11,10,11,0,10,1,9,9,1,1,0,1,11,11,0,0,0,1,0]

theorem envBound3150 : H12AffineFastState.Bounded env3150 := by
  intro p hp
  have h : env3150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3149_3150 : H12AffineEnvironment.transform 1 0 env3149 = env3150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env3149 == env3150) = true)

def leafEnv3150 : List Nat := [2,0,8,1,11,0,3,1,1,11,1,0,3,1,11,3,0,11,10,11,0,10,1,9,10,9,1,1,1,0,1,11,11,0,0,0,1,9,1,0,1,0,0]

def active3150 : List Nat := [0,2]

def tree3150 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3150 : H12WitnessSearch.Good tree3150 := H12GlobalWitnessIndex.good

theorem leafIdentity3150 : H12AffineFastState.composeSystem env3150 rootObs = leafEnv3150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3150 rootObs == leafEnv3150) = true)

theorem terminalChecked3150 : H12PackedTerminal.terminalCheckFast leafEnv3150 active3150 tree3150 = true := by decide +kernel

def env3151 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,262144,1025,8353,4096,20876,8388608,139,8329,8388608,282657,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3151 : H12AffineFastState.Bounded env3151 := by
  intro p hp
  have h : env3151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3134_3151 : H12AffineEnvironment.transform 14 8353 env3134 = env3151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env3134 == env3151) = true)

theorem identity3151 : scanCanonicalize (H12AffineFastState.compose env3151 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 96527) := by decide +kernel

theorem selectedBound3151 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env3152 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,96527,1025,8353,4096,20876,8388608,139,8329,8388608,76078,16385,16813,22560,74795,8388624,257,20481,8479126,8389564]

theorem envBound3152 : H12AffineFastState.Bounded env3152 := by
  intro p hp
  have h : env3152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3151_3152 : H12AffineEnvironment.transform 17 96527 env3151 = env3152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96527 env3151 == env3152) = true)

theorem identity3152 : scanCanonicalize (H12AffineFastState.compose env3152 (packedSelected [1,3,7,13,20,21,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound3152 : packedSelected [1,3,7,13,20,21,24,27,28] rootPS < 2^1333 := by decide +kernel

def env3153 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,96527,1025,8353,4096,20876,20925,139,8329,20925,76078,16385,16813,22560,74795,20909,257,20481,77867,20993]

theorem envBound3153 : H12AffineFastState.Bounded env3153 := by
  intro p hp
  have h : env3153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3152_3153 : H12AffineEnvironment.transform 22 20925 env3152 = env3153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env3152 == env3153) = true)

theorem identity3153 : scanCanonicalize (H12AffineFastState.compose env3153 (packedSelected [4,9,11,13,18,20,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound3153 : packedSelected [4,9,11,13,18,20,21,23,32] rootPS < 2^1333 := by decide +kernel

def env3154 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,29063,4525,2184,1025,8353,4096,20876,20925,139,8329,20925,22697,16385,16813,22560,21932,20909,257,20481,16812,20993]

theorem envBound3154 : H12AffineFastState.Bounded env3154 := by
  intro p hp
  have h : env3154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3153_3154 : H12AffineEnvironment.transform 15 29063 env3153 = env3154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env3153 == env3154) = true)

theorem identity3154 : scanCanonicalize (H12AffineFastState.compose env3154 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 10155) := by decide +kernel

theorem selectedBound3154 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env3155 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,10155,8353,5676,4525,2184,1025,8353,4096,13863,13846,139,8329,13846,16130,10154,9734,16267,12807,13830,257,14250,9735,13738]

theorem envBound3155 : H12AffineFastState.Bounded env3155 := by
  intro p hp
  have h : env3155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3154_3155 : H12AffineEnvironment.transform 13 10155 env3154 = env3155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10155 env3154 == env3155) = true)

theorem identity3155 : scanCanonicalize (H12AffineFastState.compose env3155 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound3155 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env3156 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,9751,8353,5676,4113,2184,1025,8353,4096,13863,13846,139,8329,13846,16062,9750,9734,15927,12807,13830,189,13846,9735,13334]

theorem envBound3156 : H12AffineFastState.Bounded env3156 := by
  intro p hp
  have h : env3156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3155_3156 : H12AffineEnvironment.transform 7 188 env3155 = env3156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env3155 == env3156) = true)

theorem identity3156 : scanCanonicalize (H12AffineFastState.compose env3156 (packedSelected [0,1,2,5,6,7,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound3156 : packedSelected [0,1,2,5,6,7,10,13] rootPS < 2^1333 := by decide +kernel

def env3157 : List Nat := [2,4,8,16,32,17,128,188,512,1024,561,4096,8192,9751,8353,5676,4113,697,1025,8353,4096,13863,13846,139,8329,13846,13455,9750,9734,13318,12807,13830,189,13846,9735,13334]

theorem envBound3157 : H12AffineFastState.Bounded env3157 := by
  intro p hp
  have h : env3157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3156_3157 : H12AffineEnvironment.transform 10 561 env3156 = env3157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env3156 == env3157) = true)

theorem identity3157 : scanCanonicalize (H12AffineFastState.compose env3157 (packedSelected [0,1,2,3,6,7,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound3157 : packedSelected [0,1,2,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env3158 : List Nat := [2,4,8,16,32,17,128,188,512,1024,561,4096,177,1702,16,5676,4113,697,1025,16,4096,5782,5799,139,56,5799,5182,1703,1719,5303,4790,5815,189,5799,1718,5287]

theorem envBound3158 : H12AffineFastState.Bounded env3158 := by
  intro p hp
  have h : env3158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3157_3158 : H12AffineEnvironment.transform 12 177 env3157 = env3158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env3157 == env3158) = true)

theorem identity3158 : scanCanonicalize (H12AffineFastState.compose env3158 (packedSelected [0,1,2,5,6,7,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound3158 : packedSelected [0,1,2,5,6,7,10,17] rootPS < 2^1333 := by decide +kernel

def env3159 : List Nat := [2,4,8,16,32,17,128,188,512,1024,561,1550,177,1702,16,34,1567,697,1025,16,1550,152,169,139,56,169,560,1703,1719,697,1208,185,189,169,1718,681]

theorem envBound3159 : H12AffineFastState.Bounded env3159 := by
  intro p hp
  have h : env3159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3158_3159 : H12AffineEnvironment.transform 11 1550 env3158 = env3159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env3158 == env3159) = true)

theorem identity3159 : scanCanonicalize (H12AffineFastState.compose env3159 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound3159 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env3160 : List Nat := [2,4,8,16,27,17,128,135,512,1024,522,1550,138,1693,16,25,1567,642,1025,16,1550,152,146,139,3,146,523,1692,1676,642,1155,130,134,146,1677,658]

theorem envBound3160 : H12AffineFastState.Bounded env3160 := by
  intro p hp
  have h : env3160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3159_3160 : H12AffineEnvironment.transform 4 27 env3159 = env3160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env3159 == env3160) = true)

theorem identity3160 : scanCanonicalize (H12AffineFastState.compose env3160 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound3160 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env3161 : List Nat := [2,4,8,1,10,0,128,135,512,1024,522,1550,138,1676,1,8,1550,642,1025,1,1550,137,131,139,3,131,523,1677,1676,642,1155,130,134,131,1677,643]

theorem envBound3161 : H12AffineFastState.Bounded env3161 := by
  intro p hp
  have h : env3161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3160_3161 : H12AffineEnvironment.transform 3 1 env3160 = env3161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env3160 == env3161) = true)

theorem identity3161 : scanCanonicalize (H12AffineFastState.compose env3161 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound3161 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env3162 : List Nat := [2,4,8,1,10,0,9,14,512,1024,522,1550,3,1541,1,8,1550,523,1025,1,1550,0,10,2,3,10,523,1540,1541,523,1034,11,15,10,1540,522]

theorem envBound3162 : H12AffineFastState.Bounded env3162 := by
  intro p hp
  have h : env3162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3161_3162 : H12AffineEnvironment.transform 6 9 env3161 = env3162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env3161 == env3162) = true)

theorem identity3162 : scanCanonicalize (H12AffineFastState.compose env3162 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound3162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env3163 : List Nat := [2,4,2,1,0,0,3,4,512,1024,512,1540,3,1541,1,2,1540,513,1025,1,1540,0,0,2,3,0,513,1540,1541,513,1024,1,5,0,1540,512]

theorem envBound3163 : H12AffineFastState.Bounded env3163 := by
  intro p hp
  have h : env3163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3162_3163 : H12AffineEnvironment.transform 2 2 env3162 = env3163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env3162 == env3163) = true)

theorem identity3163 : scanCanonicalize (H12AffineFastState.compose env3163 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound3163 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env3164 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1028,3,1029,1,2,1028,1,1025,1,1028,0,0,2,3,0,1,1028,1029,1,1024,1,5,0,1028,0]

theorem envBound3164 : H12AffineFastState.Bounded env3164 := by
  intro p hp
  have h : env3164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3163_3164 : H12AffineEnvironment.transform 8 0 env3163 = env3164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env3163 == env3164) = true)

def leafEnv3164 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1028,3,1029,1,2,1028,1,1025,1,1028,0,0,2,1025,3,1,0,1,1028,1029,1,1024,1,5,0,5,3,1028,0,1,1028,0]

def active3164 : List Nat := [0,1,9]

def tree3164 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood3164 : H12WitnessSearch.Good tree3164 := H12GlobalWitnessIndex.good

theorem leafIdentity3164 : H12AffineFastState.composeSystem env3164 rootObs = leafEnv3164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env3164 rootObs == leafEnv3164) = true)

theorem terminalChecked3164 : H12PackedTerminal.terminalCheckFast leafEnv3164 active3164 tree3164 = true := by decide +kernel

def env3165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849104,268435456,268435965,547952,598059,12644669,525568,545873,8479126,8914924]

theorem envBound3165 : H12AffineFastState.Bounded env3165 := by
  intro p hp
  have h : env3165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2956_3165 : H12AffineEnvironment.transform 20 4097 env2956 = env3165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env2956 == env3165) = true)

def env3166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914001,849104,16384,16893,547952,598059,12644669,525568,545873,8479126,8914924]

theorem envBound3166 : H12AffineFastState.Bounded env3166 := by
  intro p hp
  have h : env3166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3165_3166 : H12AffineEnvironment.transform 27 16384 env3165 = env3166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env3165 == env3166) = true)

def env3167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388689,323792,16384,16893,22640,74795,12644669,256,20561,8479126,8389612]

theorem envBound3167 : H12AffineFastState.Bounded env3167 := by
  intro p hp
  have h : env3167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3166_3167 : H12AffineEnvironment.transform 18 1024 env3166 = env3167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env3166 == env3167) = true)

theorem identity3167 : scanCanonicalize (H12AffineFastState.compose env3167 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20804) := by decide +kernel

theorem selectedBound3167 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env3168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,20804,41002,8329,20757,323792,16384,16893,22640,74795,4235385,256,20561,78034,21160]

theorem envBound3168 : H12AffineFastState.Bounded env3168 := by
  intro p hp
  have h : env3168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3167_3168 : H12AffineEnvironment.transform 22 20804 env3167 = env3168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20804 env3167 == env3168) = true)

def env3169 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,20756,41002,8329,20757,323712,16384,16813,22560,74795,4235305,256,20481,77954,21160]

theorem envBound3169 : H12AffineFastState.Bounded env3169 := by
  intro p hp
  have h : env3169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3168_3169 : H12AffineEnvironment.transform 5 16 env3168 = env3169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env3168 == env3169) = true)

theorem identity3169 : scanCanonicalize (H12AffineFastState.compose env3169 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound3169 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env3170 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,4194304,444,41002,8329,445,303144,4264,4357,2184,74795,4235305,256,169,77954,512]

theorem envBound3170 : H12AffineFastState.Bounded env3170 := by
  intro p hp
  have h : env3170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3169_3170 : H12AffineEnvironment.transform 13 4264 env3169 = env3170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env3169 == env3170) = true)

theorem identity3170 : scanCanonicalize (H12AffineFastState.compose env3170 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound3170 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env3171 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,41349,444,41002,8329,445,303144,4264,4357,2184,74795,428,256,169,77954,512]

theorem envBound3171 : H12AffineFastState.Bounded env3171 := by
  intro p hp
  have h : env3171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3170_3171 : H12AffineEnvironment.transform 21 41349 env3170 = env3171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env3170 == env3171) = true)

theorem identity3171 : scanCanonicalize (H12AffineFastState.compose env3171 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 38842) := by decide +kernel

theorem selectedBound3171 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env3172 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,38842,4524,262144,1024,32768,4097,41349,444,41002,8329,445,303144,4264,4357,2184,45969,428,256,169,42808,512]

theorem envBound3172 : H12AffineFastState.Bounded env3172 := by
  intro p hp
  have h : env3172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3171_3172 : H12AffineEnvironment.transform 15 38842 env3171 = env3172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38842 env3171 == env3172) = true)

theorem identity3172 : scanCanonicalize (H12AffineFastState.compose env3172 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 14224) := by decide +kernel

theorem selectedBound3172 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env3173 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8234,4524,262144,1024,14224,4097,5653,444,6074,8329,445,268216,4264,4357,2184,1025,428,256,169,4264,512]

theorem envBound3173 : H12AffineFastState.Bounded env3173 := by
  intro p hp
  have h : env3173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3172_3173 : H12AffineEnvironment.transform 14 14224 env3172 = env3173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14224 env3172 == env3173) = true)

theorem identity3173 : scanCanonicalize (H12AffineFastState.compose env3173 (packedSelected [0,1,5,8,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound3173 : packedSelected [0,1,5,8,24,27] rootPS < 2^1333 := by decide +kernel

def env3174 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,14224,8234,4524,2341,1024,14224,4097,5653,444,6074,8329,445,7837,4264,4357,2184,1025,428,256,169,4264,512]

theorem envBound3174 : H12AffineFastState.Bounded env3174 := by
  intro p hp
  have h : env3174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3173_3174 : H12AffineEnvironment.transform 17 2341 env3173 = env3174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env3173 == env3174) = true)

theorem identity3174 : scanCanonicalize (H12AffineFastState.compose env3174 (packedSelected [0,3,4,5,7,9,10,18,23] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound3174 : packedSelected [0,3,4,5,7,9,10,18,23] rootPS < 2^1333 := by decide +kernel

def env3175 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1944,8192,1840,8200,8234,1588,2341,1024,8200,1945,397,444,34,8329,445,2309,1840,1693,2184,1025,428,256,169,1840,512]

theorem envBound3175 : H12AffineFastState.Bounded env3175 := by
  intro p hp
  have h : env3175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3174_3175 : H12AffineEnvironment.transform 11 1944 env3174 = env3175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env3174 == env3175) = true)

theorem identity3175 : scanCanonicalize (H12AffineFastState.compose env3175 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound3175 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3176 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,8192,1840,8200,8234,1588,2341,1024,8200,1840,292,277,34,8224,276,2309,1840,1588,2081,1025,261,256,0,1840,512]

theorem envBound3176 : H12AffineFastState.Bounded env3176 := by
  intro p hp
  have h : env3176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3175_3176 : H12AffineEnvironment.transform 6 41 env3175 = env3176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env3175 == env3176) = true)

theorem identity3176 : scanCanonicalize (H12AffineFastState.compose env3176 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound3176 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env3177 : List Nat := [2,4,8,16,32,16,41,256,512,273,2048,544,8192,545,8200,8234,805,2341,273,8200,545,292,277,34,8224,276,2309,545,805,2081,272,261,256,0,545,512]

theorem envBound3177 : H12AffineFastState.Bounded env3177 := by
  intro p hp
  have h : env3177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3176_3177 : H12AffineEnvironment.transform 9 273 env3176 = env3177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env3176 == env3177) = true)

theorem identity3177 : scanCanonicalize (H12AffineFastState.compose env3177 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound3177 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3178 : List Nat := [2,4,8,16,26,16,19,256,512,273,2048,538,8192,539,8200,8208,799,2335,273,8200,539,286,277,24,8218,276,2309,539,799,2075,272,261,256,0,539,512]

theorem envBound3178 : H12AffineFastState.Bounded env3178 := by
  intro p hp
  have h : env3178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3177_3178 : H12AffineEnvironment.transform 4 26 env3177 = env3178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env3177 == env3178) = true)

def env3179 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20757,41002,8329,20757,323713,16384,16812,22561,74795,4235304,256,20480,77955,21160]

theorem envBound3179 : H12AffineFastState.Bounded env3179 := by
  intro p hp
  have h : env3179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3168_3179 : H12AffineEnvironment.transform 5 17 env3168 = env3179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env3168 == env3179) = true)

def env3180 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,20741,41002,8329,20741,323713,16384,16812,22561,74795,4235304,256,20480,77955,21160]

theorem envBound3180 : H12AffineFastState.Bounded env3180 := by
  intro p hp
  have h : env3180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3179_3180 : H12AffineEnvironment.transform 3 0 env3179 = env3180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env3179 == env3180) = true)

theorem identity3180 : scanCanonicalize (H12AffineFastState.compose env3180 (packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 43309) := by decide +kernel

theorem selectedBound3180 : packedSelected [0,2,3,9,10,11,13,18,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env3181 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43309,1024,32768,4097,4194304,20741,41002,8329,20741,22956,16384,16812,22561,74795,4235304,256,20480,77955,21160]

theorem envBound3181 : H12AffineFastState.Bounded env3181 := by
  intro p hp
  have h : env3181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3180_3181 : H12AffineEnvironment.transform 17 43309 env3180 = env3181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43309 env3180 == env3181) = true)

def env3182 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43309,1024,32768,4097,61568,20741,41002,8329,20741,22956,16384,16812,22561,74795,20648,256,20480,77955,21160]

theorem envBound3182 : H12AffineFastState.Bounded env3182 := by
  intro p hp
  have h : env3182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3181_3182 : H12AffineEnvironment.transform 21 61568 env3181 = env3182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61568 env3181 == env3182) = true)

theorem identity3182 : scanCanonicalize (H12AffineFastState.compose env3182 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound3182 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3183 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,8460,65536,4525,2081,1024,8460,4097,20876,20741,294,8329,20741,22956,16384,16812,22561,74795,20648,256,20480,77955,21160]

theorem envBound3183 : H12AffineFastState.Bounded env3183 := by
  intro p hp
  have h : env3183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3182_3183 : H12AffineEnvironment.transform 14 8460 env3182 = env3183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env3182 == env3183) = true)

theorem identity3183 : scanCanonicalize (H12AffineFastState.compose env3183 (packedSelected [4,9,13,17,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 28974) := by decide +kernel

theorem selectedBound3183 : packedSelected [4,9,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env3184 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,8460,28974,4525,2081,1024,8460,4097,20876,20741,294,8329,20741,22956,16384,16812,22561,21765,20648,256,20480,16813,21160]

theorem envBound3184 : H12AffineFastState.Bounded env3184 := by
  intro p hp
  have h : env3184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3183_3184 : H12AffineEnvironment.transform 15 28974 env3183 = env3184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28974 env3183 == env3184) = true)

theorem identity3184 : scanCanonicalize (H12AffineFastState.compose env3184 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound3184 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env3185 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,8192,16384,8460,26531,1824,2081,1024,8460,1676,18177,18312,294,8329,18312,20257,16384,16812,20140,17288,17957,256,18061,16813,17445]

theorem envBound3185 : H12AffineFastState.Bounded env3185 := by
  intro p hp
  have h : env3185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3184_3185 : H12AffineEnvironment.transform 11 1677 env3184 = env3185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env3184 == env3185) = true)

theorem identity3185 : scanCanonicalize (H12AffineFastState.compose env3185 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound3185 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env3186 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1677,2348,16384,2080,20111,1824,2081,1024,2080,1676,18177,18312,294,2469,18312,20257,16384,16812,20140,17288,17957,256,18061,16813,17445]

theorem envBound3186 : H12AffineFastState.Bounded env3186 := by
  intro p hp
  have h : env3186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3185_3186 : H12AffineEnvironment.transform 12 2348 env3185 = env3186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env3185 == env3186) = true)

def env3187 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,43309,1024,32768,4097,61569,20741,41002,8329,20741,22956,16384,16812,22561,74795,20649,256,20480,77955,21160]

theorem envBound3187 : H12AffineFastState.Bounded env3187 := by
  intro p hp
  have h : env3187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3181_3187 : H12AffineEnvironment.transform 21 61569 env3181 = env3187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61569 env3181 == env3187) = true)

theorem identity3187 : scanCanonicalize (H12AffineFastState.compose env3187 (packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 33062) := by decide +kernel

theorem selectedBound3187 : packedSelected [2,3,4,5,9,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env3188 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,33062,4525,43309,1024,32768,4097,61569,20741,41002,8329,20741,22956,16384,16812,22561,42253,20649,256,20480,45477,21160]

theorem envBound3188 : H12AffineFastState.Bounded env3188 := by
  intro p hp
  have h : env3188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3187_3188 : H12AffineEnvironment.transform 15 33062 env3187 = env3188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33062 env3187 == env3188) = true)

theorem identity3188 : scanCanonicalize (H12AffineFastState.compose env3188 (packedSelected [3,5,9,10,22] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound3188 : packedSelected [3,5,9,10,22] rootPS < 2^1333 := by decide +kernel

def env3189 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,8192,16384,32768,33062,1825,43309,1024,32768,1677,58893,18313,41002,8329,18313,20256,16384,16812,20141,42253,17957,256,18060,42793,17444]

theorem envBound3189 : H12AffineFastState.Bounded env3189 := by
  intro p hp
  have h : env3189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3188_3189 : H12AffineEnvironment.transform 11 1676 env3188 = env3189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env3188 == env3189) = true)

theorem identity3189 : scanCanonicalize (H12AffineFastState.compose env3189 (packedSelected [0,1,2,3,7,8,10,11,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound3189 : packedSelected [0,1,2,3,7,8,10,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env3190 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1676,8192,16384,8461,8235,1825,2080,1024,8461,1677,18176,18313,295,8329,18313,20256,16384,16812,20141,1024,17957,256,18060,1572,17444]

theorem envBound3190 : H12AffineFastState.Bounded env3190 := by
  intro p hp
  have h : env3190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1