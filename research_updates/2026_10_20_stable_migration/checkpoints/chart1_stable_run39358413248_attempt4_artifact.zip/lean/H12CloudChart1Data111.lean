import H12CloudChart1Data110

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound28125 : H12AffineFastState.Bounded env28125 := by
  intro p hp
  have h : env28125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28124_28125 : H12AffineEnvironment.transform 16 5393 env28124 = env28125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env28124 == env28125) = true)

theorem identity28125 : scanCanonicalize (H12AffineFastState.compose env28125 (packedSelected [5,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound28125 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env28126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9292,9498,5393,10280,1024,9293,4161,33,1281,1435,8328,64,10708,4097,5392,2421,1500,33,256,32,4296,1808]

theorem envBound28126 : H12AffineFastState.Bounded env28126 := by
  intro p hp
  have h : env28126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28125_28126 : H12AffineEnvironment.transform 14 9292 env28125 = env28126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env28125 == env28126) = true)

theorem identity28126 : scanCanonicalize (H12AffineFastState.compose env28126 (packedSelected [0,7,8,10,11,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound28126 : packedSelected [0,7,8,10,11,18,23,24] rootPS < 2^1333 := by decide +kernel

def env28127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2113,8192,3392,9292,9498,3408,10280,1024,9293,2048,33,1281,1435,8328,64,10708,2112,3409,2421,1500,33,256,32,2185,1808]

theorem envBound28127 : H12AffineFastState.Bounded env28127 := by
  intro p hp
  have h : env28127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28126_28127 : H12AffineEnvironment.transform 11 2113 env28126 = env28127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env28126 == env28127) = true)

theorem identity28127 : scanCanonicalize (H12AffineFastState.compose env28127 (packedSelected [1,2,4,6,8,9,10,11,15,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28127 : packedSelected [1,2,4,6,8,9,10,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env28128 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2113,8192,3392,9292,9498,3408,10280,1024,9293,2048,33,1281,1346,8273,64,10509,2112,3409,2421,1285,33,256,32,2128,1808]

theorem envBound28128 : H12AffineFastState.Bounded env28128 := by
  intro p hp
  have h : env28128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28127_28128 : H12AffineEnvironment.transform 6 89 env28127 = env28128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28127 == env28128) = true)

theorem identity28128 : scanCanonicalize (H12AffineFastState.compose env28128 (packedSelected [0,2,3,4,5,6,7,9,10,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28128 : packedSelected [0,2,3,4,5,6,7,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env28129 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,2113,8192,2340,8232,8574,2356,10280,100,8233,2048,33,357,294,8273,64,10509,2112,2357,2421,353,33,256,32,2128,884]

theorem envBound28129 : H12AffineFastState.Bounded env28129 := by
  intro p hp
  have h : env28129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28128_28129 : H12AffineEnvironment.transform 9 100 env28128 = env28129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28128 == env28129) = true)

theorem identity28129 : scanCanonicalize (H12AffineFastState.compose env28129 (packedSelected [1,2,3,4,6,9,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28129 : packedSelected [1,2,3,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env28130 : List Nat := [2,4,8,16,32,64,89,37,512,100,2048,2113,8192,2049,8232,8283,2065,10280,100,8233,2048,33,64,3,8273,64,10280,2112,2064,2128,68,33,37,32,2128,593]

theorem envBound28130 : H12AffineFastState.Bounded env28130 := by
  intro p hp
  have h : env28130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28129_28130 : H12AffineEnvironment.transform 7 37 env28129 = env28130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28129 == env28130) = true)

theorem identity28130 : scanCanonicalize (H12AffineFastState.compose env28130 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound28130 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28131 : List Nat := [2,4,8,16,32,64,89,37,512,100,2048,2113,121,2049,81,34,2065,2129,100,80,2048,33,64,3,40,64,2129,2112,2064,2128,68,33,37,32,2128,593]

theorem envBound28131 : H12AffineFastState.Bounded env28131 := by
  intro p hp
  have h : env28131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28130_28131 : H12AffineEnvironment.transform 12 121 env28130 = env28131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env28130 == env28131) = true)

theorem identity28131 : scanCanonicalize (H12AffineFastState.compose env28131 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28131 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28132 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,2065,41,2049,1,34,2065,2049,52,0,2048,33,16,3,40,16,2049,2064,2064,2048,20,33,37,32,2048,513]

theorem envBound28132 : H12AffineFastState.Bounded env28132 := by
  intro p hp
  have h : env28132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28131_28132 : H12AffineEnvironment.transform 5 16 env28131 = env28132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28131 == env28132) = true)

theorem identity28132 : scanCanonicalize (H12AffineFastState.compose env28132 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound28132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28133 : List Nat := [2,4,8,16,32,16,9,37,33,52,2048,2065,41,2049,1,34,2065,2049,52,0,2048,33,16,3,40,16,2049,2064,2064,2048,20,33,37,32,2048,32]

theorem envBound28133 : H12AffineFastState.Bounded env28133 := by
  intro p hp
  have h : env28133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28132_28133 : H12AffineEnvironment.transform 8 33 env28132 = env28133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env28132 == env28133) = true)

def env28134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4161,21792,41293,62678,8328,64,146628,46157,58461,149860,1500,33,256,21793,46212,63069]

theorem envBound28134 : H12AffineFastState.Bounded env28134 := by
  intro p hp
  have h : env28134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28122_28134 : H12AffineEnvironment.transform 17 10281 env28122 = env28134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28122 == env28134) = true)

theorem identity28134 : scanCanonicalize (H12AffineFastState.compose env28134 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28134 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10281,1024,29789,4161,21792,21777,138,8328,64,146628,16401,4097,149860,1500,33,256,21793,16600,513]

theorem envBound28135 : H12AffineFastState.Bounded env28135 := by
  intro p hp
  have h : env28135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28134_28135 : H12AffineEnvironment.transform 14 29788 env28134 = env28135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28134 == env28135) = true)

theorem identity28135 : scanCanonicalize (H12AffineFastState.compose env28135 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound28135 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21976,399,131072,2477,1024,21977,4161,21792,21777,138,268,64,138560,16401,4097,149860,1500,33,256,21793,16600,513]

theorem envBound28136 : H12AffineFastState.Bounded env28136 := by
  intro p hp
  have h : env28136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28135_28136 : H12AffineEnvironment.transform 12 388 env28135 = env28136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env28135 == env28136) = true)

theorem identity28136 : scanCanonicalize (H12AffineFastState.compose env28136 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound28136 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,19,23] rootPS < 2^1333 := by decide +kernel

def env28137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,1,399,131072,2477,1024,0,4161,249,200,138,268,64,138560,5576,4097,138429,1500,33,256,248,5377,513]

theorem envBound28137 : H12AffineFastState.Bounded env28137 := by
  intro p hp
  have h : env28137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28136_28137 : H12AffineEnvironment.transform 13 5593 env28136 = env28137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env28136 == env28137) = true)

theorem identity28137 : scanCanonicalize (H12AffineFastState.compose env28137 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28137 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,1,399,5392,2477,1024,0,4161,249,200,138,268,64,2128,5576,4097,2477,1500,33,256,248,5377,513]

theorem envBound28138 : H12AffineFastState.Bounded env28138 := by
  intro p hp
  have h : env28138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28137_28138 : H12AffineEnvironment.transform 16 5392 env28137 = env28138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28137 == env28138) = true)

theorem identity28138 : scanCanonicalize (H12AffineFastState.compose env28138 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound28138 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1260,388,309,1,399,508,2477,1024,0,1197,249,200,138,268,64,2128,292,1261,2477,1500,33,256,248,493,513]

theorem envBound28139 : H12AffineFastState.Bounded env28139 := by
  intro p hp
  have h : env28139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28138_28139 : H12AffineEnvironment.transform 11 1260 env28138 = env28139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env28138 == env28139) = true)

theorem identity28139 : scanCanonicalize (H12AffineFastState.compose env28139 (packedSelected [1,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28139 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env28140 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1076,348,309,1,343,292,2421,1024,0,1141,33,16,82,268,64,2128,292,1077,2421,1284,33,256,32,309,513]

theorem envBound28140 : H12AffineFastState.Bounded env28140 := by
  intro p hp
  have h : env28140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28139_28140 : H12AffineEnvironment.transform 6 88 env28139 = env28140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28139 == env28140) = true)

theorem identity28140 : scanCanonicalize (H12AffineFastState.compose env28140 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound28140 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28141 : List Nat := [2,4,8,16,32,64,88,256,512,1024,33,1076,348,309,1,343,292,340,1024,0,1141,33,16,82,268,64,113,292,1077,340,1284,33,256,32,309,513]

theorem envBound28141 : H12AffineFastState.Bounded env28141 := by
  intro p hp
  have h : env28141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28140_28141 : H12AffineEnvironment.transform 10 33 env28140 = env28141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env28140 == env28141) = true)

theorem identity28141 : scanCanonicalize (H12AffineFastState.compose env28141 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28141 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,33,1076,268,309,1,263,292,260,1024,0,1061,33,16,2,268,16,33,292,1077,260,1284,33,256,32,309,513]

theorem envBound28142 : H12AffineFastState.Bounded env28142 := by
  intro p hp
  have h : env28142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28141_28142 : H12AffineEnvironment.transform 5 16 env28141 = env28142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28141 == env28142) = true)

def env28143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175169,8328,64,2609402,46156,77834,2598235,119178,2101345,256,2199862,2191507,63068]

theorem envBound28143 : H12AffineFastState.Bounded env28143 := by
  intro p hp
  have h : env28143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28095_28143 : H12AffineEnvironment.transform 23 2175169 env28095 = env28143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env28095 == env28143) = true)

def env28144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73857,8328,64,508090,46156,77834,505115,119178,33,256,98678,90323,63068]

theorem envBound28144 : H12AffineFastState.Bounded env28144 := by
  intro p hp
  have h : env28144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28143_28144 : H12AffineEnvironment.transform 20 4160 env28143 = env28144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28143 == env28144) = true)

theorem identity28144 : scanCanonicalize (H12AffineFastState.compose env28144 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28144 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,21793,21776,138,8328,64,450737,46156,4097,431376,61825,33,256,41341,16600,63068]

theorem envBound28145 : H12AffineFastState.Bounded env28145 := by
  intro p hp
  have h : env28145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28144_28145 : H12AffineEnvironment.transform 15 8203 env28144 = env28145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28144 == env28145) = true)

def env28146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1024,32769,4160,21793,21776,138,8328,64,171281,46156,4097,190640,61825,33,256,41341,16600,63068]

theorem envBound28146 : H12AffineFastState.Bounded env28146 := by
  intro p hp
  have h : env28146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28145_28146 : H12AffineEnvironment.transform 17 32160 env28145 = env28146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env28145 == env28146) = true)

theorem identity28146 : scanCanonicalize (H12AffineFastState.compose env28146 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28146 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env28147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,10281,1024,32769,4160,168,153,138,8328,64,171281,46156,4097,179513,41992,33,256,41341,5457,41941]

theorem envBound28147 : H12AffineFastState.Bounded env28147 := by
  intro p hp
  have h : env28147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28146_28147 : H12AffineEnvironment.transform 13 5513 env28146 = env28147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28146 == env28147) = true)

theorem identity28147 : scanCanonicalize (H12AffineFastState.compose env28147 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound28147 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,46157,10281,1024,32769,4160,168,153,138,8328,64,10588,46156,4097,2420,41992,33,256,41341,5457,41941]

theorem envBound28148 : H12AffineFastState.Bounded env28148 := by
  intro p hp
  have h : env28148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28147_28148 : H12AffineEnvironment.transform 16 46157 env28147 = env28148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env28147 == env28148) = true)

theorem identity28148 : scanCanonicalize (H12AffineFastState.compose env28148 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound28148 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env28149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,81,8203,13340,10281,1024,80,4160,168,153,138,8328,64,10588,13341,4097,2420,9305,33,256,8492,5457,9092]

theorem envBound28149 : H12AffineFastState.Bounded env28149 := by
  intro p hp
  have h : env28149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28148_28149 : H12AffineEnvironment.transform 14 81 env28148 = env28149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env28148 == env28149) = true)

theorem identity28149 : scanCanonicalize (H12AffineFastState.compose env28149 (packedSelected [1,8,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28149 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env28150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,81,8203,13340,10281,1024,80,4160,33,16,3,8193,64,10588,13341,4097,2420,9305,33,256,8492,5457,8973]

theorem envBound28150 : H12AffineFastState.Bounded env28150 := by
  intro p hp
  have h : env28150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28149_28150 : H12AffineEnvironment.transform 6 9 env28149 = env28150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28149 == env28150) = true)

theorem identity28150 : scanCanonicalize (H12AffineFastState.compose env28150 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound28150 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,4096,8192,5376,81,8203,13340,8460,1024,80,4160,33,16,3,8193,64,8313,13341,4097,81,9305,33,256,8492,5457,8973]

theorem envBound28151 : H12AffineFastState.Bounded env28151 := by
  intro p hp
  have h : env28151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28150_28151 : H12AffineEnvironment.transform 10 293 env28150 = env28151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env28150 == env28151) = true)

theorem identity28151 : scanCanonicalize (H12AffineFastState.compose env28151 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28151 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,17,8192,1297,81,8203,9229,8460,1024,80,81,33,16,3,8193,64,8313,9228,16,81,9305,33,256,8492,1344,8973]

theorem envBound28152 : H12AffineFastState.Bounded env28152 := by
  intro p hp
  have h : env28152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28151_28152 : H12AffineEnvironment.transform 11 17 env28151 = env28152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28151 == env28152) = true)

theorem identity28152 : scanCanonicalize (H12AffineFastState.compose env28152 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound28152 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env28153 : List Nat := [2,4,8,16,32,64,9,256,80,1024,293,17,8192,1297,81,8203,9229,8460,1024,80,81,33,16,3,8193,64,8313,9228,16,81,9305,33,256,8492,1344,8541]

theorem envBound28153 : H12AffineFastState.Bounded env28153 := by
  intro p hp
  have h : env28153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28152_28153 : H12AffineEnvironment.transform 8 80 env28152 = env28153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env28152 == env28153) = true)

theorem identity28153 : scanCanonicalize (H12AffineFastState.compose env28153 (packedSelected [1,5,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 365) := by decide +kernel

theorem selectedBound28153 : packedSelected [1,5,6,11] rootPS < 2^1333 := by decide +kernel

def env28154 : List Nat := [2,4,8,16,32,64,9,256,80,1024,293,17,365,1297,81,358,1376,97,1024,80,81,33,16,3,364,64,276,1377,16,81,1332,33,256,65,1344,48]

theorem envBound28154 : H12AffineFastState.Bounded env28154 := by
  intro p hp
  have h : env28154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28153_28154 : H12AffineEnvironment.transform 12 365 env28153 = env28154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 365 env28153 == env28154) = true)

theorem identity28154 : scanCanonicalize (H12AffineFastState.compose env28154 (packedSelected [1,5,12,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28154 : packedSelected [1,5,12,14] rootPS < 2^1333 := by decide +kernel

def env28155 : List Nat := [2,4,8,16,1,64,9,256,80,1024,260,17,332,1297,81,327,1345,64,1024,80,81,0,16,3,333,64,276,1344,16,81,1301,0,256,65,1344,17]

theorem envBound28155 : H12AffineFastState.Bounded env28155 := by
  intro p hp
  have h : env28155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28154_28155 : H12AffineEnvironment.transform 4 1 env28154 = env28155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28154 == env28155) = true)

theorem identity28155 : scanCanonicalize (H12AffineFastState.compose env28155 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28155 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28156 : List Nat := [2,4,8,16,1,16,9,256,0,1024,260,17,284,1297,1,279,1297,16,1024,0,1,0,16,3,285,16,276,1296,16,1,1301,0,256,17,1296,17]

theorem envBound28156 : H12AffineFastState.Bounded env28156 := by
  intro p hp
  have h : env28156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28155_28156 : H12AffineEnvironment.transform 5 16 env28155 = env28156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28155 == env28156) = true)

theorem identity28156 : scanCanonicalize (H12AffineFastState.compose env28156 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound28156 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28157 : List Nat := [2,4,8,16,1,16,9,256,0,4,260,17,284,277,1,279,277,16,4,0,1,0,16,3,285,16,276,276,16,1,273,0,256,17,276,17]

theorem envBound28157 : H12AffineFastState.Bounded env28157 := by
  intro p hp
  have h : env28157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28156_28157 : H12AffineEnvironment.transform 9 4 env28156 = env28157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env28156 == env28157) = true)

theorem identity28157 : scanCanonicalize (H12AffineFastState.compose env28157 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28157 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env28158 : List Nat := [2,4,8,16,1,16,9,21,0,4,17,17,9,0,1,2,0,16,4,0,1,0,16,3,8,16,1,1,16,1,4,0,21,17,1,17]

theorem envBound28158 : H12AffineFastState.Bounded env28158 := by
  intro p hp
  have h : env28158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28157_28158 : H12AffineEnvironment.transform 7 21 env28157 = env28158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28157 == env28158) = true)

theorem identity28158 : scanCanonicalize (H12AffineFastState.compose env28158 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28159 : List Nat := [2,4,8,1,1,1,9,4,0,4,0,0,9,0,1,2,0,1,4,0,1,0,1,3,8,1,1,1,1,1,4,0,4,0,1,0]

theorem envBound28159 : H12AffineFastState.Bounded env28159 := by
  intro p hp
  have h : env28159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28158_28159 : H12AffineEnvironment.transform 3 1 env28158 = env28159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28158 == env28159) = true)

theorem identity28159 : scanCanonicalize (H12AffineFastState.compose env28159 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28160 : List Nat := [2,0,8,1,1,1,9,0,0,0,0,0,9,0,1,2,0,1,0,0,1,0,1,3,8,1,1,1,1,1,0,0,0,0,1,0]

theorem envBound28160 : H12AffineFastState.Bounded env28160 := by
  intro p hp
  have h : env28160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28159_28160 : H12AffineEnvironment.transform 1 0 env28159 = env28160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28159 == env28160) = true)

def env28161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1024,32769,4160,21793,21776,138,8328,64,171280,46156,4097,190641,61825,33,256,41341,16600,63068]

theorem envBound28161 : H12AffineFastState.Bounded env28161 := by
  intro p hp
  have h : env28161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28145_28161 : H12AffineEnvironment.transform 17 32161 env28145 = env28161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env28145 == env28161) = true)

theorem identity28161 : scanCanonicalize (H12AffineFastState.compose env28161 (packedSelected [3,10,16,20,21,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound28161 : packedSelected [3,10,16,20,21,24,26] rootPS < 2^1333 := by decide +kernel

def env28162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38296,32161,1024,32769,4160,21793,21776,138,8328,64,2184,46156,4097,32041,61825,33,256,41341,16600,63068]

theorem envBound28162 : H12AffineFastState.Bounded env28162 := by
  intro p hp
  have h : env28162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28161_28162 : H12AffineEnvironment.transform 16 38296 env28161 = env28162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env28161 == env28162) = true)

theorem identity28162 : scanCanonicalize (H12AffineFastState.compose env28162 (packedSelected [0,5,6,12,16,18,19,20,23,24,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound28162 : packedSelected [0,5,6,12,16,18,19,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env28163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,8203,13461,32161,1024,8460,4160,21793,21776,138,8328,64,2184,5441,4097,32041,20620,33,256,112,16600,22353]

theorem envBound28163 : H12AffineFastState.Bounded env28163 := by
  intro p hp
  have h : env28163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28162_28163 : H12AffineEnvironment.transform 14 8461 env28162 = env28163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env28162 == env28163) = true)

theorem identity28163 : scanCanonicalize (H12AffineFastState.compose env28163 (packedSelected [0,2,7,9,10,11,14,16,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound28163 : packedSelected [0,2,7,9,10,11,14,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,8461,8203,13461,2477,1024,8460,4160,8493,8476,138,8328,64,2184,5441,4097,2341,9344,33,256,112,13524,9053]

theorem envBound28164 : H12AffineFastState.Bounded env28164 := by
  intro p hp
  have h : env28164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28163_28164 : H12AffineEnvironment.transform 13 13324 env28163 = env28164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env28163 == env28164) = true)

theorem identity28164 : scanCanonicalize (H12AffineFastState.compose env28164 (packedSelected [1,2,3,5,8,10,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound28164 : packedSelected [1,2,3,5,8,10,16,19] rootPS < 2^1333 := by decide +kernel

def env28165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5513,136,398,5392,2477,1024,137,4160,168,153,138,269,64,2184,5441,4097,2341,1285,33,256,112,5457,728]

theorem envBound28165 : H12AffineFastState.Bounded env28165 := by
  intro p hp
  have h : env28165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28164_28165 : H12AffineEnvironment.transform 12 389 env28164 = env28165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env28164 == env28165) = true)

theorem identity28165 : scanCanonicalize (H12AffineFastState.compose env28165 (packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28165 : packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env28166 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,161,5293,136,170,5172,2185,1024,137,4160,168,153,138,41,64,2184,5221,4097,2049,1057,33,36,112,5237,728]

theorem envBound28166 : H12AffineFastState.Bounded env28166 := by
  intro p hp
  have h : env28166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28165_28166 : H12AffineEnvironment.transform 7 36 env28165 = env28166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28165 == env28166) = true)

theorem identity28166 : scanCanonicalize (H12AffineFastState.compose env28166 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28166 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28167 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,161,5293,136,170,5172,2185,1024,137,4112,168,153,138,41,16,2184,5173,4097,2049,1057,33,36,32,5157,648]

theorem envBound28167 : H12AffineFastState.Bounded env28167 := by
  intro p hp
  have h : env28167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28166_28167 : H12AffineEnvironment.transform 5 16 env28166 = env28167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28166 == env28167) = true)

theorem identity28167 : scanCanonicalize (H12AffineFastState.compose env28167 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound28167 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env28168 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,161,4112,136,170,4233,2185,189,137,4112,168,153,138,41,16,2184,4232,4097,2049,156,33,36,32,4248,648]

theorem envBound28168 : H12AffineFastState.Bounded env28168 := by
  intro p hp
  have h : env28168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28167_28168 : H12AffineEnvironment.transform 9 189 env28167 = env28168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env28167 == env28168) = true)

theorem identity28168 : scanCanonicalize (H12AffineFastState.compose env28168 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound28168 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env28169 : List Nat := [2,4,8,16,32,16,128,36,512,189,48,4096,161,4112,136,170,4233,185,189,137,4112,168,153,138,41,16,184,4232,4097,49,156,33,36,32,4248,648]

theorem envBound28169 : H12AffineFastState.Bounded env28169 := by
  intro p hp
  have h : env28169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28168_28169 : H12AffineEnvironment.transform 10 48 env28168 = env28169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env28168 == env28169) = true)

theorem identity28169 : scanCanonicalize (H12AffineFastState.compose env28169 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28169 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env28170 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,4096,41,4112,0,34,4097,49,53,1,4112,32,17,2,41,16,48,4096,4097,49,20,33,36,32,4112,512]

theorem envBound28170 : H12AffineFastState.Bounded env28170 := by
  intro p hp
  have h : env28170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28169_28170 : H12AffineEnvironment.transform 6 8 env28169 = env28170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28169 == env28170) = true)

theorem identity28170 : scanCanonicalize (H12AffineFastState.compose env28170 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound28170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28171 : List Nat := [2,4,8,16,32,16,8,36,49,53,48,4096,41,4112,0,34,4097,49,53,1,4112,32,17,2,41,16,48,4096,4097,49,20,33,36,32,4112,49]

theorem envBound28171 : H12AffineFastState.Bounded env28171 := by
  intro p hp
  have h : env28171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28170_28171 : H12AffineEnvironment.transform 8 49 env28170 = env28171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env28170 == env28171) = true)

theorem identity28171 : scanCanonicalize (H12AffineFastState.compose env28171 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28172 : List Nat := [2,0,8,16,32,16,8,32,49,49,48,4096,41,4112,0,34,4097,49,49,1,4112,32,17,2,41,16,48,4096,4097,49,16,33,32,32,4112,49]

theorem envBound28172 : H12AffineFastState.Bounded env28172 := by
  intro p hp
  have h : env28172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28171_28172 : H12AffineEnvironment.transform 1 0 env28171 = env28172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28171 == env28172) = true)

theorem identity28172 : scanCanonicalize (H12AffineFastState.compose env28172 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound28172 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28173 : List Nat := [2,0,8,16,32,16,8,32,49,49,48,33,41,49,0,34,32,49,49,1,49,32,17,2,41,16,48,33,32,49,16,33,32,32,49,49]

theorem envBound28173 : H12AffineFastState.Bounded env28173 := by
  intro p hp
  have h : env28173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28172_28173 : H12AffineEnvironment.transform 11 33 env28172 = env28173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env28172 == env28173) = true)

theorem identity28173 : scanCanonicalize (H12AffineFastState.compose env28173 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28173 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28174 : List Nat := [2,0,8,0,32,0,8,32,33,33,32,33,41,33,0,34,32,33,33,1,33,32,1,2,41,0,32,33,32,33,0,33,32,32,33,33]

theorem envBound28174 : H12AffineFastState.Bounded env28174 := by
  intro p hp
  have h : env28174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28173_28174 : H12AffineEnvironment.transform 3 0 env28173 = env28174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28173 == env28174) = true)

theorem identity28174 : scanCanonicalize (H12AffineFastState.compose env28174 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28174 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28175 : List Nat := [2,0,8,0,1,0,8,1,0,0,1,0,8,0,0,3,1,0,0,1,0,1,1,2,8,0,1,0,1,0,0,0,1,1,0,0]

theorem envBound28175 : H12AffineFastState.Bounded env28175 := by
  intro p hp
  have h : env28175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28174_28175 : H12AffineEnvironment.transform 4 1 env28174 = env28175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28174 == env28175) = true)

def env28176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73856,8328,64,508091,46156,77834,505114,119178,32,256,98679,90322,63068]

theorem envBound28176 : H12AffineFastState.Bounded env28176 := by
  intro p hp
  have h : env28176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28143_28176 : H12AffineEnvironment.transform 20 4161 env28143 = env28176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28143 == env28176) = true)

theorem identity28176 : scanCanonicalize (H12AffineFastState.compose env28176 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound28176 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,262144,1024,32769,4161,21792,152,21762,8328,64,439609,46156,17800,442520,41992,32,256,62709,5456,63068]

theorem envBound28177 : H12AffineFastState.Bounded env28177 := by
  intro p hp
  have h : env28177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28176_28177 : H12AffineEnvironment.transform 15 30082 env28176 = env28177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env28176 == env28177) = true)

def env28178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,4161,21792,16,21762,8192,64,439609,46156,17664,442384,41992,32,256,62589,5456,63068]

theorem envBound28178 : H12AffineFastState.Bounded env28178 := by
  intro p hp
  have h : env28178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28177_28178 : H12AffineEnvironment.transform 6 8 env28177 = env28178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28177 == env28178) = true)

theorem identity28178 : scanCanonicalize (H12AffineFastState.compose env28178 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28178 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,4161,21792,16,21762,8192,64,409956,16401,17664,406605,20565,32,256,32,5456,513]

theorem envBound28179 : H12AffineFastState.Bounded env28179 := by
  intro p hp
  have h : env28179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28178_28179 : H12AffineEnvironment.transform 14 29789 env28178 = env28179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28178 == env28179) = true)

theorem identity28179 : scanCanonicalize (H12AffineFastState.compose env28179 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound28179 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env28180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,131072,149861,1024,29788,4161,21792,16,21762,8192,64,2049,16401,17664,32040,20565,32,256,32,5456,513]

theorem envBound28180 : H12AffineFastState.Bounded env28180 := by
  intro p hp
  have h : env28180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28179_28180 : H12AffineEnvironment.transform 17 149861 env28179 = env28180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env28179 == env28180) = true)

theorem identity28180 : scanCanonicalize (H12AffineFastState.compose env28180 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28180 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env28181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,5392,23669,1024,29788,4161,21792,16,21762,8192,64,2049,16401,17664,32040,20565,32,256,32,5456,513]

theorem envBound28181 : H12AffineFastState.Bounded env28181 := by
  intro p hp
  have h : env28181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28180_28181 : H12AffineEnvironment.transform 16 5392 env28180 = env28181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28180 == env28181) = true)

theorem identity28181 : scanCanonicalize (H12AffineFastState.compose env28181 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28181 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,5392,23669,1024,21760,4161,21792,16,21762,348,64,2049,16401,17664,23668,20565,32,256,32,5456,513]

theorem envBound28182 : H12AffineFastState.Bounded env28182 := by
  intro p hp
  have h : env28182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28181_28182 : H12AffineEnvironment.transform 12 348 env28181 = env28182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28181 == env28182) = true)

def env28183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,262144,1024,32769,4161,21792,17,21762,8193,64,439609,46156,17665,442385,41992,32,256,62588,5456,63068]

theorem envBound28183 : H12AffineFastState.Bounded env28183 := by
  intro p hp
  have h : env28183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28177_28183 : H12AffineEnvironment.transform 6 9 env28177 = env28183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28177 == env28183) = true)

theorem identity28183 : scanCanonicalize (H12AffineFastState.compose env28183 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound28183 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32040,1024,32769,4161,21792,17,21762,8193,64,182289,46156,17665,179513,41992,32,256,62588,5456,63068]

theorem envBound28184 : H12AffineFastState.Bounded env28184 := by
  intro p hp
  have h : env28184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28183_28184 : H12AffineEnvironment.transform 17 32040 env28183 = env28184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env28183 == env28184) = true)

theorem identity28184 : scanCanonicalize (H12AffineFastState.compose env28184 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28184 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,5392,32040,1024,32769,4161,21792,17,21762,8193,64,56577,46156,17665,43049,41992,32,256,62588,5456,63068]

theorem envBound28185 : H12AffineFastState.Bounded env28185 := by
  intro p hp
  have h : env28185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28184_28185 : H12AffineEnvironment.transform 16 5392 env28184 = env28185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28184 == env28185) = true)

theorem identity28185 : scanCanonicalize (H12AffineFastState.compose env28185 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28185 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,5392,32040,1024,29788,4161,21792,17,21762,8193,64,10588,16401,17665,23668,20565,32,256,33,5456,513]

theorem envBound28186 : H12AffineFastState.Bounded env28186 := by
  intro p hp
  have h : env28186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28185_28186 : H12AffineEnvironment.transform 14 29789 env28185 = env28186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28185 == env28186) = true)

theorem identity28186 : scanCanonicalize (H12AffineFastState.compose env28186 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound28186 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,20497,20807,5392,22884,1024,20496,4161,21792,17,21762,1101,64,3344,16401,17665,23668,20565,32,256,33,5456,513]

theorem envBound28187 : H12AffineFastState.Bounded env28187 := by
  intro p hp
  have h : env28187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28186_28187 : H12AffineEnvironment.transform 12 1100 env28186 = env28187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env28186 == env28187) = true)

theorem identity28187 : scanCanonicalize (H12AffineFastState.compose env28187 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28187 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env28188 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,16384,20497,20578,5173,22593,1024,20496,4161,21509,17,21543,1101,64,3125,16401,17444,23668,20565,32,37,33,5237,513]

theorem envBound28188 : H12AffineFastState.Bounded env28188 := by
  intro p hp
  have h : env28188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28187_28188 : H12AffineEnvironment.transform 7 37 env28187 = env28188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28187 == env28188) = true)

theorem identity28188 : scanCanonicalize (H12AffineFastState.compose env28188 (packedSelected [1,3,4,5,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound28188 : packedSelected [1,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env28189 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1100,2129,6208,6195,5173,4112,1024,6209,4161,7252,17,7286,1101,64,3125,2112,3189,5157,6148,32,37,33,5237,513]

theorem envBound28189 : H12AffineFastState.Bounded env28189 := by
  intro p hp
  have h : env28189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28188_28189 : H12AffineEnvironment.transform 13 2129 env28188 = env28189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env28188 == env28189) = true)

theorem identity28189 : scanCanonicalize (H12AffineFastState.compose env28189 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound28189 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env28190 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,3108,1100,2129,1124,1047,2065,3124,1024,1125,3173,112,17,82,1101,64,3125,2112,3189,2049,1056,32,37,33,2129,513]

theorem envBound28190 : H12AffineFastState.Bounded env28190 := by
  intro p hp
  have h : env28190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28189_28190 : H12AffineEnvironment.transform 11 3108 env28189 = env28190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env28189 == env28190) = true)

theorem identity28190 : scanCanonicalize (H12AffineFastState.compose env28190 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28190 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env28191 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3108,1052,2049,1076,1047,2065,3124,1024,1077,3125,32,17,2,1053,16,3125,2064,3109,2049,1056,32,37,33,2049,513]

theorem envBound28191 : H12AffineFastState.Bounded env28191 := by
  intro p hp
  have h : env28191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28190_28191 : H12AffineEnvironment.transform 5 16 env28190 = env28191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28190 == env28191) = true)

theorem identity28191 : scanCanonicalize (H12AffineFastState.compose env28191 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound28191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28192 : List Nat := [2,4,8,16,32,16,9,37,512,1024,49,1045,1052,48,1076,1047,32,1029,1024,1077,1028,32,17,2,1053,16,1028,33,1044,48,1056,32,37,33,48,513]

theorem envBound28192 : H12AffineFastState.Bounded env28192 := by
  intro p hp
  have h : env28192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28191_28192 : H12AffineEnvironment.transform 10 49 env28191 = env28192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env28191 == env28192) = true)

theorem identity28192 : scanCanonicalize (H12AffineFastState.compose env28192 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound28192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28193 : List Nat := [2,4,8,16,32,16,9,37,512,565,49,544,553,48,513,546,32,560,565,512,561,32,17,2,552,16,561,33,545,48,533,32,37,33,48,513]

theorem envBound28193 : H12AffineFastState.Bounded env28193 := by
  intro p hp
  have h : env28193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28192_28193 : H12AffineEnvironment.transform 9 565 env28192 = env28193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env28192 == env28193) = true)

theorem identity28193 : scanCanonicalize (H12AffineFastState.compose env28193 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound28193 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28194 : List Nat := [2,4,8,16,32,16,9,37,33,20,49,1,8,48,32,3,32,17,20,33,16,32,17,2,9,16,16,33,0,48,52,32,37,33,48,32]

theorem envBound28194 : H12AffineFastState.Bounded env28194 := by
  intro p hp
  have h : env28194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28193_28194 : H12AffineEnvironment.transform 8 33 env28193 = env28194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env28193 == env28194) = true)

theorem identity28194 : scanCanonicalize (H12AffineFastState.compose env28194 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28194 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28195 : List Nat := [2,4,8,16,1,16,9,4,0,20,16,1,8,17,1,3,1,17,20,0,16,1,17,2,9,16,16,0,0,17,21,1,4,0,17,1]

theorem envBound28195 : H12AffineFastState.Bounded env28195 := by
  intro p hp
  have h : env28195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28194_28195 : H12AffineEnvironment.transform 4 1 env28194 = env28195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28194 == env28195) = true)

def env28196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound28196 : H12AffineFastState.Bounded env28196 := by
  intro p hp
  have h : env28196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28000_28196 : H12AffineEnvironment.transform 18 1025 env28000 = env28196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28000 == env28196) = true)

theorem identity28196 : scanCanonicalize (H12AffineFastState.compose env28196 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262490) := by decide +kernel

theorem selectedBound28196 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262490,8328,64,15025626,196950,10507601,8830977,10682826,4448283,257,8601975,8626387,10626589]

theorem envBound28197 : H12AffineFastState.Bounded env28197 := by
  intro p hp
  have h : env28197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28196_28197 : H12AffineEnvironment.transform 23 2262490 env28196 = env28197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262490 env28196 == env28197) = true)

def env28198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025626,115150,10507601,8650905,10600786,4268163,257,8487407,8478795,10544773]

theorem envBound28198 : H12AffineFastState.Bounded env28198 := by
  intro p hp
  have h : env28198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28197_28198 : H12AffineEnvironment.transform 16 49304 env28197 = env28198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env28197 == env28198) = true)

def env28199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543882,115150,17665,2363593,119042,4268163,257,2199999,2191387,63189]

theorem envBound28199 : H12AffineFastState.Bounded env28199 := by
  intro p hp
  have h : env28199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28198_28199 : H12AffineEnvironment.transform 22 2101328 env28198 = env28199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env28198 == env28199) = true)

def env28200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97546,115150,17665,2363593,119042,329731,257,2199999,2191387,63189]

theorem envBound28200 : H12AffineFastState.Bounded env28200 := by
  intro p hp
  have h : env28200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28199_28200 : H12AffineEnvironment.transform 21 272512 env28199 = env28200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28199 == env28200) = true)

theorem identity28200 : scanCanonicalize (H12AffineFastState.compose env28200 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound28200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49304,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,43477,5393,17665,2363593,1501,318684,257,2114912,2139332,63189]

theorem envBound28201 : H12AffineFastState.Bounded env28201 := by
  intro p hp
  have h : env28201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28200_28201 : H12AffineEnvironment.transform 15 54495 env28200 = env28201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env28200 == env28201) = true)

theorem identity28201 : scanCanonicalize (H12AffineFastState.compose env28201 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28201 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,13388,262144,1025,29909,2097152,272512,2101328,2114882,8328,64,23809,5393,17665,2363593,1501,272392,257,2114912,2117648,513]

theorem envBound28202 : H12AffineFastState.Bounded env28202 := by
  intro p hp
  have h : env28202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28201_28202 : H12AffineEnvironment.transform 14 29908 env28201 = env28202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28201 == env28202) = true)

theorem identity28202 : scanCanonicalize (H12AffineFastState.compose env28202 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound28202 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env28203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,13388,262144,1025,29909,25628,272512,29772,8542,8328,64,23809,5393,17665,292053,1501,272392,257,8572,13324,513]

theorem envBound28203 : H12AffineFastState.Bounded env28203 := by
  intro p hp
  have h : env28203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28202_28203 : H12AffineEnvironment.transform 20 25628 env28202 = env28203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env28202 == env28203) = true)

theorem identity28203 : scanCanonicalize (H12AffineFastState.compose env28203 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound28203 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env28204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,13388,10281,1025,29909,25628,169,29772,8542,8328,64,23809,5393,17665,23804,1501,33,257,8572,13324,513]

theorem envBound28204 : H12AffineFastState.Bounded env28204 := by
  intro p hp
  have h : env28204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28203_28204 : H12AffineEnvironment.transform 17 10281 env28203 = env28204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28203 == env28204) = true)

theorem identity28204 : scanCanonicalize (H12AffineFastState.compose env28204 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28204 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env28205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,13388,10281,1025,29788,25628,32,29772,8542,8193,64,23809,5393,17665,23669,1364,33,257,8572,13324,513]

theorem envBound28205 : H12AffineFastState.Bounded env28205 := by
  intro p hp
  have h : env28205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28204_28205 : H12AffineEnvironment.transform 6 9 env28204 = env28205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28204 == env28205) = true)

theorem identity28205 : scanCanonicalize (H12AffineFastState.compose env28205 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28205 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28206 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8203,13341,10281,1025,29709,25628,32,29725,8463,8193,17,23809,5393,17665,23588,1285,33,257,8493,13324,513]

theorem envBound28206 : H12AffineFastState.Bounded env28206 := by
  intro p hp
  have h : env28206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28205_28206 : H12AffineEnvironment.transform 5 17 env28205 = env28206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28205 == env28206) = true)

theorem identity28206 : scanCanonicalize (H12AffineFastState.compose env28206 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28206 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28207 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,13341,10281,1025,8460,12573,32,8476,8463,8193,17,2048,5393,4096,2341,1285,33,257,8493,13324,513]

theorem envBound28207 : H12AffineFastState.Bounded env28207 := by
  intro p hp
  have h : env28207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28206_28207 : H12AffineEnvironment.transform 13 5377 env28206 = env28207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28206 == env28207) = true)

def env28208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97547,115150,17665,2363593,119042,329730,257,2199999,2191387,63189]

theorem envBound28208 : H12AffineFastState.Bounded env28208 := by
  intro p hp
  have h : env28208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28199_28208 : H12AffineEnvironment.transform 21 272513 env28199 = env28208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28199 == env28208) = true)

theorem identity28208 : scanCanonicalize (H12AffineFastState.compose env28208 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound28208 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,115870,272513,120014,98780,8328,64,97547,115150,17665,382039,119042,329730,257,21793,46213,63189]

theorem envBound28209 : H12AffineFastState.Bounded env28209 := by
  intro p hp
  have h : env28209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28208_28209 : H12AffineEnvironment.transform 20 115870 env28208 = env28209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env28208 == env28209) = true)

def env28210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10400,1025,32769,115870,33,120014,98780,8328,64,97547,115150,17665,130295,119042,73890,257,21793,46213,63189]

theorem envBound28210 : H12AffineFastState.Bounded env28210 := by
  intro p hp
  have h : env28210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28209_28210 : H12AffineEnvironment.transform 17 10400 env28209 = env28210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env28209 == env28210) = true)

theorem identity28210 : scanCanonicalize (H12AffineFastState.compose env28210 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound28210 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33167,49304,10400,1025,32769,17681,33,21825,83,8328,64,64644,16449,17665,32120,20621,41261,257,21793,46213,63189]

theorem envBound28211 : H12AffineFastState.Bounded env28211 := by
  intro p hp
  have h : env28211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28210_28211 : H12AffineEnvironment.transform 15 33167 env28210 = env28211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env28210 == env28211) = true)

theorem identity28211 : scanCanonicalize (H12AffineFastState.compose env28211 (packedSelected [0,1,3,9,17,19,22,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound28211 : packedSelected [0,1,3,9,17,19,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env28212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29829,29962,13341,10400,1025,29828,17681,33,21825,83,8328,64,2049,16449,17665,32120,20621,21928,257,21793,16384,592]

theorem envBound28212 : H12AffineFastState.Bounded env28212 := by
  intro p hp
  have h : env28212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28211_28212 : H12AffineEnvironment.transform 14 29829 env28211 = env28212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env28211 == env28212) = true)

theorem identity28212 : scanCanonicalize (H12AffineFastState.compose env28212 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,20,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28212 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env28213 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29788,29962,13341,10361,1025,29789,17681,33,21825,83,8273,64,2049,16449,17665,32120,20564,21873,257,21793,16384,592]

theorem envBound28213 : H12AffineFastState.Bounded env28213 := by
  intro p hp
  have h : env28213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28212_28213 : H12AffineEnvironment.transform 6 89 env28212 = env28213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28212 == env28213) = true)

theorem identity28213 : scanCanonicalize (H12AffineFastState.compose env28213 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound28213 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env28214 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,12345,1125,1331,13341,10361,1025,1124,13608,33,9592,83,8273,64,2049,12408,13624,3393,8301,9544,257,9496,12345,592]

theorem envBound28214 : H12AffineFastState.Bounded env28214 := by
  intro p hp
  have h : env28214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28213_28214 : H12AffineEnvironment.transform 13 12345 env28213 = env28214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env28213 == env28214) = true)

theorem identity28214 : scanCanonicalize (H12AffineFastState.compose env28214 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound28214 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env28215 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,1385,5456,1125,1331,4468,3344,1025,1124,4161,33,17,83,1336,64,2049,5393,4177,3393,1284,33,257,113,5456,592]

theorem envBound28215 : H12AffineFastState.Bounded env28215 := by
  intro p hp
  have h : env28215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28214_28215 : H12AffineEnvironment.transform 12 1385 env28214 = env28215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env28214 == env28215) = true)

theorem identity28215 : scanCanonicalize (H12AffineFastState.compose env28215 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound28215 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28216 : List Nat := [2,4,8,16,32,64,89,256,512,68,2048,4096,301,4372,33,375,4468,2388,69,32,4161,33,17,83,380,64,2049,4437,4177,2309,320,33,257,113,4372,592]

theorem envBound28216 : H12AffineFastState.Bounded env28216 := by
  intro p hp
  have h : env28216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28215_28216 : H12AffineEnvironment.transform 9 68 env28215 = env28216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env28215 == env28216) = true)

theorem identity28216 : scanCanonicalize (H12AffineFastState.compose env28216 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound28216 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28217 : List Nat := [2,4,8,16,32,64,89,256,512,68,2048,2097,301,2341,33,375,2373,2388,69,32,2160,33,17,83,380,64,2049,2404,2144,2309,320,33,257,113,2341,592]

theorem envBound28217 : H12AffineFastState.Bounded env28217 := by
  intro p hp
  have h : env28217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28216_28217 : H12AffineEnvironment.transform 11 2097 env28216 = env28217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env28216 == env28217) = true)

theorem identity28217 : scanCanonicalize (H12AffineFastState.compose env28217 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound28217 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28218 : List Nat := [2,4,8,16,32,49,40,256,512,53,2048,2097,301,2341,33,262,2356,2341,52,32,2049,33,17,34,269,49,2049,2325,2065,2309,305,33,257,0,2341,545]

theorem envBound28218 : H12AffineFastState.Bounded env28218 := by
  intro p hp
  have h : env28218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28217_28218 : H12AffineEnvironment.transform 5 49 env28217 = env28218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env28217 == env28218) = true)

theorem identity28218 : scanCanonicalize (H12AffineFastState.compose env28218 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound28218 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env28219 : List Nat := [2,4,8,16,32,49,40,256,512,53,814,799,301,523,33,262,538,523,52,32,815,33,17,34,269,49,815,571,831,555,305,33,257,0,523,545]

theorem envBound28219 : H12AffineFastState.Bounded env28219 := by
  intro p hp
  have h : env28219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28218_28219 : H12AffineEnvironment.transform 10 814 env28218 = env28219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env28218 == env28219) = true)

theorem identity28219 : scanCanonicalize (H12AffineFastState.compose env28219 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound28219 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28220 : List Nat := [2,4,8,16,32,49,40,5,512,53,555,538,40,523,33,3,538,523,52,32,554,33,17,34,8,49,554,571,570,555,52,33,4,0,523,545]

theorem envBound28220 : H12AffineFastState.Bounded env28220 := by
  intro p hp
  have h : env28220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28219_28220 : H12AffineEnvironment.transform 7 5 env28219 = env28220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env28219 == env28220) = true)

theorem identity28220 : scanCanonicalize (H12AffineFastState.compose env28220 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound28220 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28221 : List Nat := [2,4,8,16,32,49,40,5,4,53,47,30,40,15,33,3,30,15,52,32,46,33,17,34,8,49,46,63,62,47,52,33,4,0,15,37]

theorem envBound28221 : H12AffineFastState.Bounded env28221 := by
  intro p hp
  have h : env28221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28220_28221 : H12AffineEnvironment.transform 8 4 env28220 = env28221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env28220 == env28221) = true)

theorem identity28221 : scanCanonicalize (H12AffineFastState.compose env28221 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound28221 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env28222 : List Nat := [2,4,8,16,25,8,17,5,4,12,22,30,17,15,24,3,30,15,13,25,23,24,17,27,8,8,23,6,7,22,13,24,4,0,15,28]

theorem envBound28222 : H12AffineFastState.Bounded env28222 := by
  intro p hp
  have h : env28222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28221_28222 : H12AffineEnvironment.transform 4 25 env28221 = env28222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env28221 == env28222) = true)

theorem identity28222 : scanCanonicalize (H12AffineFastState.compose env28222 (packedSelected [0,10] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound28222 : packedSelected [0,10] rootPS < 2^1333 := by decide +kernel

def env28223 : List Nat := [2,4,8,8,1,8,9,5,4,12,14,6,9,15,0,3,6,15,13,1,15,0,9,3,8,8,15,6,7,14,13,0,4,0,15,4]

theorem envBound28223 : H12AffineFastState.Bounded env28223 := by
  intro p hp
  have h : env28223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28222_28223 : H12AffineEnvironment.transform 3 8 env28222 = env28223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env28222 == env28223) = true)

theorem identity28223 : scanCanonicalize (H12AffineFastState.compose env28223 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound28223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28224 : List Nat := [2,4,7,7,1,7,6,5,4,3,1,6,6,0,0,3,6,0,2,1,0,0,6,3,7,7,0,6,7,1,2,0,4,0,0,4]

theorem envBound28224 : H12AffineFastState.Bounded env28224 := by
  intro p hp
  have h : env28224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28223_28224 : H12AffineEnvironment.transform 2 7 env28223 = env28224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env28223 == env28224) = true)

def env28225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10401,1025,32769,115870,32,120014,98780,8328,64,97547,115150,17665,130294,119042,73891,257,21793,46213,63189]

theorem envBound28225 : H12AffineFastState.Bounded env28225 := by
  intro p hp
  have h : env28225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28209_28225 : H12AffineEnvironment.transform 17 10401 env28209 = env28225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28209 == env28225) = true)

theorem identity28225 : scanCanonicalize (H12AffineFastState.compose env28225 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound28225 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62591,49304,10401,1025,32769,12513,32,8369,30115,8328,64,35188,13745,17665,2185,9597,54492,257,21793,46213,63189]

theorem envBound28226 : H12AffineFastState.Bounded env28226 := by
  intro p hp
  have h : env28226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28225_28226 : H12AffineEnvironment.transform 15 62591 env28225 = env28226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env28225 == env28226) = true)

theorem identity28226 : scanCanonicalize (H12AffineFastState.compose env28226 (packedSelected [0,2,6,7,8,10,11,12,15,16,18,28] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound28226 : packedSelected [0,2,6,7,8,10,11,12,15,16,18,28] rootPS < 2^1333 := by decide +kernel

def env28227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,509,30082,16741,10401,1025,508,12513,32,8369,30115,8328,64,2185,13745,17665,2185,9597,21793,257,21793,13688,30504]

theorem envBound28227 : H12AffineFastState.Bounded env28227 := by
  intro p hp
  have h : env28227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28226_28227 : H12AffineEnvironment.transform 14 509 env28226 = env28227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env28226 == env28227) = true)

theorem identity28227 : scanCanonicalize (H12AffineFastState.compose env28227 (packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound28227 : packedSelected [0,1,3,4,7,8,10,12,15,17,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,509,8694,5393,10401,1025,508,12513,32,8369,8663,8328,64,2185,13745,4469,2185,9597,341,257,341,13688,9052]

theorem envBound28228 : H12AffineFastState.Bounded env28228 := by
  intro p hp
  have h : env28228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28227_28228 : H12AffineEnvironment.transform 13 5236 env28227 = env28228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env28227 == env28228) = true)

theorem identity28228 : scanCanonicalize (H12AffineFastState.compose env28228 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound28228 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env28229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5236,509,35,5393,2420,1025,508,4404,32,356,2,349,64,2185,5220,4469,2185,1192,341,257,341,5293,649]

theorem envBound28229 : H12AffineFastState.Bounded env28229 := by
  intro p hp
  have h : env28229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28228_28229 : H12AffineEnvironment.transform 12 469 env28228 = env28229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env28228 == env28229) = true)

theorem identity28229 : scanCanonicalize (H12AffineFastState.compose env28229 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound28229 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env28230 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5236,292,35,5393,2420,1025,293,4404,32,356,2,349,64,2128,5220,4469,2128,1137,341,257,341,5236,592]

theorem envBound28230 : H12AffineFastState.Bounded env28230 := by
  intro p hp
  have h : env28230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28229_28230 : H12AffineEnvironment.transform 6 89 env28229 = env28230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env28229 == env28230) = true)

theorem identity28230 : scanCanonicalize (H12AffineFastState.compose env28230 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound28230 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28231 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,268,4404,292,35,4177,2420,321,293,4404,32,356,2,349,64,2128,4388,4469,2128,305,341,257,341,4404,592]

theorem envBound28231 : H12AffineFastState.Bounded env28231 := by
  intro p hp
  have h : env28231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28230_28231 : H12AffineEnvironment.transform 9 320 env28230 = env28231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env28230 == env28231) = true)

theorem identity28231 : scanCanonicalize (H12AffineFastState.compose env28231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28232 : List Nat := [2,4,8,16,32,64,89,117,512,53,2048,4096,121,4161,81,35,4177,2049,52,80,4161,32,17,2,40,64,2128,4177,4096,2128,68,32,116,32,4161,592]

theorem envBound28232 : H12AffineFastState.Bounded env28232 := by
  intro p hp
  have h : env28232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28231_28232 : H12AffineEnvironment.transform 7 117 env28231 = env28232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28231 == env28232) = true)

theorem identity28232 : scanCanonicalize (H12AffineFastState.compose env28232 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound28232 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28233 : List Nat := [2,4,8,16,32,64,89,117,512,53,2048,577,121,512,81,35,528,2049,52,80,512,32,17,2,40,64,2128,528,577,2128,68,32,116,32,512,592]

theorem envBound28233 : H12AffineFastState.Bounded env28233 := by
  intro p hp
  have h : env28233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28232_28233 : H12AffineEnvironment.transform 11 577 env28232 = env28233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env28232 == env28233) = true)

theorem identity28233 : scanCanonicalize (H12AffineFastState.compose env28233 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound28233 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env28234 : List Nat := [2,4,8,16,32,64,89,117,512,53,65,577,121,512,81,35,528,64,52,80,512,32,17,2,40,64,17,528,577,17,68,32,116,32,512,592]

theorem envBound28234 : H12AffineFastState.Bounded env28234 := by
  intro p hp
  have h : env28234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28233_28234 : H12AffineEnvironment.transform 10 65 env28233 = env28234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env28233 == env28234) = true)

theorem identity28234 : scanCanonicalize (H12AffineFastState.compose env28234 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28234 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env28235 : List Nat := [2,4,8,16,32,64,89,117,0,53,65,65,121,0,81,35,16,64,52,80,0,32,17,2,40,64,17,16,65,17,68,32,116,32,0,80]

theorem envBound28235 : H12AffineFastState.Bounded env28235 := by
  intro p hp
  have h : env28235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28234_28235 : H12AffineEnvironment.transform 8 0 env28234 = env28235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28234 == env28235) = true)

theorem identity28235 : scanCanonicalize (H12AffineFastState.compose env28235 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28235 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env28236 : List Nat := [2,4,8,16,32,17,8,36,0,53,16,16,40,0,0,35,16,17,52,1,0,32,17,2,40,17,17,16,16,17,21,32,37,32,0,1]

theorem envBound28236 : H12AffineFastState.Bounded env28236 := by
  intro p hp
  have h : env28236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28235_28236 : H12AffineEnvironment.transform 5 17 env28235 = env28236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28235 == env28236) = true)

theorem identity28236 : scanCanonicalize (H12AffineFastState.compose env28236 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28237 : List Nat := [2,4,8,16,0,17,8,4,0,21,16,16,8,0,0,3,16,17,20,1,0,0,17,2,8,17,17,16,16,17,21,0,5,0,0,1]

theorem envBound28237 : H12AffineFastState.Bounded env28237 := by
  intro p hp
  have h : env28237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28236_28237 : H12AffineEnvironment.transform 4 0 env28236 = env28237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28236 == env28237) = true)

theorem identity28237 : scanCanonicalize (H12AffineFastState.compose env28237 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28237 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28238 : List Nat := [2,4,8,1,0,0,8,4,0,4,1,1,8,0,0,3,1,0,5,1,0,0,0,2,8,0,0,1,1,0,4,0,5,0,0,1]

theorem envBound28238 : H12AffineFastState.Bounded env28238 := by
  intro p hp
  have h : env28238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28237_28238 : H12AffineEnvironment.transform 3 1 env28237 = env28238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28237 == env28238) = true)

def env28239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543883,115150,17664,2363592,119043,4268163,257,2199998,2191386,63188]

theorem envBound28239 : H12AffineFastState.Bounded env28239 := by
  intro p hp
  have h : env28239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28198_28239 : H12AffineEnvironment.transform 22 2101329 env28198 = env28239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env28198 == env28239) = true)

def env28240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97547,115150,17664,2363592,119043,329731,257,2199998,2191386,63188]

theorem envBound28240 : H12AffineFastState.Bounded env28240 := by
  intro p hp
  have h : env28240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28239_28240 : H12AffineEnvironment.transform 21 272512 env28239 = env28240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28239 == env28240) = true)

theorem identity28240 : scanCanonicalize (H12AffineFastState.compose env28240 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28240 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,23808,57797,17664,2363592,61704,272392,257,2142645,2117649,63188]

theorem envBound28241 : H12AffineFastState.Bounded env28241 := by
  intro p hp
  have h : env28241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28240_28241 : H12AffineEnvironment.transform 15 8203 env28240 = env28241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28240 == env28241) = true)

def env28242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,23808,57677,17664,2363456,61704,272392,257,2142525,2117649,63068]

theorem envBound28242 : H12AffineFastState.Bounded env28242 := by
  intro p hp
  have h : env28242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28241_28242 : H12AffineEnvironment.transform 6 8 env28241 = env28242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28241 == env28242) = true)

theorem identity28242 : scanCanonicalize (H12AffineFastState.compose env28242 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound28242 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env28243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,4161,272392,16,21763,8192,64,23808,57677,17664,262145,61704,272392,257,41340,16464,63068]

theorem envBound28243 : H12AffineFastState.Bounded env28243 := by
  intro p hp
  have h : env28243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28242_28243 : H12AffineEnvironment.transform 20 4161 env28242 = env28243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28242 == env28243) = true)

theorem identity28243 : scanCanonicalize (H12AffineFastState.compose env28243 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28243 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38161,262144,1025,32769,4161,272392,16,2,8192,64,2049,46156,4097,262145,41993,272392,257,41340,5457,41821]

theorem envBound28244 : H12AffineFastState.Bounded env28244 := by
  intro p hp
  have h : env28244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28243_28244 : H12AffineEnvironment.transform 13 5377 env28243 = env28244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28243 == env28244) = true)

theorem identity28244 : scanCanonicalize (H12AffineFastState.compose env28244 (packedSelected [0,1,5,6,7,8,14,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28244 : packedSelected [0,1,5,6,7,8,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8203,5393,262144,1025,1,4161,272392,16,2,8192,64,2049,13388,4097,262145,9225,272392,257,8572,5457,9053]

theorem envBound28245 : H12AffineFastState.Bounded env28245 := by
  intro p hp
  have h : env28245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28244_28245 : H12AffineEnvironment.transform 14 0 env28244 = env28245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28244 == env28245) = true)

theorem identity28245 : scanCanonicalize (H12AffineFastState.compose env28245 (packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound28245 : packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env28246 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8203,5393,2421,1025,1,4161,8573,16,2,8192,64,2049,13388,4097,2420,9225,8573,257,8572,5457,9053]

theorem envBound28246 : H12AffineFastState.Bounded env28246 := by
  intro p hp
  have h : env28246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28245_28246 : H12AffineEnvironment.transform 17 2421 env28245 = env28246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env28245 == env28246) = true)

theorem identity28246 : scanCanonicalize (H12AffineFastState.compose env28246 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound28246 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28247 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5377,0,1046,5393,2421,1025,1,4161,1376,16,2,1053,64,2049,4177,4097,2420,20,1376,257,1377,5457,1856]

theorem envBound28247 : H12AffineFastState.Bounded env28247 := by
  intro p hp
  have h : env28247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28246_28247 : H12AffineEnvironment.transform 12 1053 env28246 = env28247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env28246 == env28247) = true)

theorem identity28247 : scanCanonicalize (H12AffineFastState.compose env28247 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound28247 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env28248 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1060,1053,293,0,1046,309,2421,1025,1,1125,1376,16,2,1053,64,2049,1141,1061,2420,20,1376,257,1377,373,1856]

theorem envBound28248 : H12AffineFastState.Bounded env28248 := by
  intro p hp
  have h : env28248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28247_28248 : H12AffineEnvironment.transform 11 1060 env28247 = env28248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env28247 == env28248) = true)

theorem identity28248 : scanCanonicalize (H12AffineFastState.compose env28248 (packedSelected [0,1,2,3,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound28248 : packedSelected [0,1,2,3,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28249 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,357,348,293,0,343,309,2421,320,1,292,33,16,2,348,64,2049,308,356,2420,20,33,257,32,373,513]

theorem envBound28249 : H12AffineFastState.Bounded env28249 := by
  intro p hp
  have h : env28249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28248_28249 : H12AffineEnvironment.transform 9 321 env28248 = env28249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env28248 == env28249) = true)

theorem identity28249 : scanCanonicalize (H12AffineFastState.compose env28249 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound28249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28250 : List Nat := [2,4,8,16,32,64,8,53,512,116,2048,80,105,16,0,98,0,2112,117,1,17,33,16,2,105,64,2049,1,81,2113,20,33,52,32,64,513]

theorem envBound28250 : H12AffineFastState.Bounded env28250 := by
  intro p hp
  have h : env28250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28249_28250 : H12AffineEnvironment.transform 7 53 env28249 = env28250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env28249 == env28250) = true)

theorem identity28250 : scanCanonicalize (H12AffineFastState.compose env28250 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound28250 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28251 : List Nat := [2,4,8,16,32,64,8,53,64,116,2048,80,105,16,0,98,0,2112,117,1,17,33,16,2,105,64,2049,1,81,2113,20,33,52,32,64,65]

theorem envBound28251 : H12AffineFastState.Bounded env28251 := by
  intro p hp
  have h : env28251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28250_28251 : H12AffineEnvironment.transform 8 64 env28250 = env28251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env28250 == env28251) = true)

theorem identity28251 : scanCanonicalize (H12AffineFastState.compose env28251 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28251 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28252 : List Nat := [2,4,8,16,32,16,8,53,16,36,2048,0,57,16,0,50,0,2064,37,1,17,33,16,2,57,16,2049,1,1,2065,20,33,52,32,16,17]

theorem envBound28252 : H12AffineFastState.Bounded env28252 := by
  intro p hp
  have h : env28252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28251_28252 : H12AffineEnvironment.transform 5 16 env28251 = env28252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28251 == env28252) = true)

theorem identity28252 : scanCanonicalize (H12AffineFastState.compose env28252 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound28252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28253 : List Nat := [2,4,8,16,32,16,8,53,16,36,11,0,57,16,0,50,0,27,37,1,17,33,16,2,57,16,10,1,1,26,20,33,52,32,16,17]

theorem envBound28253 : H12AffineFastState.Bounded env28253 := by
  intro p hp
  have h : env28253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28252_28253 : H12AffineEnvironment.transform 10 11 env28252 = env28253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env28252 == env28253) = true)

theorem identity28253 : scanCanonicalize (H12AffineFastState.compose env28253 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28253 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28254 : List Nat := [2,4,8,11,32,11,8,46,11,36,11,0,34,11,0,41,0,0,37,1,10,33,11,2,34,11,10,1,1,1,15,33,47,32,11,10]

theorem envBound28254 : H12AffineFastState.Bounded env28254 := by
  intro p hp
  have h : env28254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28253_28254 : H12AffineEnvironment.transform 3 11 env28253 = env28254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28253 == env28254) = true)

theorem identity28254 : scanCanonicalize (H12AffineFastState.compose env28254 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28255 : List Nat := [2,4,3,0,32,0,3,37,0,36,0,0,34,0,0,34,0,0,37,1,1,33,0,2,34,0,1,1,1,1,4,33,36,32,0,1]

theorem envBound28255 : H12AffineFastState.Bounded env28255 := by
  intro p hp
  have h : env28255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28254_28255 : H12AffineEnvironment.transform 2 3 env28254 = env28255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28254 == env28255) = true)

def env28256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,23808,57676,17664,2363457,61704,272392,257,2142524,2117649,63069]

theorem envBound28256 : H12AffineFastState.Bounded env28256 := by
  intro p hp
  have h : env28256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28241_28256 : H12AffineEnvironment.transform 6 9 env28241 = env28256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28241 == env28256) = true)

theorem identity28256 : scanCanonicalize (H12AffineFastState.compose env28256 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound28256 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env28257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,25628,272393,29773,8542,8193,64,23808,57676,17664,291933,61704,272392,257,54560,13325,63069]

theorem envBound28257 : H12AffineFastState.Bounded env28257 := by
  intro p hp
  have h : env28257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28256_28257 : H12AffineEnvironment.transform 20 25628 env28256 = env28257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env28256 == env28257) = true)

theorem identity28257 : scanCanonicalize (H12AffineFastState.compose env28257 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound28257 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env28258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1025,32769,25628,32,29773,8542,8193,64,23808,57676,17664,23668,61704,33,257,54560,13325,63069]

theorem envBound28258 : H12AffineFastState.Bounded env28258 := by
  intro p hp
  have h : env28258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28257_28258 : H12AffineEnvironment.transform 17 10281 env28257 = env28258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28257 == env28258) = true)

theorem identity28258 : scanCanonicalize (H12AffineFastState.compose env28258 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28258 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13389,10281,1025,29789,25628,32,29773,8542,8193,64,23808,5392,17664,23668,1364,33,257,8572,13325,513]

theorem envBound28259 : H12AffineFastState.Bounded env28259 := by
  intro p hp
  have h : env28259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28258_28259 : H12AffineEnvironment.transform 14 29788 env28258 = env28259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28258 == env28259) = true)

theorem identity28259 : scanCanonicalize (H12AffineFastState.compose env28259 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28259 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env28260 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,8203,13340,10281,1025,29708,25628,32,29724,8463,8193,17,23808,5392,17664,23589,1285,33,257,8493,13325,513]

theorem envBound28260 : H12AffineFastState.Bounded env28260 := by
  intro p hp
  have h : env28260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28259_28260 : H12AffineEnvironment.transform 5 17 env28259 = env28260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28259 == env28260) = true)

theorem identity28260 : scanCanonicalize (H12AffineFastState.compose env28260 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28260 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28261 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,13340,10281,1025,8460,12572,32,8476,8463,8193,17,2048,5392,4096,2341,1285,33,257,8493,13325,513]

theorem envBound28261 : H12AffineFastState.Bounded env28261 := by
  intro p hp
  have h : env28261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28260_28261 : H12AffineEnvironment.transform 13 5376 env28260 = env28261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28260 == env28261) = true)

def env28262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97546,115150,17664,2363592,119043,329730,257,2199998,2191386,63188]

theorem envBound28262 : H12AffineFastState.Bounded env28262 := by
  intro p hp
  have h : env28262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28239_28262 : H12AffineEnvironment.transform 21 272513 env28239 = env28262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28239 == env28262) = true)

theorem identity28262 : scanCanonicalize (H12AffineFastState.compose env28262 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound28262 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77899,272513,73754,95497,8328,64,97546,115150,17664,336003,119043,329730,257,41461,16465,63188]

theorem envBound28263 : H12AffineFastState.Bounded env28263 := by
  intro p hp
  have h : env28263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28262_28263 : H12AffineEnvironment.transform 20 77899 env28262 = env28263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env28262 == env28263) = true)

def env28264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77851,272513,73754,95497,8328,16,97546,115102,17664,336003,119043,329730,257,41381,16385,63108]

theorem envBound28264 : H12AffineFastState.Bounded env28264 := by
  intro p hp
  have h : env28264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28263_28264 : H12AffineEnvironment.transform 5 16 env28263 = env28264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28263 == env28264) = true)

theorem identity28264 : scanCanonicalize (H12AffineFastState.compose env28264 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound28264 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env28265 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,43049,1025,32769,77851,32936,73754,95497,8328,16,97546,115102,17664,100522,119043,106539,257,41381,16385,63108]

theorem envBound28265 : H12AffineFastState.Bounded env28265 := by
  intro p hp
  have h : env28265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28264_28265 : H12AffineEnvironment.transform 17 43049 env28264 = env28265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env28264 == env28265) = true)

theorem identity28265 : scanCanonicalize (H12AffineFastState.compose env28265 (packedSelected [1,3,4,5,7,8,9,11,14,17,26,27,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound28265 : packedSelected [1,3,4,5,7,8,9,11,14,17,26,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env28266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,49304,43049,1025,32769,45461,32936,41364,62599,8328,16,64644,16400,17664,2340,20621,8613,257,41381,16385,63108]

theorem envBound28266 : H12AffineFastState.Bounded env28266 := by
  intro p hp
  have h : env28266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28265_28266 : H12AffineEnvironment.transform 15 33166 env28265 = env28266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env28265 == env28266) = true)

theorem identity28266 : scanCanonicalize (H12AffineFastState.compose env28266 (packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28266 : packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28267 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,33166,49304,35108,1025,32769,37016,32936,32921,54666,389,16,56713,16400,17664,2340,20621,168,257,32936,16385,55177]

theorem envBound28267 : H12AffineFastState.Bounded env28267 := by
  intro p hp
  have h : env28267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28266_28267 : H12AffineEnvironment.transform 12 269 env28266 = env28267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28266 == env28267) = true)

theorem identity28267 : scanCanonicalize (H12AffineFastState.compose env28267 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28267 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env28268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,1,399,16537,2341,1025,0,4249,169,152,21899,389,16,23944,16400,17664,2340,20621,168,257,169,16385,22408]

theorem envBound28268 : H12AffineFastState.Bounded env28268 := by
  intro p hp
  have h : env28268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28267_28268 : H12AffineEnvironment.transform 14 1 env28267 = env28268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28267 == env28268) = true)

theorem identity28268 : scanCanonicalize (H12AffineFastState.compose env28268 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28268 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28269 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,1,399,5528,2341,1025,0,4249,169,152,138,389,16,2185,5393,4097,2340,1420,168,257,169,5376,649]

theorem envBound28269 : H12AffineFastState.Bounded env28269 := by
  intro p hp
  have h : env28269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28268_28269 : H12AffineEnvironment.transform 13 5377 env28268 = env28269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28268 == env28269) = true)

theorem identity28269 : scanCanonicalize (H12AffineFastState.compose env28269 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28269 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28270 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,1,170,5309,2048,1025,0,4249,169,152,138,160,16,2185,5172,4097,2049,1193,168,36,169,5157,649]

theorem envBound28270 : H12AffineFastState.Bounded env28270 := by
  intro p hp
  have h : env28270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28269_28270 : H12AffineEnvironment.transform 7 37 env28269 = env28270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28269 == env28270) = true)

theorem identity28270 : scanCanonicalize (H12AffineFastState.compose env28270 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound28270 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28271 : List Nat := [2,4,8,16,32,16,128,37,512,189,2048,4096,40,4249,1,170,4096,2048,188,0,4249,169,152,138,160,16,2185,4233,4097,2049,20,168,36,169,4248,649]

theorem envBound28271 : H12AffineFastState.Bounded env28271 := by
  intro p hp
  have h : env28271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28270_28271 : H12AffineEnvironment.transform 9 189 env28270 = env28271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env28270 == env28271) = true)

theorem identity28271 : scanCanonicalize (H12AffineFastState.compose env28271 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound28271 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env28272 : List Nat := [2,4,8,16,32,16,128,37,512,189,2048,2201,40,2048,1,170,2201,2048,188,0,2048,169,152,138,160,16,2185,2064,2200,2049,20,168,36,169,2049,649]

theorem envBound28272 : H12AffineFastState.Bounded env28272 := by
  intro p hp
  have h : env28272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28271_28272 : H12AffineEnvironment.transform 11 2201 env28271 = env28272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env28271 == env28272) = true)

def env28273 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,77850,272513,73754,95497,8328,17,97546,115103,17664,336003,119043,329730,257,41380,16384,63109]

theorem envBound28273 : H12AffineFastState.Bounded env28273 := by
  intro p hp
  have h : env28273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28263_28273 : H12AffineEnvironment.transform 5 17 env28263 = env28273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28263 == env28273) = true)

theorem identity28273 : scanCanonicalize (H12AffineFastState.compose env28273 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound28273 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env28274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,62851,49304,262144,1025,32769,50585,272513,54681,32906,8328,17,34953,13340,17664,316672,9344,327041,257,41380,16384,63109]

theorem envBound28274 : H12AffineFastState.Bounded env28274 := by
  intro p hp
  have h : env28274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28273_28274 : H12AffineEnvironment.transform 15 62851 env28273 = env28274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env28273 == env28274) = true)

theorem identity28274 : scanCanonicalize (H12AffineFastState.compose env28274 (packedSelected [0,1,4,5,7,8,10,16,17,18,19,20,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound28274 : packedSelected [0,1,4,5,7,8,10,16,17,18,19,20,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env28275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,398,13461,262144,1025,29708,12692,272513,8596,29831,8328,17,31876,13340,17664,270605,9344,264588,257,21929,16384,648]

theorem envBound28275 : H12AffineFastState.Bounded env28275 := by
  intro p hp
  have h : env28275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28274_28275 : H12AffineEnvironment.transform 14 29709 env28274 = env28275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env28274 == env28275) = true)

theorem identity28275 : scanCanonicalize (H12AffineFastState.compose env28275 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound28275 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env28276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,0,398,13461,262144,1025,1,12692,272513,8596,138,8328,17,2185,13340,12557,270605,9344,264588,257,8612,13325,648]

theorem envBound28276 : H12AffineFastState.Bounded env28276 := by
  intro p hp
  have h : env28276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28275_28276 : H12AffineEnvironment.transform 13 13325 env28275 = env28276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env28275 == env28276) = true)

theorem identity28276 : scanCanonicalize (H12AffineFastState.compose env28276 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound28276 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28277 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,0,398,13461,10401,1025,1,12692,32,8596,138,8328,17,2185,13340,12557,2476,9344,8493,257,8612,13325,648]

theorem envBound28277 : H12AffineFastState.Bounded env28277 := by
  intro p hp
  have h : env28277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28276_28277 : H12AffineEnvironment.transform 17 10401 env28276 = env28277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env28276 == env28277) = true)

theorem identity28277 : scanCanonicalize (H12AffineFastState.compose env28277 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28277 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env28278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,0,398,5529,2477,1025,1,4248,32,152,138,388,17,2185,5392,4097,2476,1420,33,257,168,5377,648]

theorem envBound28278 : H12AffineFastState.Bounded env28278 := by
  intro p hp
  have h : env28278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28277_28278 : H12AffineEnvironment.transform 12 268 env28277 = env28278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28277 == env28278) = true)

theorem identity28278 : scanCanonicalize (H12AffineFastState.compose env28278 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound28278 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28279 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,268,5377,0,294,5425,2309,1025,1,4144,32,48,34,300,17,2081,5392,4097,2308,1316,33,257,0,5377,544]

theorem envBound28279 : H12AffineFastState.Bounded env28279 := by
  intro p hp
  have h : env28279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28278_28279 : H12AffineEnvironment.transform 6 40 env28278 = env28279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env28278 == env28279) = true)

def env28280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025626,115151,10507601,8650904,10600787,4268162,257,8487406,8478794,10544772]

theorem envBound28280 : H12AffineFastState.Bounded env28280 := by
  intro p hp
  have h : env28280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28197_28280 : H12AffineEnvironment.transform 16 49305 env28197 = env28280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env28197 == env28280) = true)

def env28281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543882,115151,17665,2363592,119043,4268162,257,2199998,2191386,63188]

theorem envBound28281 : H12AffineFastState.Bounded env28281 := by
  intro p hp
  have h : env28281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28280_28281 : H12AffineEnvironment.transform 22 2101328 env28280 = env28281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env28280 == env28281) = true)

def env28282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97546,115151,17665,2363592,119043,329730,257,2199998,2191386,63188]

theorem envBound28282 : H12AffineFastState.Bounded env28282 := by
  intro p hp
  have h : env28282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28281_28282 : H12AffineEnvironment.transform 21 272512 env28281 = env28282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28281 == env28282) = true)

theorem identity28282 : scanCanonicalize (H12AffineFastState.compose env28282 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound28282 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272512,17,21762,8328,64,97546,115151,17665,262281,119043,329730,257,98815,90203,63188]

theorem envBound28283 : H12AffineFastState.Bounded env28283 := by
  intro p hp
  have h : env28283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28282_28283 : H12AffineEnvironment.transform 20 4161 env28282 = env28283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28282 == env28283) = true)

def env28284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21762,8192,64,97546,115015,17665,262145,119043,329730,257,98679,90203,63068]

theorem envBound28284 : H12AffineFastState.Bounded env28284 := by
  intro p hp
  have h : env28284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28283_28284 : H12AffineEnvironment.transform 6 8 env28283 = env28284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28283 == env28284) = true)

theorem identity28284 : scanCanonicalize (H12AffineFastState.compose env28284 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound28284 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32041,1025,32769,4161,21793,17,21762,8192,64,97546,115015,17665,32040,119043,95531,257,98679,90203,63068]

theorem envBound28285 : H12AffineFastState.Bounded env28285 := by
  intro p hp
  have h : env28285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28284_28285 : H12AffineEnvironment.transform 17 32041 env28284 = env28285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env28284 == env28285) = true)

theorem identity28285 : scanCanonicalize (H12AffineFastState.compose env28285 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound28285 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21795,49169,32041,1025,32769,4161,21793,17,21762,8192,64,10281,37988,17665,32040,33824,8200,257,54356,13688,63068]

theorem envBound28286 : H12AffineFastState.Bounded env28286 := by
  intro p hp
  have h : env28286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28285_28286 : H12AffineEnvironment.transform 15 21795 env28285 = env28286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env28285 == env28286) = true)

theorem identity28286 : scanCanonicalize (H12AffineFastState.compose env28286 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28286 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env28287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21795,16401,32041,1025,1,4161,21793,17,21762,8192,64,10281,5220,17665,32040,1056,8200,257,21588,13688,30300]

theorem envBound28287 : H12AffineFastState.Bounded env28287 := by
  intro p hp
  have h : env28287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28286_28287 : H12AffineEnvironment.transform 14 0 env28286 = env28287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28286 == env28287) = true)

theorem identity28287 : scanCanonicalize (H12AffineFastState.compose env28287 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound28287 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env28288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,0,8203,13625,2049,1025,1,4161,8201,17,8234,8192,64,10281,5220,12329,2048,1056,8200,257,8572,13688,884]

theorem envBound28288 : H12AffineFastState.Bounded env28288 := by
  intro p hp
  have h : env28288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28287_28288 : H12AffineEnvironment.transform 13 13608 env28287 = env28288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env28287 == env28288) = true)

theorem identity28288 : scanCanonicalize (H12AffineFastState.compose env28288 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28288 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5236,0,343,5221,2049,1025,1,4161,341,17,374,348,64,2421,5220,4469,2048,1056,340,257,32,5156,884]

theorem envBound28289 : H12AffineFastState.Bounded env28289 := by
  intro p hp
  have h : env28289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28288_28289 : H12AffineEnvironment.transform 12 348 env28288 = env28289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28288 == env28289) = true)

theorem identity28289 : scanCanonicalize (H12AffineFastState.compose env28289 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28289 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28290 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,0,35,5221,2049,1025,1,4161,33,17,2,40,64,2049,5220,4097,2048,1056,32,117,32,5156,512]

theorem envBound28290 : H12AffineFastState.Bounded env28290 := by
  intro p hp
  have h : env28290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28289_28290 : H12AffineEnvironment.transform 7 116 env28289 = env28290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28289 == env28290) = true)

theorem identity28290 : scanCanonicalize (H12AffineFastState.compose env28290 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound28290 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28291 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,4096,40,4145,0,35,4128,2049,68,1,4161,33,17,2,40,64,2049,4129,4097,2048,101,32,117,32,4193,512]

theorem envBound28291 : H12AffineFastState.Bounded env28291 := by
  intro p hp
  have h : env28291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28290_28291 : H12AffineEnvironment.transform 9 69 env28290 = env28291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env28290 == env28291) = true)

theorem identity28291 : scanCanonicalize (H12AffineFastState.compose env28291 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28291 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28292 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,4096,9,4112,0,2,4097,2049,68,1,4161,0,17,2,9,64,2049,4096,4097,2048,68,1,84,1,4160,512]

theorem envBound28292 : H12AffineFastState.Bounded env28292 := by
  intro p hp
  have h : env28292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28291_28292 : H12AffineEnvironment.transform 4 1 env28291 = env28292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28291 == env28292) = true)

theorem identity28292 : scanCanonicalize (H12AffineFastState.compose env28292 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28292 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28293 : List Nat := [2,4,8,16,1,64,8,85,512,69,2048,17,9,1,0,2,16,2049,68,1,80,0,17,2,9,64,2049,17,16,2048,68,1,84,1,81,512]

theorem envBound28293 : H12AffineFastState.Bounded env28293 := by
  intro p hp
  have h : env28293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28292_28293 : H12AffineEnvironment.transform 11 17 env28292 = env28293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28292 == env28293) = true)

theorem identity28293 : scanCanonicalize (H12AffineFastState.compose env28293 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound28293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28294 : List Nat := [2,4,8,16,1,64,8,85,512,69,80,17,9,1,0,2,16,81,68,1,80,0,17,2,9,64,81,17,16,80,68,1,84,1,81,512]

theorem envBound28294 : H12AffineFastState.Bounded env28294 := by
  intro p hp
  have h : env28294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28293_28294 : H12AffineEnvironment.transform 10 80 env28293 = env28294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env28293 == env28294) = true)

theorem identity28294 : scanCanonicalize (H12AffineFastState.compose env28294 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 95) := by decide +kernel

theorem selectedBound28294 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28295 : List Nat := [2,4,8,16,1,64,8,85,95,69,80,17,9,1,0,2,16,81,68,1,80,0,17,2,9,64,81,17,16,80,68,1,84,1,81,95]

theorem envBound28295 : H12AffineFastState.Bounded env28295 := by
  intro p hp
  have h : env28295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28294_28295 : H12AffineEnvironment.transform 8 95 env28294 = env28295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 95 env28294 == env28295) = true)

def env28296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21762,8193,64,97546,115014,17665,262144,119043,329730,257,98678,90203,63069]

theorem envBound28296 : H12AffineFastState.Bounded env28296 := by
  intro p hp
  have h : env28296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28283_28296 : H12AffineEnvironment.transform 6 9 env28283 = env28296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28283 == env28296) = true)

theorem identity28296 : scanCanonicalize (H12AffineFastState.compose env28296 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound28296 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1025,32769,4161,62588,17,21762,8193,64,97546,115014,17665,56437,119043,119927,257,98678,90203,63069]

theorem envBound28297 : H12AffineFastState.Bounded env28297 := by
  intro p hp
  have h : env28297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28296_28297 : H12AffineEnvironment.transform 17 56437 env28296 = env28297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env28296 == env28297) = true)

theorem identity28297 : scanCanonicalize (H12AffineFastState.compose env28297 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound28297 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,5393,2420,1025,21760,4161,8573,17,21762,8193,64,97546,70727,17665,2420,66562,65910,257,87159,90203,9052]

theorem envBound28298 : H12AffineFastState.Bounded env28298 := by
  intro p hp
  have h : env28298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28297_28298 : H12AffineEnvironment.transform 14 21761 env28297 = env28298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env28297 == env28298) = true)

theorem identity28298 : scanCanonicalize (H12AffineFastState.compose env28298 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28298 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env28299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,5393,2420,1025,21760,4161,8573,17,21762,8193,64,23808,13389,17665,2420,9224,8572,257,29821,16465,9052]

theorem envBound28299 : H12AffineFastState.Bounded env28299 := by
  intro p hp
  have h : env28299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28298_28299 : H12AffineEnvironment.transform 15 8202 env28298 = env28299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28298 == env28299) = true)

def env28300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97547,115151,17665,2363592,119043,329731,257,2199998,2191386,63188]

theorem envBound28300 : H12AffineFastState.Bounded env28300 := by
  intro p hp
  have h : env28300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28281_28300 : H12AffineEnvironment.transform 21 272513 env28281 = env28300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28281 == env28300) = true)

def env28301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,97547,115015,17665,2363456,119043,329731,257,2199862,2191386,63068]

theorem envBound28301 : H12AffineFastState.Bounded env28301 := by
  intro p hp
  have h : env28301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28300_28301 : H12AffineEnvironment.transform 6 8 env28300 = env28301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28300 == env28301) = true)

def env28302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,16,21763,8192,64,97547,115015,17665,262144,119043,329731,257,98678,90202,63068]

theorem envBound28302 : H12AffineFastState.Bounded env28302 := by
  intro p hp
  have h : env28302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28301_28302 : H12AffineEnvironment.transform 20 4160 env28301 = env28302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28301 == env28302) = true)

theorem identity28302 : scanCanonicalize (H12AffineFastState.compose env28302 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28302 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,262144,1025,32769,4160,272393,16,2,8192,64,75786,103494,4096,262144,99330,329731,257,98678,79195,41821]

theorem envBound28303 : H12AffineFastState.Bounded env28303 := by
  intro p hp
  have h : env28303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28302_28303 : H12AffineEnvironment.transform 13 5377 env28302 = env28303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28302 == env28303) = true)

theorem identity28303 : scanCanonicalize (H12AffineFastState.compose env28303 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound28303 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10360,1025,32769,4160,113,16,2,8192,64,75786,103494,4096,10360,99330,73851,257,98678,79195,41821]

theorem envBound28304 : H12AffineFastState.Bounded env28304 := by
  intro p hp
  have h : env28304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28303_28304 : H12AffineEnvironment.transform 17 10360 env28303 = env28304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env28303 == env28304) = true)

theorem identity28304 : scanCanonicalize (H12AffineFastState.compose env28304 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound28304 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env28305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41342,38160,10360,1025,32769,4160,113,16,2,8192,64,35188,13624,4096,10360,9596,33029,257,8200,37925,41821]

theorem envBound28305 : H12AffineFastState.Bounded env28305 := by
  intro p hp
  have h : env28305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28304_28305 : H12AffineEnvironment.transform 15 41342 env28304 = env28305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env28304 == env28305) = true)

theorem identity28305 : scanCanonicalize (H12AffineFastState.compose env28305 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound28305 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8313,263,13673,10360,1025,8312,4160,113,16,2,8192,64,10509,13624,4096,10360,9596,8572,257,8200,13404,804]

theorem envBound28306 : H12AffineFastState.Bounded env28306 := by
  intro p hp
  have h : env28306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28305_28306 : H12AffineEnvironment.transform 14 8313 env28305 = env28306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env28305 == env28306) = true)

theorem identity28306 : scanCanonicalize (H12AffineFastState.compose env28306 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28306 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env28307 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8313,115,13341,10360,1025,8312,4160,113,16,2,8192,64,10361,13388,4096,10360,9224,8200,117,8200,13404,592]

theorem envBound28307 : H12AffineFastState.Bounded env28307 := by
  intro p hp
  have h : env28307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28306_28307 : H12AffineEnvironment.transform 7 116 env28306 = env28307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28306 == env28307) = true)

theorem identity28307 : scanCanonicalize (H12AffineFastState.compose env28307 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound28307 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env28308 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1101,5237,1076,115,4176,3125,1025,1077,4160,113,16,2,1101,64,3124,4097,4096,3125,69,1093,117,1093,4113,592]

theorem envBound28308 : H12AffineFastState.Bounded env28308 := by
  intro p hp
  have h : env28308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28307_28308 : H12AffineEnvironment.transform 12 1101 env28307 = env28308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env28307 == env28308) = true)

theorem identity28308 : scanCanonicalize (H12AffineFastState.compose env28308 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound28308 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env28309 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2065,1101,3172,1076,115,2113,3125,1025,1077,2129,113,16,2,1101,64,3124,2064,2065,3125,69,1093,117,1093,2048,592]

theorem envBound28309 : H12AffineFastState.Bounded env28309 := by
  intro p hp
  have h : env28309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28308_28309 : H12AffineEnvironment.transform 11 2065 env28308 = env28309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env28308 == env28309) = true)

theorem identity28309 : scanCanonicalize (H12AffineFastState.compose env28309 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28309 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env28310 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,2065,121,2128,0,115,2113,2049,53,1,2129,113,16,2,121,64,2048,2064,2065,2049,69,113,117,113,2048,592]

theorem envBound28310 : H12AffineFastState.Bounded env28310 := by
  intro p hp
  have h : env28310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28309_28310 : H12AffineEnvironment.transform 9 52 env28309 = env28310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28309 == env28310) = true)

theorem identity28310 : scanCanonicalize (H12AffineFastState.compose env28310 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28310 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env28311 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,41,2048,0,35,2065,2049,53,1,2049,33,16,2,41,16,2048,2064,2065,2049,21,33,37,33,2048,512]

theorem envBound28311 : H12AffineFastState.Bounded env28311 := by
  intro p hp
  have h : env28311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28310_28311 : H12AffineEnvironment.transform 5 16 env28310 = env28311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28310 == env28311) = true)

theorem identity28311 : scanCanonicalize (H12AffineFastState.compose env28311 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound28311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28312 : List Nat := [2,4,8,16,32,16,8,36,20,52,2048,2065,41,2048,0,35,2065,2049,53,1,2049,33,16,2,41,16,2048,2064,2065,2049,21,33,37,33,2048,20]

theorem envBound28312 : H12AffineFastState.Bounded env28312 := by
  intro p hp
  have h : env28312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28311_28312 : H12AffineEnvironment.transform 8 20 env28311 = env28312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env28311 == env28312) = true)

theorem identity28312 : scanCanonicalize (H12AffineFastState.compose env28312 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28313 : List Nat := [2,3,8,16,32,16,8,35,19,51,2048,2065,41,2048,0,35,2065,2049,50,1,2049,33,16,2,41,16,2048,2064,2065,2049,18,33,34,33,2048,19]

theorem envBound28313 : H12AffineFastState.Bounded env28313 := by
  intro p hp
  have h : env28313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28312_28313 : H12AffineEnvironment.transform 1 3 env28312 = env28313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28312 == env28313) = true)

theorem identity28313 : scanCanonicalize (H12AffineFastState.compose env28313 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound28313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28314 : List Nat := [2,3,8,16,32,16,8,35,19,51,49,32,41,49,0,35,32,48,50,1,48,33,16,2,41,16,49,33,32,48,18,33,34,33,49,19]

theorem envBound28314 : H12AffineFastState.Bounded env28314 := by
  intro p hp
  have h : env28314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28313_28314 : H12AffineEnvironment.transform 10 49 env28313 = env28314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env28313 == env28314) = true)

theorem identity28314 : scanCanonicalize (H12AffineFastState.compose env28314 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28314 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28315 : List Nat := [2,3,8,10,32,10,8,35,9,41,43,32,41,43,0,35,32,42,40,1,42,33,10,2,41,10,43,33,32,42,8,33,34,33,43,9]

theorem envBound28315 : H12AffineFastState.Bounded env28315 := by
  intro p hp
  have h : env28315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28314_28315 : H12AffineEnvironment.transform 3 10 env28314 = env28315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28314 == env28315) = true)

theorem identity28315 : scanCanonicalize (H12AffineFastState.compose env28315 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28315 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28316 : List Nat := [2,3,8,10,1,10,8,2,9,8,10,1,8,10,0,2,1,11,9,1,11,0,10,2,8,10,10,0,1,11,8,0,3,0,10,9]

theorem envBound28316 : H12AffineFastState.Bounded env28316 := by
  intro p hp
  have h : env28316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28315_28316 : H12AffineEnvironment.transform 4 1 env28315 = env28316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28315 == env28316) = true)

def env28317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21762,8192,64,97547,115015,17665,262145,119043,329731,257,98679,90203,63068]

theorem envBound28317 : H12AffineFastState.Bounded env28317 := by
  intro p hp
  have h : env28317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28301_28317 : H12AffineEnvironment.transform 20 4161 env28301 = env28317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28301 == env28317) = true)

theorem identity28317 : scanCanonicalize (H12AffineFastState.compose env28317 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound28317 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32041,1025,32769,4161,21792,17,21762,8192,64,97547,115015,17665,32040,119043,95530,257,98679,90203,63068]

theorem envBound28318 : H12AffineFastState.Bounded env28318 := by
  intro p hp
  have h : env28318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28317_28318 : H12AffineEnvironment.transform 17 32041 env28317 = env28318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env28317 == env28318) = true)

theorem identity28318 : scanCanonicalize (H12AffineFastState.compose env28318 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62511) := by decide +kernel

theorem selectedBound28318 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env28319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62511,49169,32041,1025,32769,4161,21792,17,21762,8192,64,35108,13672,17665,32040,9516,33029,257,30040,38004,63068]

theorem envBound28319 : H12AffineFastState.Bounded env28319 := by
  intro p hp
  have h : env28319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28318_28319 : H12AffineEnvironment.transform 15 62511 env28318 = env28319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62511 env28318 == env28319) = true)

theorem identity28319 : scanCanonicalize (H12AffineFastState.compose env28319 (packedSelected [0,3,5,9,10,12,15,19,22,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound28319 : packedSelected [0,3,5,9,10,12,15,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env28320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,8575,5441,32041,1025,21841,4161,21792,17,21762,8192,64,23668,13672,17665,32040,9516,21589,257,30040,16676,8972]

theorem envBound28320 : H12AffineFastState.Bounded env28320 := by
  intro p hp
  have h : env28320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28319_28320 : H12AffineEnvironment.transform 14 21840 env28319 = env28320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env28319 == env28320) = true)

theorem identity28320 : scanCanonicalize (H12AffineFastState.compose env28320 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28320 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env28321 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,21621,8282,5220,31756,1025,21620,4161,21509,17,21543,8192,64,23668,13389,17444,31757,9225,21589,36,29821,16385,8745]

theorem envBound28321 : H12AffineFastState.Bounded env28321 := by
  intro p hp
  have h : env28321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28320_28321 : H12AffineEnvironment.transform 7 37 env28320 = env28321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28320 == env28321) = true)

theorem identity28321 : scanCanonicalize (H12AffineFastState.compose env28321 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound28321 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env28322 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5237,0,8282,5220,10361,1025,1,4161,112,17,82,8192,64,2049,13389,4177,10360,9225,32,36,8200,5236,8745]

theorem envBound28322 : H12AffineFastState.Bounded env28322 := by
  intro p hp
  have h : env28322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28321_28322 : H12AffineEnvironment.transform 13 5237 env28321 = env28322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env28321 == env28322) = true)

theorem identity28322 : scanCanonicalize (H12AffineFastState.compose env28322 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound28322 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env28323 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5237,0,35,5220,2048,1025,1,4161,112,17,82,121,64,2049,5172,4177,2049,1136,32,36,113,5236,592]

theorem envBound28323 : H12AffineFastState.Bounded env28323 := by
  intro p hp
  have h : env28323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28322_28323 : H12AffineEnvironment.transform 12 121 env28322 = env28323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env28322 == env28323) = true)

def env28324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,97547,115014,17665,2363457,119043,329731,257,2199863,2191386,63069]

theorem envBound28324 : H12AffineFastState.Bounded env28324 := by
  intro p hp
  have h : env28324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28300_28324 : H12AffineEnvironment.transform 6 9 env28300 = env28324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28300 == env28324) = true)

def env28325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,16,21763,8193,64,97547,115014,17665,262145,119043,329731,257,98679,90202,63069]

theorem envBound28325 : H12AffineFastState.Bounded env28325 := by
  intro p hp
  have h : env28325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28324_28325 : H12AffineEnvironment.transform 20 4160 env28324 = env28325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28324 == env28325) = true)

theorem identity28325 : scanCanonicalize (H12AffineFastState.compose env28325 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28325 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,262144,1025,29789,4160,272392,16,21763,8193,64,97547,79130,17665,262145,75103,329731,257,95531,90202,513]

theorem envBound28326 : H12AffineFastState.Bounded env28326 := by
  intro p hp
  have h : env28326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28325_28326 : H12AffineEnvironment.transform 14 29788 env28325 = env28326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28325 == env28326) = true)

theorem identity28326 : scanCanonicalize (H12AffineFastState.compose env28326 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound28326 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21591,13388,262144,1025,29789,4160,272392,16,21763,8193,64,10588,24909,17665,262145,28936,285780,257,8572,13325,513]

theorem envBound28327 : H12AffineFastState.Bounded env28327 := by
  intro p hp
  have h : env28327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28326_28327 : H12AffineEnvironment.transform 15 21591 env28326 = env28327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env28326 == env28327) = true)

theorem identity28327 : scanCanonicalize (H12AffineFastState.compose env28327 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28327 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5392,262144,1025,21761,4160,264532,16,21763,349,64,2048,16401,17665,262145,20564,285780,257,32,5457,513]

theorem envBound28328 : H12AffineFastState.Bounded env28328 := by
  intro p hp
  have h : env28328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28327_28328 : H12AffineEnvironment.transform 12 348 env28327 = env28328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28327 == env28328) = true)

theorem identity28328 : scanCanonicalize (H12AffineFastState.compose env28328 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound28328 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,21591,5392,2420,1025,21761,4160,32,16,21763,349,64,2048,16401,17665,2421,20564,21792,257,32,5457,513]

theorem envBound28329 : H12AffineFastState.Bounded env28329 := by
  intro p hp
  have h : env28329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28328_28329 : H12AffineEnvironment.transform 17 2420 env28328 = env28329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env28328 == env28329) = true)

theorem identity28329 : scanCanonicalize (H12AffineFastState.compose env28329 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28329 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1297,1094,5392,2420,1025,1296,4160,32,16,1298,349,64,2048,4096,5392,2421,69,1329,257,32,5457,513]

theorem envBound28330 : H12AffineFastState.Bounded env28330 := by
  intro p hp
  have h : env28330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28329_28330 : H12AffineEnvironment.transform 13 4113 env28329 = env28330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28329 == env28330) = true)

theorem identity28330 : scanCanonicalize (H12AffineFastState.compose env28330 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound28330 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,348,4113,1297,1094,5392,1076,1025,1296,4160,32,16,1298,349,64,1344,4096,5392,1077,69,1329,257,32,5457,513]

theorem envBound28331 : H12AffineFastState.Bounded env28331 := by
  intro p hp
  have h : env28331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28330_28331 : H12AffineEnvironment.transform 10 1344 env28330 = env28331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env28330 == env28331) = true)

theorem identity28331 : scanCanonicalize (H12AffineFastState.compose env28331 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound28331 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28332 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,4096,348,4113,373,34,4468,80,101,372,4160,32,16,374,349,64,292,4096,4468,81,69,341,257,32,4405,513]

theorem envBound28332 : H12AffineFastState.Bounded env28332 := by
  intro p hp
  have h : env28332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28331_28332 : H12AffineEnvironment.transform 9 100 env28331 = env28332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env28331 == env28332) = true)

theorem identity28332 : scanCanonicalize (H12AffineFastState.compose env28332 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound28332 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28333 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,65,348,80,373,34,309,80,101,372,1,32,16,374,349,64,292,65,309,81,69,341,257,32,372,513]

theorem envBound28333 : H12AffineFastState.Bounded env28333 := by
  intro p hp
  have h : env28333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28332_28333 : H12AffineEnvironment.transform 11 65 env28332 = env28333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env28332 == env28333) = true)

theorem identity28333 : scanCanonicalize (H12AffineFastState.compose env28333 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28333 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28334 : List Nat := [2,4,8,16,32,64,9,116,512,100,80,65,40,80,1,34,65,80,101,0,1,32,16,2,41,64,80,65,65,81,69,33,117,32,0,513]

theorem envBound28334 : H12AffineFastState.Bounded env28334 := by
  intro p hp
  have h : env28334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28333_28334 : H12AffineEnvironment.transform 7 116 env28333 = env28334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28333 == env28334) = true)

theorem identity28334 : scanCanonicalize (H12AffineFastState.compose env28334 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound28334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28335 : List Nat := [2,4,8,16,32,64,9,116,64,100,80,65,40,80,1,34,65,80,101,0,1,32,16,2,41,64,80,65,65,81,69,33,117,32,0,65]

theorem envBound28335 : H12AffineFastState.Bounded env28335 := by
  intro p hp
  have h : env28335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28334_28335 : H12AffineEnvironment.transform 8 64 env28334 = env28335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env28334 == env28335) = true)

theorem identity28335 : scanCanonicalize (H12AffineFastState.compose env28335 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound28335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28336 : List Nat := [2,4,8,16,32,59,9,15,59,31,43,58,40,43,1,34,58,43,30,0,1,32,16,2,41,59,43,58,58,42,62,33,14,32,0,58]

theorem envBound28336 : H12AffineFastState.Bounded env28336 := by
  intro p hp
  have h : env28336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28335_28336 : H12AffineEnvironment.transform 5 59 env28335 = env28336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env28335 == env28336) = true)

theorem identity28336 : scanCanonicalize (H12AffineFastState.compose env28336 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28336 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28337 : List Nat := [2,4,8,16,11,16,9,15,16,31,0,17,3,0,1,9,17,0,30,0,1,11,16,2,2,16,0,17,17,1,21,10,14,11,0,17]

theorem envBound28337 : H12AffineFastState.Bounded env28337 := by
  intro p hp
  have h : env28337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28336_28337 : H12AffineEnvironment.transform 4 11 env28336 = env28337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28336 == env28337) = true)

def env28338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21762,8193,64,97547,115014,17665,262144,119043,329731,257,98678,90203,63069]

theorem envBound28338 : H12AffineFastState.Bounded env28338 := by
  intro p hp
  have h : env28338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28324_28338 : H12AffineEnvironment.transform 20 4161 env28324 = env28338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28324 == env28338) = true)

theorem identity28338 : scanCanonicalize (H12AffineFastState.compose env28338 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound28338 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56437,1025,32769,4161,62589,17,21762,8193,64,97547,115014,17665,56437,119043,119926,257,98678,90203,63069]

theorem envBound28339 : H12AffineFastState.Bounded env28339 := by
  intro p hp
  have h : env28339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28338_28339 : H12AffineEnvironment.transform 17 56437 env28338 = env28339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env28338 == env28339) = true)

theorem identity28339 : scanCanonicalize (H12AffineFastState.compose env28339 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound28339 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,49168,56437,1025,32769,4161,62589,17,21762,8193,64,64605,16400,17665,56437,20565,21792,257,32,57613,63069]

theorem envBound28340 : H12AffineFastState.Bounded env28340 := by
  intro p hp
  have h : env28340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28339_28340 : H12AffineEnvironment.transform 15 33110 env28339 = env28340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env28339 == env28340) = true)

theorem identity28340 : scanCanonicalize (H12AffineFastState.compose env28340 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound28340 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env28341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29708,30042,13340,10361,1025,29709,4161,113,17,21762,8193,64,2129,16400,17665,10361,20565,21792,257,32,5377,593]

theorem envBound28341 : H12AffineFastState.Bounded env28341 := by
  intro p hp
  have h : env28341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28340_28341 : H12AffineEnvironment.transform 14 29708 env28340 = env28341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env28340 == env28341) = true)

theorem identity28341 : scanCanonicalize (H12AffineFastState.compose env28341 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28341 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env28342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,8202,13340,10361,1025,8541,4161,113,17,82,8193,64,2129,5440,4177,10361,1285,112,257,32,5377,593]

theorem envBound28342 : H12AffineFastState.Bounded env28342 := by
  intro p hp
  have h : env28342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28341_28342 : H12AffineEnvironment.transform 13 5456 env28341 = env28342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28341 == env28342) = true)

theorem identity28342 : scanCanonicalize (H12AffineFastState.compose env28342 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28342 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28343 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5157,8233,8202,13340,10361,1025,8232,4161,113,17,82,8193,64,2129,5173,4177,10361,1136,112,116,32,5236,593]

theorem envBound28343 : H12AffineFastState.Bounded env28343 := by
  intro p hp
  have h : env28343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28342_28343 : H12AffineEnvironment.transform 7 117 env28342 = env28343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28342 == env28343) = true)

theorem identity28343 : scanCanonicalize (H12AffineFastState.compose env28343 (packedSelected [0,3,5,6,7,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound28343 : packedSelected [0,3,5,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env28344 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,7180,5157,7205,7174,2064,5237,1025,7204,4161,113,17,82,7181,64,2129,5173,4177,5237,1136,112,116,32,5236,593]

theorem envBound28344 : H12AffineFastState.Bounded env28344 := by
  intro p hp
  have h : env28344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28343_28344 : H12AffineEnvironment.transform 12 7180 env28343 = env28344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env28343 == env28344) = true)

def env28345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543883,115151,17664,2363593,119042,4268162,257,2199999,2191387,63189]

theorem envBound28345 : H12AffineFastState.Bounded env28345 := by
  intro p hp
  have h : env28345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28280_28345 : H12AffineEnvironment.transform 22 2101329 env28280 = env28345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env28280 == env28345) = true)

def env28346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97547,115151,17664,2363593,119042,329730,257,2199999,2191387,63189]

theorem envBound28346 : H12AffineFastState.Bounded env28346 := by
  intro p hp
  have h : env28346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28345_28346 : H12AffineEnvironment.transform 21 272512 env28345 = env28346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env28345 == env28346) = true)

theorem identity28346 : scanCanonicalize (H12AffineFastState.compose env28346 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound28346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58516,272512,62661,41431,8328,64,97547,115151,17664,324701,119042,329730,257,95531,103567,63189]

theorem envBound28347 : H12AffineFastState.Bounded env28347 := by
  intro p hp
  have h : env28347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28346_28347 : H12AffineEnvironment.transform 20 58516 env28346 = env28347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env28346 == env28347) = true)

def env28348 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58516,272512,62613,41351,8328,16,97547,115103,17664,324621,119042,329730,257,95531,103567,63109]

theorem envBound28348 : H12AffineFastState.Bounded env28348 := by
  intro p hp
  have h : env28348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28347_28348 : H12AffineEnvironment.transform 5 16 env28347 = env28348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28347 == env28348) = true)

theorem identity28348 : scanCanonicalize (H12AffineFastState.compose env28348 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound28348 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env28349 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62851,49305,262144,1025,32769,58516,272512,62613,41351,8328,16,34952,13340,17664,324621,9345,327041,257,32936,24844,63109]

theorem envBound28349 : H12AffineFastState.Bounded env28349 := by
  intro p hp
  have h : env28349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28348_28349 : H12AffineEnvironment.transform 15 62851 env28348 = env28349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env28348 == env28349) = true)

theorem identity28349 : scanCanonicalize (H12AffineFastState.compose env28349 (packedSelected [0,1,3,9,16,17,20,22,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound28349 : packedSelected [0,1,3,9,16,17,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env28350 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,21646,24980,262144,1025,8460,17817,272512,21912,138,8328,16,10629,13340,17664,283904,9345,285836,257,8613,24844,22408]

theorem envBound28350 : H12AffineFastState.Bounded env28350 := by
  intro p hp
  have h : env28350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28349_28350 : H12AffineEnvironment.transform 14 8461 env28349 = env28350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env28349 == env28350) = true)

def env28351 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,58516,272512,62612,41350,8328,17,97547,115102,17664,324620,119042,329730,257,95531,103567,63108]

theorem envBound28351 : H12AffineFastState.Bounded env28351 := by
  intro p hp
  have h : env28351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28347_28351 : H12AffineEnvironment.transform 5 17 env28347 = env28351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28347 == env28351) = true)

theorem identity28351 : scanCanonicalize (H12AffineFastState.compose env28351 (packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound28351 : packedSelected [1,5,8,10,12,15,17,18,19,23,24,26,31,38,41] rootPS < 2^1333 := by decide +kernel

def env28352 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,49305,262144,1025,32769,58516,272512,62612,41350,8328,17,56577,24980,17664,324620,28936,305160,257,54561,13445,63108]

theorem envBound28352 : H12AffineFastState.Bounded env28352 := by
  intro p hp
  have h : env28352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28351_28352 : H12AffineEnvironment.transform 15 40970 env28351 = env28352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env28351 == env28352) = true)

theorem identity28352 : scanCanonicalize (H12AffineFastState.compose env28352 (packedSelected [1,5,8,10,18,23,24,31] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound28352 : packedSelected [1,5,8,10,18,23,24,31] rootPS < 2^1333 := by decide +kernel

def env28353 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,49305,56357,1025,32769,58516,62629,62612,41350,8328,17,56577,24980,17664,10281,28936,29741,257,54561,13445,63108]

theorem envBound28353 : H12AffineFastState.Bounded env28353 := by
  intro p hp
  have h : env28353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28352_28353 : H12AffineEnvironment.transform 17 56357 env28352 = env28353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env28352 == env28353) = true)

theorem identity28353 : scanCanonicalize (H12AffineFastState.compose env28353 (packedSelected [0,1,2,3,5,6,7,8,9,12,16,17,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28353 : packedSelected [0,1,2,3,5,6,7,8,9,12,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env28354 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,49169,56357,1025,32769,58396,62509,62492,41230,8192,17,56577,24860,17664,10281,28936,29741,257,54561,13325,62988]

theorem envBound28354 : H12AffineFastState.Bounded env28354 := by
  intro p hp
  have h : env28354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28353_28354 : H12AffineEnvironment.transform 6 8 env28353 = env28354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28353 == env28354) = true)

theorem identity28354 : scanCanonicalize (H12AffineFastState.compose env28354 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound28354 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28355 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21541,29743,5172,2048,1025,21540,12345,8200,8249,29995,8192,17,2340,24860,17664,10281,28936,29741,257,260,13325,8745]

theorem envBound28355 : H12AffineFastState.Bounded env28355 := by
  intro p hp
  have h : env28355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28354_28355 : H12AffineEnvironment.transform 14 21541 env28354 = env28355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env28354 == env28355) = true)

theorem identity28355 : scanCanonicalize (H12AffineFastState.compose env28355 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28355 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28356 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21541,21795,5172,2048,1025,21540,4405,260,309,21543,268,17,2340,16400,17664,2341,20484,21793,257,260,5377,805]

theorem envBound28356 : H12AffineFastState.Bounded env28356 := by
  intro p hp
  have h : env28356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28355_28356 : H12AffineEnvironment.transform 12 268 env28355 = env28356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28355 == env28356) = true)

theorem identity28356 : scanCanonicalize (H12AffineFastState.compose env28356 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28356 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28357 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,293,35,5172,2048,1025,292,4405,260,309,295,268,17,2340,5392,4096,2341,1284,33,257,260,5377,805]

theorem envBound28357 : H12AffineFastState.Bounded env28357 := by
  intro p hp
  have h : env28357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28356_28357 : H12AffineEnvironment.transform 13 5376 env28356 = env28357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28356 == env28357) = true)

theorem identity28357 : scanCanonicalize (H12AffineFastState.compose env28357 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound28357 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env28358 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,268,5376,293,35,5172,1076,1025,292,4405,260,309,295,268,17,1296,5392,4096,1297,1284,33,257,260,5377,805]

theorem envBound28358 : H12AffineFastState.Bounded env28358 := by
  intro p hp
  have h : env28358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28357_28358 : H12AffineEnvironment.transform 10 1076 env28357 = env28358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env28357 == env28358) = true)

theorem identity28358 : scanCanonicalize (H12AffineFastState.compose env28358 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound28358 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28359 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,1280,268,0,293,35,308,1076,1025,292,1077,260,309,295,268,17,1296,16,1280,1297,1284,33,257,260,1,805]

theorem envBound28359 : H12AffineFastState.Bounded env28359 := by
  intro p hp
  have h : env28359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28358_28359 : H12AffineEnvironment.transform 11 1280 env28358 = env28359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env28358 == env28359) = true)

theorem identity28359 : scanCanonicalize (H12AffineFastState.compose env28359 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28359 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env28360 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,0,0,35,17,1076,1025,1,1077,33,16,2,41,17,1077,16,1061,1076,1057,33,36,33,1,512]

theorem envBound28360 : H12AffineFastState.Bounded env28360 := by
  intro p hp
  have h : env28360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28359_28360 : H12AffineEnvironment.transform 7 37 env28359 = env28360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28359 == env28360) = true)

theorem identity28360 : scanCanonicalize (H12AffineFastState.compose env28360 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28361 : List Nat := [2,4,8,1,32,0,8,37,512,1024,1061,1061,41,0,0,35,0,1061,1025,1,1060,33,1,2,41,0,1060,1,1061,1061,1057,33,36,33,1,512]

theorem envBound28361 : H12AffineFastState.Bounded env28361 := by
  intro p hp
  have h : env28361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28360_28361 : H12AffineEnvironment.transform 3 1 env28360 = env28361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28360 == env28361) = true)

theorem identity28361 : scanCanonicalize (H12AffineFastState.compose env28361 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound28361 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28362 : List Nat := [2,4,8,1,32,0,8,37,512,15,42,42,41,0,0,35,0,42,14,1,43,33,1,2,41,0,43,1,42,42,46,33,36,33,1,512]

theorem envBound28362 : H12AffineFastState.Bounded env28362 := by
  intro p hp
  have h : env28362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28361_28362 : H12AffineEnvironment.transform 9 15 env28361 = env28362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env28361 == env28362) = true)

theorem identity28362 : scanCanonicalize (H12AffineFastState.compose env28362 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound28362 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28363 : List Nat := [2,4,8,1,32,0,8,37,42,15,42,42,41,0,0,35,0,42,14,1,43,33,1,2,41,0,43,1,42,42,46,33,36,33,1,42]

theorem envBound28363 : H12AffineFastState.Bounded env28363 := by
  intro p hp
  have h : env28363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28362_28363 : H12AffineEnvironment.transform 8 42 env28362 = env28363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env28362 == env28363) = true)

theorem identity28363 : scanCanonicalize (H12AffineFastState.compose env28363 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28364 : List Nat := [2,3,8,1,32,0,8,34,42,8,42,42,41,0,0,35,0,42,9,1,43,33,1,2,41,0,43,1,42,42,41,33,35,33,1,42]

theorem envBound28364 : H12AffineFastState.Bounded env28364 := by
  intro p hp
  have h : env28364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28363_28364 : H12AffineEnvironment.transform 1 3 env28363 = env28364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28363 == env28364) = true)

theorem identity28364 : scanCanonicalize (H12AffineFastState.compose env28364 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28364 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28365 : List Nat := [2,3,8,1,0,0,8,2,10,8,10,10,9,0,0,3,0,10,9,1,11,1,1,2,9,0,11,1,10,10,9,1,3,1,1,10]

theorem envBound28365 : H12AffineFastState.Bounded env28365 := by
  intro p hp
  have h : env28365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28364_28365 : H12AffineEnvironment.transform 4 0 env28364 = env28365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28364 == env28365) = true)

theorem identity28365 : scanCanonicalize (H12AffineFastState.compose env28365 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound28365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28366 : List Nat := [2,3,1,1,0,0,1,2,3,1,3,3,0,0,0,3,0,3,0,1,2,1,1,2,0,0,2,1,3,3,0,1,3,1,1,3]

theorem envBound28366 : H12AffineFastState.Bounded env28366 := by
  intro p hp
  have h : env28366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28365_28366 : H12AffineEnvironment.transform 2 1 env28365 = env28366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env28365 == env28366) = true)

def env28367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97546,115151,17664,2363593,119042,329731,257,2199999,2191387,63189]

theorem envBound28367 : H12AffineFastState.Bounded env28367 := by
  intro p hp
  have h : env28367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28345_28367 : H12AffineEnvironment.transform 21 272513 env28345 = env28367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env28345 == env28367) = true)

theorem identity28367 : scanCanonicalize (H12AffineFastState.compose env28367 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28367 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,262144,1025,29909,2097152,272513,2101329,2114883,8328,64,97546,79131,17664,2363593,75222,329731,257,2188651,2191387,513]

theorem envBound28368 : H12AffineFastState.Bounded env28368 := by
  intro p hp
  have h : env28368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28367_28368 : H12AffineEnvironment.transform 14 29908 env28367 = env28368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28367 == env28368) = true)

def env28369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,32240,1025,29909,2097152,21873,2101329,2114883,8328,64,97546,79131,17664,2125113,75222,95731,257,2188651,2191387,513]

theorem envBound28369 : H12AffineFastState.Bounded env28369 := by
  intro p hp
  have h : env28369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28368_28369 : H12AffineEnvironment.transform 17 32240 env28368 = env28369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env28368 == env28369) = true)

def env28370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32120,1025,29789,2097152,21873,2101329,2114883,8192,64,97546,79131,17664,2125113,75102,95611,257,2188651,2191387,513]

theorem envBound28370 : H12AffineFastState.Bounded env28370 := by
  intro p hp
  have h : env28370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28369_28370 : H12AffineEnvironment.transform 6 8 env28369 = env28370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28369 == env28370) = true)

theorem identity28370 : scanCanonicalize (H12AffineFastState.compose env28370 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 69731) := by decide +kernel

theorem selectedBound28370 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28371 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13389,32120,1025,29789,69731,21873,65586,87328,8192,64,97546,79131,17664,97626,75102,95611,257,29960,24696,513]

theorem envBound28371 : H12AffineFastState.Bounded env28371 := by
  intro p hp
  have h : env28371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28370_28371 : H12AffineEnvironment.transform 20 69731 env28370 = env28371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69731 env28370 == env28371) = true)

theorem identity28371 : scanCanonicalize (H12AffineFastState.compose env28371 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound28371 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env28372 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,1378,13389,32120,1025,29789,5377,21873,1360,20546,8192,64,30824,12409,17664,30776,8252,28697,257,29960,24696,513]

theorem envBound28372 : H12AffineFastState.Bounded env28372 := by
  intro p hp
  have h : env28372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28371_28372 : H12AffineEnvironment.transform 15 1378 env28371 = env28372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env28371 == env28372) = true)

theorem identity28372 : scanCanonicalize (H12AffineFastState.compose env28372 (packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound28372 : packedSelected [2,3,4,5,6,10,12,15,16,22] rootPS < 2^1333 := by decide +kernel

def env28373 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,9576,1378,13389,11340,1025,9577,5377,1093,1360,374,8192,64,10588,12409,5172,10508,8252,8493,257,9276,12620,513]

theorem envBound28373 : H12AffineFastState.Bounded env28373 := by
  intro p hp
  have h : env28373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28372_28373 : H12AffineEnvironment.transform 13 4404 env28372 = env28373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env28372 == env28373) = true)

theorem identity28373 : scanCanonicalize (H12AffineFastState.compose env28373 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound28373 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env28374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,4404,1344,1378,5221,3172,1025,1345,5377,1093,1360,374,40,64,2420,4177,5172,2340,20,261,257,1044,4452,513]

theorem envBound28374 : H12AffineFastState.Bounded env28374 := by
  intro p hp
  have h : env28374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28373_28374 : H12AffineEnvironment.transform 12 40 env28373 = env28374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env28373 == env28374) = true)

theorem identity28374 : scanCanonicalize (H12AffineFastState.compose env28374 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28374 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env28375 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,40,4112,1124,1094,5221,3172,1025,1125,5157,1093,1140,82,40,64,2128,4177,5172,2048,20,33,37,1044,4160,513]

theorem envBound28375 : H12AffineFastState.Bounded env28375 := by
  intro p hp
  have h : env28375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28374_28375 : H12AffineEnvironment.transform 7 36 env28374 = env28375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28374 == env28375) = true)

theorem identity28375 : scanCanonicalize (H12AffineFastState.compose env28375 (packedSelected [2,4,5,6,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound28375 : packedSelected [2,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28376 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,2113,40,2129,1124,1094,3108,3172,1025,1125,3172,1093,1140,82,40,64,2128,2064,3189,2048,20,33,37,1044,2049,513]

theorem envBound28376 : H12AffineFastState.Bounded env28376 := by
  intro p hp
  have h : env28376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28375_28376 : H12AffineEnvironment.transform 11 2113 env28375 = env28376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env28375 == env28376) = true)

theorem identity28376 : scanCanonicalize (H12AffineFastState.compose env28376 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound28376 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env28377 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,2113,40,2129,1,35,2113,2049,100,0,2049,32,17,82,40,64,2128,2064,2064,2048,20,33,37,113,2049,513]

theorem envBound28377 : H12AffineFastState.Bounded env28377 := by
  intro p hp
  have h : env28377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28376_28377 : H12AffineEnvironment.transform 9 101 env28376 = env28377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env28376 == env28377) = true)

theorem identity28377 : scanCanonicalize (H12AffineFastState.compose env28377 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound28377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28378 : List Nat := [2,4,8,16,32,64,8,36,512,101,112,49,40,33,1,35,49,113,100,0,113,32,17,82,40,64,32,96,96,112,20,33,37,113,113,513]

theorem envBound28378 : H12AffineFastState.Bounded env28378 := by
  intro p hp
  have h : env28378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28377_28378 : H12AffineEnvironment.transform 10 112 env28377 = env28378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env28377 == env28378) = true)

theorem identity28378 : scanCanonicalize (H12AffineFastState.compose env28378 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28378 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env28379 : List Nat := [2,4,8,16,32,64,8,36,1,101,112,49,40,33,1,35,49,113,100,0,113,32,17,82,40,64,32,96,96,112,20,33,37,113,113,0]

theorem envBound28379 : H12AffineFastState.Bounded env28379 := by
  intro p hp
  have h : env28379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28378_28379 : H12AffineEnvironment.transform 8 1 env28378 = env28379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28378 == env28379) = true)

theorem identity28379 : scanCanonicalize (H12AffineFastState.compose env28379 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28379 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28380 : List Nat := [2,4,8,1,32,64,8,36,1,101,97,32,40,33,1,35,32,96,100,0,96,32,0,67,40,64,32,96,96,97,5,33,37,96,96,0]

theorem envBound28380 : H12AffineFastState.Bounded env28380 := by
  intro p hp
  have h : env28380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28379_28380 : H12AffineEnvironment.transform 3 1 env28379 = env28380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28379 == env28380) = true)

theorem identity28380 : scanCanonicalize (H12AffineFastState.compose env28380 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28381 : List Nat := [2,4,8,1,1,64,8,5,1,68,64,1,9,0,1,2,1,65,69,0,65,1,0,67,9,64,1,65,65,64,5,0,4,65,65,0]

theorem envBound28381 : H12AffineFastState.Bounded env28381 := by
  intro p hp
  have h : env28381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28380_28381 : H12AffineEnvironment.transform 4 1 env28380 = env28381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28380 == env28381) = true)

end H12CloudChart1