import H12CloudChart1Data214

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound54441 : H12AffineFastState.Bounded env54441 := by
  intro p hp
  have h : env54441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54406_54441 : H12AffineEnvironment.transform 21 272513 env54406 = env54441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54406 == env54441) = true)

theorem identity54441 : scanCanonicalize (H12AffineFastState.compose env54441 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound54441 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,58517,272513,62660,41431,8328,64,121942,115150,17664,283904,119043,329731,257,95530,103566,63188]

theorem envBound54442 : H12AffineFastState.Bounded env54442 := by
  intro p hp
  have h : env54442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54441_54442 : H12AffineEnvironment.transform 20 58517 env54441 = env54442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env54441 == env54442) = true)

theorem identity54442 : scanCanonicalize (H12AffineFastState.compose env54442 (packedSelected [4,7,9,14,17,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54442 : packedSelected [4,7,9,14,17,27,35] rootPS < 2^1333 := by decide +kernel

def env54443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,25028,262144,1025,32769,58517,272513,62660,41431,8328,64,64604,57796,17664,283904,61705,272393,257,21792,46212,63188]

theorem envBound54443 : H12AffineFastState.Bounded env54443 := by
  intro p hp
  have h : env54443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54442_54443 : H12AffineEnvironment.transform 15 8202 env54442 = env54443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54442 == env54443) = true)

theorem identity54443 : scanCanonicalize (H12AffineFastState.compose env54443 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound54443 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env54444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,25028,262144,1025,29908,4160,272513,17,21762,8328,64,2185,5393,17664,283904,1500,272393,257,21792,16465,513]

theorem envBound54444 : H12AffineFastState.Bounded env54444 := by
  intro p hp
  have h : env54444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54443_54444 : H12AffineEnvironment.transform 14 29909 env54443 = env54444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54443 == env54444) = true)

theorem identity54444 : scanCanonicalize (H12AffineFastState.compose env54444 (packedSelected [4,7,9,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound54444 : packedSelected [4,7,9,17,27] rootPS < 2^1333 := by decide +kernel

def env54445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,81,8202,5440,262144,1025,80,4160,272513,17,8582,8328,64,2185,5393,12676,270724,1500,272393,257,8612,13525,513]

theorem envBound54445 : H12AffineFastState.Bounded env54445 := by
  intro p hp
  have h : env54445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54444_54445 : H12AffineEnvironment.transform 13 13444 env54444 = env54445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env54444 == env54445) = true)

theorem identity54445 : scanCanonicalize (H12AffineFastState.compose env54445 (packedSelected [1,2,5,6,8,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54445 : packedSelected [1,2,5,6,8,17,24] rootPS < 2^1333 := by decide +kernel

def env54446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,81,262,5440,262144,1025,80,4160,264589,17,138,388,64,2185,5393,4232,262280,1500,264453,257,168,5593,513]

theorem envBound54446 : H12AffineFastState.Bounded env54446 := by
  intro p hp
  have h : env54446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54445_54446 : H12AffineEnvironment.transform 12 268 env54445 = env54446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54445 == env54446) = true)

theorem identity54446 : scanCanonicalize (H12AffineFastState.compose env54446 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound54446 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,81,262,5440,2340,1025,80,4160,169,17,138,388,64,2185,5393,4232,2476,1500,33,257,168,5593,513]

theorem envBound54447 : H12AffineFastState.Bounded env54447 := by
  intro p hp
  have h : env54447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54446_54447 : H12AffineEnvironment.transform 17 2340 env54446 = env54447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env54446 == env54447) = true)

theorem identity54447 : scanCanonicalize (H12AffineFastState.compose env54447 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54447 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env54448 : List Nat := [2,4,8,16,32,64,128,256,16,1024,2048,4096,268,5512,81,262,5440,2340,1025,80,4160,169,17,138,388,64,2185,5393,4232,2476,1500,33,257,168,5593,17]

theorem envBound54448 : H12AffineFastState.Bounded env54448 := by
  intro p hp
  have h : env54448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54447_54448 : H12AffineEnvironment.transform 8 16 env54447 = env54448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54447 == env54448) = true)

theorem identity54448 : scanCanonicalize (H12AffineFastState.compose env54448 (packedSelected [2,3,5,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54448 : packedSelected [2,3,5,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env54449 : List Nat := [2,4,8,16,32,64,128,5,16,1024,2048,4096,9,5261,81,3,5189,2081,1025,80,4160,169,17,138,129,64,2185,5140,4232,2217,1241,33,4,168,5340,17]

theorem envBound54449 : H12AffineFastState.Bounded env54449 := by
  intro p hp
  have h : env54449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54448_54449 : H12AffineEnvironment.transform 7 5 env54448 = env54449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54448 == env54449) = true)

theorem identity54449 : scanCanonicalize (H12AffineFastState.compose env54449 (packedSelected [1,2,4,8,9,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3228) := by decide +kernel

theorem selectedBound54449 : packedSelected [1,2,4,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54450 : List Nat := [2,4,8,16,32,64,128,5,16,1024,2048,3228,9,2065,81,3,2265,2081,1025,80,3292,169,17,138,129,64,2185,2184,3092,2217,1241,33,4,168,2112,17]

theorem envBound54450 : H12AffineFastState.Bounded env54450 := by
  intro p hp
  have h : env54450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54449_54450 : H12AffineEnvironment.transform 11 3228 env54449 = env54450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3228 env54449 == env54450) = true)

theorem identity54450 : scanCanonicalize (H12AffineFastState.compose env54450 (packedSelected [1,2,3,4,5,7,8,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54450 : packedSelected [1,2,3,4,5,7,8,12,18] rootPS < 2^1333 := by decide +kernel

def env54451 : List Nat := [2,4,8,16,32,16,128,5,16,1024,2048,3228,9,2065,1,3,2185,2081,1025,0,3212,169,17,138,129,16,2185,2184,3092,2217,1161,33,4,168,2064,17]

theorem envBound54451 : H12AffineFastState.Bounded env54451 := by
  intro p hp
  have h : env54451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54450_54451 : H12AffineEnvironment.transform 5 16 env54450 = env54451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54450 == env54451) = true)

theorem identity54451 : scanCanonicalize (H12AffineFastState.compose env54451 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound54451 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54452 : List Nat := [2,4,8,16,32,16,128,5,16,1024,137,1045,9,152,1,3,0,168,1025,0,1029,169,17,138,129,16,0,1,1181,32,1161,33,4,168,153,17]

theorem envBound54452 : H12AffineFastState.Bounded env54452 := by
  intro p hp
  have h : env54452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54451_54452 : H12AffineEnvironment.transform 10 137 env54451 = env54452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env54451 == env54452) = true)

theorem identity54452 : scanCanonicalize (H12AffineFastState.compose env54452 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54452 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env54453 : List Nat := [2,4,8,16,32,16,128,5,16,4,137,17,9,152,1,3,0,168,5,0,1,169,17,138,129,16,0,1,153,32,141,33,4,168,153,17]

theorem envBound54453 : H12AffineFastState.Bounded env54453 := by
  intro p hp
  have h : env54453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54452_54453 : H12AffineEnvironment.transform 9 4 env54452 = env54453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54452 == env54453) = true)

def env54454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066246,115151,10507601,8692165,10600787,4268163,257,8487407,8478795,10544772]

theorem envBound54454 : H12AffineFastState.Bounded env54454 := by
  intro p hp
  have h : env54454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54321_54454 : H12AffineEnvironment.transform 16 25029 env54321 = env54454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env54321 == env54454) = true)

def env54455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4584662,115151,17665,2404757,119043,4268163,257,2199999,2191387,63188]

theorem envBound54455 : H12AffineFastState.Bounded env54455 := by
  intro p hp
  have h : env54455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54454_54455 : H12AffineEnvironment.transform 22 2101328 env54454 = env54455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env54454 == env54455) = true)

def env54456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,121942,115151,17665,2404757,119043,329731,257,2199999,2191387,63188]

theorem envBound54456 : H12AffineFastState.Bounded env54456 := by
  intro p hp
  have h : env54456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54455_54456 : H12AffineEnvironment.transform 21 272512 env54455 = env54456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54455 == env54456) = true)

theorem identity54456 : scanCanonicalize (H12AffineFastState.compose env54456 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound54456 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,115871,272512,120015,98780,8328,64,121942,115151,17665,357642,119043,329731,257,21792,46212,63188]

theorem envBound54457 : H12AffineFastState.Bounded env54457 := by
  intro p hp
  have h : env54457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54456_54457 : H12AffineEnvironment.transform 20 115871 env54456 = env54457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env54456 == env54457) = true)

def env54458 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,115871,272512,119967,98700,8328,16,121862,115103,17665,357642,119043,329731,257,21792,46212,63108]

theorem envBound54458 : H12AffineFastState.Bounded env54458 := by
  intro p hp
  have h : env54458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54457_54458 : H12AffineEnvironment.transform 5 16 env54457 = env54458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54457 == env54458) = true)

theorem identity54458 : scanCanonicalize (H12AffineFastState.compose env54458 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100523) := by decide +kernel

theorem selectedBound54458 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env54459 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,100523,1025,32769,115871,106539,119967,98700,8328,16,121862,115103,17665,64929,119043,32936,257,21792,46212,63108]

theorem envBound54459 : H12AffineFastState.Bounded env54459 := by
  intro p hp
  have h : env54459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54458_54459 : H12AffineEnvironment.transform 17 100523 env54458 = env54459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100523 env54458 == env54459) = true)

theorem identity54459 : scanCanonicalize (H12AffineFastState.compose env54459 (packedSelected [0,1,3,4,7,17,18,22,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound54459 : packedSelected [0,1,3,4,7,17,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env54460 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,97326,1025,29828,77850,87214,73754,95497,8328,16,75907,79130,17665,2340,75142,29741,257,21792,16385,513]

theorem envBound54460 : H12AffineFastState.Bounded env54460 := by
  intro p hp
  have h : env54460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54459_54460 : H12AffineEnvironment.transform 14 29829 env54459 = env54460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env54459 == env54460) = true)

theorem identity54460 : scanCanonicalize (H12AffineFastState.compose env54460 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54460 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env54461 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,65536,13460,76079,1025,8581,77850,65967,73754,73736,8328,16,75907,79130,4096,2340,75142,8492,257,33,5376,513]

theorem envBound54461 : H12AffineFastState.Bounded env54461 := by
  intro p hp
  have h : env54461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54460_54461 : H12AffineEnvironment.transform 13 5377 env54460 = env54461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54460 == env54461) = true)

theorem identity54461 : scanCanonicalize (H12AffineFastState.compose env54461 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound54461 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env54462 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,398,13460,10401,1025,8581,12692,33,8596,8582,8328,16,10509,13460,4096,2340,9224,8492,257,33,5376,513]

theorem envBound54462 : H12AffineFastState.Bounded env54462 := by
  intro p hp
  have h : env54462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54461_54462 : H12AffineEnvironment.transform 15 398 env54461 = env54462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env54461 == env54462) = true)

theorem identity54462 : scanCanonicalize (H12AffineFastState.compose env54462 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54462 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env54463 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,136,398,5528,2477,1025,137,4248,33,152,138,388,16,2049,5528,4096,2340,1284,32,257,33,5376,513]

theorem envBound54463 : H12AffineFastState.Bounded env54463 := by
  intro p hp
  have h : env54463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54462_54463 : H12AffineEnvironment.transform 12 268 env54462 = env54463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54462 == env54463) = true)

theorem identity54463 : scanCanonicalize (H12AffineFastState.compose env54463 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound54463 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54464 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,268,4248,136,398,4097,2477,408,137,4248,33,152,138,388,16,2049,4097,4096,2340,157,32,257,33,4249,513]

theorem envBound54464 : H12AffineFastState.Bounded env54464 := by
  intro p hp
  have h : env54464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54463_54464 : H12AffineEnvironment.transform 9 409 env54463 = env54464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env54463 == env54464) = true)

theorem identity54464 : scanCanonicalize (H12AffineFastState.compose env54464 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound54464 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env54465 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,2492,268,2340,136,398,2493,2477,408,137,2340,33,152,138,388,16,2049,2493,2492,2340,157,32,257,33,2341,513]

theorem envBound54465 : H12AffineFastState.Bounded env54465 := by
  intro p hp
  have h : env54465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54464_54465 : H12AffineEnvironment.transform 11 2492 env54464 = env54465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env54464 == env54465) = true)

theorem identity54465 : scanCanonicalize (H12AffineFastState.compose env54465 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54465 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env54466 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2356,268,2340,0,262,2357,2341,272,1,2340,33,16,2,268,16,2049,2357,2356,2340,21,32,257,33,2341,513]

theorem envBound54466 : H12AffineFastState.Bounded env54466 := by
  intro p hp
  have h : env54466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54465_54466 : H12AffineEnvironment.transform 6 8 env54465 = env54466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54465 == env54466) = true)

theorem identity54466 : scanCanonicalize (H12AffineFastState.compose env54466 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54466 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54467 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2064,40,2048,0,34,2065,2049,52,1,2048,33,16,2,40,16,2049,2065,2064,2048,21,32,37,33,2049,513]

theorem envBound54467 : H12AffineFastState.Bounded env54467 := by
  intro p hp
  have h : env54467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54466_54467 : H12AffineEnvironment.transform 7 36 env54466 = env54467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54466 == env54467) = true)

theorem identity54467 : scanCanonicalize (H12AffineFastState.compose env54467 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54467 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54468 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,40,48,0,34,33,49,52,1,48,33,16,2,40,16,49,33,32,48,21,32,37,33,49,513]

theorem envBound54468 : H12AffineFastState.Bounded env54468 := by
  intro p hp
  have h : env54468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54467_54468 : H12AffineEnvironment.transform 10 48 env54467 = env54468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54467 == env54468) = true)

def leafEnv54468 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,40,48,0,34,33,49,52,1,48,33,16,2,20,40,1,16,49,33,32,48,21,32,37,33,5,34,49,513,1,49,0]

def active54468 : List Nat := [0,1,2,3,4,8]

def tree54468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54468 : H12WitnessSearch.Good tree54468 := H12GlobalWitnessIndex.good

theorem leafIdentity54468 : H12AffineFastState.composeSystem env54468 rootObs = leafEnv54468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54468 rootObs == leafEnv54468) = true)

theorem terminalChecked54468 : H12PackedTerminal.terminalCheckFast leafEnv54468 active54468 tree54468 = true := by decide +kernel

def env54469 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,115871,272512,119966,98701,8328,17,121863,115102,17665,357642,119043,329731,257,21792,46212,63109]

theorem envBound54469 : H12AffineFastState.Bounded env54469 := by
  intro p hp
  have h : env54469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54457_54469 : H12AffineEnvironment.transform 5 17 env54457 = env54469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54457 == env54469) = true)

theorem identity54469 : scanCanonicalize (H12AffineFastState.compose env54469 (packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound54469 : packedSelected [4,5,7,8,9,11,12,14,15,19,24,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env54470 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,122147,1025,32769,115871,128419,119966,98701,8328,17,121863,115102,17665,43049,119043,54560,257,21792,46212,63109]

theorem envBound54470 : H12AffineFastState.Bounded env54470 := by
  intro p hp
  have h : env54470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54469_54470 : H12AffineEnvironment.transform 17 122147 env54469 = env54470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env54469 == env54470) = true)

theorem identity54470 : scanCanonicalize (H12AffineFastState.compose env54470 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound54470 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54471 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54279,24980,2340,1025,32769,4248,8612,153,21898,8328,17,2048,5529,17665,43049,1284,54560,257,21792,46212,63109]

theorem envBound54471 : H12AffineFastState.Bounded env54471 := by
  intro p hp
  have h : env54471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54470_54471 : H12AffineEnvironment.transform 15 54279 env54470 = env54471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env54470 == env54471) = true)

theorem identity54471 : scanCanonicalize (H12AffineFastState.compose env54471 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound54471 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54472 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8323,24980,2340,1025,29829,4248,8612,153,21898,8328,17,2048,5529,17665,23725,1284,8612,257,21792,16384,513]

theorem envBound54472 : H12AffineFastState.Bounded env54472 := by
  intro p hp
  have h : env54472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54471_54472 : H12AffineEnvironment.transform 14 29828 env54471 = env54472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env54471 == env54472) = true)

theorem identity54472 : scanCanonicalize (H12AffineFastState.compose env54472 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54472 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env54473 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,399,16536,2340,1025,21897,4248,168,153,21898,388,17,2048,5529,17665,23725,1284,168,257,21792,16384,513]

theorem envBound54473 : H12AffineFastState.Bounded env54473 := by
  intro p hp
  have h : env54473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54472_54473 : H12AffineEnvironment.transform 12 268 env54472 = env54473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54472 == env54473) = true)

theorem identity54473 : scanCanonicalize (H12AffineFastState.compose env54473 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54473 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54474 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,262,16401,2340,1025,21760,4113,33,16,21763,269,17,2048,5392,17665,23588,1284,33,257,21792,16384,513]

theorem envBound54474 : H12AffineFastState.Bounded env54474 := by
  intro p hp
  have h : env54474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54473_54474 : H12AffineEnvironment.transform 6 9 env54473 = env54474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54473 == env54474) = true)

theorem identity54474 : scanCanonicalize (H12AffineFastState.compose env54474 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54474 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54475 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,292,262,5172,2340,1025,293,4113,33,16,294,269,17,2048,5392,4388,2049,1284,33,257,261,5157,513]

theorem envBound54475 : H12AffineFastState.Bounded env54475 := by
  intro p hp
  have h : env54475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54474_54475 : H12AffineEnvironment.transform 13 5157 env54474 = env54475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54474 == env54475) = true)

theorem identity54475 : scanCanonicalize (H12AffineFastState.compose env54475 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54475 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54476 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,1,35,5172,2049,1025,0,4113,33,16,3,40,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound54476 : H12AffineFastState.Bounded env54476 := by
  intro p hp
  have h : env54476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54475_54476 : H12AffineEnvironment.transform 7 37 env54475 = env54476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54475 == env54476) = true)

def env54477 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,41,1045,1,35,1028,2049,1025,0,33,33,16,3,40,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound54477 : H12AffineFastState.Bounded env54477 := by
  intro p hp
  have h : env54477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54476_54477 : H12AffineEnvironment.transform 11 48 env54476 = env54477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54476 == env54477) = true)

def env54478 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,41,1044,1,35,1029,2049,1025,0,32,33,16,3,40,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound54478 : H12AffineFastState.Bounded env54478 := by
  intro p hp
  have h : env54478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54476_54478 : H12AffineEnvironment.transform 11 49 env54476 = env54478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54476 == env54478) = true)

theorem identity54478 : scanCanonicalize (H12AffineFastState.compose env54478 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54479 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,41,33,1,35,48,2049,52,0,32,33,16,3,40,17,2048,49,48,2049,20,33,36,32,33,513]

theorem envBound54479 : H12AffineFastState.Bounded env54479 := by
  intro p hp
  have h : env54479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54478_54479 : H12AffineEnvironment.transform 9 53 env54478 = env54479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54478 == env54479) = true)

def env54480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,121943,115151,17665,2404757,119043,329730,257,2199999,2191387,63188]

theorem envBound54480 : H12AffineFastState.Bounded env54480 := by
  intro p hp
  have h : env54480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54455_54480 : H12AffineEnvironment.transform 21 272513 env54455 = env54480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54455 == env54480) = true)

theorem identity54480 : scanCanonicalize (H12AffineFastState.compose env54480 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound54480 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,25029,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,2185,5393,17665,2404757,1501,318684,257,2114913,2139333,63188]

theorem envBound54481 : H12AffineFastState.Bounded env54481 := by
  intro p hp
  have h : env54481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54480_54481 : H12AffineEnvironment.transform 15 54494 env54480 = env54481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env54480 == env54481) = true)

theorem identity54481 : scanCanonicalize (H12AffineFastState.compose env54481 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound54481 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25029,262144,1025,29908,2097152,272513,2101328,2114883,8328,64,2185,5393,17665,2377024,1501,272393,257,2114913,2117648,513]

theorem envBound54482 : H12AffineFastState.Bounded env54482 := by
  intro p hp
  have h : env54482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54481_54482 : H12AffineEnvironment.transform 14 29909 env54481 = env54482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54481 == env54482) = true)

theorem identity54482 : scanCanonicalize (H12AffineFastState.compose env54482 (packedSelected [7,12,14,15,16,27,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound54482 : packedSelected [7,12,14,15,16,27,38,41] rootPS < 2^1333 := by decide +kernel

def env54483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25029,262144,1025,29908,25629,272513,29773,8542,8328,64,2185,5393,17665,270685,1501,272393,257,8572,13325,513]

theorem envBound54483 : H12AffineFastState.Bounded env54483 := by
  intro p hp
  have h : env54483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54482_54483 : H12AffineEnvironment.transform 20 25629 env54482 = env54483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env54482 == env54483) = true)

theorem identity54483 : scanCanonicalize (H12AffineFastState.compose env54483 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound54483 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env54484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25029,10400,1025,29908,25629,33,29773,8542,8328,64,2185,5393,17665,2557,1501,169,257,8572,13325,513]

theorem envBound54484 : H12AffineFastState.Bounded env54484 := by
  intro p hp
  have h : env54484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54483_54484 : H12AffineEnvironment.transform 17 10400 env54483 = env54484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env54483 == env54484) = true)

theorem identity54484 : scanCanonicalize (H12AffineFastState.compose env54484 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound54484 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env54485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,2129,15492,8203,10644,10400,1025,15493,11340,33,15388,8542,8328,64,2185,5393,3408,2557,1501,169,257,8572,13325,513]

theorem envBound54485 : H12AffineFastState.Bounded env54485 := by
  intro p hp
  have h : env54485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54484_54485 : H12AffineEnvironment.transform 13 2129 env54484 = env54485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env54484 == env54485) = true)

theorem identity54485 : scanCanonicalize (H12AffineFastState.compose env54485 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 6548) := by decide +kernel

theorem selectedBound54485 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env54486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,6548,2129,1296,6559,4096,4404,1025,1297,5592,33,1416,6346,6428,64,2185,5393,3408,2557,1501,169,257,6376,3481,513]

theorem envBound54486 : H12AffineFastState.Bounded env54486 := by
  intro p hp
  have h : env54486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54485_54486 : H12AffineEnvironment.transform 12 6548 env54485 = env54486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6548 env54485 == env54486) = true)

theorem identity54486 : scanCanonicalize (H12AffineFastState.compose env54486 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound54486 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env54487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,1101,2129,1296,1094,3545,3309,1025,1297,2049,33,1416,1299,1221,64,2185,2248,3408,2557,1501,169,257,1329,3481,513]

theorem envBound54487 : H12AffineFastState.Bounded env54487 := by
  intro p hp
  have h : env54487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54486_54487 : H12AffineEnvironment.transform 11 3545 env54486 = env54487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env54486 == env54487) = true)

theorem identity54487 : scanCanonicalize (H12AffineFastState.compose env54487 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound54487 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54488 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,2341,177,2129,492,186,2341,2065,253,493,2049,33,372,495,57,64,2185,2248,2476,2557,289,169,257,461,2405,513]

theorem envBound54488 : H12AffineFastState.Bounded env54488 := by
  intro p hp
  have h : env54488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54487_54488 : H12AffineEnvironment.transform 9 252 env54487 = env54488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env54487 == env54488) = true)

theorem identity54488 : scanCanonicalize (H12AffineFastState.compose env54488 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound54488 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54489 : List Nat := [2,4,8,16,32,64,128,237,512,252,2048,2248,177,2129,1,186,2248,2065,253,0,2049,33,153,2,57,64,2185,2248,2113,2064,204,169,236,32,2184,513]

theorem envBound54489 : H12AffineFastState.Bounded env54489 := by
  intro p hp
  have h : env54489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54488_54489 : H12AffineEnvironment.transform 7 237 env54488 = env54489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env54488 == env54489) = true)

theorem identity54489 : scanCanonicalize (H12AffineFastState.compose env54489 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54489 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54490 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,2112,57,2129,1,50,2112,2065,117,0,2049,33,17,2,57,64,2049,2112,2113,2064,68,33,100,32,2048,513]

theorem envBound54490 : H12AffineFastState.Bounded env54490 := by
  intro p hp
  have h : env54490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54489_54490 : H12AffineEnvironment.transform 6 8 env54489 = env54490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54489 == env54490) = true)

theorem identity54490 : scanCanonicalize (H12AffineFastState.compose env54490 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound54490 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54491 : List Nat := [2,4,8,16,32,64,8,101,512,116,90,26,57,11,1,50,26,75,117,0,91,33,17,2,57,64,91,26,27,74,68,33,100,32,90,513]

theorem envBound54491 : H12AffineFastState.Bounded env54491 := by
  intro p hp
  have h : env54491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54490_54491 : H12AffineEnvironment.transform 10 90 env54490 = env54491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env54490 == env54491) = true)

theorem identity54491 : scanCanonicalize (H12AffineFastState.compose env54491 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound54491 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54492 : List Nat := [2,4,8,16,32,64,8,101,25,116,90,26,57,11,1,50,26,75,117,0,91,33,17,2,57,64,91,26,27,74,68,33,100,32,90,24]

theorem envBound54492 : H12AffineFastState.Bounded env54492 := by
  intro p hp
  have h : env54492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54491_54492 : H12AffineEnvironment.transform 8 25 env54491 = env54492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env54491 == env54492) = true)

theorem identity54492 : scanCanonicalize (H12AffineFastState.compose env54492 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54492 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54493 : List Nat := [2,4,8,10,32,64,8,101,3,110,64,0,35,11,1,40,0,75,111,0,65,33,11,2,35,64,65,0,1,74,68,33,100,32,64,2]

theorem envBound54493 : H12AffineFastState.Bounded env54493 := by
  intro p hp
  have h : env54493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54492_54493 : H12AffineEnvironment.transform 3 10 env54492 = env54493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54492 == env54493) = true)

theorem identity54493 : scanCanonicalize (H12AffineFastState.compose env54493 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54493 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54494 : List Nat := [2,4,8,10,11,64,8,78,3,69,64,0,8,11,1,3,0,75,68,0,65,10,11,2,8,64,65,0,1,74,68,10,79,11,64,2]

theorem envBound54494 : H12AffineFastState.Bounded env54494 := by
  intro p hp
  have h : env54494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54493_54494 : H12AffineEnvironment.transform 4 11 env54493 = env54494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54493 == env54494) = true)

theorem identity54494 : scanCanonicalize (H12AffineFastState.compose env54494 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54494 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env54495 : List Nat := [2,4,3,1,0,64,3,69,3,69,64,0,3,0,1,3,0,64,68,0,65,1,0,2,3,64,65,0,1,65,68,1,68,0,64,2]

theorem envBound54495 : H12AffineFastState.Bounded env54495 := by
  intro p hp
  have h : env54495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54494_54495 : H12AffineEnvironment.transform 2 3 env54494 = env54495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54494 == env54495) = true)

theorem identity54495 : scanCanonicalize (H12AffineFastState.compose env54495 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54496 : List Nat := [2,2,3,1,0,64,3,67,3,67,64,0,3,0,1,3,0,64,66,0,65,1,0,2,3,64,65,0,1,65,66,1,66,0,64,2]

theorem envBound54496 : H12AffineFastState.Bounded env54496 := by
  intro p hp
  have h : env54496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54495_54496 : H12AffineEnvironment.transform 1 2 env54495 = env54496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54495 == env54496) = true)

theorem identity54496 : scanCanonicalize (H12AffineFastState.compose env54496 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54497 : List Nat := [2,2,3,1,0,0,3,3,3,3,0,0,3,0,1,3,0,0,2,0,1,1,0,2,3,0,1,0,1,1,2,1,2,0,0,2]

theorem envBound54497 : H12AffineFastState.Bounded env54497 := by
  intro p hp
  have h : env54497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54496_54497 : H12AffineEnvironment.transform 5 0 env54496 = env54497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54496 == env54497) = true)

def env54498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4584663,115151,17664,2404756,119042,4268163,257,2199998,2191386,63189]

theorem envBound54498 : H12AffineFastState.Bounded env54498 := by
  intro p hp
  have h : env54498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54454_54498 : H12AffineEnvironment.transform 22 2101329 env54454 = env54498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env54454 == env54498) = true)

def env54499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,121943,115151,17664,2404756,119042,329731,257,2199998,2191386,63189]

theorem envBound54499 : H12AffineFastState.Bounded env54499 := by
  intro p hp
  have h : env54499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54498_54499 : H12AffineEnvironment.transform 21 272512 env54498 = env54499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54498 == env54499) = true)

theorem identity54499 : scanCanonicalize (H12AffineFastState.compose env54499 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound54499 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,77899,272512,73754,95496,8328,64,121943,115151,17664,360927,119042,329731,257,41461,16465,63189]

theorem envBound54500 : H12AffineFastState.Bounded env54500 := by
  intro p hp
  have h : env54500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54499_54500 : H12AffineEnvironment.transform 20 77899 env54499 = env54500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env54499 == env54500) = true)

def env54501 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,262144,1025,32769,77851,272512,73754,95496,8328,16,121863,115103,17664,360847,119042,329731,257,41381,16385,63109]

theorem envBound54501 : H12AffineFastState.Bounded env54501 := by
  intro p hp
  have h : env54501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54500_54501 : H12AffineEnvironment.transform 5 16 env54500 = env54501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54500 == env54501) = true)

theorem identity54501 : scanCanonicalize (H12AffineFastState.compose env54501 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound54501 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env54502 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24981,23725,1025,32769,77851,29741,73754,95496,8328,16,121863,115103,17664,122146,119042,87214,257,41381,16385,63109]

theorem envBound54502 : H12AffineFastState.Bounded env54502 := by
  intro p hp
  have h : env54502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54501_54502 : H12AffineEnvironment.transform 17 23725 env54501 = env54502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env54501 == env54502) = true)

theorem identity54502 : scanCanonicalize (H12AffineFastState.compose env54502 (packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21646) := by decide +kernel

theorem selectedBound54502 : packedSelected [0,3,4,7,10,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env54503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,21646,24981,23725,1025,32769,25749,29741,29844,8582,8328,16,34953,38161,17664,35244,34188,32,257,41381,16385,63109]

theorem envBound54503 : H12AffineFastState.Bounded env54503 := by
  intro p hp
  have h : env54503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54502_54503 : H12AffineEnvironment.transform 15 21646 env54502 = env54503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21646 env54502 == env54503) = true)

theorem identity54503 : scanCanonicalize (H12AffineFastState.compose env54503 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound54503 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env54504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,8322,5529,10401,1025,32769,4249,33,152,8582,8328,16,34953,38161,12556,35244,34188,32,257,41381,13325,33417]

theorem envBound54504 : H12AffineFastState.Bounded env54504 := by
  intro p hp
  have h : env54504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54503_54504 : H12AffineEnvironment.transform 13 13324 env54503 = env54504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env54503 == env54504) = true)

theorem identity54504 : scanCanonicalize (H12AffineFastState.compose env54504 (packedSelected [4,7,9,17,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54504 : packedSelected [4,7,9,17,27] rootPS < 2^1333 := by decide +kernel

def env54505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,32768,398,5529,2477,1025,32769,4249,33,152,138,388,16,34953,38161,4096,35244,34188,32,257,32937,5377,33417]

theorem envBound54505 : H12AffineFastState.Bounded env54505 := by
  intro p hp
  have h : env54505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54504_54505 : H12AffineEnvironment.transform 12 268 env54504 = env54505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54504 == env54505) = true)

theorem identity54505 : scanCanonicalize (H12AffineFastState.compose env54505 (packedSelected [1,4,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound54505 : packedSelected [1,4,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env54506 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,268,4248,32768,398,4097,2477,409,32769,4249,33,152,138,388,16,34953,37001,4096,35244,32788,32,257,32937,4249,33417]

theorem envBound54506 : H12AffineFastState.Bounded env54506 := by
  intro p hp
  have h : env54506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54505_54506 : H12AffineEnvironment.transform 9 408 env54505 = env54506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env54505 == env54506) = true)

theorem identity54506 : scanCanonicalize (H12AffineFastState.compose env54506 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound54506 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54507 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,268,4248,136,398,4097,2477,409,137,4249,33,152,138,388,16,2049,4097,4096,2340,156,32,257,33,4249,513]

theorem envBound54507 : H12AffineFastState.Bounded env54507 := by
  intro p hp
  have h : env54507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54506_54507 : H12AffineEnvironment.transform 14 136 env54506 = env54507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env54506 == env54507) = true)

theorem identity54507 : scanCanonicalize (H12AffineFastState.compose env54507 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound54507 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env54508 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2493,268,2341,136,398,2492,2477,409,137,2340,33,152,138,388,16,2049,2492,2493,2340,156,32,257,33,2340,513]

theorem envBound54508 : H12AffineFastState.Bounded env54508 := by
  intro p hp
  have h : env54508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54507_54508 : H12AffineEnvironment.transform 11 2493 env54507 = env54508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env54507 == env54508) = true)

theorem identity54508 : scanCanonicalize (H12AffineFastState.compose env54508 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54508 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env54509 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2357,268,2341,0,262,2356,2341,273,1,2340,33,16,2,268,16,2049,2356,2357,2340,20,32,257,33,2340,513]

theorem envBound54509 : H12AffineFastState.Bounded env54509 := by
  intro p hp
  have h : env54509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54508_54509 : H12AffineEnvironment.transform 6 8 env54508 = env54509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54508 == env54509) = true)

def env54510 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,262144,1025,32769,77850,272512,73754,95496,8328,17,121862,115102,17664,360846,119042,329731,257,41380,16384,63108]

theorem envBound54510 : H12AffineFastState.Bounded env54510 := by
  intro p hp
  have h : env54510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54500_54510 : H12AffineEnvironment.transform 5 17 env54500 = env54510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54500 == env54510) = true)

theorem identity54510 : scanCanonicalize (H12AffineFastState.compose env54510 (packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 122283) := by decide +kernel

theorem selectedBound54510 : packedSelected [3,5,8,10,11,14,16,17,19,20,26,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env54511 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24980,122283,1025,32769,77850,128299,73754,95496,8328,17,121862,115102,17664,23589,119042,54696,257,41380,16384,63108]

theorem envBound54511 : H12AffineFastState.Bounded env54511 := by
  intro p hp
  have h : env54511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54510_54511 : H12AffineEnvironment.transform 17 122283 env54510 = env54511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122283 env54510 == env54511) = true)

theorem identity54511 : scanCanonicalize (H12AffineFastState.compose env54511 (packedSelected [0,1,3,9,16,18,19,20,22,23,24,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound54511 : packedSelected [0,1,3,9,16,18,19,20,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54512 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,65536,16401,122283,1025,32769,70047,119982,65951,87181,269,17,121862,115102,17664,23589,119042,54696,257,32801,16384,55041]

theorem envBound54512 : H12AffineFastState.Bounded env54512 := by
  intro p hp
  have h : env54512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54511_54512 : H12AffineEnvironment.transform 12 389 env54511 = env54512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env54511 == env54512) = true)

theorem identity54512 : scanCanonicalize (H12AffineFastState.compose env54512 (packedSelected [17,18,19,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound54512 : packedSelected [17,18,19,23,26] rootPS < 2^1333 := by decide +kernel

def env54513 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,32768,33166,16401,23589,1025,32769,36881,21792,32785,54531,269,17,23944,16400,17664,23589,20620,54696,257,32801,16384,55041]

theorem envBound54513 : H12AffineFastState.Bounded env54513 := by
  intro p hp
  have h : env54513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54512_54513 : H12AffineEnvironment.transform 15 33166 env54512 = env54513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env54512 == env54513) = true)

theorem identity54513 : scanCanonicalize (H12AffineFastState.compose env54513 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54513 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54514 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5377,32768,33166,5392,2340,1025,32769,36881,33,32785,32770,269,17,2185,5393,4097,2340,1421,32937,257,32801,5377,33280]

theorem envBound54514 : H12AffineFastState.Bounded env54514 := by
  intro p hp
  have h : env54514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54513_54514 : H12AffineEnvironment.transform 13 5377 env54513 = env54514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54513 == env54514) = true)

theorem identity54514 : scanCanonicalize (H12AffineFastState.compose env54514 (packedSelected [1,5,10,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound54514 : packedSelected [1,5,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54515 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,40,5292,32768,32803,5309,2185,1025,32769,36881,33,32785,32770,160,17,2185,5308,4097,2185,1056,32937,172,32801,5292,33280]

theorem envBound54515 : H12AffineFastState.Bounded env54515 := by
  intro p hp
  have h : env54515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54514_54515 : H12AffineEnvironment.transform 7 173 env54514 = env54515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54514 == env54515) = true)

theorem identity54515 : scanCanonicalize (H12AffineFastState.compose env54515 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54515 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env54516 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,32768,32803,5172,2048,1025,32769,36881,33,32785,32770,41,17,2048,5173,4097,2048,1056,32800,37,32801,5157,33280]

theorem envBound54516 : H12AffineFastState.Bounded env54516 := by
  intro p hp
  have h : env54516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54515_54516 : H12AffineEnvironment.transform 6 9 env54515 = env54516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54515 == env54516) = true)

theorem identity54516 : scanCanonicalize (H12AffineFastState.compose env54516 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54516 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54517 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,34,5172,2048,1025,0,4112,33,16,3,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound54517 : H12AffineFastState.Bounded env54517 := by
  intro p hp
  have h : env54517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54516_54517 : H12AffineEnvironment.transform 14 1 env54516 = env54517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54516 == env54517) = true)

def env54518 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,40,1045,1,34,1028,2048,1025,0,32,33,16,3,41,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound54518 : H12AffineFastState.Bounded env54518 := by
  intro p hp
  have h : env54518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54517_54518 : H12AffineEnvironment.transform 11 48 env54517 = env54518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54517 == env54518) = true)

theorem identity54518 : scanCanonicalize (H12AffineFastState.compose env54518 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound54518 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54519 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,40,1045,1,34,1028,1572,1025,0,32,33,16,3,41,17,1572,1029,49,1572,1056,33,37,32,1045,513]

theorem envBound54519 : H12AffineFastState.Bounded env54519 := by
  intro p hp
  have h : env54519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54518_54519 : H12AffineEnvironment.transform 10 1572 env54518 = env54519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env54518 == env54519) = true)

def env54520 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,33,1,34,48,528,53,0,32,33,16,3,41,17,528,49,49,528,20,33,37,32,33,513]

theorem envBound54520 : H12AffineFastState.Bounded env54520 := by
  intro p hp
  have h : env54520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54519_54520 : H12AffineEnvironment.transform 9 52 env54519 = env54520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54519 == env54520) = true)

theorem identity54520 : scanCanonicalize (H12AffineFastState.compose env54520 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound54520 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54521 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,40,33,1,34,48,59,53,0,32,33,16,3,41,17,59,49,49,59,20,33,37,32,33,42]

theorem envBound54521 : H12AffineFastState.Bounded env54521 := by
  intro p hp
  have h : env54521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54520_54521 : H12AffineEnvironment.transform 8 43 env54520 = env54521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env54520 == env54521) = true)

def leafEnv54521 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,40,33,1,34,48,59,53,0,32,33,16,3,21,41,1,17,59,49,49,59,20,33,37,32,5,35,33,42,1,32,0]

def active54521 : List Nat := [0,1,2,3,4]

def tree54521 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54521 : H12WitnessSearch.Good tree54521 := H12GlobalWitnessIndex.good

theorem leafIdentity54521 : H12AffineFastState.composeSystem env54521 rootObs = leafEnv54521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54521 rootObs == leafEnv54521) = true)

theorem terminalChecked54521 : H12PackedTerminal.terminalCheckFast leafEnv54521 active54521 tree54521 = true := by decide +kernel

def env54522 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,32,1,34,49,529,52,0,32,33,16,3,41,17,529,48,49,529,21,33,37,32,32,513]

theorem envBound54522 : H12AffineFastState.Bounded env54522 := by
  intro p hp
  have h : env54522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54519_54522 : H12AffineEnvironment.transform 9 53 env54519 = env54522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54519 == env54522) = true)

def env54523 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,1,34,1029,2048,1025,0,33,33,16,3,41,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound54523 : H12AffineFastState.Bounded env54523 := by
  intro p hp
  have h : env54523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54517_54523 : H12AffineEnvironment.transform 11 49 env54517 = env54523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54517 == env54523) = true)

theorem identity54523 : scanCanonicalize (H12AffineFastState.compose env54523 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54524 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,49,40,1044,1,34,1029,528,1025,0,33,33,16,3,41,17,528,1028,48,528,1056,33,37,32,1044,513]

theorem envBound54524 : H12AffineFastState.Bounded env54524 := by
  intro p hp
  have h : env54524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54523_54524 : H12AffineEnvironment.transform 10 528 env54523 = env54524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54523 == env54524) = true)

def env54525 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,32,1,34,49,528,53,0,33,33,16,3,41,17,528,48,48,528,20,33,37,32,32,513]

theorem envBound54525 : H12AffineFastState.Bounded env54525 := by
  intro p hp
  have h : env54525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54524_54525 : H12AffineEnvironment.transform 9 52 env54524 = env54525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54524 == env54525) = true)

theorem identity54525 : scanCanonicalize (H12AffineFastState.compose env54525 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54526 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,40,32,1,34,49,58,53,0,33,33,16,3,41,17,58,48,48,58,20,33,37,32,32,43]

theorem envBound54526 : H12AffineFastState.Bounded env54526 := by
  intro p hp
  have h : env54526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54525_54526 : H12AffineEnvironment.transform 8 42 env54525 = env54526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54525 == env54526) = true)

def leafEnv54526 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,40,32,1,34,49,58,53,0,33,33,16,3,21,41,1,17,58,48,48,58,20,33,37,32,5,35,32,43,1,33,0]

def active54526 : List Nat := [0,1,2,3,4]

def tree54526 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54526 : H12WitnessSearch.Good tree54526 := H12GlobalWitnessIndex.good

theorem leafIdentity54526 : H12AffineFastState.composeSystem env54526 rootObs = leafEnv54526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54526 rootObs == leafEnv54526) = true)

theorem terminalChecked54526 : H12PackedTerminal.terminalCheckFast leafEnv54526 active54526 tree54526 = true := by decide +kernel

def env54527 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,33,1,34,48,528,52,0,33,33,16,3,41,17,528,49,48,528,21,33,37,32,33,513]

theorem envBound54527 : H12AffineFastState.Bounded env54527 := by
  intro p hp
  have h : env54527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54524_54527 : H12AffineEnvironment.transform 9 53 env54524 = env54527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54524 == env54527) = true)

def env54528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,121942,115151,17664,2404756,119042,329730,257,2199998,2191386,63189]

theorem envBound54528 : H12AffineFastState.Bounded env54528 := by
  intro p hp
  have h : env54528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54498_54528 : H12AffineEnvironment.transform 21 272513 env54498 = env54528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54498 == env54528) = true)

theorem identity54528 : scanCanonicalize (H12AffineFastState.compose env54528 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54528 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,64605,57796,17664,2404756,61705,272393,257,2142645,2117649,63189]

theorem envBound54529 : H12AffineFastState.Bounded env54529 := by
  intro p hp
  have h : env54529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54528_54529 : H12AffineEnvironment.transform 15 8203 env54528 = env54529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54528 == env54529) = true)

def env54530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,64605,57676,17664,2404636,61705,272393,257,2142525,2117649,63069]

theorem envBound54530 : H12AffineFastState.Bounded env54530 := by
  intro p hp
  have h : env54530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54529_54530 : H12AffineEnvironment.transform 6 8 env54529 = env54530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54529 == env54530) = true)

theorem identity54530 : scanCanonicalize (H12AffineFastState.compose env54530 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound54530 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env54531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24909,262144,1025,32769,12392,272393,8249,29995,8192,64,64605,57676,17664,295284,61705,272393,257,33109,24697,63069]

theorem envBound54531 : H12AffineFastState.Bounded env54531 := by
  intro p hp
  have h : env54531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54530_54531 : H12AffineEnvironment.transform 20 12392 env54530 = env54531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env54530 == env54531) = true)

theorem identity54531 : scanCanonicalize (H12AffineFastState.compose env54531 (packedSelected [0,1,2,4,11,17,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54531 : packedSelected [0,1,2,4,11,17,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,32768,34,16740,262144,1025,32769,4161,264224,16,21762,41,64,56436,49509,17664,295284,53536,264224,257,33109,16464,54900]

theorem envBound54532 : H12AffineFastState.Bounded env54532 := by
  intro p hp
  have h : env54532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54531_54532 : H12AffineEnvironment.transform 12 41 env54531 = env54532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54531 == env54532) = true)

theorem identity54532 : scanCanonicalize (H12AffineFastState.compose env54532 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound54532 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,373,34,16740,262144,1025,372,4161,264224,16,21762,41,64,23809,16400,17664,262145,20565,264224,257,32,16464,22273]

theorem envBound54533 : H12AffineFastState.Bounded env54533 := by
  intro p hp
  have h : env54533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54532_54533 : H12AffineEnvironment.transform 14 373 env54532 = env54533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env54532 == env54533) = true)

theorem identity54533 : scanCanonicalize (H12AffineFastState.compose env54533 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound54533 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,373,34,5393,262144,1025,372,4161,264224,16,375,41,64,2420,5221,4469,262145,1056,264224,257,32,5157,884]

theorem envBound54534 : H12AffineFastState.Bounded env54534 := by
  intro p hp
  have h : env54534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54533_54534 : H12AffineEnvironment.transform 13 5237 env54533 = env54534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env54533 == env54534) = true)

theorem identity54534 : scanCanonicalize (H12AffineFastState.compose env54534 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound54534 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env54535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,373,34,5393,2048,1025,372,4161,32,16,375,41,64,2420,5221,4469,2049,1056,32,257,32,5157,884]

theorem envBound54535 : H12AffineFastState.Bounded env54535 := by
  intro p hp
  have h : env54535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54534_54535 : H12AffineEnvironment.transform 17 2048 env54534 = env54535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env54534 == env54535) = true)

theorem identity54535 : scanCanonicalize (H12AffineFastState.compose env54535 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 383) := by decide +kernel

theorem selectedBound54535 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env54536 : List Nat := [2,4,8,16,32,64,8,256,383,1024,2048,4096,41,5237,373,34,5393,2048,1025,372,4161,32,16,375,41,64,2420,5221,4469,2049,1056,32,257,32,5157,11]

theorem envBound54536 : H12AffineFastState.Bounded env54536 := by
  intro p hp
  have h : env54536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54535_54536 : H12AffineEnvironment.transform 8 383 env54535 = env54536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 383 env54535 == env54536) = true)

theorem identity54536 : scanCanonicalize (H12AffineFastState.compose env54536 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54536 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54537 : List Nat := [2,4,8,16,32,64,8,256,383,272,2048,4096,41,4453,373,34,4097,2048,273,372,4161,32,16,375,41,64,2420,4469,4469,2049,304,32,257,32,4405,11]

theorem envBound54537 : H12AffineFastState.Bounded env54537 := by
  intro p hp
  have h : env54537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54536_54537 : H12AffineEnvironment.transform 9 272 env54536 = env54537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54536 == env54537) = true)

theorem identity54537 : scanCanonicalize (H12AffineFastState.compose env54537 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54537 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env54538 : List Nat := [2,4,8,16,32,64,8,36,91,52,2048,4096,41,4161,81,34,4097,2048,53,80,4161,32,16,83,41,64,2128,4177,4177,2049,20,32,37,32,4113,11]

theorem envBound54538 : H12AffineFastState.Bounded env54538 := by
  intro p hp
  have h : env54538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54537_54538 : H12AffineEnvironment.transform 7 36 env54537 = env54538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54537 == env54538) = true)

theorem identity54538 : scanCanonicalize (H12AffineFastState.compose env54538 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound54538 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54539 : List Nat := [2,4,8,16,32,64,8,36,91,52,2048,2064,41,2129,81,34,2065,2048,53,80,2129,32,16,83,41,64,2128,2113,2113,2049,20,32,37,32,2049,11]

theorem envBound54539 : H12AffineFastState.Bounded env54539 := by
  intro p hp
  have h : env54539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54538_54539 : H12AffineEnvironment.transform 11 2064 env54538 = env54539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env54538 == env54539) = true)

theorem identity54539 : scanCanonicalize (H12AffineFastState.compose env54539 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54539 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54540 : List Nat := [2,4,8,16,1,64,8,5,91,21,2048,2064,8,2129,81,3,2065,2048,20,80,2129,1,16,83,8,64,2128,2113,2113,2049,20,1,4,1,2049,11]

theorem envBound54540 : H12AffineFastState.Bounded env54540 := by
  intro p hp
  have h : env54540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54539_54540 : H12AffineEnvironment.transform 4 1 env54539 = env54540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54539 == env54540) = true)

theorem identity54540 : scanCanonicalize (H12AffineFastState.compose env54540 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound54540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54541 : List Nat := [2,4,8,16,1,64,8,5,91,21,81,65,8,0,81,3,64,81,20,80,0,1,16,83,8,64,1,16,16,80,20,1,4,1,80,11]

theorem envBound54541 : H12AffineFastState.Bounded env54541 := by
  intro p hp
  have h : env54541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54540_54541 : H12AffineEnvironment.transform 10 81 env54540 = env54541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env54540 == env54541) = true)

def env54542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,64605,57677,17664,2404637,61705,272393,257,2142524,2117649,63068]

theorem envBound54542 : H12AffineFastState.Bounded env54542 := by
  intro p hp
  have h : env54542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54529_54542 : H12AffineEnvironment.transform 6 9 env54529 = env54542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54529 == env54542) = true)

theorem identity54542 : scanCanonicalize (H12AffineFastState.compose env54542 (packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound54542 : packedSelected [1,3,5,7,10,14,15,17,19,20,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env54543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10281,1025,32769,2097152,33,2101329,2114883,8193,64,64605,57677,17664,2136372,61705,32,257,2142524,2117649,63068]

theorem envBound54543 : H12AffineFastState.Bounded env54543 := by
  intro p hp
  have h : env54543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54542_54543 : H12AffineEnvironment.transform 17 10281 env54542 = env54543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54542 == env54543) = true)

theorem identity54543 : scanCanonicalize (H12AffineFastState.compose env54543 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound54543 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54544 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10281,1025,32769,4161,33,16,21762,8193,64,64605,57677,17664,35189,61705,32,257,41341,16464,63068]

theorem envBound54544 : H12AffineFastState.Bounded env54544 := by
  intro p hp
  have h : env54544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54543_54544 : H12AffineEnvironment.transform 20 4161 env54543 = env54544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54543 == env54544) = true)

theorem identity54544 : scanCanonicalize (H12AffineFastState.compose env54544 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound54544 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env54545 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1297,8203,24908,10281,1025,1296,4161,33,16,21762,8193,64,31052,25692,17664,3172,29720,32,257,9324,16464,29517]

theorem envBound54545 : H12AffineFastState.Bounded env54545 := by
  intro p hp
  have h : env54545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54544_54545 : H12AffineEnvironment.transform 14 1297 env54544 = env54545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env54544 == env54545) = true)

theorem identity54545 : scanCanonicalize (H12AffineFastState.compose env54545 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound54545 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env54546 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,1297,115,16692,2129,1025,1296,4161,33,16,21762,121,64,22836,17444,17664,3172,21600,32,257,1044,16464,21301]

theorem envBound54546 : H12AffineFastState.Bounded env54546 := by
  intro p hp
  have h : env54546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54545_54546 : H12AffineEnvironment.transform 12 120 env54545 = env54546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54545 == env54546) = true)

theorem identity54546 : scanCanonicalize (H12AffineFastState.compose env54546 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound54546 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54547 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5237,1297,115,5441,2129,1025,1296,4161,33,16,375,121,64,3393,4177,4469,3172,21,32,257,1044,5157,1856]

theorem envBound54547 : H12AffineFastState.Bounded env54547 := by
  intro p hp
  have h : env54547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54546_54547 : H12AffineEnvironment.transform 13 5237 env54546 = env54547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env54546 == env54547) = true)

theorem identity54547 : scanCanonicalize (H12AffineFastState.compose env54547 (packedSelected [0,2,9,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound54547 : packedSelected [0,2,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54548 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,120,3124,1297,115,3328,2129,1025,1296,2048,33,16,375,121,64,3393,2064,2356,3172,21,32,257,1044,3172,1856]

theorem envBound54548 : H12AffineFastState.Bounded env54548 := by
  intro p hp
  have h : env54548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54547_54548 : H12AffineEnvironment.transform 11 2113 env54547 = env54548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env54547 == env54548) = true)

theorem identity54548 : scanCanonicalize (H12AffineFastState.compose env54548 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound54548 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env54549 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,120,2128,373,115,2404,2129,101,372,2048,33,16,375,121,64,2341,2064,2356,2048,21,32,257,112,2048,804]

theorem envBound54549 : H12AffineFastState.Bounded env54549 := by
  intro p hp
  have h : env54549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54548_54549 : H12AffineEnvironment.transform 9 100 env54548 = env54549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env54548 == env54549) = true)

theorem identity54549 : scanCanonicalize (H12AffineFastState.compose env54549 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 382) := by decide +kernel

theorem selectedBound54549 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54550 : List Nat := [2,4,8,16,32,64,9,256,382,100,2048,2113,120,2128,373,115,2404,2129,101,372,2048,33,16,375,121,64,2341,2064,2356,2048,21,32,257,112,2048,90]

theorem envBound54550 : H12AffineFastState.Bounded env54550 := by
  intro p hp
  have h : env54550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54549_54550 : H12AffineEnvironment.transform 8 382 env54549 = env54550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 382 env54549 == env54550) = true)

theorem identity54550 : scanCanonicalize (H12AffineFastState.compose env54550 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound54550 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env54551 : List Nat := [2,4,8,16,32,64,9,256,382,100,80,17,120,0,373,115,308,1,101,372,80,33,16,375,121,64,373,64,356,80,21,32,257,112,80,90]

theorem envBound54551 : H12AffineFastState.Bounded env54551 := by
  intro p hp
  have h : env54551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54550_54551 : H12AffineEnvironment.transform 10 80 env54550 = env54551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env54550 == env54551) = true)

theorem identity54551 : scanCanonicalize (H12AffineFastState.compose env54551 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound54551 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54552 : List Nat := [2,4,8,16,32,49,9,256,271,21,33,17,9,0,260,2,308,1,20,261,33,33,16,262,8,49,260,49,277,33,21,32,257,1,33,43]

theorem envBound54552 : H12AffineFastState.Bounded env54552 := by
  intro p hp
  have h : env54552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54551_54552 : H12AffineEnvironment.transform 5 49 env54551 = env54552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env54551 == env54552) = true)

theorem identity54552 : scanCanonicalize (H12AffineFastState.compose env54552 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54552 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54553 : List Nat := [2,4,8,16,32,49,9,36,43,21,33,17,9,0,32,2,16,1,20,33,33,33,16,34,8,49,32,49,49,33,21,32,37,1,33,43]

theorem envBound54553 : H12AffineFastState.Bounded env54553 := by
  intro p hp
  have h : env54553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54552_54553 : H12AffineEnvironment.transform 7 36 env54552 = env54553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54552 == env54553) = true)

theorem identity54553 : scanCanonicalize (H12AffineFastState.compose env54553 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54553 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54554 : List Nat := [2,4,5,16,32,49,4,36,38,21,33,17,4,0,32,2,16,1,20,33,33,33,16,34,5,49,32,49,49,33,21,32,37,1,33,38]

theorem envBound54554 : H12AffineFastState.Bounded env54554 := by
  intro p hp
  have h : env54554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54553_54554 : H12AffineEnvironment.transform 2 5 env54553 = env54554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54553 == env54554) = true)

theorem identity54554 : scanCanonicalize (H12AffineFastState.compose env54554 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54555 : List Nat := [2,4,5,16,0,17,4,4,6,21,1,17,4,0,0,2,16,1,20,1,1,1,16,2,5,17,0,17,17,1,21,0,5,1,1,6]

theorem envBound54555 : H12AffineFastState.Bounded env54555 := by
  intro p hp
  have h : env54555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54554_54555 : H12AffineEnvironment.transform 4 0 env54554 = env54555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54554 == env54555) = true)

theorem identity54555 : scanCanonicalize (H12AffineFastState.compose env54555 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound54555 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54556 : List Nat := [2,4,5,5,0,4,4,4,6,0,1,4,4,0,0,2,5,1,1,1,1,1,5,2,5,4,0,4,4,1,0,0,5,1,1,6]

theorem envBound54556 : H12AffineFastState.Bounded env54556 := by
  intro p hp
  have h : env54556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54555_54556 : H12AffineEnvironment.transform 3 5 env54555 = env54556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env54555 == env54556) = true)

def env54557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254784,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound54557 : H12AffineFastState.Bounded env54557 := by
  intro p hp
  have h : env54557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53841_54557 : H12AffineEnvironment.transform 25 65 env53841 = env54557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env53841 == env54557) = true)

def env54558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound54558 : H12AffineFastState.Bounded env54558 := by
  intro p hp
  have h : env54558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54557_54558 : H12AffineEnvironment.transform 26 30393344 env54557 = env54558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env54557 == env54558) = true)

def env54559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound54559 : H12AffineFastState.Bounded env54559 := by
  intro p hp
  have h : env54559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54558_54559 : H12AffineEnvironment.transform 18 1024 env54558 = env54559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env54558 == env54559) = true)

theorem identity54559 : scanCanonicalize (H12AffineFastState.compose env54559 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound54559 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403623,18973837,10507600,8497639,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound54560 : H12AffineFastState.Bounded env54560 := by
  intro p hp
  have h : env54560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54559_54560 : H12AffineEnvironment.transform 17 223719 env54559 = env54560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env54559 == env54560) = true)

def env54561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760059,5393,10507600,8497639,10491277,4256861,256,8410416,8434836,10564186]

theorem envBound54561 : H12AffineFastState.Bounded env54561 := by
  intro p hp
  have h : env54561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54560_54561 : H12AffineEnvironment.transform 23 2199964 env54560 = env54561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env54560 == env54561) = true)

def env54562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270123,5393,17664,2210231,1501,4256861,256,2114912,2139332,74250]

theorem envBound54562 : H12AffineFastState.Bounded env54562 := by
  intro p hp
  have h : env54562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54561_54562 : H12AffineEnvironment.transform 22 2101328 env54561 = env54562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env54561 == env54562) = true)

def env54563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,16,98780,8328,65,4270123,5393,17664,109047,1501,4256861,256,21792,46212,74250]

theorem envBound54563 : H12AffineFastState.Bounded env54563 := by
  intro p hp
  have h : env54563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54562_54563 : H12AffineEnvironment.transform 20 4160 env54562 = env54563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54562 == env54563) = true)

theorem identity54563 : scanCanonicalize (H12AffineFastState.compose env54563 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54563 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4160,4194304,16,41431,8328,65,4196384,5393,17664,35324,1501,4256861,256,21792,46212,513]

theorem envBound54564 : H12AffineFastState.Bounded env54564 := by
  intro p hp
  have h : env54564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54563_54564 : H12AffineEnvironment.transform 15 8203 env54563 = env54564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54563 == env54564) = true)

theorem identity54564 : scanCanonicalize (H12AffineFastState.compose env54564 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound54564 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149996,1024,32769,4160,8573,16,41431,8328,65,10589,5393,17664,35324,1501,54560,256,21792,46212,513]

theorem envBound54565 : H12AffineFastState.Bounded env54565 := by
  intro p hp
  have h : env54565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54564_54565 : H12AffineEnvironment.transform 21 8573 env54564 = env54565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env54564 == env54565) = true)

theorem identity54565 : scanCanonicalize (H12AffineFastState.compose env54565 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54565 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env54566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149861,1024,32769,4160,8573,16,41310,8193,65,10589,5393,17664,35189,1364,54560,256,21792,46093,513]

theorem envBound54566 : H12AffineFastState.Bounded env54566 := by
  intro p hp
  have h : env54566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54565_54566 : H12AffineEnvironment.transform 6 9 env54565 = env54566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54565 == env54566) = true)

theorem identity54566 : scanCanonicalize (H12AffineFastState.compose env54566 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound54566 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,10280,1024,32769,4160,8573,16,41310,8193,65,10589,5393,17664,35189,1364,54560,256,21792,46093,513]

theorem envBound54567 : H12AffineFastState.Bounded env54567 := by
  intro p hp
  have h : env54567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54566_54567 : H12AffineEnvironment.transform 16 24909 env54566 = env54567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env54566 == env54567) = true)

theorem identity54567 : scanCanonicalize (H12AffineFastState.compose env54567 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54567 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env54568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24909,10280,1024,8541,4160,8573,16,2,8193,65,10589,5393,17664,10281,1364,29820,256,21792,5457,513]

theorem envBound54568 : H12AffineFastState.Bounded env54568 := by
  intro p hp
  have h : env54568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54567_54568 : H12AffineEnvironment.transform 14 8540 env54567 = env54568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54567 == env54568) = true)

theorem identity54568 : scanCanonicalize (H12AffineFastState.compose env54568 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54568 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,8203,5393,10280,1024,8541,4160,8573,16,2,8193,65,10589,5393,12636,10281,1364,32,256,8572,5457,513]

theorem envBound54569 : H12AffineFastState.Bounded env54569 := by
  intro p hp
  have h : env54569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54568_54569 : H12AffineEnvironment.transform 13 13404 env54568 = env54569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54568 == env54569) = true)

theorem identity54569 : scanCanonicalize (H12AffineFastState.compose env54569 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54569 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54570 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,8203,5393,10280,1024,8460,4113,8492,16,2,8193,16,10508,5393,12557,10281,1285,32,256,8493,5376,513]

theorem envBound54570 : H12AffineFastState.Bounded env54570 := by
  intro p hp
  have h : env54570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54569_54570 : H12AffineEnvironment.transform 5 17 env54569 = env54570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54569 == env54570) = true)

theorem identity54570 : scanCanonicalize (H12AffineFastState.compose env54570 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54570 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54571 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,262,5393,2341,1024,1,4113,33,16,2,268,16,2049,5393,4096,2340,1285,32,256,32,5376,513]

theorem envBound54571 : H12AffineFastState.Bounded env54571 := by
  intro p hp
  have h : env54571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54570_54571 : H12AffineEnvironment.transform 12 269 env54570 = env54571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54570 == env54571) = true)

theorem identity54571 : scanCanonicalize (H12AffineFastState.compose env54571 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound54571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54572 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1312,269,32,0,262,49,2341,1024,1,1329,33,16,2,268,16,2049,49,1312,2340,1285,32,256,32,32,513]

theorem envBound54572 : H12AffineFastState.Bounded env54572 := by
  intro p hp
  have h : env54572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54571_54572 : H12AffineEnvironment.transform 11 1312 env54571 = env54572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env54571 == env54572) = true)

theorem identity54572 : scanCanonicalize (H12AffineFastState.compose env54572 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54573 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,1028,41,32,0,34,49,2049,1024,1,1045,33,16,2,40,16,2049,49,1028,2048,1057,32,36,32,32,513]

theorem envBound54573 : H12AffineFastState.Bounded env54573 := by
  intro p hp
  have h : env54573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54572_54573 : H12AffineEnvironment.transform 7 36 env54572 = env54573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54572 == env54573) = true)

theorem identity54573 : scanCanonicalize (H12AffineFastState.compose env54573 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound54573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54574 : List Nat := [2,4,8,16,32,17,9,36,512,1024,545,1028,41,32,0,34,49,544,1024,1,1045,33,16,2,40,16,544,49,1028,545,1057,32,36,32,32,513]

theorem envBound54574 : H12AffineFastState.Bounded env54574 := by
  intro p hp
  have h : env54574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54573_54574 : H12AffineEnvironment.transform 10 545 env54573 = env54574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env54573 == env54574) = true)

theorem identity54574 : scanCanonicalize (H12AffineFastState.compose env54574 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54574 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54575 : List Nat := [2,4,8,16,0,17,9,4,512,1024,513,1028,9,0,0,2,17,512,1024,1,1045,1,16,2,8,16,512,17,1028,513,1025,0,4,0,0,513]

theorem envBound54575 : H12AffineFastState.Bounded env54575 := by
  intro p hp
  have h : env54575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54574_54575 : H12AffineEnvironment.transform 4 0 env54574 = env54575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54574 == env54575) = true)

theorem identity54575 : scanCanonicalize (H12AffineFastState.compose env54575 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound54575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54576 : List Nat := [2,4,8,16,0,17,9,4,512,516,513,512,9,0,0,2,17,512,516,1,529,1,16,2,8,16,512,17,512,513,517,0,4,0,0,513]

theorem envBound54576 : H12AffineFastState.Bounded env54576 := by
  intro p hp
  have h : env54576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54575_54576 : H12AffineEnvironment.transform 9 516 env54575 = env54576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env54575 == env54576) = true)

theorem identity54576 : scanCanonicalize (H12AffineFastState.compose env54576 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54576 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env54577 : List Nat := [2,4,8,16,0,17,9,4,16,20,17,16,9,0,0,2,17,16,20,1,1,1,16,2,8,16,16,17,16,17,21,0,4,0,0,17]

theorem envBound54577 : H12AffineFastState.Bounded env54577 := by
  intro p hp
  have h : env54577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54576_54577 : H12AffineEnvironment.transform 8 16 env54576 = env54577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54576 == env54577) = true)

theorem identity54577 : scanCanonicalize (H12AffineFastState.compose env54577 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54577 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54578 : List Nat := [2,4,2,16,0,17,3,4,16,20,17,16,3,0,0,2,17,16,20,1,1,1,16,2,2,16,16,17,16,17,21,0,4,0,0,17]

theorem envBound54578 : H12AffineFastState.Bounded env54578 := by
  intro p hp
  have h : env54578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54577_54578 : H12AffineEnvironment.transform 2 2 env54577 = env54578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54577 == env54578) = true)

theorem identity54578 : scanCanonicalize (H12AffineFastState.compose env54578 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54578 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env54579 : List Nat := [2,4,2,1,0,0,3,4,1,5,0,1,3,0,0,2,0,1,5,1,1,1,1,2,2,1,1,0,1,0,4,0,4,0,0,0]

theorem envBound54579 : H12AffineFastState.Bounded env54579 := by
  intro p hp
  have h : env54579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54578_54579 : H12AffineEnvironment.transform 3 1 env54578 = env54579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54578 == env54579) = true)

def env54580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,17,98781,8328,65,4270123,5393,17664,109046,1501,4256861,256,21793,46213,74250]

theorem envBound54580 : H12AffineFastState.Bounded env54580 := by
  intro p hp
  have h : env54580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54562_54580 : H12AffineEnvironment.transform 20 4161 env54562 = env54580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54562 == env54580) = true)

theorem identity54580 : scanCanonicalize (H12AffineFastState.compose env54580 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound54580 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,243123,17,98781,8328,65,171416,5393,17664,109046,1501,213486,256,21793,46213,74250]

theorem envBound54581 : H12AffineFastState.Bounded env54581 := by
  intro p hp
  have h : env54581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54580_54581 : H12AffineEnvironment.transform 21 243123 env54580 = env54581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env54580 == env54581) = true)

def env54582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,243003,17,98645,8192,65,171280,5393,17664,108926,1365,213350,256,21793,46093,74250]

theorem envBound54582 : H12AffineFastState.Bounded env54582 := by
  intro p hp
  have h : env54582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54581_54582 : H12AffineEnvironment.transform 6 8 env54581 = env54582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54581 == env54582) = true)

theorem identity54582 : scanCanonicalize (H12AffineFastState.compose env54582 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54582 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4161,201831,17,73737,8192,65,146508,5393,17664,67618,1365,213350,256,21793,5457,74250]

theorem envBound54583 : H12AffineFastState.Bounded env54583 := by
  intro p hp
  have h : env54583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54582_54583 : H12AffineEnvironment.transform 14 8540 env54582 = env54583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54582 == env54583) = true)

theorem identity54583 : scanCanonicalize (H12AffineFastState.compose env54583 (packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound54583 : packedSelected [0,1,7,8,9,10,12,14,15,16,19,22,31] rootPS < 2^1333 := by decide +kernel

def env54584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,114,131072,157981,1024,8541,4161,136213,17,8315,8192,65,146508,5393,17664,2128,1365,147732,256,21793,5457,8824]

theorem envBound54584 : H12AffineFastState.Bounded env54584 := by
  intro p hp
  have h : env54584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54583_54584 : H12AffineEnvironment.transform 15 114 env54583 = env54584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env54583 == env54584) = true)

theorem identity54584 : scanCanonicalize (H12AffineFastState.compose env54584 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound54584 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env54585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,114,5393,31756,1024,8541,4161,260,17,8315,8192,65,10589,5393,17664,2128,1365,21509,256,21793,5457,8824]

theorem envBound54585 : H12AffineFastState.Bounded env54585 := by
  intro p hp
  have h : env54585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54584_54585 : H12AffineEnvironment.transform 16 5393 env54584 = env54585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env54584 == env54585) = true)

theorem identity54585 : scanCanonicalize (H12AffineFastState.compose env54585 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54585 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env54586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,114,5393,23889,1024,0,4161,260,17,294,349,65,2048,5393,17664,2128,1365,21509,256,21793,5457,805]

theorem envBound54586 : H12AffineFastState.Bounded env54586 := by
  intro p hp
  have h : env54586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54585_54586 : H12AffineEnvironment.transform 12 349 env54585 = env54586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54585 == env54586) = true)

theorem identity54586 : scanCanonicalize (H12AffineFastState.compose env54586 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54586 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5157,1,114,5393,2420,1024,0,4161,260,17,294,349,65,2048,5393,4389,2128,1365,32,256,260,5457,805]

theorem envBound54587 : H12AffineFastState.Bounded env54587 := by
  intro p hp
  have h : env54587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54586_54587 : H12AffineEnvironment.transform 13 5157 env54586 = env54587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54586 == env54587) = true)

def env54588 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,243002,17,98644,8193,65,171281,5393,17664,108927,1364,213351,256,21793,46092,74250]

theorem envBound54588 : H12AffineFastState.Bounded env54588 := by
  intro p hp
  have h : env54588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54581_54588 : H12AffineEnvironment.transform 6 9 env54581 = env54588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54581 == env54588) = true)

theorem identity54588 : scanCanonicalize (H12AffineFastState.compose env54588 (packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54588 : packedSelected [0,7,8,9,11,12,14,16,22,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env54589 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,131072,223598,1024,21761,4161,221242,17,87124,8193,65,149521,5393,17664,97407,1364,213351,256,21793,24844,74250]

theorem envBound54589 : H12AffineFastState.Bounded env54589 := by
  intro p hp
  have h : env54589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54588_54589 : H12AffineEnvironment.transform 14 21760 env54588 = env54589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54588 == env54589) = true)

theorem identity54589 : scanCanonicalize (H12AffineFastState.compose env54589 (packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound54589 : packedSelected [5,8,11,16,20,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env54590 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,79131,23669,1024,21761,4161,21793,17,87124,8193,65,97546,5393,17664,97407,1364,29820,256,21793,24844,74250]

theorem envBound54590 : H12AffineFastState.Bounded env54590 := by
  intro p hp
  have h : env54590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54589_54590 : H12AffineEnvironment.transform 16 79131 env54589 = env54590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env54589 == env54590) = true)

theorem identity54590 : scanCanonicalize (H12AffineFastState.compose env54590 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54590 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env54591 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,65536,70727,23669,1024,21761,4161,21793,17,87124,349,65,89174,5393,17664,89379,1364,21792,256,21793,16464,66390]

theorem envBound54591 : H12AffineFastState.Bounded env54591 := by
  intro p hp
  have h : env54591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54590_54591 : H12AffineEnvironment.transform 12 348 env54590 = env54591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54590 == env54591) = true)

theorem identity54591 : scanCanonicalize (H12AffineFastState.compose env54591 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54591 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env54592 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,263,5440,23669,1024,21761,4161,21793,17,21843,349,65,23889,5393,17664,23588,1364,21792,256,21793,16464,593]

theorem envBound54592 : H12AffineFastState.Bounded env54592 := by
  intro p hp
  have h : env54592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54591_54592 : H12AffineEnvironment.transform 15 263 env54591 = env54592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54591 == env54592) = true)

theorem identity54592 : scanCanonicalize (H12AffineFastState.compose env54592 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound54592 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54593 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1296,263,5440,3173,1024,1297,4161,1329,17,1347,349,65,3393,5393,5392,3124,1364,1328,256,1329,4160,593]

theorem envBound54593 : H12AffineFastState.Bounded env54593 := by
  intro p hp
  have h : env54593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54592_54593 : H12AffineEnvironment.transform 13 4112 env54592 = env54593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env54592 == env54593) = true)

theorem identity54593 : scanCanonicalize (H12AffineFastState.compose env54593 (packedSelected [0,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound54593 : packedSelected [0,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54594 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,348,3345,1296,263,2113,3173,1024,1297,3392,1329,17,1347,349,65,3393,2064,2065,3124,1364,1328,256,1329,3393,593]

theorem envBound54594 : H12AffineFastState.Bounded env54594 := by
  intro p hp
  have h : env54594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54593_54594 : H12AffineEnvironment.transform 11 3329 env54593 = env54594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env54593 == env54594) = true)

def env54595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270122,5393,17665,2210230,1500,4256861,256,2114913,2139333,74251]

theorem envBound54595 : H12AffineFastState.Bounded env54595 := by
  intro p hp
  have h : env54595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54561_54595 : H12AffineEnvironment.transform 22 2101329 env54561 = env54595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env54561 == env54595) = true)

def env54596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,17,98780,8328,65,4270122,5393,17665,109046,1500,4256861,256,21793,46213,74251]

theorem envBound54596 : H12AffineFastState.Bounded env54596 := by
  intro p hp
  have h : env54596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54595_54596 : H12AffineEnvironment.transform 20 4160 env54595 = env54596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54595 == env54596) = true)

theorem identity54596 : scanCanonicalize (H12AffineFastState.compose env54596 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound54596 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,213351,17,98780,8328,65,158029,5393,17665,109046,1500,243002,256,21793,46213,74251]

theorem envBound54597 : H12AffineFastState.Bounded env54597 := by
  intro p hp
  have h : env54597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54596_54597 : H12AffineEnvironment.transform 21 213351 env54596 = env54597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env54596 == env54597) = true)

theorem identity54597 : scanCanonicalize (H12AffineFastState.compose env54597 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54597 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149997,1024,32769,4160,156013,17,41430,8328,65,158029,5393,17665,35324,1500,169264,256,21793,46213,513]

theorem envBound54598 : H12AffineFastState.Bounded env54598 := by
  intro p hp
  have h : env54598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54597_54598 : H12AffineEnvironment.transform 15 8202 env54597 = env54598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54597 == env54598) = true)

theorem identity54598 : scanCanonicalize (H12AffineFastState.compose env54598 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound54598 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env54599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,2557,1024,32769,4160,8573,17,41430,8328,65,10589,5393,17665,35324,1500,54560,256,21793,46213,513]

theorem envBound54599 : H12AffineFastState.Bounded env54599 := by
  intro p hp
  have h : env54599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54598_54599 : H12AffineEnvironment.transform 16 16400 env54598 = env54599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env54598 == env54599) = true)

theorem identity54599 : scanCanonicalize (H12AffineFastState.compose env54599 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound54599 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env54600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8202,16400,2557,1024,29709,4160,8573,17,21978,8328,65,10589,5393,17665,32240,1500,8492,256,21793,16521,513]

theorem envBound54600 : H12AffineFastState.Bounded env54600 := by
  intro p hp
  have h : env54600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54599_54600 : H12AffineEnvironment.transform 14 29708 env54599 = env54600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env54599 == env54600) = true)

theorem identity54600 : scanCanonicalize (H12AffineFastState.compose env54600 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54600 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env54601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8202,16400,2421,1024,29709,4160,8573,17,21842,8192,65,10589,5393,17665,32120,1364,8492,256,21793,16385,513]

theorem envBound54601 : H12AffineFastState.Bounded env54601 := by
  intro p hp
  have h : env54601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54600_54601 : H12AffineEnvironment.transform 6 8 env54600 = env54601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54600 == env54601) = true)

theorem identity54601 : scanCanonicalize (H12AffineFastState.compose env54601 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound54601 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env54602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4453,9577,8202,4469,2421,1024,9576,4160,8573,17,1079,8192,65,10589,5393,5220,11293,1364,8492,256,1092,4452,513]

theorem envBound54602 : H12AffineFastState.Bounded env54602 := by
  intro p hp
  have h : env54602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54601_54602 : H12AffineEnvironment.transform 13 4453 env54601 = env54602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env54601 == env54602) = true)

theorem identity54602 : scanCanonicalize (H12AffineFastState.compose env54602 (packedSelected [0,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound54602 : packedSelected [0,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4453,1,1378,4469,2421,1024,0,4160,1045,17,1079,1384,65,3125,5393,5220,2421,1364,1092,256,1092,4452,513]

theorem envBound54603 : H12AffineFastState.Bounded env54603 := by
  intro p hp
  have h : env54603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54602_54603 : H12AffineEnvironment.transform 12 1384 env54602 = env54603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env54602 == env54603) = true)

theorem identity54603 : scanCanonicalize (H12AffineFastState.compose env54603 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54604 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,120,4453,1,114,4469,2421,272,0,4160,261,17,295,120,65,2341,4097,4468,2421,68,340,256,340,4452,513]

theorem envBound54604 : H12AffineFastState.Bounded env54604 := by
  intro p hp
  have h : env54604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54603_54604 : H12AffineEnvironment.transform 9 272 env54603 = env54604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54603 == env54604) = true)

theorem identity54604 : scanCanonicalize (H12AffineFastState.compose env54604 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound54604 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54605 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,120,2048,1,114,2064,2421,272,0,2341,261,17,295,120,65,2341,2404,2065,2421,68,340,256,340,2049,513]

theorem envBound54605 : H12AffineFastState.Bounded env54605 := by
  intro p hp
  have h : env54605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54604_54605 : H12AffineEnvironment.transform 11 2405 env54604 = env54605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env54604 == env54605) = true)

theorem identity54605 : scanCanonicalize (H12AffineFastState.compose env54605 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54605 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54606 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2357,40,2048,1,34,2064,2341,272,0,2341,261,17,295,40,17,2341,2356,2065,2341,20,260,256,260,2049,513]

theorem envBound54606 : H12AffineFastState.Bounded env54606 := by
  intro p hp
  have h : env54606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54605_54606 : H12AffineEnvironment.transform 5 16 env54605 = env54606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54605 == env54606) = true)

theorem identity54606 : scanCanonicalize (H12AffineFastState.compose env54606 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54606 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54607 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,309,40,0,1,34,16,293,272,0,293,261,17,295,40,17,293,308,17,293,20,260,256,260,1,513]

theorem envBound54607 : H12AffineFastState.Bounded env54607 := by
  intro p hp
  have h : env54607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54606_54607 : H12AffineEnvironment.transform 10 0 env54606 = env54607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54606 == env54607) = true)

def env54608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,16,98781,8328,65,4270122,5393,17665,109047,1500,4256861,256,21792,46212,74251]

theorem envBound54608 : H12AffineFastState.Bounded env54608 := by
  intro p hp
  have h : env54608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54595_54608 : H12AffineEnvironment.transform 20 4161 env54595 = env54608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54595 == env54608) = true)

theorem identity54608 : scanCanonicalize (H12AffineFastState.compose env54608 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound54608 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179512,1024,32769,4161,4194304,16,21762,8328,65,4259061,5393,17665,32040,1500,4256861,256,21792,46212,63188]

theorem envBound54609 : H12AffineFastState.Bounded env54609 := by
  intro p hp
  have h : env54609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54608_54609 : H12AffineEnvironment.transform 15 54495 env54608 = env54609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env54608 == env54609) = true)

def env54610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4161,4194304,16,21762,8192,65,4258941,5393,17665,32040,1364,4256861,256,21792,46092,63068]

theorem envBound54610 : H12AffineFastState.Bounded env54610 := by
  intro p hp
  have h : env54610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54609_54610 : H12AffineEnvironment.transform 6 8 env54609 = env54610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54609 == env54610) = true)

theorem identity54610 : scanCanonicalize (H12AffineFastState.compose env54610 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound54610 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35189,1024,32769,4161,4194304,16,21762,8192,65,4258941,5393,17665,32040,1364,4256861,256,21792,46092,63068]

theorem envBound54611 : H12AffineFastState.Bounded env54611 := by
  intro p hp
  have h : env54611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54610_54611 : H12AffineEnvironment.transform 16 13389 env54610 = env54611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env54610 == env54611) = true)

theorem identity54611 : scanCanonicalize (H12AffineFastState.compose env54611 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound54611 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35189,1024,32769,4161,62589,16,21762,8192,65,2048,5393,17665,32040,1364,32,256,21792,46092,63068]

theorem envBound54612 : H12AffineFastState.Bounded env54612 := by
  intro p hp
  have h : env54612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54611_54612 : H12AffineEnvironment.transform 21 62589 env54611 = env54612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env54611 == env54612) = true)

theorem identity54612 : scanCanonicalize (H12AffineFastState.compose env54612 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54612 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env54613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,13389,10281,1024,8541,4161,21793,16,21762,8192,65,2048,5393,17665,32040,1364,32,256,21792,5456,22272]

theorem envBound54613 : H12AffineFastState.Bounded env54613 := by
  intro p hp
  have h : env54613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54612_54613 : H12AffineEnvironment.transform 14 8540 env54612 = env54613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54612 == env54613) = true)

theorem identity54613 : scanCanonicalize (H12AffineFastState.compose env54613 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1132) := by decide +kernel

theorem selectedBound54613 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env54614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1132,16384,1328,20839,4129,3141,1024,1329,4161,21793,16,21762,1132,65,2048,5393,17665,22852,1364,32,256,21792,5456,22272]

theorem envBound54614 : H12AffineFastState.Bounded env54614 := by
  intro p hp
  have h : env54614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54613_54614 : H12AffineEnvironment.transform 12 1132 env54613 = env54614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1132 env54613 == env54614) = true)

theorem identity54614 : scanCanonicalize (H12AffineFastState.compose env54614 (packedSelected [0,7,16] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54614 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env54615 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,16384,33,20839,4129,2388,273,32,4161,20528,16,20499,381,65,2048,4096,16400,22852,69,32,256,20529,4161,21009]

theorem envBound54615 : H12AffineFastState.Bounded env54615 := by
  intro p hp
  have h : env54615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54614_54615 : H12AffineEnvironment.transform 9 273 env54614 = env54615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54614 == env54615) = true)

theorem identity54615 : scanCanonicalize (H12AffineFastState.compose env54615 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound54615 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54616 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,381,4373,33,114,4129,2388,273,32,4161,293,16,262,381,65,2048,4096,4357,2129,69,32,256,292,4161,772]

theorem envBound54616 : H12AffineFastState.Bounded env54616 := by
  intro p hp
  have h : env54616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54615_54616 : H12AffineEnvironment.transform 13 4373 env54615 = env54616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env54615 == env54616) = true)

theorem identity54616 : scanCanonicalize (H12AffineFastState.compose env54616 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54616 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54617 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,89,4145,33,114,4129,2160,53,32,4161,1,16,34,89,65,2048,4096,4129,2129,69,32,36,0,4161,544]

theorem envBound54617 : H12AffineFastState.Bounded env54617 := by
  intro p hp
  have h : env54617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54616_54617 : H12AffineEnvironment.transform 7 36 env54616 = env54617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54616 == env54617) = true)

theorem identity54617 : scanCanonicalize (H12AffineFastState.compose env54617 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound54617 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54618 : List Nat := [2,4,8,16,32,48,8,36,512,53,2048,4096,41,4145,33,2,4129,2048,53,32,4145,1,16,34,41,49,2048,4096,4129,2081,53,32,36,0,4145,544]

theorem envBound54618 : H12AffineFastState.Bounded env54618 := by
  intro p hp
  have h : env54618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54617_54618 : H12AffineEnvironment.transform 5 48 env54617 = env54618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env54617 == env54618) = true)

theorem identity54618 : scanCanonicalize (H12AffineFastState.compose env54618 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54618 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54619 : List Nat := [2,4,8,16,32,48,8,36,1,53,2048,4096,41,4145,33,2,4129,2048,53,32,4145,1,16,34,41,49,2048,4096,4129,2081,53,32,36,0,4145,33]

theorem envBound54619 : H12AffineFastState.Bounded env54619 := by
  intro p hp
  have h : env54619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54618_54619 : H12AffineEnvironment.transform 8 1 env54618 = env54619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54618 == env54619) = true)

theorem identity54619 : scanCanonicalize (H12AffineFastState.compose env54619 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54619 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env54620 : List Nat := [2,4,8,16,32,48,8,36,1,53,1,4096,41,4145,33,2,4129,1,53,32,4145,1,16,34,41,49,1,4096,4129,32,53,32,36,0,4145,33]

theorem envBound54620 : H12AffineFastState.Bounded env54620 := by
  intro p hp
  have h : env54620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54619_54620 : H12AffineEnvironment.transform 10 1 env54619 = env54620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54619 == env54620) = true)

theorem identity54620 : scanCanonicalize (H12AffineFastState.compose env54620 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound54620 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env54621 : List Nat := [2,4,8,16,32,48,8,36,1,53,1,0,41,49,33,2,33,1,53,32,49,1,16,34,41,49,1,0,33,32,53,32,36,0,49,33]

theorem envBound54621 : H12AffineFastState.Bounded env54621 := by
  intro p hp
  have h : env54621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54620_54621 : H12AffineEnvironment.transform 11 0 env54620 = env54621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env54620 == env54621) = true)

theorem identity54621 : scanCanonicalize (H12AffineFastState.compose env54621 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54622 : List Nat := [2,4,8,16,0,16,8,4,1,21,1,0,9,17,1,2,1,1,21,0,17,1,16,2,9,17,1,0,1,0,21,0,4,0,17,1]

theorem envBound54622 : H12AffineFastState.Bounded env54622 := by
  intro p hp
  have h : env54622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54621_54622 : H12AffineEnvironment.transform 4 0 env54621 = env54622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54621 == env54622) = true)

theorem identity54622 : scanCanonicalize (H12AffineFastState.compose env54622 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound54622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54623 : List Nat := [2,4,7,16,0,16,7,4,1,21,1,0,6,17,1,2,1,1,21,0,17,1,16,2,6,17,1,0,1,0,21,0,4,0,17,1]

theorem envBound54623 : H12AffineFastState.Bounded env54623 := by
  intro p hp
  have h : env54623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54622_54623 : H12AffineEnvironment.transform 2 7 env54622 = env54623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env54622 == env54623) = true)

theorem identity54623 : scanCanonicalize (H12AffineFastState.compose env54623 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54624 : List Nat := [2,4,7,0,0,0,7,4,1,5,1,0,6,1,1,2,1,1,5,0,1,1,0,2,6,1,1,0,1,0,5,0,4,0,1,1]

theorem envBound54624 : H12AffineFastState.Bounded env54624 := by
  intro p hp
  have h : env54624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54623_54624 : H12AffineEnvironment.transform 3 0 env54623 = env54624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54623 == env54624) = true)

def env54625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4161,4194304,16,21762,8193,65,4258940,5393,17665,32040,1365,4256861,256,21792,46093,63069]

theorem envBound54625 : H12AffineFastState.Bounded env54625 := by
  intro p hp
  have h : env54625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54609_54625 : H12AffineEnvironment.transform 6 9 env54609 = env54625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54609 == env54625) = true)

theorem identity54625 : scanCanonicalize (H12AffineFastState.compose env54625 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound54625 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10280,1024,32769,4161,4194304,16,21762,8193,65,4258940,5393,17665,32040,1365,4256861,256,21792,46093,63069]

theorem envBound54626 : H12AffineFastState.Bounded env54626 := by
  intro p hp
  have h : env54626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54625_54626 : H12AffineEnvironment.transform 16 38160 env54625 = env54626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env54625 == env54626) = true)

theorem identity54626 : scanCanonicalize (H12AffineFastState.compose env54626 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound54626 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env54627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10280,1024,32769,4161,21872,16,21762,8193,65,43276,5393,17665,32040,1365,41261,256,21792,46093,63069]

theorem envBound54627 : H12AffineFastState.Bounded env54627 := by
  intro p hp
  have h : env54627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54626_54627 : H12AffineEnvironment.transform 21 21872 env54626 = env54627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env54626 == env54627) = true)

theorem identity54627 : scanCanonicalize (H12AffineFastState.compose env54627 (packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54627 : packedSelected [1,2,4,6,8,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,13388,10280,1024,8541,4161,21872,16,21762,8193,65,2128,5393,17665,32040,1365,113,256,21792,5457,22273]

theorem envBound54628 : H12AffineFastState.Bounded env54628 := by
  intro p hp
  have h : env54628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54627_54628 : H12AffineEnvironment.transform 14 8540 env54627 = env54628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54627 == env54628) = true)

theorem identity54628 : scanCanonicalize (H12AffineFastState.compose env54628 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54628 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,342,13388,10280,1024,8541,4161,8492,16,8542,8193,65,2128,5393,12637,2420,1365,113,256,8572,5457,9053]

theorem envBound54629 : H12AffineFastState.Bounded env54629 := by
  intro p hp
  have h : env54629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54628_54629 : H12AffineEnvironment.transform 13 13404 env54628 = env54629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54628 == env54629) = true)

def env54630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760058,5392,10507600,8497639,10491276,4256860,256,8410417,8434837,10564187]

theorem envBound54630 : H12AffineFastState.Bounded env54630 := by
  intro p hp
  have h : env54630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54560_54630 : H12AffineEnvironment.transform 23 2199965 env54560 = env54630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env54560 == env54630) = true)

def env54631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270122,5392,17664,2210231,1500,4256860,256,2114913,2139333,74251]

theorem envBound54631 : H12AffineFastState.Bounded env54631 := by
  intro p hp
  have h : env54631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54630_54631 : H12AffineEnvironment.transform 22 2101328 env54630 = env54631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env54630 == env54631) = true)

def env54632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,16,98781,8328,65,4270122,5392,17664,109047,1500,4256860,256,21793,46213,74251]

theorem envBound54632 : H12AffineFastState.Bounded env54632 := by
  intro p hp
  have h : env54632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54631_54632 : H12AffineEnvironment.transform 20 4160 env54631 = env54632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54631 == env54632) = true)

theorem identity54632 : scanCanonicalize (H12AffineFastState.compose env54632 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound54632 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,223719,1024,29909,4160,4194304,16,95497,8328,65,4270122,5392,17664,89379,1500,4194440,256,21793,16465,74251]

theorem envBound54633 : H12AffineFastState.Bounded env54633 := by
  intro p hp
  have h : env54633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54632_54633 : H12AffineEnvironment.transform 14 29908 env54632 = env54633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env54632 == env54633) = true)

def env54634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212199,1024,8661,4160,4194304,16,73737,8328,65,4270122,5392,4096,67619,1500,4194440,256,33,5457,74251]

theorem envBound54634 : H12AffineFastState.Bounded env54634 := by
  intro p hp
  have h : env54634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54633_54634 : H12AffineEnvironment.transform 13 5376 env54633 = env54634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54633 == env54634) = true)

theorem identity54634 : scanCanonicalize (H12AffineFastState.compose env54634 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound54634 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,10401,1024,8661,4160,4194304,16,73737,8328,65,4270122,5392,4096,67619,1500,4194440,256,33,5457,74251]

theorem envBound54635 : H12AffineFastState.Bounded env54635 := by
  intro p hp
  have h : env54635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54634_54635 : H12AffineEnvironment.transform 16 70726 env54634 = env54635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env54634 == env54635) = true)

theorem identity54635 : scanCanonicalize (H12AffineFastState.compose env54635 (packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound54635 : packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env54636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70726,10401,1024,8661,4160,8492,16,73737,8328,65,67846,5392,4096,67619,1500,8612,256,33,5457,74251]

theorem envBound54636 : H12AffineFastState.Bounded env54636 := by
  intro p hp
  have h : env54636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54635_54636 : H12AffineEnvironment.transform 21 8492 env54635 = env54636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env54635 == env54636) = true)

theorem identity54636 : scanCanonicalize (H12AffineFastState.compose env54636 (packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54636 : packedSelected [0,1,3,5,8,9,10,19,22,27] rootPS < 2^1333 := by decide +kernel

def env54637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,65536,70726,2556,1024,136,4160,113,16,65876,469,65,67846,5392,4096,67619,1500,249,256,33,5457,66390]

theorem envBound54637 : H12AffineFastState.Bounded env54637 := by
  intro p hp
  have h : env54637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54636_54637 : H12AffineEnvironment.transform 12 349 env54636 = env54637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54636 == env54637) = true)

theorem identity54637 : scanCanonicalize (H12AffineFastState.compose env54637 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound54637 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env54638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,137,478,5528,2556,1024,136,4160,113,16,138,469,65,2264,5392,4096,2557,1500,249,256,33,5457,648]

theorem envBound54638 : H12AffineFastState.Bounded env54638 := by
  intro p hp
  have h : env54638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54637_54638 : H12AffineEnvironment.transform 15 478 env54637 = env54638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env54637 == env54638) = true)

theorem identity54638 : scanCanonicalize (H12AffineFastState.compose env54638 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54638 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54639 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,137,398,5528,2476,1024,136,4112,33,16,138,389,17,2184,5392,4096,2477,1420,169,256,33,5377,648]

theorem envBound54639 : H12AffineFastState.Bounded env54639 := by
  intro p hp
  have h : env54639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54638_54639 : H12AffineEnvironment.transform 5 16 env54638 = env54639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54638 == env54639) = true)

theorem identity54639 : scanCanonicalize (H12AffineFastState.compose env54639 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound54639 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54640 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,269,4113,137,398,4233,2476,273,136,4112,33,16,138,389,17,2184,4097,4096,2477,157,169,256,33,4112,648]

theorem envBound54640 : H12AffineFastState.Bounded env54640 := by
  intro p hp
  have h : env54640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54639_54640 : H12AffineEnvironment.transform 9 273 env54639 = env54640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54639 == env54640) = true)

theorem identity54640 : scanCanonicalize (H12AffineFastState.compose env54640 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54640 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54641 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,269,4113,0,263,4096,2341,273,1,4112,33,16,3,268,17,2049,4097,4096,2340,20,32,256,33,4112,513]

theorem envBound54641 : H12AffineFastState.Bounded env54641 := by
  intro p hp
  have h : env54641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54640_54641 : H12AffineEnvironment.transform 6 9 env54640 = env54641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54640 == env54641) = true)

theorem identity54641 : scanCanonicalize (H12AffineFastState.compose env54641 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54642 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,0,34,4096,2048,52,1,4112,33,16,3,41,17,2049,4097,4096,2049,20,32,37,33,4112,513]

theorem envBound54642 : H12AffineFastState.Bounded env54642 := by
  intro p hp
  have h : env54642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54641_54642 : H12AffineEnvironment.transform 7 37 env54641 = env54642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54641 == env54642) = true)

theorem identity54642 : scanCanonicalize (H12AffineFastState.compose env54642 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound54642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54643 : List Nat := [2,4,8,16,5,16,9,0,512,17,2048,4096,13,4113,0,7,4096,2048,17,1,4112,4,16,3,12,17,2049,4097,4096,2049,20,5,0,4,4112,513]

theorem envBound54643 : H12AffineFastState.Bounded env54643 := by
  intro p hp
  have h : env54643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54642_54643 : H12AffineEnvironment.transform 4 5 env54642 = env54643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env54642 == env54643) = true)

theorem identity54643 : scanCanonicalize (H12AffineFastState.compose env54643 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 8) := by decide +kernel

theorem selectedBound54643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54644 : List Nat := [2,4,8,16,5,16,9,0,512,17,8,4096,13,4113,0,7,4096,8,17,1,4112,4,16,3,12,17,9,4097,4096,9,20,5,0,4,4112,513]

theorem envBound54644 : H12AffineFastState.Bounded env54644 := by
  intro p hp
  have h : env54644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54643_54644 : H12AffineEnvironment.transform 10 8 env54643 = env54644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 8 env54643 == env54644) = true)

theorem identity54644 : scanCanonicalize (H12AffineFastState.compose env54644 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound54644 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54645 : List Nat := [2,4,8,16,5,16,9,0,3,17,8,4096,13,4113,0,7,4096,8,17,1,4112,4,16,3,12,17,9,4097,4096,9,20,5,0,4,4112,2]

theorem envBound54645 : H12AffineFastState.Bounded env54645 := by
  intro p hp
  have h : env54645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54644_54645 : H12AffineEnvironment.transform 8 3 env54644 = env54645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env54644 == env54645) = true)

theorem identity54645 : scanCanonicalize (H12AffineFastState.compose env54645 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54645 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54646 : List Nat := [2,4,4,16,5,16,5,0,3,17,4,4096,1,4113,0,7,4096,4,17,1,4112,4,16,3,0,17,5,4097,4096,5,20,5,0,4,4112,2]

theorem envBound54646 : H12AffineFastState.Bounded env54646 := by
  intro p hp
  have h : env54646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54645_54646 : H12AffineEnvironment.transform 2 4 env54645 = env54646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54645 == env54646) = true)

theorem identity54646 : scanCanonicalize (H12AffineFastState.compose env54646 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 21) := by decide +kernel

theorem selectedBound54646 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54647 : List Nat := [2,4,4,16,5,16,5,0,3,17,4,21,1,4,0,7,21,4,17,1,5,4,16,3,0,17,5,20,21,5,20,5,0,4,5,2]

theorem envBound54647 : H12AffineFastState.Bounded env54647 := by
  intro p hp
  have h : env54647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54646_54647 : H12AffineEnvironment.transform 11 21 env54646 = env54647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 21 env54646 == env54647) = true)

def env54648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212198,1024,8660,4160,4194304,16,73736,8328,65,4270122,5392,4097,67618,1500,4194440,256,32,5456,74251]

theorem envBound54648 : H12AffineFastState.Bounded env54648 := by
  intro p hp
  have h : env54648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54633_54648 : H12AffineEnvironment.transform 13 5377 env54633 = env54648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54633 == env54648) = true)

theorem identity54648 : scanCanonicalize (H12AffineFastState.compose env54648 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound54648 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70862,10280,1024,8660,4160,4194304,16,73736,8328,65,4270122,5392,4097,67618,1500,4194440,256,32,5456,74251]

theorem envBound54649 : H12AffineFastState.Bounded env54649 := by
  intro p hp
  have h : env54649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54648_54649 : H12AffineEnvironment.transform 16 70862 env54648 = env54649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env54648 == env54649) = true)

theorem identity54649 : scanCanonicalize (H12AffineFastState.compose env54649 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound54649 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env54650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,478,5392,10280,1024,8660,4160,4194304,16,8662,8328,65,4205044,5392,4097,2556,1500,4194440,256,32,5456,9173]

theorem envBound54650 : H12AffineFastState.Bounded env54650 := by
  intro p hp
  have h : env54650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54649_54650 : H12AffineEnvironment.transform 15 478 env54649 = env54650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env54649 == env54650) = true)

theorem identity54650 : scanCanonicalize (H12AffineFastState.compose env54650 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound54650 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,478,5392,2556,1024,0,4160,4194304,16,2,348,65,4196384,5392,4097,2556,1500,4194440,256,32,5456,513]

theorem envBound54651 : H12AffineFastState.Bounded env54651 := by
  intro p hp
  have h : env54651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54650_54651 : H12AffineEnvironment.transform 12 468 env54650 = env54651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env54650 == env54651) = true)

theorem identity54651 : scanCanonicalize (H12AffineFastState.compose env54651 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound54651 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,478,5392,2556,1024,0,4160,112,16,2,348,65,2128,5392,4097,2556,1500,248,256,32,5456,513]

theorem envBound54652 : H12AffineFastState.Bounded env54652 := by
  intro p hp
  have h : env54652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54651_54652 : H12AffineEnvironment.transform 21 112 env54651 = env54652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env54651 == env54652) = true)

theorem identity54652 : scanCanonicalize (H12AffineFastState.compose env54652 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54652 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env54653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5392,2421,1024,0,4160,112,16,2,348,65,2128,5392,4097,2421,1365,113,256,32,5456,513]

theorem envBound54653 : H12AffineFastState.Bounded env54653 := by
  intro p hp
  have h : env54653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54652_54653 : H12AffineEnvironment.transform 6 9 env54652 = env54653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54652 == env54653) = true)

theorem identity54653 : scanCanonicalize (H12AffineFastState.compose env54653 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54653 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54654 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1024,0,4113,33,16,2,269,16,2049,5392,4097,2340,1284,32,256,32,5377,513]

theorem envBound54654 : H12AffineFastState.Bounded env54654 := by
  intro p hp
  have h : env54654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54653_54654 : H12AffineEnvironment.transform 5 17 env54653 = env54654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54653 == env54654) = true)

theorem identity54654 : scanCanonicalize (H12AffineFastState.compose env54654 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound54654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54655 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2586,268,3867,1,262,3850,2340,1024,0,2571,33,16,2,269,16,2049,3850,2587,2340,1284,32,256,32,3867,513]

theorem envBound54655 : H12AffineFastState.Bounded env54655 := by
  intro p hp
  have h : env54655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54654_54655 : H12AffineEnvironment.transform 11 2586 env54654 = env54655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env54654 == env54655) = true)

theorem identity54655 : scanCanonicalize (H12AffineFastState.compose env54655 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound54655 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54656 : List Nat := [2,4,8,16,32,17,9,256,512,1024,783,277,268,1044,1,262,1029,555,1024,0,260,33,16,2,269,16,782,1029,276,555,1284,32,256,32,1044,513]

theorem envBound54656 : H12AffineFastState.Bounded env54656 := by
  intro p hp
  have h : env54656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54655_54656 : H12AffineEnvironment.transform 10 783 env54655 = env54656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env54655 == env54656) = true)

theorem identity54656 : scanCanonicalize (H12AffineFastState.compose env54656 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound54656 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54657 : List Nat := [2,4,8,16,32,17,9,256,512,543,783,277,268,523,1,262,538,555,543,0,260,33,16,2,269,16,782,538,276,555,795,32,256,32,523,513]

theorem envBound54657 : H12AffineFastState.Bounded env54657 := by
  intro p hp
  have h : env54657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54656_54657 : H12AffineEnvironment.transform 9 543 env54656 = env54657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env54656 == env54657) = true)

def env54658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,17,98780,8328,65,4270122,5392,17664,109046,1500,4256860,256,21792,46212,74251]

theorem envBound54658 : H12AffineFastState.Bounded env54658 := by
  intro p hp
  have h : env54658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54631_54658 : H12AffineEnvironment.transform 20 4161 env54631 = env54658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54631 == env54658) = true)

theorem identity54658 : scanCanonicalize (H12AffineFastState.compose env54658 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156013) := by decide +kernel

theorem selectedBound54658 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,156013,17,98780,8328,65,215367,5392,17664,109046,1500,169265,256,21792,46212,74251]

theorem envBound54659 : H12AffineFastState.Bounded env54659 := by
  intro p hp
  have h : env54659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54658_54659 : H12AffineEnvironment.transform 21 156013 env54658 = env54659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env54658 == env54659) = true)

def env54660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,156013,17,98644,8192,65,215367,5392,17664,108926,1364,169265,256,21792,46092,74251]

theorem envBound54660 : H12AffineFastState.Bounded env54660 := by
  intro p hp
  have h : env54660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54659_54660 : H12AffineEnvironment.transform 6 8 env54659 = env54660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54659 == env54660) = true)

theorem identity54660 : scanCanonicalize (H12AffineFastState.compose env54660 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54660 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4161,156013,17,73736,8192,65,215367,5392,17664,67618,1364,144493,256,21792,5456,74251]

theorem envBound54661 : H12AffineFastState.Bounded env54661 := by
  intro p hp
  have h : env54661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54660_54661 : H12AffineEnvironment.transform 14 8540 env54660 = env54661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54660 == env54661) = true)

theorem identity54661 : scanCanonicalize (H12AffineFastState.compose env54661 (packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound54661 : packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,79179,23588,1024,8541,4161,87078,17,73736,8192,65,31756,5392,17664,67618,1364,65830,256,21792,5456,74251]

theorem envBound54662 : H12AffineFastState.Bounded env54662 := by
  intro p hp
  have h : env54662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54661_54662 : H12AffineEnvironment.transform 16 79179 env54661 = env54662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env54661 == env54662) = true)

theorem identity54662 : scanCanonicalize (H12AffineFastState.compose env54662 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound54662 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env54663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30043,16400,23588,1024,8541,4161,8573,17,21843,8192,65,31756,5392,17664,32121,1364,29821,256,21792,5456,22352]

theorem envBound54663 : H12AffineFastState.Bounded env54663 := by
  intro p hp
  have h : env54663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54662_54663 : H12AffineEnvironment.transform 15 30043 env54662 = env54663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env54662 == env54663) = true)

theorem identity54663 : scanCanonicalize (H12AffineFastState.compose env54663 (packedSelected [2,4,6,7,10,11,12,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound54663 : packedSelected [2,4,6,7,10,11,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env54664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,8540,1331,12408,11340,1024,8541,4161,8573,17,9531,8192,65,3172,5392,13672,3345,1364,1045,256,9544,5456,10040]

theorem envBound54664 : H12AffineFastState.Bounded env54664 := by
  intro p hp
  have h : env54664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54663_54664 : H12AffineEnvironment.transform 13 12392 env54663 = env54664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env54663 == env54664) = true)

theorem identity54664 : scanCanonicalize (H12AffineFastState.compose env54664 (packedSelected [2,3,5,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54664 : packedSelected [2,3,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54665 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,12392,8313,1046,12408,11340,1024,8312,4161,8280,17,9246,8192,65,3172,5173,13389,3124,1137,1045,37,9325,5237,9757]

theorem envBound54665 : H12AffineFastState.Bounded env54665 := by
  intro p hp
  have h : env54665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54664_54665 : H12AffineEnvironment.transform 7 37 env54664 = env54665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54664 == env54665) = true)

theorem identity54665 : scanCanonicalize (H12AffineFastState.compose env54665 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound54665 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54666 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,4113,0,1046,4097,3125,1024,1,4161,33,17,1127,121,65,3172,5173,5172,3124,1137,1045,37,1044,5237,1636]

theorem envBound54666 : H12AffineFastState.Bounded env54666 := by
  intro p hp
  have h : env54666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54665_54666 : H12AffineEnvironment.transform 12 121 env54665 = env54666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env54665 == env54666) = true)

theorem identity54666 : scanCanonicalize (H12AffineFastState.compose env54666 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound54666 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env54667 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,2064,121,2049,0,1046,2065,3125,1024,1,2129,33,17,1127,121,65,3172,3109,3108,3124,1137,1045,37,1044,3173,1636]

theorem envBound54667 : H12AffineFastState.Bounded env54667 := by
  intro p hp
  have h : env54667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54666_54667 : H12AffineEnvironment.transform 11 2064 env54666 = env54667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env54666 == env54667) = true)

theorem identity54667 : scanCanonicalize (H12AffineFastState.compose env54667 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54667 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54668 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2064,121,2049,0,34,2065,2049,52,1,2129,33,17,83,121,65,2128,2065,2064,2048,69,33,37,32,2129,592]

theorem envBound54668 : H12AffineFastState.Bounded env54668 := by
  intro p hp
  have h : env54668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54667_54668 : H12AffineEnvironment.transform 9 52 env54667 = env54668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54667 == env54668) = true)

theorem identity54668 : scanCanonicalize (H12AffineFastState.compose env54668 (packedSelected [1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound54668 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env54669 : List Nat := [2,4,8,16,32,33,8,37,512,52,2048,2064,24,2049,0,34,2065,2049,52,1,2096,33,17,50,24,32,2097,2065,2064,2048,36,33,37,32,2096,561]

theorem envBound54669 : H12AffineFastState.Bounded env54669 := by
  intro p hp
  have h : env54669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54668_54669 : H12AffineEnvironment.transform 5 33 env54668 = env54669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env54668 == env54669) = true)

theorem identity54669 : scanCanonicalize (H12AffineFastState.compose env54669 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54669 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54670 : List Nat := [2,4,8,16,17,16,8,20,512,5,2048,2064,24,2049,0,19,2065,2049,5,1,2049,16,17,3,24,17,2048,2065,2064,2048,21,16,20,17,2049,512]

theorem envBound54670 : H12AffineFastState.Bounded env54670 := by
  intro p hp
  have h : env54670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54669_54670 : H12AffineEnvironment.transform 4 17 env54669 = env54670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54669 == env54670) = true)

theorem identity54670 : scanCanonicalize (H12AffineFastState.compose env54670 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound54670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54671 : List Nat := [2,4,8,16,17,16,8,20,512,5,512,528,24,513,0,19,529,513,5,1,513,16,17,3,24,17,512,529,528,512,21,16,20,17,513,512]

theorem envBound54671 : H12AffineFastState.Bounded env54671 := by
  intro p hp
  have h : env54671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54670_54671 : H12AffineEnvironment.transform 10 512 env54670 = env54671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env54670 == env54671) = true)

theorem identity54671 : scanCanonicalize (H12AffineFastState.compose env54671 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound54671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54672 : List Nat := [2,4,8,16,17,16,8,20,5,5,5,21,24,4,0,19,20,4,5,1,4,16,17,3,24,17,5,20,21,5,21,16,20,17,4,5]

theorem envBound54672 : H12AffineFastState.Bounded env54672 := by
  intro p hp
  have h : env54672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54671_54672 : H12AffineEnvironment.transform 8 5 env54671 = env54672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env54671 == env54672) = true)

theorem identity54672 : scanCanonicalize (H12AffineFastState.compose env54672 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54672 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54673 : List Nat := [2,4,8,0,1,0,8,4,5,5,5,5,8,4,0,3,4,4,5,1,4,0,1,3,8,1,5,4,5,5,5,0,4,1,4,5]

theorem envBound54673 : H12AffineFastState.Bounded env54673 := by
  intro p hp
  have h : env54673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54672_54673 : H12AffineEnvironment.transform 3 0 env54672 = env54673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54672 == env54673) = true)

def env54674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,156013,17,98645,8193,65,215367,5392,17664,108927,1365,169265,256,21792,46093,74251]

theorem envBound54674 : H12AffineFastState.Bounded env54674 := by
  intro p hp
  have h : env54674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54659_54674 : H12AffineEnvironment.transform 6 9 env54659 = env54674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54659 == env54674) = true)

theorem identity54674 : scanCanonicalize (H12AffineFastState.compose env54674 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38208) := by decide +kernel

theorem selectedBound54674 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38208,130094,1024,32769,4161,62509,17,98645,8193,65,121863,5392,17664,108927,1365,113,256,21792,46093,74251]

theorem envBound54675 : H12AffineFastState.Bounded env54675 := by
  intro p hp
  have h : env54675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54674_54675 : H12AffineEnvironment.transform 16 38208 env54674 = env54675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38208 env54674 == env54675) = true)

theorem identity54675 : scanCanonicalize (H12AffineFastState.compose env54675 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54675 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env54676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,5440,97326,1024,1,4161,29741,17,65877,8193,65,89095,5392,17664,76159,1365,113,256,21792,13325,74251]

theorem envBound54676 : H12AffineFastState.Bounded env54676 := by
  intro p hp
  have h : env54676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54675_54676 : H12AffineEnvironment.transform 14 0 env54675 = env54676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54675 == env54676) = true)

theorem identity54676 : scanCanonicalize (H12AffineFastState.compose env54676 (packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54676 : packedSelected [1,4,7,9,10,16,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,65536,5440,89459,1024,1,4161,21872,17,65877,348,65,89095,5392,17664,67618,1365,113,256,21792,5456,66390]

theorem envBound54677 : H12AffineFastState.Bounded env54677 := by
  intro p hp
  have h : env54677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54676_54677 : H12AffineEnvironment.transform 12 349 env54676 = env54677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54676 == env54677) = true)

theorem identity54677 : scanCanonicalize (H12AffineFastState.compose env54677 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54677 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54678 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,0,65536,5173,89094,1024,1,4161,21509,17,65568,41,65,89095,5221,17525,67618,1056,113,117,21589,5157,66083]

theorem envBound54678 : H12AffineFastState.Bounded env54678 := by
  intro p hp
  have h : env54678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54677_54678 : H12AffineEnvironment.transform 7 117 env54677 = env54678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54677 == env54678) = true)

theorem identity54678 : scanCanonicalize (H12AffineFastState.compose env54678 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54678 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54679 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,0,65536,5173,67619,1024,1,4161,32,17,65568,41,65,67618,5221,4176,67618,1056,113,117,112,5157,66083]

theorem envBound54679 : H12AffineFastState.Bounded env54679 := by
  intro p hp
  have h : env54679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54678_54679 : H12AffineEnvironment.transform 13 5157 env54678 = env54679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54678 == env54679) = true)

theorem identity54679 : scanCanonicalize (H12AffineFastState.compose env54679 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4195) := by decide +kernel

theorem selectedBound54679 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env54680 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,0,4195,5173,6208,1024,1,4161,32,17,4163,41,65,6209,5221,4176,6209,1056,113,117,112,5157,4672]

theorem envBound54680 : H12AffineFastState.Bounded env54680 := by
  intro p hp
  have h : env54680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54679_54680 : H12AffineEnvironment.transform 15 4195 env54679 = env54680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4195 env54679 == env54680) = true)

theorem identity54680 : scanCanonicalize (H12AffineFastState.compose env54680 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound54680 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54681 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,40,2048,0,3142,2064,1125,1024,1,3172,32,17,3174,41,65,1124,2112,3189,1124,1056,113,117,112,2048,3685]

theorem envBound54681 : H12AffineFastState.Bounded env54681 := by
  intro p hp
  have h : env54681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54680_54681 : H12AffineEnvironment.transform 11 3109 env54680 = env54681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env54680 == env54681) = true)

theorem identity54681 : scanCanonicalize (H12AffineFastState.compose env54681 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54681 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54682 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2112,40,2048,0,2083,2064,0,101,1,2049,32,17,2051,41,65,1,2112,2064,1,69,113,117,112,2048,2560]

theorem envBound54682 : H12AffineFastState.Bounded env54682 := by
  intro p hp
  have h : env54682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54681_54682 : H12AffineEnvironment.transform 9 101 env54681 = env54682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54681 == env54682) = true)

theorem identity54682 : scanCanonicalize (H12AffineFastState.compose env54682 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54682 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env54683 : List Nat := [2,4,8,16,32,64,9,117,512,101,1,65,40,1,0,34,17,0,101,1,0,32,17,2,41,65,1,65,17,1,69,113,117,112,1,513]

theorem envBound54683 : H12AffineFastState.Bounded env54683 := by
  intro p hp
  have h : env54683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54682_54683 : H12AffineEnvironment.transform 10 1 env54682 = env54683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54682 == env54683) = true)

def env54684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270123,5392,17665,2210230,1501,4256860,256,2114912,2139332,74250]

theorem envBound54684 : H12AffineFastState.Bounded env54684 := by
  intro p hp
  have h : env54684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54630_54684 : H12AffineEnvironment.transform 22 2101329 env54630 = env54684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env54630 == env54684) = true)

def env54685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,4194304,17,98781,8328,65,4270123,5392,17665,109046,1501,4256860,256,21792,46212,74250]

theorem envBound54685 : H12AffineFastState.Bounded env54685 := by
  intro p hp
  have h : env54685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54684_54685 : H12AffineEnvironment.transform 20 4160 env54684 = env54685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54684 == env54685) = true)

theorem identity54685 : scanCanonicalize (H12AffineFastState.compose env54685 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound54685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4160,169401,17,98781,8328,65,245138,5392,17665,109046,1501,156133,256,21792,46212,74250]

theorem envBound54686 : H12AffineFastState.Bounded env54686 := by
  intro p hp
  have h : env54686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54685_54686 : H12AffineEnvironment.transform 21 169401 env54685 = env54686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env54685 == env54686) = true)

def env54687 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169265,17,98645,8192,65,245018,5392,17665,108926,1365,156013,256,21792,46092,74250]

theorem envBound54687 : H12AffineFastState.Bounded env54687 := by
  intro p hp
  have h : env54687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54686_54687 : H12AffineEnvironment.transform 6 8 env54686 = env54687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54686 == env54687) = true)

theorem identity54687 : scanCanonicalize (H12AffineFastState.compose env54687 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4160,144493,17,73737,8192,65,203846,5392,17665,67618,1365,156013,256,21792,5456,74250]

theorem envBound54688 : H12AffineFastState.Bounded env54688 := by
  intro p hp
  have h : env54688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54687_54688 : H12AffineEnvironment.transform 14 8540 env54687 = env54688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54687 == env54688) = true)

theorem identity54688 : scanCanonicalize (H12AffineFastState.compose env54688 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound54688 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env54689 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8495,131072,149568,1024,8541,4160,144493,17,294,8192,65,146793,5392,17665,10509,1365,156013,256,21792,5456,805]

theorem envBound54689 : H12AffineFastState.Bounded env54689 := by
  intro p hp
  have h : env54689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54688_54689 : H12AffineEnvironment.transform 15 8495 env54688 = env54689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env54688 == env54689) = true)

theorem identity54689 : scanCanonicalize (H12AffineFastState.compose env54689 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound54689 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,26] rootPS < 2^1333 := by decide +kernel

def env54690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8495,16449,2049,1024,8541,4160,29740,17,294,8192,65,32040,5392,17665,10509,1365,8492,256,21792,5456,805]

theorem envBound54690 : H12AffineFastState.Bounded env54690 := by
  intro p hp
  have h : env54690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54689_54690 : H12AffineEnvironment.transform 16 16449 env54689 = env54690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env54689 == env54690) = true)

theorem identity54690 : scanCanonicalize (H12AffineFastState.compose env54690 (packedSelected [2,4,6,11,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54690 : packedSelected [2,4,6,11,20,22,23] rootPS < 2^1333 := by decide +kernel

def env54691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,373,262,16449,2049,1024,372,4160,21509,17,294,41,65,23809,5392,17665,2340,1365,261,256,21792,5456,805]

theorem envBound54691 : H12AffineFastState.Bounded env54691 := by
  intro p hp
  have h : env54691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54690_54691 : H12AffineEnvironment.transform 12 41 env54690 = env54691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54690 == env54691) = true)

theorem identity54691 : scanCanonicalize (H12AffineFastState.compose env54691 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54691 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env54692 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,80,35,16449,2049,1024,81,4160,21509,17,3,41,65,23588,5173,17444,2049,1136,32,37,21509,5237,512]

theorem envBound54692 : H12AffineFastState.Bounded env54692 := by
  intro p hp
  have h : env54692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54691_54692 : H12AffineEnvironment.transform 7 37 env54691 = env54692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54691 == env54692) = true)

theorem identity54692 : scanCanonicalize (H12AffineFastState.compose env54692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54693 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,35,16400,2049,1024,0,4113,21509,17,3,41,16,23588,5173,17444,2049,1057,32,37,21509,5156,512]

theorem envBound54693 : H12AffineFastState.Bounded env54693 := by
  intro p hp
  have h : env54693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54692_54693 : H12AffineEnvironment.transform 5 17 env54692 = env54693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54692 == env54693) = true)

theorem identity54693 : scanCanonicalize (H12AffineFastState.compose env54693 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54693 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54694 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,16384,1,2,16400,2049,1024,0,4113,21509,17,3,8,16,23557,5140,17413,2049,1024,1,4,21509,5125,512]

theorem envBound54694 : H12AffineFastState.Bounded env54694 := by
  intro p hp
  have h : env54694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54693_54694 : H12AffineEnvironment.transform 4 1 env54693 = env54694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54693 == env54694) = true)

theorem identity54694 : scanCanonicalize (H12AffineFastState.compose env54694 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound54694 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54695 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,4096,8,16384,1,2,16400,1054,1024,0,4113,21509,17,3,8,16,20506,5140,17413,1054,1024,1,4,21509,5125,512]

theorem envBound54695 : H12AffineFastState.Bounded env54695 := by
  intro p hp
  have h : env54695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54694_54695 : H12AffineEnvironment.transform 10 1055 env54694 = env54695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env54694 == env54695) = true)

theorem identity54695 : scanCanonicalize (H12AffineFastState.compose env54695 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound54695 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1