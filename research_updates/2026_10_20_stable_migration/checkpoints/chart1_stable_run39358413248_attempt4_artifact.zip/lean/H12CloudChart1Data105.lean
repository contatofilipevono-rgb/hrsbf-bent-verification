import H12CloudChart1Data104

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env26602 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4405,33,294,4389,2308,52,32,4112,32,16,3,300,17,2081,4388,4097,2340,304,32,256,32,4405,513]

theorem envBound26602 : H12AffineFastState.Bounded env26602 := by
  intro p hp
  have h : env26602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26601_26602 : H12AffineEnvironment.transform 9 52 env26601 = env26602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26601 == env26602) = true)

theorem identity26602 : scanCanonicalize (H12AffineFastState.compose env26602 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound26602 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26603 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2325,301,2080,33,294,2096,2308,52,32,2309,32,16,3,300,17,2081,2097,2324,2340,304,32,256,32,2080,513]

theorem envBound26603 : H12AffineFastState.Bounded env26603 := by
  intro p hp
  have h : env26603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26602_26603 : H12AffineEnvironment.transform 11 2325 env26602 = env26603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env26602 == env26603) = true)

theorem identity26603 : scanCanonicalize (H12AffineFastState.compose env26603 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound26603 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26604 : List Nat := [2,4,8,16,32,17,9,256,309,52,2048,2325,301,2080,33,294,2096,2308,52,32,2309,32,16,3,300,17,2081,2097,2324,2340,304,32,256,32,2080,308]

theorem envBound26604 : H12AffineFastState.Bounded env26604 := by
  intro p hp
  have h : env26604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26603_26604 : H12AffineEnvironment.transform 8 309 env26603 = env26604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env26603 == env26604) = true)

theorem identity26604 : scanCanonicalize (H12AffineFastState.compose env26604 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26604 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env26605 : List Nat := [2,4,8,16,32,17,9,37,16,52,2048,2096,8,2080,33,3,2096,2081,52,32,2080,32,16,3,9,17,2081,2097,2097,2049,21,32,37,32,2080,17]

theorem envBound26605 : H12AffineFastState.Bounded env26605 := by
  intro p hp
  have h : env26605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26604_26605 : H12AffineEnvironment.transform 7 37 env26604 = env26605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26604 == env26605) = true)

theorem identity26605 : scanCanonicalize (H12AffineFastState.compose env26605 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26606 : List Nat := [2,4,8,1,32,0,9,37,1,37,2048,2081,8,2080,33,3,2081,2081,37,32,2080,32,1,3,9,0,2081,2080,2080,2049,4,32,37,32,2080,0]

theorem envBound26606 : H12AffineFastState.Bounded env26606 := by
  intro p hp
  have h : env26606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26605_26606 : H12AffineEnvironment.transform 3 1 env26605 = env26606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26605 == env26606) = true)

theorem identity26606 : scanCanonicalize (H12AffineFastState.compose env26606 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound26606 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26607 : List Nat := [2,4,8,1,32,0,9,37,1,37,33,0,8,1,33,3,0,0,37,32,1,32,1,3,9,0,0,1,1,32,4,32,37,32,1,0]

theorem envBound26607 : H12AffineFastState.Bounded env26607 := by
  intro p hp
  have h : env26607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26606_26607 : H12AffineEnvironment.transform 10 33 env26606 = env26607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env26606 == env26607) = true)

def env26608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,78019,32,73874,73736,8328,64,203983,79131,4232,212199,75223,73890,256,32,5456,513]

theorem envBound26608 : H12AffineFastState.Bounded env26608 := by
  intro p hp
  have h : env26608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26595_26608 : H12AffineEnvironment.transform 17 10401 env26595 = env26608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env26595 == env26608) = true)

theorem identity26608 : scanCanonicalize (H12AffineFastState.compose env26608 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound26608 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,79251,10401,1024,8540,78019,32,73874,73736,8328,64,10588,79131,4232,2420,75223,73890,256,32,5456,513]

theorem envBound26609 : H12AffineFastState.Bounded env26609 := by
  intro p hp
  have h : env26609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26608_26609 : H12AffineEnvironment.transform 16 79251 env26608 = env26609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env26608 == env26609) = true)

theorem identity26609 : scanCanonicalize (H12AffineFastState.compose env26609 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound26609 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env26610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8541,65536,75923,10401,1024,8540,77251,32,73874,73736,8328,64,10588,75803,3464,2420,75223,73890,256,32,2128,513]

theorem envBound26610 : H12AffineFastState.Bounded env26610 := by
  intro p hp
  have h : env26610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26609_26610 : H12AffineEnvironment.transform 11 3328 env26609 = env26610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env26609 == env26610) = true)

theorem identity26610 : scanCanonicalize (H12AffineFastState.compose env26610 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound26610 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8541,8322,2065,10401,1024,8540,3393,32,16,138,8328,64,10588,2201,3464,2420,1365,32,256,32,2128,513]

theorem envBound26611 : H12AffineFastState.Bounded env26611 := by
  intro p hp
  have h : env26611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26610_26611 : H12AffineEnvironment.transform 15 8322 env26610 = env26611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env26610 == env26611) = true)

theorem identity26611 : scanCanonicalize (H12AffineFastState.compose env26611 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound26611 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,8192,137,8541,8322,16,8352,1024,8540,1344,32,16,138,8328,64,8541,152,1417,373,1365,32,256,32,81,513]

theorem envBound26612 : H12AffineFastState.Bounded env26612 := by
  intro p hp
  have h : env26612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26611_26612 : H12AffineEnvironment.transform 10 1 env26611 = env26612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26611 == env26612) = true)

theorem identity26612 : scanCanonicalize (H12AffineFastState.compose env26612 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound26612 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,1337,137,1124,1467,16,1433,1024,1125,1344,32,16,138,1457,64,1124,152,1417,373,1365,32,256,32,81,513]

theorem envBound26613 : H12AffineFastState.Bounded env26613 := by
  intro p hp
  have h : env26613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26612_26613 : H12AffineEnvironment.transform 12 1337 env26612 = env26613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env26612 == env26613) = true)

theorem identity26613 : scanCanonicalize (H12AffineFastState.compose env26613 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26613 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1281,1337,0,1124,1330,16,1296,1024,1125,1344,32,16,3,1336,64,1124,17,1280,373,1365,32,256,32,81,513]

theorem envBound26614 : H12AffineFastState.Bounded env26614 := by
  intro p hp
  have h : env26614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26613_26614 : H12AffineEnvironment.transform 6 9 env26613 = env26614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26613 == env26614) = true)

theorem identity26614 : scanCanonicalize (H12AffineFastState.compose env26614 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26614 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26615 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1,1060,1052,0,1124,1047,16,1077,1024,1125,1125,32,16,3,1053,64,1124,17,1061,80,1136,32,37,32,81,513]

theorem envBound26615 : H12AffineFastState.Bounded env26615 := by
  intro p hp
  have h : env26615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26614_26615 : H12AffineEnvironment.transform 7 37 env26614 = env26615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26614 == env26615) = true)

theorem identity26615 : scanCanonicalize (H12AffineFastState.compose env26615 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26615 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26616 : List Nat := [2,4,8,16,32,64,9,37,512,52,1,16,40,0,80,35,16,1,52,81,81,32,16,3,41,64,80,17,17,80,68,32,37,32,81,513]

theorem envBound26616 : H12AffineFastState.Bounded env26616 := by
  intro p hp
  have h : env26616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26615_26616 : H12AffineEnvironment.transform 9 52 env26615 = env26616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26615 == env26616) = true)

theorem identity26616 : scanCanonicalize (H12AffineFastState.compose env26616 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26617 : List Nat := [2,4,8,16,32,16,9,37,512,52,1,16,40,0,0,35,16,1,52,1,1,32,16,3,41,16,0,17,17,0,20,32,37,32,1,513]

theorem envBound26617 : H12AffineFastState.Bounded env26617 := by
  intro p hp
  have h : env26617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26616_26617 : H12AffineEnvironment.transform 5 16 env26616 = env26617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26616 == env26617) = true)

theorem identity26617 : scanCanonicalize (H12AffineFastState.compose env26617 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26618 : List Nat := [2,4,8,16,0,16,9,5,512,20,1,16,8,0,0,3,16,1,20,1,1,0,16,3,9,16,0,17,17,0,20,0,5,0,1,513]

theorem envBound26618 : H12AffineFastState.Bounded env26618 := by
  intro p hp
  have h : env26618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26617_26618 : H12AffineEnvironment.transform 4 0 env26617 = env26618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26617 == env26618) = true)

theorem identity26618 : scanCanonicalize (H12AffineFastState.compose env26618 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26619 : List Nat := [2,4,8,1,0,1,9,5,512,5,1,1,8,0,0,3,1,1,5,1,1,0,1,3,9,1,0,0,0,0,5,0,5,0,1,513]

theorem envBound26619 : H12AffineFastState.Bounded env26619 := by
  intro p hp
  have h : env26619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26618_26619 : H12AffineEnvironment.transform 3 1 env26618 = env26619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26618 == env26619) = true)

def env26620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787197,79131,8466458,8820105,8389957,98814,256,8462514,8492191,8462995]

theorem envBound26620 : H12AffineFastState.Bounded env26620 := by
  intro p hp
  have h : env26620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26592_26620 : H12AffineEnvironment.transform 21 33 env26592 = env26620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26592 == env26620) = true)

theorem identity26620 : scanCanonicalize (H12AffineFastState.compose env26620 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound26620 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,262144,1024,32769,45340,33,8388608,138,8328,64,8787197,46276,8434117,8820105,8389957,33,256,8429933,8394048,8430412]

theorem envBound26621 : H12AffineFastState.Bounded env26621 := by
  intro p hp
  have h : env26621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26620_26621 : H12AffineEnvironment.transform 15 33247 env26620 = env26621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env26620 == env26621) = true)

theorem identity26621 : scanCanonicalize (H12AffineFastState.compose env26621 (packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound26621 : packedSelected [0,3,9,10,11,12,14,15,18,22,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env26622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,10400,1024,32769,45340,33,8388608,138,8328,64,8535133,46276,8434117,8568105,8389957,33,256,8429933,8394048,8430412]

theorem envBound26622 : H12AffineFastState.Bounded env26622 := by
  intro p hp
  have h : env26622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26621_26622 : H12AffineEnvironment.transform 17 10400 env26621 = env26622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26621 == env26622) = true)

def env26623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,10280,1024,32769,45340,33,8388608,2,8192,64,8535133,46156,8433997,8568105,8389957,33,256,8429933,8394048,8430412]

theorem envBound26623 : H12AffineFastState.Bounded env26623 := by
  intro p hp
  have h : env26623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26622_26623 : H12AffineEnvironment.transform 6 8 env26622 = env26623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26622 == env26623) = true)

theorem identity26623 : scanCanonicalize (H12AffineFastState.compose env26623 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound26623 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env26624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,13340,10280,1024,32769,45340,33,8388608,2,8192,64,8390721,46156,8433997,8423733,8389957,33,256,8429933,8394048,8430412]

theorem envBound26624 : H12AffineFastState.Bounded env26624 := by
  intro p hp
  have h : env26624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26623_26624 : H12AffineEnvironment.transform 16 13340 env26623 = env26624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env26623 == env26624) = true)

theorem identity26624 : scanCanonicalize (H12AffineFastState.compose env26624 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound26624 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,13340,10280,1024,32769,45340,33,41293,2,8192,64,43276,46156,4096,10360,41992,33,256,32,46093,513]

theorem envBound26625 : H12AffineFastState.Bounded env26625 := by
  intro p hp
  have h : env26625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26624_26625 : H12AffineEnvironment.transform 22 41293 env26624 = env26625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env26624 == env26625) = true)

theorem identity26625 : scanCanonicalize (H12AffineFastState.compose env26625 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26625 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,13340,10280,1024,8541,4160,33,17,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5457,513]

theorem envBound26626 : H12AffineFastState.Bounded env26626 := by
  intro p hp
  have h : env26626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26625_26626 : H12AffineEnvironment.transform 14 8540 env26625 = env26626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26625 == env26626) = true)

theorem identity26626 : scanCanonicalize (H12AffineFastState.compose env26626 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26626 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,262,5393,2341,1024,80,4160,33,17,2,269,64,2128,5392,4096,2421,1364,33,256,32,5457,513]

theorem envBound26627 : H12AffineFastState.Bounded env26627 := by
  intro p hp
  have h : env26627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26626_26627 : H12AffineEnvironment.transform 12 269 env26626 = env26627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26626 == env26627) = true)

theorem identity26627 : scanCanonicalize (H12AffineFastState.compose env26627 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1866) := by decide +kernel

theorem selectedBound26627 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1866,4096,269,5376,81,262,5393,1647,1024,80,4160,33,17,2,269,64,1818,5392,4096,1599,1364,33,256,32,5457,513]

theorem envBound26628 : H12AffineFastState.Bounded env26628 := by
  intro p hp
  have h : env26628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26627_26628 : H12AffineEnvironment.transform 10 1866 env26627 = env26628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1866 env26627 == env26628) = true)

theorem identity26628 : scanCanonicalize (H12AffineFastState.compose env26628 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound26628 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26629 : List Nat := [2,4,8,16,32,64,8,256,512,321,523,4096,269,4161,81,262,4176,814,321,80,4160,33,17,2,269,64,603,4177,4096,894,21,33,256,32,4112,513]

theorem envBound26629 : H12AffineFastState.Bounded env26629 := by
  intro p hp
  have h : env26629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26628_26629 : H12AffineEnvironment.transform 9 321 env26628 = env26629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26628 == env26629) = true)

theorem identity26629 : scanCanonicalize (H12AffineFastState.compose env26629 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26629 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26630 : List Nat := [2,4,8,16,32,64,8,36,512,101,523,4096,41,4161,81,34,4176,522,101,80,4160,33,17,2,41,64,603,4177,4096,602,21,33,36,32,4112,513]

theorem envBound26630 : H12AffineFastState.Bounded env26630 := by
  intro p hp
  have h : env26630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26629_26630 : H12AffineEnvironment.transform 7 36 env26629 = env26630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26629 == env26630) = true)

theorem identity26630 : scanCanonicalize (H12AffineFastState.compose env26630 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26630 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26631 : List Nat := [2,4,8,16,32,17,8,36,512,52,523,4096,41,4112,0,34,4097,522,52,1,4113,33,17,2,41,17,522,4096,4096,523,21,33,36,32,4112,513]

theorem envBound26631 : H12AffineFastState.Bounded env26631 := by
  intro p hp
  have h : env26631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26630_26631 : H12AffineEnvironment.transform 5 17 env26630 = env26631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26630 == env26631) = true)

theorem identity26631 : scanCanonicalize (H12AffineFastState.compose env26631 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 574) := by decide +kernel

theorem selectedBound26631 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26632 : List Nat := [2,4,8,16,32,17,8,36,512,52,523,574,41,558,0,34,575,522,52,1,559,33,17,2,41,17,522,574,574,523,21,33,36,32,558,513]

theorem envBound26632 : H12AffineFastState.Bounded env26632 := by
  intro p hp
  have h : env26632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26631_26632 : H12AffineEnvironment.transform 11 574 env26631 = env26632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 574 env26631 == env26632) = true)

theorem identity26632 : scanCanonicalize (H12AffineFastState.compose env26632 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound26632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26633 : List Nat := [2,4,8,16,7,17,8,3,512,19,523,537,14,521,0,5,536,522,19,1,520,6,17,2,14,17,522,537,537,523,21,6,3,7,521,513]

theorem envBound26633 : H12AffineFastState.Bounded env26633 := by
  intro p hp
  have h : env26633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26632_26633 : H12AffineEnvironment.transform 4 7 env26632 = env26633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env26632 == env26633) = true)

theorem identity26633 : scanCanonicalize (H12AffineFastState.compose env26633 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound26633 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26634 : List Nat := [2,1,8,16,2,17,8,3,512,19,523,537,11,521,0,0,536,522,19,1,520,3,17,2,11,17,522,537,537,523,16,3,3,2,521,513]

theorem envBound26634 : H12AffineFastState.Bounded env26634 := by
  intro p hp
  have h : env26634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26633_26634 : H12AffineEnvironment.transform 1 1 env26633 = env26634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env26633 == env26634) = true)

def env26635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10281,1024,32769,45340,33,8388608,3,8193,64,8535133,46157,8433996,8568105,8389957,33,256,8429933,8394048,8430412]

theorem envBound26635 : H12AffineFastState.Bounded env26635 := by
  intro p hp
  have h : env26635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26622_26635 : H12AffineEnvironment.transform 6 9 env26622 = env26635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26622 == env26635) = true)

theorem identity26635 : scanCanonicalize (H12AffineFastState.compose env26635 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(22+1) ^^^ 9308) := by decide +kernel

theorem selectedBound26635 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env26636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10281,1024,32769,45340,33,9308,3,8193,64,137217,46157,38160,170357,8473,33,256,34097,12572,34576]

theorem envBound26636 : H12AffineFastState.Bounded env26636 := by
  intro p hp
  have h : env26636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26635_26636 : H12AffineEnvironment.transform 22 9308 env26635 = env26636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9308 env26635 == env26636) = true)

theorem identity26636 : scanCanonicalize (H12AffineFastState.compose env26636 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound26636 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,33110,131072,3173,1024,32769,38224,33,16,3,1101,64,137217,36865,38160,170357,1365,33,256,34097,5456,34576]

theorem envBound26637 : H12AffineFastState.Bounded env26637 := by
  intro p hp
  have h : env26637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26636_26637 : H12AffineEnvironment.transform 12 1100 env26636 = env26637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env26636 == env26637) = true)

theorem identity26637 : scanCanonicalize (H12AffineFastState.compose env26637 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 37989) := by decide +kernel

theorem selectedBound26637 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env26638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,32768,33110,37989,3173,1024,32769,38224,33,16,3,1101,64,35940,36865,38160,3344,1365,33,256,34097,5456,34576]

theorem envBound26638 : H12AffineFastState.Bounded env26638 := by
  intro p hp
  have h : env26638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26637_26638 : H12AffineEnvironment.transform 16 37989 env26637 = env26638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37989 env26637 == env26638) = true)

theorem identity26638 : scanCanonicalize (H12AffineFastState.compose env26638 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26638 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,5377,1,343,5220,3173,1024,0,5457,33,16,3,1101,64,3173,4096,5393,3344,1365,33,256,1328,5456,1809]

theorem envBound26639 : H12AffineFastState.Bounded env26639 := by
  intro p hp
  have h : env26639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26638_26639 : H12AffineEnvironment.transform 14 1 env26638 = env26639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26638 == env26639) = true)

theorem identity26639 : scanCanonicalize (H12AffineFastState.compose env26639 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26639 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env26640 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,1100,5157,1,115,5220,3173,1024,0,5237,33,16,3,1101,64,3173,4096,5173,3124,1137,33,36,1044,5236,1589]

theorem envBound26640 : H12AffineFastState.Bounded env26640 := by
  intro p hp
  have h : env26640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26639_26640 : H12AffineEnvironment.transform 7 36 env26639 = env26640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26639 == env26640) = true)

theorem identity26640 : scanCanonicalize (H12AffineFastState.compose env26640 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound26640 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env26641 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,40,4161,1,115,4096,2049,100,0,4113,33,16,3,41,64,2049,4096,4177,2128,21,33,36,112,4112,593]

theorem envBound26641 : H12AffineFastState.Bounded env26641 := by
  intro p hp
  have h : env26641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26640_26641 : H12AffineEnvironment.transform 9 100 env26640 = env26641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env26640 == env26641) = true)

theorem identity26641 : scanCanonicalize (H12AffineFastState.compose env26641 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound26641 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env26642 : List Nat := [2,4,8,16,32,64,9,36,512,100,64,4096,40,4161,1,115,4096,65,100,0,4113,33,16,3,41,64,65,4096,4177,16,21,33,36,112,4112,593]

theorem envBound26642 : H12AffineFastState.Bounded env26642 := by
  intro p hp
  have h : env26642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26641_26642 : H12AffineEnvironment.transform 10 64 env26641 = env26642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env26641 == env26642) = true)

theorem identity26642 : scanCanonicalize (H12AffineFastState.compose env26642 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound26642 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env26643 : List Nat := [2,4,8,16,32,64,9,36,512,100,64,48,40,113,1,115,48,65,100,0,33,33,16,3,41,64,65,48,97,16,21,33,36,112,32,593]

theorem envBound26643 : H12AffineFastState.Bounded env26643 := by
  intro p hp
  have h : env26643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26642_26643 : H12AffineEnvironment.transform 11 48 env26642 = env26643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env26642 == env26643) = true)

theorem identity26643 : scanCanonicalize (H12AffineFastState.compose env26643 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26643 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26644 : List Nat := [2,4,8,16,16,64,9,20,512,84,64,0,24,65,1,67,0,65,84,0,17,17,16,3,25,64,65,0,81,16,21,17,20,64,16,593]

theorem envBound26644 : H12AffineFastState.Bounded env26644 := by
  intro p hp
  have h : env26644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26643_26644 : H12AffineEnvironment.transform 4 16 env26643 = env26644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26643 == env26644) = true)

def env26645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981468,79131,8466458,8820104,8389956,4293086,256,8462515,8492191,8462994]

theorem envBound26645 : H12AffineFastState.Bounded env26645 := by
  intro p hp
  have h : env26645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26591_26645 : H12AffineEnvironment.transform 13 5513 env26591 = env26645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env26591 == env26645) = true)

def env26646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787196,79131,8466458,8820104,8389956,98814,256,8462515,8492191,8462994]

theorem envBound26646 : H12AffineFastState.Bounded env26646 := by
  intro p hp
  have h : env26646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26645_26646 : H12AffineEnvironment.transform 21 32 env26645 = env26646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26645 == env26646) = true)

theorem identity26646 : scanCanonicalize (H12AffineFastState.compose env26646 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound26646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,73755,98644,8328,64,472295,79131,4097,505235,75103,98814,256,168,46212,649]

theorem envBound26647 : H12AffineFastState.Bounded env26647 := by
  intro p hp
  have h : env26647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26646_26647 : H12AffineEnvironment.transform 22 73755 env26646 = env26647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env26646 == env26647) = true)

def env26648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472175,79131,4097,505115,75103,98678,256,32,46092,513]

theorem envBound26648 : H12AffineFastState.Bounded env26648 := by
  intro p hp
  have h : env26648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26647_26648 : H12AffineEnvironment.transform 6 8 env26647 = env26648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26647 == env26648) = true)

theorem identity26648 : scanCanonicalize (H12AffineFastState.compose env26648 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound26648 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,45340,32,41293,2,8192,64,439609,46157,4097,406605,41993,32,256,32,46092,513]

theorem envBound26649 : H12AffineFastState.Bounded env26649 := by
  intro p hp
  have h : env26649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26648_26649 : H12AffineEnvironment.transform 15 33110 env26648 = env26649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env26648 == env26649) = true)

theorem identity26649 : scanCanonicalize (H12AffineFastState.compose env26649 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound26649 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env26650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,171061,1024,32769,45340,32,41293,2,8192,64,10508,46157,4097,43128,41993,32,256,32,46092,513]

theorem envBound26650 : H12AffineFastState.Bounded env26650 := by
  intro p hp
  have h : env26650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26649_26650 : H12AffineEnvironment.transform 17 171061 env26649 = env26650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env26649 == env26650) = true)

theorem identity26650 : scanCanonicalize (H12AffineFastState.compose env26650 (packedSelected [0,3,4,7,9,10,14,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound26650 : packedSelected [0,3,4,7,9,10,14,19,24] rootPS < 2^1333 := by decide +kernel

def env26651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38161,2340,1024,32769,45340,32,41293,2,8192,64,10508,46157,4097,43128,41993,32,256,32,46092,513]

theorem envBound26651 : H12AffineFastState.Bounded env26651 := by
  intro p hp
  have h : env26651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26650_26651 : H12AffineEnvironment.transform 16 38161 env26650 = env26651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env26650 == env26651) = true)

theorem identity26651 : scanCanonicalize (H12AffineFastState.compose env26651 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26651 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env26652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33110,38161,2340,1024,32769,36928,32,32785,2,348,64,2128,38161,4097,35108,34133,32,256,32,38224,513]

theorem envBound26652 : H12AffineFastState.Bounded env26652 := by
  intro p hp
  have h : env26652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26651_26652 : H12AffineEnvironment.transform 12 348 env26651 = env26652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26651 == env26652) = true)

theorem identity26652 : scanCanonicalize (H12AffineFastState.compose env26652 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26652 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5392,2340,1024,0,4161,32,16,2,348,64,2128,5392,4097,2341,1364,32,256,32,5457,513]

theorem envBound26653 : H12AffineFastState.Bounded env26653 := by
  intro p hp
  have h : env26653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26652_26653 : H12AffineEnvironment.transform 14 1 env26652 = env26653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26652 == env26653) = true)

theorem identity26653 : scanCanonicalize (H12AffineFastState.compose env26653 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26653 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1076,348,309,1,343,292,2340,1024,0,1141,32,16,2,348,64,2128,292,1077,2341,1364,32,256,32,357,513]

theorem envBound26654 : H12AffineFastState.Bounded env26654 := by
  intro p hp
  have h : env26654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26653_26654 : H12AffineEnvironment.transform 11 1076 env26653 = env26654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env26653 == env26654) = true)

theorem identity26654 : scanCanonicalize (H12AffineFastState.compose env26654 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 286) := by decide +kernel

theorem selectedBound26654 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env26655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,286,1076,348,309,1,343,292,58,1024,0,1141,32,16,2,348,64,334,292,1077,59,1364,32,256,32,357,513]

theorem envBound26655 : H12AffineFastState.Bounded env26655 := by
  intro p hp
  have h : env26655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26654_26655 : H12AffineEnvironment.transform 10 286 env26654 = env26655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 286 env26654 == env26655) = true)

theorem identity26655 : scanCanonicalize (H12AffineFastState.compose env26655 (packedSelected [1,4,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 126) := by decide +kernel

theorem selectedBound26655 : packedSelected [1,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26656 : List Nat := [2,4,8,16,32,64,8,126,512,1024,96,1076,34,75,1,41,90,58,1024,0,1141,32,16,2,34,64,48,90,1077,59,1066,32,126,32,27,513]

theorem envBound26656 : H12AffineFastState.Bounded env26656 := by
  intro p hp
  have h : env26656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26655_26656 : H12AffineEnvironment.transform 7 126 env26655 = env26656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 126 env26655 == env26656) = true)

theorem identity26656 : scanCanonicalize (H12AffineFastState.compose env26656 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26656 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env26657 : List Nat := [2,4,8,16,32,16,8,46,512,1024,48,1076,34,27,1,41,10,58,1024,0,1061,32,16,2,34,16,48,10,1077,59,1066,32,46,32,27,513]

theorem envBound26657 : H12AffineFastState.Bounded env26657 := by
  intro p hp
  have h : env26657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26656_26657 : H12AffineEnvironment.transform 5 16 env26656 = env26657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26656 == env26657) = true)

theorem identity26657 : scanCanonicalize (H12AffineFastState.compose env26657 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26658 : List Nat := [2,4,8,16,10,16,8,4,512,1024,26,1054,8,27,1,3,10,16,1024,0,1039,10,16,2,8,16,26,10,1055,17,1024,10,4,10,27,513]

theorem envBound26658 : H12AffineFastState.Bounded env26658 := by
  intro p hp
  have h : env26658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26657_26658 : H12AffineEnvironment.transform 4 10 env26657 = env26658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26657 == env26658) = true)

def env26659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,73755,98644,8193,64,472174,79131,4097,505114,75103,98679,256,33,46093,512]

theorem envBound26659 : H12AffineFastState.Bounded env26659 := by
  intro p hp
  have h : env26659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26647_26659 : H12AffineEnvironment.transform 6 9 env26647 = env26659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26647 == env26659) = true)

theorem identity26659 : scanCanonicalize (H12AffineFastState.compose env26659 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound26659 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,45340,32,41292,3,8193,64,439609,46156,4097,406605,41992,32,256,33,46093,512]

theorem envBound26660 : H12AffineFastState.Bounded env26660 := by
  intro p hp
  have h : env26660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26659_26660 : H12AffineEnvironment.transform 15 33111 env26659 = env26660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env26659 == env26660) = true)

theorem identity26660 : scanCanonicalize (H12AffineFastState.compose env26660 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 46188) := by decide +kernel

theorem selectedBound26660 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46188,262144,1024,32769,45340,32,41292,3,8193,64,262485,46156,4097,294945,41992,32,256,33,46093,512]

theorem envBound26661 : H12AffineFastState.Bounded env26661 := by
  intro p hp
  have h : env26661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26660_26661 : H12AffineEnvironment.transform 16 46188 env26660 = env26661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46188 env26660 == env26661) = true)

theorem identity26661 : scanCanonicalize (H12AffineFastState.compose env26661 (packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26661 : packedSelected [1,3,4,5,6,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env26662 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33030,46141,262144,1024,32769,45340,32,41245,3,8193,17,262404,46109,4097,294945,41992,32,256,33,46093,512]

theorem envBound26662 : H12AffineFastState.Bounded env26662 := by
  intro p hp
  have h : env26662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26661_26662 : H12AffineEnvironment.transform 5 17 env26661 = env26662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26661 == env26662) = true)

theorem identity26662 : scanCanonicalize (H12AffineFastState.compose env26662 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound26662 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env26663 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,32768,33030,46141,10280,1024,32769,45340,32,41245,3,8193,17,10540,46109,4097,43017,41992,32,256,33,46093,512]

theorem envBound26663 : H12AffineFastState.Bounded env26663 := by
  intro p hp
  have h : env26663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26662_26663 : H12AffineEnvironment.transform 17 10280 env26662 = env26663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26662 == env26663) = true)

theorem identity26663 : scanCanonicalize (H12AffineFastState.compose env26663 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26663 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26664 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,263,13372,10280,1024,0,12573,32,8476,3,8193,17,10540,13340,4097,10248,9225,32,256,33,13324,512]

theorem envBound26664 : H12AffineFastState.Bounded env26664 := by
  intro p hp
  have h : env26664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26663_26664 : H12AffineEnvironment.transform 14 1 env26663 = env26664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26663 == env26664) = true)

theorem identity26664 : scanCanonicalize (H12AffineFastState.compose env26664 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound26664 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26665 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5376,1,263,5393,2309,1024,0,4144,32,49,3,300,17,2049,5425,4097,2341,1316,32,256,33,5409,512]

theorem envBound26665 : H12AffineFastState.Bounded env26665 := by
  intro p hp
  have h : env26665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26664_26665 : H12AffineEnvironment.transform 12 301 env26664 = env26665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env26664 == env26665) = true)

theorem identity26665 : scanCanonicalize (H12AffineFastState.compose env26665 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26665 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env26666 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,9,5156,1,35,5173,2081,1024,0,4144,32,49,3,8,17,2049,5141,4097,2049,1024,32,36,33,5125,512]

theorem envBound26666 : H12AffineFastState.Bounded env26666 := by
  intro p hp
  have h : env26666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26665_26666 : H12AffineEnvironment.transform 7 36 env26665 = env26666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26665 == env26666) = true)

theorem identity26666 : scanCanonicalize (H12AffineFastState.compose env26666 (packedSelected [3,5,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26666 : packedSelected [3,5,16] rootPS < 2^1333 := by decide +kernel

def env26667 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5125,1,2,5140,2048,1024,0,4113,1,16,3,8,17,2049,5141,4097,2049,1024,1,5,0,5125,512]

theorem envBound26667 : H12AffineFastState.Bounded env26667 := by
  intro p hp
  have h : env26667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26666_26667 : H12AffineEnvironment.transform 4 1 env26666 = env26667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26666 == env26667) = true)

def env26668 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1045,1,2,1028,2048,1024,0,1,1,16,3,8,17,2049,1029,17,2049,1024,1,5,0,1045,512]

theorem envBound26668 : H12AffineFastState.Bounded env26668 := by
  intro p hp
  have h : env26668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26667_26668 : H12AffineEnvironment.transform 11 16 env26667 = env26668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env26667 == env26668) = true)

theorem identity26668 : scanCanonicalize (H12AffineFastState.compose env26668 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26668 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26669 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,16,9,1,1,2,16,2048,20,0,1,1,16,3,8,17,2049,17,17,2049,20,1,5,0,1,512]

theorem envBound26669 : H12AffineFastState.Bounded env26669 := by
  intro p hp
  have h : env26669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26668_26669 : H12AffineEnvironment.transform 9 20 env26668 = env26669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26668 == env26669) = true)

theorem identity26669 : scanCanonicalize (H12AffineFastState.compose env26669 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26670 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,5,9,1,1,2,5,2048,1,0,1,1,5,3,8,4,2049,4,4,2049,1,1,5,0,1,512]

theorem envBound26670 : H12AffineFastState.Bounded env26670 := by
  intro p hp
  have h : env26670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26669_26670 : H12AffineEnvironment.transform 3 5 env26669 = env26670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26669 == env26670) = true)

def leafEnv26670 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,5,9,1,1,2,5,2048,1,0,1,1,5,3,1,8,1,4,2049,4,4,2049,1,1,5,0,4,3,1,512,1,1,0]

def active26670 : List Nat := [0,1,2,8,10]

def tree26670 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26670 : H12WitnessSearch.Good tree26670 := H12GlobalWitnessIndex.good

theorem leafIdentity26670 : H12AffineFastState.composeSystem env26670 rootObs = leafEnv26670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26670 rootObs == leafEnv26670) = true)

theorem terminalChecked26670 : H12PackedTerminal.terminalCheckFast leafEnv26670 active26670 tree26670 = true := by decide +kernel

def env26671 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1044,1,2,1029,2048,1024,0,0,1,16,3,8,17,2049,1028,16,2049,1024,1,5,0,1044,512]

theorem envBound26671 : H12AffineFastState.Bounded env26671 := by
  intro p hp
  have h : env26671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26667_26671 : H12AffineEnvironment.transform 11 17 env26667 = env26671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26667 == env26671) = true)

def env26672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787197,79131,8466458,8820104,8389956,98815,256,8462515,8492191,8462994]

theorem envBound26672 : H12AffineFastState.Bounded env26672 := by
  intro p hp
  have h : env26672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26645_26672 : H12AffineEnvironment.transform 21 33 env26645 = env26672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26645 == env26672) = true)

theorem identity26672 : scanCanonicalize (H12AffineFastState.compose env26672 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26672 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8203,131072,262144,1024,32769,4297,33,8388608,41311,8328,64,8787197,5392,8392721,8820104,8389956,41460,256,8388792,8434836,8389273]

theorem envBound26673 : H12AffineFastState.Bounded env26673 := by
  intro p hp
  have h : env26673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26672_26673 : H12AffineEnvironment.transform 15 8203 env26672 = env26673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26672 == env26673) = true)

def env26674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,33,8388608,41311,8192,64,8787061,5392,8392721,8819968,8389956,41340,256,8388656,8434716,8389137]

theorem envBound26674 : H12AffineFastState.Bounded env26674 := by
  intro p hp
  have h : env26674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26673_26674 : H12AffineEnvironment.transform 6 8 env26673 = env26674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26673 == env26674) = true)

theorem identity26674 : scanCanonicalize (H12AffineFastState.compose env26674 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound26674 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35109,1024,32769,4161,33,8388608,41311,8192,64,8559952,5392,8392721,8526885,8389956,41340,256,8388656,8434716,8389137]

theorem envBound26675 : H12AffineFastState.Bounded env26675 := by
  intro p hp
  have h : env26675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26674_26675 : H12AffineEnvironment.transform 17 35109 env26674 = env26675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env26674 == env26675) = true)

theorem identity26675 : scanCanonicalize (H12AffineFastState.compose env26675 (packedSelected [4,7,9,14,16,20,21,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound26675 : packedSelected [4,7,9,14,16,20,21,27,35] rootPS < 2^1333 := by decide +kernel

def env26676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35109,1024,32769,4161,33,16,41311,8192,64,171328,5392,4097,138293,1364,41340,256,32,46092,513]

theorem envBound26676 : H12AffineFastState.Bounded env26676 := by
  intro p hp
  have h : env26676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26675_26676 : H12AffineEnvironment.transform 22 16 env26675 = env26676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env26675 == env26676) = true)

theorem identity26676 : scanCanonicalize (H12AffineFastState.compose env26676 (packedSelected [2,4,5,6,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound26676 : packedSelected [2,4,5,6,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env26677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,80,8203,131072,2421,1024,81,4161,33,16,8463,8192,64,138512,5392,4097,138293,1364,8492,256,32,13404,513]

theorem envBound26677 : H12AffineFastState.Bounded env26677 := by
  intro p hp
  have h : env26677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26676_26677 : H12AffineEnvironment.transform 14 80 env26676 = env26677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env26676 == env26677) = true)

theorem identity26677 : scanCanonicalize (H12AffineFastState.compose env26677 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26677 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env26678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,80,8203,13341,2421,1024,81,4161,33,16,8463,8192,64,10509,5392,4097,10280,1364,8492,256,32,13404,513]

theorem envBound26678 : H12AffineFastState.Bounded env26678 := by
  intro p hp
  have h : env26678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26677_26678 : H12AffineEnvironment.transform 16 13341 env26677 = env26678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env26677 == env26678) = true)

theorem identity26678 : scanCanonicalize (H12AffineFastState.compose env26678 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26678 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,80,262,5392,2421,1024,81,4161,33,16,2,269,64,2048,5392,4097,2341,1364,33,256,32,5457,513]

theorem envBound26679 : H12AffineFastState.Bounded env26679 := by
  intro p hp
  have h : env26679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26678_26679 : H12AffineEnvironment.transform 12 269 env26678 = env26679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26678 == env26679) = true)

theorem identity26679 : scanCanonicalize (H12AffineFastState.compose env26679 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26679 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1077,269,308,80,262,293,2421,1024,81,1140,33,16,2,269,64,2048,293,1076,2341,1364,33,256,32,356,513]

theorem envBound26680 : H12AffineFastState.Bounded env26680 := by
  intro p hp
  have h : env26680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26679_26680 : H12AffineEnvironment.transform 11 1077 env26679 = env26680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env26679 == env26680) = true)

theorem identity26680 : scanCanonicalize (H12AffineFastState.compose env26680 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound26680 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env26681 : List Nat := [2,4,8,16,32,64,8,14,512,1024,2048,1077,3,58,80,8,43,2171,1024,81,1140,33,16,2,3,64,2048,43,1076,2091,1114,33,14,32,106,513]

theorem envBound26681 : H12AffineFastState.Bounded env26681 := by
  intro p hp
  have h : env26681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26680_26681 : H12AffineEnvironment.transform 7 14 env26680 = env26681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env26680 == env26681) = true)

theorem identity26681 : scanCanonicalize (H12AffineFastState.compose env26681 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26681 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env26682 : List Nat := [2,4,8,16,32,17,8,14,512,1024,2048,1077,3,58,1,8,43,2090,1024,0,1061,33,16,2,3,17,2048,43,1076,2091,1035,33,14,32,59,513]

theorem envBound26682 : H12AffineFastState.Bounded env26682 := by
  intro p hp
  have h : env26682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26681_26682 : H12AffineEnvironment.transform 5 17 env26681 = env26682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26681 == env26682) = true)

theorem identity26682 : scanCanonicalize (H12AffineFastState.compose env26682 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound26682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26683 : List Nat := [2,4,8,16,32,17,8,14,512,21,2048,32,3,58,1,8,43,2090,21,0,48,33,16,2,3,17,2048,43,33,2091,30,33,14,32,59,513]

theorem envBound26683 : H12AffineFastState.Bounded env26683 := by
  intro p hp
  have h : env26683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26682_26683 : H12AffineEnvironment.transform 9 21 env26682 = env26683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env26682 == env26683) = true)

theorem identity26683 : scanCanonicalize (H12AffineFastState.compose env26683 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound26683 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26684 : List Nat := [2,4,8,16,32,17,8,14,512,21,26,32,3,58,1,8,43,48,21,0,48,33,16,2,3,17,26,43,33,49,30,33,14,32,59,513]

theorem envBound26684 : H12AffineFastState.Bounded env26684 := by
  intro p hp
  have h : env26684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26683_26684 : H12AffineEnvironment.transform 10 26 env26683 = env26684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env26683 == env26684) = true)

theorem identity26684 : scanCanonicalize (H12AffineFastState.compose env26684 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound26684 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26685 : List Nat := [2,4,8,16,32,17,8,14,48,21,26,32,3,58,1,8,43,48,21,0,48,33,16,2,3,17,26,43,33,49,30,33,14,32,59,49]

theorem envBound26685 : H12AffineFastState.Bounded env26685 := by
  intro p hp
  have h : env26685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26684_26685 : H12AffineEnvironment.transform 8 48 env26684 = env26685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env26684 == env26685) = true)

theorem identity26685 : scanCanonicalize (H12AffineFastState.compose env26685 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26685 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26686 : List Nat := [2,4,8,11,32,10,8,14,43,14,1,32,3,33,1,8,43,43,14,0,43,33,11,2,3,10,1,43,33,42,5,33,14,32,32,42]

theorem envBound26686 : H12AffineFastState.Bounded env26686 := by
  intro p hp
  have h : env26686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26685_26686 : H12AffineEnvironment.transform 3 11 env26685 = env26686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26685 == env26686) = true)

theorem identity26686 : scanCanonicalize (H12AffineFastState.compose env26686 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26686 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26687 : List Nat := [2,2,8,11,32,10,8,8,43,8,1,32,3,33,1,8,43,43,8,0,43,33,11,2,3,10,1,43,33,42,3,33,8,32,32,42]

theorem envBound26687 : H12AffineFastState.Bounded env26687 := by
  intro p hp
  have h : env26687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26686_26687 : H12AffineEnvironment.transform 1 2 env26686 = env26687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26686 == env26687) = true)

theorem identity26687 : scanCanonicalize (H12AffineFastState.compose env26687 (packedSelected [0,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound26687 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env26688 : List Nat := [2,2,2,1,32,0,2,2,33,2,1,32,3,33,1,2,33,33,2,0,33,33,1,2,3,0,1,33,33,32,3,33,2,32,32,32]

theorem envBound26688 : H12AffineFastState.Bounded env26688 := by
  intro p hp
  have h : env26688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26687_26688 : H12AffineEnvironment.transform 2 2 env26687 = env26688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env26687 == env26688) = true)

theorem identity26688 : scanCanonicalize (H12AffineFastState.compose env26688 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound26688 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26689 : List Nat := [2,2,2,1,2,0,2,2,3,2,1,2,3,3,1,2,3,3,2,0,3,3,1,2,3,0,1,3,3,2,3,3,2,2,2,2]

theorem envBound26689 : H12AffineFastState.Bounded env26689 := by
  intro p hp
  have h : env26689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26688_26689 : H12AffineEnvironment.transform 4 2 env26688 = env26689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env26688 == env26689) = true)

theorem identity26689 : scanCanonicalize (H12AffineFastState.compose env26689 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26689 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env26690 : List Nat := [1,1,1,1,1,0,1,1,0,1,1,1,0,0,1,1,0,0,1,0,0,0,1,1,0,0,1,0,0,1,0,0,1,1,1,1]

theorem envBound26690 : H12AffineFastState.Bounded env26690 := by
  intro p hp
  have h : env26690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26689_26690 : H12AffineEnvironment.transform 0 1 env26689 = env26690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26689 == env26690) = true)

def env26691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,8388608,41311,8193,64,8787060,5392,8392721,8819969,8389956,41341,256,8388657,8434717,8389136]

theorem envBound26691 : H12AffineFastState.Bounded env26691 := by
  intro p hp
  have h : env26691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26673_26691 : H12AffineEnvironment.transform 6 9 env26673 = env26691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26673 == env26691) = true)

theorem identity26691 : scanCanonicalize (H12AffineFastState.compose env26691 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 136529) := by decide +kernel

theorem selectedBound26691 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,136529,41311,8193,64,262437,5392,132416,294992,135189,41341,256,136544,172364,137025]

theorem envBound26692 : H12AffineFastState.Bounded env26692 := by
  intro p hp
  have h : env26692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26691_26692 : H12AffineEnvironment.transform 22 136529 env26691 = env26692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136529 env26691 == env26692) = true)

theorem identity26692 : scanCanonicalize (H12AffineFastState.compose env26692 (packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound26692 : packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env26693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,171108,1024,32769,4160,33,136529,41311,8193,64,171329,5392,132416,138292,135189,41341,256,136544,172364,137025]

theorem envBound26693 : H12AffineFastState.Bounded env26693 := by
  intro p hp
  have h : env26693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26692_26693 : H12AffineEnvironment.transform 17 171108 env26692 = env26693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env26692 == env26693) = true)

theorem identity26693 : scanCanonicalize (H12AffineFastState.compose env26693 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound26693 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env26694 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5440,35108,1024,32769,4160,33,17,41311,8193,64,34817,5392,4096,2420,1365,41341,256,32,46092,513]

theorem envBound26694 : H12AffineFastState.Bounded env26694 := by
  intro p hp
  have h : env26694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26693_26694 : H12AffineEnvironment.transform 16 5440 env26693 = env26694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env26693 == env26694) = true)

theorem identity26694 : scanCanonicalize (H12AffineFastState.compose env26694 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26694 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env26695 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4453,32768,8203,4389,35108,101,32769,4160,33,17,41311,8193,64,34817,4469,4096,2420,304,41341,256,32,45161,513]

theorem envBound26695 : H12AffineFastState.Bounded env26695 := by
  intro p hp
  have h : env26695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26694_26695 : H12AffineEnvironment.transform 9 101 env26694 = env26695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26694 == env26695) = true)

theorem identity26695 : scanCanonicalize (H12AffineFastState.compose env26695 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26695 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26696 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,4405,32768,8203,4389,35108,53,32769,4112,33,17,41231,8193,16,34817,4389,4096,2340,304,41261,256,32,45113,513]

theorem envBound26696 : H12AffineFastState.Bounded env26696 := by
  intro p hp
  have h : env26696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26695_26696 : H12AffineEnvironment.transform 5 16 env26695 = env26696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26695 == env26696) = true)

theorem identity26696 : scanCanonicalize (H12AffineFastState.compose env26696 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26696 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26697 : List Nat := [2,4,8,16,32,16,9,256,1,53,2048,4096,8192,4405,32768,8203,4389,35108,53,32769,4112,33,17,41231,8193,16,34817,4389,4096,2340,304,41261,256,32,45113,0]

theorem envBound26697 : H12AffineFastState.Bounded env26697 := by
  intro p hp
  have h : env26697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26696_26697 : H12AffineEnvironment.transform 8 1 env26696 = env26697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26696 == env26697) = true)

theorem identity26697 : scanCanonicalize (H12AffineFastState.compose env26697 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 12329) := by decide +kernel

theorem selectedBound26697 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26698 : List Nat := [2,4,8,16,32,16,9,256,1,53,2048,4096,8192,4405,12329,8203,4389,14605,53,12328,4112,33,17,4390,8193,16,14376,4389,4096,2340,304,4356,256,32,16,0]

theorem envBound26698 : H12AffineFastState.Bounded env26698 := by
  intro p hp
  have h : env26698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26697_26698 : H12AffineEnvironment.transform 14 12329 env26697 = env26698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12329 env26697 == env26698) = true)

theorem identity26698 : scanCanonicalize (H12AffineFastState.compose env26698 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound26698 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env26699 : List Nat := [2,4,8,16,32,16,9,256,1,53,2048,4096,6429,4405,2356,6422,4389,16,53,2357,4112,33,17,4390,6428,16,309,4389,4096,2340,304,4356,256,32,16,0]

theorem envBound26699 : H12AffineFastState.Bounded env26699 := by
  intro p hp
  have h : env26699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26698_26699 : H12AffineEnvironment.transform 12 6429 env26698 = env26699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env26698 == env26699) = true)

theorem identity26699 : scanCanonicalize (H12AffineFastState.compose env26699 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound26699 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env26700 : List Nat := [2,4,8,16,32,16,9,256,1,53,2048,2064,269,2341,2356,262,2357,16,53,2357,2048,33,17,2358,268,16,309,2357,2064,2340,304,2324,256,32,16,0]

theorem envBound26700 : H12AffineFastState.Bounded env26700 := by
  intro p hp
  have h : env26700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26699_26700 : H12AffineEnvironment.transform 11 2064 env26699 = env26700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env26699 == env26700) = true)

theorem identity26700 : scanCanonicalize (H12AffineFastState.compose env26700 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound26700 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26701 : List Nat := [2,4,8,16,32,16,9,256,1,53,17,1,269,308,293,262,292,16,53,292,17,33,17,295,268,16,309,292,1,309,304,261,256,32,16,0]

theorem envBound26701 : H12AffineFastState.Bounded env26701 := by
  intro p hp
  have h : env26701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26700_26701 : H12AffineEnvironment.transform 10 17 env26700 = env26701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env26700 == env26701) = true)

theorem identity26701 : scanCanonicalize (H12AffineFastState.compose env26701 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound26701 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env26702 : List Nat := [2,4,8,16,32,16,9,53,1,53,17,1,56,1,16,51,17,16,53,17,17,33,17,18,57,16,0,17,1,0,5,48,53,32,16,0]

theorem envBound26702 : H12AffineFastState.Bounded env26702 := by
  intro p hp
  have h : env26702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26701_26702 : H12AffineEnvironment.transform 7 53 env26701 = env26702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env26701 == env26702) = true)

theorem identity26702 : scanCanonicalize (H12AffineFastState.compose env26702 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26702 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26703 : List Nat := [2,4,8,0,32,0,9,37,1,37,1,1,40,1,0,35,1,0,37,1,1,33,1,2,41,0,0,1,1,0,5,32,37,32,0,0]

theorem envBound26703 : H12AffineFastState.Bounded env26703 := by
  intro p hp
  have h : env26703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26702_26703 : H12AffineEnvironment.transform 3 0 env26702 = env26703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26702 == env26703) = true)

theorem identity26703 : scanCanonicalize (H12AffineFastState.compose env26703 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26704 : List Nat := [2,4,3,0,32,0,2,37,1,37,1,1,35,1,0,35,1,0,37,1,1,33,1,2,34,0,0,1,1,0,5,32,37,32,0,0]

theorem envBound26704 : H12AffineFastState.Bounded env26704 := by
  intro p hp
  have h : env26704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26703_26704 : H12AffineEnvironment.transform 2 3 env26703 = env26704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26703 == env26704) = true)

def env26705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound26705 : H12AffineFastState.Bounded env26705 := by
  intro p hp
  have h : env26705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26494_26705 : H12AffineEnvironment.transform 18 1025 env26494 = env26705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26494 == env26705) = true)

theorem identity26705 : scanCanonicalize (H12AffineFastState.compose env26705 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10651083) := by decide +kernel

theorem selectedBound26705 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env26706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10651083,8328,64,6637003,8585543,10507601,8830976,2294235,12836874,257,213350,237762,2237964]

theorem envBound26706 : H12AffineFastState.Bounded env26706 := by
  intro p hp
  have h : env26706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26705_26706 : H12AffineEnvironment.transform 23 10651083 env26705 = env26706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10651083 env26705 == env26706) = true)

def env26707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180360,2114883,8328,64,6637003,115151,2266585,262280,2294235,4268162,257,213350,237762,2237964]

theorem envBound26707 : H12AffineFastState.Bounded env26707 := by
  intro p hp
  have h : env26707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26706_26707 : H12AffineEnvironment.transform 22 180360 env26706 = env26707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env26706 == env26707) = true)

def env26708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,169371,8328,64,4691219,115151,17665,262280,119043,4268162,257,213350,237762,63188]

theorem envBound26708 : H12AffineFastState.Bounded env26708 := by
  intro p hp
  have h : env26708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26707_26708 : H12AffineEnvironment.transform 20 184536 env26707 = env26708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env26707 == env26708) = true)

def env26709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,169371,8328,64,245139,115151,17665,262280,119043,329730,257,213350,237762,63188]

theorem envBound26709 : H12AffineFastState.Bounded env26709 := by
  intro p hp
  have h : env26709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26708_26709 : H12AffineEnvironment.transform 21 272512 env26708 = env26709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26708 == env26709) = true)

def env26710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272392,180224,169235,8192,64,245019,115015,17665,262144,119043,329730,257,213350,237642,63068]

theorem envBound26710 : H12AffineFastState.Bounded env26710 := by
  intro p hp
  have h : env26710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26709_26710 : H12AffineEnvironment.transform 6 8 env26709 = env26710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26709 == env26710) = true)

def env26711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272392,16,21763,8192,64,97547,115015,17665,262144,119043,329730,257,98678,90202,63068]

theorem envBound26711 : H12AffineFastState.Bounded env26711 := by
  intro p hp
  have h : env26711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26710_26711 : H12AffineEnvironment.transform 16 49168 env26710 = env26711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26710 == env26711) = true)

theorem identity26711 : scanCanonicalize (H12AffineFastState.compose env26711 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26711 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,262144,1025,32769,4160,272392,16,2,8192,64,75786,103494,4096,262144,99330,329730,257,98678,79195,41821]

theorem envBound26712 : H12AffineFastState.Bounded env26712 := by
  intro p hp
  have h : env26712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26711_26712 : H12AffineEnvironment.transform 13 5377 env26711 = env26712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26711 == env26712) = true)

theorem identity26712 : scanCanonicalize (H12AffineFastState.compose env26712 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound26712 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env26713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,10361,1025,32769,4160,113,16,2,8192,64,75786,103494,4096,10361,99330,73851,257,98678,79195,41821]

theorem envBound26713 : H12AffineFastState.Bounded env26713 := by
  intro p hp
  have h : env26713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26712_26713 : H12AffineEnvironment.transform 17 10361 env26712 = env26713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env26712 == env26713) = true)

theorem identity26713 : scanCanonicalize (H12AffineFastState.compose env26713 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound26713 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env26714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,32802,38161,10361,1025,32769,4160,113,16,2,8192,64,43048,5220,4096,10361,1056,41049,257,340,46457,41821]

theorem envBound26714 : H12AffineFastState.Bounded env26714 := by
  intro p hp
  have h : env26714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26713_26714 : H12AffineEnvironment.transform 15 32802 env26713 = env26714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env26713 == env26714) = true)

theorem identity26714 : scanCanonicalize (H12AffineFastState.compose env26714 (packedSelected [2,6,9,10,12,15,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26714 : packedSelected [2,6,9,10,12,15,16,19,22] rootPS < 2^1333 := by decide +kernel

def env26715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,35,5392,10361,1025,0,4160,113,16,2,8192,64,10281,5220,4096,10361,1056,8280,257,340,13688,9052]

theorem envBound26715 : H12AffineFastState.Bounded env26715 := by
  intro p hp
  have h : env26715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26714_26715 : H12AffineEnvironment.transform 14 1 env26714 = env26715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26714 == env26715) = true)

theorem identity26715 : scanCanonicalize (H12AffineFastState.compose env26715 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound26715 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,1,35,5392,2049,1025,0,4160,113,16,2,120,64,2129,5220,4096,2049,1056,32,257,340,5376,804]

theorem envBound26716 : H12AffineFastState.Bounded env26716 := by
  intro p hp
  have h : env26716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26715_26716 : H12AffineEnvironment.transform 12 120 env26715 = env26716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env26715 == env26716) = true)

theorem identity26716 : scanCanonicalize (H12AffineFastState.compose env26716 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26716 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env26717 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,1,35,5220,2049,1025,0,4160,113,16,2,120,64,2129,5220,4096,2049,1056,32,117,32,5236,592]

theorem envBound26717 : H12AffineFastState.Bounded env26717 := by
  intro p hp
  have h : env26717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26716_26717 : H12AffineEnvironment.transform 7 116 env26716 = env26717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26716 == env26717) = true)

theorem identity26717 : scanCanonicalize (H12AffineFastState.compose env26717 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound26717 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26718 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3108,120,2129,1,35,2112,2049,1025,0,3172,113,16,2,120,64,2129,2112,3108,2049,1056,32,117,32,2128,592]

theorem envBound26718 : H12AffineFastState.Bounded env26718 := by
  intro p hp
  have h : env26718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26717_26718 : H12AffineEnvironment.transform 11 3108 env26717 = env26718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env26717 == env26718) = true)

theorem identity26718 : scanCanonicalize (H12AffineFastState.compose env26718 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26718 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26719 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,2064,120,2129,1,35,2112,2049,53,0,2128,113,16,2,120,64,2129,2112,2064,2049,20,32,117,32,2128,592]

theorem envBound26719 : H12AffineFastState.Bounded env26719 := by
  intro p hp
  have h : env26719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26718_26719 : H12AffineEnvironment.transform 9 52 env26718 = env26719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26718 == env26719) = true)

theorem identity26719 : scanCanonicalize (H12AffineFastState.compose env26719 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26719 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26720 : List Nat := [2,4,8,16,32,64,8,116,512,52,0,16,120,81,1,35,64,1,53,0,80,113,16,2,120,64,81,64,16,1,20,32,117,32,80,592]

theorem envBound26720 : H12AffineFastState.Bounded env26720 := by
  intro p hp
  have h : env26720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26719_26720 : H12AffineEnvironment.transform 10 0 env26719 = env26720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26719 == env26720) = true)

theorem identity26720 : scanCanonicalize (H12AffineFastState.compose env26720 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound26720 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env26721 : List Nat := [2,4,8,16,32,64,8,116,49,52,0,16,120,81,1,35,64,1,53,0,80,113,16,2,120,64,81,64,16,1,20,32,117,32,80,97]

theorem envBound26721 : H12AffineFastState.Bounded env26721 := by
  intro p hp
  have h : env26721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26720_26721 : H12AffineEnvironment.transform 8 49 env26720 = env26721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env26720 == env26721) = true)

theorem identity26721 : scanCanonicalize (H12AffineFastState.compose env26721 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26721 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env26722 : List Nat := [2,4,8,16,32,16,8,36,49,52,0,16,40,1,1,35,16,1,53,0,0,33,16,2,40,16,1,16,16,1,20,32,37,32,0,49]

theorem envBound26722 : H12AffineFastState.Bounded env26722 := by
  intro p hp
  have h : env26722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26721_26722 : H12AffineEnvironment.transform 5 16 env26721 = env26722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26721 == env26722) = true)

theorem identity26722 : scanCanonicalize (H12AffineFastState.compose env26722 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26723 : List Nat := [2,4,8,1,32,1,8,36,32,37,0,1,40,1,1,35,1,1,36,0,0,33,1,2,40,1,1,1,1,1,5,32,37,32,0,32]

theorem envBound26723 : H12AffineFastState.Bounded env26723 := by
  intro p hp
  have h : env26723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26722_26723 : H12AffineEnvironment.transform 3 1 env26722 = env26723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26722 == env26723) = true)

theorem identity26723 : scanCanonicalize (H12AffineFastState.compose env26723 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound26723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26724 : List Nat := [2,4,8,1,14,1,8,10,14,11,0,1,6,1,1,13,1,1,10,0,0,15,1,2,6,1,1,1,1,1,5,14,11,14,0,14]

theorem envBound26724 : H12AffineFastState.Bounded env26724 := by
  intro p hp
  have h : env26724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26723_26724 : H12AffineEnvironment.transform 4 14 env26723 = env26724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env26723 == env26724) = true)

theorem identity26724 : scanCanonicalize (H12AffineFastState.compose env26724 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound26724 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26725 : List Nat := [2,4,7,1,1,1,7,5,1,4,0,1,6,1,1,2,1,1,5,0,0,0,1,2,6,1,1,1,1,1,5,1,4,1,0,1]

theorem envBound26725 : H12AffineFastState.Bounded env26725 := by
  intro p hp
  have h : env26725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26724_26725 : H12AffineEnvironment.transform 2 7 env26724 = env26725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env26724 == env26725) = true)

def env26726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,17,21762,8192,64,97546,115015,17665,262144,119043,329730,257,98679,90203,63068]

theorem envBound26726 : H12AffineFastState.Bounded env26726 := by
  intro p hp
  have h : env26726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26710_26726 : H12AffineEnvironment.transform 16 49169 env26710 = env26726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26710 == env26726) = true)

theorem identity26726 : scanCanonicalize (H12AffineFastState.compose env26726 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound26726 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,4161,21792,17,21762,8192,64,97546,115015,17665,32040,119043,95530,257,98679,90203,63068]

theorem envBound26727 : H12AffineFastState.Bounded env26727 := by
  intro p hp
  have h : env26727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26726_26727 : H12AffineEnvironment.transform 17 32040 env26726 = env26727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env26726 == env26727) = true)

theorem identity26727 : scanCanonicalize (H12AffineFastState.compose env26727 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound26727 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21874,49169,32040,1025,32769,4161,21792,17,21762,8192,64,10360,37941,17665,32040,33905,8280,257,54277,13609,63068]

theorem envBound26728 : H12AffineFastState.Bounded env26728 := by
  intro p hp
  have h : env26728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26727_26728 : H12AffineEnvironment.transform 15 21874 env26727 = env26728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env26727 == env26728) = true)

theorem identity26728 : scanCanonicalize (H12AffineFastState.compose env26728 (packedSelected [7,14,16,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound26728 : packedSelected [7,14,16,18,23,27] rootPS < 2^1333 := by decide +kernel

def env26729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,21874,24860,32040,1025,8460,4161,21792,17,21762,8192,64,10360,13624,17665,32040,9596,8280,257,29960,13609,22353]

theorem envBound26729 : H12AffineFastState.Bounded env26729 := by
  intro p hp
  have h : env26729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26728_26729 : H12AffineEnvironment.transform 14 8461 env26728 = env26729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env26728 == env26729) = true)

theorem identity26729 : scanCanonicalize (H12AffineFastState.compose env26729 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26729 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env26730 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,21795,24860,32040,1025,8460,4112,21792,17,21762,8192,17,10281,13624,17665,32040,9517,8201,257,29960,13609,22272]

theorem envBound26730 : H12AffineFastState.Bounded env26730 := by
  intro p hp
  have h : env26730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26729_26730 : H12AffineEnvironment.transform 5 17 env26729 = env26730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26729 == env26730) = true)

theorem identity26730 : scanCanonicalize (H12AffineFastState.compose env26730 (packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26730 : packedSelected [0,1,3,4,5,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env26731 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,34,13341,10281,1025,8460,4112,33,17,3,8192,17,10281,13624,4096,10281,9517,8201,257,8201,13609,513]

theorem envBound26731 : H12AffineFastState.Bounded env26731 := by
  intro p hp
  have h : env26731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26730_26731 : H12AffineEnvironment.transform 13 5377 env26730 = env26731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26730 == env26731) = true)

theorem identity26731 : scanCanonicalize (H12AffineFastState.compose env26731 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound26731 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26732 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,292,34,5172,2048,1025,293,4112,33,17,3,41,17,2048,5393,4096,2048,1284,32,257,32,5376,513]

theorem envBound26732 : H12AffineFastState.Bounded env26732 := by
  intro p hp
  have h : env26732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26731_26732 : H12AffineEnvironment.transform 12 41 env26731 = env26732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env26731 == env26732) = true)

theorem identity26732 : scanCanonicalize (H12AffineFastState.compose env26732 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound26732 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26733 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1028,41,261,292,34,48,2048,1025,293,1044,33,17,3,41,17,2048,277,1028,2048,1284,32,257,32,260,513]

theorem envBound26733 : H12AffineFastState.Bounded env26733 := by
  intro p hp
  have h : env26733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26732_26733 : H12AffineEnvironment.transform 11 1028 env26732 = env26733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env26732 == env26733) = true)

theorem identity26733 : scanCanonicalize (H12AffineFastState.compose env26733 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound26733 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26734 : List Nat := [2,4,8,16,32,17,8,256,260,1024,2048,1028,41,261,292,34,48,2048,1025,293,1044,33,17,3,41,17,2048,277,1028,2048,1284,32,257,32,260,261]

theorem envBound26734 : H12AffineFastState.Bounded env26734 := by
  intro p hp
  have h : env26734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26733_26734 : H12AffineEnvironment.transform 8 260 env26733 = env26734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env26733 == env26734) = true)

theorem identity26734 : scanCanonicalize (H12AffineFastState.compose env26734 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound26734 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26735 : List Nat := [2,4,8,16,32,17,8,256,260,1024,1076,1028,41,261,292,34,48,1076,1025,293,1044,33,17,3,41,17,1076,277,1028,1076,1284,32,257,32,260,261]

theorem envBound26735 : H12AffineFastState.Bounded env26735 := by
  intro p hp
  have h : env26735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26734_26735 : H12AffineEnvironment.transform 10 1076 env26734 = env26735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env26734 == env26735) = true)

theorem identity26735 : scanCanonicalize (H12AffineFastState.compose env26735 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound26735 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env26736 : List Nat := [2,4,8,16,32,17,8,5,1,1024,1076,1028,41,0,33,34,48,1076,1025,32,1044,33,17,3,41,17,1076,16,1028,1076,1025,32,4,32,1,0]

theorem envBound26736 : H12AffineFastState.Bounded env26736 := by
  intro p hp
  have h : env26736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26735_26736 : H12AffineEnvironment.transform 7 5 env26735 = env26736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env26735 == env26736) = true)

theorem identity26736 : scanCanonicalize (H12AffineFastState.compose env26736 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound26736 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26737 : List Nat := [2,4,8,16,32,17,8,5,1,20,32,16,41,0,33,34,48,32,21,32,0,33,17,3,41,17,32,16,16,32,21,32,4,32,1,0]

theorem envBound26737 : H12AffineFastState.Bounded env26737 := by
  intro p hp
  have h : env26737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26736_26737 : H12AffineEnvironment.transform 9 20 env26736 = env26737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env26736 == env26737) = true)

theorem identity26737 : scanCanonicalize (H12AffineFastState.compose env26737 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound26737 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26738 : List Nat := [2,4,8,16,16,17,8,5,1,20,16,16,25,0,17,18,0,16,21,16,0,17,17,3,25,17,16,16,16,16,21,16,4,16,1,0]

theorem envBound26738 : H12AffineFastState.Bounded env26738 := by
  intro p hp
  have h : env26738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26737_26738 : H12AffineEnvironment.transform 4 16 env26737 = env26738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env26737 == env26738) = true)

def env26739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180225,169234,8193,64,245018,115014,17665,262145,119043,329730,257,213350,237643,63069]

theorem envBound26739 : H12AffineFastState.Bounded env26739 := by
  intro p hp
  have h : env26739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26709_26739 : H12AffineEnvironment.transform 6 9 env26709 = env26739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26709 == env26739) = true)

def env26740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,17,21762,8193,64,97546,115014,17665,262145,119043,329730,257,98678,90203,63069]

theorem envBound26740 : H12AffineFastState.Bounded env26740 := by
  intro p hp
  have h : env26740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26739_26740 : H12AffineEnvironment.transform 16 49168 env26739 = env26740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env26739 == env26740) = true)

theorem identity26740 : scanCanonicalize (H12AffineFastState.compose env26740 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound26740 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56436,1025,32769,4161,62589,17,21762,8193,64,97546,115014,17665,56437,119043,119926,257,98678,90203,63069]

theorem envBound26741 : H12AffineFastState.Bounded env26741 := by
  intro p hp
  have h : env26741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26740_26741 : H12AffineEnvironment.transform 17 56436 env26740 = env26741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env26740 == env26741) = true)

theorem identity26741 : scanCanonicalize (H12AffineFastState.compose env26741 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound26741 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,65536,49168,56436,1025,32769,4161,54641,17,21762,269,64,89094,115014,17665,56437,119043,119926,257,98678,82263,55121]

theorem envBound26742 : H12AffineFastState.Bounded env26742 := by
  intro p hp
  have h : env26742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26741_26742 : H12AffineEnvironment.transform 12 268 env26741 = env26742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env26741 == env26742) = true)

theorem identity26742 : scanCanonicalize (H12AffineFastState.compose env26742 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26742 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env26743 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,65536,49168,56356,1025,32769,4113,54561,17,21762,269,16,89094,114966,17665,56357,119043,119846,257,98598,82183,55041]

theorem envBound26743 : H12AffineFastState.Bounded env26743 := by
  intro p hp
  have h : env26743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26742_26743 : H12AffineEnvironment.transform 5 16 env26742 = env26743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26742 == env26743) = true)

theorem identity26743 : scanCanonicalize (H12AffineFastState.compose env26743 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound26743 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env26744 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,33031,49168,56356,1025,32769,4113,54561,17,21762,269,16,56577,16401,17665,56357,20484,21793,257,33,49152,55041]

theorem envBound26744 : H12AffineFastState.Bounded env26744 := by
  intro p hp
  have h : env26744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26743_26744 : H12AffineEnvironment.transform 15 33031 env26743 = env26744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env26743 == env26744) = true)

theorem identity26744 : scanCanonicalize (H12AffineFastState.compose env26744 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound26744 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26745 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,262,16401,23589,1025,0,4113,21792,17,21762,269,16,23808,16401,17665,23588,20484,21793,257,33,16385,22272]

theorem envBound26745 : H12AffineFastState.Bounded env26745 := by
  intro p hp
  have h : env26745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26744_26745 : H12AffineEnvironment.transform 14 1 env26744 = env26745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env26744 == env26745) = true)

theorem identity26745 : scanCanonicalize (H12AffineFastState.compose env26745 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound26745 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env26746 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5157,1,262,5172,2048,1025,0,4113,261,17,295,269,16,2341,5172,4388,2049,1057,260,257,33,5156,805]

theorem envBound26746 : H12AffineFastState.Bounded env26746 := by
  intro p hp
  have h : env26746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26745_26746 : H12AffineEnvironment.transform 13 5157 env26745 = env26746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env26745 == env26746) = true)

theorem identity26746 : scanCanonicalize (H12AffineFastState.compose env26746 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound26746 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26747 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,268,2048,1,262,2065,2048,1025,0,3124,261,17,295,269,16,2341,2065,3329,2049,1057,260,257,33,2049,805]

theorem envBound26747 : H12AffineFastState.Bounded env26747 := by
  intro p hp
  have h : env26747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26746_26747 : H12AffineEnvironment.transform 11 3109 env26746 = env26747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env26746 == env26747) = true)

theorem identity26747 : scanCanonicalize (H12AffineFastState.compose env26747 (packedSelected [0,3,4,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26747 : packedSelected [0,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env26748 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,2356,268,2048,1,262,2065,2048,272,0,2341,261,17,295,269,16,2341,2065,2064,2049,304,260,257,33,2049,805]

theorem envBound26748 : H12AffineFastState.Bounded env26748 := by
  intro p hp
  have h : env26748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26747_26748 : H12AffineEnvironment.transform 9 273 env26747 = env26748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26747 == env26748) = true)

theorem identity26748 : scanCanonicalize (H12AffineFastState.compose env26748 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26748 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26749 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,2064,40,2048,1,34,2065,2048,52,0,2049,33,17,3,41,16,2049,2065,2064,2049,20,32,37,33,2049,513]

theorem envBound26749 : H12AffineFastState.Bounded env26749 := by
  intro p hp
  have h : env26749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26748_26749 : H12AffineEnvironment.transform 7 36 env26748 = env26749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26748 == env26749) = true)

theorem identity26749 : scanCanonicalize (H12AffineFastState.compose env26749 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound26749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26750 : List Nat := [2,4,8,16,32,16,9,36,512,53,17,1,40,17,1,34,0,17,52,0,16,33,17,3,41,16,16,0,1,16,20,32,37,33,16,513]

theorem envBound26750 : H12AffineFastState.Bounded env26750 := by
  intro p hp
  have h : env26750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26749_26750 : H12AffineEnvironment.transform 10 17 env26749 = env26750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env26749 == env26750) = true)

theorem identity26750 : scanCanonicalize (H12AffineFastState.compose env26750 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound26750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26751 : List Nat := [2,4,8,16,32,16,9,36,42,53,17,1,40,17,1,34,0,17,52,0,16,33,17,3,41,16,16,0,1,16,20,32,37,33,16,43]

theorem envBound26751 : H12AffineFastState.Bounded env26751 := by
  intro p hp
  have h : env26751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26750_26751 : H12AffineEnvironment.transform 8 42 env26750 = env26751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env26750 == env26751) = true)

theorem identity26751 : scanCanonicalize (H12AffineFastState.compose env26751 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26751 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26752 : List Nat := [2,4,8,16,10,16,9,14,0,31,17,1,2,17,1,8,0,17,30,0,16,11,17,3,3,16,16,0,1,16,20,10,15,11,16,1]

theorem envBound26752 : H12AffineFastState.Bounded env26752 := by
  intro p hp
  have h : env26752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26751_26752 : H12AffineEnvironment.transform 4 10 env26751 = env26752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26751 == env26752) = true)

def env26753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,16,21763,8193,64,97547,115014,17665,262145,119043,329730,257,98679,90202,63069]

theorem envBound26753 : H12AffineFastState.Bounded env26753 := by
  intro p hp
  have h : env26753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26739_26753 : H12AffineEnvironment.transform 16 49169 env26739 = env26753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env26739 == env26753) = true)

theorem identity26753 : scanCanonicalize (H12AffineFastState.compose env26753 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound26753 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13389,262144,1025,29789,4160,272393,16,21763,8193,64,97547,79130,17665,262145,75103,329730,257,95531,90202,513]

theorem envBound26754 : H12AffineFastState.Bounded env26754 := by
  intro p hp
  have h : env26754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26753_26754 : H12AffineEnvironment.transform 14 29788 env26753 = env26754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env26753 == env26754) = true)

theorem identity26754 : scanCanonicalize (H12AffineFastState.compose env26754 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound26754 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,13389,262144,1025,29789,4160,272393,16,21763,8193,64,10589,24908,17665,262145,28937,285780,257,8573,13324,513]

theorem envBound26755 : H12AffineFastState.Bounded env26755 := by
  intro p hp
  have h : env26755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26754_26755 : H12AffineEnvironment.transform 15 21590 env26754 = env26755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env26754 == env26755) = true)

theorem identity26755 : scanCanonicalize (H12AffineFastState.compose env26755 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound26755 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,5392,262144,1025,21760,4160,264532,16,21763,348,64,2048,16401,17665,262145,20564,285780,257,32,5457,513]

theorem envBound26756 : H12AffineFastState.Bounded env26756 := by
  intro p hp
  have h : env26756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26755_26756 : H12AffineEnvironment.transform 12 349 env26755 = env26756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env26755 == env26756) = true)

theorem identity26756 : scanCanonicalize (H12AffineFastState.compose env26756 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound26756 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,5392,2420,1025,21760,4160,32,16,21763,348,64,2048,16401,17665,2421,20564,21792,257,32,5457,513]

theorem envBound26757 : H12AffineFastState.Bounded env26757 := by
  intro p hp
  have h : env26757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26756_26757 : H12AffineEnvironment.transform 17 2420 env26756 = env26757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env26756 == env26757) = true)

theorem identity26757 : scanCanonicalize (H12AffineFastState.compose env26757 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound26757 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4113,1296,1095,5392,2420,1025,1297,4160,32,16,1298,348,64,2048,4096,5392,2421,69,1329,257,32,5457,513]

theorem envBound26758 : H12AffineFastState.Bounded env26758 := by
  intro p hp
  have h : env26758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26757_26758 : H12AffineEnvironment.transform 13 4113 env26757 = env26758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env26757 == env26758) = true)

theorem identity26758 : scanCanonicalize (H12AffineFastState.compose env26758 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound26758 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26759 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,349,4113,1296,1095,5392,1076,1025,1297,4160,32,16,1298,348,64,1344,4096,5392,1077,69,1329,257,32,5457,513]

theorem envBound26759 : H12AffineFastState.Bounded env26759 := by
  intro p hp
  have h : env26759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26758_26759 : H12AffineEnvironment.transform 10 1344 env26758 = env26759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env26758 == env26759) = true)

theorem identity26759 : scanCanonicalize (H12AffineFastState.compose env26759 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound26759 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26760 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,4096,41,4113,1124,1095,5220,1076,1025,1125,4160,32,16,1126,40,64,1076,4096,5220,1077,69,1093,117,32,5157,513]

theorem envBound26760 : H12AffineFastState.Bounded env26760 := by
  intro p hp
  have h : env26760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26759_26760 : H12AffineEnvironment.transform 7 116 env26759 = env26760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env26759 == env26760) = true)

theorem identity26760 : scanCanonicalize (H12AffineFastState.compose env26760 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound26760 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env26761 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1076,1061,41,1076,1124,1095,65,1076,1025,1125,1125,32,16,1126,40,64,1076,1061,65,1077,69,1093,117,32,0,513]

theorem envBound26761 : H12AffineFastState.Bounded env26761 := by
  intro p hp
  have h : env26761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26760_26761 : H12AffineEnvironment.transform 11 1061 env26760 = env26761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env26760 == env26761) = true)

theorem identity26761 : scanCanonicalize (H12AffineFastState.compose env26761 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound26761 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env26762 : List Nat := [2,4,8,16,32,64,9,116,65,1024,1076,1061,41,1076,1124,1095,65,1076,1025,1125,1125,32,16,1126,40,64,1076,1061,65,1077,69,1093,117,32,0,64]

theorem envBound26762 : H12AffineFastState.Bounded env26762 := by
  intro p hp
  have h : env26762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26761_26762 : H12AffineEnvironment.transform 8 65 env26761 = env26762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env26761 == env26762) = true)

theorem identity26762 : scanCanonicalize (H12AffineFastState.compose env26762 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26762 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env26763 : List Nat := [2,4,8,16,32,64,9,116,65,52,0,17,41,0,80,115,65,0,53,81,81,32,16,82,40,64,0,17,65,1,69,113,117,32,0,64]

theorem envBound26763 : H12AffineFastState.Bounded env26763 := by
  intro p hp
  have h : env26763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26762_26763 : H12AffineEnvironment.transform 9 52 env26762 = env26763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26762 == env26763) = true)

theorem identity26763 : scanCanonicalize (H12AffineFastState.compose env26763 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26763 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26764 : List Nat := [2,4,8,16,32,16,9,36,17,52,0,17,41,0,0,35,17,0,53,1,1,32,16,2,40,16,0,17,17,1,21,33,37,32,0,16]

theorem envBound26764 : H12AffineFastState.Bounded env26764 := by
  intro p hp
  have h : env26764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26763_26764 : H12AffineEnvironment.transform 5 16 env26763 = env26764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26763 == env26764) = true)

def env26765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,169371,8328,64,245138,115151,17665,262280,119043,329731,257,213350,237762,63188]

theorem envBound26765 : H12AffineFastState.Bounded env26765 := by
  intro p hp
  have h : env26765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26708_26765 : H12AffineEnvironment.transform 21 272513 env26708 = env26765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26708 == env26765) = true)

theorem identity26765 : scanCanonicalize (H12AffineFastState.compose env26765 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49305) := by decide +kernel

theorem selectedBound26765 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272513,17,21762,8328,64,97547,115151,17665,262280,119043,329731,257,98815,90203,63188]

theorem envBound26766 : H12AffineFastState.Bounded env26766 := by
  intro p hp
  have h : env26766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26765_26766 : H12AffineEnvironment.transform 16 49305 env26765 = env26766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env26765 == env26766) = true)

def env26767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,17,21762,8192,64,97547,115015,17665,262144,119043,329731,257,98679,90203,63068]

theorem envBound26767 : H12AffineFastState.Bounded env26767 := by
  intro p hp
  have h : env26767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26766_26767 : H12AffineEnvironment.transform 6 8 env26766 = env26767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26766 == env26767) = true)

theorem identity26767 : scanCanonicalize (H12AffineFastState.compose env26767 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound26767 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,4161,21793,17,21762,8192,64,97547,115015,17665,32040,119043,95531,257,98679,90203,63068]

theorem envBound26768 : H12AffineFastState.Bounded env26768 := by
  intro p hp
  have h : env26768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26767_26768 : H12AffineEnvironment.transform 17 32040 env26767 = env26768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env26767 == env26768) = true)

theorem identity26768 : scanCanonicalize (H12AffineFastState.compose env26768 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 62591) := by decide +kernel

theorem selectedBound26768 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62591,49169,32040,1025,32769,4161,21793,17,21762,8192,64,35188,13624,17665,32040,9596,33108,257,29960,37924,63068]

theorem envBound26769 : H12AffineFastState.Bounded env26769 := by
  intro p hp
  have h : env26769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26768_26769 : H12AffineEnvironment.transform 15 62591 env26768 = env26769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62591 env26768 == env26769) = true)

theorem identity26769 : scanCanonicalize (H12AffineFastState.compose env26769 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26769 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env26770 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62591,49169,31837,1025,32769,4161,21588,17,21623,8192,64,34817,13389,17524,31837,9225,32801,116,29821,37924,63068]

theorem envBound26770 : H12AffineFastState.Bounded env26770 := by
  intro p hp
  have h : env26770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26769_26770 : H12AffineEnvironment.transform 7 117 env26769 = env26770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26769 == env26770) = true)

theorem identity26770 : scanCanonicalize (H12AffineFastState.compose env26770 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound26770 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env26771 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29788,35,13389,31837,1025,29789,4161,21588,17,21623,8192,64,31837,13389,17524,31837,9225,29821,116,29821,24696,512]

theorem envBound26771 : H12AffineFastState.Bounded env26771 := by
  intro p hp
  have h : env26771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26770_26771 : H12AffineEnvironment.transform 14 29788 env26770 = env26771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env26770 == env26771) = true)

theorem identity26771 : scanCanonicalize (H12AffineFastState.compose env26771 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13436) := by decide +kernel

theorem selectedBound26771 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26772 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13436,32,35,13389,2081,1025,33,4161,8232,17,8203,8192,64,2081,13389,12296,2081,9225,1,116,1,5124,512]

theorem envBound26772 : H12AffineFastState.Bounded env26772 := by
  intro p hp
  have h : env26772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26771_26772 : H12AffineEnvironment.transform 13 13436 env26771 = env26772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13436 env26771 == env26772) = true)

theorem identity26772 : scanCanonicalize (H12AffineFastState.compose env26772 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26772 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env26773 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,8192,13405,1,2,13389,2048,1025,0,4161,8201,17,8203,8192,64,2048,13389,12296,2048,9225,1,85,1,5124,512]

theorem envBound26773 : H12AffineFastState.Bounded env26773 := by
  intro p hp
  have h : env26773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26772_26773 : H12AffineEnvironment.transform 4 1 env26772 = env26773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26772 == env26773) = true)

theorem identity26773 : scanCanonicalize (H12AffineFastState.compose env26773 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound26773 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26774 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,8,5205,1,2,5189,2048,1025,0,4161,1,17,3,8,64,2048,5189,4096,2048,1025,1,85,1,5124,512]

theorem envBound26774 : H12AffineFastState.Bounded env26774 := by
  intro p hp
  have h : env26774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26773_26774 : H12AffineEnvironment.transform 12 8 env26773 = env26774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env26773 == env26774) = true)

theorem identity26774 : scanCanonicalize (H12AffineFastState.compose env26774 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound26774 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26775 : List Nat := [2,4,8,16,1,64,8,84,512,533,2048,4096,8,4672,1,2,4688,2048,532,0,4161,1,17,3,8,64,2048,4688,4096,2048,532,1,85,1,4625,512]

theorem envBound26775 : H12AffineFastState.Bounded env26775 := by
  intro p hp
  have h : env26775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26774_26775 : H12AffineEnvironment.transform 9 533 env26774 = env26775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env26774 == env26775) = true)

theorem identity26775 : scanCanonicalize (H12AffineFastState.compose env26775 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26775 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26776 : List Nat := [2,4,8,16,1,17,8,5,512,533,2048,4096,8,4625,1,2,4609,2048,532,0,4112,1,17,3,8,17,2048,4609,4096,2048,532,1,4,1,4625,512]

theorem envBound26776 : H12AffineFastState.Bounded env26776 := by
  intro p hp
  have h : env26776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26775_26776 : H12AffineEnvironment.transform 5 17 env26775 = env26776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26775 == env26776) = true)

theorem identity26776 : scanCanonicalize (H12AffineFastState.compose env26776 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound26776 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26777 : List Nat := [2,4,8,16,1,17,8,5,512,533,2048,0,8,529,1,2,513,2048,532,0,16,1,17,3,8,17,2048,513,0,2048,532,1,4,1,529,512]

theorem envBound26777 : H12AffineFastState.Bounded env26777 := by
  intro p hp
  have h : env26777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26776_26777 : H12AffineEnvironment.transform 11 0 env26776 = env26777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26776 == env26777) = true)

theorem identity26777 : scanCanonicalize (H12AffineFastState.compose env26777 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26777 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26778 : List Nat := [2,4,8,16,1,17,8,5,512,533,0,0,8,529,1,2,513,0,532,0,16,1,17,3,8,17,0,513,0,0,532,1,4,1,529,512]

theorem envBound26778 : H12AffineFastState.Bounded env26778 := by
  intro p hp
  have h : env26778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26777_26778 : H12AffineEnvironment.transform 10 0 env26777 = env26778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26777 == env26778) = true)

theorem identity26778 : scanCanonicalize (H12AffineFastState.compose env26778 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound26778 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26779 : List Nat := [2,4,8,16,1,17,8,5,16,5,0,0,8,1,1,2,17,0,4,0,16,1,17,3,8,17,0,17,0,0,4,1,4,1,1,16]

theorem envBound26779 : H12AffineFastState.Bounded env26779 := by
  intro p hp
  have h : env26779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26778_26779 : H12AffineEnvironment.transform 8 16 env26778 = env26779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env26778 == env26779) = true)

theorem identity26779 : scanCanonicalize (H12AffineFastState.compose env26779 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26779 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26780 : List Nat := [2,4,8,0,1,1,8,5,0,5,0,0,8,1,1,2,1,0,4,0,0,1,1,3,8,1,0,1,0,0,4,1,4,1,1,0]

theorem envBound26780 : H12AffineFastState.Bounded env26780 := by
  intro p hp
  have h : env26780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26779_26780 : H12AffineEnvironment.transform 3 0 env26779 = env26780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26779 == env26780) = true)

theorem identity26780 : scanCanonicalize (H12AffineFastState.compose env26780 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound26780 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26781 : List Nat := [2,4,6,0,1,1,6,5,0,5,0,0,6,1,1,2,1,0,4,0,0,1,1,3,6,1,0,1,0,0,4,1,4,1,1,0]

theorem envBound26781 : H12AffineFastState.Bounded env26781 := by
  intro p hp
  have h : env26781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26780_26781 : H12AffineEnvironment.transform 2 6 env26780 = env26781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env26780 == env26781) = true)

def env26782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,17,21762,8193,64,97547,115014,17665,262145,119043,329731,257,98678,90203,63069]

theorem envBound26782 : H12AffineFastState.Bounded env26782 := by
  intro p hp
  have h : env26782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26766_26782 : H12AffineEnvironment.transform 6 9 env26766 = env26782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26766 == env26782) = true)

theorem identity26782 : scanCanonicalize (H12AffineFastState.compose env26782 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound26782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,56436,1025,32769,4161,62588,17,21762,8193,64,97547,115014,17665,56437,119043,119927,257,98678,90203,63069]

theorem envBound26783 : H12AffineFastState.Bounded env26783 := by
  intro p hp
  have h : env26783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26782_26783 : H12AffineEnvironment.transform 17 56436 env26782 = env26783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env26782 == env26783) = true)

theorem identity26783 : scanCanonicalize (H12AffineFastState.compose env26783 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound26783 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env26784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49168,56436,1025,32769,4161,62588,17,21762,8193,64,2128,46109,17665,56437,42072,41260,257,62509,5376,63069]

theorem envBound26784 : H12AffineFastState.Bounded env26784 := by
  intro p hp
  have h : env26784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26783_26784 : H12AffineEnvironment.transform 15 30043 env26783 = env26784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env26783 == env26784) = true)

theorem identity26784 : scanCanonicalize (H12AffineFastState.compose env26784 (packedSelected [0,7,10,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26784 : packedSelected [0,7,10,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env26785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,30043,24908,32040,1025,8541,4161,21792,17,21762,8193,64,2128,5441,17665,32041,1284,112,257,21873,5376,22273]

theorem envBound26785 : H12AffineFastState.Bounded env26785 := by
  intro p hp
  have h : env26785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26784_26785 : H12AffineEnvironment.transform 14 8540 env26784 = env26785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26784 == env26785) = true)

theorem identity26785 : scanCanonicalize (H12AffineFastState.compose env26785 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26785 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env26786 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29962,24861,32040,1025,8460,4112,21792,17,21762,8193,17,2049,5392,17665,32041,1284,33,257,21792,5376,22273]

theorem envBound26786 : H12AffineFastState.Bounded env26786 := by
  intro p hp
  have h : env26786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26785_26786 : H12AffineEnvironment.transform 5 17 env26785 = env26786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26785 == env26786) = true)

theorem identity26786 : scanCanonicalize (H12AffineFastState.compose env26786 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 12344) := by decide +kernel

theorem selectedBound26786 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env26787 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,12344,8461,1330,4389,3344,1025,8460,4112,9496,17,9530,8193,17,2049,5392,13625,3345,1284,33,257,9496,5376,10041]

theorem envBound26787 : H12AffineFastState.Bounded env26787 := by
  intro p hp
  have h : env26787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26786_26787 : H12AffineEnvironment.transform 13 12344 env26786 = env26787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12344 env26786 == env26787) = true)

theorem identity26787 : scanCanonicalize (H12AffineFastState.compose env26787 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound26787 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env26788 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,4373,32,1330,4389,3344,1025,33,4112,1077,17,1047,300,17,2049,5392,5140,3345,1284,33,257,1077,5376,1556]

theorem envBound26788 : H12AffineFastState.Bounded env26788 := by
  intro p hp
  have h : env26788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26787_26788 : H12AffineEnvironment.transform 12 301 env26787 = env26788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env26787 == env26788) = true)

theorem identity26788 : scanCanonicalize (H12AffineFastState.compose env26788 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound26788 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26789 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4373,32,262,4389,2340,53,33,4112,1,17,35,300,17,2049,4388,4128,2341,304,33,257,1,4404,544]

theorem envBound26789 : H12AffineFastState.Bounded env26789 := by
  intro p hp
  have h : env26789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26788_26789 : H12AffineEnvironment.transform 9 52 env26788 = env26789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env26788 == env26789) = true)

theorem identity26789 : scanCanonicalize (H12AffineFastState.compose env26789 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound26789 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26790 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,1,301,276,32,262,292,2340,53,33,17,1,17,35,300,17,2049,293,33,2341,304,33,257,1,309,544]

theorem envBound26790 : H12AffineFastState.Bounded env26790 := by
  intro p hp
  have h : env26790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26789_26790 : H12AffineEnvironment.transform 11 1 env26789 = env26790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env26789 == env26790) = true)

theorem identity26790 : scanCanonicalize (H12AffineFastState.compose env26790 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound26790 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env26791 : List Nat := [2,4,8,16,1,17,9,256,512,21,2048,1,268,276,1,262,261,2309,20,0,17,1,17,2,269,17,2049,260,0,2308,273,0,257,1,276,513]

theorem envBound26791 : H12AffineFastState.Bounded env26791 := by
  intro p hp
  have h : env26791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26790_26791 : H12AffineEnvironment.transform 4 1 env26790 = env26791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env26790 == env26791) = true)

theorem identity26791 : scanCanonicalize (H12AffineFastState.compose env26791 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound26791 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26792 : List Nat := [2,4,8,16,1,17,9,256,261,21,2048,1,268,276,1,262,261,2309,20,0,17,1,17,2,269,17,2049,260,0,2308,273,0,257,1,276,260]

theorem envBound26792 : H12AffineFastState.Bounded env26792 := by
  intro p hp
  have h : env26792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26791_26792 : H12AffineEnvironment.transform 8 261 env26791 = env26792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env26791 == env26792) = true)

theorem identity26792 : scanCanonicalize (H12AffineFastState.compose env26792 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26792 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26793 : List Nat := [2,4,8,16,1,17,9,256,261,21,0,1,268,276,1,262,261,261,20,0,17,1,17,2,269,17,1,260,0,260,273,0,257,1,276,260]

theorem envBound26793 : H12AffineFastState.Bounded env26793 := by
  intro p hp
  have h : env26793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26792_26793 : H12AffineEnvironment.transform 10 0 env26792 = env26793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26792 == env26793) = true)

theorem identity26793 : scanCanonicalize (H12AffineFastState.compose env26793 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26793 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26794 : List Nat := [2,4,8,1,1,0,9,256,261,4,0,1,268,261,1,262,261,261,5,0,0,1,0,2,269,0,1,260,0,260,256,0,257,1,261,260]

theorem envBound26794 : H12AffineFastState.Bounded env26794 := by
  intro p hp
  have h : env26794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26793_26794 : H12AffineEnvironment.transform 3 1 env26793 = env26794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26793 == env26794) = true)

theorem identity26794 : scanCanonicalize (H12AffineFastState.compose env26794 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound26794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26795 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,1,8,1,1,2,1,1,5,0,0,1,0,2,9,0,1,0,0,0,4,0,5,1,1,0]

theorem envBound26795 : H12AffineFastState.Bounded env26795 := by
  intro p hp
  have h : env26795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26794_26795 : H12AffineEnvironment.transform 7 4 env26794 = env26795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env26794 == env26795) = true)

def env26796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,169370,8328,64,4691218,115151,17664,262280,119042,4268162,257,213350,237762,63189]

theorem envBound26796 : H12AffineFastState.Bounded env26796 := by
  intro p hp
  have h : env26796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26707_26796 : H12AffineEnvironment.transform 20 184537 env26707 = env26796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env26707 == env26796) = true)

def env26797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,169370,8328,64,245138,115151,17664,262280,119042,329730,257,213350,237762,63189]

theorem envBound26797 : H12AffineFastState.Bounded env26797 := by
  intro p hp
  have h : env26797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26796_26797 : H12AffineEnvironment.transform 21 272512 env26796 = env26797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26796 == env26797) = true)

theorem identity26797 : scanCanonicalize (H12AffineFastState.compose env26797 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound26797 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140301,272512,144476,155982,8328,64,215366,79131,17664,262280,75222,329730,257,213350,218134,513]

theorem envBound26798 : H12AffineFastState.Bounded env26798 := by
  intro p hp
  have h : env26798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26797_26798 : H12AffineEnvironment.transform 14 29908 env26797 = env26798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env26797 == env26798) = true)

def env26799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140301,272392,144476,155982,8192,64,215366,79131,17664,262144,75102,329730,257,213350,218134,513]

theorem envBound26799 : H12AffineFastState.Bounded env26799 := by
  intro p hp
  have h : env26799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26798_26799 : H12AffineEnvironment.transform 6 8 env26798 = env26799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26798 == env26799) = true)

theorem identity26799 : scanCanonicalize (H12AffineFastState.compose env26799 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound26799 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env26800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,262144,1025,29789,82966,272392,87111,65877,8192,64,10589,79131,17664,262144,75102,329730,257,8573,13325,513]

theorem envBound26800 : H12AffineFastState.Bounded env26800 := by
  intro p hp
  have h : env26800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26799_26800 : H12AffineEnvironment.transform 16 90139 env26799 = env26800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env26799 == env26800) = true)

theorem identity26800 : scanCanonicalize (H12AffineFastState.compose env26800 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound26800 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env26801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,97326,1025,29789,82966,87078,87111,65877,8192,64,10589,79131,17664,97326,75102,29740,257,8573,13325,513]

theorem envBound26801 : H12AffineFastState.Bounded env26801 := by
  intro p hp
  have h : env26801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26800_26801 : H12AffineEnvironment.transform 17 97326 env26800 = env26801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env26800 == env26801) = true)

theorem identity26801 : scanCanonicalize (H12AffineFastState.compose env26801 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound26801 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env26802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,343,24908,32121,1025,29789,17729,21873,21776,2,8192,64,10589,13388,17664,32121,9225,29740,257,8573,13325,513]

theorem envBound26802 : H12AffineFastState.Bounded env26802 := by
  intro p hp
  have h : env26802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26801_26802 : H12AffineEnvironment.transform 15 343 env26801 = env26802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env26801 == env26802) = true)

theorem identity26802 : scanCanonicalize (H12AffineFastState.compose env26802 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound26802 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4160,9244,343,12556,11577,1025,9245,5377,1329,1360,2,8192,64,10589,13388,5440,11577,9225,9324,257,8573,13325,513]

theorem envBound26803 : H12AffineFastState.Bounded env26803 := by
  intro p hp
  have h : env26803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26802_26803 : H12AffineEnvironment.transform 13 4160 env26802 = env26803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env26802 == env26803) = true)

theorem identity26803 : scanCanonicalize (H12AffineFastState.compose env26803 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound26803 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4160,292,343,5172,2049,1025,293,5377,1329,1360,2,1336,64,3173,4468,5440,2049,305,340,257,1093,4405,513]

theorem envBound26804 : H12AffineFastState.Bounded env26804 := by
  intro p hp
  have h : env26804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26803_26804 : H12AffineEnvironment.transform 12 1336 env26803 = env26804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env26803 == env26804) = true)

theorem identity26804 : scanCanonicalize (H12AffineFastState.compose env26804 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26804 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26805 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1052,4160,0,115,5172,2049,1025,1,5157,1045,1140,2,1052,64,3173,4176,5220,2049,21,112,37,1093,4113,513]

theorem envBound26805 : H12AffineFastState.Bounded env26805 := by
  intro p hp
  have h : env26805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26804_26805 : H12AffineEnvironment.transform 7 36 env26804 = env26805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26804 == env26805) = true)

theorem identity26805 : scanCanonicalize (H12AffineFastState.compose env26805 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound26805 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26806 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,512,1052,576,0,115,1588,2049,1025,1,1573,1045,1140,2,1052,64,3173,592,1636,2049,21,112,37,1093,529,513]

theorem envBound26806 : H12AffineFastState.Bounded env26806 := by
  intro p hp
  have h : env26806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26805_26806 : H12AffineEnvironment.transform 11 512 env26805 = env26806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env26805 == env26806) = true)

theorem identity26806 : scanCanonicalize (H12AffineFastState.compose env26806 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound26806 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26807 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,512,120,576,0,115,592,2049,101,1,577,113,16,2,120,64,2049,592,512,2049,21,112,37,33,529,513]

theorem envBound26807 : H12AffineFastState.Bounded env26807 := by
  intro p hp
  have h : env26807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26806_26807 : H12AffineEnvironment.transform 9 100 env26806 = env26807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env26806 == env26807) = true)

theorem identity26807 : scanCanonicalize (H12AffineFastState.compose env26807 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound26807 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26808 : List Nat := [2,4,8,16,32,32,8,36,512,4,2048,512,24,544,0,19,560,2049,5,1,545,17,16,2,24,32,2049,560,512,2049,21,16,37,33,529,513]

theorem envBound26808 : H12AffineFastState.Bounded env26808 := by
  intro p hp
  have h : env26808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26807_26808 : H12AffineEnvironment.transform 5 32 env26807 = env26808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env26807 == env26808) = true)

theorem identity26808 : scanCanonicalize (H12AffineFastState.compose env26808 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound26808 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26809 : List Nat := [2,4,8,0,32,32,8,36,512,4,2048,512,8,544,0,3,544,2049,5,1,545,1,0,2,8,32,2049,544,512,2049,5,0,37,33,513,513]

theorem envBound26809 : H12AffineFastState.Bounded env26809 := by
  intro p hp
  have h : env26809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26808_26809 : H12AffineEnvironment.transform 3 0 env26808 = env26809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env26808 == env26809) = true)

def env26810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272393,144476,155982,8193,64,215366,79131,17664,262145,75103,329730,257,213350,218134,513]

theorem envBound26810 : H12AffineFastState.Bounded env26810 := by
  intro p hp
  have h : env26810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26798_26810 : H12AffineEnvironment.transform 6 9 env26798 = env26810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26798 == env26810) = true)

def env26811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10280,1025,29788,140301,33,144476,155982,8193,64,215366,79131,17664,10281,75103,73770,257,213350,218134,513]

theorem envBound26811 : H12AffineFastState.Bounded env26811 := by
  intro p hp
  have h : env26811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26810_26811 : H12AffineEnvironment.transform 17 10280 env26810 = env26811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26810 == env26811) = true)

theorem identity26811 : scanCanonicalize (H12AffineFastState.compose env26811 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound26811 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env26812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1025,8540,140301,33,144476,144462,8193,64,203846,79131,4096,10281,75103,73770,257,201830,196886,513]

theorem envBound26812 : H12AffineFastState.Bounded env26812 := by
  intro p hp
  have h : env26812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26811_26812 : H12AffineEnvironment.transform 13 5376 env26811 = env26812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env26811 == env26812) = true)

theorem identity26812 : scanCanonicalize (H12AffineFastState.compose env26812 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26812 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env26813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,5393,10280,1025,8540,12572,33,8525,8543,8193,64,67927,79131,4096,10281,75103,73770,257,65911,70663,513]

theorem envBound26813 : H12AffineFastState.Bounded env26813 := by
  intro p hp
  have h : env26813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26812_26813 : H12AffineEnvironment.transform 16 5393 env26812 = env26813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26812 == env26813) = true)

theorem identity26813 : scanCanonicalize (H12AffineFastState.compose env26813 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26813 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,5393,2420,1025,0,4160,33,17,3,349,64,67927,70727,4096,2421,66563,65910,257,65911,70663,513]

theorem envBound26814 : H12AffineFastState.Bounded env26814 := by
  intro p hp
  have h : env26814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26813_26814 : H12AffineEnvironment.transform 12 348 env26813 = env26814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26813 == env26814) = true)

theorem identity26814 : scanCanonicalize (H12AffineFastState.compose env26814 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound26814 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2420,1025,0,4160,33,17,3,349,64,2049,5393,4096,2421,1365,32,257,33,5457,513]

theorem envBound26815 : H12AffineFastState.Bounded env26815 := by
  intro p hp
  have h : env26815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26814_26815 : H12AffineEnvironment.transform 15 342 env26814 = env26815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env26814 == env26815) = true)

theorem identity26815 : scanCanonicalize (H12AffineFastState.compose env26815 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound26815 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26816 : List Nat := [2,4,8,16,32,64,9,256,512,564,2048,4096,348,4916,1,342,4901,2420,565,0,4160,33,17,3,349,64,2049,4901,4096,2421,865,32,257,33,4965,513]

theorem envBound26816 : H12AffineFastState.Bounded env26816 := by
  intro p hp
  have h : env26816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26815_26816 : H12AffineEnvironment.transform 9 564 env26815 = env26816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env26815 == env26816) = true)

theorem identity26816 : scanCanonicalize (H12AffineFastState.compose env26816 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26816 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26817 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,4096,268,4916,1,262,4901,2340,565,0,4112,33,17,3,269,16,2049,4901,4096,2341,817,32,257,33,4917,513]

theorem envBound26817 : H12AffineFastState.Bounded env26817 := by
  intro p hp
  have h : env26817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26816_26817 : H12AffineEnvironment.transform 5 16 env26816 = env26817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26816 == env26817) = true)

theorem identity26817 : scanCanonicalize (H12AffineFastState.compose env26817 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound26817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26818 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,513,268,309,1,262,292,2340,565,0,529,33,17,3,269,16,2049,292,513,2341,817,32,257,33,308,513]

theorem envBound26818 : H12AffineFastState.Bounded env26818 := by
  intro p hp
  have h : env26818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26817_26818 : H12AffineEnvironment.transform 11 513 env26817 = env26818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env26817 == env26818) = true)

theorem identity26818 : scanCanonicalize (H12AffineFastState.compose env26818 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound26818 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26819 : List Nat := [2,4,8,16,32,16,9,256,512,564,821,513,268,309,1,262,292,529,565,0,529,33,17,3,269,16,820,292,513,528,817,32,257,33,308,513]

theorem envBound26819 : H12AffineFastState.Bounded env26819 := by
  intro p hp
  have h : env26819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26818_26819 : H12AffineEnvironment.transform 10 821 env26818 = env26819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env26818 == env26819) = true)

theorem identity26819 : scanCanonicalize (H12AffineFastState.compose env26819 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound26819 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26820 : List Nat := [2,4,8,16,32,16,9,256,293,273,16,292,268,309,1,262,292,308,272,0,308,33,17,3,269,16,17,292,292,309,20,32,257,33,308,292]

theorem envBound26820 : H12AffineFastState.Bounded env26820 := by
  intro p hp
  have h : env26820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26819_26820 : H12AffineEnvironment.transform 8 293 env26819 = env26820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env26819 == env26820) = true)

theorem identity26820 : scanCanonicalize (H12AffineFastState.compose env26820 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26820 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26821 : List Nat := [2,4,8,16,17,16,9,256,276,273,16,277,268,260,1,262,277,261,272,0,261,16,17,3,269,16,17,277,277,260,20,17,257,16,261,277]

theorem envBound26821 : H12AffineFastState.Bounded env26821 := by
  intro p hp
  have h : env26821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26820_26821 : H12AffineEnvironment.transform 4 17 env26820 = env26821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26820 == env26821) = true)

theorem identity26821 : scanCanonicalize (H12AffineFastState.compose env26821 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26821 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26822 : List Nat := [2,4,8,16,17,16,9,21,1,4,16,0,25,17,1,19,0,16,5,0,16,16,17,3,24,16,17,0,0,17,20,17,20,16,16,0]

theorem envBound26822 : H12AffineFastState.Bounded env26822 := by
  intro p hp
  have h : env26822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26821_26822 : H12AffineEnvironment.transform 7 21 env26821 = env26822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26821 == env26822) = true)

theorem identity26822 : scanCanonicalize (H12AffineFastState.compose env26822 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26823 : List Nat := [2,4,8,1,0,1,9,4,1,4,1,0,8,0,1,2,0,1,5,0,1,1,0,3,9,1,0,0,0,0,5,0,5,1,1,0]

theorem envBound26823 : H12AffineFastState.Bounded env26823 := by
  intro p hp
  have h : env26823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26822_26823 : H12AffineEnvironment.transform 3 1 env26822 = env26823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26822 == env26823) = true)

def env26824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1025,29788,140301,32,144476,155982,8193,64,215366,79131,17664,10280,75103,73771,257,213350,218134,513]

theorem envBound26824 : H12AffineFastState.Bounded env26824 := by
  intro p hp
  have h : env26824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26810_26824 : H12AffineEnvironment.transform 17 10281 env26810 = env26824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26810 == env26824) = true)

theorem identity26824 : scanCanonicalize (H12AffineFastState.compose env26824 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound26824 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1025,29788,4161,32,16,21762,8193,64,97546,79131,17664,10280,75103,73771,257,95530,90202,513]

theorem envBound26825 : H12AffineFastState.Bounded env26825 := by
  intro p hp
  have h : env26825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26824_26825 : H12AffineEnvironment.transform 16 13388 env26824 = env26825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env26824 == env26825) = true)

theorem identity26825 : scanCanonicalize (H12AffineFastState.compose env26825 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15373) := by decide +kernel

theorem selectedBound26825 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env26826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15373,2128,65536,13388,10281,1025,2129,4161,32,16,10511,8193,64,65799,79131,14605,10280,75103,73771,257,67879,72791,513]

theorem envBound26826 : H12AffineFastState.Bounded env26826 := by
  intro p hp
  have h : env26826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26825_26826 : H12AffineEnvironment.transform 13 15373 env26825 = env26826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15373 env26825 == env26826) = true)

theorem identity26826 : scanCanonicalize (H12AffineFastState.compose env26826 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 10330) := by decide +kernel

theorem selectedBound26826 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15373,2128,10330,13388,10281,1025,2129,4161,32,16,10511,8193,64,10589,7489,14605,10280,3333,2161,257,8573,13325,513]

theorem envBound26827 : H12AffineFastState.Bounded env26827 := by
  intro p hp
  have h : env26827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26826_26827 : H12AffineEnvironment.transform 15 10330 env26826 = env26827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10330 env26826 == env26827) = true)

theorem identity26827 : scanCanonicalize (H12AffineFastState.compose env26827 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound26827 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env26828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4429,3392,2128,6423,1281,6500,1025,2129,4161,32,16,6210,4428,64,6160,7489,2112,6501,3333,2161,257,4144,1344,513]

theorem envBound26828 : H12AffineFastState.Bounded env26828 := by
  intro p hp
  have h : env26828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26827_26828 : H12AffineEnvironment.transform 12 4429 env26827 = env26828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env26827 == env26828) = true)

theorem identity26828 : scanCanonicalize (H12AffineFastState.compose env26828 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound26828 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,4429,1,1297,5206,1281,5157,1025,1296,4161,32,16,5379,4428,64,5457,4096,1281,5156,68,1328,257,4144,1344,513]

theorem envBound26829 : H12AffineFastState.Bounded env26829 := by
  intro p hp
  have h : env26829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26828_26829 : H12AffineEnvironment.transform 10 1345 env26828 = env26829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env26828 == env26829) = true)

theorem identity26829 : scanCanonicalize (H12AffineFastState.compose env26829 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound26829 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env26830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,1140,1337,1,1297,34,1281,81,1025,1296,1077,32,16,375,1336,64,293,1140,1281,80,68,1328,257,1092,1344,513]

theorem envBound26830 : H12AffineFastState.Bounded env26830 := by
  intro p hp
  have h : env26830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26829_26830 : H12AffineEnvironment.transform 11 1140 env26829 = env26830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env26829 == env26830) = true)

theorem identity26830 : scanCanonicalize (H12AffineFastState.compose env26830 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26830 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env26831 : List Nat := [2,4,8,16,32,64,9,256,512,273,80,357,40,1,0,34,16,81,272,1,292,32,16,375,41,64,293,357,16,80,68,33,257,341,81,513]

theorem envBound26831 : H12AffineFastState.Bounded env26831 := by
  intro p hp
  have h : env26831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26830_26831 : H12AffineEnvironment.transform 9 273 env26830 = env26831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26830 == env26831) = true)

theorem identity26831 : scanCanonicalize (H12AffineFastState.compose env26831 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26831 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26832 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,308,40,1,0,34,16,0,272,1,292,32,16,294,41,17,293,308,16,1,21,33,257,260,0,513]

theorem envBound26832 : H12AffineFastState.Bounded env26832 := by
  intro p hp
  have h : env26832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26831_26832 : H12AffineEnvironment.transform 5 17 env26831 = env26832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26831 == env26832) = true)

theorem identity26832 : scanCanonicalize (H12AffineFastState.compose env26832 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26833 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,40,1,0,34,16,0,52,1,0,32,16,2,41,17,1,16,16,1,21,33,37,32,0,513]

theorem envBound26833 : H12AffineFastState.Bounded env26833 := by
  intro p hp
  have h : env26833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26832_26833 : H12AffineEnvironment.transform 7 36 env26832 = env26833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26832 == env26833) = true)

theorem identity26833 : scanCanonicalize (H12AffineFastState.compose env26833 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound26833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26834 : List Nat := [2,4,8,16,32,17,9,36,59,53,1,16,40,1,0,34,16,0,52,1,0,32,16,2,41,17,1,16,16,1,21,33,37,32,0,58]

theorem envBound26834 : H12AffineFastState.Bounded env26834 := by
  intro p hp
  have h : env26834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26833_26834 : H12AffineEnvironment.transform 8 59 env26833 = env26834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env26833 == env26834) = true)

def env26835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,169370,8328,64,245139,115151,17664,262280,119042,329731,257,213350,237762,63189]

theorem envBound26835 : H12AffineFastState.Bounded env26835 := by
  intro p hp
  have h : env26835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26796_26835 : H12AffineEnvironment.transform 21 272513 env26796 = env26835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env26796 == env26835) = true)

theorem identity26835 : scanCanonicalize (H12AffineFastState.compose env26835 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound26835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58516,272513,62661,41431,8328,64,100830,115151,17664,262280,119042,329731,257,95531,103567,63189]

theorem envBound26836 : H12AffineFastState.Bounded env26836 := by
  intro p hp
  have h : env26836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26835_26836 : H12AffineEnvironment.transform 16 13389 env26835 = env26836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env26835 == env26836) = true)

def env26837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58516,169,62661,41431,8328,64,100830,115151,17664,10400,119042,73771,257,95531,103567,63189]

theorem envBound26837 : H12AffineFastState.Bounded env26837 := by
  intro p hp
  have h : env26837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26836_26837 : H12AffineEnvironment.transform 17 10280 env26836 = env26837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env26836 == env26837) = true)

theorem identity26837 : scanCanonicalize (H12AffineFastState.compose env26837 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound26837 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,13389,10280,1025,32769,58516,169,62661,41431,8328,64,31836,13389,17664,10400,9344,54697,257,32937,24845,63189]

theorem envBound26838 : H12AffineFastState.Bounded env26838 := by
  intro p hp
  have h : env26838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26837_26838 : H12AffineEnvironment.transform 15 62850 env26837 = env26838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env26837 == env26838) = true)

theorem identity26838 : scanCanonicalize (H12AffineFastState.compose env26838 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26838 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env26839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,13389,10280,1025,32769,58397,32,62540,41310,8193,64,31836,13389,17664,10281,9225,54560,257,32800,24845,63068]

theorem envBound26839 : H12AffineFastState.Bounded env26839 := by
  intro p hp
  have h : env26839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26838_26839 : H12AffineEnvironment.transform 6 9 env26838 = env26839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26838 == env26839) = true)

theorem identity26839 : scanCanonicalize (H12AffineFastState.compose env26839 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,342,13389,10280,1025,29788,4160,32,17,21763,8193,64,31836,13389,17664,10281,9225,8573,257,29821,24845,513]

theorem envBound26840 : H12AffineFastState.Bounded env26840 := by
  intro p hp
  have h : env26840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26839_26840 : H12AffineEnvironment.transform 14 29789 env26839 = env26840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26839 == env26840) = true)

theorem identity26840 : scanCanonicalize (H12AffineFastState.compose env26840 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound26840 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,342,13389,10280,1025,0,4160,32,17,8543,8193,64,2048,13389,12636,10281,9225,8573,257,33,5457,513]

theorem envBound26841 : H12AffineFastState.Bounded env26841 := by
  intro p hp
  have h : env26841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26840_26841 : H12AffineEnvironment.transform 13 13404 env26840 = env26841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env26840 == env26841) = true)

theorem identity26841 : scanCanonicalize (H12AffineFastState.compose env26841 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26841 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26842 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,1,262,13341,10280,1025,0,4112,32,17,8463,8193,16,2048,13341,12556,10281,9225,8493,257,33,5377,513]

theorem envBound26842 : H12AffineFastState.Bounded env26842 := by
  intro p hp
  have h : env26842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26841_26842 : H12AffineEnvironment.transform 5 16 env26841 = env26842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26841 == env26842) = true)

def env26843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58516,168,62661,41431,8328,64,100830,115151,17664,10401,119042,73770,257,95531,103567,63189]

theorem envBound26843 : H12AffineFastState.Bounded env26843 := by
  intro p hp
  have h : env26843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26836_26843 : H12AffineEnvironment.transform 17 10281 env26836 = env26843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env26836 == env26843) = true)

theorem identity26843 : scanCanonicalize (H12AffineFastState.compose env26843 (packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 41462) := by decide +kernel

theorem selectedBound26843 : packedSelected [0,1,2,4,5,6,8,9,11,17,18,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41462,13389,10281,1025,32769,58516,168,62661,41431,8328,64,10280,24633,17664,10401,28916,33244,257,54493,13689,63189]

theorem envBound26844 : H12AffineFastState.Bounded env26844 := by
  intro p hp
  have h : env26844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26843_26844 : H12AffineEnvironment.transform 15 41462 env26843 = env26844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41462 env26843 == env26844) = true)

theorem identity26844 : scanCanonicalize (H12AffineFastState.compose env26844 (packedSelected [1,3,5,8,11,12,15,17,18,23,26,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 12693) := by decide +kernel

theorem selectedBound26844 : packedSelected [1,3,5,8,11,12,15,17,18,23,26,31,32] rootPS < 2^1333 := by decide +kernel

def env26845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12693,32768,41462,13389,10281,1025,32769,38145,168,34128,41431,8328,64,10280,4524,13461,10401,353,33244,257,42312,13689,34624]

theorem envBound26845 : H12AffineFastState.Bounded env26845 := by
  intro p hp
  have h : env26845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26844_26845 : H12AffineEnvironment.transform 13 12693 env26844 = env26845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12693 env26844 == env26845) = true)

theorem identity26845 : scanCanonicalize (H12AffineFastState.compose env26845 (packedSelected [3,5,12,14,15,17,18,23,31,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26845 : packedSelected [3,5,12,14,15,17,18,23,31,35] rootPS < 2^1333 := by decide +kernel

def env26846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,32768,41343,13389,10281,1025,32769,38145,33,34128,41310,8193,64,10280,4389,13340,10280,353,33109,257,42312,13689,34624]

theorem envBound26846 : H12AffineFastState.Bounded env26846 := by
  intro p hp
  have h : env26846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26845_26846 : H12AffineEnvironment.transform 6 9 env26845 = env26846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26845 == env26846) = true)

def env26847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180361,2114882,8328,64,6637003,115150,2266584,262281,2294235,4268163,257,213350,237762,2237964]

theorem envBound26847 : H12AffineFastState.Bounded env26847 := by
  intro p hp
  have h : env26847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26706_26847 : H12AffineEnvironment.transform 22 180361 env26706 = env26847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env26706 == env26847) = true)

def env26848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,169370,8328,64,4691219,115150,17664,262281,119043,4268163,257,213350,237762,63188]

theorem envBound26848 : H12AffineFastState.Bounded env26848 := by
  intro p hp
  have h : env26848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26847_26848 : H12AffineEnvironment.transform 20 184536 env26847 = env26848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env26847 == env26848) = true)

def env26849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,169370,8328,64,245139,115150,17664,262281,119043,329731,257,213350,237762,63188]

theorem envBound26849 : H12AffineFastState.Bounded env26849 := by
  intro p hp
  have h : env26849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26848_26849 : H12AffineEnvironment.transform 21 272512 env26848 = env26849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env26848 == env26849) = true)

theorem identity26849 : scanCanonicalize (H12AffineFastState.compose env26849 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound26849 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77899,272512,73754,95497,8328,64,23808,115150,17664,262281,119043,329731,257,41461,16465,63188]

theorem envBound26850 : H12AffineFastState.Bounded env26850 := by
  intro p hp
  have h : env26850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26849_26850 : H12AffineEnvironment.transform 16 123027 env26849 = env26850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env26849 == env26850) = true)

def env26851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,77899,32,73754,95497,8328,64,23808,115150,17664,10281,119043,73891,257,41461,16465,63188]

theorem envBound26851 : H12AffineFastState.Bounded env26851 := by
  intro p hp
  have h : env26851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26850_26851 : H12AffineEnvironment.transform 17 10400 env26850 = env26851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26850 == env26851) = true)

theorem identity26851 : scanCanonicalize (H12AffineFastState.compose env26851 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound26851 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env26852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,16400,10400,1025,32769,37064,32,32921,54666,8328,64,23808,24909,17664,10281,29056,32800,257,41461,16465,63188]

theorem envBound26852 : H12AffineFastState.Bounded env26852 := by
  intro p hp
  have h : env26852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26851_26852 : H12AffineEnvironment.transform 15 41091 env26851 = env26852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env26851 == env26852) = true)

theorem identity26852 : scanCanonicalize (H12AffineFastState.compose env26852 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound26852 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env26853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,41091,13389,10400,1025,32769,37064,32,32921,41431,8328,64,10589,5392,12637,10281,1501,32800,257,41461,13324,33417]

theorem envBound26853 : H12AffineFastState.Bounded env26853 := by
  intro p hp
  have h : env26853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26852_26853 : H12AffineEnvironment.transform 13 13405 env26852 = env26853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env26852 == env26853) = true)

theorem identity26853 : scanCanonicalize (H12AffineFastState.compose env26853 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26853 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env26854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,32768,33247,5393,2556,1025,32769,37064,32,32921,32907,468,64,2049,5392,4097,2421,1501,32800,257,32937,5456,33417]

theorem envBound26854 : H12AffineFastState.Bounded env26854 := by
  intro p hp
  have h : env26854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26853_26854 : H12AffineEnvironment.transform 12 348 env26853 = env26854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26853 == env26854) = true)

theorem identity26854 : scanCanonicalize (H12AffineFastState.compose env26854 (packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 340) := by decide +kernel

theorem selectedBound26854 : packedSelected [3,5,6,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env26855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,340,139,5393,2556,1025,341,4508,32,461,479,468,64,2049,5392,4097,2421,1501,372,257,509,5456,989]

theorem envBound26855 : H12AffineFastState.Bounded env26855 := by
  intro p hp
  have h : env26855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26854_26855 : H12AffineEnvironment.transform 14 340 env26854 = env26855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 340 env26854 == env26855) = true)

theorem identity26855 : scanCanonicalize (H12AffineFastState.compose env26855 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound26855 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env26856 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,128,5341,136,139,5325,2080,1025,137,4160,32,17,3,8,64,2049,5324,4097,2217,1025,168,221,33,5260,513]

theorem envBound26856 : H12AffineFastState.Bounded env26856 := by
  intro p hp
  have h : env26856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1