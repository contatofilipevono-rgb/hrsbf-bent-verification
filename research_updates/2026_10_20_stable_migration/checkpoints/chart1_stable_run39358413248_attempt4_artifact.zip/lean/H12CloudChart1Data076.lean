import H12CloudChart1Data075

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity19191 : scanCanonicalize (H12AffineFastState.compose env19191 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound19191 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58517,180409,16,95496,8328,65,171416,5393,45525,10281,61705,144613,256,21793,46212,120542]

theorem envBound19192 : H12AffineFastState.Bounded env19192 := by
  intro p hp
  have h : env19192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19191_19192 : H12AffineEnvironment.transform 17 190521 env19191 = env19192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env19191 == env19192) = true)

def env19193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58397,180273,16,95496,8192,65,171280,5393,45405,10281,61705,144493,256,21793,46092,120406]

theorem envBound19193 : H12AffineFastState.Bounded env19193 := by
  intro p hp
  have h : env19193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19192_19193 : H12AffineEnvironment.transform 6 8 env19192 = env19193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19192 == env19193) = true)

theorem identity19193 : scanCanonicalize (H12AffineFastState.compose env19193 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound19193 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,130175,1024,32769,58397,119927,16,95496,8192,65,100694,5393,45405,10281,61705,73771,256,21793,46092,120406]

theorem envBound19194 : H12AffineFastState.Bounded env19194 := by
  intro p hp
  have h : env19194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19193_19194 : H12AffineEnvironment.transform 16 70726 env19193 = env19194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env19193 == env19194) = true)

theorem identity19194 : scanCanonicalize (H12AffineFastState.compose env19194 (packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19194 : packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env19195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,70726,108927,1024,32769,45341,98679,16,73736,8192,65,100694,5393,45405,10281,41993,73771,256,33,46092,99158]

theorem envBound19195 : H12AffineFastState.Bounded env19195 := by
  intro p hp
  have h : env19195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19194_19195 : H12AffineEnvironment.transform 13 5376 env19194 = env19195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19194 == env19195) = true)

theorem identity19195 : scanCanonicalize (H12AffineFastState.compose env19195 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound19195 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env19196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,40970,46156,2421,1024,32769,45341,8573,16,32770,8192,65,10588,5393,45405,10281,41993,32801,256,33,46092,9052]

theorem envBound19196 : H12AffineFastState.Bounded env19196 := by
  intro p hp
  have h : env19196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19195_19196 : H12AffineEnvironment.transform 15 40970 env19195 = env19196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env19195 == env19196) = true)

theorem identity19196 : scanCanonicalize (H12AffineFastState.compose env19196 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19196 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env19197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,81,8283,13341,2421,1024,80,12620,8573,16,83,8192,65,10588,5393,12556,10281,9304,112,256,33,13405,9052]

theorem envBound19197 : H12AffineFastState.Bounded env19197 := by
  intro p hp
  have h : env19197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19196_19197 : H12AffineEnvironment.transform 14 81 env19196 = env19197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19196 == env19197) = true)

theorem identity19197 : scanCanonicalize (H12AffineFastState.compose env19197 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19197 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env19198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,81,342,5392,2421,1024,80,4161,112,16,83,269,65,2129,5393,4097,2340,1365,112,256,33,5456,593]

theorem envBound19198 : H12AffineFastState.Bounded env19198 := by
  intro p hp
  have h : env19198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19197_19198 : H12AffineEnvironment.transform 12 269 env19197 = env19198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19197 == env19198) = true)

theorem identity19198 : scanCanonicalize (H12AffineFastState.compose env19198 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19198 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19199 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,269,5376,81,342,5392,2388,1024,80,4161,81,16,83,269,65,2129,5393,4097,2309,1365,81,256,0,5456,593]

theorem envBound19199 : H12AffineFastState.Bounded env19199 := by
  intro p hp
  have h : env19199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19198_19199 : H12AffineEnvironment.transform 4 1 env19198 = env19199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19198 == env19199) = true)

theorem identity19199 : scanCanonicalize (H12AffineFastState.compose env19199 (packedSelected [1,2,4,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound19199 : packedSelected [1,2,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env19200 : List Nat := [2,4,8,16,1,64,8,256,512,1024,80,4096,269,5376,81,342,5392,260,1024,80,4161,81,16,83,269,65,1,5393,4097,341,1365,81,256,0,5456,593]

theorem envBound19200 : H12AffineFastState.Bounded env19200 := by
  intro p hp
  have h : env19200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19199_19200 : H12AffineEnvironment.transform 10 80 env19199 = env19200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env19199 == env19200) = true)

theorem identity19200 : scanCanonicalize (H12AffineFastState.compose env19200 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound19200 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env19201 : List Nat := [2,4,8,16,1,64,8,256,512,1024,80,17,269,1297,81,342,1281,260,1024,80,80,81,16,83,269,65,1,1280,16,341,1365,81,256,0,1345,593]

theorem envBound19201 : H12AffineFastState.Bounded env19201 := by
  intro p hp
  have h : env19201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19200_19201 : H12AffineEnvironment.transform 11 17 env19200 = env19201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19200 == env19201) = true)

theorem identity19201 : scanCanonicalize (H12AffineFastState.compose env19201 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound19201 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env19202 : List Nat := [2,4,8,16,1,64,8,256,512,69,80,17,269,340,81,342,324,260,69,80,80,81,16,83,269,65,1,325,16,341,272,81,256,0,260,593]

theorem envBound19202 : H12AffineFastState.Bounded env19202 := by
  intro p hp
  have h : env19202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19201_19202 : H12AffineEnvironment.transform 9 69 env19201 = env19202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env19201 == env19202) = true)

theorem identity19202 : scanCanonicalize (H12AffineFastState.compose env19202 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19202 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env19203 : List Nat := [2,4,8,16,1,16,8,256,512,21,0,17,269,260,1,262,276,260,21,0,0,1,16,3,269,17,1,277,16,261,272,1,256,0,260,513]

theorem envBound19203 : H12AffineFastState.Bounded env19203 := by
  intro p hp
  have h : env19203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19202_19203 : H12AffineEnvironment.transform 5 16 env19202 = env19203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19202 == env19203) = true)

theorem identity19203 : scanCanonicalize (H12AffineFastState.compose env19203 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19203 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19204 : List Nat := [2,4,8,0,1,0,8,256,512,5,0,1,269,260,1,262,260,260,5,0,0,1,0,3,269,1,1,261,0,261,256,1,256,0,260,513]

theorem envBound19204 : H12AffineFastState.Bounded env19204 := by
  intro p hp
  have h : env19204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19203_19204 : H12AffineEnvironment.transform 3 0 env19203 = env19204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19203 == env19204) = true)

theorem identity19204 : scanCanonicalize (H12AffineFastState.compose env19204 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound19204 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19205 : List Nat := [2,4,8,0,1,0,8,256,260,5,0,1,269,260,1,262,260,260,5,0,0,1,0,3,269,1,1,261,0,261,256,1,256,0,260,261]

theorem envBound19205 : H12AffineFastState.Bounded env19205 := by
  intro p hp
  have h : env19205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19204_19205 : H12AffineEnvironment.transform 8 260 env19204 = env19205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env19204 == env19205) = true)

theorem identity19205 : scanCanonicalize (H12AffineFastState.compose env19205 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19206 : List Nat := [2,4,8,0,1,0,8,4,0,5,0,1,9,0,1,2,0,0,5,0,0,1,0,3,9,1,1,1,0,1,4,1,4,0,0,1]

theorem envBound19206 : H12AffineFastState.Bounded env19206 := by
  intro p hp
  have h : env19206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19205_19206 : H12AffineEnvironment.transform 7 4 env19205 = env19206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19205 == env19206) = true)

theorem identity19206 : scanCanonicalize (H12AffineFastState.compose env19206 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19207 : List Nat := [2,4,2,0,1,0,2,4,0,5,0,1,3,0,1,2,0,0,5,0,0,1,0,3,3,1,1,1,0,1,4,1,4,0,0,1]

theorem envBound19207 : H12AffineFastState.Bounded env19207 := by
  intro p hp
  have h : env19207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19206_19207 : H12AffineEnvironment.transform 2 2 env19206 = env19207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19206 == env19207) = true)

def env19208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58396,180272,16,95496,8193,65,171281,5393,45404,10281,61705,144492,256,21793,46093,120407]

theorem envBound19208 : H12AffineFastState.Bounded env19208 := by
  intro p hp
  have h : env19208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19192_19208 : H12AffineEnvironment.transform 6 9 env19192 = env19208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19192 == env19208) = true)

theorem identity19208 : scanCanonicalize (H12AffineFastState.compose env19208 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound19208 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,89379,1024,32769,58396,95530,16,95496,8193,65,75787,5393,45404,10281,61705,98678,256,21793,46093,120407]

theorem envBound19209 : H12AffineFastState.Bounded env19209 := by
  intro p hp
  have h : env19209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19208_19209 : H12AffineEnvironment.transform 16 111898 env19208 = env19209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env19208 == env19209) = true)

theorem identity19209 : scanCanonicalize (H12AffineFastState.compose env19209 (packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound19209 : packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19210 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29822,49508,10589,1024,32769,58396,340,16,374,8193,65,23669,5393,45404,10281,61705,62728,256,21793,46093,41513]

theorem envBound19210 : H12AffineFastState.Bounded env19210 := by
  intro p hp
  have h : env19210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19209_19210 : H12AffineEnvironment.transform 15 29822 env19209 = env19210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env19209 == env19210) = true)

theorem identity19210 : scanCanonicalize (H12AffineFastState.compose env19210 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound19210 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19211 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,343,46157,10589,1024,32769,37173,340,16,374,8193,65,10588,5393,45404,10281,33824,32801,256,8200,46093,41513]

theorem envBound19211 : H12AffineFastState.Bounded env19211 := by
  intro p hp
  have h : env19211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19210_19211 : H12AffineEnvironment.transform 13 13609 env19210 = env19211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env19210 == env19211) = true)

theorem identity19211 : scanCanonicalize (H12AffineFastState.compose env19211 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound19211 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8232,343,5221,10589,1024,8233,12573,340,16,374,8193,65,10588,5393,4468,10281,9224,8201,256,8200,5157,513]

theorem envBound19212 : H12AffineFastState.Bounded env19212 := by
  intro p hp
  have h : env19212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19211_19212 : H12AffineEnvironment.transform 14 8232 env19211 = env19212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19211 == env19212) = true)

theorem identity19212 : scanCanonicalize (H12AffineFastState.compose env19212 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound19212 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19213 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12344,8232,343,4468,10589,273,8233,12573,340,16,374,8193,65,10588,4096,4468,10281,8473,8201,256,8200,4404,513]

theorem envBound19213 : H12AffineFastState.Bounded env19213 := by
  intro p hp
  have h : env19213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19212_19213 : H12AffineEnvironment.transform 9 273 env19212 = env19213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19212 == env19213) = true)

theorem identity19213 : scanCanonicalize (H12AffineFastState.compose env19213 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19213 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19214 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,12344,8232,262,4389,10508,273,8233,12573,261,16,295,8193,16,10509,4096,4389,10281,8473,8201,256,8200,4404,513]

theorem envBound19214 : H12AffineFastState.Bounded env19214 := by
  intro p hp
  have h : env19214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19213_19214 : H12AffineEnvironment.transform 5 17 env19213 = env19214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19213 == env19214) = true)

theorem identity19214 : scanCanonicalize (H12AffineFastState.compose env19214 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19214 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19215 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,8192,12344,8232,35,4096,10281,52,8233,12344,32,16,2,8193,16,10280,4096,4096,10281,8252,8201,37,8200,4113,513]

theorem envBound19215 : H12AffineFastState.Bounded env19215 := by
  intro p hp
  have h : env19215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19214_19215 : H12AffineEnvironment.transform 7 37 env19214 = env19215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19214 == env19215) = true)

theorem identity19215 : scanCanonicalize (H12AffineFastState.compose env19215 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound19215 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env19216 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,8192,8232,8232,35,16,10281,52,8233,8232,32,16,2,8193,16,10280,16,16,10281,8252,8201,37,8200,1,513]

theorem envBound19216 : H12AffineFastState.Bounded env19216 := by
  intro p hp
  have h : env19216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19215_19216 : H12AffineEnvironment.transform 11 16 env19215 = env19216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19215 == env19216) = true)

theorem identity19216 : scanCanonicalize (H12AffineFastState.compose env19216 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound19216 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env19217 : List Nat := [2,4,8,16,32,17,9,37,512,52,529,16,8192,8232,8232,35,16,8760,52,8233,8232,32,16,2,8193,16,8761,16,16,8760,8252,8201,37,8200,1,513]

theorem envBound19217 : H12AffineFastState.Bounded env19217 := by
  intro p hp
  have h : env19217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19216_19217 : H12AffineEnvironment.transform 10 529 env19216 = env19217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env19216 == env19217) = true)

theorem identity19217 : scanCanonicalize (H12AffineFastState.compose env19217 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19217 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env19218 : List Nat := [2,4,8,16,0,17,9,5,512,20,529,16,8192,8200,8200,3,16,8728,20,8201,8200,0,16,2,8193,16,8729,16,16,8728,8220,8201,5,8200,1,513]

theorem envBound19218 : H12AffineFastState.Bounded env19218 := by
  intro p hp
  have h : env19218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19217_19218 : H12AffineEnvironment.transform 4 0 env19217 = env19218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19217 == env19218) = true)

theorem identity19218 : scanCanonicalize (H12AffineFastState.compose env19218 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound19218 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19219 : List Nat := [2,4,8,16,0,17,9,5,17,20,0,16,8192,8200,8200,3,16,8201,20,8201,8200,0,16,2,8193,16,8200,16,16,8201,8220,8201,5,8200,1,16]

theorem envBound19219 : H12AffineFastState.Bounded env19219 := by
  intro p hp
  have h : env19219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19218_19219 : H12AffineEnvironment.transform 8 17 env19218 = env19219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env19218 == env19219) = true)

def env19220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396460,272513,452649,95496,8328,65,292256,458024,45525,10281,399664,144612,256,21793,46212,474855]

theorem envBound19220 : H12AffineFastState.Bounded env19220 := by
  intro p hp
  have h : env19220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19190_19220 : H12AffineEnvironment.transform 21 272513 env19190 = env19220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env19190 == env19220) = true)

def env19221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272393,452649,95496,8192,65,292136,458024,45405,10281,399664,144492,256,21793,46092,474735]

theorem envBound19221 : H12AffineFastState.Bounded env19221 := by
  intro p hp
  have h : env19221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19220_19221 : H12AffineEnvironment.transform 6 8 env19220 = env19221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19220 == env19221) = true)

def env19222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314420,272393,272441,95496,8192,65,292136,277816,45405,10281,317728,62588,256,21793,46092,392831]

theorem envBound19222 : H12AffineFastState.Bounded env19222 := by
  intro p hp
  have h : env19222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19221_19222 : H12AffineEnvironment.transform 16 49168 env19221 = env19222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env19221 == env19222) = true)

theorem identity19222 : scanCanonicalize (H12AffineFastState.compose env19222 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19222 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,262144,1024,32769,314420,272393,272441,41310,8192,65,292136,277816,45405,10281,317728,62588,256,21793,46092,272937]

theorem envBound19223 : H12AffineFastState.Bounded env19223 := by
  intro p hp
  have h : env19223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19222_19223 : H12AffineEnvironment.transform 15 54358 env19222 = env19223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19222 == env19223) = true)

theorem identity19223 : scanCanonicalize (H12AffineFastState.compose env19223 (packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19223 : packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,41050,46108,262144,1024,32769,309304,272393,272441,41310,8192,65,262436,277816,45405,10281,306476,32880,256,8493,46092,272937]

theorem envBound19224 : H12AffineFastState.Bounded env19224 := by
  intro p hp
  have h : env19224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19223_19224 : H12AffineEnvironment.transform 13 13324 env19223 = env19224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19223 == env19224) = true)

theorem identity19224 : scanCanonicalize (H12AffineFastState.compose env19224 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound19224 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env19225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,41050,46108,43049,1024,32769,4113,32800,32784,41310,8192,65,43277,38161,45405,10281,1285,32880,256,8493,46092,33280]

theorem envBound19225 : H12AffineFastState.Bounded env19225 := by
  intro p hp
  have h : env19225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19224_19225 : H12AffineEnvironment.transform 17 43049 env19224 = env19225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env19224 == env19225) = true)

theorem identity19225 : scanCanonicalize (H12AffineFastState.compose env19225 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19225 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19226 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,40971,46108,43049,1024,32769,4113,32800,32784,41231,8192,16,43277,38161,45324,10281,1285,32801,256,8493,46092,33280]

theorem envBound19226 : H12AffineFastState.Bounded env19226 := by
  intro p hp
  have h : env19226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19225_19226 : H12AffineEnvironment.transform 5 17 env19225 = env19226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19225 == env19226) = true)

theorem identity19226 : scanCanonicalize (H12AffineFastState.compose env19226 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19226 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19227 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8461,262,5393,2340,1024,8460,4113,8493,8477,2,8192,16,2048,13340,4097,10281,1285,8492,256,8493,5377,8973]

theorem envBound19227 : H12AffineFastState.Bounded env19227 := by
  intro p hp
  have h : env19227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19226_19227 : H12AffineEnvironment.transform 14 8461 env19226 = env19227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19226 == env19227) = true)

theorem identity19227 : scanCanonicalize (H12AffineFastState.compose env19227 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19227 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env19228 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,8192,12344,8461,262,4389,2340,52,8460,4113,8493,8477,2,8192,16,2048,12328,4097,10281,305,8492,256,8493,4405,8973]

theorem envBound19228 : H12AffineFastState.Bounded env19228 := by
  intro p hp
  have h : env19228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19227_19228 : H12AffineEnvironment.transform 9 52 env19227 = env19228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19227 == env19228) = true)

theorem identity19228 : scanCanonicalize (H12AffineFastState.compose env19228 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19228 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env19229 : List Nat := [2,4,8,16,0,17,8,256,512,20,2048,4096,8192,12312,8461,262,4357,2308,20,8460,4113,8461,8477,2,8192,16,2048,12296,4097,10249,273,8460,256,8461,4373,8973]

theorem envBound19229 : H12AffineFastState.Bounded env19229 := by
  intro p hp
  have h : env19229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19228_19229 : H12AffineEnvironment.transform 4 0 env19228 = env19229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19228 == env19229) = true)

theorem identity19229 : scanCanonicalize (H12AffineFastState.compose env19229 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19229 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19230 : List Nat := [2,4,8,16,0,17,8,256,512,20,2048,4096,269,4373,0,262,4357,2308,20,1,4113,0,16,2,269,16,2048,4357,4097,2308,273,1,256,0,4373,512]

theorem envBound19230 : H12AffineFastState.Bounded env19230 := by
  intro p hp
  have h : env19230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19229_19230 : H12AffineEnvironment.transform 12 269 env19229 = env19230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19229 == env19230) = true)

theorem identity19230 : scanCanonicalize (H12AffineFastState.compose env19230 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound19230 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19231 : List Nat := [2,4,8,16,0,17,8,256,512,20,782,4096,269,4373,0,262,4357,522,20,1,4113,0,16,2,269,16,782,4357,4097,522,273,1,256,0,4373,512]

theorem envBound19231 : H12AffineFastState.Bounded env19231 := by
  intro p hp
  have h : env19231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19230_19231 : H12AffineEnvironment.transform 10 782 env19230 = env19231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env19230 == env19231) = true)

theorem identity19231 : scanCanonicalize (H12AffineFastState.compose env19231 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound19231 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19232 : List Nat := [2,4,8,16,0,17,8,256,512,20,782,538,269,783,0,262,799,522,20,1,523,0,16,2,269,16,782,799,539,522,273,1,256,0,783,512]

theorem envBound19232 : H12AffineFastState.Bounded env19232 := by
  intro p hp
  have h : env19232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19231_19232 : H12AffineEnvironment.transform 11 538 env19231 = env19232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env19231 == env19232) = true)

theorem identity19232 : scanCanonicalize (H12AffineFastState.compose env19232 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19233 : List Nat := [2,4,8,16,0,17,8,4,512,20,522,538,9,523,0,2,539,522,20,1,523,0,16,2,9,16,522,539,539,522,21,1,4,0,523,512]

theorem envBound19233 : H12AffineFastState.Bounded env19233 := by
  intro p hp
  have h : env19233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19232_19233 : H12AffineEnvironment.transform 7 4 env19232 = env19233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19232 == env19233) = true)

theorem identity19233 : scanCanonicalize (H12AffineFastState.compose env19233 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound19233 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19234 : List Nat := [2,4,8,16,0,17,8,4,15,20,5,21,9,4,0,2,20,5,20,1,4,0,16,2,9,16,5,20,20,5,21,1,4,0,4,15]

theorem envBound19234 : H12AffineFastState.Bounded env19234 := by
  intro p hp
  have h : env19234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19233_19234 : H12AffineEnvironment.transform 8 15 env19233 = env19234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env19233 == env19234) = true)

theorem identity19234 : scanCanonicalize (H12AffineFastState.compose env19234 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound19234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19235 : List Nat := [1,4,8,16,0,17,8,4,12,20,5,21,9,4,0,1,20,5,20,1,4,0,16,1,9,16,5,20,20,5,21,1,4,0,4,12]

theorem envBound19235 : H12AffineFastState.Bounded env19235 := by
  intro p hp
  have h : env19235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19234_19235 : H12AffineEnvironment.transform 0 1 env19234 = env19235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env19234 == env19235) = true)

def env19236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314421,272393,272440,95496,8192,65,292136,277817,45405,10281,317729,62589,256,21793,46092,392830]

theorem envBound19236 : H12AffineFastState.Bounded env19236 := by
  intro p hp
  have h : env19236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19221_19236 : H12AffineEnvironment.transform 16 49169 env19221 = env19236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env19221 == env19236) = true)

theorem identity19236 : scanCanonicalize (H12AffineFastState.compose env19236 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound19236 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,130175,1024,32769,77898,119926,119879,95496,8192,65,100695,115014,45405,10281,75102,62589,256,21793,46092,513]

theorem envBound19237 : H12AffineFastState.Bounded env19237 := by
  intro p hp
  have h : env19237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19236_19237 : H12AffineEnvironment.transform 17 130175 env19236 = env19237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env19236 == env19237) = true)

theorem identity19237 : scanCanonicalize (H12AffineFastState.compose env19237 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound19237 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10280,1024,32769,58397,33,16,41311,8192,65,23808,5393,45405,10281,61705,62589,256,21793,46092,513]

theorem envBound19238 : H12AffineFastState.Bounded env19238 := by
  intro p hp
  have h : env19238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19237_19238 : H12AffineEnvironment.transform 15 54359 env19237 = env19238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env19237 == env19238) = true)

theorem identity19238 : scanCanonicalize (H12AffineFastState.compose env19238 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound19238 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env19239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,262,5440,10280,1024,21840,12620,33,16,29710,8192,65,23808,5393,25612,10281,9304,8492,256,21793,24925,513]

theorem envBound19239 : H12AffineFastState.Bounded env19239 := by
  intro p hp
  have h : env19239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19238_19239 : H12AffineEnvironment.transform 14 21841 env19238 = env19239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env19238 == env19239) = true)

theorem identity19239 : scanCanonicalize (H12AffineFastState.compose env19239 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound19239 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env19240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8460,262,5440,10280,1024,8461,12620,33,16,83,8192,65,10589,5393,4177,10281,9304,8492,256,8572,5376,513]

theorem envBound19240 : H12AffineFastState.Bounded env19240 := by
  intro p hp
  have h : env19240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19239_19240 : H12AffineEnvironment.transform 13 13405 env19239 = env19240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env19239 == env19240) = true)

theorem identity19240 : scanCanonicalize (H12AffineFastState.compose env19240 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,80,262,5440,2420,1024,81,4112,33,16,83,348,65,2049,5393,4177,2421,1284,112,256,32,5376,513]

theorem envBound19241 : H12AffineFastState.Bounded env19241 := by
  intro p hp
  have h : env19241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19240_19241 : H12AffineEnvironment.transform 12 348 env19240 = env19241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19240 == env19241) = true)

theorem identity19241 : scanCanonicalize (H12AffineFastState.compose env19241 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1361) := by decide +kernel

theorem selectedBound19241 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env19242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1361,4096,348,5377,80,262,5440,1061,1024,81,4112,33,16,83,348,65,1360,5393,4177,1060,1284,112,256,32,5376,513]

theorem envBound19242 : H12AffineFastState.Bounded env19242 := by
  intro p hp
  have h : env19242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19241_19242 : H12AffineEnvironment.transform 10 1361 env19241 = env19242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1361 env19241 == env19242) = true)

theorem identity19242 : scanCanonicalize (H12AffineFastState.compose env19242 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound19242 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env19243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1361,1,348,1280,80,262,1345,1061,1024,81,17,33,16,83,348,65,1360,1296,80,1060,1284,112,256,32,1281,513]

theorem envBound19243 : H12AffineFastState.Bounded env19243 := by
  intro p hp
  have h : env19243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19242_19243 : H12AffineEnvironment.transform 11 1 env19242 = env19243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env19242 == env19243) = true)

theorem identity19243 : scanCanonicalize (H12AffineFastState.compose env19243 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19243 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env19244 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1280,1,269,1280,1,262,1296,1061,1024,0,17,33,16,2,269,16,1281,1296,1,1060,1284,33,256,32,1281,513]

theorem envBound19244 : H12AffineFastState.Bounded env19244 := by
  intro p hp
  have h : env19244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19243_19244 : H12AffineEnvironment.transform 5 17 env19243 = env19244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19243 == env19244) = true)

theorem identity19244 : scanCanonicalize (H12AffineFastState.compose env19244 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19245 : List Nat := [2,4,8,16,32,17,8,256,512,52,308,1,269,308,1,262,292,17,52,0,17,33,16,2,269,16,309,292,1,16,304,33,256,32,309,513]

theorem envBound19245 : H12AffineFastState.Bounded env19245 := by
  intro p hp
  have h : env19245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19244_19245 : H12AffineEnvironment.transform 9 52 env19244 = env19245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19244 == env19245) = true)

theorem identity19245 : scanCanonicalize (H12AffineFastState.compose env19245 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound19245 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19246 : List Nat := [2,4,8,16,32,17,8,256,0,52,308,1,269,308,1,262,292,17,52,0,17,33,16,2,269,16,309,292,1,16,304,33,256,32,309,1]

theorem envBound19246 : H12AffineFastState.Bounded env19246 := by
  intro p hp
  have h : env19246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19245_19246 : H12AffineEnvironment.transform 8 0 env19245 = env19246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env19245 == env19246) = true)

def env19247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272392,452649,95496,8193,65,292137,458024,45404,10281,399664,144493,256,21793,46093,474734]

theorem envBound19247 : H12AffineFastState.Bounded env19247 := by
  intro p hp
  have h : env19247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19220_19247 : H12AffineEnvironment.transform 6 9 env19220 = env19247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19220 == env19247) = true)

def env19248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272392,272441,95496,8193,65,292137,277816,45404,10281,317728,62589,256,21793,46093,392830]

theorem envBound19248 : H12AffineFastState.Bounded env19248 := by
  intro p hp
  have h : env19248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19247_19248 : H12AffineEnvironment.transform 16 49168 env19247 = env19248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env19247 == env19248) = true)

theorem identity19248 : scanCanonicalize (H12AffineFastState.compose env19248 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound19248 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89379,1024,32769,102678,95531,95514,95496,8193,65,75786,90139,45404,10281,99331,62589,256,21793,46093,41821]

theorem envBound19249 : H12AffineFastState.Bounded env19249 := by
  intro p hp
  have h : env19249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19248_19249 : H12AffineEnvironment.transform 17 89379 env19248 = env19249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env19248 == env19249) = true)

theorem identity19249 : scanCanonicalize (H12AffineFastState.compose env19249 (packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound19249 : packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env19250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32802,49168,56577,1024,32769,4404,62729,62776,62762,8193,65,43048,57401,45404,10281,1057,62589,256,21793,46093,41821]

theorem envBound19250 : H12AffineFastState.Bounded env19250 := by
  intro p hp
  have h : env19250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19249_19250 : H12AffineEnvironment.transform 15 32802 env19249 = env19250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env19249 == env19250) = true)

theorem identity19250 : scanCanonicalize (H12AffineFastState.compose env19250 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound19250 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env19251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,32802,46108,43277,1024,32769,4404,33029,33076,33062,8193,65,43048,37941,45404,10281,1057,32881,256,8493,46093,41821]

theorem envBound19251 : H12AffineFastState.Bounded env19251 := by
  intro p hp
  have h : env19251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19250_19251 : H12AffineEnvironment.transform 13 13324 env19250 = env19251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env19250 == env19251) = true)

theorem identity19251 : scanCanonicalize (H12AffineFastState.compose env19251 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19251 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env19252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,35,13341,10508,1024,0,4404,260,309,295,8193,65,10281,5172,12637,10281,1057,112,256,8493,13324,9052]

theorem envBound19252 : H12AffineFastState.Bounded env19252 := by
  intro p hp
  have h : env19252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19251_19252 : H12AffineEnvironment.transform 14 1 env19251 = env19252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19251 == env19252) = true)

theorem identity19252 : scanCanonicalize (H12AffineFastState.compose env19252 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19252 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5156,1,35,5173,2340,1024,0,4404,260,309,295,41,65,2049,5172,4469,2049,1057,112,256,261,5156,884]

theorem envBound19253 : H12AffineFastState.Bounded env19253 := by
  intro p hp
  have h : env19253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19252_19253 : H12AffineEnvironment.transform 12 40 env19252 = env19253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19252 == env19253) = true)

theorem identity19253 : scanCanonicalize (H12AffineFastState.compose env19253 (packedSelected [0,3,4,5,6,7,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19253 : packedSelected [0,3,4,5,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19254 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,40,5156,1,35,5173,2340,1024,0,4404,260,309,295,41,49,2049,5172,4357,2049,1057,0,256,261,5156,772]

theorem envBound19254 : H12AffineFastState.Bounded env19254 := by
  intro p hp
  have h : env19254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19253_19254 : H12AffineEnvironment.transform 5 48 env19253 = env19254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19253 == env19254) = true)

theorem identity19254 : scanCanonicalize (H12AffineFastState.compose env19254 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19254 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19255 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4113,33,16,2,41,49,2049,5172,4128,2049,1057,0,37,32,5156,545]

theorem envBound19255 : H12AffineFastState.Bounded env19255 := by
  intro p hp
  have h : env19255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19254_19255 : H12AffineEnvironment.transform 7 37 env19254 = env19255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19254 == env19255) = true)

def env19256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272392,272440,95496,8193,65,292137,277817,45404,10281,317729,62588,256,21793,46093,392831]

theorem envBound19256 : H12AffineFastState.Bounded env19256 := by
  intro p hp
  have h : env19256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19247_19256 : H12AffineEnvironment.transform 16 49169 env19247 = env19256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env19247 == env19256) = true)

theorem identity19256 : scanCanonicalize (H12AffineFastState.compose env19256 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound19256 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,49169,262144,1024,32769,314420,272392,272440,3,8193,65,292137,277817,45404,10281,317729,62588,256,21793,46093,297844]

theorem envBound19257 : H12AffineFastState.Bounded env19257 := by
  intro p hp
  have h : env19257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19256_19257 : H12AffineEnvironment.transform 15 29963 env19256 = env19257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env19256 == env19257) = true)

theorem identity19257 : scanCanonicalize (H12AffineFastState.compose env19257 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound19257 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env19258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8313,29963,24680,262144,1024,8312,289869,272392,272440,3,8193,65,292137,277817,4389,10281,293208,21509,256,21793,5236,273165]

theorem envBound19258 : H12AffineFastState.Bounded env19258 := by
  intro p hp
  have h : env19258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19257_19258 : H12AffineEnvironment.transform 14 8313 env19257 = env19258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env19257 == env19258) = true)

theorem identity19258 : scanCanonicalize (H12AffineFastState.compose env19258 (packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19258 : packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS < 2^1333 := by decide +kernel

def env19259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,372,21510,16741,262144,1024,373,281920,264453,264501,3,268,65,283684,269364,4389,2340,284757,21509,256,21793,5236,264704]

theorem envBound19259 : H12AffineFastState.Bounded env19259 := by
  intro p hp
  have h : env19259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19258_19259 : H12AffineEnvironment.transform 12 269 env19258 = env19259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19258 == env19259) = true)

theorem identity19259 : scanCanonicalize (H12AffineFastState.compose env19259 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound19259 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env19260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,372,21510,16741,23589,1024,373,4453,21792,21776,3,268,65,2049,16401,4389,2340,1136,21509,256,21793,5236,22053]

theorem envBound19260 : H12AffineFastState.Bounded env19260 := by
  intro p hp
  have h : env19260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19259_19260 : H12AffineEnvironment.transform 17 23589 env19259 = env19260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env19259 == env19260) = true)

theorem identity19260 : scanCanonicalize (H12AffineFastState.compose env19260 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19260 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env19261 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,81,21510,16448,23589,1024,80,4160,21509,21557,3,41,65,2049,16401,4096,2049,1136,21509,37,21508,5236,22053]

theorem envBound19261 : H12AffineFastState.Bounded env19261 := by
  intro p hp
  have h : env19261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19260_19261 : H12AffineEnvironment.transform 7 37 env19260 = env19261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19260 == env19261) = true)

theorem identity19261 : scanCanonicalize (H12AffineFastState.compose env19261 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound19261 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19262 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5157,81,35,5221,2048,1024,80,4160,32,16,3,41,65,2049,5172,4096,2049,1136,32,37,33,5236,512]

theorem envBound19262 : H12AffineFastState.Bounded env19262 := by
  intro p hp
  have h : env19262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19261_19262 : H12AffineEnvironment.transform 13 5157 env19261 = env19262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env19261 == env19262) = true)

theorem identity19262 : scanCanonicalize (H12AffineFastState.compose env19262 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19262 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19263 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5157,33,35,5141,2048,1024,32,4144,32,16,3,41,49,2049,5172,4096,2049,1024,32,37,33,5124,512]

theorem envBound19263 : H12AffineFastState.Bounded env19263 := by
  intro p hp
  have h : env19263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19262_19263 : H12AffineEnvironment.transform 5 48 env19262 = env19263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19262 == env19263) = true)

def env19264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound19264 : H12AffineFastState.Bounded env19264 := by
  intro p hp
  have h : env19264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19074_19264 : H12AffineEnvironment.transform 18 1025 env19074 = env19264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19074 == env19264) = true)

theorem identity19264 : scanCanonicalize (H12AffineFastState.compose env19264 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10873901) := by decide +kernel

theorem selectedBound19264 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10873901,8328,65,6433836,8677536,10507600,8830977,2385980,12880364,257,272512,313636,2445290]

theorem envBound19265 : H12AffineFastState.Bounded env19265 := by
  intro p hp
  have h : env19265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19264_19265 : H12AffineEnvironment.transform 23 10873901 env19264 = env19265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10873901 env19264 == env19265) = true)

def env19266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433836,8393984,10507600,8568225,2102684,12645452,257,21792,46212,2175562]

theorem envBound19266 : H12AffineFastState.Bounded env19266 := by
  intro p hp
  have h : env19266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19265_19266 : H12AffineEnvironment.transform 17 32160 env19265 = env19266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env19265 == env19266) = true)

def env19267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101328,98781,8328,65,6433836,2098512,17664,2272753,2102684,6349852,257,21792,46212,2175562]

theorem envBound19267 : H12AffineFastState.Bounded env19267 := by
  intro p hp
  have h : env19267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19266_19267 : H12AffineEnvironment.transform 22 2101328 env19266 = env19267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19266 == env19267) = true)

def env19268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,16,98781,8328,65,4340844,5392,17664,179633,1500,4256860,257,21792,46212,74250]

theorem envBound19268 : H12AffineFastState.Bounded env19268 := by
  intro p hp
  have h : env19268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19267_19268 : H12AffineEnvironment.transform 20 4160 env19267 = env19268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19267 == env19268) = true)

theorem identity19268 : scanCanonicalize (H12AffineFastState.compose env19268 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound19268 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21793,16,98781,8328,65,158029,5392,17664,179633,1500,41341,257,21792,46212,74250]

theorem envBound19269 : H12AffineFastState.Bounded env19269 := by
  intro p hp
  have h : env19269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19268_19269 : H12AffineEnvironment.transform 21 21793 env19268 = env19269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env19268 == env19269) = true)

theorem identity19269 : scanCanonicalize (H12AffineFastState.compose env19269 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19269 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32160,1025,32769,4160,21793,16,41430,8328,65,158029,5392,17664,179633,1500,41341,257,21792,46212,513]

theorem envBound19270 : H12AffineFastState.Bounded env19270 := by
  intro p hp
  have h : env19270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19269_19270 : H12AffineEnvironment.transform 15 8203 env19269 = env19270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19269 == env19270) = true)

theorem identity19270 : scanCanonicalize (H12AffineFastState.compose env19270 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound19270 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,32160,1025,32769,4160,21793,16,41430,8328,65,10589,5392,17664,64929,1500,41341,257,21792,46212,513]

theorem envBound19271 : H12AffineFastState.Bounded env19271 := by
  intro p hp
  have h : env19271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19270_19271 : H12AffineEnvironment.transform 16 16400 env19270 = env19271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env19270 == env19271) = true)

theorem identity19271 : scanCanonicalize (H12AffineFastState.compose env19271 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound19271 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env19272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,216,8203,16400,32160,1025,217,4160,21793,16,8462,8328,65,10589,5392,17664,32121,1500,8613,257,21792,13404,513]

theorem envBound19272 : H12AffineFastState.Bounded env19272 := by
  intro p hp
  have h : env19272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19271_19272 : H12AffineEnvironment.transform 14 216 env19271 = env19272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env19271 == env19272) = true)

def env19273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,17,98781,8328,65,4340845,5393,17664,179632,1501,4256861,257,21792,46212,74251]

theorem envBound19273 : H12AffineFastState.Bounded env19273 := by
  intro p hp
  have h : env19273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19267_19273 : H12AffineEnvironment.transform 20 4161 env19267 = env19273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19267 == env19273) = true)

def env19274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98645,8192,65,4340845,5393,17664,179512,1365,4256861,257,21792,46092,74251]

theorem envBound19274 : H12AffineFastState.Bounded env19274 := by
  intro p hp
  have h : env19274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19273_19274 : H12AffineEnvironment.transform 6 8 env19273 = env19274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19273 == env19274) = true)

theorem identity19274 : scanCanonicalize (H12AffineFastState.compose env19274 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19274 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,32040,1025,32769,4161,4194304,17,2,8192,65,4340845,5393,17664,179512,1365,4256861,257,21792,46092,41820]

theorem envBound19275 : H12AffineFastState.Bounded env19275 := by
  intro p hp
  have h : env19275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19274_19275 : H12AffineEnvironment.transform 15 33111 env19274 = env19275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19274 == env19275) = true)

theorem identity19275 : scanCanonicalize (H12AffineFastState.compose env19275 (packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound19275 : packedSelected [0,5,8,9,14,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env19276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16401,32040,1025,32769,4161,4194304,17,2,8192,65,4226172,5393,17664,64809,1365,4256861,257,21792,46092,41820]

theorem envBound19276 : H12AffineFastState.Bounded env19276 := by
  intro p hp
  have h : env19276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19275_19276 : H12AffineEnvironment.transform 16 16401 env19275 = env19276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env19275 == env19276) = true)

theorem identity19276 : scanCanonicalize (H12AffineFastState.compose env19276 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19276 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env19277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,32040,1025,8540,4161,4194304,17,2,8192,65,4226172,5393,17664,23668,1365,4216064,257,21792,5457,513]

theorem envBound19277 : H12AffineFastState.Bounded env19277 := by
  intro p hp
  have h : env19277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19276_19277 : H12AffineEnvironment.transform 14 8541 env19276 = env19277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19276 == env19277) = true)

theorem identity19277 : scanCanonicalize (H12AffineFastState.compose env19277 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound19277 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19278 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,8202,16401,30777,272,8540,4161,4194304,17,2,8192,65,4225389,4096,16401,22885,68,4214801,257,20529,4160,513]

theorem envBound19278 : H12AffineFastState.Bounded env19278 := by
  intro p hp
  have h : env19278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19277_19278 : H12AffineEnvironment.transform 9 273 env19277 = env19278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19277 == env19278) = true)

theorem identity19278 : scanCanonicalize (H12AffineFastState.compose env19278 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound19278 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19279 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8202,4096,10280,272,8540,4161,4194304,17,2,8192,65,4204924,4096,4096,2420,68,4194304,257,32,4160,513]

theorem envBound19279 : H12AffineFastState.Bounded env19279 := by
  intro p hp
  have h : env19279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19278_19279 : H12AffineEnvironment.transform 13 4113 env19278 = env19279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env19278 == env19279) = true)

theorem identity19279 : scanCanonicalize (H12AffineFastState.compose env19279 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound19279 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19280 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8202,4096,10280,272,8540,4161,113,17,2,8192,65,10509,4096,4096,2420,68,113,257,32,4160,513]

theorem envBound19280 : H12AffineFastState.Bounded env19280 := by
  intro p hp
  have h : env19280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19279_19280 : H12AffineEnvironment.transform 21 113 env19279 = env19280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env19279 == env19280) = true)

theorem identity19280 : scanCanonicalize (H12AffineFastState.compose env19280 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound19280 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env19281 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,65,8192,80,8541,8202,65,10280,272,8540,0,113,17,2,8192,65,10509,65,65,2420,68,113,257,32,1,513]

theorem envBound19281 : H12AffineFastState.Bounded env19281 := by
  intro p hp
  have h : env19281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19280_19281 : H12AffineEnvironment.transform 11 65 env19280 = env19281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env19280 == env19281) = true)

theorem identity19281 : scanCanonicalize (H12AffineFastState.compose env19281 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19281 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19282 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,65,8192,80,8313,8202,65,10280,52,8312,0,113,17,2,8192,65,10281,65,65,2128,68,113,37,32,1,513]

theorem envBound19282 : H12AffineFastState.Bounded env19282 := by
  intro p hp
  have h : env19282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19281_19282 : H12AffineEnvironment.transform 7 36 env19281 = env19282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19281 == env19282) = true)

theorem identity19282 : scanCanonicalize (H12AffineFastState.compose env19282 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound19282 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19283 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,65,8192,80,8313,8202,65,8201,52,8312,0,113,17,2,8192,65,8200,65,65,113,68,113,37,32,1,513]

theorem envBound19283 : H12AffineFastState.Bounded env19283 := by
  intro p hp
  have h : env19283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19282_19283 : H12AffineEnvironment.transform 10 33 env19282 = env19283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env19282 == env19283) = true)

theorem identity19283 : scanCanonicalize (H12AffineFastState.compose env19283 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 600) := by decide +kernel

theorem selectedBound19283 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19284 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,65,600,80,545,594,65,593,52,544,0,113,17,2,600,65,592,65,65,113,68,113,37,32,1,513]

theorem envBound19284 : H12AffineFastState.Bounded env19284 := by
  intro p hp
  have h : env19284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19283_19284 : H12AffineEnvironment.transform 12 600 env19283 = env19284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 600 env19283 == env19284) = true)

theorem identity19284 : scanCanonicalize (H12AffineFastState.compose env19284 (packedSelected [1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound19284 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env19285 : List Nat := [2,4,8,16,32,64,8,36,33,53,33,65,121,80,0,115,65,112,52,1,0,113,17,2,121,65,113,65,65,113,68,113,37,32,1,32]

theorem envBound19285 : H12AffineFastState.Bounded env19285 := by
  intro p hp
  have h : env19285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19284_19285 : H12AffineEnvironment.transform 8 33 env19284 = env19285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env19284 == env19285) = true)

theorem identity19285 : scanCanonicalize (H12AffineFastState.compose env19285 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19285 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19286 : List Nat := [2,4,8,16,32,48,8,36,33,53,33,49,9,32,0,3,49,0,52,1,0,1,17,2,9,49,1,49,49,1,52,1,37,32,1,32]

theorem envBound19286 : H12AffineFastState.Bounded env19286 := by
  intro p hp
  have h : env19286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19285_19286 : H12AffineEnvironment.transform 5 48 env19285 = env19286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19285 == env19286) = true)

theorem identity19286 : scanCanonicalize (H12AffineFastState.compose env19286 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19287 : List Nat := [2,4,8,16,1,17,8,5,0,20,0,16,9,1,0,3,16,0,21,1,0,1,17,2,9,16,1,16,16,1,21,1,4,1,1,1]

theorem envBound19287 : H12AffineFastState.Bounded env19287 := by
  intro p hp
  have h : env19287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19286_19287 : H12AffineEnvironment.transform 4 1 env19286 = env19287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19286 == env19287) = true)

def env19288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,4194304,17,98644,8193,65,4340845,5393,17664,179513,1364,4256861,257,21792,46093,74251]

theorem envBound19288 : H12AffineFastState.Bounded env19288 := by
  intro p hp
  have h : env19288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19273_19288 : H12AffineEnvironment.transform 6 9 env19273 = env19288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19273 == env19288) = true)

theorem identity19288 : scanCanonicalize (H12AffineFastState.compose env19288 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19288 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4161,4194304,17,41310,8193,65,4340845,5393,17664,179513,1364,4256861,257,21792,46093,513]

theorem envBound19289 : H12AffineFastState.Bounded env19289 := by
  intro p hp
  have h : env19289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19288_19289 : H12AffineEnvironment.transform 15 8202 env19288 = env19289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19288 == env19289) = true)

theorem identity19289 : scanCanonicalize (H12AffineFastState.compose env19289 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19289 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env19290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4161,4194304,17,21762,8193,65,4340845,5393,17664,149861,1364,4194305,257,21792,16465,513]

theorem envBound19290 : H12AffineFastState.Bounded env19290 := by
  intro p hp
  have h : env19290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19289_19290 : H12AffineEnvironment.transform 14 29788 env19289 = env19290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19289 == env19290) = true)

theorem identity19290 : scanCanonicalize (H12AffineFastState.compose env19290 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound19290 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env19291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4161,21873,17,21762,8193,65,157980,5393,17664,149861,1364,21872,257,21792,16465,513]

theorem envBound19291 : H12AffineFastState.Bounded env19291 := by
  intro p hp
  have h : env19291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19290_19291 : H12AffineEnvironment.transform 21 21873 env19290 = env19291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env19290 == env19291) = true)

theorem identity19291 : scanCanonicalize (H12AffineFastState.compose env19291 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound19291 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env19292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,5393,32041,1025,29789,4161,21873,17,21762,8193,65,31757,5393,17664,23668,1364,21872,257,21792,16465,513]

theorem envBound19292 : H12AffineFastState.Bounded env19292 := by
  intro p hp
  have h : env19292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19291_19292 : H12AffineEnvironment.transform 16 5393 env19291 = env19292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env19291 == env19292) = true)

theorem identity19292 : scanCanonicalize (H12AffineFastState.compose env19292 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19292 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,5393,23669,1025,21761,4161,21873,17,21762,349,65,23889,5393,17664,23668,1364,21872,257,21792,16465,513]

theorem envBound19293 : H12AffineFastState.Bounded env19293 := by
  intro p hp
  have h : env19293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19292_19293 : H12AffineEnvironment.transform 12 348 env19292 = env19293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19292 == env19293) = true)

theorem identity19293 : scanCanonicalize (H12AffineFastState.compose env19293 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19293 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,81,342,5393,2340,1025,80,4161,32,17,83,349,65,2048,5393,4177,2341,1364,33,257,113,5376,513]

theorem envBound19294 : H12AffineFastState.Bounded env19294 := by
  intro p hp
  have h : env19294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19293_19294 : H12AffineEnvironment.transform 13 5457 env19293 = env19294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env19293 == env19294) = true)

theorem identity19294 : scanCanonicalize (H12AffineFastState.compose env19294 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound19294 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env19295 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4112,81,342,4176,2340,320,80,4161,32,17,83,349,65,2048,4176,4177,2341,21,33,257,113,4161,513]

theorem envBound19295 : H12AffineFastState.Bounded env19295 := by
  intro p hp
  have h : env19295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19294_19295 : H12AffineEnvironment.transform 9 321 env19294 = env19295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env19294 == env19295) = true)

theorem identity19295 : scanCanonicalize (H12AffineFastState.compose env19295 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19295 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19296 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,4112,0,263,4097,2340,273,1,4112,32,17,2,268,16,2048,4097,4096,2341,21,33,257,32,4112,513]

theorem envBound19296 : H12AffineFastState.Bounded env19296 := by
  intro p hp
  have h : env19296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19295_19296 : H12AffineEnvironment.transform 5 17 env19295 = env19296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19295 == env19296) = true)

theorem identity19296 : scanCanonicalize (H12AffineFastState.compose env19296 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound19296 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19297 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,16,269,0,0,263,17,2340,273,1,0,32,17,2,268,16,2048,17,16,2341,21,33,257,32,0,513]

theorem envBound19297 : H12AffineFastState.Bounded env19297 := by
  intro p hp
  have h : env19297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19296_19297 : H12AffineEnvironment.transform 11 16 env19296 = env19297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19296 == env19297) = true)

theorem identity19297 : scanCanonicalize (H12AffineFastState.compose env19297 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound19297 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19298 : List Nat := [2,4,8,16,32,17,9,256,512,272,292,16,269,0,0,263,17,0,273,1,0,32,17,2,268,16,292,17,16,1,21,33,257,32,0,513]

theorem envBound19298 : H12AffineFastState.Bounded env19298 := by
  intro p hp
  have h : env19298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19297_19298 : H12AffineEnvironment.transform 10 292 env19297 = env19298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env19297 == env19298) = true)

def env19299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101329,98780,8328,65,6433836,2098513,17665,2272752,2102684,6349853,257,21792,46212,2175562]

theorem envBound19299 : H12AffineFastState.Bounded env19299 := by
  intro p hp
  have h : env19299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19266_19299 : H12AffineEnvironment.transform 22 2101329 env19266 = env19299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19266 == env19299) = true)

def env19300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,17,98780,8328,65,4340844,5393,17665,179632,1500,4256861,257,21792,46212,74250]

theorem envBound19300 : H12AffineFastState.Bounded env19300 := by
  intro p hp
  have h : env19300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19299_19300 : H12AffineEnvironment.transform 20 4160 env19299 = env19300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19299 == env19300) = true)

theorem identity19300 : scanCanonicalize (H12AffineFastState.compose env19300 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19300 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32160,1025,29908,4160,4194304,17,95497,8328,65,4340844,5393,17665,149861,1500,4194440,257,21792,16465,74250]

theorem envBound19301 : H12AffineFastState.Bounded env19301 := by
  intro p hp
  have h : env19301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19300_19301 : H12AffineEnvironment.transform 14 29909 env19300 = env19301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19300 == env19301) = true)

def env19302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10400,1025,8660,4160,4194304,17,73737,8328,65,4340844,5393,4097,138341,1500,4194440,257,32,5457,74250]

theorem envBound19302 : H12AffineFastState.Bounded env19302 := by
  intro p hp
  have h : env19302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19301_19302 : H12AffineEnvironment.transform 13 5376 env19301 = env19302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19301 == env19302) = true)

theorem identity19302 : scanCanonicalize (H12AffineFastState.compose env19302 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19302 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,131072,10400,1025,8660,4160,4194304,17,2,8328,65,4340844,5393,4097,138341,1500,4194440,257,32,5457,513]

theorem envBound19303 : H12AffineFastState.Bounded env19303 := by
  intro p hp
  have h : env19303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19302_19303 : H12AffineEnvironment.transform 15 8203 env19302 = env19303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19302 == env19303) = true)

theorem identity19303 : scanCanonicalize (H12AffineFastState.compose env19303 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19303 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env19304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,5392,10400,1025,8660,4160,4194304,17,2,8328,65,4204924,5393,4097,2421,1500,4194440,257,32,5457,513]

theorem envBound19304 : H12AffineFastState.Bounded env19304 := by
  intro p hp
  have h : env19304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19303_19304 : H12AffineEnvironment.transform 16 5392 env19303 = env19304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19303 == env19304) = true)

theorem identity19304 : scanCanonicalize (H12AffineFastState.compose env19304 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(21+1) ^^^ 15484) := by decide +kernel

theorem selectedBound19304 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,5392,10400,1025,8660,4160,15484,17,2,8328,65,5376,5393,4097,2421,1500,15604,257,32,5457,513]

theorem envBound19305 : H12AffineFastState.Bounded env19305 := by
  intro p hp
  have h : env19305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19304_19305 : H12AffineEnvironment.transform 21 15484 env19304 = env19305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 15484 env19304 == env19305) = true)

theorem identity19305 : scanCanonicalize (H12AffineFastState.compose env19305 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19305 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env19306 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4112,8661,8203,4096,10400,273,8660,4160,14700,17,2,8328,65,4112,4097,4097,2421,204,14820,257,32,4161,513]

theorem envBound19306 : H12AffineFastState.Bounded env19306 := by
  intro p hp
  have h : env19306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19305_19306 : H12AffineEnvironment.transform 9 272 env19305 = env19306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19305 == env19306) = true)

theorem identity19306 : scanCanonicalize (H12AffineFastState.compose env19306 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound19306 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env19307 : List Nat := [2,4,8,16,32,64,128,100,512,116,2048,4096,8192,4112,8369,8203,4096,10400,117,8368,4160,14344,17,2,8328,65,4112,4097,4097,2065,204,14464,101,32,4161,513]

theorem envBound19307 : H12AffineFastState.Bounded env19307 := by
  intro p hp
  have h : env19307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19306_19307 : H12AffineEnvironment.transform 7 100 env19306 = env19307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env19306 == env19307) = true)

theorem identity19307 : scanCanonicalize (H12AffineFastState.compose env19307 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 6304) := by decide +kernel

theorem selectedBound19307 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env19308 : List Nat := [2,4,8,16,32,64,128,100,512,116,2048,4096,6304,4112,6161,6315,4096,4096,117,6160,4160,168,17,2,6184,65,4112,4097,4097,2065,204,32,101,32,4161,513]

theorem envBound19308 : H12AffineFastState.Bounded env19308 := by
  intro p hp
  have h : env19308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19307_19308 : H12AffineEnvironment.transform 12 6304 env19307 = env19308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6304 env19307 == env19308) = true)

def env19309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1025,8661,4160,4194304,17,73736,8328,65,4340844,5393,4096,138340,1500,4194440,257,33,5456,74250]

theorem envBound19309 : H12AffineFastState.Bounded env19309 := by
  intro p hp
  have h : env19309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19301_19309 : H12AffineEnvironment.transform 13 5377 env19301 = env19309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19301 == env19309) = true)

theorem identity19309 : scanCanonicalize (H12AffineFastState.compose env19309 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound19309 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,131072,10401,1025,8661,4160,4194304,17,138,8328,65,4340844,5393,4096,138340,1500,4194440,257,33,5456,648]

theorem envBound19310 : H12AffineFastState.Bounded env19310 := by
  intro p hp
  have h : env19310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19309_19310 : H12AffineEnvironment.transform 15 8322 env19309 = env19310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env19309 == env19310) = true)

theorem identity19310 : scanCanonicalize (H12AffineFastState.compose env19310 (packedSelected [0,2,4,6,9,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound19310 : packedSelected [0,2,4,6,9,16,27] rootPS < 2^1333 := by decide +kernel

def env19311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,5529,10401,1025,8661,4160,4194304,17,138,8328,65,4205045,5393,4096,2557,1500,4194440,257,33,5456,648]

theorem envBound19311 : H12AffineFastState.Bounded env19311 := by
  intro p hp
  have h : env19311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19310_19311 : H12AffineEnvironment.transform 16 5529 env19310 = env19311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env19310 == env19311) = true)

theorem identity19311 : scanCanonicalize (H12AffineFastState.compose env19311 (packedSelected [0,7,9,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19311 : packedSelected [0,7,9,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env19312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5529,2556,1025,136,4160,4194304,17,138,469,65,4196520,5393,4096,2557,1500,4194440,257,33,5456,648]

theorem envBound19312 : H12AffineFastState.Bounded env19312 := by
  intro p hp
  have h : env19312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19311_19312 : H12AffineEnvironment.transform 12 349 env19311 = env19312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19311 == env19312) = true)

theorem identity19312 : scanCanonicalize (H12AffineFastState.compose env19312 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19312 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env19313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5529,2556,1025,136,4160,32,17,138,469,65,2184,5393,4096,2557,1500,168,257,33,5456,648]

theorem envBound19313 : H12AffineFastState.Bounded env19313 := by
  intro p hp
  have h : env19313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19312_19313 : H12AffineEnvironment.transform 21 32 env19312 = env19313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19312 == env19313) = true)

theorem identity19313 : scanCanonicalize (H12AffineFastState.compose env19313 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19313 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19314 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,40,5236,137,170,5356,2185,1025,136,4160,32,17,138,160,65,2184,5220,4096,2184,1193,168,116,33,5157,648]

theorem envBound19314 : H12AffineFastState.Bounded env19314 := by
  intro p hp
  have h : env19314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19313_19314 : H12AffineEnvironment.transform 7 117 env19313 = env19314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19313 == env19314) = true)

theorem identity19314 : scanCanonicalize (H12AffineFastState.compose env19314 (packedSelected [0,3,5,6,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound19314 : packedSelected [0,3,5,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19315 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1125,4096,40,5236,137,170,5356,1260,1025,136,4160,32,17,138,160,65,1261,5220,4096,1261,1193,168,116,33,5157,648]

theorem envBound19315 : H12AffineFastState.Bounded env19315 := by
  intro p hp
  have h : env19315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19314_19315 : H12AffineEnvironment.transform 10 1125 env19314 = env19315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env19314 == env19315) = true)

theorem identity19315 : scanCanonicalize (H12AffineFastState.compose env19315 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19315 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19316 : List Nat := [2,4,8,16,32,64,128,117,512,100,1,4096,40,4112,137,170,4232,136,101,136,4160,32,17,138,160,65,137,4096,4096,137,205,168,116,33,4161,648]

theorem envBound19316 : H12AffineFastState.Bounded env19316 := by
  intro p hp
  have h : env19316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19315_19316 : H12AffineEnvironment.transform 9 100 env19315 = env19316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19315 == env19316) = true)

def env19317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,16,98780,8328,65,4340845,5392,17665,179633,1501,4256860,257,21792,46212,74251]

theorem envBound19317 : H12AffineFastState.Bounded env19317 := by
  intro p hp
  have h : env19317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19299_19317 : H12AffineEnvironment.transform 20 4161 env19299 = env19317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19299 == env19317) = true)

theorem identity19317 : scanCanonicalize (H12AffineFastState.compose env19317 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41460) := by decide +kernel

theorem selectedBound19317 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,41460,16,98780,8328,65,171417,5392,17665,179633,1501,21928,257,21792,46212,74251]

theorem envBound19318 : H12AffineFastState.Bounded env19318 := by
  intro p hp
  have h : env19318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19317_19318 : H12AffineEnvironment.transform 21 41460 env19317 = env19318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41460 env19317 == env19318) = true)

def env19319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,41340,16,98644,8192,65,171281,5392,17665,179513,1365,21792,257,21792,46092,74251]

theorem envBound19319 : H12AffineFastState.Bounded env19319 := by
  intro p hp
  have h : env19319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19318_19319 : H12AffineEnvironment.transform 6 8 env19318 = env19319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19318 == env19319) = true)

theorem identity19319 : scanCanonicalize (H12AffineFastState.compose env19319 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19319 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,4161,41340,16,21762,8192,65,171281,5392,17665,179513,1365,21792,257,21792,46092,63069]

theorem envBound19320 : H12AffineFastState.Bounded env19320 := by
  intro p hp
  have h : env19320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19319_19320 : H12AffineEnvironment.transform 15 54358 env19319 = env19320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19319 == env19320) = true)

theorem identity19320 : scanCanonicalize (H12AffineFastState.compose env19320 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound19320 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5221,32040,1025,32769,4161,41340,16,21762,8192,65,35188,5392,17665,43356,1365,21792,257,21792,46092,63069]

theorem envBound19321 : H12AffineFastState.Bounded env19321 := by
  intro p hp
  have h : env19321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19320_19321 : H12AffineEnvironment.transform 16 5221 env19320 = env19321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env19320 == env19321) = true)

theorem identity19321 : scanCanonicalize (H12AffineFastState.compose env19321 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound19321 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,29822,5221,32040,1025,8233,4161,340,16,21762,8192,65,10588,5392,17665,2420,1365,21792,257,21792,5156,22133]

theorem envBound19322 : H12AffineFastState.Bounded env19322 := by
  intro p hp
  have h : env19322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19321_19322 : H12AffineEnvironment.transform 14 8232 env19321 = env19322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env19321 == env19322) = true)

theorem identity19322 : scanCanonicalize (H12AffineFastState.compose env19322 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19322 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19323 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,29822,5221,31837,1025,8233,4161,33,16,21623,8192,65,10281,5221,17524,2049,1056,21589,116,21589,5156,22133]

theorem envBound19323 : H12AffineFastState.Bounded env19323 := by
  intro p hp
  have h : env19323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19322_19323 : H12AffineEnvironment.transform 7 117 env19322 = env19323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19322 == env19323) = true)

theorem identity19323 : scanCanonicalize (H12AffineFastState.compose env19323 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound19323 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19324 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,120,16384,80,21510,5221,23589,1025,81,4161,33,16,21623,120,65,2129,5221,17524,2049,1056,21589,116,21589,5156,22133]

theorem envBound19324 : H12AffineFastState.Bounded env19324 := by
  intro p hp
  have h : env19324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19323_19324 : H12AffineEnvironment.transform 12 120 env19323 = env19324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env19323 == env19324) = true)

theorem identity19324 : scanCanonicalize (H12AffineFastState.compose env19324 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19324 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19325 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,1,21510,5172,23589,1025,0,4112,33,16,21542,41,16,2048,5172,17445,2049,1056,21508,37,21508,5156,22052]

theorem envBound19325 : H12AffineFastState.Bounded env19325 := by
  intro p hp
  have h : env19325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19324_19325 : H12AffineEnvironment.transform 5 17 env19324 = env19325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19324 == env19325) = true)

theorem identity19325 : scanCanonicalize (H12AffineFastState.compose env19325 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound19325 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19326 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,2065,41,16384,1,19479,3109,17460,1025,0,2049,33,16,19511,41,16,2048,3109,17445,2049,1056,19477,37,19477,3125,20021]

theorem envBound19326 : H12AffineFastState.Bounded env19326 := by
  intro p hp
  have h : env19326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19325_19326 : H12AffineEnvironment.transform 11 2065 env19325 = env19326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env19325 == env19326) = true)

theorem identity19326 : scanCanonicalize (H12AffineFastState.compose env19326 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19326 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env19327 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1,16,41,16384,1,17430,1060,17460,1025,0,0,33,16,17462,41,16,1,1060,17445,0,1056,17428,37,17428,1076,17972]

theorem envBound19327 : H12AffineFastState.Bounded env19327 := by
  intro p hp
  have h : env19327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19326_19327 : H12AffineEnvironment.transform 10 1 env19326 = env19327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19326 == env19327) = true)

theorem identity19327 : scanCanonicalize (H12AffineFastState.compose env19327 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 1060) := by decide +kernel

theorem selectedBound19327 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env19328 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1,16,41,1060,1,50,1060,16,1025,0,0,33,16,18,41,16,1,1060,1,0,1056,48,37,48,1076,528]

theorem envBound19328 : H12AffineFastState.Bounded env19328 := by
  intro p hp
  have h : env19328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19327_19328 : H12AffineEnvironment.transform 13 1060 env19327 = env19328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1060 env19327 == env19328) = true)

theorem identity19328 : scanCanonicalize (H12AffineFastState.compose env19328 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19328 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19329 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1,1,41,1060,1,35,1060,1,1025,0,0,33,1,3,41,1,1,1060,1,0,1056,33,37,33,1061,513]

theorem envBound19329 : H12AffineFastState.Bounded env19329 := by
  intro p hp
  have h : env19329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19328_19329 : H12AffineEnvironment.transform 3 1 env19328 = env19329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19328 == env19329) = true)

def env19330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,41341,16,98645,8193,65,171280,5392,17665,179512,1364,21793,257,21792,46093,74251]

theorem envBound19330 : H12AffineFastState.Bounded env19330 := by
  intro p hp
  have h : env19330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19318_19330 : H12AffineEnvironment.transform 6 9 env19318 = env19330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19318 == env19330) = true)

theorem identity19330 : scanCanonicalize (H12AffineFastState.compose env19330 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound19330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32041,1025,32769,4161,41341,16,62558,8193,65,171280,5392,17665,179512,1364,21793,257,21792,46093,22272]

theorem envBound19331 : H12AffineFastState.Bounded env19331 := by
  intro p hp
  have h : env19331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19330_19331 : H12AffineEnvironment.transform 15 29963 env19330 = env19331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env19330 == env19331) = true)

theorem identity19331 : scanCanonicalize (H12AffineFastState.compose env19331 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound19331 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,262,131072,2340,1025,32769,4161,41341,16,32851,8193,65,171280,5392,12556,179512,1364,8492,257,8493,46093,8973]

theorem envBound19332 : H12AffineFastState.Bounded env19332 := by
  intro p hp
  have h : env19332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19331_19332 : H12AffineEnvironment.transform 13 13325 env19331 = env19332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env19331 == env19332) = true)

def env19333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433836,8393985,10507600,8568224,2102685,12645453,257,21793,46213,2175563]

theorem envBound19333 : H12AffineFastState.Bounded env19333 := by
  intro p hp
  have h : env19333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19265_19333 : H12AffineEnvironment.transform 17 32161 env19265 = env19333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env19265 == env19333) = true)

def env19334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101328,98780,8328,65,6433836,2098513,17664,2272752,2102685,6349853,257,21793,46213,2175563]

theorem envBound19334 : H12AffineFastState.Bounded env19334 := by
  intro p hp
  have h : env19334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19333_19334 : H12AffineEnvironment.transform 22 2101328 env19333 = env19334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env19333 == env19334) = true)

def env19335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,16,98780,8328,65,4340844,5393,17664,179632,1501,4256861,257,21793,46213,74251]

theorem envBound19335 : H12AffineFastState.Bounded env19335 := by
  intro p hp
  have h : env19335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19334_19335 : H12AffineEnvironment.transform 20 4160 env19334 = env19335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19334 == env19335) = true)

theorem identity19335 : scanCanonicalize (H12AffineFastState.compose env19335 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98814) := by decide +kernel

theorem selectedBound19335 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,98814,16,98780,8328,65,245138,5393,17664,179632,1501,95651,257,21793,46213,74251]

theorem envBound19336 : H12AffineFastState.Bounded env19336 := by
  intro p hp
  have h : env19336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19335_19336 : H12AffineEnvironment.transform 21 98814 env19335 = env19336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98814 env19335 == env19336) = true)

def env19337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,98678,16,98644,8192,65,245018,5393,17664,179512,1365,95531,257,21793,46093,74251]

theorem envBound19337 : H12AffineFastState.Bounded env19337 := by
  intro p hp
  have h : env19337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19336_19337 : H12AffineEnvironment.transform 6 8 env19336 = env19337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19336 == env19337) = true)

theorem identity19337 : scanCanonicalize (H12AffineFastState.compose env19337 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound19337 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4160,21793,16,21763,8192,65,158029,5393,17664,179512,1365,41340,257,21793,46093,63068]

theorem envBound19338 : H12AffineFastState.Bounded env19338 := by
  intro p hp
  have h : env19338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19337_19338 : H12AffineEnvironment.transform 15 54359 env19337 = env19338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env19337 == env19338) = true)

theorem identity19338 : scanCanonicalize (H12AffineFastState.compose env19338 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound19338 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46156,32041,1025,32769,4160,21793,16,21763,8192,65,56577,5393,17664,2420,1365,41340,257,21793,46093,63068]

theorem envBound19339 : H12AffineFastState.Bounded env19339 := by
  intro p hp
  have h : env19339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19338_19339 : H12AffineEnvironment.transform 16 46156 env19338 = env19339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env19338 == env19339) = true)

theorem identity19339 : scanCanonicalize (H12AffineFastState.compose env19339 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19339 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,16401,32041,1025,29788,4160,21793,16,21763,8192,65,10588,5393,17664,2420,1365,21793,257,21793,16464,513]

theorem envBound19340 : H12AffineFastState.Bounded env19340 := by
  intro p hp
  have h : env19340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19339_19340 : H12AffineEnvironment.transform 14 29789 env19339 = env19340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19339 == env19340) = true)

theorem identity19340 : scanCanonicalize (H12AffineFastState.compose env19340 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound19340 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,1296,8202,12636,3172,1025,1297,4160,9324,16,9294,8192,65,10588,5393,13389,2420,1365,9324,257,9324,12573,513]

theorem envBound19341 : H12AffineFastState.Bounded env19341 := by
  intro p hp
  have h : env19341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19340_19341 : H12AffineEnvironment.transform 13 12621 env19340 = env19341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env19340 == env19341) = true)

theorem identity19341 : scanCanonicalize (H12AffineFastState.compose env19341 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound19341 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env19342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,1296,1094,5392,3172,1025,1297,4160,32,16,2,1100,65,3344,5393,4097,2420,1365,32,257,32,5457,513]

theorem envBound19342 : H12AffineFastState.Bounded env19342 := by
  intro p hp
  have h : env19342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19341_19342 : H12AffineEnvironment.transform 12 1100 env19341 = env19342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env19341 == env19342) = true)

theorem identity19342 : scanCanonicalize (H12AffineFastState.compose env19342 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1809) := by decide +kernel

theorem selectedBound19342 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1809,1100,528,1296,1094,513,3172,1025,1297,1873,32,16,2,1100,65,3344,512,1808,2420,1365,32,257,32,576,513]

theorem envBound19343 : H12AffineFastState.Bounded env19343 := by
  intro p hp
  have h : env19343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19342_19343 : H12AffineEnvironment.transform 11 1809 env19342 = env19343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1809 env19342 == env19343) = true)

def env19344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98679,16,98645,8193,65,245019,5393,17664,179513,1364,95530,257,21793,46092,74251]

theorem envBound19344 : H12AffineFastState.Bounded env19344 := by
  intro p hp
  have h : env19344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19336_19344 : H12AffineEnvironment.transform 6 9 env19336 = env19344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19336 == env19344) = true)

theorem identity19344 : scanCanonicalize (H12AffineFastState.compose env19344 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound19344 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,32040,1025,32769,4160,62589,16,62559,8193,65,182289,5393,17664,179513,1364,32,257,21793,46092,22273]

theorem envBound19345 : H12AffineFastState.Bounded env19345 := by
  intro p hp
  have h : env19345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19344_19345 : H12AffineEnvironment.transform 15 29962 env19344 = env19345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env19344 == env19345) = true)

theorem identity19345 : scanCanonicalize (H12AffineFastState.compose env19345 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound19345 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,13388,32040,1025,32769,4160,62589,16,62559,8193,65,64605,5393,17664,35189,1364,32,257,21793,46092,22273]

theorem envBound19346 : H12AffineFastState.Bounded env19346 := by
  intro p hp
  have h : env19346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19345_19346 : H12AffineEnvironment.transform 16 13388 env19345 = env19346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env19345 == env19346) = true)

theorem identity19346 : scanCanonicalize (H12AffineFastState.compose env19346 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19346 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env19347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8283,13388,10361,1025,32769,4160,41260,16,41230,8193,65,43276,5393,4177,35189,1364,32,257,112,46092,592]

theorem envBound19347 : H12AffineFastState.Bounded env19347 := by
  intro p hp
  have h : env19347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19346_19347 : H12AffineEnvironment.transform 13 5457 env19346 = env19347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env19346 == env19347) = true)

theorem identity19347 : scanCanonicalize (H12AffineFastState.compose env19347 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19347 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32768,8203,13340,10281,1025,32769,4112,41260,16,41230,8193,17,43276,5393,4097,35109,1284,32,257,32,46092,512]

theorem envBound19348 : H12AffineFastState.Bounded env19348 := by
  intro p hp
  have h : env19348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19347_19348 : H12AffineEnvironment.transform 5 16 env19347 = env19348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19347 == env19348) = true)

theorem identity19348 : scanCanonicalize (H12AffineFastState.compose env19348 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound19348 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19349 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,32,8203,13340,10281,1025,33,4112,8460,16,8494,8193,17,10540,5393,4097,2309,1284,32,257,32,13356,512]

theorem envBound19349 : H12AffineFastState.Bounded env19349 := by
  intro p hp
  have h : env19349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19348_19349 : H12AffineEnvironment.transform 14 32 env19348 = env19349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env19348 == env19349) = true)

theorem identity19349 : scanCanonicalize (H12AffineFastState.compose env19349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound19349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19350 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1052,5377,32,1047,4096,3125,1025,33,4112,1296,16,1330,1053,17,3376,5393,4097,2309,1284,32,257,32,4144,512]

theorem envBound19350 : H12AffineFastState.Bounded env19350 := by
  intro p hp
  have h : env19350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19349_19350 : H12AffineEnvironment.transform 12 1052 env19349 = env19350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env19349 == env19350) = true)

theorem identity19350 : scanCanonicalize (H12AffineFastState.compose env19350 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3361) := by decide +kernel

theorem selectedBound19350 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env19351 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3361,1052,2080,32,1047,3361,3125,1025,33,3377,1296,16,1330,1053,17,3376,2096,3360,2309,1284,32,257,32,3345,512]

theorem envBound19351 : H12AffineFastState.Bounded env19351 := by
  intro p hp
  have h : env19351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19350_19351 : H12AffineEnvironment.transform 11 3361 env19350 = env19351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3361 env19350 == env19351) = true)

theorem identity19351 : scanCanonicalize (H12AffineFastState.compose env19351 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound19351 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19352 : List Nat := [2,4,8,16,32,16,9,256,512,21,2048,2356,9,2080,32,2,2356,2080,20,33,2340,261,16,295,8,17,2341,2096,2357,2309,273,32,257,32,2308,512]

theorem envBound19352 : H12AffineFastState.Bounded env19352 := by
  intro p hp
  have h : env19352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19351_19352 : H12AffineEnvironment.transform 9 21 env19351 = env19352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19351 == env19352) = true)

theorem identity19352 : scanCanonicalize (H12AffineFastState.compose env19352 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19352 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19353 : List Nat := [2,4,8,16,32,16,9,256,512,21,0,308,9,32,32,2,308,32,20,33,292,261,16,295,8,17,293,48,309,261,273,32,257,32,260,512]

theorem envBound19353 : H12AffineFastState.Bounded env19353 := by
  intro p hp
  have h : env19353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19352_19353 : H12AffineEnvironment.transform 10 0 env19352 = env19353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19352 == env19353) = true)

theorem identity19353 : scanCanonicalize (H12AffineFastState.compose env19353 (packedSelected [0,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19353 : packedSelected [0,7,14] rootPS < 2^1333 := by decide +kernel

def env19354 : List Nat := [2,4,8,16,32,16,9,4,512,21,0,48,9,32,32,2,48,32,20,33,32,1,16,35,8,17,33,48,49,1,21,32,5,32,0,512]

theorem envBound19354 : H12AffineFastState.Bounded env19354 := by
  intro p hp
  have h : env19354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19353_19354 : H12AffineEnvironment.transform 7 4 env19353 = env19354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19353 == env19354) = true)

theorem identity19354 : scanCanonicalize (H12AffineFastState.compose env19354 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound19354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19355 : List Nat := [2,0,8,16,32,16,9,0,512,17,0,48,9,32,32,2,48,32,16,33,32,1,16,35,8,17,33,48,49,1,17,32,1,32,0,512]

theorem envBound19355 : H12AffineFastState.Bounded env19355 := by
  intro p hp
  have h : env19355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19354_19355 : H12AffineEnvironment.transform 1 0 env19354 = env19355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env19354 == env19355) = true)

theorem identity19355 : scanCanonicalize (H12AffineFastState.compose env19355 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19356 : List Nat := [2,0,8,16,17,16,9,0,512,17,0,1,9,17,17,2,1,17,16,16,17,1,16,18,8,17,16,1,0,1,17,17,1,17,0,512]

theorem envBound19356 : H12AffineFastState.Bounded env19356 := by
  intro p hp
  have h : env19356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19355_19356 : H12AffineEnvironment.transform 4 17 env19355 = env19356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19355 == env19356) = true)

theorem identity19356 : scanCanonicalize (H12AffineFastState.compose env19356 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19356 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19357 : List Nat := [2,0,8,10,11,10,9,0,512,11,0,1,9,11,11,2,1,11,10,10,11,1,10,8,8,11,10,1,0,1,11,11,1,11,0,512]

theorem envBound19357 : H12AffineFastState.Bounded env19357 := by
  intro p hp
  have h : env19357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19356_19357 : H12AffineEnvironment.transform 3 10 env19356 = env19357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19356 == env19357) = true)

theorem identity19357 : scanCanonicalize (H12AffineFastState.compose env19357 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound19357 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env19358 : List Nat := [2,0,1,3,2,3,0,0,512,2,0,1,0,2,2,2,1,2,3,3,2,1,3,1,1,2,3,1,0,1,2,2,1,2,0,512]

theorem envBound19358 : H12AffineFastState.Bounded env19358 := by
  intro p hp
  have h : env19358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19357_19358 : H12AffineEnvironment.transform 2 1 env19357 = env19358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env19357 == env19358) = true)

theorem identity19358 : scanCanonicalize (H12AffineFastState.compose env19358 (packedSelected [1,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound19358 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19359 : List Nat := [0,0,1,1,0,1,0,0,512,0,0,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,1,1,0,1,0,0,1,0,0,512]

theorem envBound19359 : H12AffineFastState.Bounded env19359 := by
  intro p hp
  have h : env19359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19358_19359 : H12AffineEnvironment.transform 0 0 env19358 = env19359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env19358 == env19359) = true)

def env19360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,17,98780,8328,65,4340845,5392,17664,179633,1500,4256860,257,21793,46213,74250]

theorem envBound19360 : H12AffineFastState.Bounded env19360 := by
  intro p hp
  have h : env19360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19334_19360 : H12AffineEnvironment.transform 20 4161 env19334 = env19360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19334 == env19360) = true)

theorem identity19360 : scanCanonicalize (H12AffineFastState.compose env19360 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound19360 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32161,1025,32769,4161,4194304,17,21763,8328,65,4340845,5392,17664,179633,1500,4256860,257,21793,46213,63189]

theorem envBound19361 : H12AffineFastState.Bounded env19361 := by
  intro p hp
  have h : env19361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19360_19361 : H12AffineEnvironment.transform 15 54495 env19360 = env19361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env19360 == env19361) = true)

def env19362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4161,4194304,17,21763,8192,65,4340845,5392,17664,179513,1364,4256860,257,21793,46093,63069]

theorem envBound19362 : H12AffineFastState.Bounded env19362 := by
  intro p hp
  have h : env19362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19361_19362 : H12AffineEnvironment.transform 6 8 env19361 = env19362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19361 == env19362) = true)

theorem identity19362 : scanCanonicalize (H12AffineFastState.compose env19362 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19362 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1025,32769,4161,4194304,17,2,8192,65,4340845,5392,4097,179513,1364,4235613,257,32,46093,41820]

theorem envBound19363 : H12AffineFastState.Bounded env19363 := by
  intro p hp
  have h : env19363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19362_19363 : H12AffineEnvironment.transform 13 5377 env19362 = env19363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19362 == env19363) = true)

theorem identity19363 : scanCanonicalize (H12AffineFastState.compose env19363 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound19363 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1025,32769,4161,41260,17,2,8192,65,171329,5392,4097,179513,1364,113,257,32,46093,41820]

theorem envBound19364 : H12AffineFastState.Bounded env19364 := by
  intro p hp
  have h : env19364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19363_19364 : H12AffineEnvironment.transform 21 41260 env19363 = env19364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env19363 == env19364) = true)

theorem identity19364 : scanCanonicalize (H12AffineFastState.compose env19364 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 38208) := by decide +kernel

theorem selectedBound19364 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env19365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38208,10280,1025,32769,4161,41260,17,2,8192,65,2049,5392,4097,10361,1364,113,257,32,46093,41820]

theorem envBound19365 : H12AffineFastState.Bounded env19365 := by
  intro p hp
  have h : env19365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19364_19365 : H12AffineEnvironment.transform 16 38208 env19364 = env19365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38208 env19364 == env19365) = true)

theorem identity19365 : scanCanonicalize (H12AffineFastState.compose env19365 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19365 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env19366 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33030,38160,10280,1025,32769,4113,41260,17,2,8192,17,2049,5392,4097,10281,1284,33,257,32,46093,41740]

theorem envBound19366 : H12AffineFastState.Bounded env19366 := by
  intro p hp
  have h : env19366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19365_19366 : H12AffineEnvironment.transform 5 16 env19365 = env19366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19365 == env19366) = true)

theorem identity19366 : scanCanonicalize (H12AffineFastState.compose env19366 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound19366 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19367 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,1,263,5393,10280,1025,0,4113,8493,17,2,8192,17,2049,5392,4097,10281,1284,33,257,32,13324,8973]

theorem envBound19367 : H12AffineFastState.Bounded env19367 := by
  intro p hp
  have h : env19367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19366_19367 : H12AffineEnvironment.transform 14 1 env19366 = env19367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19366 == env19367) = true)

theorem identity19367 : scanCanonicalize (H12AffineFastState.compose env19367 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19367 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env19368 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,1,35,5173,10280,1025,0,4113,8201,17,2,8192,17,2049,5172,4097,10281,1056,33,37,32,13324,8745]

theorem envBound19368 : H12AffineFastState.Bounded env19368 := by
  intro p hp
  have h : env19368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19367_19368 : H12AffineEnvironment.transform 7 36 env19367 = env19368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19367 == env19368) = true)

theorem identity19368 : scanCanonicalize (H12AffineFastState.compose env19368 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19368 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env19369 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4113,32,17,2,41,17,2049,5172,4097,2048,1056,33,37,32,5157,512]

theorem envBound19369 : H12AffineFastState.Bounded env19369 := by
  intro p hp
  have h : env19369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19368_19369 : H12AffineEnvironment.transform 12 41 env19368 = env19369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19368 == env19369) = true)

theorem identity19369 : scanCanonicalize (H12AffineFastState.compose env19369 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19370 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5125,1,3,5141,2049,1025,0,4113,0,17,2,9,17,2049,5140,4097,2048,1024,1,5,0,5125,512]

theorem envBound19370 : H12AffineFastState.Bounded env19370 := by
  intro p hp
  have h : env19370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19369_19370 : H12AffineEnvironment.transform 4 0 env19369 = env19370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19369 == env19370) = true)

def env19371 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1045,1,3,1029,2049,1025,0,1,0,17,2,9,17,2049,1028,17,2048,1024,1,5,0,1045,512]

theorem envBound19371 : H12AffineFastState.Bounded env19371 := by
  intro p hp
  have h : env19371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19370_19371 : H12AffineEnvironment.transform 11 16 env19370 = env19371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env19370 == env19371) = true)

theorem identity19371 : scanCanonicalize (H12AffineFastState.compose env19371 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19372 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,16,9,1045,1,3,1029,1,1025,0,1,0,17,2,9,17,1,1028,17,0,1024,1,5,0,1045,512]

theorem envBound19372 : H12AffineFastState.Bounded env19372 := by
  intro p hp
  have h : env19372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19371_19372 : H12AffineEnvironment.transform 10 0 env19371 = env19372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19371 == env19372) = true)

def env19373 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,1,1,3,17,1,21,0,1,0,17,2,9,17,1,16,17,0,20,1,5,0,1,512]

theorem envBound19373 : H12AffineFastState.Bounded env19373 := by
  intro p hp
  have h : env19373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19372_19373 : H12AffineEnvironment.transform 9 20 env19372 = env19373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19372 == env19373) = true)

theorem identity19373 : scanCanonicalize (H12AffineFastState.compose env19373 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound19373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19374 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,9,1,1,3,17,1,21,0,1,0,17,2,9,17,1,16,17,0,20,1,5,0,1,31]

theorem envBound19374 : H12AffineFastState.Bounded env19374 := by
  intro p hp
  have h : env19374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19373_19374 : H12AffineEnvironment.transform 8 31 env19373 = env19374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env19373 == env19374) = true)

def leafEnv19374 : List Nat := [2,4,8,16,0,16,8,4,31,20,0,16,9,1,1,3,17,1,21,0,1,0,17,2,21,9,1,17,1,16,17,0,20,1,5,0,5,3,1,31,1,1,0]

def active19374 : List Nat := [0,1,2,3]

def tree19374 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19374 : H12WitnessSearch.Good tree19374 := H12GlobalWitnessIndex.good

theorem leafIdentity19374 : H12AffineFastState.composeSystem env19374 rootObs = leafEnv19374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19374 rootObs == leafEnv19374) = true)

theorem terminalChecked19374 : H12PackedTerminal.terminalCheckFast leafEnv19374 active19374 tree19374 = true := by decide +kernel

def env19375 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,0,1,3,16,1,20,0,1,0,17,2,9,17,1,17,17,0,21,1,5,0,0,512]

theorem envBound19375 : H12AffineFastState.Bounded env19375 := by
  intro p hp
  have h : env19375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19372_19375 : H12AffineEnvironment.transform 9 21 env19372 = env19375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19372 == env19375) = true)

theorem identity19375 : scanCanonicalize (H12AffineFastState.compose env19375 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound19375 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19376 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,1,3,5,1,1,0,1,0,4,2,9,4,1,4,4,0,0,1,5,0,0,512]

theorem envBound19376 : H12AffineFastState.Bounded env19376 := by
  intro p hp
  have h : env19376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19375_19376 : H12AffineEnvironment.transform 3 5 env19375 = env19376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env19375 == env19376) = true)

def leafEnv19376 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,5,9,0,1,3,5,1,1,0,1,0,4,2,1,9,1,4,1,4,4,0,0,1,5,0,5,3,0,512,1,1,0]

def active19376 : List Nat := [0,1,2,8]

def tree19376 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19376 : H12WitnessSearch.Good tree19376 := H12GlobalWitnessIndex.good

theorem leafIdentity19376 : H12AffineFastState.composeSystem env19376 rootObs = leafEnv19376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19376 rootObs == leafEnv19376) = true)

theorem terminalChecked19376 : H12PackedTerminal.terminalCheckFast leafEnv19376 active19376 tree19376 = true := by decide +kernel

def env19377 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1044,1,3,1028,2049,1025,0,0,0,17,2,9,17,2049,1029,16,2048,1024,1,5,0,1044,512]

theorem envBound19377 : H12AffineFastState.Bounded env19377 := by
  intro p hp
  have h : env19377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19370_19377 : H12AffineEnvironment.transform 11 17 env19370 = env19377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19370 == env19377) = true)

theorem identity19377 : scanCanonicalize (H12AffineFastState.compose env19377 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound19377 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19378 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,17,9,1044,1,3,1028,1044,1025,0,0,0,17,2,9,17,1044,1029,16,1045,1024,1,5,0,1044,512]

theorem envBound19378 : H12AffineFastState.Bounded env19378 := by
  intro p hp
  have h : env19378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19377_19378 : H12AffineEnvironment.transform 10 1045 env19377 = env19378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env19377 == env19378) = true)

def env19379 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,9,0,1,3,16,0,21,0,0,0,17,2,9,17,0,17,16,1,20,1,5,0,0,512]

theorem envBound19379 : H12AffineFastState.Bounded env19379 := by
  intro p hp
  have h : env19379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19378_19379 : H12AffineEnvironment.transform 9 20 env19378 = env19379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env19378 == env19379) = true)

theorem identity19379 : scanCanonicalize (H12AffineFastState.compose env19379 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound19379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19380 : List Nat := [2,4,8,16,0,16,8,4,30,20,1,17,9,0,1,3,16,0,21,0,0,0,17,2,9,17,0,17,16,1,20,1,5,0,0,30]

theorem envBound19380 : H12AffineFastState.Bounded env19380 := by
  intro p hp
  have h : env19380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19379_19380 : H12AffineEnvironment.transform 8 30 env19379 = env19380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env19379 == env19380) = true)

def leafEnv19380 : List Nat := [2,4,8,16,0,16,8,4,30,20,1,17,9,0,1,3,16,0,21,0,0,0,17,2,21,9,1,17,0,17,16,1,20,1,5,0,5,3,0,30,1,0,0]

def active19380 : List Nat := [0,1,2,3]

def tree19380 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19380 : H12WitnessSearch.Good tree19380 := H12GlobalWitnessIndex.good

theorem leafIdentity19380 : H12AffineFastState.composeSystem env19380 rootObs = leafEnv19380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19380 rootObs == leafEnv19380) = true)

theorem terminalChecked19380 : H12PackedTerminal.terminalCheckFast leafEnv19380 active19380 tree19380 = true := by decide +kernel

def env19381 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,1,1,3,17,1,20,0,0,0,17,2,9,17,1,16,16,0,21,1,5,0,1,512]

theorem envBound19381 : H12AffineFastState.Bounded env19381 := by
  intro p hp
  have h : env19381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19378_19381 : H12AffineEnvironment.transform 9 21 env19378 = env19381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env19378 == env19381) = true)

theorem identity19381 : scanCanonicalize (H12AffineFastState.compose env19381 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound19381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19382 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,9,1,1,3,4,1,1,0,0,0,4,2,9,4,1,5,5,0,0,1,5,0,1,512]

theorem envBound19382 : H12AffineFastState.Bounded env19382 := by
  intro p hp
  have h : env19382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19381_19382 : H12AffineEnvironment.transform 3 5 env19381 = env19382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env19381 == env19382) = true)

def leafEnv19382 : List Nat := [2,4,8,5,0,5,8,4,512,0,0,4,9,1,1,3,4,1,1,0,0,0,4,2,1,9,1,4,1,5,5,0,0,1,5,0,5,3,1,512,1,0,0]

def active19382 : List Nat := [0,1,2,8]

def tree19382 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19382 : H12WitnessSearch.Good tree19382 := H12GlobalWitnessIndex.good

theorem leafIdentity19382 : H12AffineFastState.composeSystem env19382 rootObs = leafEnv19382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19382 rootObs == leafEnv19382) = true)

theorem terminalChecked19382 : H12PackedTerminal.terminalCheckFast leafEnv19382 active19382 tree19382 = true := by decide +kernel

def env19383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,4161,4194304,17,21763,8193,65,4340845,5392,17664,179512,1365,4256860,257,21793,46092,63068]

theorem envBound19383 : H12AffineFastState.Bounded env19383 := by
  intro p hp
  have h : env19383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19361_19383 : H12AffineEnvironment.transform 6 9 env19361 = env19383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19361 == env19383) = true)

theorem identity19383 : scanCanonicalize (H12AffineFastState.compose env19383 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19383 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4161,4194304,17,21763,8193,65,4340845,5392,17664,149861,1365,4194305,257,21793,16465,513]

theorem envBound19384 : H12AffineFastState.Bounded env19384 := by
  intro p hp
  have h : env19384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19383_19384 : H12AffineEnvironment.transform 14 29789 env19383 = env19384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19383 == env19384) = true)

theorem identity19384 : scanCanonicalize (H12AffineFastState.compose env19384 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound19384 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env19385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4161,147505,17,21763,8193,65,31836,5392,17664,149861,1365,147504,257,21793,16465,513]

theorem envBound19385 : H12AffineFastState.Bounded env19385 := by
  intro p hp
  have h : env19385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19384_19385 : H12AffineEnvironment.transform 21 147505 env19384 = env19385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env19384 == env19385) = true)

theorem identity19385 : scanCanonicalize (H12AffineFastState.compose env19385 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound19385 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env19386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,5393,32040,1025,29788,4161,21792,17,21763,8193,65,31836,5392,17664,23668,1365,21793,257,21793,16465,513]

theorem envBound19386 : H12AffineFastState.Bounded env19386 := by
  intro p hp
  have h : env19386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19385_19386 : H12AffineEnvironment.transform 16 5393 env19385 = env19386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env19385 == env19386) = true)

theorem identity19386 : scanCanonicalize (H12AffineFastState.compose env19386 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound19386 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5393,2421,1025,1,4161,8573,17,8542,8193,65,2049,5392,12637,10281,1365,8572,257,8572,13324,513]

theorem envBound19387 : H12AffineFastState.Bounded env19387 := by
  intro p hp
  have h : env19387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19386_19387 : H12AffineEnvironment.transform 13 13405 env19386 = env19387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env19386 == env19387) = true)

theorem identity19387 : scanCanonicalize (H12AffineFastState.compose env19387 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19387 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5393,2421,1025,1,4161,32,17,3,348,65,2049,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound19388 : H12AffineFastState.Bounded env19388 := by
  intro p hp
  have h : env19388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19387_19388 : H12AffineEnvironment.transform 12 349 env19387 = env19388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19387 == env19388) = true)

theorem identity19388 : scanCanonicalize (H12AffineFastState.compose env19388 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound19388 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,603,4096,349,5376,0,342,5393,814,1025,1,4161,32,17,3,348,65,602,5392,4096,815,1365,33,257,33,5457,513]

theorem envBound19389 : H12AffineFastState.Bounded env19389 := by
  intro p hp
  have h : env19389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19388_19389 : H12AffineEnvironment.transform 10 603 env19388 = env19389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env19388 == env19389) = true)

theorem identity19389 : scanCanonicalize (H12AffineFastState.compose env19389 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound19389 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19390 : List Nat := [2,4,8,16,32,64,9,256,512,273,603,4096,349,4113,0,342,4096,814,272,1,4161,32,17,3,348,65,602,4097,4096,815,68,33,257,33,4160,513]

theorem envBound19390 : H12AffineFastState.Bounded env19390 := by
  intro p hp
  have h : env19390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19389_19390 : H12AffineEnvironment.transform 9 273 env19389 = env19390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19389 == env19390) = true)

theorem identity19390 : scanCanonicalize (H12AffineFastState.compose env19390 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound19390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19391 : List Nat := [2,4,8,16,32,64,9,256,512,273,603,17,349,0,0,342,17,814,272,1,80,32,17,3,348,65,602,16,17,815,68,33,257,33,81,513]

theorem envBound19391 : H12AffineFastState.Bounded env19391 := by
  intro p hp
  have h : env19391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19390_19391 : H12AffineEnvironment.transform 11 17 env19390 = env19391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env19390 == env19391) = true)

theorem identity19391 : scanCanonicalize (H12AffineFastState.compose env19391 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound19391 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19392 : List Nat := [2,4,8,16,32,64,9,256,43,273,112,17,349,0,0,342,17,261,272,1,80,32,17,3,348,65,113,16,17,260,68,33,257,33,81,42]

theorem envBound19392 : H12AffineFastState.Bounded env19392 := by
  intro p hp
  have h : env19392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19391_19392 : H12AffineEnvironment.transform 8 43 env19391 = env19392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env19391 == env19392) = true)

theorem identity19392 : scanCanonicalize (H12AffineFastState.compose env19392 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19392 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env19393 : List Nat := [2,4,8,16,32,64,9,116,43,101,112,17,41,0,0,34,17,113,100,1,80,32,17,3,40,65,113,16,17,112,68,33,117,33,81,42]

theorem envBound19393 : H12AffineFastState.Bounded env19393 := by
  intro p hp
  have h : env19393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19392_19393 : H12AffineEnvironment.transform 7 116 env19392 = env19393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19392 == env19393) = true)

theorem identity19393 : scanCanonicalize (H12AffineFastState.compose env19393 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound19393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19394 : List Nat := [2,4,8,16,32,62,9,10,43,27,14,17,41,0,0,34,17,15,26,1,46,32,17,3,40,63,15,16,17,14,58,33,11,33,47,42]

theorem envBound19394 : H12AffineFastState.Bounded env19394 := by
  intro p hp
  have h : env19394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19393_19394 : H12AffineEnvironment.transform 5 62 env19393 = env19394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env19393 == env19394) = true)

theorem identity19394 : scanCanonicalize (H12AffineFastState.compose env19394 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound19394 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19395 : List Nat := [0,4,8,16,32,60,9,8,41,25,12,17,41,0,0,32,17,13,24,1,44,32,17,1,40,61,13,16,17,12,56,33,9,33,45,40]

theorem envBound19395 : H12AffineFastState.Bounded env19395 := by
  intro p hp
  have h : env19395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19394_19395 : H12AffineEnvironment.transform 0 0 env19394 = env19395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env19394 == env19395) = true)

theorem identity19395 : scanCanonicalize (H12AffineFastState.compose env19395 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19395 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19396 : List Nat := [0,4,8,16,0,28,9,8,9,25,12,17,9,0,0,0,17,13,24,1,12,0,17,1,8,29,13,16,17,12,24,1,9,1,13,8]

theorem envBound19396 : H12AffineFastState.Bounded env19396 := by
  intro p hp
  have h : env19396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19395_19396 : H12AffineEnvironment.transform 4 0 env19395 = env19396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19395 == env19396) = true)

def env19397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101329,98781,8328,65,6433836,2098512,17665,2272753,2102685,6349852,257,21793,46213,2175563]

theorem envBound19397 : H12AffineFastState.Bounded env19397 := by
  intro p hp
  have h : env19397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19333_19397 : H12AffineEnvironment.transform 22 2101329 env19333 = env19397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env19333 == env19397) = true)

def env19398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,17,98781,8328,65,4340844,5392,17665,179633,1501,4256860,257,21793,46213,74251]

theorem envBound19398 : H12AffineFastState.Bounded env19398 := by
  intro p hp
  have h : env19398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19397_19398 : H12AffineEnvironment.transform 20 4160 env19397 = env19398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19397 == env19398) = true)

theorem identity19398 : scanCanonicalize (H12AffineFastState.compose env19398 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19398 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,4194304,17,41431,8328,65,4340844,5392,17665,179633,1501,4256860,257,21793,46213,513]

theorem envBound19399 : H12AffineFastState.Bounded env19399 := by
  intro p hp
  have h : env19399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19398_19399 : H12AffineEnvironment.transform 15 8202 env19398 = env19399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19398 == env19399) = true)

theorem identity19399 : scanCanonicalize (H12AffineFastState.compose env19399 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound19399 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32161,1025,32769,4160,41261,17,41431,8328,65,171329,5392,17665,179633,1501,21873,257,21793,46213,513]

theorem envBound19400 : H12AffineFastState.Bounded env19400 := by
  intro p hp
  have h : env19400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19399_19400 : H12AffineEnvironment.transform 21 41261 env19399 = env19400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env19399 == env19400) = true)

def env19401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,41261,17,41311,8192,65,171329,5392,17665,179513,1365,21873,257,21793,46093,513]

theorem envBound19401 : H12AffineFastState.Bounded env19401 := by
  intro p hp
  have h : env19401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19400_19401 : H12AffineEnvironment.transform 6 8 env19400 = env19401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19400 == env19401) = true)

theorem identity19401 : scanCanonicalize (H12AffineFastState.compose env19401 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19401 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,32041,1025,8540,4160,112,17,2,8192,65,146460,5392,17665,138340,1365,21873,257,21793,5456,513]

theorem envBound19402 : H12AffineFastState.Bounded env19402 := by
  intro p hp
  have h : env19402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19401_19402 : H12AffineEnvironment.transform 14 8541 env19401 = env19402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19401 == env19402) = true)

theorem identity19402 : scanCanonicalize (H12AffineFastState.compose env19402 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound19402 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,17665,32041,1025,8540,4160,112,17,2,8192,65,31005,5392,17665,22885,1365,21873,257,21793,5456,513]

theorem envBound19403 : H12AffineFastState.Bounded env19403 := by
  intro p hp
  have h : env19403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19402_19403 : H12AffineEnvironment.transform 16 17665 env19402 = env19403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env19402 == env19403) = true)

theorem identity19403 : scanCanonicalize (H12AffineFastState.compose env19403 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19403 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env19404 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,8202,16401,30777,273,8540,4160,112,17,2,8192,65,31005,4096,16401,22885,69,20577,257,20529,4160,513]

theorem envBound19404 : H12AffineFastState.Bounded env19404 := by
  intro p hp
  have h : env19404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19403_19404 : H12AffineEnvironment.transform 9 272 env19403 = env19404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19403 == env19404) = true)

theorem identity19404 : scanCanonicalize (H12AffineFastState.compose env19404 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound19404 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19405 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,8202,4096,10280,273,8540,4160,112,17,2,8192,65,10508,4096,4096,2420,69,112,257,32,4160,513]

theorem envBound19405 : H12AffineFastState.Bounded env19405 := by
  intro p hp
  have h : env19405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19404_19405 : H12AffineEnvironment.transform 13 4113 env19404 = env19405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env19404 == env19405) = true)

def env19406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4160,41261,17,41310,8193,65,171329,5392,17665,179512,1364,21873,257,21793,46092,513]

theorem envBound19406 : H12AffineFastState.Bounded env19406 := by
  intro p hp
  have h : env19406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19400_19406 : H12AffineEnvironment.transform 6 9 env19400 = env19406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19400 == env19406) = true)

theorem identity19406 : scanCanonicalize (H12AffineFastState.compose env19406 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound19406 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env19407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4160,21872,17,21763,8193,65,157980,5392,17665,149861,1364,21873,257,21793,16465,513]

theorem envBound19407 : H12AffineFastState.Bounded env19407 := by
  intro p hp
  have h : env19407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19406_19407 : H12AffineEnvironment.transform 14 29789 env19406 = env19407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env19406 == env19407) = true)

theorem identity19407 : scanCanonicalize (H12AffineFastState.compose env19407 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19407 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env19408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,5392,32040,1025,29788,4160,21872,17,21763,8193,65,31756,5392,17665,23669,1364,21873,257,21793,16465,513]

theorem envBound19408 : H12AffineFastState.Bounded env19408 := by
  intro p hp
  have h : env19408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19407_19408 : H12AffineEnvironment.transform 16 5392 env19407 = env19408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19407 == env19408) = true)

theorem identity19408 : scanCanonicalize (H12AffineFastState.compose env19408 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound19408 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,5392,2420,1025,0,4160,8492,17,8543,8193,65,2128,5392,12637,10281,1364,8493,257,8573,13325,513]

theorem envBound19409 : H12AffineFastState.Bounded env19409 := by
  intro p hp
  have h : env19409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19408_19409 : H12AffineEnvironment.transform 13 13404 env19408 = env19409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env19408 == env19409) = true)

def env19410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,16,98781,8328,65,4340845,5393,17665,179632,1500,4256861,257,21793,46213,74250]

theorem envBound19410 : H12AffineFastState.Bounded env19410 := by
  intro p hp
  have h : env19410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19397_19410 : H12AffineEnvironment.transform 20 4161 env19397 = env19410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19397 == env19410) = true)

theorem identity19410 : scanCanonicalize (H12AffineFastState.compose env19410 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound19410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,95531,16,98781,8328,65,215366,5393,17665,179632,1500,98678,257,21793,46213,74250]

theorem envBound19411 : H12AffineFastState.Bounded env19411 := by
  intro p hp
  have h : env19411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19410_19411 : H12AffineEnvironment.transform 21 95531 env19410 = env19411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env19410 == env19411) = true)

def env19412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,95531,16,98645,8192,65,215366,5393,17665,179512,1364,98678,257,21793,46093,74250]

theorem envBound19412 : H12AffineFastState.Bounded env19412 := by
  intro p hp
  have h : env19412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19411_19412 : H12AffineEnvironment.transform 6 8 env19411 = env19412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19411 == env19412) = true)

theorem identity19412 : scanCanonicalize (H12AffineFastState.compose env19412 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19412 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,4161,41341,16,21763,8192,65,171280,5393,17665,179512,1364,21792,257,21793,46093,63068]

theorem envBound19413 : H12AffineFastState.Bounded env19413 := by
  intro p hp
  have h : env19413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19412_19413 : H12AffineEnvironment.transform 15 54358 env19412 = env19413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19412 == env19413) = true)

def env19414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95531,16,98644,8193,65,215366,5393,17665,179513,1365,98678,257,21793,46092,74250]

theorem envBound19414 : H12AffineFastState.Bounded env19414 := by
  intro p hp
  have h : env19414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19411_19414 : H12AffineEnvironment.transform 6 9 env19411 = env19414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19411 == env19414) = true)

theorem identity19414 : scanCanonicalize (H12AffineFastState.compose env19414 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound19414 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,32040,1025,32769,4161,32,16,62559,8193,65,146509,5393,17665,179513,1365,62589,257,21793,46092,22273]

theorem envBound19415 : H12AffineFastState.Bounded env19415 := by
  intro p hp
  have h : env19415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19414_19415 : H12AffineEnvironment.transform 15 29963 env19414 = env19415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env19414 == env19415) = true)

theorem identity19415 : scanCanonicalize (H12AffineFastState.compose env19415 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound19415 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env19416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,46156,32040,1025,32769,4161,32,16,62559,8193,65,34817,5393,17665,2421,1365,62589,257,21793,46092,22273]

theorem envBound19416 : H12AffineFastState.Bounded env19416 := by
  intro p hp
  have h : env19416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19415_19416 : H12AffineEnvironment.transform 16 46156 env19415 = env19416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env19415 == env19416) = true)

theorem identity19416 : scanCanonicalize (H12AffineFastState.compose env19416 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19416 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,16400,32040,1025,29789,4161,32,16,3,8193,65,31837,5393,17665,2421,1365,33,257,21793,16464,22273]

theorem envBound19417 : H12AffineFastState.Bounded env19417 := by
  intro p hp
  have h : env19417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19416_19417 : H12AffineEnvironment.transform 14 29788 env19416 = env19417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19416 == env19417) = true)

theorem identity19417 : scanCanonicalize (H12AffineFastState.compose env19417 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound19417 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21540,21875,16400,23888,1025,21541,4161,32,16,3,121,65,23589,5393,17665,2421,1365,33,257,21793,16464,22273]

theorem envBound19418 : H12AffineFastState.Bounded env19418 := by
  intro p hp
  have h : env19418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19417_19418 : H12AffineEnvironment.transform 12 120 env19417 = env19418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env19417 == env19418) = true)

theorem identity19418 : scanCanonicalize (H12AffineFastState.compose env19418 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19418 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19419 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,21540,21591,16400,23668,1025,21541,4161,32,16,3,121,65,23589,5173,17445,2129,1137,33,37,21509,16464,22053]

theorem envBound19419 : H12AffineFastState.Bounded env19419 := by
  intro p hp
  have h : env19419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19418_19419 : H12AffineEnvironment.transform 7 36 env19418 = env19419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19418 == env19419) = true)

theorem identity19419 : scanCanonicalize (H12AffineFastState.compose env19419 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19419 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19420 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,16384,21540,21511,16400,23588,1025,21541,4113,32,16,3,41,17,23589,5173,17445,2049,1057,33,37,21509,16384,22053]

theorem envBound19420 : H12AffineFastState.Bounded env19420 := by
  intro p hp
  have h : env19420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19419_19420 : H12AffineEnvironment.transform 5 16 env19419 = env19420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19419 == env19420) = true)

theorem identity19420 : scanCanonicalize (H12AffineFastState.compose env19420 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound19420 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env19421 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,2048,7204,7175,2064,5156,1025,7205,4113,32,16,3,41,17,5157,5173,3109,2049,1057,33,37,7173,2048,7717]

theorem envBound19421 : H12AffineFastState.Bounded env19421 := by
  intro p hp
  have h : env19421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19420_19421 : H12AffineEnvironment.transform 13 2048 env19420 = env19421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env19420 == env19421) = true)

def env19422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound19422 : H12AffineFastState.Bounded env19422 := by
  intro p hp
  have h : env19422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19073_19422 : H12AffineEnvironment.transform 26 30393345 env19073 = env19422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env19073 == env19422) = true)

def env19423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound19423 : H12AffineFastState.Bounded env19423 := by
  intro p hp
  have h : env19423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19422_19423 : H12AffineEnvironment.transform 18 1024 env19422 = env19423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19422 == env19423) = true)

theorem identity19423 : scanCanonicalize (H12AffineFastState.compose env19423 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 485740) := by decide +kernel

theorem selectedBound19423 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,485740,8328,65,12626285,2551264,10507600,8830977,8842621,6687916,256,10923457,10898533,8899242]

theorem envBound19424 : H12AffineFastState.Bounded env19424 := by
  intro p hp
  have h : env19424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19423_19424 : H12AffineEnvironment.transform 23 485740 env19423 = env19424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 485740 env19423 == env19424) = true)

def env19425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554080,485740,8328,65,6705549,2551264,437680,2111713,2102685,6687916,256,21793,46213,2175562]

theorem envBound19425 : H12AffineFastState.Bounded env19425 := by
  intro p hp
  have h : env19425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19424_19425 : H12AffineEnvironment.transform 22 2554080 env19424 = env19425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554080 env19424 == env19425) = true)

def env19426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,98780,8328,65,6338877,2098512,17664,2111713,2102685,6349852,256,21793,46213,2175562]

theorem envBound19426 : H12AffineFastState.Bounded env19426 := by
  intro p hp
  have h : env19426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19425_19426 : H12AffineEnvironment.transform 17 190640 env19425 = env19426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env19425 == env19426) = true)

def env19427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,98780,8328,65,4237693,5392,17664,10401,1501,4256860,256,21793,46213,74250]

theorem envBound19427 : H12AffineFastState.Bounded env19427 := by
  intro p hp
  have h : env19427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19426_19427 : H12AffineEnvironment.transform 20 4160 env19426 = env19427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19426 == env19427) = true)

def env19428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,98644,8192,65,4237693,5392,17664,10281,1365,4256860,256,21793,46093,74250]

theorem envBound19428 : H12AffineFastState.Bounded env19428 := by
  intro p hp
  have h : env19428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19427_19428 : H12AffineEnvironment.transform 6 8 env19427 = env19428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19427 == env19428) = true)

theorem identity19428 : scanCanonicalize (H12AffineFastState.compose env19428 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound19428 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,108926,1024,32769,4160,4194304,16,98644,8192,65,4237693,5392,17664,10281,1365,4256860,256,21793,46093,74250]

theorem envBound19429 : H12AffineFastState.Bounded env19429 := by
  intro p hp
  have h : env19429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19428_19429 : H12AffineEnvironment.transform 16 82246 env19428 = env19429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env19428 == env19429) = true)

theorem identity19429 : scanCanonicalize (H12AffineFastState.compose env19429 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 119846) := by decide +kernel

theorem selectedBound19429 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19430 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,108926,1024,32769,4160,119846,16,98644,8192,65,97627,5392,17664,10281,1365,73850,256,21793,46093,74250]

theorem envBound19430 : H12AffineFastState.Bounded env19430 := by
  intro p hp
  have h : env19430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19429_19430 : H12AffineEnvironment.transform 21 119846 env19429 = env19430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119846 env19429 == env19430) = true)

theorem identity19430 : scanCanonicalize (H12AffineFastState.compose env19430 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound19430 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env19431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,114,16692,43276,1024,32769,4160,54356,16,33062,8192,65,32041,5392,17664,10281,1365,8200,256,21793,46093,8824]

theorem envBound19431 : H12AffineFastState.Bounded env19431 := by
  intro p hp
  have h : env19431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19430_19431 : H12AffineEnvironment.transform 15 114 env19430 = env19431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env19430 == env19431) = true)

theorem identity19431 : scanCanonicalize (H12AffineFastState.compose env19431 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19431 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env19432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,114,5220,43276,1024,32769,4160,33028,16,33062,8192,65,10361,5392,4176,10281,1365,8200,256,113,46093,8824]

theorem envBound19432 : H12AffineFastState.Bounded env19432 := by
  intro p hp
  have h : env19432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19431_19432 : H12AffineEnvironment.transform 13 5456 env19431 = env19432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19431 == env19432) = true)

theorem identity19432 : scanCanonicalize (H12AffineFastState.compose env19432 (packedSelected [0,1,2,3,4,7,8,9,10,12,15,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8573) := by decide +kernel

theorem selectedBound19432 : packedSelected [0,1,2,3,4,7,8,9,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env19433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8573,114,5220,2161,1024,8572,4160,8313,16,8283,8192,65,10361,5392,4176,10281,1365,8200,256,113,5488,8824]

theorem envBound19433 : H12AffineFastState.Bounded env19433 := by
  intro p hp
  have h : env19433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19432_19433 : H12AffineEnvironment.transform 14 8573 env19432 = env19433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8573 env19432 == env19433) = true)

theorem identity19433 : scanCanonicalize (H12AffineFastState.compose env19433 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19433 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19434 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5156,8201,114,5220,2161,1024,8200,4160,8313,16,8283,8192,65,10361,5220,4176,10281,1057,8200,116,113,5124,8824]

theorem envBound19434 : H12AffineFastState.Bounded env19434 := by
  intro p hp
  have h : env19434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19433_19434 : H12AffineEnvironment.transform 7 116 env19433 = env19434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19433 == env19434) = true)

theorem identity19434 : scanCanonicalize (H12AffineFastState.compose env19434 (packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound19434 : packedSelected [0,3,5,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env19435 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8,5156,1,114,5220,2161,1024,0,4160,113,16,83,8,65,2161,5220,4176,2081,1057,0,116,113,5124,624]

theorem envBound19435 : H12AffineFastState.Bounded env19435 := by
  intro p hp
  have h : env19435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19434_19435 : H12AffineEnvironment.transform 12 8 env19434 = env19435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env19434 == env19435) = true)

theorem identity19435 : scanCanonicalize (H12AffineFastState.compose env19435 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19435 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env19436 : List Nat := [2,4,8,16,32,48,8,4,512,1024,2048,4096,8,5156,1,2,5140,2049,1024,0,4144,1,16,35,8,49,2049,5140,4128,2081,1057,0,4,1,5124,512]

theorem envBound19436 : H12AffineFastState.Bounded env19436 := by
  intro p hp
  have h : env19436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19435_19436 : H12AffineEnvironment.transform 5 48 env19435 = env19436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19435 == env19436) = true)

theorem identity19436 : scanCanonicalize (H12AffineFastState.compose env19436 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19436 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19437 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5125,1,2,5140,2049,1024,0,4113,1,16,2,8,16,2049,5140,4097,2048,1024,0,4,1,5124,512]

theorem envBound19437 : H12AffineFastState.Bounded env19437 := by
  intro p hp
  have h : env19437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19436_19437 : H12AffineEnvironment.transform 4 1 env19436 = env19437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19436 == env19437) = true)

def env19438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,98645,8193,65,4237693,5392,17664,10280,1364,4256860,256,21793,46092,74250]

theorem envBound19438 : H12AffineFastState.Bounded env19438 := by
  intro p hp
  have h : env19438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19427_19438 : H12AffineEnvironment.transform 6 9 env19427 = env19438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19427 == env19438) = true)

theorem identity19438 : scanCanonicalize (H12AffineFastState.compose env19438 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound19438 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1024,32769,4160,4194304,16,98645,8193,65,4237693,5392,17664,10280,1364,4256860,256,21793,46092,74250]

theorem envBound19439 : H12AffineFastState.Bounded env19439 := by
  intro p hp
  have h : env19439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19438_19439 : H12AffineEnvironment.transform 16 122906 env19438 = env19439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env19438 == env19439) = true)

theorem identity19439 : scanCanonicalize (H12AffineFastState.compose env19439 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound19439 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1024,32769,4160,32800,16,98645,8193,65,10589,5392,17664,10280,1364,29820,256,21793,46092,74250]

theorem envBound19440 : H12AffineFastState.Bounded env19440 := by
  intro p hp
  have h : env19440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19439_19440 : H12AffineEnvironment.transform 21 32800 env19439 = env19440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env19439 == env19440) = true)

theorem identity19440 : scanCanonicalize (H12AffineFastState.compose env19440 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound19440 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env19441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,56437,1024,32769,4160,32800,16,21763,8193,65,10589,5392,17664,10280,1364,29820,256,21793,46092,63068]

theorem envBound19441 : H12AffineFastState.Bounded env19441 := by
  intro p hp
  have h : env19441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19440_19441 : H12AffineEnvironment.transform 15 54358 env19440 = env19441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env19440 == env19441) = true)

theorem identity19441 : scanCanonicalize (H12AffineFastState.compose env19441 (packedSelected [2,3,5,6,14,15,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19441 : packedSelected [2,3,5,6,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env19442 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,54358,5392,56437,1024,32769,4160,32800,16,21763,349,65,2049,5392,17664,2420,1364,21792,256,21793,38224,55040]

theorem envBound19442 : H12AffineFastState.Bounded env19442 := by
  intro p hp
  have h : env19442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19441_19442 : H12AffineEnvironment.transform 12 348 env19441 = env19442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19441 == env19442) = true)

theorem identity19442 : scanCanonicalize (H12AffineFastState.compose env19442 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19442 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env19443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,81,21511,5392,23588,1024,80,4160,113,16,21763,349,65,2049,5392,17664,2420,1364,21792,256,21793,5377,22353]

theorem envBound19443 : H12AffineFastState.Bounded env19443 := by
  intro p hp
  have h : env19443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19442_19443 : H12AffineEnvironment.transform 14 81 env19442 = env19443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19442 == env19443) = true)

theorem identity19443 : scanCanonicalize (H12AffineFastState.compose env19443 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19443 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,81,343,5392,2420,1024,80,4160,113,16,83,349,65,2049,5392,4176,2420,1364,112,256,113,5377,513]

theorem envBound19444 : H12AffineFastState.Bounded env19444 := by
  intro p hp
  have h : env19444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19443_19444 : H12AffineEnvironment.transform 13 5456 env19443 = env19444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19443 == env19444) = true)

theorem identity19444 : scanCanonicalize (H12AffineFastState.compose env19444 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound19444 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env19445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,97,4096,348,5456,81,343,5392,277,1024,80,4160,113,16,83,349,65,96,5392,4176,277,1364,112,256,113,5377,513]

theorem envBound19445 : H12AffineFastState.Bounded env19445 := by
  intro p hp
  have h : env19445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19444_19445 : H12AffineEnvironment.transform 10 97 env19444 = env19445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env19444 == env19445) = true)

theorem identity19445 : scanCanonicalize (H12AffineFastState.compose env19445 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19445 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19446 : List Nat := [2,4,8,16,32,16,9,256,512,1024,49,4096,268,5376,1,263,5392,277,1024,0,4112,33,16,3,269,17,48,5392,4096,277,1284,32,256,33,5377,513]

theorem envBound19446 : H12AffineFastState.Bounded env19446 := by
  intro p hp
  have h : env19446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19445_19446 : H12AffineEnvironment.transform 5 16 env19445 = env19446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19445 == env19446) = true)

theorem identity19446 : scanCanonicalize (H12AffineFastState.compose env19446 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound19446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,49,276,268,1044,1,263,1028,277,1024,0,260,33,16,3,269,17,48,1028,276,277,1284,32,256,33,1045,513]

end H12CloudChart1