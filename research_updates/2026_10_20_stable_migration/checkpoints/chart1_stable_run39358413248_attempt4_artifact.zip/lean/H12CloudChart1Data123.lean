import H12CloudChart1Data122

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env31202 : List Nat := [2,4,8,16,32,64,89,37,512,1024,1141,80,1101,1061,81,1046,1125,64,1025,80,1060,32,1061,1126,1052,64,1060,80,0,1141,20,32,36,112,16,1636]

theorem envBound31202 : H12AffineFastState.Bounded env31202 := by
  intro p hp
  have h : env31202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31201_31202 : H12AffineEnvironment.transform 10 1141 env31201 = env31202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env31201 == env31202) = true)

theorem identity31202 : scanCanonicalize (H12AffineFastState.compose env31202 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31202 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env31203 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1061,0,1053,1061,1,1046,1077,16,1025,0,1060,32,1061,1078,1052,16,1060,0,0,1061,20,32,36,32,16,1588]

theorem envBound31203 : H12AffineFastState.Bounded env31203 := by
  intro p hp
  have h : env31203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31202_31203 : H12AffineEnvironment.transform 5 16 env31202 = env31203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31202 == env31203) = true)

theorem identity31203 : scanCanonicalize (H12AffineFastState.compose env31203 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31203 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31204 : List Nat := [2,4,8,16,32,16,9,37,1,1024,1061,0,1053,1061,1,1046,1077,16,1025,0,1060,32,1061,1078,1052,16,1060,0,0,1061,20,32,36,32,16,1077]

theorem envBound31204 : H12AffineFastState.Bounded env31204 := by
  intro p hp
  have h : env31204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31203_31204 : H12AffineEnvironment.transform 8 1 env31203 = env31204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31203 == env31204) = true)

theorem identity31204 : scanCanonicalize (H12AffineFastState.compose env31204 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31204 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31205 : List Nat := [2,4,8,16,16,16,9,21,1,1024,1045,0,1053,1045,1,1046,1029,16,1025,0,1044,16,1045,1030,1052,16,1044,0,0,1045,20,16,20,16,16,1029]

theorem envBound31205 : H12AffineFastState.Bounded env31205 := by
  intro p hp
  have h : env31205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31204_31205 : H12AffineEnvironment.transform 4 16 env31204 = env31205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31204 == env31205) = true)

theorem identity31205 : scanCanonicalize (H12AffineFastState.compose env31205 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31205 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31206 : List Nat := [2,4,8,16,16,16,9,21,1,5,16,0,24,16,1,19,0,16,4,0,17,16,16,3,25,16,17,0,0,16,20,16,20,16,16,0]

theorem envBound31206 : H12AffineFastState.Bounded env31206 := by
  intro p hp
  have h : env31206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31205_31206 : H12AffineEnvironment.transform 9 5 env31205 = env31206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31205 == env31206) = true)

theorem identity31206 : scanCanonicalize (H12AffineFastState.compose env31206 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31206 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31207 : List Nat := [2,4,8,1,1,1,9,4,1,5,1,0,9,1,1,2,0,1,4,0,0,1,1,3,8,1,0,0,0,1,5,1,5,1,1,0]

theorem envBound31207 : H12AffineFastState.Bounded env31207 := by
  intro p hp
  have h : env31207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31206_31207 : H12AffineEnvironment.transform 3 1 env31206 = env31207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31206 == env31207) = true)

theorem identity31207 : scanCanonicalize (H12AffineFastState.compose env31207 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31208 : List Nat := [2,4,2,1,1,1,3,4,1,5,1,0,3,1,1,2,0,1,4,0,0,1,1,3,2,1,0,0,0,1,5,1,5,1,1,0]

theorem envBound31208 : H12AffineFastState.Bounded env31208 := by
  intro p hp
  have h : env31208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31207_31208 : H12AffineEnvironment.transform 2 2 env31207 = env31208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31207 == env31208) = true)

def env31209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664478,8393985,10507601,8724626,2102685,12645453,257,21793,46212,2175562]

theorem envBound31209 : H12AffineFastState.Bounded env31209 := by
  intro p hp
  have h : env31209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31136_31209 : H12AffineEnvironment.transform 23 10588557 env31136 = env31209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env31136 == env31209) = true)

def env31210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664478,2098513,17665,2437314,2102685,6349853,257,21793,46212,2175562]

theorem envBound31210 : H12AffineFastState.Bounded env31210 := by
  intro p hp
  have h : env31210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31210 : H12AffineEnvironment.transform 22 2101328 env31209 = env31210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env31209 == env31210) = true)

def env31211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2202014,2098513,17665,2437314,2102685,2411677,257,21793,46212,2175562]

theorem envBound31211 : H12AffineFastState.Bounded env31211 := by
  intro p hp
  have h : env31211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31210_31211 : H12AffineEnvironment.transform 21 272512 env31210 = env31211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31210 == env31211) = true)

theorem identity31211 : scanCanonicalize (H12AffineFastState.compose env31211 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound31211 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,58517,272512,62661,98781,8328,64,97547,57796,17665,382039,61704,272392,257,21793,46212,120543]

theorem envBound31212 : H12AffineFastState.Bounded env31212 := by
  intro p hp
  have h : env31212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31211_31212 : H12AffineEnvironment.transform 20 58517 env31211 = env31212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env31211 == env31212) = true)

def env31213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10280,1025,32769,58517,168,62661,98781,8328,64,97547,57796,17665,130175,61704,32,257,21793,46212,120543]

theorem envBound31213 : H12AffineFastState.Bounded env31213 := by
  intro p hp
  have h : env31213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31212_31213 : H12AffineEnvironment.transform 17 10280 env31212 = env31213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31212 == env31213) = true)

theorem identity31213 : scanCanonicalize (H12AffineFastState.compose env31213 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound31213 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env31214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62850,5393,10280,1025,32769,58517,168,62661,29791,8328,64,34953,57796,17665,2557,61704,32,257,21793,46212,9053]

theorem envBound31214 : H12AffineFastState.Bounded env31214 := by
  intro p hp
  have h : env31214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31213_31214 : H12AffineEnvironment.transform 15 62850 env31213 = env31214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env31213 == env31214) = true)

theorem identity31214 : scanCanonicalize (H12AffineFastState.compose env31214 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound31214 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,21590,5393,10280,1025,8661,17729,168,21777,29791,8328,64,10589,16400,17665,2557,20700,32,257,21793,5456,9053]

theorem envBound31215 : H12AffineFastState.Bounded env31215 := by
  intro p hp
  have h : env31215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31214_31215 : H12AffineEnvironment.transform 14 8660 env31214 = env31215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env31214 == env31215) = true)

theorem identity31215 : scanCanonicalize (H12AffineFastState.compose env31215 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31215 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env31216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,136,21590,5393,2420,1025,137,17729,168,21777,21763,468,64,2049,16400,17665,2557,20700,32,257,21793,5456,513]

theorem envBound31216 : H12AffineFastState.Bounded env31216 := by
  intro p hp
  have h : env31216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31215_31216 : H12AffineEnvironment.transform 12 348 env31215 = env31216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31215 == env31216) = true)

theorem identity31216 : scanCanonicalize (H12AffineFastState.compose env31216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31217 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,348,16384,136,20807,4096,2420,272,137,16464,168,20480,20498,468,64,2049,16400,16400,2557,20700,32,257,20528,4161,513]

theorem envBound31217 : H12AffineFastState.Bounded env31217 := by
  intro p hp
  have h : env31217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31216_31217 : H12AffineEnvironment.transform 9 273 env31216 = env31217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31216 == env31217) = true)

theorem identity31217 : scanCanonicalize (H12AffineFastState.compose env31217 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31217 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31218 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,4096,348,16384,80,20807,4096,2420,272,81,16464,112,20480,20498,268,64,2049,16400,16400,2341,20484,32,257,20528,4161,513]

theorem envBound31218 : H12AffineFastState.Bounded env31218 := by
  intro p hp
  have h : env31218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31217_31218 : H12AffineEnvironment.transform 6 88 env31217 = env31218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31217 == env31218) = true)

theorem identity31218 : scanCanonicalize (H12AffineFastState.compose env31218 (packedSelected [1,2,3,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2624) := by decide +kernel

theorem selectedBound31218 : packedSelected [1,2,3,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31219 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,2624,348,16384,80,19207,2624,2420,272,81,16464,112,19008,19026,268,64,2049,16400,16400,2341,19012,32,257,19056,2561,513]

theorem envBound31219 : H12AffineFastState.Bounded env31219 := by
  intro p hp
  have h : env31219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31218_31219 : H12AffineEnvironment.transform 11 2624 env31218 = env31219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2624 env31218 == env31219) = true)

theorem identity31219 : scanCanonicalize (H12AffineFastState.compose env31219 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 528) := by decide +kernel

theorem selectedBound31219 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env31220 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,2624,348,528,80,2327,2624,2420,272,81,576,112,2128,2114,268,64,2049,512,512,2341,2132,32,257,2144,2561,513]

theorem envBound31220 : H12AffineFastState.Bounded env31220 := by
  intro p hp
  have h : env31220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31219_31220 : H12AffineEnvironment.transform 13 528 env31219 = env31220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 528 env31219 == env31220) = true)

theorem identity31220 : scanCanonicalize (H12AffineFastState.compose env31220 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31220 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env31221 : List Nat := [2,4,8,16,32,64,88,256,512,273,513,65,348,528,80,790,65,885,272,81,576,112,593,579,268,64,512,512,512,804,597,32,257,609,0,513]

theorem envBound31221 : H12AffineFastState.Bounded env31221 := by
  intro p hp
  have h : env31221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31220_31221 : H12AffineEnvironment.transform 10 513 env31220 = env31221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31220 == env31221) = true)

theorem identity31221 : scanCanonicalize (H12AffineFastState.compose env31221 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31221 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31222 : List Nat := [2,4,8,16,32,64,88,256,1,273,0,65,348,17,80,279,65,372,272,81,65,112,80,66,268,64,1,1,1,293,84,32,257,96,0,0]

theorem envBound31222 : H12AffineFastState.Bounded env31222 := by
  intro p hp
  have h : env31222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31221_31222 : H12AffineEnvironment.transform 8 1 env31221 = env31222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31221 == env31222) = true)

theorem identity31222 : scanCanonicalize (H12AffineFastState.compose env31222 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound31222 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env31223 : List Nat := [2,4,8,16,32,64,88,100,1,117,0,65,56,17,80,115,65,16,116,81,65,112,80,66,104,64,1,1,1,65,84,32,101,96,0,0]

theorem envBound31223 : H12AffineFastState.Bounded env31223 := by
  intro p hp
  have h : env31223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31222_31223 : H12AffineEnvironment.transform 7 100 env31222 = env31223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env31222 == env31223) = true)

theorem identity31223 : scanCanonicalize (H12AffineFastState.compose env31223 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound31223 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31224 : List Nat := [2,4,8,16,32,1,25,37,1,52,0,0,56,17,17,50,0,16,53,16,0,49,17,3,41,1,1,1,1,0,21,32,36,33,0,0]

theorem envBound31224 : H12AffineFastState.Bounded env31224 := by
  intro p hp
  have h : env31224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31223_31224 : H12AffineEnvironment.transform 5 1 env31223 = env31224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31223 == env31224) = true)

theorem identity31224 : scanCanonicalize (H12AffineFastState.compose env31224 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31224 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31225 : List Nat := [2,4,8,16,16,1,25,21,1,4,0,0,8,17,17,2,0,16,5,16,0,1,17,3,25,1,1,1,1,0,21,16,20,17,0,0]

theorem envBound31225 : H12AffineFastState.Bounded env31225 := by
  intro p hp
  have h : env31225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31224_31225 : H12AffineEnvironment.transform 4 16 env31224 = env31225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31224 == env31225) = true)

theorem identity31225 : scanCanonicalize (H12AffineFastState.compose env31225 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31225 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31226 : List Nat := [2,4,8,1,1,1,8,4,1,4,0,0,8,0,0,2,0,1,5,1,0,1,0,3,8,1,1,1,1,0,4,1,5,0,0,0]

theorem envBound31226 : H12AffineFastState.Bounded env31226 := by
  intro p hp
  have h : env31226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31225_31226 : H12AffineEnvironment.transform 3 1 env31225 = env31226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31225 == env31226) = true)

def env31227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10281,1025,32769,58517,169,62661,98781,8328,64,97547,57796,17665,130174,61704,33,257,21793,46212,120543]

theorem envBound31227 : H12AffineFastState.Bounded env31227 := by
  intro p hp
  have h : env31227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31212_31227 : H12AffineEnvironment.transform 17 10281 env31212 = env31227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31212 == env31227) = true)

theorem identity31227 : scanCanonicalize (H12AffineFastState.compose env31227 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound31227 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env31228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,13508,10281,1025,32769,58517,169,62661,21898,8328,64,43356,57796,17665,10281,61704,33,257,21793,46212,648]

theorem envBound31228 : H12AffineFastState.Bounded env31228 := by
  intro p hp
  have h : env31228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31227_31228 : H12AffineEnvironment.transform 15 54359 env31227 = env31228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env31227 == env31228) = true)

theorem identity31228 : scanCanonicalize (H12AffineFastState.compose env31228 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31228 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env31229 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13389,10281,1025,32769,58396,32,62540,21763,8193,64,43356,57677,17665,10281,61704,33,257,21793,46093,513]

theorem envBound31229 : H12AffineFastState.Bounded env31229 := by
  intro p hp
  have h : env31229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31228_31229 : H12AffineEnvironment.transform 6 9 env31228 = env31229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31228 == env31229) = true)

theorem identity31229 : scanCanonicalize (H12AffineFastState.compose env31229 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound31229 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31230 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30042,13389,10281,1025,8460,17681,32,21825,21763,8193,64,2129,16448,17665,10281,20485,33,257,21793,5376,513]

theorem envBound31230 : H12AffineFastState.Bounded env31230 := by
  intro p hp
  have h : env31230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31229_31230 : H12AffineEnvironment.transform 14 8461 env31229 = env31230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env31229 == env31230) = true)

theorem identity31230 : scanCanonicalize (H12AffineFastState.compose env31230 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound31230 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env31231 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,342,13389,10281,1025,8460,12573,32,8525,8463,8193,64,2129,13388,12557,10281,9225,33,257,8493,5376,513]

theorem envBound31231 : H12AffineFastState.Bounded env31231 := by
  intro p hp
  have h : env31231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31230_31231 : H12AffineEnvironment.transform 13 13324 env31230 = env31231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env31230 == env31231) = true)

theorem identity31231 : scanCanonicalize (H12AffineFastState.compose env31231 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31231 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env31232 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8461,262,13341,10281,1025,8460,12573,32,8477,8463,8193,16,2049,13340,12557,10281,9225,33,257,8493,5376,513]

theorem envBound31232 : H12AffineFastState.Bounded env31232 := by
  intro p hp
  have h : env31232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31231_31232 : H12AffineEnvironment.transform 5 16 env31231 = env31232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31231 == env31232) = true)

theorem identity31232 : scanCanonicalize (H12AffineFastState.compose env31232 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31232 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31233 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4113,32,17,3,269,16,2049,5392,4097,2341,1285,33,257,33,5376,513]

theorem envBound31233 : H12AffineFastState.Bounded env31233 := by
  intro p hp
  have h : env31233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31232_31233 : H12AffineEnvironment.transform 12 268 env31232 = env31233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31232 == env31233) = true)

theorem identity31233 : scanCanonicalize (H12AffineFastState.compose env31233 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound31233 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31234 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,32,268,1312,1,262,1329,2341,1025,0,49,32,17,3,269,16,2049,1328,33,2341,1285,33,257,33,1312,513]

theorem envBound31234 : H12AffineFastState.Bounded env31234 := by
  intro p hp
  have h : env31234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31233_31234 : H12AffineEnvironment.transform 11 32 env31233 = env31234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env31233 == env31234) = true)

theorem identity31234 : scanCanonicalize (H12AffineFastState.compose env31234 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound31234 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31235 : List Nat := [2,4,8,16,32,16,9,256,49,1024,2048,32,268,1312,1,262,1329,2341,1025,0,49,32,17,3,269,16,2049,1328,33,2341,1285,33,257,33,1312,48]

theorem envBound31235 : H12AffineFastState.Bounded env31235 := by
  intro p hp
  have h : env31235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31234_31235 : H12AffineEnvironment.transform 8 49 env31234 = env31235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env31234 == env31235) = true)

theorem identity31235 : scanCanonicalize (H12AffineFastState.compose env31235 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound31235 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31236 : List Nat := [2,4,8,16,32,16,9,256,49,288,2048,32,268,0,1,262,17,2341,289,0,49,32,17,3,269,16,2049,16,33,2341,37,33,257,33,0,48]

theorem envBound31236 : H12AffineFastState.Bounded env31236 := by
  intro p hp
  have h : env31236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31235_31236 : H12AffineEnvironment.transform 9 288 env31235 = env31236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env31235 == env31236) = true)

theorem identity31236 : scanCanonicalize (H12AffineFastState.compose env31236 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31236 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31237 : List Nat := [2,4,8,0,32,0,9,256,33,288,2048,32,268,0,1,262,1,2341,289,0,33,32,1,3,269,0,2049,0,33,2341,37,33,257,33,0,32]

theorem envBound31237 : H12AffineFastState.Bounded env31237 := by
  intro p hp
  have h : env31237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31236_31237 : H12AffineEnvironment.transform 3 0 env31236 = env31237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31236 == env31237) = true)

theorem identity31237 : scanCanonicalize (H12AffineFastState.compose env31237 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31237 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31238 : List Nat := [2,4,8,0,32,0,9,256,33,288,1,32,268,0,1,262,1,292,289,0,33,32,1,3,269,0,0,0,33,292,37,33,257,33,0,32]

theorem envBound31238 : H12AffineFastState.Bounded env31238 := by
  intro p hp
  have h : env31238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31237_31238 : H12AffineEnvironment.transform 10 1 env31237 = env31238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31237 == env31238) = true)

theorem identity31238 : scanCanonicalize (H12AffineFastState.compose env31238 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31239 : List Nat := [2,4,8,0,32,0,9,36,33,4,1,32,40,0,1,34,1,0,5,0,33,32,1,3,41,0,0,0,33,0,37,33,37,33,0,32]

theorem envBound31239 : H12AffineFastState.Bounded env31239 := by
  intro p hp
  have h : env31239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31238_31239 : H12AffineEnvironment.transform 7 36 env31238 = env31239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31238 == env31239) = true)

theorem identity31239 : scanCanonicalize (H12AffineFastState.compose env31239 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31239 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env31240 : List Nat := [2,4,8,0,0,0,9,4,1,4,1,0,8,0,1,2,1,0,5,0,1,0,1,3,9,0,0,0,1,0,5,1,5,1,0,0]

theorem envBound31240 : H12AffineFastState.Bounded env31240 := by
  intro p hp
  have h : env31240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31239_31240 : H12AffineEnvironment.transform 4 0 env31239 = env31240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31239 == env31240) = true)

theorem identity31240 : scanCanonicalize (H12AffineFastState.compose env31240 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31241 : List Nat := [2,4,3,0,0,0,2,4,1,4,1,0,3,0,1,2,1,0,5,0,1,0,1,3,2,0,0,0,1,0,5,1,5,1,0,0]

theorem envBound31241 : H12AffineFastState.Bounded env31241 := by
  intro p hp
  have h : env31241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31240_31241 : H12AffineEnvironment.transform 2 3 env31240 = env31241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31240 == env31241) = true)

def env31242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2202015,2098513,17665,2437314,2102685,2411676,257,21793,46212,2175562]

theorem envBound31242 : H12AffineFastState.Bounded env31242 := by
  intro p hp
  have h : env31242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31210_31242 : H12AffineEnvironment.transform 21 272513 env31210 = env31242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31210 == env31242) = true)

theorem identity31242 : scanCanonicalize (H12AffineFastState.compose env31242 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound31242 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70727,262144,1025,29909,2097152,272513,2101328,95497,8328,64,2190667,2098513,17665,2437314,2102685,2373704,257,21793,16464,2175562]

theorem envBound31243 : H12AffineFastState.Bounded env31243 := by
  intro p hp
  have h : env31243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31242_31243 : H12AffineEnvironment.transform 14 29908 env31242 = env31243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env31242 == env31243) = true)

def env31244 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70679,262144,1025,29829,2097152,272513,2101248,95497,8328,16,2190619,2098433,17665,2437266,2102685,2373656,257,21793,16384,2175514]

theorem envBound31244 : H12AffineFastState.Bounded env31244 := by
  intro p hp
  have h : env31244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31243_31244 : H12AffineEnvironment.transform 5 16 env31243 = env31244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31243 == env31244) = true)

theorem identity31244 : scanCanonicalize (H12AffineFastState.compose env31244 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(20+1) ^^^ 268596) := by decide +kernel

theorem selectedBound31244 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env31245 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70679,262144,1025,29829,268596,272513,264500,95497,8328,16,357423,269365,17665,76198,265385,8492,257,21793,16384,338734]

theorem envBound31245 : H12AffineFastState.Bounded env31245 := by
  intro p hp
  have h : env31245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31244_31245 : H12AffineEnvironment.transform 20 268596 env31244 = env31245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268596 env31244 == env31245) = true)

theorem identity31245 : scanCanonicalize (H12AffineFastState.compose env31245 (packedSelected [0,1,9,10,11,16,20,22,26,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound31245 : packedSelected [0,1,9,10,11,16,20,22,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env31246 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,21647,16536,262144,1025,29829,268596,272513,264500,8582,8328,16,270496,269365,17665,32041,265385,8492,257,21793,16384,294817]

theorem envBound31246 : H12AffineFastState.Bounded env31246 := by
  intro p hp
  have h : env31246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31245_31246 : H12AffineEnvironment.transform 15 21647 env31245 = env31246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env31245 == env31246) = true)

theorem identity31246 : scanCanonicalize (H12AffineFastState.compose env31246 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound31246 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31247 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,21647,16536,2340,1025,29829,4112,8613,16,8582,8328,16,10628,5393,17665,32041,1421,8492,257,21793,16384,30341]

theorem envBound31247 : H12AffineFastState.Bounded env31247 := by
  intro p hp
  have h : env31247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31246_31247 : H12AffineEnvironment.transform 17 2340 env31246 = env31247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env31246 == env31247) = true)

theorem identity31247 : scanCanonicalize (H12AffineFastState.compose env31247 (packedSelected [3,4,5,6,9,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5260) := by decide +kernel

theorem selectedBound31247 : packedSelected [3,4,5,6,9,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31248 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5260,8200,3,5140,2340,1025,8201,4112,8613,16,8582,8328,16,10628,5393,4493,10661,1421,8492,257,429,5260,8713]

theorem envBound31248 : H12AffineFastState.Bounded env31248 := by
  intro p hp
  have h : env31248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31247_31248 : H12AffineEnvironment.transform 13 5260 env31247 = env31248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5260 env31247 == env31248) = true)

theorem identity31248 : scanCanonicalize (H12AffineFastState.compose env31248 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound31248 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31249 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8,5260,0,3,5140,2340,1025,1,4112,429,16,398,128,16,2444,5393,4493,2477,1421,292,257,429,5260,513]

theorem envBound31249 : H12AffineFastState.Bounded env31249 := by
  intro p hp
  have h : env31249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31248_31249 : H12AffineEnvironment.transform 12 8 env31248 = env31249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env31248 == env31249) = true)

theorem identity31249 : scanCanonicalize (H12AffineFastState.compose env31249 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31249 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31250 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8,5124,0,3,5140,2340,1025,1,4112,293,16,262,8,16,2308,5393,4357,2341,1285,292,257,293,5124,513]

theorem envBound31250 : H12AffineFastState.Bounded env31250 := by
  intro p hp
  have h : env31250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31249_31250 : H12AffineEnvironment.transform 6 8 env31249 = env31250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31249 == env31250) = true)

theorem identity31250 : scanCanonicalize (H12AffineFastState.compose env31250 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound31250 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31251 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1540,4096,8,5124,0,3,5140,1824,1025,1,4112,293,16,262,8,16,1792,5393,4357,1825,1285,292,257,293,5124,513]

theorem envBound31251 : H12AffineFastState.Bounded env31251 := by
  intro p hp
  have h : env31251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31250_31251 : H12AffineEnvironment.transform 10 1540 env31250 = env31251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env31250 == env31251) = true)

theorem identity31251 : scanCanonicalize (H12AffineFastState.compose env31251 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound31251 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env31252 : List Nat := [2,4,8,16,32,16,8,256,512,21,529,4096,8,4113,0,3,4097,821,20,1,4112,293,16,262,8,16,789,4356,4357,820,272,292,257,293,4113,513]

theorem envBound31252 : H12AffineFastState.Bounded env31252 := by
  intro p hp
  have h : env31252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31251_31252 : H12AffineEnvironment.transform 9 21 env31251 = env31252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env31251 == env31252) = true)

theorem identity31252 : scanCanonicalize (H12AffineFastState.compose env31252 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound31252 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31253 : List Nat := [2,4,8,16,32,16,8,52,512,21,529,4096,8,4113,0,3,4097,513,20,1,4112,17,16,50,8,16,545,4144,4145,512,36,16,53,17,4113,513]

theorem envBound31253 : H12AffineFastState.Bounded env31253 := by
  intro p hp
  have h : env31253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31252_31253 : H12AffineEnvironment.transform 7 52 env31252 = env31253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env31252 == env31253) = true)

theorem identity31253 : scanCanonicalize (H12AffineFastState.compose env31253 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound31253 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31254 : List Nat := [2,4,8,16,32,16,8,52,512,21,529,561,8,544,0,3,560,513,20,1,545,17,16,50,8,16,545,513,512,512,36,16,53,17,544,513]

theorem envBound31254 : H12AffineFastState.Bounded env31254 := by
  intro p hp
  have h : env31254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31253_31254 : H12AffineEnvironment.transform 11 561 env31253 = env31254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env31253 == env31254) = true)

theorem identity31254 : scanCanonicalize (H12AffineFastState.compose env31254 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31255 : List Nat := [2,4,8,16,17,16,8,5,512,21,529,512,8,529,0,3,513,513,20,1,528,17,16,3,8,16,528,513,512,512,21,16,4,17,529,513]

theorem envBound31255 : H12AffineFastState.Bounded env31255 := by
  intro p hp
  have h : env31255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31254_31255 : H12AffineEnvironment.transform 4 17 env31254 = env31255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31254 == env31255) = true)

theorem identity31255 : scanCanonicalize (H12AffineFastState.compose env31255 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31255 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31256 : List Nat := [2,4,8,1,0,1,8,5,512,4,512,512,8,512,0,3,513,513,5,1,513,0,1,3,8,1,513,513,512,512,4,1,4,0,512,513]

theorem envBound31256 : H12AffineFastState.Bounded env31256 := by
  intro p hp
  have h : env31256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31255_31256 : H12AffineEnvironment.transform 3 1 env31255 = env31256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31255 == env31256) = true)

theorem identity31256 : scanCanonicalize (H12AffineFastState.compose env31256 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31256 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31257 : List Nat := [2,4,8,1,0,1,8,5,0,4,0,0,8,0,0,3,1,1,5,1,1,0,1,3,8,1,1,1,0,0,4,1,4,0,0,1]

theorem envBound31257 : H12AffineFastState.Bounded env31257 := by
  intro p hp
  have h : env31257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31256_31257 : H12AffineEnvironment.transform 8 0 env31256 = env31257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31256 == env31257) = true)

def env31258 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70678,262144,1025,29828,2097152,272513,2101249,95497,8328,17,2190618,2098432,17665,2437267,2102685,2373657,257,21793,16385,2175515]

theorem envBound31258 : H12AffineFastState.Bounded env31258 := by
  intro p hp
  have h : env31258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31243_31258 : H12AffineEnvironment.transform 5 17 env31243 = env31258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31243 == env31258) = true)

theorem identity31258 : scanCanonicalize (H12AffineFastState.compose env31258 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(20+1) ^^^ 69910) := by decide +kernel

theorem selectedBound31258 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env31259 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70678,262144,1025,29828,69910,272513,65815,95497,8328,17,31756,70678,17665,270725,66699,338191,257,21793,16385,8973]

theorem envBound31259 : H12AffineFastState.Bounded env31259 := by
  intro p hp
  have h : env31259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31258_31259 : H12AffineEnvironment.transform 20 69910 env31258 = env31259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69910 env31258 == env31259) = true)

theorem identity31259 : scanCanonicalize (H12AffineFastState.compose env31259 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound31259 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31260 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70678,97327,1025,29828,69910,87214,65815,95497,8328,17,31756,70678,17665,89514,66699,21792,257,21793,16385,8973]

theorem envBound31260 : H12AffineFastState.Bounded env31260 := by
  intro p hp
  have h : env31260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31259_31260 : H12AffineEnvironment.transform 17 97327 env31259 = env31260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env31259 == env31260) = true)

theorem identity31260 : scanCanonicalize (H12AffineFastState.compose env31260 (packedSelected [0,1,4,5,7,8,17,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound31260 : packedSelected [0,1,4,5,7,8,17,22,24] rootPS < 2^1333 := by decide +kernel

def env31261 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,65536,70678,67755,1025,0,69910,73770,65815,65933,8328,17,2184,70678,12677,76078,66699,8612,257,8613,13445,8973]

theorem envBound31261 : H12AffineFastState.Bounded env31261 := by
  intro p hp
  have h : env31261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31260_31261 : H12AffineEnvironment.transform 13 13444 env31260 = env31261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env31260 == env31261) = true)

def env31262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664478,2098512,17664,2437315,2102685,6349852,257,21793,46212,2175562]

theorem envBound31262 : H12AffineFastState.Bounded env31262 := by
  intro p hp
  have h : env31262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31209_31262 : H12AffineEnvironment.transform 22 2101329 env31209 = env31262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env31209 == env31262) = true)

def env31263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2202014,2098512,17664,2437315,2102685,2411676,257,21793,46212,2175562]

theorem envBound31263 : H12AffineFastState.Bounded env31263 := by
  intro p hp
  have h : env31263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31262_31263 : H12AffineEnvironment.transform 21 272512 env31262 = env31263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31262 == env31263) = true)

theorem identity31263 : scanCanonicalize (H12AffineFastState.compose env31263 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound31263 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,4160,272512,17,98780,8328,64,100830,5392,17664,336003,1501,318684,257,21793,46212,74250]

theorem envBound31264 : H12AffineFastState.Bounded env31264 := by
  intro p hp
  have h : env31264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31263_31264 : H12AffineEnvironment.transform 20 4160 env31263 = env31264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31263 == env31264) = true)

theorem identity31264 : scanCanonicalize (H12AffineFastState.compose env31264 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31264 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4160,272512,17,41431,8328,64,43477,5392,17664,262280,1501,318684,257,21793,46212,513]

theorem envBound31265 : H12AffineFastState.Bounded env31265 := by
  intro p hp
  have h : env31265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31264_31265 : H12AffineEnvironment.transform 15 8203 env31264 = env31265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31264 == env31265) = true)

def env31266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2202015,2098512,17664,2437315,2102685,2411677,257,21793,46212,2175562]

theorem envBound31266 : H12AffineFastState.Bounded env31266 := by
  intro p hp
  have h : env31266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31262_31266 : H12AffineEnvironment.transform 21 272513 env31262 = env31266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31262 == env31266) = true)

def env31267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272393,2101329,98644,8192,64,2201879,2098512,17664,2437195,2102549,2411541,257,21793,46092,2175562]

theorem envBound31267 : H12AffineFastState.Bounded env31267 := by
  intro p hp
  have h : env31267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31266_31267 : H12AffineEnvironment.transform 6 8 env31266 = env31267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31266 == env31267) = true)

theorem identity31267 : scanCanonicalize (H12AffineFastState.compose env31267 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound31267 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,262144,1025,32769,2097152,272393,2101329,8542,8192,64,2111773,2098512,17664,2396225,2102549,2411541,257,21793,46092,2134592]

theorem envBound31268 : H12AffineFastState.Bounded env31268 := by
  intro p hp
  have h : env31268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31267_31268 : H12AffineEnvironment.transform 15 40970 env31267 = env31268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env31267 == env31268) = true)

theorem identity31268 : scanCanonicalize (H12AffineFastState.compose env31268 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound31268 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1025,32769,2097152,32,2101329,8542,8192,64,2111773,2098512,17664,2144360,2102549,2155580,257,21793,46092,2134592]

theorem envBound31269 : H12AffineFastState.Bounded env31269 := by
  intro p hp
  have h : env31269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31268_31269 : H12AffineEnvironment.transform 17 10281 env31268 = env31269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31268 == env31269) = true)

theorem identity31269 : scanCanonicalize (H12AffineFastState.compose env31269 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31269 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33110,16401,2421,1025,32769,2097152,32,2101329,2,348,64,2103361,2098512,17664,2136372,2102549,2147680,257,21793,38224,2134592]

theorem envBound31270 : H12AffineFastState.Bounded env31270 := by
  intro p hp
  have h : env31270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31269_31270 : H12AffineEnvironment.transform 12 348 env31269 = env31270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31269 == env31270) = true)

theorem identity31270 : scanCanonicalize (H12AffineFastState.compose env31270 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31270 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,342,16401,2421,1025,1,2097152,32,2101329,2,348,64,2103361,2098512,17664,2103604,2102549,2114912,257,21793,5456,2101824]

theorem envBound31271 : H12AffineFastState.Bounded env31271 := by
  intro p hp
  have h : env31271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31270_31271 : H12AffineEnvironment.transform 14 0 env31270 = env31271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31270 == env31271) = true)

theorem identity31271 : scanCanonicalize (H12AffineFastState.compose env31271 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 17509) := by decide +kernel

theorem selectedBound31271 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env31272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,342,16401,2421,1025,1,17509,32,21556,2,348,64,23588,16693,17664,23889,20848,261,257,21793,5456,22053]

theorem envBound31272 : H12AffineFastState.Bounded env31272 := by
  intro p hp
  have h : env31272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31271_31272 : H12AffineEnvironment.transform 20 17509 env31271 = env31272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17509 env31271 == env31272) = true)

theorem identity31272 : scanCanonicalize (H12AffineFastState.compose env31272 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31272 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env31273 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,0,114,16401,2129,1025,1,17509,32,21556,2,120,64,23588,16401,17444,23669,20564,33,37,21509,5236,22053]

theorem envBound31273 : H12AffineFastState.Bounded env31273 := by
  intro p hp
  have h : env31273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31272_31273 : H12AffineEnvironment.transform 7 36 env31272 = env31273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31272 == env31273) = true)

theorem identity31273 : scanCanonicalize (H12AffineFastState.compose env31273 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound31273 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env31274 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,5237,0,114,5220,2129,1025,1,4112,32,65,2,120,64,2129,5220,4177,2048,1057,33,37,112,5236,592]

theorem envBound31274 : H12AffineFastState.Bounded env31274 := by
  intro p hp
  have h : env31274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31273_31274 : H12AffineEnvironment.transform 13 5237 env31273 = env31274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env31273 == env31274) = true)

def env31275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272392,2101329,98645,8193,64,2201878,2098512,17664,2437194,2102548,2411540,257,21793,46093,2175562]

theorem envBound31275 : H12AffineFastState.Bounded env31275 := by
  intro p hp
  have h : env31275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31266_31275 : H12AffineEnvironment.transform 6 9 env31266 = env31275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31266 == env31275) = true)

theorem identity31275 : scanCanonicalize (H12AffineFastState.compose env31275 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound31275 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272392,73754,98645,8193,64,43357,79131,17664,262145,75103,392287,257,21793,46093,513]

theorem envBound31276 : H12AffineFastState.Bounded env31276 := by
  intro p hp
  have h : env31276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31275_31276 : H12AffineEnvironment.transform 20 77899 env31275 = env31276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env31275 == env31276) = true)

theorem identity31276 : scanCanonicalize (H12AffineFastState.compose env31276 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound31276 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67618,1025,32769,77899,73770,73754,98645,8193,64,43357,79131,17664,67619,75103,62589,257,21793,46093,513]

theorem envBound31277 : H12AffineFastState.Bounded env31277 := by
  intro p hp
  have h : env31277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31276_31277 : H12AffineEnvironment.transform 17 67618 env31276 = env31277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env31276 == env31277) = true)

theorem identity31277 : scanCanonicalize (H12AffineFastState.compose env31277 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound31277 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env31278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,65536,70679,67618,1025,29708,77899,73770,73754,95576,8193,64,23888,79131,17664,67619,75103,112,257,21793,16384,513]

theorem envBound31278 : H12AffineFastState.Bounded env31278 := by
  intro p hp
  have h : env31278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31277_31278 : H12AffineEnvironment.transform 14 29709 env31277 = env31278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env31277 == env31278) = true)

theorem identity31278 : scanCanonicalize (H12AffineFastState.compose env31278 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound31278 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env31279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,65536,70679,67618,1025,0,77899,73770,73754,65876,8193,64,10588,79131,12556,67619,75103,112,257,8493,13324,513]

theorem envBound31279 : H12AffineFastState.Bounded env31279 := by
  intro p hp
  have h : env31279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31278_31279 : H12AffineEnvironment.transform 13 13324 env31278 = env31279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env31278 == env31279) = true)

theorem identity31279 : scanCanonicalize (H12AffineFastState.compose env31279 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31279 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env31280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,65536,70679,67618,1025,0,69959,65830,65814,65876,269,64,2128,70679,4096,67619,66643,112,257,33,5376,513]

theorem envBound31280 : H12AffineFastState.Bounded env31280 := by
  intro p hp
  have h : env31280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31279_31280 : H12AffineEnvironment.transform 12 268 env31279 = env31280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31279 == env31280) = true)

theorem identity31280 : scanCanonicalize (H12AffineFastState.compose env31280 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31280 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,343,5440,2421,1025,0,4112,113,65,3,269,64,2128,5440,4096,2420,1284,112,257,33,5376,513]

theorem envBound31281 : H12AffineFastState.Bounded env31281 := by
  intro p hp
  have h : env31281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31280_31281 : H12AffineEnvironment.transform 15 343 env31280 = env31281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31280 == env31281) = true)

theorem identity31281 : scanCanonicalize (H12AffineFastState.compose env31281 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31281 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31282 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1025,0,4112,32,16,3,269,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound31282 : H12AffineFastState.Bounded env31282 := by
  intro p hp
  have h : env31282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31281_31282 : H12AffineEnvironment.transform 5 17 env31281 = env31282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31281 == env31282) = true)

theorem identity31282 : scanCanonicalize (H12AffineFastState.compose env31282 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31282 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31283 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,1,262,4389,2340,53,0,4112,32,16,3,269,17,2049,4389,4096,2341,304,33,257,33,4404,513]

theorem envBound31283 : H12AffineFastState.Bounded env31283 := by
  intro p hp
  have h : env31283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31282_31283 : H12AffineEnvironment.transform 9 52 env31282 = env31283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31282 == env31283) = true)

theorem identity31283 : scanCanonicalize (H12AffineFastState.compose env31283 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31284 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,1,35,4096,2049,53,0,4112,32,16,3,40,17,2049,4096,4096,2048,21,33,36,33,4113,513]

theorem envBound31284 : H12AffineFastState.Bounded env31284 := by
  intro p hp
  have h : env31284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31283_31284 : H12AffineEnvironment.transform 7 37 env31283 = env31284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31283 == env31284) = true)

theorem identity31284 : scanCanonicalize (H12AffineFastState.compose env31284 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound31284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31285 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2576,41,2561,1,35,2576,2049,53,0,2560,32,16,3,40,17,2049,2576,2576,2048,21,33,36,33,2561,513]

theorem envBound31285 : H12AffineFastState.Bounded env31285 := by
  intro p hp
  have h : env31285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31284_31285 : H12AffineEnvironment.transform 11 2576 env31284 = env31285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env31284 == env31285) = true)

theorem identity31285 : scanCanonicalize (H12AffineFastState.compose env31285 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound31285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31286 : List Nat := [2,4,8,16,32,17,9,37,512,52,59,555,41,570,1,35,555,58,53,0,571,32,16,3,40,17,58,555,555,59,21,33,36,33,570,513]

theorem envBound31286 : H12AffineFastState.Bounded env31286 := by
  intro p hp
  have h : env31286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31285_31286 : H12AffineEnvironment.transform 10 59 env31285 = env31286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env31285 == env31286) = true)

theorem identity31286 : scanCanonicalize (H12AffineFastState.compose env31286 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound31286 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31287 : List Nat := [2,4,8,16,26,17,9,31,512,14,1,529,19,512,1,25,529,0,15,0,513,26,16,3,18,17,0,529,529,1,21,27,30,27,512,513]

theorem envBound31287 : H12AffineFastState.Bounded env31287 := by
  intro p hp
  have h : env31287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31286_31287 : H12AffineEnvironment.transform 4 26 env31286 = env31287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env31286 == env31287) = true)

theorem identity31287 : scanCanonicalize (H12AffineFastState.compose env31287 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31287 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31288 : List Nat := [2,4,8,16,26,17,9,31,1,14,1,16,19,1,1,25,16,0,15,0,0,26,16,3,18,17,0,16,16,1,21,27,30,27,1,0]

theorem envBound31288 : H12AffineFastState.Bounded env31288 := by
  intro p hp
  have h : env31288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31287_31288 : H12AffineEnvironment.transform 8 1 env31287 = env31288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31287 == env31288) = true)

def env31289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound31289 : H12AffineFastState.Bounded env31289 := by
  intro p hp
  have h : env31289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30625_31289 : H12AffineEnvironment.transform 25 65 env30625 = env31289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env30625 == env31289) = true)

def env31290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound31290 : H12AffineFastState.Bounded env31290 := by
  intro p hp
  have h : env31290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31289_31290 : H12AffineEnvironment.transform 26 30393344 env31289 = env31290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env31289 == env31290) = true)

def env31291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound31291 : H12AffineFastState.Bounded env31291 := by
  intro p hp
  have h : env31291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31290_31291 : H12AffineEnvironment.transform 18 1024 env31290 = env31291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31290 == env31291) = true)

theorem identity31291 : scanCanonicalize (H12AffineFastState.compose env31291 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2534898) := by decide +kernel

theorem selectedBound31291 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2534898,8328,65,14773746,469375,10507600,8830977,10955235,4704307,256,8874334,8882427,10882612]

theorem envBound31292 : H12AffineFastState.Bounded env31292 := by
  intro p hp
  have h : env31292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31291_31292 : H12AffineEnvironment.transform 23 2534898 env31291 = env31292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2534898 env31291 == env31292) = true)

def env31293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,8388608,2114882,8328,65,14773746,115151,10507600,8399025,10600787,4268163,256,8487406,8478795,10544772]

theorem envBound31293 : H12AffineFastState.Bounded env31293 := by
  intro p hp
  have h : env31293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31292_31293 : H12AffineEnvironment.transform 17 190640 env31292 = env31293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env31292 == env31293) = true)

def env31294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101328,2114882,8328,65,4292002,115151,17664,2111713,119043,4268163,256,2199998,2191387,63188]

theorem envBound31294 : H12AffineFastState.Bounded env31294 := by
  intro p hp
  have h : env31294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31293_31294 : H12AffineEnvironment.transform 22 2101328 env31293 = env31294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env31293 == env31294) = true)

def env31295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,16,21762,8328,65,4292002,115151,17664,10401,119043,4268163,256,98814,90203,63188]

theorem envBound31295 : H12AffineFastState.Bounded env31295 := by
  intro p hp
  have h : env31295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31294_31295 : H12AffineEnvironment.transform 20 4160 env31294 = env31295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31294 == env31295) = true)

theorem identity31295 : scanCanonicalize (H12AffineFastState.compose env31295 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound31295 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190640,1024,32769,4160,4194304,16,21762,8328,65,4237692,5393,17664,10401,1501,4256861,256,21792,46213,63188]

theorem envBound31296 : H12AffineFastState.Bounded env31296 := by
  intro p hp
  have h : env31296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31295_31296 : H12AffineEnvironment.transform 15 54494 env31295 = env31296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env31295 == env31296) = true)

def env31297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4160,4194304,16,21762,8192,65,4237692,5393,17664,10281,1365,4256861,256,21792,46093,63068]

theorem envBound31297 : H12AffineFastState.Bounded env31297 := by
  intro p hp
  have h : env31297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31296_31297 : H12AffineEnvironment.transform 6 8 env31296 = env31297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31296 == env31297) = true)

theorem identity31297 : scanCanonicalize (H12AffineFastState.compose env31297 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound31297 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,32041,1024,32769,4160,4194304,16,21762,8192,65,4237692,5393,17664,10281,1365,4256861,256,21792,46093,63068]

theorem envBound31298 : H12AffineFastState.Bounded env31298 := by
  intro p hp
  have h : env31298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31297_31298 : H12AffineEnvironment.transform 16 38161 env31297 = env31298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env31297 == env31298) = true)

theorem identity31298 : scanCanonicalize (H12AffineFastState.compose env31298 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound31298 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env31299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38161,32041,1024,32769,4160,29741,16,21762,8192,65,56657,5393,17664,10281,1365,32880,256,21792,46093,63068]

theorem envBound31299 : H12AffineFastState.Bounded env31299 := by
  intro p hp
  have h : env31299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31298_31299 : H12AffineEnvironment.transform 21 29741 env31298 = env31299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env31298 == env31299) = true)

theorem identity31299 : scanCanonicalize (H12AffineFastState.compose env31299 (packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound31299 : packedSelected [1,3,4,8,9,10,12,14,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env31300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32803,38161,10588,1024,32769,4160,8280,16,375,8192,65,35108,5393,4469,10281,1365,32880,256,341,46093,41513]

theorem envBound31300 : H12AffineFastState.Bounded env31300 := by
  intro p hp
  have h : env31300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31299_31300 : H12AffineEnvironment.transform 13 5237 env31299 = env31300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env31299 == env31300) = true)

theorem identity31300 : scanCanonicalize (H12AffineFastState.compose env31300 (packedSelected [0,7,9,14,16,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound31300 : packedSelected [0,7,9,14,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env31301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,8203,13625,10588,1024,8233,4160,8280,16,375,8192,65,10508,5393,4469,10281,1365,8280,256,341,5157,513]

theorem envBound31301 : H12AffineFastState.Bounded env31301 := by
  intro p hp
  have h : env31301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31300_31301 : H12AffineEnvironment.transform 14 8232 env31300 = env31301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env31300 == env31301) = true)

theorem identity31301 : scanCanonicalize (H12AffineFastState.compose env31301 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31301 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31302 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,4112,8232,8203,12636,10588,101,8233,4160,8280,16,375,8192,65,10508,4468,4469,10281,304,8280,256,341,4160,513]

theorem envBound31302 : H12AffineFastState.Bounded env31302 := by
  intro p hp
  have h : env31302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31301_31302 : H12AffineEnvironment.transform 9 101 env31301 = env31302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31301 == env31302) = true)

theorem identity31302 : scanCanonicalize (H12AffineFastState.compose env31302 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31302 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31303 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,8192,4112,8232,8203,12329,10281,101,8233,4160,8280,16,2,8192,65,10361,4097,4096,10281,69,8280,117,32,4160,513]

theorem envBound31303 : H12AffineFastState.Bounded env31303 := by
  intro p hp
  have h : env31303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31302_31303 : H12AffineEnvironment.transform 7 117 env31302 = env31303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31302 == env31303) = true)

theorem identity31303 : scanCanonicalize (H12AffineFastState.compose env31303 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31303 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31304 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,17,8192,1,8232,8203,8248,10281,101,8233,81,8280,16,2,8192,65,10361,16,17,10281,69,8280,117,32,81,513]

theorem envBound31304 : H12AffineFastState.Bounded env31304 := by
  intro p hp
  have h : env31304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31303_31304 : H12AffineEnvironment.transform 11 17 env31303 = env31304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31303 == env31304) = true)

theorem identity31304 : scanCanonicalize (H12AffineFastState.compose env31304 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31304 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31305 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,17,8192,1,8232,8203,8248,8233,101,8233,81,8280,16,2,8192,65,8313,16,17,8233,69,8280,117,32,81,513]

theorem envBound31305 : H12AffineFastState.Bounded env31305 := by
  intro p hp
  have h : env31305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31304_31305 : H12AffineEnvironment.transform 10 0 env31304 = env31305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31304 == env31305) = true)

def env31306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21762,8193,65,4237692,5393,17664,10280,1364,4256861,256,21792,46092,63069]

theorem envBound31306 : H12AffineFastState.Bounded env31306 := by
  intro p hp
  have h : env31306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31296_31306 : H12AffineEnvironment.transform 6 9 env31296 = env31306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31296 == env31306) = true)

theorem identity31306 : scanCanonicalize (H12AffineFastState.compose env31306 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound31306 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56437,1024,32769,4160,4194304,16,21762,8193,65,4237692,5393,17664,10280,1364,4256861,256,21792,46092,63069]

theorem envBound31307 : H12AffineFastState.Bounded env31307 := by
  intro p hp
  have h : env31307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31306_31307 : H12AffineEnvironment.transform 16 13388 env31306 = env31307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env31306 == env31307) = true)

theorem identity31307 : scanCanonicalize (H12AffineFastState.compose env31307 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound31307 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,56437,1024,32769,4160,29820,16,21762,8193,65,56576,5393,17664,10280,1364,32801,256,21792,46092,63069]

theorem envBound31308 : H12AffineFastState.Bounded env31308 := by
  intro p hp
  have h : env31308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31307_31308 : H12AffineEnvironment.transform 21 29820 env31307 = env31308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env31307 == env31308) = true)

theorem identity31308 : scanCanonicalize (H12AffineFastState.compose env31308 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound31308 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21841,262,13388,2340,1024,21840,4160,29820,16,21762,8193,65,2129,5393,17664,10280,1364,21872,256,21792,24925,8972]

theorem envBound31309 : H12AffineFastState.Bounded env31309 := by
  intro p hp
  have h : env31309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31308_31309 : H12AffineEnvironment.transform 14 21841 env31308 = env31309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env31308 == env31309) = true)

theorem identity31309 : scanCanonicalize (H12AffineFastState.compose env31309 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31309 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env31310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,262,13388,2340,1024,81,4160,8573,16,3,8193,65,2129,5393,4097,10280,1364,113,256,33,13404,8972]

theorem envBound31310 : H12AffineFastState.Bounded env31310 := by
  intro p hp
  have h : env31310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31309_31310 : H12AffineEnvironment.transform 13 5377 env31309 = env31310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31309 == env31310) = true)

theorem identity31310 : scanCanonicalize (H12AffineFastState.compose env31310 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31310 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env31311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,80,262,5440,2340,1024,81,4160,113,16,3,269,65,2129,5393,4097,2340,1364,113,256,33,5456,512]

theorem envBound31311 : H12AffineFastState.Bounded env31311 := by
  intro p hp
  have h : env31311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31310_31311 : H12AffineEnvironment.transform 12 268 env31310 = env31311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31310 == env31311) = true)

theorem identity31311 : scanCanonicalize (H12AffineFastState.compose env31311 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31311 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31312 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,268,5377,80,262,5440,2308,1024,81,4160,81,16,3,269,65,2129,5393,4097,2308,1364,81,256,1,5456,512]

theorem envBound31312 : H12AffineFastState.Bounded env31312 := by
  intro p hp
  have h : env31312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31311_31312 : H12AffineEnvironment.transform 4 0 env31311 = env31312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31311 == env31312) = true)

theorem identity31312 : scanCanonicalize (H12AffineFastState.compose env31312 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31312 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31313 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,268,4112,80,262,4177,2308,273,81,4160,81,16,3,269,65,2129,4096,4097,2308,69,81,256,1,4161,512]

theorem envBound31313 : H12AffineFastState.Bounded env31313 := by
  intro p hp
  have h : env31313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31312_31313 : H12AffineEnvironment.transform 9 273 env31312 = env31313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31312 == env31313) = true)

theorem identity31313 : scanCanonicalize (H12AffineFastState.compose env31313 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound31313 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31314 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,2065,268,2049,80,262,2112,2308,273,81,2129,81,16,3,269,65,2129,2065,2064,2308,69,81,256,1,2128,512]

theorem envBound31314 : H12AffineFastState.Bounded env31314 := by
  intro p hp
  have h : env31314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31313_31314 : H12AffineEnvironment.transform 11 2065 env31313 = env31314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env31313 == env31314) = true)

theorem identity31314 : scanCanonicalize (H12AffineFastState.compose env31314 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound31314 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31315 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,2065,88,2049,80,82,2112,2128,69,81,2129,81,16,3,89,65,2129,2065,2064,2128,69,81,84,1,2128,512]

theorem envBound31315 : H12AffineFastState.Bounded env31315 := by
  intro p hp
  have h : env31315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31314_31315 : H12AffineEnvironment.transform 7 84 env31314 = env31315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env31314 == env31315) = true)

theorem identity31315 : scanCanonicalize (H12AffineFastState.compose env31315 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31315 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env31316 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2065,9,2049,1,3,2065,2049,20,0,2048,0,16,3,8,16,2048,2065,2064,2049,20,0,5,1,2049,512]

theorem envBound31316 : H12AffineFastState.Bounded env31316 := by
  intro p hp
  have h : env31316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31315_31316 : H12AffineEnvironment.transform 5 17 env31315 = env31316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31315 == env31316) = true)

theorem identity31316 : scanCanonicalize (H12AffineFastState.compose env31316 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound31316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31317 : List Nat := [2,4,8,16,0,17,9,5,512,20,5,20,9,4,1,3,20,4,20,0,5,0,16,3,8,16,5,20,21,4,20,0,5,1,4,512]

theorem envBound31317 : H12AffineFastState.Bounded env31317 := by
  intro p hp
  have h : env31317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31316_31317 : H12AffineEnvironment.transform 10 5 env31316 = env31317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env31316 == env31317) = true)

theorem identity31317 : scanCanonicalize (H12AffineFastState.compose env31317 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound31317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31318 : List Nat := [2,4,8,16,0,17,9,5,12,20,5,20,9,4,1,3,20,4,20,0,5,0,16,3,8,16,5,20,21,4,20,0,5,1,4,12]

theorem envBound31318 : H12AffineFastState.Bounded env31318 := by
  intro p hp
  have h : env31318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31317_31318 : H12AffineEnvironment.transform 8 12 env31317 = env31318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env31317 == env31318) = true)

def env31319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,21763,8328,65,4292002,115151,17664,10400,119043,4268163,256,98815,90202,63188]

theorem envBound31319 : H12AffineFastState.Bounded env31319 := by
  intro p hp
  have h : env31319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31294_31319 : H12AffineEnvironment.transform 20 4161 env31294 = env31319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31294 == env31319) = true)

theorem identity31319 : scanCanonicalize (H12AffineFastState.compose env31319 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201966) := by decide +kernel

theorem selectedBound31319 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,201966,17,21763,8328,65,158028,115151,17664,10400,119043,144493,256,98815,90202,63188]

theorem envBound31320 : H12AffineFastState.Bounded env31320 := by
  intro p hp
  have h : env31320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31319_31320 : H12AffineEnvironment.transform 21 201966 env31319 = env31320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201966 env31319 == env31320) = true)

theorem identity31320 : scanCanonicalize (H12AffineFastState.compose env31320 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31320 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138341,1024,29908,4161,201966,17,21763,8328,65,158028,79130,17664,10400,75222,144493,256,95530,90202,513]

theorem envBound31321 : H12AffineFastState.Bounded env31321 := by
  intro p hp
  have h : env31321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31320_31321 : H12AffineEnvironment.transform 14 29909 env31320 = env31321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31320 == env31321) = true)

theorem identity31321 : scanCanonicalize (H12AffineFastState.compose env31321 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31321 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,97407,1024,29908,4161,29940,17,21763,8328,65,67926,79130,17664,10400,75222,87159,256,95530,90202,513]

theorem envBound31322 : H12AffineFastState.Bounded env31322 := by
  intro p hp
  have h : env31322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31321_31322 : H12AffineEnvironment.transform 16 90138 env31321 = env31322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31321 == env31322) = true)

def env31323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,79130,76159,1024,8660,4161,8692,17,3,8328,65,67926,79130,4096,10400,75222,65911,256,73770,79194,513]

theorem envBound31323 : H12AffineFastState.Bounded env31323 := by
  intro p hp
  have h : env31323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31322_31323 : H12AffineEnvironment.transform 13 5376 env31322 = env31323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31322 == env31323) = true)

theorem identity31323 : scanCanonicalize (H12AffineFastState.compose env31323 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31323 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79130,76159,1024,8541,4161,8573,17,3,8193,65,67926,79130,4096,10281,75103,65911,256,73770,79194,513]

theorem envBound31324 : H12AffineFastState.Bounded env31324 := by
  intro p hp
  have h : env31324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31323_31324 : H12AffineEnvironment.transform 6 9 env31323 = env31324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31323 == env31324) = true)

theorem identity31324 : scanCanonicalize (H12AffineFastState.compose env31324 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31324 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5393,2420,1024,8541,4161,8573,17,3,8193,65,10589,5393,4096,10281,1364,8572,256,33,5457,513]

theorem envBound31325 : H12AffineFastState.Bounded env31325 := by
  intro p hp
  have h : env31325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31324_31325 : H12AffineEnvironment.transform 15 8203 env31324 = env31325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31324 == env31325) = true)

theorem identity31325 : scanCanonicalize (H12AffineFastState.compose env31325 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31325 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31326 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5393,2341,1024,8460,4112,8492,17,3,8193,16,10508,5393,4096,10281,1285,8493,256,33,5376,513]

theorem envBound31326 : H12AffineFastState.Bounded env31326 := by
  intro p hp
  have h : env31326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31325_31326 : H12AffineEnvironment.transform 5 17 env31325 = env31326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31325 == env31326) = true)

theorem identity31326 : scanCanonicalize (H12AffineFastState.compose env31326 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 285) := by decide +kernel

theorem selectedBound31326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31327 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,285,5376,16,278,5393,2341,1024,17,4112,49,17,3,284,16,2065,5393,4096,2356,1285,48,256,33,5376,513]

theorem envBound31327 : H12AffineFastState.Bounded env31327 := by
  intro p hp
  have h : env31327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31326_31327 : H12AffineEnvironment.transform 12 285 env31326 = env31327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 285 env31326 == env31327) = true)

theorem identity31327 : scanCanonicalize (H12AffineFastState.compose env31327 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1792) := by decide +kernel

theorem selectedBound31327 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31328 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,4096,285,5376,16,278,5393,1573,1024,17,4112,49,17,3,284,16,1809,5393,4096,1588,1285,48,256,33,5376,513]

theorem envBound31328 : H12AffineFastState.Bounded env31328 := by
  intro p hp
  have h : env31328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31327_31328 : H12AffineEnvironment.transform 10 1792 env31327 = env31328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env31327 == env31328) = true)

theorem identity31328 : scanCanonicalize (H12AffineFastState.compose env31328 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31328 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31329 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,4096,56,5157,16,51,5172,1573,1024,17,4112,49,17,3,57,16,1588,5172,4096,1588,1056,48,37,33,5157,513]

theorem envBound31329 : H12AffineFastState.Bounded env31329 := by
  intro p hp
  have h : env31329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31328_31329 : H12AffineEnvironment.transform 7 37 env31328 = env31329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31328 == env31329) = true)

theorem identity31329 : scanCanonicalize (H12AffineFastState.compose env31329 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound31329 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31330 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1573,1076,56,17,16,51,0,1573,1024,17,1060,49,17,3,57,16,1588,0,1076,1588,1056,48,37,33,17,513]

theorem envBound31330 : H12AffineFastState.Bounded env31330 := by
  intro p hp
  have h : env31330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31329_31330 : H12AffineEnvironment.transform 11 1076 env31329 = env31330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env31329 == env31330) = true)

theorem identity31330 : scanCanonicalize (H12AffineFastState.compose env31330 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound31330 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31331 : List Nat := [2,4,8,16,32,17,9,37,512,37,512,17,56,17,16,51,0,512,37,17,1,49,17,3,57,16,529,0,17,529,5,48,37,33,17,513]

theorem envBound31331 : H12AffineFastState.Bounded env31331 := by
  intro p hp
  have h : env31331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31330_31331 : H12AffineEnvironment.transform 9 37 env31330 = env31331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env31330 == env31331) = true)

theorem identity31331 : scanCanonicalize (H12AffineFastState.compose env31331 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31331 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31332 : List Nat := [2,4,8,16,32,17,9,37,0,37,0,17,56,17,16,51,0,0,37,17,1,49,17,3,57,16,17,0,17,17,5,48,37,33,17,1]

theorem envBound31332 : H12AffineFastState.Bounded env31332 := by
  intro p hp
  have h : env31332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31331_31332 : H12AffineEnvironment.transform 8 0 env31331 = env31332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31331 == env31332) = true)

def env31333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79131,76158,1024,8661,4161,8693,17,2,8328,65,67926,79130,4097,10400,75222,65910,256,73771,79195,513]

theorem envBound31333 : H12AffineFastState.Bounded env31333 := by
  intro p hp
  have h : env31333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31322_31333 : H12AffineEnvironment.transform 13 5377 env31322 = env31333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31322 == env31333) = true)

theorem identity31333 : scanCanonicalize (H12AffineFastState.compose env31333 (packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound31333 : packedSelected [1,2,3,4,6,9,11,14,20,24,28,32] rootPS < 2^1333 := by decide +kernel

def env31334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,479,13508,10401,1024,8661,4161,8693,17,2,8328,65,2185,13509,4097,10400,9225,169,256,8692,13444,513]

theorem envBound31334 : H12AffineFastState.Bounded env31334 := by
  intro p hp
  have h : env31334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31333_31334 : H12AffineEnvironment.transform 15 479 env31333 = env31334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env31333 == env31334) = true)

theorem identity31334 : scanCanonicalize (H12AffineFastState.compose env31334 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound31334 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,8192,2264,8660,479,10525,10401,1024,8661,3480,8693,17,2,8328,65,2185,10524,3544,10400,9225,169,256,8692,10589,513]

theorem envBound31335 : H12AffineFastState.Bounded env31335 := by
  intro p hp
  have h : env31335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31334_31335 : H12AffineEnvironment.transform 11 3545 env31334 = env31335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env31334 == env31335) = true)

theorem identity31335 : scanCanonicalize (H12AffineFastState.compose env31335 (packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound31335 : packedSelected [0,1,2,6,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env31336 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3189,8192,2264,8312,115,10417,10401,1024,8313,3124,8281,17,2,8328,65,2185,10416,3188,10400,9225,169,172,8280,10481,513]

theorem envBound31336 : H12AffineFastState.Bounded env31336 := by
  intro p hp
  have h : env31336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31335_31336 : H12AffineEnvironment.transform 7 172 env31335 = env31336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31335 == env31336) = true)

theorem identity31336 : scanCanonicalize (H12AffineFastState.compose env31336 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound31336 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31337 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,3189,240,2264,136,115,2113,2129,1024,137,3124,169,17,2,120,65,2185,2112,3188,2128,1273,169,172,168,2049,513]

theorem envBound31337 : H12AffineFastState.Bounded env31337 := by
  intro p hp
  have h : env31337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31336_31337 : H12AffineEnvironment.transform 12 240 env31336 = env31337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env31336 == env31337) = true)

theorem identity31337 : scanCanonicalize (H12AffineFastState.compose env31337 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound31337 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env31338 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1125,16,240,1213,136,115,1060,1076,1024,137,81,169,17,2,120,65,1260,1061,17,1077,1273,169,172,168,1124,513]

theorem envBound31338 : H12AffineFastState.Bounded env31338 := by
  intro p hp
  have h : env31338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31337_31338 : H12AffineEnvironment.transform 10 1125 env31337 = env31338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env31337 == env31338) = true)

theorem identity31338 : scanCanonicalize (H12AffineFastState.compose env31338 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31338 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31339 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1076,16,161,1213,136,34,1060,1076,1024,137,0,169,17,2,41,16,1213,1061,17,1077,1192,169,172,168,1077,513]

theorem envBound31339 : H12AffineFastState.Bounded env31339 := by
  intro p hp
  have h : env31339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31338_31339 : H12AffineEnvironment.transform 5 17 env31338 = env31339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31338 == env31339) = true)

def env31340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,2114882,8328,65,4292003,115151,17665,2111712,119042,4268163,256,2199999,2191386,63189]

theorem envBound31340 : H12AffineFastState.Bounded env31340 := by
  intro p hp
  have h : env31340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31293_31340 : H12AffineEnvironment.transform 22 2101329 env31293 = env31340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env31293 == env31340) = true)

def env31341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,21762,8328,65,4292003,115151,17665,10400,119042,4268163,256,98815,90202,63189]

theorem envBound31341 : H12AffineFastState.Bounded env31341 := by
  intro p hp
  have h : env31341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31340_31341 : H12AffineEnvironment.transform 20 4160 env31340 = env31341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31340 == env31341) = true)

theorem identity31341 : scanCanonicalize (H12AffineFastState.compose env31341 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound31341 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,254011,17,21762,8328,65,171416,115151,17665,10400,119042,180408,256,98815,90202,63189]

theorem envBound31342 : H12AffineFastState.Bounded env31342 := by
  intro p hp
  have h : env31342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31341_31342 : H12AffineEnvironment.transform 21 254011 env31341 = env31342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env31341 == env31342) = true)

def env31343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,254011,17,21762,8192,65,171280,115015,17665,10280,119042,180272,256,98679,90202,63069]

theorem envBound31343 : H12AffineFastState.Bounded env31343 := by
  intro p hp
  have h : env31343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31342_31343 : H12AffineEnvironment.transform 6 8 env31342 = env31343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31342 == env31343) = true)

theorem identity31343 : scanCanonicalize (H12AffineFastState.compose env31343 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31343 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179512,1024,32769,4160,243003,17,2,8192,65,171280,103495,4097,10280,99330,169264,256,98679,79194,41821]

theorem envBound31344 : H12AffineFastState.Bounded env31344 := by
  intro p hp
  have h : env31344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31343_31344 : H12AffineEnvironment.transform 13 5376 env31343 = env31344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31343 == env31344) = true)

theorem identity31344 : scanCanonicalize (H12AffineFastState.compose env31344 (packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31344 : packedSelected [0,1,4,8,10,12,14,15,18,19,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env31345 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,65536,131072,179277,1024,32769,4160,242766,17,2,8192,65,171109,103495,4097,10280,99330,169029,117,98306,78895,41512]

theorem envBound31345 : H12AffineFastState.Bounded env31345 := by
  intro p hp
  have h : env31345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31344_31345 : H12AffineEnvironment.transform 7 117 env31344 = env31345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31344 == env31345) = true)

theorem identity31345 : scanCanonicalize (H12AffineFastState.compose env31345 (packedSelected [0,1,3,4,6,7,8,9,10,12,15,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound31345 : packedSelected [0,1,3,4,6,7,8,9,10,12,15,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env31346 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,65536,131072,138340,1024,8232,4160,201831,17,2,8192,65,146508,78958,4097,10280,74795,144492,117,73771,78895,513]

theorem envBound31346 : H12AffineFastState.Bounded env31346 := by
  intro p hp
  have h : env31346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31345_31346 : H12AffineEnvironment.transform 14 8233 env31345 = env31346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env31345 == env31346) = true)

theorem identity31346 : scanCanonicalize (H12AffineFastState.compose env31346 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound31346 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31347 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8233,65536,4097,3173,1024,8232,4160,66662,17,2,8192,65,11341,78958,4097,10280,74795,9325,117,73771,78895,513]

theorem envBound31347 : H12AffineFastState.Bounded env31347 := by
  intro p hp
  have h : env31347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31346_31347 : H12AffineEnvironment.transform 16 4097 env31346 = env31347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env31346 == env31347) = true)

theorem identity31347 : scanCanonicalize (H12AffineFastState.compose env31347 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31347 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31348 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,8192,4161,8233,65536,4097,2129,52,8232,4160,65618,17,2,8192,65,10361,77914,4097,10280,73759,8281,117,73771,77851,513]

theorem envBound31348 : H12AffineFastState.Bounded env31348 := by
  intro p hp
  have h : env31348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31347_31348 : H12AffineEnvironment.transform 9 52 env31347 = env31348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31347 == env31348) = true)

theorem identity31348 : scanCanonicalize (H12AffineFastState.compose env31348 (packedSelected [0,2,3,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31348 : packedSelected [0,2,3,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env31349 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,121,4161,80,65536,4097,2129,52,81,4160,65618,17,2,121,65,2048,69667,4097,2129,65638,32,117,65618,69730,513]

theorem envBound31349 : H12AffineFastState.Bounded env31349 := by
  intro p hp
  have h : env31349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31348_31349 : H12AffineEnvironment.transform 12 121 env31348 = env31349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31348 == env31349) = true)

theorem identity31349 : scanCanonicalize (H12AffineFastState.compose env31349 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31349 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env31350 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,41,4113,0,65536,4097,2049,52,1,4112,65538,17,2,41,17,2048,69667,4097,2049,65590,32,37,65538,69682,513]

theorem envBound31350 : H12AffineFastState.Bounded env31350 := by
  intro p hp
  have h : env31350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31349_31350 : H12AffineEnvironment.transform 5 16 env31349 = env31350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31349 == env31350) = true)

def env31351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254011,17,21762,8193,65,171281,115014,17665,10281,119042,180273,256,98678,90202,63068]

theorem envBound31351 : H12AffineFastState.Bounded env31351 := by
  intro p hp
  have h : env31351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31342_31351 : H12AffineEnvironment.transform 6 9 env31342 = env31351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31342 == env31351) = true)

theorem identity31351 : scanCanonicalize (H12AffineFastState.compose env31351 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31351 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138340,1024,29788,4160,201830,17,21762,8193,65,158028,79131,17665,10281,75103,144492,256,95531,90202,513]

theorem envBound31352 : H12AffineFastState.Bounded env31352 := by
  intro p hp
  have h : env31352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31351_31352 : H12AffineEnvironment.transform 14 29789 env31351 = env31352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31351 == env31352) = true)

theorem identity31352 : scanCanonicalize (H12AffineFastState.compose env31352 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31352 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97406,1024,29788,4160,29820,17,21762,8193,65,67926,79131,17665,10281,75103,87158,256,95531,90202,513]

theorem envBound31353 : H12AffineFastState.Bounded env31353 := by
  intro p hp
  have h : env31353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31352_31353 : H12AffineEnvironment.transform 16 90138 env31352 = env31353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31352 == env31353) = true)

theorem identity31353 : scanCanonicalize (H12AffineFastState.compose env31353 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound31353 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2420,1024,29788,4160,29820,17,21762,8193,65,31836,16401,17665,10281,20565,8572,256,33,5456,513]

theorem envBound31354 : H12AffineFastState.Bounded env31354 := by
  intro p hp
  have h : env31354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31353_31354 : H12AffineEnvironment.transform 15 29962 env31353 = env31354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env31353 == env31354) = true)

theorem identity31354 : scanCanonicalize (H12AffineFastState.compose env31354 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound31354 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env31355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,8494,5392,2420,1024,8312,4160,8280,17,294,8193,65,10360,5173,4389,10281,1137,8572,256,33,5456,513]

theorem envBound31355 : H12AffineFastState.Bounded env31355 := by
  intro p hp
  have h : env31355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31354_31355 : H12AffineEnvironment.transform 13 5156 env31354 = env31355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env31354 == env31355) = true)

theorem identity31355 : scanCanonicalize (H12AffineFastState.compose env31355 (packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31355 : packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env31356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5156,292,115,5392,2420,1024,293,4160,261,17,294,348,65,2341,5173,4389,2420,1137,33,256,33,5456,513]

theorem envBound31356 : H12AffineFastState.Bounded env31356 := by
  intro p hp
  have h : env31356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31355_31356 : H12AffineEnvironment.transform 12 349 env31355 = env31356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31355 == env31356) = true)

theorem identity31356 : scanCanonicalize (H12AffineFastState.compose env31356 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31356 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31357 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5156,1,115,5173,2129,1024,0,4160,32,17,3,121,65,2048,5173,4096,2129,1137,33,37,33,5237,513]

theorem envBound31357 : H12AffineFastState.Bounded env31357 := by
  intro p hp
  have h : env31357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31356_31357 : H12AffineEnvironment.transform 7 37 env31356 = env31357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31356 == env31357) = true)

theorem identity31357 : scanCanonicalize (H12AffineFastState.compose env31357 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound31357 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31358 : List Nat := [2,4,8,16,32,64,9,37,512,564,2048,4096,120,4624,1,115,4609,2129,564,0,4160,32,17,3,121,65,2048,4609,4096,2129,581,33,37,33,4673,513]

theorem envBound31358 : H12AffineFastState.Bounded env31358 := by
  intro p hp
  have h : env31358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31357_31358 : H12AffineEnvironment.transform 9 564 env31357 = env31358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env31357 == env31358) = true)

theorem identity31358 : scanCanonicalize (H12AffineFastState.compose env31358 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31358 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31359 : List Nat := [2,4,8,16,32,17,9,37,512,564,2048,4096,41,4624,1,34,4609,2048,564,0,4113,32,17,3,40,16,2048,4609,4096,2048,532,33,37,33,4624,513]

theorem envBound31359 : H12AffineFastState.Bounded env31359 := by
  intro p hp
  have h : env31359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31358_31359 : H12AffineEnvironment.transform 5 17 env31358 = env31359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31358 == env31359) = true)

theorem identity31359 : scanCanonicalize (H12AffineFastState.compose env31359 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31359 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31360 : List Nat := [2,4,8,1,32,0,9,37,512,549,2048,4096,41,4609,1,34,4609,2048,549,0,4096,32,0,3,40,1,2048,4609,4096,2048,517,33,37,33,4609,513]

theorem envBound31360 : H12AffineFastState.Bounded env31360 := by
  intro p hp
  have h : env31360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31359_31360 : H12AffineEnvironment.transform 3 1 env31359 = env31360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31359 == env31360) = true)

def env31361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,21763,8328,65,4292003,115151,17665,10401,119042,4268163,256,98814,90203,63189]

theorem envBound31361 : H12AffineFastState.Bounded env31361 := by
  intro p hp
  have h : env31361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31340_31361 : H12AffineEnvironment.transform 20 4161 env31340 = env31361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31340 == env31361) = true)

theorem identity31361 : scanCanonicalize (H12AffineFastState.compose env31361 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4161,4194304,16,21763,8328,65,4218280,57796,17665,10401,61705,4194440,256,41461,16464,63189]

theorem envBound31362 : H12AffineFastState.Bounded env31362 := by
  intro p hp
  have h : env31362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31361_31362 : H12AffineEnvironment.transform 15 8203 env31361 = env31362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31361 == env31362) = true)

theorem identity31362 : scanCanonicalize (H12AffineFastState.compose env31362 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31362 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env31363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8203,131072,157873,1024,0,4161,4194304,16,21763,8328,65,4218280,25029,17665,10401,28936,4194440,256,8692,16464,30420]

theorem envBound31363 : H12AffineFastState.Bounded env31363 := by
  intro p hp
  have h : env31363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31362_31363 : H12AffineEnvironment.transform 14 1 env31362 = env31363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31362 == env31363) = true)

def env31364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,131072,157753,1024,0,4161,4194304,16,21763,8192,65,4218144,24909,17665,10281,28936,4194304,256,8572,16464,30300]

theorem envBound31364 : H12AffineFastState.Bounded env31364 := by
  intro p hp
  have h : env31364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31363_31364 : H12AffineEnvironment.transform 6 8 env31363 = env31364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31363 == env31364) = true)

theorem identity31364 : scanCanonicalize (H12AffineFastState.compose env31364 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound31364 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,5393,32040,1024,0,4161,4194304,16,21763,8192,65,4218144,24909,17665,10281,28936,4194304,256,8572,16464,30300]

theorem envBound31365 : H12AffineFastState.Bounded env31365 := by
  intro p hp
  have h : env31365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31364_31365 : H12AffineEnvironment.transform 16 5393 env31364 = env31365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env31364 == env31365) = true)

theorem identity31365 : scanCanonicalize (H12AffineFastState.compose env31365 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound31365 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env31366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,5393,32040,1024,0,4161,8572,16,21763,8192,65,31836,24909,17665,10281,28936,8572,256,8572,16464,30300]

theorem envBound31366 : H12AffineFastState.Bounded env31366 := by
  intro p hp
  have h : env31366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31365_31366 : H12AffineEnvironment.transform 21 8572 env31365 = env31366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env31365 == env31366) = true)

theorem identity31366 : scanCanonicalize (H12AffineFastState.compose env31366 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31366 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env31367 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8192,16384,1,8203,5188,31869,1024,0,4161,8233,16,21590,8192,65,31836,24600,17492,10281,28765,8233,85,8233,16464,30300]

theorem envBound31367 : H12AffineFastState.Bounded env31367 := by
  intro p hp
  have h : env31367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31366_31367 : H12AffineEnvironment.transform 7 85 env31366 = env31367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31366 == env31367) = true)

theorem identity31367 : scanCanonicalize (H12AffineFastState.compose env31367 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound31367 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env31368 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,9,16384,1,2,5188,23668,1024,0,4161,32,16,21590,9,65,23637,16401,17492,2080,20564,32,85,32,16464,22101]

theorem envBound31368 : H12AffineFastState.Bounded env31368 := by
  intro p hp
  have h : env31368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31367_31368 : H12AffineEnvironment.transform 12 9 env31367 = env31368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env31367 == env31368) = true)

theorem identity31368 : scanCanonicalize (H12AffineFastState.compose env31368 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3141) := by decide +kernel

theorem selectedBound31368 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env31369 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,3141,9,16384,1,2,2049,16433,1024,0,3076,32,16,18451,9,65,16400,16401,17492,2080,19473,32,85,32,16464,18960]

theorem envBound31369 : H12AffineFastState.Bounded env31369 := by
  intro p hp
  have h : env31369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31368_31369 : H12AffineEnvironment.transform 11 3141 env31368 = env31369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3141 env31368 == env31369) = true)

def env31370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,131072,157752,1024,0,4161,4194304,16,21763,8193,65,4218145,24908,17665,10280,28936,4194305,256,8573,16464,30301]

theorem envBound31370 : H12AffineFastState.Bounded env31370 := by
  intro p hp
  have h : env31370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31363_31370 : H12AffineEnvironment.transform 6 9 env31363 = env31370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31363 == env31370) = true)

theorem identity31370 : scanCanonicalize (H12AffineFastState.compose env31370 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound31370 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,13389,23669,1024,0,4161,4194304,16,21763,8193,65,4218145,24908,17665,10280,28936,4194305,256,8573,16464,30301]

theorem envBound31371 : H12AffineFastState.Bounded env31371 := by
  intro p hp
  have h : env31371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31370_31371 : H12AffineEnvironment.transform 16 13389 env31370 = env31371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env31370 == env31371) = true)

theorem identity31371 : scanCanonicalize (H12AffineFastState.compose env31371 (packedSelected [0,7,10,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31371 : packedSelected [0,7,10,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env31372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1,8203,13389,2340,1024,0,4161,4194304,16,82,8193,65,4196464,13341,4176,10280,9305,4194305,256,8573,5377,8972]

theorem envBound31372 : H12AffineFastState.Bounded env31372 := by
  intro p hp
  have h : env31372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31371_31372 : H12AffineEnvironment.transform 13 5457 env31371 = env31372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31371 == env31372) = true)

theorem identity31372 : scanCanonicalize (H12AffineFastState.compose env31372 (packedSelected [0,4,7,9,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 12361) := by decide +kernel

theorem selectedBound31372 : packedSelected [0,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env31373 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1,8203,13389,2340,1024,0,4161,12361,16,82,8193,65,14393,13341,4176,10280,9305,12360,256,8573,5377,8972]

theorem envBound31373 : H12AffineFastState.Bounded env31373 := by
  intro p hp
  have h : env31373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31372_31373 : H12AffineEnvironment.transform 21 12361 env31372 = env31373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 12361 env31372 == env31373) = true)

theorem identity31373 : scanCanonicalize (H12AffineFastState.compose env31373 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31373 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env31374 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,1,8203,13341,2340,1024,0,4113,12313,16,2,8193,17,14393,13341,4096,10280,9225,12312,256,8493,5377,8972]

theorem envBound31374 : H12AffineFastState.Bounded env31374 := by
  intro p hp
  have h : env31374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31373_31374 : H12AffineEnvironment.transform 5 16 env31373 = env31374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31373 == env31374) = true)

theorem identity31374 : scanCanonicalize (H12AffineFastState.compose env31374 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound31374 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31375 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,8192,3344,1,8203,11276,2340,1024,0,2048,10248,16,2,8193,17,8232,11276,2065,10280,9225,10249,256,8493,3344,8972]

theorem envBound31375 : H12AffineFastState.Bounded env31375 := by
  intro p hp
  have h : env31375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31374_31375 : H12AffineEnvironment.transform 11 2065 env31374 = env31375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env31374 == env31375) = true)

theorem identity31375 : scanCanonicalize (H12AffineFastState.compose env31375 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound31375 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env31376 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2065,2089,3344,1,2082,1061,2340,1024,0,2048,33,16,2,2088,17,2049,1061,2065,1,3104,32,256,2308,3344,2853]

theorem envBound31376 : H12AffineFastState.Bounded env31376 := by
  intro p hp
  have h : env31376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31375_31376 : H12AffineEnvironment.transform 12 2089 env31375 = env31376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env31375 == env31376) = true)

theorem identity31376 : scanCanonicalize (H12AffineFastState.compose env31376 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound31376 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31377 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,49,9,1328,1,2,1061,260,1024,0,32,33,16,2,8,17,33,1061,49,1,1024,32,256,292,1328,773]

theorem envBound31377 : H12AffineFastState.Bounded env31377 := by
  intro p hp
  have h : env31377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31376_31377 : H12AffineEnvironment.transform 10 32 env31376 = env31377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env31376 == env31377) = true)

theorem identity31377 : scanCanonicalize (H12AffineFastState.compose env31377 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31377 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31378 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,49,9,1045,1,2,1061,33,1024,0,32,33,16,2,8,17,33,1061,49,1,1024,32,37,1,1045,544]

theorem envBound31378 : H12AffineFastState.Bounded env31378 := by
  intro p hp
  have h : env31378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31377_31378 : H12AffineEnvironment.transform 7 37 env31377 = env31378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31377 == env31378) = true)

theorem identity31378 : scanCanonicalize (H12AffineFastState.compose env31378 (packedSelected [0,1,5] rootPS)) = affineNative (2^(9+1) ^^^ 532) := by decide +kernel

theorem selectedBound31378 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env31379 : List Nat := [2,4,8,16,32,16,9,37,512,532,32,49,9,513,1,2,561,33,532,0,32,33,16,2,8,17,33,561,49,1,532,32,37,1,513,544]

theorem envBound31379 : H12AffineFastState.Bounded env31379 := by
  intro p hp
  have h : env31379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31378_31379 : H12AffineEnvironment.transform 9 532 env31378 = env31379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 532 env31378 == env31379) = true)

def env31380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773746,115150,10507600,8399024,10600786,4268162,256,8487407,8478794,10544773]

theorem envBound31380 : H12AffineFastState.Bounded env31380 := by
  intro p hp
  have h : env31380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31292_31380 : H12AffineEnvironment.transform 17 190641 env31292 = env31380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env31292 == env31380) = true)

def env31381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,2114883,8328,65,4292002,115150,17664,2111712,119042,4268162,256,2199999,2191386,63189]

theorem envBound31381 : H12AffineFastState.Bounded env31381 := by
  intro p hp
  have h : env31381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31380_31381 : H12AffineEnvironment.transform 22 2101328 env31380 = env31381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env31380 == env31381) = true)

def env31382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,21763,8328,65,4292002,115150,17664,10400,119042,4268162,256,98815,90202,63189]

theorem envBound31382 : H12AffineFastState.Bounded env31382 := by
  intro p hp
  have h : env31382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31381_31382 : H12AffineEnvironment.transform 20 4160 env31381 = env31382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31381 == env31382) = true)

def env31383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21763,8192,65,4291882,115014,17664,10280,119042,4268042,256,98679,90202,63069]

theorem envBound31383 : H12AffineFastState.Bounded env31383 := by
  intro p hp
  have h : env31383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31382_31383 : H12AffineEnvironment.transform 6 8 env31382 = env31383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31382 == env31383) = true)

theorem identity31383 : scanCanonicalize (H12AffineFastState.compose env31383 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound31383 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,32040,1024,32769,4160,4194304,16,21763,8192,65,4291882,115014,17664,10280,119042,4268042,256,98679,90202,63069]

theorem envBound31384 : H12AffineFastState.Bounded env31384 := by
  intro p hp
  have h : env31384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31383_31384 : H12AffineEnvironment.transform 16 38161 env31383 = env31384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env31383 == env31384) = true)

theorem identity31384 : scanCanonicalize (H12AffineFastState.compose env31384 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound31384 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env31385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,32040,1024,32769,4160,4194304,16,21763,8192,65,4229153,13389,17664,10280,9225,4248833,256,29820,38225,63069]

theorem envBound31385 : H12AffineFastState.Bounded env31385 := by
  intro p hp
  have h : env31385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31384_31385 : H12AffineEnvironment.transform 15 62731 env31384 = env31385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env31384 == env31385) = true)

theorem identity31385 : scanCanonicalize (H12AffineFastState.compose env31385 (packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31385 : packedSelected [0,5,7,9,12,14,16,22,24,26,38] rootPS < 2^1333 := by decide +kernel

def env31386 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62590,37988,31837,1024,32769,4160,4194304,16,21622,8192,65,4229153,13389,17525,10280,9225,4248692,117,29820,37924,63069]

theorem envBound31386 : H12AffineFastState.Bounded env31386 := by
  intro p hp
  have h : env31386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31385_31386 : H12AffineEnvironment.transform 7 117 env31385 = env31386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31385 == env31386) = true)

theorem identity31386 : scanCanonicalize (H12AffineFastState.compose env31386 (packedSelected [0,2,4,6,7,8,9,10,12,14,15,18,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound31386 : packedSelected [0,2,4,6,7,8,9,10,12,14,15,18,28,32] rootPS < 2^1333 := by decide +kernel

def env31387 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,62590,37988,31837,1024,32769,4160,21588,16,21622,8192,65,56437,13389,17525,10280,9225,32800,117,29820,37924,63069]

theorem envBound31387 : H12AffineFastState.Bounded env31387 := by
  intro p hp
  have h : env31387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31386_31387 : H12AffineEnvironment.transform 21 21588 env31386 = env31387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env31386 == env31387) = true)

theorem identity31387 : scanCanonicalize (H12AffineFastState.compose env31387 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound31387 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env31388 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,21620,8202,16400,31837,1024,21621,4160,21588,16,21622,8192,65,2049,13389,17525,10280,9225,21588,117,29820,16464,8745]

theorem envBound31388 : H12AffineFastState.Bounded env31388 := by
  intro p hp
  have h : env31388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31387_31388 : H12AffineEnvironment.transform 14 21620 env31387 = env31388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env31387 == env31388) = true)

theorem identity31388 : scanCanonicalize (H12AffineFastState.compose env31388 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31388 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31389 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13325,8313,8202,13341,2128,1024,8312,4160,8281,16,8315,8192,65,2049,13389,12408,10280,9225,8281,117,113,13405,8745]

theorem envBound31389 : H12AffineFastState.Bounded env31389 := by
  intro p hp
  have h : env31389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31388_31389 : H12AffineEnvironment.transform 13 13325 env31388 = env31389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env31388 == env31389) = true)

theorem identity31389 : scanCanonicalize (H12AffineFastState.compose env31389 (packedSelected [0,1,4,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound31389 : packedSelected [0,1,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env31390 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,6200,3125,6209,6194,3109,2128,1024,6208,4160,6241,16,6211,6200,65,2049,3189,2112,4112,7217,6241,117,113,3173,6673]

theorem envBound31390 : H12AffineFastState.Bounded env31390 := by
  intro p hp
  have h : env31390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31389_31390 : H12AffineEnvironment.transform 12 6200 env31389 = env31390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env31389 == env31390) = true)

theorem identity31390 : scanCanonicalize (H12AffineFastState.compose env31390 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31390 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31391 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,6200,2048,6209,6194,2064,2128,53,6208,4160,6241,16,6211,6200,65,2049,2112,2112,4112,6148,6241,117,113,2128,6673]

theorem envBound31391 : H12AffineFastState.Bounded env31391 := by
  intro p hp
  have h : env31391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31390_31391 : H12AffineEnvironment.transform 9 53 env31390 = env31391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31390 == env31391) = true)

theorem identity31391 : scanCanonicalize (H12AffineFastState.compose env31391 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound31391 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env31392 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2113,121,2048,0,115,2064,2128,53,1,2049,32,16,2,121,65,2049,2112,2112,2129,69,32,117,113,2128,592]

theorem envBound31392 : H12AffineFastState.Bounded env31392 := by
  intro p hp
  have h : env31392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31391_31392 : H12AffineEnvironment.transform 11 2113 env31391 = env31392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env31391 == env31392) = true)

theorem identity31392 : scanCanonicalize (H12AffineFastState.compose env31392 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31392 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env31393 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2064,40,2048,0,34,2064,2049,53,1,2049,32,16,2,40,16,2049,2065,2065,2048,20,32,36,32,2049,513]

theorem envBound31393 : H12AffineFastState.Bounded env31393 := by
  intro p hp
  have h : env31393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31392_31393 : H12AffineEnvironment.transform 5 17 env31392 = env31393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31392 == env31393) = true)

theorem identity31393 : scanCanonicalize (H12AffineFastState.compose env31393 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31394 : List Nat := [2,4,8,16,0,17,8,4,512,21,2048,2064,8,2048,0,2,2064,2049,21,1,2049,0,16,2,8,16,2049,2065,2065,2048,20,0,4,0,2049,513]

theorem envBound31394 : H12AffineFastState.Bounded env31394 := by
  intro p hp
  have h : env31394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31393_31394 : H12AffineEnvironment.transform 4 0 env31393 = env31394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31393 == env31394) = true)

theorem identity31394 : scanCanonicalize (H12AffineFastState.compose env31394 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound31394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31395 : List Nat := [2,4,8,16,0,17,8,4,512,21,16,0,8,16,0,2,0,17,21,1,17,0,16,2,8,16,17,1,1,16,20,0,4,0,17,513]

theorem envBound31395 : H12AffineFastState.Bounded env31395 := by
  intro p hp
  have h : env31395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31394_31395 : H12AffineEnvironment.transform 10 16 env31394 = env31395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env31394 == env31395) = true)

def env31396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,4194304,16,21763,8193,65,4291883,115015,17664,10281,119042,4268043,256,98678,90202,63068]

theorem envBound31396 : H12AffineFastState.Bounded env31396 := by
  intro p hp
  have h : env31396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31382_31396 : H12AffineEnvironment.transform 6 9 env31382 = env31396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31382 == env31396) = true)

theorem identity31396 : scanCanonicalize (H12AffineFastState.compose env31396 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound31396 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56436,1024,32769,4160,4194304,16,21763,8193,65,4291883,115015,17664,10281,119042,4268043,256,98678,90202,63068]

theorem envBound31397 : H12AffineFastState.Bounded env31397 := by
  intro p hp
  have h : env31397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31396_31397 : H12AffineEnvironment.transform 16 13388 env31396 = env31397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env31396 == env31397) = true)

theorem identity31397 : scanCanonicalize (H12AffineFastState.compose env31397 (packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS)) = affineNative (2^(21+1) ^^^ 87159) := by decide +kernel

theorem selectedBound31397 : packedSelected [0,1,2,4,6,7,8,10,14,15,16,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env31398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,56436,1024,32769,4160,87159,16,21763,8193,65,10588,115015,17664,10281,119042,29820,256,98678,90202,63068]

theorem envBound31398 : H12AffineFastState.Bounded env31398 := by
  intro p hp
  have h : env31398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31397_31398 : H12AffineEnvironment.transform 21 87159 env31397 = env31398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87159 env31397 == env31398) = true)

theorem identity31398 : scanCanonicalize (H12AffineFastState.compose env31398 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31398 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env31399 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,13388,23668,1024,1,4160,87159,16,21763,8193,65,10588,82247,17664,10281,86274,29820,256,65910,90202,30300]

theorem envBound31399 : H12AffineFastState.Bounded env31399 := by
  intro p hp
  have h : env31399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31398_31399 : H12AffineEnvironment.transform 14 0 env31398 = env31399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31398 == env31399) = true)

theorem identity31399 : scanCanonicalize (H12AffineFastState.compose env31399 (packedSelected [1,4,8,9,11,14,16,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31399 : packedSelected [1,4,8,9,11,14,16,18,19] rootPS < 2^1333 := by decide +kernel

def env31400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,65536,5393,23668,1024,1,4160,87159,16,21763,348,65,2049,82247,17664,2420,86274,21793,256,65910,82183,22273]

theorem envBound31400 : H12AffineFastState.Bounded env31400 := by
  intro p hp
  have h : env31400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31399_31400 : H12AffineEnvironment.transform 12 349 env31399 = env31400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31399 == env31400) = true)

theorem identity31400 : scanCanonicalize (H12AffineFastState.compose env31400 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound31400 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,21590,5393,23668,1024,1,4160,33,16,21763,348,65,2049,5393,17664,2420,1364,21793,256,21792,5457,22273]

theorem envBound31401 : H12AffineFastState.Bounded env31401 := by
  intro p hp
  have h : env31401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31400_31401 : H12AffineEnvironment.transform 15 21590 env31400 = env31401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env31400 == env31401) = true)

theorem identity31401 : scanCanonicalize (H12AffineFastState.compose env31401 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound31401 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env31402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5408,0,374,5393,2388,1024,1,4160,33,16,35,348,65,2049,5393,4128,2420,1364,1,256,0,5457,545]

theorem envBound31402 : H12AffineFastState.Bounded env31402 := by
  intro p hp
  have h : env31402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31401_31402 : H12AffineEnvironment.transform 13 5408 env31401 = env31402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env31401 == env31402) = true)

theorem identity31402 : scanCanonicalize (H12AffineFastState.compose env31402 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31402 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31403 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5408,0,263,5393,2341,1024,1,4145,33,16,35,301,48,2049,5393,4128,2309,1317,1,256,0,5408,545]

theorem envBound31403 : H12AffineFastState.Bounded env31403 := by
  intro p hp
  have h : env31403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31402_31403 : H12AffineEnvironment.transform 5 49 env31402 = env31403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31402 == env31403) = true)

theorem identity31403 : scanCanonicalize (H12AffineFastState.compose env31403 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31403 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31404 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2308,1024,1,4112,0,16,2,268,17,2049,5393,4097,2309,1284,1,256,0,5377,512]

theorem envBound31404 : H12AffineFastState.Bounded env31404 := by
  intro p hp
  have h : env31404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31403_31404 : H12AffineEnvironment.transform 4 1 env31403 = env31404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31403 == env31404) = true)

theorem identity31404 : scanCanonicalize (H12AffineFastState.compose env31404 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31404 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31405 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,0,3,5141,2048,1024,1,4112,0,16,2,8,17,2049,5141,4097,2049,1024,1,4,0,5125,512]

theorem envBound31405 : H12AffineFastState.Bounded env31405 := by
  intro p hp
  have h : env31405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31404_31405 : H12AffineEnvironment.transform 7 4 env31404 = env31405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31404 == env31405) = true)

theorem identity31405 : scanCanonicalize (H12AffineFastState.compose env31405 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound31405 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31406 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1566,4096,9,5125,0,3,5141,1566,1024,1,4112,0,16,2,8,17,1567,5141,4097,1567,1024,1,4,0,5125,512]

theorem envBound31406 : H12AffineFastState.Bounded env31406 := by
  intro p hp
  have h : env31406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31405_31406 : H12AffineEnvironment.transform 10 1566 env31405 = env31406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env31405 == env31406) = true)

theorem identity31406 : scanCanonicalize (H12AffineFastState.compose env31406 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1540) := by decide +kernel

theorem selectedBound31406 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31407 : List Nat := [2,4,8,16,1,16,9,4,512,1024,1566,1540,9,513,0,3,529,1566,1024,1,1556,0,16,2,8,17,1567,529,1541,1567,1024,1,4,0,513,512]

theorem envBound31407 : H12AffineFastState.Bounded env31407 := by
  intro p hp
  have h : env31407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31406_31407 : H12AffineEnvironment.transform 11 1540 env31406 = env31407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1540 env31406 == env31407) = true)

theorem identity31407 : scanCanonicalize (H12AffineFastState.compose env31407 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound31407 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31408 : List Nat := [2,4,8,16,1,16,9,4,512,15,529,523,9,513,0,3,529,529,15,1,539,0,16,2,8,17,528,529,522,528,15,1,4,0,513,512]

theorem envBound31408 : H12AffineFastState.Bounded env31408 := by
  intro p hp
  have h : env31408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31407_31408 : H12AffineEnvironment.transform 9 15 env31407 = env31408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env31407 == env31408) = true)

theorem identity31408 : scanCanonicalize (H12AffineFastState.compose env31408 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31408 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31409 : List Nat := [2,4,8,11,1,11,9,4,512,15,522,523,9,513,0,3,522,522,15,1,512,0,11,2,8,10,523,522,522,523,15,1,4,0,513,512]

theorem envBound31409 : H12AffineFastState.Bounded env31409 := by
  intro p hp
  have h : env31409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31408_31409 : H12AffineEnvironment.transform 3 11 env31408 = env31409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31408 == env31409) = true)

theorem identity31409 : scanCanonicalize (H12AffineFastState.compose env31409 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound31409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31410 : List Nat := [2,4,8,11,1,11,9,4,4,15,14,15,9,5,0,3,14,14,15,1,4,0,11,2,8,10,15,14,14,15,15,1,4,0,5,4]

theorem envBound31410 : H12AffineFastState.Bounded env31410 := by
  intro p hp
  have h : env31410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31409_31410 : H12AffineEnvironment.transform 8 4 env31409 = env31410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env31409 == env31410) = true)

theorem identity31410 : scanCanonicalize (H12AffineFastState.compose env31410 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31411 : List Nat := [1,4,8,8,1,8,9,4,4,12,13,12,9,5,0,0,13,13,12,1,4,0,8,1,8,9,12,13,13,12,12,1,4,0,5,4]

theorem envBound31411 : H12AffineFastState.Bounded env31411 := by
  intro p hp
  have h : env31411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31410_31411 : H12AffineEnvironment.transform 0 1 env31410 = env31411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31410 == env31411) = true)

def env31412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,21762,8328,65,4292002,115150,17664,10401,119042,4268162,256,98814,90203,63189]

theorem envBound31412 : H12AffineFastState.Bounded env31412 := by
  intro p hp
  have h : env31412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31381_31412 : H12AffineEnvironment.transform 20 4161 env31381 = env31412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31381 == env31412) = true)

theorem identity31412 : scanCanonicalize (H12AffineFastState.compose env31412 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound31412 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180272,17,21762,8328,65,245138,115150,17664,10401,119042,254130,256,98814,90203,63189]

theorem envBound31413 : H12AffineFastState.Bounded env31413 := by
  intro p hp
  have h : env31413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31412_31413 : H12AffineEnvironment.transform 21 180272 env31412 = env31413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env31412 == env31413) = true)

def env31414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180272,17,21762,8192,65,245018,115014,17664,10281,119042,254010,256,98678,90203,63069]

theorem envBound31414 : H12AffineFastState.Bounded env31414 := by
  intro p hp
  have h : env31414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31413_31414 : H12AffineEnvironment.transform 6 8 env31413 = env31414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31413 == env31414) = true)

theorem identity31414 : scanCanonicalize (H12AffineFastState.compose env31414 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31414 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179513,1024,32769,4161,169264,17,2,8192,65,245018,103494,4096,10281,99330,243002,256,98678,79195,41821]

theorem envBound31415 : H12AffineFastState.Bounded env31415 := by
  intro p hp
  have h : env31415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31414_31415 : H12AffineEnvironment.transform 13 5376 env31414 = env31415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31414 == env31415) = true)

theorem identity31415 : scanCanonicalize (H12AffineFastState.compose env31415 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31415 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env31416 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179513,1024,32769,4113,169264,17,2,8192,17,245018,103446,4096,10281,99330,243002,256,98598,79115,41741]

theorem envBound31416 : H12AffineFastState.Bounded env31416 := by
  intro p hp
  have h : env31416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31415_31416 : H12AffineEnvironment.transform 5 16 env31415 = env31416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31415 == env31416) = true)

theorem identity31416 : scanCanonicalize (H12AffineFastState.compose env31416 (packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound31416 : packedSelected [0,7,9,10,11,12,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env31417 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,33030,131072,179513,1024,32769,4113,169264,17,2,8192,17,146460,5392,4096,10281,1284,144444,256,32,46093,41741]

theorem envBound31417 : H12AffineFastState.Bounded env31417 := by
  intro p hp
  have h : env31417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31416_31417 : H12AffineEnvironment.transform 15 33030 env31416 = env31417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env31416 == env31417) = true)

theorem identity31417 : scanCanonicalize (H12AffineFastState.compose env31417 (packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound31417 : packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env31418 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,33030,5392,43049,1024,32769,4113,32800,17,2,8192,17,10508,5392,4096,10281,1284,8492,256,32,46093,41741]

theorem envBound31418 : H12AffineFastState.Bounded env31418 := by
  intro p hp
  have h : env31418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31417_31418 : H12AffineEnvironment.transform 16 5392 env31417 = env31418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env31417 == env31418) = true)

theorem identity31418 : scanCanonicalize (H12AffineFastState.compose env31418 (packedSelected [2,6,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31418 : packedSelected [2,6,10,12,14] rootPS < 2^1333 := by decide +kernel

def env31419 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,0,262,5392,10281,1024,1,4113,32,17,2,8192,17,10508,5392,4096,10281,1284,8492,256,32,13325,8973]

theorem envBound31419 : H12AffineFastState.Bounded env31419 := by
  intro p hp
  have h : env31419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31418_31419 : H12AffineEnvironment.transform 14 0 env31418 = env31419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31418 == env31419) = true)

theorem identity31419 : scanCanonicalize (H12AffineFastState.compose env31419 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound31419 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31420 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7181,5376,0,262,5392,5156,1024,1,4113,32,17,2,7181,17,5377,5392,4096,5156,1284,7457,256,32,2048,7936]

theorem envBound31420 : H12AffineFastState.Bounded env31420 := by
  intro p hp
  have h : env31420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31419_31420 : H12AffineEnvironment.transform 12 7181 env31419 = env31420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env31419 == env31420) = true)

def env31421 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180272,17,21762,8193,65,245019,115015,17664,10280,119042,254011,256,98679,90203,63068]

theorem envBound31421 : H12AffineFastState.Bounded env31421 := by
  intro p hp
  have h : env31421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31413_31421 : H12AffineEnvironment.transform 6 9 env31413 = env31421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31413 == env31421) = true)

theorem identity31421 : scanCanonicalize (H12AffineFastState.compose env31421 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31421 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,138341,1024,29788,4161,144493,17,21762,8193,65,215366,79130,17664,10280,75103,201830,256,95530,90203,513]

theorem envBound31422 : H12AffineFastState.Bounded env31422 := by
  intro p hp
  have h : env31422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31421_31422 : H12AffineEnvironment.transform 14 29789 env31421 = env31422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31421 == env31422) = true)

theorem identity31422 : scanCanonicalize (H12AffineFastState.compose env31422 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31422 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,97407,1024,29788,4161,87159,17,21762,8193,65,10588,79130,17664,10280,75103,29820,256,95530,90203,513]

theorem envBound31423 : H12AffineFastState.Bounded env31423 := by
  intro p hp
  have h : env31423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31422_31423 : H12AffineEnvironment.transform 16 90138 env31422 = env31423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31422 == env31423) = true)

theorem identity31423 : scanCanonicalize (H12AffineFastState.compose env31423 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound31423 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31424 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5392,2421,1024,29788,4161,8573,17,21762,8193,65,10588,16400,17664,10280,20565,29820,256,32,5457,513]

theorem envBound31424 : H12AffineFastState.Bounded env31424 := by
  intro p hp
  have h : env31424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31423_31424 : H12AffineEnvironment.transform 15 29962 env31423 = env31424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env31423 == env31424) = true)

theorem identity31424 : scanCanonicalize (H12AffineFastState.compose env31424 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31424 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,21591,5392,2421,1024,21761,4161,32,17,21762,348,65,2049,16400,17664,2421,20565,21793,256,32,5457,513]

theorem envBound31425 : H12AffineFastState.Bounded env31425 := by
  intro p hp
  have h : env31425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31424_31425 : H12AffineEnvironment.transform 12 349 env31424 = env31425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31424 == env31425) = true)

theorem identity31425 : scanCanonicalize (H12AffineFastState.compose env31425 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31425 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1296,1095,5392,2421,1024,1297,4161,32,17,1298,348,65,2049,4096,5392,2421,69,1329,256,32,5457,513]

theorem envBound31426 : H12AffineFastState.Bounded env31426 := by
  intro p hp
  have h : env31426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31425_31426 : H12AffineEnvironment.transform 13 4112 env31425 = env31426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31425 == env31426) = true)

theorem identity31426 : scanCanonicalize (H12AffineFastState.compose env31426 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound31426 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,4096,349,4112,1296,1095,5392,1077,1024,1297,4161,32,17,1298,348,65,1345,4096,5392,1077,69,1329,256,32,5457,513]

theorem envBound31427 : H12AffineFastState.Bounded env31427 := by
  intro p hp
  have h : env31427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31426_31427 : H12AffineEnvironment.transform 10 1344 env31426 = env31427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env31426 == env31427) = true)

theorem identity31427 : scanCanonicalize (H12AffineFastState.compose env31427 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound31427 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1344,1281,349,1297,1296,1095,17,1077,1024,1297,1344,32,17,1298,348,65,1345,1281,17,1077,69,1329,256,32,80,513]

theorem envBound31428 : H12AffineFastState.Bounded env31428 := by
  intro p hp
  have h : env31428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31427_31428 : H12AffineEnvironment.transform 11 1281 env31427 = env31428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env31427 == env31428) = true)

theorem identity31428 : scanCanonicalize (H12AffineFastState.compose env31428 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31428 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env31429 : List Nat := [2,4,8,16,32,64,9,256,512,101,293,356,349,372,373,34,17,80,101,372,293,32,17,375,348,65,292,356,17,80,69,340,256,32,80,513]

theorem envBound31429 : H12AffineFastState.Bounded env31429 := by
  intro p hp
  have h : env31429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31428_31429 : H12AffineEnvironment.transform 9 101 env31428 = env31429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31428 == env31429) = true)

def env31430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,2114883,8328,65,4292003,115150,17665,2111713,119043,4268162,256,2199998,2191387,63188]

theorem envBound31430 : H12AffineFastState.Bounded env31430 := by
  intro p hp
  have h : env31430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31380_31430 : H12AffineEnvironment.transform 22 2101329 env31380 = env31430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env31380 == env31430) = true)

def env31431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,21763,8328,65,4292003,115150,17665,10401,119043,4268162,256,98814,90203,63188]

theorem envBound31431 : H12AffineFastState.Bounded env31431 := by
  intro p hp
  have h : env31431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31430_31431 : H12AffineEnvironment.transform 20 4160 env31430 = env31431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31430 == env31431) = true)

theorem identity31431 : scanCanonicalize (H12AffineFastState.compose env31431 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound31431 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,144613,17,21763,8328,65,215366,115150,17665,10401,119043,201831,256,98814,90203,63188]

theorem envBound31432 : H12AffineFastState.Bounded env31432 := by
  intro p hp
  have h : env31432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31431_31432 : H12AffineEnvironment.transform 21 144613 env31431 = env31432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env31431 == env31432) = true)

def env31433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,144493,17,21763,8192,65,215366,115014,17665,10281,119043,201831,256,98678,90203,63068]

theorem envBound31433 : H12AffineFastState.Bounded env31433 := by
  intro p hp
  have h : env31433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31432_31433 : H12AffineEnvironment.transform 6 8 env31432 = env31433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31432 == env31433) = true)

theorem identity31433 : scanCanonicalize (H12AffineFastState.compose env31433 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31433 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,179512,1024,32769,4160,144493,17,2,8192,65,203847,103495,4096,10281,99330,201831,256,98678,79194,41821]

theorem envBound31434 : H12AffineFastState.Bounded env31434 := by
  intro p hp
  have h : env31434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31433_31434 : H12AffineEnvironment.transform 13 5377 env31433 = env31434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31433 == env31434) = true)

theorem identity31434 : scanCanonicalize (H12AffineFastState.compose env31434 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound31434 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env31435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8312,65536,131072,138560,1024,8313,4160,144493,17,2,8192,65,203847,78911,4096,10281,74874,201831,256,73998,79194,805]

theorem envBound31435 : H12AffineFastState.Bounded env31435 := by
  intro p hp
  have h : env31435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31434_31435 : H12AffineEnvironment.transform 14 8312 env31434 = env31435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env31434 == env31435) = true)

theorem identity31435 : scanCanonicalize (H12AffineFastState.compose env31435 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31435 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env31436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8312,343,131072,138560,1024,8313,4160,144493,17,2,8192,65,138512,13672,4096,10281,9517,136496,256,8281,13325,805]

theorem envBound31436 : H12AffineFastState.Bounded env31436 := by
  intro p hp
  have h : env31436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31435_31436 : H12AffineEnvironment.transform 15 343 env31435 = env31436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31435 == env31436) = true)

theorem identity31436 : scanCanonicalize (H12AffineFastState.compose env31436 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 13672) := by decide +kernel

theorem selectedBound31436 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env31437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8312,343,13672,10280,1024,8313,4160,261,17,2,8192,65,10360,13672,4096,10281,9517,8280,256,8281,13325,805]

theorem envBound31437 : H12AffineFastState.Bounded env31437 := by
  intro p hp
  have h : env31437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31436_31437 : H12AffineEnvironment.transform 16 13672 env31436 = env31437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13672 env31436 == env31437) = true)

theorem identity31437 : scanCanonicalize (H12AffineFastState.compose env31437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31438 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,8192,4404,8312,343,12637,10280,53,8313,4160,261,17,2,8192,65,10360,12637,4096,10281,8472,8280,256,8281,12344,805]

theorem envBound31438 : H12AffineFastState.Bounded env31438 := by
  intro p hp
  have h : env31438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31437_31438 : H12AffineEnvironment.transform 9 53 env31437 = env31438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31437 == env31438) = true)

theorem identity31438 : scanCanonicalize (H12AffineFastState.compose env31438 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31438 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env31439 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,121,4404,1,343,4388,2129,53,0,4160,261,17,2,121,65,2049,4388,4096,2128,353,33,256,32,4161,805]

theorem envBound31439 : H12AffineFastState.Bounded env31439 := by
  intro p hp
  have h : env31439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31438_31439 : H12AffineEnvironment.transform 12 121 env31438 = env31439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31438 == env31439) = true)

theorem identity31439 : scanCanonicalize (H12AffineFastState.compose env31439 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound31439 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env31440 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2357,121,2049,1,343,2065,2129,53,0,2421,261,17,2,121,65,2049,2065,2357,2128,353,33,256,32,2420,805]

theorem envBound31440 : H12AffineFastState.Bounded env31440 := by
  intro p hp
  have h : env31440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31439_31440 : H12AffineEnvironment.transform 11 2357 env31439 = env31440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env31439 == env31440) = true)

theorem identity31440 : scanCanonicalize (H12AffineFastState.compose env31440 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31440 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env31441 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2065,121,2049,1,115,2065,2129,53,0,2129,33,17,2,121,65,2049,2065,2065,2128,69,33,36,32,2128,513]

theorem envBound31441 : H12AffineFastState.Bounded env31441 := by
  intro p hp
  have h : env31441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31440_31441 : H12AffineEnvironment.transform 7 36 env31440 = env31441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31440 == env31441) = true)

theorem identity31441 : scanCanonicalize (H12AffineFastState.compose env31441 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31441 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31442 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2049,1,35,2065,2049,53,0,2049,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2048,513]

theorem envBound31442 : H12AffineFastState.Bounded env31442 := by
  intro p hp
  have h : env31442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31441_31442 : H12AffineEnvironment.transform 5 16 env31441 = env31442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31441 == env31442) = true)

def env31443 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,21763,8193,65,215366,115015,17665,10280,119043,201831,256,98679,90203,63069]

theorem envBound31443 : H12AffineFastState.Bounded env31443 := by
  intro p hp
  have h : env31443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31432_31443 : H12AffineEnvironment.transform 6 9 env31432 = env31443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31432 == env31443) = true)

theorem identity31443 : scanCanonicalize (H12AffineFastState.compose env31443 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound31443 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138340,1024,29789,4160,144492,17,21763,8193,65,215366,79131,17665,10280,75103,201831,256,95531,90203,513]

theorem envBound31444 : H12AffineFastState.Bounded env31444 := by
  intro p hp
  have h : env31444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31443_31444 : H12AffineEnvironment.transform 14 29788 env31443 = env31444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env31443 == env31444) = true)

theorem identity31444 : scanCanonicalize (H12AffineFastState.compose env31444 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31444 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,97406,1024,29789,4160,87158,17,21763,8193,65,10588,79131,17665,10280,75103,29821,256,95531,90203,513]

theorem envBound31445 : H12AffineFastState.Bounded env31445 := by
  intro p hp
  have h : env31445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31444_31445 : H12AffineEnvironment.transform 16 90138 env31444 = env31445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31444 == env31445) = true)

theorem identity31445 : scanCanonicalize (H12AffineFastState.compose env31445 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound31445 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,5393,2421,1024,29789,4160,8573,17,21763,8193,65,10588,16400,17665,10280,20564,29821,256,32,5456,513]

theorem envBound31446 : H12AffineFastState.Bounded env31446 := by
  intro p hp
  have h : env31446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31445_31446 : H12AffineEnvironment.transform 15 29963 env31445 = env31446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env31445 == env31446) = true)

theorem identity31446 : scanCanonicalize (H12AffineFastState.compose env31446 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31446 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,21590,5393,2421,1024,21760,4160,32,17,21763,348,65,2049,16400,17665,2421,20564,21792,256,32,5456,513]

theorem envBound31447 : H12AffineFastState.Bounded env31447 := by
  intro p hp
  have h : env31447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31446_31447 : H12AffineEnvironment.transform 12 349 env31446 = env31447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31446 == env31447) = true)

theorem identity31447 : scanCanonicalize (H12AffineFastState.compose env31447 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31447 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1297,1094,5393,2421,1024,1296,4160,32,17,1299,348,65,2049,4096,5393,2421,68,1328,256,32,5456,513]

theorem envBound31448 : H12AffineFastState.Bounded env31448 := by
  intro p hp
  have h : env31448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31447_31448 : H12AffineEnvironment.transform 13 4112 env31447 = env31448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31447 == env31448) = true)

theorem identity31448 : scanCanonicalize (H12AffineFastState.compose env31448 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound31448 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,4096,349,4112,1297,1094,5393,1076,1024,1296,4160,32,17,1299,348,65,1344,4096,5393,1076,68,1328,256,32,5456,513]

theorem envBound31449 : H12AffineFastState.Bounded env31449 := by
  intro p hp
  have h : env31449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31448_31449 : H12AffineEnvironment.transform 10 1345 env31448 = env31449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env31448 == env31449) = true)

theorem identity31449 : scanCanonicalize (H12AffineFastState.compose env31449 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31449 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,17,349,1,1297,1094,1280,1076,1024,1296,81,32,17,1299,348,65,1344,17,1280,1076,68,1328,256,32,1345,513]

theorem envBound31450 : H12AffineFastState.Bounded env31450 := by
  intro p hp
  have h : env31450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31449_31450 : H12AffineEnvironment.transform 11 17 env31449 = env31450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31449 == env31450) = true)

theorem identity31450 : scanCanonicalize (H12AffineFastState.compose env31450 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31450 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env31451 : List Nat := [2,4,8,16,32,64,9,256,512,53,372,17,349,1,292,115,309,1,53,293,81,32,17,294,348,65,373,17,309,1,68,261,256,32,372,513]

theorem envBound31451 : H12AffineFastState.Bounded env31451 := by
  intro p hp
  have h : env31451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31450_31451 : H12AffineEnvironment.transform 9 53 env31450 = env31451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31450 == env31451) = true)

theorem identity31451 : scanCanonicalize (H12AffineFastState.compose env31451 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31451 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31452 : List Nat := [2,4,8,16,32,64,9,37,512,53,81,17,120,1,1,115,16,1,53,0,81,32,17,3,121,65,80,17,16,1,68,32,37,32,81,513]

theorem envBound31452 : H12AffineFastState.Bounded env31452 := by
  intro p hp
  have h : env31452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31451_31452 : H12AffineEnvironment.transform 7 37 env31451 = env31452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31451 == env31452) = true)

theorem identity31452 : scanCanonicalize (H12AffineFastState.compose env31452 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31453 : List Nat := [2,4,8,16,16,64,9,21,512,5,81,17,72,1,1,67,16,1,5,0,81,16,17,3,73,65,80,17,16,1,68,16,21,16,81,513]

theorem envBound31453 : H12AffineFastState.Bounded env31453 := by
  intro p hp
  have h : env31453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31452_31453 : H12AffineEnvironment.transform 4 16 env31452 = env31453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31452 == env31453) = true)

theorem identity31453 : scanCanonicalize (H12AffineFastState.compose env31453 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31453 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31454 : List Nat := [2,4,8,16,16,64,9,21,0,5,81,17,72,1,1,67,16,1,5,0,81,16,17,3,73,65,80,17,16,1,68,16,21,16,81,1]

theorem envBound31454 : H12AffineFastState.Bounded env31454 := by
  intro p hp
  have h : env31454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31453_31454 : H12AffineEnvironment.transform 8 0 env31453 = env31454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31453 == env31454) = true)

theorem identity31454 : scanCanonicalize (H12AffineFastState.compose env31454 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31455 : List Nat := [2,4,8,0,0,64,9,5,0,5,65,1,72,1,1,67,0,1,5,0,65,0,1,3,73,65,64,1,0,1,68,0,5,0,65,1]

theorem envBound31455 : H12AffineFastState.Bounded env31455 := by
  intro p hp
  have h : env31455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31454_31455 : H12AffineEnvironment.transform 3 0 env31454 = env31455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31454 == env31455) = true)

theorem identity31455 : scanCanonicalize (H12AffineFastState.compose env31455 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31455 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31456 : List Nat := [2,4,8,0,0,0,9,5,0,5,1,1,8,1,1,3,0,1,5,0,1,0,1,3,9,1,0,1,0,1,4,0,5,0,1,1]

theorem envBound31456 : H12AffineFastState.Bounded env31456 := by
  intro p hp
  have h : env31456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31455_31456 : H12AffineEnvironment.transform 5 0 env31455 = env31456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31455 == env31456) = true)

def env31457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,21762,8328,65,4292003,115150,17665,10400,119043,4268162,256,98815,90202,63188]

theorem envBound31457 : H12AffineFastState.Bounded env31457 := by
  intro p hp
  have h : env31457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31430_31457 : H12AffineEnvironment.transform 20 4161 env31430 = env31457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31430 == env31457) = true)

theorem identity31457 : scanCanonicalize (H12AffineFastState.compose env31457 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31457 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,138340,1024,29908,4161,4194304,16,21762,8328,65,4292003,79131,17665,10400,75222,4268162,256,95530,90202,513]

theorem envBound31458 : H12AffineFastState.Bounded env31458 := by
  intro p hp
  have h : env31458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31457_31458 : H12AffineEnvironment.transform 14 29909 env31457 = env31458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31457 == env31458) = true)

def env31459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,138340,1024,8660,4161,4194304,16,2,8328,65,4270243,79131,4097,10400,75222,4268162,256,73770,79194,513]

theorem envBound31459 : H12AffineFastState.Bounded env31459 := by
  intro p hp
  have h : env31459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31458_31459 : H12AffineEnvironment.transform 13 5376 env31458 = env31459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31458 == env31459) = true)

theorem identity31459 : scanCanonicalize (H12AffineFastState.compose env31459 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound31459 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1