import H12CloudChart1Data222

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans56445_56468 : H12AffineEnvironment.transform 20 4161 env56445 = env56468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56445 == env56468) = true)

theorem identity56468 : scanCanonicalize (H12AffineFastState.compose env56468 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149860) := by decide +kernel

theorem selectedBound56468 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,21762,8328,65,215367,115150,17665,35188,119043,243123,256,98814,90203,63188]

theorem envBound56469 : H12AffineFastState.Bounded env56469 := by
  intro p hp
  have h : env56469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56468_56469 : H12AffineEnvironment.transform 17 149860 env56468 = env56469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env56468 == env56469) = true)

def env56470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,21762,8192,65,215367,115014,17665,35188,119043,243003,256,98678,90203,63068]

theorem envBound56470 : H12AffineFastState.Bounded env56470 := by
  intro p hp
  have h : env56470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56469_56470 : H12AffineEnvironment.transform 6 8 env56469 = env56470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56469 == env56470) = true)

theorem identity56470 : scanCanonicalize (H12AffineFastState.compose env56470 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound56470 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1024,32769,4161,62589,16,21762,8192,65,75786,115014,17665,35188,119043,119926,256,98678,90203,63068]

theorem envBound56471 : H12AffineFastState.Bounded env56471 := by
  intro p hp
  have h : env56471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56470_56471 : H12AffineEnvironment.transform 16 24909 env56470 = env56471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env56470 == env56471) = true)

theorem identity56471 : scanCanonicalize (H12AffineFastState.compose env56471 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56471 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,10281,1024,32769,4161,41341,16,2,8192,65,75786,103494,4097,35188,99331,98678,256,98678,79195,41820]

theorem envBound56472 : H12AffineFastState.Bounded env56472 := by
  intro p hp
  have h : env56472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56471_56472 : H12AffineEnvironment.transform 13 5376 env56471 = env56472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56471 == env56472) = true)

theorem identity56472 : scanCanonicalize (H12AffineFastState.compose env56472 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56472 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env56473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,13389,10281,1024,8540,4161,32,16,2,8192,65,75786,79131,4097,10281,75102,73771,256,73771,79195,513]

theorem envBound56473 : H12AffineFastState.Bounded env56473 := by
  intro p hp
  have h : env56473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56472_56473 : H12AffineEnvironment.transform 14 8541 env56472 = env56473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56472 == env56473) = true)

theorem identity56473 : scanCanonicalize (H12AffineFastState.compose env56473 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56473 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env56474 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,65536,13341,10281,1024,8460,4113,32,16,2,8192,17,75786,79131,4097,10281,75022,73771,256,73771,79115,513]

theorem envBound56474 : H12AffineFastState.Bounded env56474 := by
  intro p hp
  have h : env56474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56473_56474 : H12AffineEnvironment.transform 5 16 env56473 = env56474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56473 == env56474) = true)

theorem identity56474 : scanCanonicalize (H12AffineFastState.compose env56474 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound56474 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56475 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,262,13341,10281,1024,8460,4113,32,16,2,8192,17,10508,13341,4097,10281,9224,8493,256,8493,13325,513]

theorem envBound56475 : H12AffineFastState.Bounded env56475 := by
  intro p hp
  have h : env56475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56474_56475 : H12AffineEnvironment.transform 15 262 env56474 = env56475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env56474 == env56475) = true)

theorem identity56475 : scanCanonicalize (H12AffineFastState.compose env56475 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3354) := by decide +kernel

theorem selectedBound56475 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env56476 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3354,8192,2074,8461,262,10503,10281,1024,8460,3339,32,16,2,8192,17,10508,10503,3355,10281,9224,8493,256,8493,10519,513]

theorem envBound56476 : H12AffineFastState.Bounded env56476 := by
  intro p hp
  have h : env56476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56475_56476 : H12AffineEnvironment.transform 11 3354 env56475 = env56476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3354 env56475 == env56476) = true)

theorem identity56476 : scanCanonicalize (H12AffineFastState.compose env56476 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound56476 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56477 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3354,50,2074,319,262,2357,2075,1024,318,3339,32,16,2,50,17,2366,2357,3355,2075,1082,287,256,287,2341,513]

theorem envBound56477 : H12AffineFastState.Bounded env56477 := by
  intro p hp
  have h : env56477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56476_56477 : H12AffineEnvironment.transform 12 50 env56476 = env56477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env56476 == env56477) = true)

theorem identity56477 : scanCanonicalize (H12AffineFastState.compose env56477 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound56477 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56478 : List Nat := [2,4,8,16,32,16,8,63,512,1024,2048,3109,50,2074,0,57,2058,2075,1024,1,3124,32,16,2,50,17,2049,2058,3108,2075,1082,32,63,32,2074,513]

theorem envBound56478 : H12AffineFastState.Bounded env56478 := by
  intro p hp
  have h : env56478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56477_56478 : H12AffineEnvironment.transform 7 63 env56477 = env56478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env56477 == env56478) = true)

theorem identity56478 : scanCanonicalize (H12AffineFastState.compose env56478 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound56478 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56479 : List Nat := [2,4,8,16,32,16,8,63,512,14,2048,2091,50,2074,0,57,2058,2075,14,1,2106,32,16,2,50,17,2049,2058,2090,2075,52,32,63,32,2074,513]

theorem envBound56479 : H12AffineFastState.Bounded env56479 := by
  intro p hp
  have h : env56479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56478_56479 : H12AffineEnvironment.transform 9 14 env56478 = env56479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env56478 == env56479) = true)

theorem identity56479 : scanCanonicalize (H12AffineFastState.compose env56479 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56479 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56480 : List Nat := [2,4,8,16,32,16,8,63,49,14,2048,2091,50,2074,0,57,2058,2075,14,1,2106,32,16,2,50,17,2049,2058,2090,2075,52,32,63,32,2074,48]

theorem envBound56480 : H12AffineFastState.Bounded env56480 := by
  intro p hp
  have h : env56480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56479_56480 : H12AffineEnvironment.transform 8 49 env56479 = env56480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56479 == env56480) = true)

theorem identity56480 : scanCanonicalize (H12AffineFastState.compose env56480 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound56480 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56481 : List Nat := [2,4,8,16,32,16,8,63,49,14,16,59,50,10,0,57,26,11,14,1,42,32,16,2,50,17,17,26,58,11,52,32,63,32,10,48]

theorem envBound56481 : H12AffineFastState.Bounded env56481 := by
  intro p hp
  have h : env56481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56480_56481 : H12AffineEnvironment.transform 10 16 env56480 = env56481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env56480 == env56481) = true)

theorem identity56481 : scanCanonicalize (H12AffineFastState.compose env56481 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound56481 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56482 : List Nat := [2,4,8,16,26,16,8,5,11,14,16,1,8,10,0,3,26,11,14,1,16,26,16,2,8,17,17,26,0,11,14,26,5,26,10,10]

theorem envBound56482 : H12AffineFastState.Bounded env56482 := by
  intro p hp
  have h : env56482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56481_56482 : H12AffineEnvironment.transform 4 26 env56481 = env56482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env56481 == env56482) = true)

theorem identity56482 : scanCanonicalize (H12AffineFastState.compose env56482 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56482 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56483 : List Nat := [2,4,5,16,23,16,5,5,6,3,16,1,5,7,0,3,23,6,3,1,16,23,16,2,5,17,17,23,0,6,3,23,5,23,7,7]

theorem envBound56483 : H12AffineFastState.Bounded env56483 := by
  intro p hp
  have h : env56483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56482_56483 : H12AffineEnvironment.transform 2 5 env56482 = env56483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56482 == env56483) = true)

theorem identity56483 : scanCanonicalize (H12AffineFastState.compose env56483 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56483 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56484 : List Nat := [2,4,5,1,6,1,5,5,6,3,1,1,5,7,0,3,6,6,3,1,1,6,1,2,5,0,0,6,0,6,3,6,5,6,7,7]

theorem envBound56484 : H12AffineFastState.Bounded env56484 := by
  intro p hp
  have h : env56484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56483_56484 : H12AffineEnvironment.transform 3 1 env56483 = env56484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56483 == env56484) = true)

theorem identity56484 : scanCanonicalize (H12AffineFastState.compose env56484 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56484 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56485 : List Nat := [1,4,5,1,5,1,5,5,5,0,1,1,5,4,0,0,5,5,0,1,1,5,1,1,5,0,0,5,0,5,0,5,5,5,4,4]

theorem envBound56485 : H12AffineFastState.Bounded env56485 := by
  intro p hp
  have h : env56485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56484_56485 : H12AffineEnvironment.transform 0 1 env56484 = env56485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56484 == env56485) = true)

def env56486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169264,16,21762,8193,65,215367,115015,17665,35188,119043,243002,256,98679,90203,63069]

theorem envBound56486 : H12AffineFastState.Bounded env56486 := by
  intro p hp
  have h : env56486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56469_56486 : H12AffineEnvironment.transform 6 9 env56469 = env56486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56469 == env56486) = true)

theorem identity56486 : scanCanonicalize (H12AffineFastState.compose env56486 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound56486 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4161,21792,16,21762,8193,65,100695,115015,17665,35188,119043,95530,256,98679,90203,63069]

theorem envBound56487 : H12AffineFastState.Bounded env56487 := by
  intro p hp
  have h : env56487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56486_56487 : H12AffineEnvironment.transform 16 49168 env56486 = env56487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env56486 == env56487) = true)

theorem identity56487 : scanCanonicalize (H12AffineFastState.compose env56487 (packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound56487 : packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21510,49168,35188,1024,32769,4161,21792,16,21762,8193,65,56657,38209,17665,35188,34053,8492,256,54641,13405,63069]

theorem envBound56488 : H12AffineFastState.Bounded env56488 := by
  intro p hp
  have h : env56488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56487_56488 : H12AffineEnvironment.transform 15 21510 env56487 = env56488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env56487 == env56488) = true)

theorem identity56488 : scanCanonicalize (H12AffineFastState.compose env56488 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound56488 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env56489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,372,21510,16740,2048,1024,373,4161,21792,16,21762,8193,65,23589,5173,17665,2048,1137,8492,256,21509,13405,30505]

theorem envBound56489 : H12AffineFastState.Bounded env56489 := by
  intro p hp
  have h : env56489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56488_56489 : H12AffineEnvironment.transform 14 372 env56488 = env56489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env56488 == env56489) = true)

theorem identity56489 : scanCanonicalize (H12AffineFastState.compose env56489 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound56489 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env56490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,372,34,5440,2048,1024,373,4161,260,16,294,8193,65,2049,5173,4389,2048,1137,8492,256,33,13405,8973]

theorem envBound56490 : H12AffineFastState.Bounded env56490 := by
  intro p hp
  have h : env56490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56489_56490 : H12AffineEnvironment.transform 13 5156 env56489 = env56490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env56489 == env56490) = true)

theorem identity56490 : scanCanonicalize (H12AffineFastState.compose env56490 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56490 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5156,372,34,5440,2048,1024,373,4161,260,16,294,269,65,2049,5173,4389,2048,1137,32,256,33,5457,513]

theorem envBound56491 : H12AffineFastState.Bounded env56491 := by
  intro p hp
  have h : env56491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56490_56491 : H12AffineEnvironment.transform 12 268 env56490 = env56491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56490 == env56491) = true)

theorem identity56491 : scanCanonicalize (H12AffineFastState.compose env56491 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56492 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,1,34,5173,2048,1024,0,4161,113,16,83,120,65,2049,5173,4176,2048,1137,32,117,33,5156,513]

theorem envBound56492 : H12AffineFastState.Bounded env56492 := by
  intro p hp
  have h : env56492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56491_56492 : H12AffineEnvironment.transform 7 117 env56491 = env56492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56491 == env56492) = true)

theorem identity56492 : scanCanonicalize (H12AffineFastState.compose env56492 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound56492 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env56493 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2048,121,3108,1,34,3125,2048,1024,0,2113,113,16,83,120,65,2049,3125,2128,2048,1137,32,117,33,3108,513]

theorem envBound56493 : H12AffineFastState.Bounded env56493 := by
  intro p hp
  have h : env56493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56492_56493 : H12AffineEnvironment.transform 11 2048 env56492 = env56493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env56492 == env56493) = true)

theorem identity56493 : scanCanonicalize (H12AffineFastState.compose env56493 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound56493 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env56494 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1093,1093,121,97,1,34,112,1093,1024,0,1028,113,16,83,120,65,1092,112,1045,1093,1137,32,117,33,97,513]

theorem envBound56494 : H12AffineFastState.Bounded env56494 := by
  intro p hp
  have h : env56494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56493_56494 : H12AffineEnvironment.transform 10 1093 env56493 = env56494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env56493 == env56494) = true)

theorem identity56494 : scanCanonicalize (H12AffineFastState.compose env56494 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound56494 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56495 : List Nat := [2,4,8,16,32,64,9,117,512,117,48,48,121,97,1,34,112,48,117,0,113,113,16,83,120,65,49,112,96,48,4,32,117,33,97,513]

theorem envBound56495 : H12AffineFastState.Bounded env56495 := by
  intro p hp
  have h : env56495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56494_56495 : H12AffineEnvironment.transform 9 117 env56494 = env56495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env56494 == env56495) = true)

theorem identity56495 : scanCanonicalize (H12AffineFastState.compose env56495 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56495 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56496 : List Nat := [2,4,8,16,32,0,9,53,512,53,48,48,57,33,1,34,48,48,53,0,49,49,16,19,56,1,49,48,32,48,4,32,53,33,33,513]

theorem envBound56496 : H12AffineFastState.Bounded env56496 := by
  intro p hp
  have h : env56496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56495_56496 : H12AffineEnvironment.transform 5 0 env56495 = env56496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56495 == env56496) = true)

theorem identity56496 : scanCanonicalize (H12AffineFastState.compose env56496 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56496 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56497 : List Nat := [2,4,8,0,32,0,9,37,512,37,32,32,41,33,1,34,32,32,37,0,33,33,0,3,40,1,33,32,32,32,4,32,37,33,33,513]

theorem envBound56497 : H12AffineFastState.Bounded env56497 := by
  intro p hp
  have h : env56497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56496_56497 : H12AffineEnvironment.transform 3 0 env56496 = env56497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56496 == env56497) = true)

theorem identity56497 : scanCanonicalize (H12AffineFastState.compose env56497 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56498 : List Nat := [2,4,8,0,1,0,9,4,512,4,1,1,8,0,1,3,1,1,4,0,0,0,0,3,9,1,0,1,1,1,4,1,4,0,0,513]

theorem envBound56498 : H12AffineFastState.Bounded env56498 := by
  intro p hp
  have h : env56498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56497_56498 : H12AffineEnvironment.transform 4 1 env56497 = env56498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56497 == env56498) = true)

def env56499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412021,2114882,8328,65,6409270,115151,2497573,35189,2590758,4268162,256,510106,469311,2535409]

theorem envBound56499 : H12AffineFastState.Bounded env56499 := by
  intro p hp
  have h : env56499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56360_56499 : H12AffineEnvironment.transform 22 412021 env56360 = env56499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412021 env56360 == env56499) = true)

def env56500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412021,2114882,8328,65,215366,115151,2497573,35189,2590758,2336242,256,510106,469311,2535409]

theorem envBound56500 : H12AffineFastState.Bounded env56500 := by
  intro p hp
  have h : env56500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56499_56500 : H12AffineEnvironment.transform 21 2262384 env56499 = env56500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env56499 == env56500) = true)

def env56501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,21762,8328,65,215366,115151,396389,35189,497766,243122,256,510106,469311,442289]

theorem envBound56501 : H12AffineFastState.Bounded env56501 := by
  intro p hp
  have h : env56501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56500_56501 : H12AffineEnvironment.transform 20 4160 env56500 = env56501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56500 == env56501) = true)

theorem identity56501 : scanCanonicalize (H12AffineFastState.compose env56501 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound56501 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,169264,73754,21762,8328,65,215366,115151,91402,35189,61705,243122,256,41461,16464,120542]

theorem envBound56502 : H12AffineFastState.Bounded env56502 := by
  intro p hp
  have h : env56502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56501_56502 : H12AffineEnvironment.transform 17 223599 env56501 = env56502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env56501 == env56502) = true)

def env56503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4112,169264,73754,21762,8328,17,215318,115103,91402,35109,61705,243122,256,41381,16384,120462]

theorem envBound56503 : H12AffineFastState.Bounded env56503 := by
  intro p hp
  have h : env56503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56502_56503 : H12AffineEnvironment.transform 5 16 env56502 = env56503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56502 == env56503) = true)

theorem identity56503 : scanCanonicalize (H12AffineFastState.compose env56503 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57749) := by decide +kernel

theorem selectedBound56503 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env56504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,57749,100522,1024,32769,4112,29861,73754,21762,8328,17,108675,115103,91402,35109,61705,87079,256,41381,16384,120462]

theorem envBound56504 : H12AffineFastState.Bounded env56504 := by
  intro p hp
  have h : env56504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56503_56504 : H12AffineEnvironment.transform 16 57749 env56503 = env56504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57749 env56503 == env56504) = true)

theorem identity56504 : scanCanonicalize (H12AffineFastState.compose env56504 (packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound56504 : packedSelected [0,3,4,5,7,8,18,22,23,28] rootPS < 2^1333 := by decide +kernel

def env56505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,65536,46109,100522,1024,32769,4112,8493,73754,138,8328,17,108675,103447,77954,35109,42113,65967,256,41381,5512,99078]

theorem envBound56505 : H12AffineFastState.Bounded env56505 := by
  intro p hp
  have h : env56505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56504_56505 : H12AffineEnvironment.transform 13 5512 env56504 = env56505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env56504 == env56505) = true)

theorem identity56505 : scanCanonicalize (H12AffineFastState.compose env56505 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56505 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env56506 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,65536,46109,100386,1024,32769,4112,8493,73754,2,8192,17,108555,103447,77834,35109,41993,65831,256,41261,5376,99078]

theorem envBound56506 : H12AffineFastState.Bounded env56506 := by
  intro p hp
  have h : env56506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56505_56506 : H12AffineEnvironment.transform 6 8 env56505 = env56506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56505 == env56506) = true)

theorem identity56506 : scanCanonicalize (H12AffineFastState.compose env56506 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound56506 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env56507 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,32768,263,46109,35109,1024,32769,4112,8493,8477,2,8192,17,43276,38160,12557,35109,41993,32,256,41261,5376,33281]

theorem envBound56507 : H12AffineFastState.Bounded env56507 := by
  intro p hp
  have h : env56507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56506_56507 : H12AffineEnvironment.transform 15 263 env56506 = env56507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env56506 == env56507) = true)

theorem identity56507 : scanCanonicalize (H12AffineFastState.compose env56507 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound56507 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56508 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,263,5393,10281,1024,8461,4112,8493,8477,2,8192,17,2048,13340,12557,10281,1285,32,256,33,5376,8973]

theorem envBound56508 : H12AffineFastState.Bounded env56508 := by
  intro p hp
  have h : env56508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56507_56508 : H12AffineEnvironment.transform 14 8460 env56507 = env56508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env56507 == env56508) = true)

theorem identity56508 : scanCanonicalize (H12AffineFastState.compose env56508 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56508 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env56509 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5376,513]

theorem envBound56509 : H12AffineFastState.Bounded env56509 := by
  intro p hp
  have h : env56509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56508_56509 : H12AffineEnvironment.transform 12 268 env56508 = env56509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56508 == env56509) = true)

theorem identity56509 : scanCanonicalize (H12AffineFastState.compose env56509 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56510 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,0,34,5172,2048,1024,1,4112,33,17,2,41,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound56510 : H12AffineFastState.Bounded env56510 := by
  intro p hp
  have h : env56510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56509_56510 : H12AffineEnvironment.transform 7 37 env56509 = env56510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56509 == env56510) = true)

def env56511 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,0,34,1028,2048,1024,1,32,33,17,2,41,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound56511 : H12AffineFastState.Bounded env56511 := by
  intro p hp
  have h : env56511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56510_56511 : H12AffineEnvironment.transform 11 48 env56510 = env56511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56510 == env56511) = true)

theorem identity56511 : scanCanonicalize (H12AffineFastState.compose env56511 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound56511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56512 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,48,41,1045,0,34,1028,33,1024,1,32,33,17,2,41,17,33,1029,49,33,1056,32,37,33,1045,513]

theorem envBound56512 : H12AffineFastState.Bounded env56512 := by
  intro p hp
  have h : env56512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56511_56512 : H12AffineEnvironment.transform 10 33 env56511 = env56512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env56511 == env56512) = true)

def env56513 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,41,33,0,34,48,33,52,1,32,33,17,2,41,17,33,49,49,33,20,32,37,33,33,513]

theorem envBound56513 : H12AffineFastState.Bounded env56513 := by
  intro p hp
  have h : env56513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56512_56513 : H12AffineEnvironment.transform 9 52 env56512 = env56513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56512 == env56513) = true)

theorem identity56513 : scanCanonicalize (H12AffineFastState.compose env56513 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound56513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56514 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,48,41,33,0,34,48,33,52,1,32,33,17,2,41,17,33,49,49,33,20,32,37,33,33,42]

theorem envBound56514 : H12AffineFastState.Bounded env56514 := by
  intro p hp
  have h : env56514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56513_56514 : H12AffineEnvironment.transform 8 43 env56513 = env56514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env56513 == env56514) = true)

def leafEnv56514 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,48,41,33,0,34,48,33,52,1,32,33,17,2,20,41,1,17,33,49,49,33,20,32,37,33,4,34,33,42,1,32,0]

def active56514 : List Nat := [0,1,2,3,4]

def tree56514 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56514 : H12WitnessSearch.Good tree56514 := H12GlobalWitnessIndex.good

theorem leafIdentity56514 : H12AffineFastState.composeSystem env56514 rootObs = leafEnv56514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56514 rootObs == leafEnv56514) = true)

theorem terminalChecked56514 : H12PackedTerminal.terminalCheckFast leafEnv56514 active56514 tree56514 = true := by decide +kernel

def env56515 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,41,32,0,34,49,33,53,1,32,33,17,2,41,17,33,48,49,33,21,32,37,33,32,513]

theorem envBound56515 : H12AffineFastState.Bounded env56515 := by
  intro p hp
  have h : env56515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56512_56515 : H12AffineEnvironment.transform 9 53 env56512 = env56515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56512 == env56515) = true)

def env56516 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,0,34,1029,2048,1024,1,33,33,17,2,41,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound56516 : H12AffineFastState.Bounded env56516 := by
  intro p hp
  have h : env56516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56510_56516 : H12AffineEnvironment.transform 11 49 env56510 = env56516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56510 == env56516) = true)

theorem identity56516 : scanCanonicalize (H12AffineFastState.compose env56516 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound56516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56517 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,49,41,1044,0,34,1029,1044,1024,1,33,33,17,2,41,17,1044,1028,48,1044,1056,32,37,33,1044,513]

theorem envBound56517 : H12AffineFastState.Bounded env56517 := by
  intro p hp
  have h : env56517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56516_56517 : H12AffineEnvironment.transform 10 1044 env56516 = env56517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env56516 == env56517) = true)

def env56518 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,41,32,0,34,49,32,52,1,33,33,17,2,41,17,32,48,48,32,20,32,37,33,32,513]

theorem envBound56518 : H12AffineFastState.Bounded env56518 := by
  intro p hp
  have h : env56518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56517_56518 : H12AffineEnvironment.transform 9 52 env56517 = env56518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56517 == env56518) = true)

theorem identity56518 : scanCanonicalize (H12AffineFastState.compose env56518 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound56518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56519 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,49,41,32,0,34,49,32,52,1,33,33,17,2,41,17,32,48,48,32,20,32,37,33,32,43]

theorem envBound56519 : H12AffineFastState.Bounded env56519 := by
  intro p hp
  have h : env56519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56518_56519 : H12AffineEnvironment.transform 8 42 env56518 = env56519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env56518 == env56519) = true)

def leafEnv56519 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,49,41,32,0,34,49,32,52,1,33,33,17,2,20,41,1,17,32,48,48,32,20,32,37,33,4,34,32,43,1,33,0]

def active56519 : List Nat := [0,1,2,3,4]

def tree56519 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56519 : H12WitnessSearch.Good tree56519 := H12GlobalWitnessIndex.good

theorem leafIdentity56519 : H12AffineFastState.composeSystem env56519 rootObs = leafEnv56519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56519 rootObs == leafEnv56519) = true)

theorem terminalChecked56519 : H12PackedTerminal.terminalCheckFast leafEnv56519 active56519 tree56519 = true := by decide +kernel

def env56520 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,41,33,0,34,48,33,53,1,33,33,17,2,41,17,33,49,48,33,21,32,37,33,33,513]

theorem envBound56520 : H12AffineFastState.Bounded env56520 := by
  intro p hp
  have h : env56520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56517_56520 : H12AffineEnvironment.transform 9 53 env56517 = env56520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56517 == env56520) = true)

def env56521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4113,169264,73754,21762,8328,16,215319,115102,91402,35108,61705,243122,256,41380,16385,120463]

theorem envBound56521 : H12AffineFastState.Bounded env56521 := by
  intro p hp
  have h : env56521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56502_56521 : H12AffineEnvironment.transform 5 17 env56502 = env56521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56502 == env56521) = true)

theorem identity56521 : scanCanonicalize (H12AffineFastState.compose env56521 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 115102) := by decide +kernel

theorem selectedBound56521 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env56522 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115102,43168,1024,32769,4113,87214,73754,21762,8328,16,34953,115102,91402,35108,61705,29740,256,41380,16385,120463]

theorem envBound56522 : H12AffineFastState.Bounded env56522 := by
  intro p hp
  have h : env56522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56521_56522 : H12AffineEnvironment.transform 16 115102 env56521 = env56522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115102 env56521 == env56522) = true)

theorem identity56522 : scanCanonicalize (H12AffineFastState.compose env56522 (packedSelected [1,3,4,5,7,8,9,17,19,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound56522 : packedSelected [1,3,4,5,7,8,9,17,19,27,31] rootPS < 2^1333 := by decide +kernel

def env56523 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,65536,90138,2340,1024,8581,4113,87214,73754,21762,8328,16,10509,90138,91402,10400,20621,29740,256,32,16385,96011]

theorem envBound56523 : H12AffineFastState.Bounded env56523 := by
  intro p hp
  have h : env56523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56522_56523 : H12AffineEnvironment.transform 14 8580 env56522 = env56523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env56522 == env56523) = true)

theorem identity56523 : scanCanonicalize (H12AffineFastState.compose env56523 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound56523 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env56524 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8322,16536,2340,1024,8581,4113,29740,152,21762,8328,16,10509,16536,17800,10400,20621,29740,256,32,16385,22409]

theorem envBound56524 : H12AffineFastState.Bounded env56524 := by
  intro p hp
  have h : env56524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56523_56524 : H12AffineEnvironment.transform 15 8322 env56523 = env56524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env56523 == env56524) = true)

theorem identity56524 : scanCanonicalize (H12AffineFastState.compose env56524 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56524 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env56525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8322,5529,2340,1024,8581,4113,8493,152,3,8328,16,10509,5529,4233,10400,1420,8493,256,32,5376,648]

theorem envBound56525 : H12AffineFastState.Bounded env56525 := by
  intro p hp
  have h : env56525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56524_56525 : H12AffineEnvironment.transform 13 5377 env56524 = env56525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56524 == env56525) = true)

theorem identity56525 : scanCanonicalize (H12AffineFastState.compose env56525 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56525 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56526 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,5392,2340,1024,8460,4113,8493,17,3,8193,16,10509,5392,4096,10281,1285,8493,256,32,5376,513]

theorem envBound56526 : H12AffineFastState.Bounded env56526 := by
  intro p hp
  have h : env56526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56525_56526 : H12AffineEnvironment.transform 6 9 env56525 = env56526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56525 == env56526) = true)

theorem identity56526 : scanCanonicalize (H12AffineFastState.compose env56526 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound56526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56527 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,8192,4112,8461,8203,4097,2340,273,8460,4113,8493,17,3,8193,16,10509,4097,4096,10281,20,8493,256,32,4113,513]

theorem envBound56527 : H12AffineFastState.Bounded env56527 := by
  intro p hp
  have h : env56527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56526_56527 : H12AffineEnvironment.transform 9 273 env56526 = env56527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env56526 == env56527) = true)

theorem identity56527 : scanCanonicalize (H12AffineFastState.compose env56527 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56527 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56528 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,1,263,4097,2340,273,0,4113,33,17,3,269,16,2049,4097,4096,2341,20,33,256,32,4113,513]

theorem envBound56528 : H12AffineFastState.Bounded env56528 := by
  intro p hp
  have h : env56528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56527_56528 : H12AffineEnvironment.transform 12 268 env56527 = env56528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56527 == env56528) = true)

theorem identity56528 : scanCanonicalize (H12AffineFastState.compose env56528 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound56528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56529 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,268,2049,1,263,2064,2340,273,0,2048,33,17,3,269,16,2049,2064,2065,2341,20,33,256,32,2048,513]

theorem envBound56529 : H12AffineFastState.Bounded env56529 := by
  intro p hp
  have h : env56529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56528_56529 : H12AffineEnvironment.transform 11 2065 env56528 = env56529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env56528 == env56529) = true)

theorem identity56529 : scanCanonicalize (H12AffineFastState.compose env56529 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56529 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56530 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2065,40,2049,1,35,2064,2048,53,0,2048,33,17,3,41,16,2049,2064,2065,2049,20,33,36,32,2048,513]

theorem envBound56530 : H12AffineFastState.Bounded env56530 := by
  intro p hp
  have h : env56530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56529_56530 : H12AffineEnvironment.transform 7 36 env56529 = env56530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56529 == env56530) = true)

theorem identity56530 : scanCanonicalize (H12AffineFastState.compose env56530 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound56530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56531 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,40,48,1,35,33,49,53,0,49,33,17,3,41,16,48,33,32,48,20,33,36,32,49,513]

theorem envBound56531 : H12AffineFastState.Bounded env56531 := by
  intro p hp
  have h : env56531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56530_56531 : H12AffineEnvironment.transform 10 49 env56530 = env56531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env56530 == env56531) = true)

def leafEnv56531 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,32,40,48,1,35,33,49,53,0,49,33,17,3,20,41,1,16,48,33,32,48,20,33,36,32,4,34,49,513,1,48,0]

def active56531 : List Nat := [0,1,2,3,4,8]

def tree56531 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56531 : H12WitnessSearch.Good tree56531 := H12GlobalWitnessIndex.good

theorem leafIdentity56531 : H12AffineFastState.composeSystem env56531 rootObs = leafEnv56531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56531 rootObs == leafEnv56531) = true)

theorem terminalChecked56531 : H12PackedTerminal.terminalCheckFast leafEnv56531 active56531 tree56531 = true := by decide +kernel

def env56532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,21763,8328,65,215366,115151,396388,35189,497767,243123,256,510106,469311,442288]

theorem envBound56532 : H12AffineFastState.Bounded env56532 := by
  intro p hp
  have h : env56532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56500_56532 : H12AffineEnvironment.transform 20 4161 env56500 = env56532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56500 == env56532) = true)

theorem identity56532 : scanCanonicalize (H12AffineFastState.compose env56532 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound56532 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,169265,412021,21763,8328,65,171416,5393,396388,35189,412857,156013,256,400452,458209,442288]

theorem envBound56533 : H12AffineFastState.Bounded env56533 := by
  intro p hp
  have h : env56533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56532_56533 : H12AffineEnvironment.transform 15 54494 env56532 = env56533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env56532 == env56533) = true)

def env56534 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4113,169265,411941,21763,8328,17,171416,5393,396340,35109,412857,155965,256,400404,458161,442288]

theorem envBound56534 : H12AffineFastState.Bounded env56534 := by
  intro p hp
  have h : env56534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56533_56534 : H12AffineEnvironment.transform 5 16 env56533 = env56534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56533 == env56534) = true)

theorem identity56534 : scanCanonicalize (H12AffineFastState.compose env56534 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23724) := by decide +kernel

theorem selectedBound56534 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env56535 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,23724,1024,32769,4113,169265,136585,21763,8328,17,171416,5393,151704,35109,135189,155965,256,147640,172317,189212]

theorem envBound56535 : H12AffineFastState.Bounded env56535 := by
  intro p hp
  have h : env56535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56534_56535 : H12AffineEnvironment.transform 17 23724 env56534 = env56535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23724 env56534 == env56535) = true)

theorem identity56535 : scanCanonicalize (H12AffineFastState.compose env56535 (packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound56535 : packedSelected [4,5,7,8,9,10,11,16,18,19,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env56536 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,46108,23724,1024,32769,4113,8493,41365,21763,8328,17,10628,5393,58500,35109,41993,54561,256,62628,5377,22272]

theorem envBound56536 : H12AffineFastState.Bounded env56536 := by
  intro p hp
  have h : env56536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56535_56536 : H12AffineEnvironment.transform 16 46108 env56535 = env56536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env56535 == env56536) = true)

theorem identity56536 : scanCanonicalize (H12AffineFastState.compose env56536 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56536 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env56537 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,46108,23588,1024,32769,4113,8493,41245,21763,8192,17,10508,5393,58380,35109,41993,54561,256,62508,5377,22272]

theorem envBound56537 : H12AffineFastState.Bounded env56537 := by
  intro p hp
  have h : env56537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56536_56537 : H12AffineEnvironment.transform 6 8 env56536 = env56537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56536 == env56537) = true)

theorem identity56537 : scanCanonicalize (H12AffineFastState.compose env56537 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56537 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env56538 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33031,46108,2341,1024,32769,4113,8493,41245,2,8192,17,10508,5393,45325,35109,41993,32800,256,41261,5377,513]

theorem envBound56538 : H12AffineFastState.Bounded env56538 := by
  intro p hp
  have h : env56538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56537_56538 : H12AffineEnvironment.transform 13 5377 env56537 = env56538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56537 == env56538) = true)

theorem identity56538 : scanCanonicalize (H12AffineFastState.compose env56538 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound56538 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56539 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,5392,2341,1024,8461,4113,8493,17,2,8192,17,10508,5393,4097,10281,1285,8492,256,33,5377,513]

theorem envBound56539 : H12AffineFastState.Bounded env56539 := by
  intro p hp
  have h : env56539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56538_56539 : H12AffineEnvironment.transform 14 8460 env56538 = env56539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env56538 == env56539) = true)

theorem identity56539 : scanCanonicalize (H12AffineFastState.compose env56539 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56540 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8232,8203,5172,2049,1024,8233,4113,8201,17,2,8192,17,10280,5173,4097,10281,1057,8200,36,33,5157,513]

theorem envBound56540 : H12AffineFastState.Bounded env56540 := by
  intro p hp
  have h : env56540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56539_56540 : H12AffineEnvironment.transform 7 36 env56539 = env56540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56539 == env56540) = true)

theorem identity56540 : scanCanonicalize (H12AffineFastState.compose env56540 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound56540 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56541 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5172,2049,1024,1,4113,33,17,2,40,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound56541 : H12AffineFastState.Bounded env56541 := by
  intro p hp
  have h : env56541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56540_56541 : H12AffineEnvironment.transform 12 40 env56540 = env56541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env56540 == env56541) = true)

def env56542 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,0,35,1028,2049,1024,1,33,33,17,2,40,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound56542 : H12AffineFastState.Bounded env56542 := by
  intro p hp
  have h : env56542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56541_56542 : H12AffineEnvironment.transform 11 48 env56541 = env56542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56541 == env56542) = true)

theorem identity56542 : scanCanonicalize (H12AffineFastState.compose env56542 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound56542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56543 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,48,40,528,0,35,513,2049,517,1,33,33,17,2,40,17,2048,512,49,2049,548,32,36,33,528,513]

theorem envBound56543 : H12AffineFastState.Bounded env56543 := by
  intro p hp
  have h : env56543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56542_56543 : H12AffineEnvironment.transform 9 517 env56542 = env56543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env56542 == env56543) = true)

def env56544 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,40,32,0,35,49,2049,53,1,33,33,17,2,40,17,2048,48,49,2049,20,32,36,33,32,49]

theorem envBound56544 : H12AffineFastState.Bounded env56544 := by
  intro p hp
  have h : env56544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56543_56544 : H12AffineEnvironment.transform 8 48 env56543 = env56544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56543 == env56544) = true)

def env56545 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,40,33,0,35,48,2049,52,1,33,33,17,2,40,17,2048,49,49,2049,21,32,36,33,33,48]

theorem envBound56545 : H12AffineFastState.Bounded env56545 := by
  intro p hp
  have h : env56545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56543_56545 : H12AffineEnvironment.transform 8 49 env56543 = env56545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56543 == env56545) = true)

theorem identity56545 : scanCanonicalize (H12AffineFastState.compose env56545 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56546 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,43,40,33,0,35,43,2049,47,1,33,33,10,2,40,10,2048,42,42,2049,14,32,36,33,33,43]

theorem envBound56546 : H12AffineFastState.Bounded env56546 := by
  intro p hp
  have h : env56546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56545_56546 : H12AffineEnvironment.transform 3 11 env56545 = env56546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56545 == env56546) = true)

def leafEnv56546 : List Nat := [2,4,8,11,32,11,8,36,42,47,2048,43,40,33,0,35,43,2049,47,1,33,33,10,2,14,40,1,10,2048,42,42,2049,14,32,36,33,4,35,33,43,1,33,0]

def active56546 : List Nat := [0,1,2,4,10]

def tree56546 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56546 : H12WitnessSearch.Good tree56546 := H12GlobalWitnessIndex.good

theorem leafIdentity56546 : H12AffineFastState.composeSystem env56546 rootObs = leafEnv56546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56546 rootObs == leafEnv56546) = true)

theorem terminalChecked56546 : H12PackedTerminal.terminalCheckFast leafEnv56546 active56546 tree56546 = true := by decide +kernel

def env56547 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,0,35,1029,2049,1024,1,32,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound56547 : H12AffineFastState.Bounded env56547 := by
  intro p hp
  have h : env56547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56541_56547 : H12AffineEnvironment.transform 11 49 env56541 = env56547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56541 == env56547) = true)

theorem identity56547 : scanCanonicalize (H12AffineFastState.compose env56547 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound56547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56548 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,49,40,1044,0,35,1029,2049,1024,1,32,33,17,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,49]

theorem envBound56548 : H12AffineFastState.Bounded env56548 := by
  intro p hp
  have h : env56548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56547_56548 : H12AffineEnvironment.transform 8 48 env56547 = env56548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56547 == env56548) = true)

def env56549 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,40,32,0,35,49,2049,52,1,32,33,17,2,40,17,2048,48,48,2049,21,32,36,33,32,49]

theorem envBound56549 : H12AffineFastState.Bounded env56549 := by
  intro p hp
  have h : env56549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56548_56549 : H12AffineEnvironment.transform 9 52 env56548 = env56549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56548 == env56549) = true)

theorem identity56549 : scanCanonicalize (H12AffineFastState.compose env56549 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56550 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,42,40,32,0,35,42,2049,47,1,32,33,10,2,40,10,2048,43,43,2049,14,32,36,33,32,42]

theorem envBound56550 : H12AffineFastState.Bounded env56550 := by
  intro p hp
  have h : env56550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56549_56550 : H12AffineEnvironment.transform 3 11 env56549 = env56550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56549 == env56550) = true)

def leafEnv56550 : List Nat := [2,4,8,11,32,11,8,36,43,47,2048,42,40,32,0,35,42,2049,47,1,32,33,10,2,14,40,1,10,2048,43,43,2049,14,32,36,33,4,35,32,42,1,32,0]

def active56550 : List Nat := [0,1,2,4,10]

def tree56550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56550 : H12WitnessSearch.Good tree56550 := H12GlobalWitnessIndex.good

theorem leafIdentity56550 : H12AffineFastState.composeSystem env56550 rootObs = leafEnv56550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56550 rootObs == leafEnv56550) = true)

theorem terminalChecked56550 : H12PackedTerminal.terminalCheckFast leafEnv56550 active56550 tree56550 = true := by decide +kernel

def env56551 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,40,33,0,35,48,2049,53,1,32,33,17,2,40,17,2048,49,48,2049,20,32,36,33,33,49]

theorem envBound56551 : H12AffineFastState.Bounded env56551 := by
  intro p hp
  have h : env56551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56548_56551 : H12AffineEnvironment.transform 9 53 env56548 = env56551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56548 == env56551) = true)

def env56552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4112,169265,411940,21763,8328,16,171416,5393,396341,35108,412857,155964,256,400405,458160,442288]

theorem envBound56552 : H12AffineFastState.Bounded env56552 := by
  intro p hp
  have h : env56552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56533_56552 : H12AffineEnvironment.transform 5 17 env56533 = env56552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56533 == env56552) = true)

theorem identity56552 : scanCanonicalize (H12AffineFastState.compose env56552 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound56552 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env56553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,5393,262144,1024,32769,4112,32800,285749,21763,8328,16,34953,5393,268580,35108,285096,29741,256,264452,321697,305825]

theorem envBound56553 : H12AffineFastState.Bounded env56553 := by
  intro p hp
  have h : env56553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56552_56553 : H12AffineEnvironment.transform 16 5393 env56552 = env56553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env56552 == env56553) = true)

theorem identity56553 : scanCanonicalize (H12AffineFastState.compose env56553 (packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound56553 : packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,5393,262144,1024,29708,4112,29741,285749,21763,8328,16,31876,5393,268580,32041,285096,29741,256,264452,269484,286380]

theorem envBound56554 : H12AffineFastState.Bounded env56554 := by
  intro p hp
  have h : env56554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56553_56554 : H12AffineEnvironment.transform 14 29709 env56553 = env56554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env56553 == env56554) = true)

theorem identity56554 : scanCanonicalize (H12AffineFastState.compose env56554 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound56554 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env56555 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,8322,5393,23725,1024,29708,4112,29741,152,21763,8328,16,31876,5393,17801,32041,1285,29741,256,21929,16385,513]

theorem envBound56555 : H12AffineFastState.Bounded env56555 := by
  intro p hp
  have h : env56555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56554_56555 : H12AffineEnvironment.transform 17 23725 env56554 = env56555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env56554 == env56555) = true)

theorem identity56555 : scanCanonicalize (H12AffineFastState.compose env56555 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound56555 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env56556 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21896,263,5393,23725,1024,21897,4112,21928,152,21763,269,16,23809,5393,17801,23724,1285,21928,256,21929,16385,513]

theorem envBound56556 : H12AffineFastState.Bounded env56556 := by
  intro p hp
  have h : env56556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56555_56556 : H12AffineEnvironment.transform 12 389 env56555 = env56556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env56555 == env56556) = true)

theorem identity56556 : scanCanonicalize (H12AffineFastState.compose env56556 (packedSelected [0,4,7,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2477) := by decide +kernel

theorem selectedBound56556 : packedSelected [0,4,7,9,14,15] rootPS < 2^1333 := by decide +kernel

def env56557 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,2477,7205,263,5393,5376,1024,7204,4112,7173,152,7342,269,16,5292,5393,3108,5377,1285,7173,256,7172,2476,513]

theorem envBound56557 : H12AffineFastState.Bounded env56557 := by
  intro p hp
  have h : env56557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56556_56557 : H12AffineEnvironment.transform 13 2477 env56556 = env56557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2477 env56556 == env56557) = true)

theorem identity56557 : scanCanonicalize (H12AffineFastState.compose env56557 (packedSelected [0,1,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound56557 : packedSelected [0,1,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env56558 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,389,2477,429,263,2201,2184,1024,428,3480,397,152,294,269,16,2340,2201,3108,2185,1285,397,256,396,2476,513]

theorem envBound56558 : H12AffineFastState.Bounded env56558 := by
  intro p hp
  have h : env56558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56557_56558 : H12AffineEnvironment.transform 11 3464 env56557 = env56558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env56557 == env56558) = true)

theorem identity56558 : scanCanonicalize (H12AffineFastState.compose env56558 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound56558 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env56559 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3108,41,2049,1,171,2201,2184,1024,0,3124,33,152,138,161,16,2184,2201,3108,2185,1193,33,172,32,2048,513]

theorem envBound56559 : H12AffineFastState.Bounded env56559 := by
  intro p hp
  have h : env56559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56558_56559 : H12AffineEnvironment.transform 7 172 env56558 = env56559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56558 == env56559) = true)

theorem identity56559 : scanCanonicalize (H12AffineFastState.compose env56559 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56559 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56560 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,2065,41,2049,1,171,2201,2184,53,0,2049,33,152,138,161,16,2184,2201,2065,2185,156,33,172,32,2048,513]

theorem envBound56560 : H12AffineFastState.Bounded env56560 := by
  intro p hp
  have h : env56560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56559_56560 : H12AffineEnvironment.transform 9 53 env56559 = env56560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56559 == env56560) = true)

theorem identity56560 : scanCanonicalize (H12AffineFastState.compose env56560 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56560 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56561 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2065,41,2049,1,35,2065,2048,53,0,2049,33,16,2,41,16,2048,2065,2065,2049,20,33,36,32,2048,513]

theorem envBound56561 : H12AffineFastState.Bounded env56561 := by
  intro p hp
  have h : env56561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56560_56561 : H12AffineEnvironment.transform 6 8 env56560 = env56561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56560 == env56561) = true)

theorem identity56561 : scanCanonicalize (H12AffineFastState.compose env56561 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56562 : List Nat := [2,4,8,16,1,17,8,5,512,20,2048,2065,8,2049,1,2,2065,2048,20,0,2049,0,16,2,8,16,2048,2065,2065,2049,20,0,5,1,2048,513]

theorem envBound56562 : H12AffineFastState.Bounded env56562 := by
  intro p hp
  have h : env56562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56561_56562 : H12AffineEnvironment.transform 4 1 env56561 = env56562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56561 == env56562) = true)

theorem identity56562 : scanCanonicalize (H12AffineFastState.compose env56562 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56563 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,8,1,1,2,17,0,20,0,1,0,16,2,8,16,0,17,17,1,20,0,5,1,0,513]

theorem envBound56563 : H12AffineFastState.Bounded env56563 := by
  intro p hp
  have h : env56563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56562_56563 : H12AffineEnvironment.transform 10 0 env56562 = env56563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56562 == env56563) = true)

theorem identity56563 : scanCanonicalize (H12AffineFastState.compose env56563 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56563 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56564 : List Nat := [2,4,8,16,1,17,8,5,0,20,0,17,8,1,1,2,17,0,20,0,1,0,16,2,8,16,0,17,17,1,20,0,5,1,0,1]

theorem envBound56564 : H12AffineFastState.Bounded env56564 := by
  intro p hp
  have h : env56564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56563_56564 : H12AffineEnvironment.transform 8 0 env56563 = env56564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56563 == env56564) = true)

theorem identity56564 : scanCanonicalize (H12AffineFastState.compose env56564 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56564 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56565 : List Nat := [2,4,8,0,1,1,8,5,0,4,0,1,8,1,1,2,1,0,4,0,1,0,0,2,8,0,0,1,1,1,4,0,5,1,0,1]

theorem envBound56565 : H12AffineFastState.Bounded env56565 := by
  intro p hp
  have h : env56565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56564_56565 : H12AffineEnvironment.transform 3 0 env56564 = env56565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56564 == env56565) = true)

def env56566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412021,2114882,8328,65,215367,115151,2497573,35189,2590758,2336243,256,510106,469311,2535409]

theorem envBound56566 : H12AffineFastState.Bounded env56566 := by
  intro p hp
  have h : env56566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56499_56566 : H12AffineEnvironment.transform 21 2262385 env56499 = env56566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env56499 == env56566) = true)

def env56567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,21762,8328,65,215367,115151,396389,35189,497766,243123,256,510106,469311,442289]

theorem envBound56567 : H12AffineFastState.Bounded env56567 := by
  intro p hp
  have h : env56567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56566_56567 : H12AffineEnvironment.transform 20 4160 env56566 = env56567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56566 == env56567) = true)

theorem identity56567 : scanCanonicalize (H12AffineFastState.compose env56567 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56567 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,169265,412021,21762,8328,65,158029,57797,396389,35189,440428,169401,256,452752,395573,442289]

theorem envBound56568 : H12AffineFastState.Bounded env56568 := by
  intro p hp
  have h : env56568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56567_56568 : H12AffineEnvironment.transform 15 8202 env56567 = env56568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56567 == env56568) = true)

theorem identity56568 : scanCanonicalize (H12AffineFastState.compose env56568 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound56568 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env56569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4160,169265,62661,21762,8328,65,158029,57797,45525,35189,1500,169401,256,21792,46213,513]

theorem envBound56569 : H12AffineFastState.Bounded env56569 := by
  intro p hp
  have h : env56569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56568_56569 : H12AffineEnvironment.transform 17 179632 env56568 = env56569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env56568 == env56569) = true)

theorem identity56569 : scanCanonicalize (H12AffineFastState.compose env56569 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound56569 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,64929,1024,32769,4160,54560,62661,21762,8328,65,10588,57797,45525,35189,1500,54696,256,21792,46213,513]

theorem envBound56570 : H12AffineFastState.Bounded env56570 := by
  intro p hp
  have h : env56570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56569_56570 : H12AffineEnvironment.transform 16 16401 env56569 = env56570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56569 == env56570) = true)

theorem identity56570 : scanCanonicalize (H12AffineFastState.compose env56570 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound56570 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,16401,2420,1024,29908,4160,8693,16,21762,8328,65,10588,5392,17664,32160,1500,8573,256,21792,16464,513]

theorem envBound56571 : H12AffineFastState.Bounded env56571 := by
  intro p hp
  have h : env56571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56570_56571 : H12AffineEnvironment.transform 14 29909 env56570 = env56571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env56570 == env56571) = true)

theorem identity56571 : scanCanonicalize (H12AffineFastState.compose env56571 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56571 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,343,16401,2420,1024,21897,4160,168,16,21762,469,65,2049,5392,17664,23805,1500,32,256,21792,16464,513]

theorem envBound56572 : H12AffineFastState.Bounded env56572 := by
  intro p hp
  have h : env56572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56571_56572 : H12AffineEnvironment.transform 12 349 env56571 = env56572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56571 == env56572) = true)

theorem identity56572 : scanCanonicalize (H12AffineFastState.compose env56572 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56572 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,343,16401,2420,1024,21761,4160,32,16,21762,349,65,2049,5392,17664,23669,1364,32,256,21792,16464,513]

theorem envBound56573 : H12AffineFastState.Bounded env56573 := by
  intro p hp
  have h : env56573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56572_56573 : H12AffineEnvironment.transform 6 8 env56572 = env56573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56572 == env56573) = true)

def env56574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,21763,8328,65,215367,115151,396388,35189,497767,243122,256,510106,469311,442288]

theorem envBound56574 : H12AffineFastState.Bounded env56574 := by
  intro p hp
  have h : env56574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56566_56574 : H12AffineEnvironment.transform 20 4161 env56566 = env56574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56566 == env56574) = true)

theorem identity56574 : scanCanonicalize (H12AffineFastState.compose env56574 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound56574 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,4161,169264,120014,21763,8328,65,215367,115151,102879,35189,1500,243122,256,21793,46212,74251]

theorem envBound56575 : H12AffineFastState.Bounded env56575 := by
  intro p hp
  have h : env56575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56574_56575 : H12AffineEnvironment.transform 17 236987 env56574 = env56575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env56574 == env56575) = true)

def env56576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130175,1024,32769,4161,62708,120014,21763,8328,65,75907,115151,102879,35189,1500,119926,256,21793,46212,74251]

theorem envBound56576 : H12AffineFastState.Bounded env56576 := by
  intro p hp
  have h : env56576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56575_56576 : H12AffineEnvironment.transform 16 25028 env56575 = env56576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env56575 == env56576) = true)

theorem identity56576 : scanCanonicalize (H12AffineFastState.compose env56576 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound56576 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,479,25028,64928,1024,32769,4161,62708,54545,21763,8328,65,10588,49168,36864,35189,1500,54697,256,21793,46212,9172]

theorem envBound56577 : H12AffineFastState.Bounded env56577 := by
  intro p hp
  have h : env56577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56576_56577 : H12AffineEnvironment.transform 15 479 env56576 = env56577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env56576 == env56577) = true)

theorem identity56577 : scanCanonicalize (H12AffineFastState.compose env56577 (packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56577 : packedSelected [0,4,5,7,8,10,12,15,17,18,22,23,24,26,28,38,41] rootPS < 2^1333 := by decide +kernel

def env56578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,398,24981,64928,1024,32769,4112,62629,54545,21763,8328,16,10509,49168,36864,35108,1421,54697,256,21793,46212,9093]

theorem envBound56578 : H12AffineFastState.Bounded env56578 := by
  intro p hp
  have h : env56578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56577_56578 : H12AffineEnvironment.transform 5 17 env56577 = env56578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56577 == env56578) = true)

theorem identity56578 : scanCanonicalize (H12AffineFastState.compose env56578 (packedSelected [1,5,8,17,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound56578 : packedSelected [1,5,8,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env56579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21760,398,24981,10400,1024,21761,4112,8613,17,21763,8328,16,10509,5392,17664,23588,1421,169,256,21793,24964,9093]

theorem envBound56579 : H12AffineFastState.Bounded env56579 := by
  intro p hp
  have h : env56579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56578_56579 : H12AffineEnvironment.transform 14 21760 env56578 = env56579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env56578 == env56579) = true)

theorem identity56579 : scanCanonicalize (H12AffineFastState.compose env56579 (packedSelected [1,2,3,5,6,7,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound56579 : packedSelected [1,2,3,5,6,7,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2049,7425,398,10644,10400,1024,7424,4112,8613,17,7426,8328,16,10509,5392,3329,5157,1421,169,256,7456,10629,9093]

theorem envBound56580 : H12AffineFastState.Bounded env56580 := by
  intro p hp
  have h : env56580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56579_56580 : H12AffineEnvironment.transform 13 2049 env56579 = env56580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env56579 == env56580) = true)

theorem identity56580 : scanCanonicalize (H12AffineFastState.compose env56580 (packedSelected [4,7,10,11,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound56580 : packedSelected [4,7,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env56581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,8192,2049,137,398,10644,10400,1024,136,3480,8613,17,138,8328,16,10509,2200,3329,2477,1421,169,256,168,10629,9093]

theorem envBound56581 : H12AffineFastState.Bounded env56581 := by
  intro p hp
  have h : env56581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56580_56581 : H12AffineEnvironment.transform 11 3464 env56580 = env56581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env56580 == env56581) = true)

theorem identity56581 : scanCanonicalize (H12AffineFastState.compose env56581 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56581 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env56582 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,3245,8192,2049,137,171,10417,10400,1024,136,3261,8320,17,138,8328,16,10280,2200,3108,2184,1192,169,37,168,10400,8864]

theorem envBound56582 : H12AffineFastState.Bounded env56582 := by
  intro p hp
  have h : env56582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56581_56582 : H12AffineEnvironment.transform 7 37 env56581 = env56582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56581 == env56582) = true)

theorem identity56582 : scanCanonicalize (H12AffineFastState.compose env56582 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56582 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56583 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3109,8192,2049,1,35,10297,10280,1024,0,3125,8200,17,2,8192,16,10280,2064,3108,2048,1056,33,37,32,10280,8744]

theorem envBound56583 : H12AffineFastState.Bounded env56583 := by
  intro p hp
  have h : env56583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56582_56583 : H12AffineEnvironment.transform 6 8 env56582 = env56583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56582 == env56583) = true)

theorem identity56583 : scanCanonicalize (H12AffineFastState.compose env56583 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound56583 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56584 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3109,8,2049,1,35,2097,2080,1024,0,3125,0,17,2,8,16,2080,2064,3108,2048,1056,33,37,32,2080,544]

theorem envBound56584 : H12AffineFastState.Bounded env56584 := by
  intro p hp
  have h : env56584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56583_56584 : H12AffineEnvironment.transform 12 8 env56583 = env56584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env56583 == env56584) = true)

def env56585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130174,1024,32769,4161,62709,120014,21763,8328,65,75906,115151,102879,35189,1500,119927,256,21793,46212,74251]

theorem envBound56585 : H12AffineFastState.Bounded env56585 := by
  intro p hp
  have h : env56585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56575_56585 : H12AffineEnvironment.transform 16 25029 env56575 = env56585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env56575 == env56585) = true)

theorem identity56585 : scanCanonicalize (H12AffineFastState.compose env56585 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound56585 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,16401,122282,1024,32769,4161,54561,120014,21763,348,65,67926,115151,102879,35189,1500,119927,256,21793,38224,66527]

theorem envBound56586 : H12AffineFastState.Bounded env56586 := by
  intro p hp
  have h : env56586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56585_56586 : H12AffineEnvironment.transform 12 468 env56585 = env56586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env56585 == env56586) = true)

theorem identity56586 : scanCanonicalize (H12AffineFastState.compose env56586 (packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound56586 : packedSelected [0,1,4,7,10,12,15,17,18,19,22,23,28,38,41] rootPS < 2^1333 := by decide +kernel

def env56587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,33110,16401,23804,1024,32769,4161,54561,21912,21763,348,65,34816,16537,4233,35189,1500,21793,256,21793,38224,33417]

theorem envBound56587 : H12AffineFastState.Bounded env56587 := by
  intro p hp
  have h : env56587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56586_56587 : H12AffineEnvironment.transform 15 33110 env56586 = env56587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env56586 == env56587) = true)

theorem identity56587 : scanCanonicalize (H12AffineFastState.compose env56587 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound56587 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env56588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5373,32768,33110,5356,2049,1024,32769,4161,33244,357,510,348,65,34816,5220,4233,35189,1500,476,256,476,38224,33417]

theorem envBound56588 : H12AffineFastState.Bounded env56588 := by
  intro p hp
  have h : env56588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56587_56588 : H12AffineEnvironment.transform 13 5373 env56587 = env56588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env56587 == env56588) = true)

theorem identity56588 : scanCanonicalize (H12AffineFastState.compose env56588 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56588 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56589 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5373,32768,32803,5356,2049,1024,32769,4161,32937,16,139,41,65,34816,5220,4233,34816,1193,169,117,169,37925,33417]

theorem envBound56589 : H12AffineFastState.Bounded env56589 := by
  intro p hp
  have h : env56589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56588_56589 : H12AffineEnvironment.transform 7 117 env56588 = env56589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56588 == env56589) = true)

theorem identity56589 : scanCanonicalize (H12AffineFastState.compose env56589 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56589 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env56590 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5373,0,35,5356,2049,1024,1,4161,169,16,139,41,65,2048,5220,4233,2048,1193,169,117,169,5157,649]

theorem envBound56590 : H12AffineFastState.Bounded env56590 := by
  intro p hp
  have h : env56590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56589_56590 : H12AffineEnvironment.transform 14 0 env56589 = env56590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56589 == env56590) = true)

theorem identity56590 : scanCanonicalize (H12AffineFastState.compose env56590 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound56590 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56591 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,1141,161,136,0,35,153,2049,1024,1,1076,169,16,139,41,65,2048,17,1276,2048,1193,169,117,169,80,649]

theorem envBound56591 : H12AffineFastState.Bounded env56591 := by
  intro p hp
  have h : env56591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56590_56591 : H12AffineEnvironment.transform 11 1141 env56590 = env56591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env56590 == env56591) = true)

theorem identity56591 : scanCanonicalize (H12AffineFastState.compose env56591 (packedSelected [1,2,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56591 : packedSelected [1,2,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env56592 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,1141,9,32,0,35,49,2049,1024,1,1076,1,16,35,41,65,2048,17,1108,2048,1025,1,117,1,80,545]

theorem envBound56592 : H12AffineFastState.Bounded env56592 := by
  intro p hp
  have h : env56592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56591_56592 : H12AffineEnvironment.transform 6 40 env56591 = env56592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56591 == env56592) = true)

theorem identity56592 : scanCanonicalize (H12AffineFastState.compose env56592 (packedSelected [0,2,4,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1546) := by decide +kernel

theorem selectedBound56592 : packedSelected [0,2,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env56593 : List Nat := [2,4,8,16,32,64,40,117,512,1024,1546,1141,9,32,0,35,49,1547,1024,1,1076,1,16,35,41,65,1546,17,1108,1546,1025,1,117,1,80,545]

theorem envBound56593 : H12AffineFastState.Bounded env56593 := by
  intro p hp
  have h : env56593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56592_56593 : H12AffineEnvironment.transform 10 1546 env56592 = env56593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1546 env56592 == env56593) = true)

theorem identity56593 : scanCanonicalize (H12AffineFastState.compose env56593 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56593 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56594 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1546,1108,9,1,0,2,16,1547,1024,1,1045,1,16,2,8,65,1546,17,1108,1546,1025,1,84,1,80,512]

theorem envBound56594 : H12AffineFastState.Bounded env56594 := by
  intro p hp
  have h : env56594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56593_56594 : H12AffineEnvironment.transform 4 1 env56593 = env56594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56593 == env56594) = true)

theorem identity56594 : scanCanonicalize (H12AffineFastState.compose env56594 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 591) := by decide +kernel

theorem selectedBound56594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56595 : List Nat := [2,4,8,16,1,64,9,84,512,591,69,539,9,1,0,2,16,68,591,1,602,1,16,2,8,65,69,17,539,69,590,1,84,1,80,512]

theorem envBound56595 : H12AffineFastState.Bounded env56595 := by
  intro p hp
  have h : env56595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56594_56595 : H12AffineEnvironment.transform 9 591 env56594 = env56595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 591 env56594 == env56595) = true)

theorem identity56595 : scanCanonicalize (H12AffineFastState.compose env56595 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound56595 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56596 : List Nat := [2,4,8,4,1,64,9,64,512,591,69,527,9,1,0,2,4,68,591,1,590,1,4,2,8,65,69,5,527,69,590,1,64,1,68,512]

theorem envBound56596 : H12AffineFastState.Bounded env56596 := by
  intro p hp
  have h : env56596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56595_56596 : H12AffineEnvironment.transform 3 4 env56595 = env56596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env56595 == env56596) = true)

theorem identity56596 : scanCanonicalize (H12AffineFastState.compose env56596 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56597 : List Nat := [2,3,8,3,1,64,9,64,512,584,66,520,9,1,0,2,3,67,584,1,585,1,3,2,8,65,66,2,520,66,585,1,64,1,67,512]

theorem envBound56597 : H12AffineFastState.Bounded env56597 := by
  intro p hp
  have h : env56597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56596_56597 : H12AffineEnvironment.transform 1 3 env56596 = env56597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56596 == env56597) = true)

theorem identity56597 : scanCanonicalize (H12AffineFastState.compose env56597 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound56597 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56598 : List Nat := [2,3,8,3,1,2,9,2,512,522,0,520,9,1,0,2,3,1,522,1,523,1,3,2,8,3,0,2,520,0,523,1,2,1,1,512]

theorem envBound56598 : H12AffineFastState.Bounded env56598 := by
  intro p hp
  have h : env56598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56597_56598 : H12AffineEnvironment.transform 5 2 env56597 = env56598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env56597 == env56598) = true)

theorem identity56598 : scanCanonicalize (H12AffineFastState.compose env56598 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound56598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56599 : List Nat := [2,3,8,3,1,2,9,2,10,0,0,2,9,1,0,2,3,1,0,1,1,1,3,2,8,3,0,2,2,0,1,1,2,1,1,10]

theorem envBound56599 : H12AffineFastState.Bounded env56599 := by
  intro p hp
  have h : env56599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56598_56599 : H12AffineEnvironment.transform 8 10 env56598 = env56599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env56598 == env56599) = true)

def env56600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound56600 : H12AffineFastState.Bounded env56600 := by
  intro p hp
  have h : env56600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56358_56600 : H12AffineEnvironment.transform 18 1025 env56358 = env56600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env56358 == env56600) = true)

theorem identity56600 : scanCanonicalize (H12AffineFastState.compose env56600 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388278) := by decide +kernel

theorem selectedBound56600 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,16777216,8328,65,29868032,17066042,8763878,8830977,25265169,21268854,257,25438234,25479614,25207751]

theorem envBound56601 : H12AffineFastState.Bounded env56601 := by
  intro p hp
  have h : env56601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56600_56601 : H12AffineEnvironment.transform 20 388278 env56600 = env56601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388278 env56600 == env56601) = true)

def env56602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,351520,8328,65,12754208,79130,8763878,8830977,8706353,4314198,257,8484154,8492190,8781543]

theorem envBound56602 : H12AffineFastState.Bounded env56602 := by
  intro p hp
  have h : env56602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56601_56602 : H12AffineEnvironment.transform 23 351520 env56601 = env56602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351520 env56601 == env56602) = true)

def env56603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,8388608,95496,8328,65,12754208,79130,8491470,8579113,8450329,4314198,257,8484154,8492190,8509135]

theorem envBound56603 : H12AffineFastState.Bounded env56603 := by
  intro p hp
  have h : env56603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56602_56603 : H12AffineEnvironment.transform 17 10280 env56602 = env56603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env56602 == env56603) = true)

def env56604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,16,95496,8328,65,4365616,79130,102878,190521,61705,4314198,257,95530,103566,120543]

theorem envBound56604 : H12AffineFastState.Bounded env56604 := by
  intro p hp
  have h : env56604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56603_56604 : H12AffineEnvironment.transform 22 16 env56603 = env56604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56603 == env56604) = true)

theorem identity56604 : scanCanonicalize (H12AffineFastState.compose env56604 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound56604 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,62589,16,95496,8328,65,158029,79130,102878,190521,61705,73771,257,95530,103566,120543]

theorem envBound56605 : H12AffineFastState.Bounded env56605 := by
  intro p hp
  have h : env56605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56604_56605 : H12AffineEnvironment.transform 21 62589 env56604 = env56605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env56604 == env56605) = true)

theorem identity56605 : scanCanonicalize (H12AffineFastState.compose env56605 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound56605 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env56606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4160,62589,16,41430,8328,65,158029,57796,17664,190521,61705,62709,257,41460,16464,513]

theorem envBound56606 : H12AffineFastState.Bounded env56606 := by
  intro p hp
  have h : env56606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56605_56606 : H12AffineEnvironment.transform 15 54494 env56605 = env56606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env56605 == env56606) = true)

theorem identity56606 : scanCanonicalize (H12AffineFastState.compose env56606 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound56606 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46276,10280,1025,32769,4160,62589,16,41430,8328,65,56713,57796,17664,23805,61705,62709,257,41460,16464,513]

theorem envBound56607 : H12AffineFastState.Bounded env56607 := by
  intro p hp
  have h : env56607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56606_56607 : H12AffineEnvironment.transform 16 46276 env56606 = env56607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env56606 == env56607) = true)

theorem identity56607 : scanCanonicalize (H12AffineFastState.compose env56607 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9412) := by decide +kernel

theorem selectedBound56607 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9412,28698,4096,10280,1025,9413,4160,20665,16,1298,8328,65,31053,17664,17664,23805,21965,20529,257,1328,16464,513]

theorem envBound56608 : H12AffineFastState.Bounded env56608 := by
  intro p hp
  have h : env56608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56607_56608 : H12AffineEnvironment.transform 14 9412 env56607 = env56608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9412 env56607 == env56608) = true)

theorem identity56608 : scanCanonicalize (H12AffineFastState.compose env56608 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56608 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,9412,9499,4096,10280,1025,9413,4160,1464,16,1298,8328,65,11340,4097,4097,2556,204,1328,257,1328,5457,513]

theorem envBound56609 : H12AffineFastState.Bounded env56609 := by
  intro p hp
  have h : env56609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56608_56609 : H12AffineEnvironment.transform 13 5377 env56608 = env56609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56608 == env56609) = true)

theorem identity56609 : scanCanonicalize (H12AffineFastState.compose env56609 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound56609 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env56610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5377,217,262,4096,3125,1025,216,4160,1464,16,1298,1173,65,2129,4097,4097,2556,204,1328,257,1328,5457,513]

theorem envBound56610 : H12AffineFastState.Bounded env56610 := by
  intro p hp
  have h : env56610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56609_56610 : H12AffineEnvironment.transform 12 1053 env56609 = env56610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env56609 == env56610) = true)

theorem identity56610 : scanCanonicalize (H12AffineFastState.compose env56610 (packedSelected [1,7,8,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound56610 : packedSelected [1,7,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env56611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,1053,1212,217,262,445,3125,1025,216,509,1464,16,1298,1173,65,2129,444,444,2556,204,1328,257,1328,1260,513]

theorem envBound56611 : H12AffineFastState.Bounded env56611 := by
  intro p hp
  have h : env56611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56610_56611 : H12AffineEnvironment.transform 11 445 env56610 = env56611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env56610 == env56611) = true)

theorem identity56611 : scanCanonicalize (H12AffineFastState.compose env56611 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56611 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env56612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,445,1053,1212,137,262,445,3125,1025,136,429,1464,16,1298,1173,17,2049,444,444,2476,156,1328,257,1328,1212,513]

theorem envBound56612 : H12AffineFastState.Bounded env56612 := by
  intro p hp
  have h : env56612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56611_56612 : H12AffineEnvironment.transform 5 16 env56611 = env56612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56611 == env56612) = true)

theorem identity56612 : scanCanonicalize (H12AffineFastState.compose env56612 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound56612 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56613 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,445,160,1,137,262,445,2184,188,136,429,261,16,431,40,17,2049,444,444,2476,156,397,257,397,1,513]

theorem envBound56613 : H12AffineFastState.Bounded env56613 := by
  intro p hp
  have h : env56613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56612_56613 : H12AffineEnvironment.transform 9 189 env56612 = env56613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env56612 == env56613) = true)

theorem identity56613 : scanCanonicalize (H12AffineFastState.compose env56613 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound56613 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env56614 : List Nat := [2,4,8,16,32,16,128,256,512,189,820,445,160,1,137,262,445,956,188,136,429,261,16,431,40,17,821,444,444,664,156,397,257,397,1,513]

theorem envBound56614 : H12AffineFastState.Bounded env56614 := by
  intro p hp
  have h : env56614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56613_56614 : H12AffineEnvironment.transform 10 820 env56613 = env56614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env56613 == env56614) = true)

theorem identity56614 : scanCanonicalize (H12AffineFastState.compose env56614 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 444) := by decide +kernel

theorem selectedBound56614 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56615 : List Nat := [2,4,8,16,32,16,128,256,444,189,136,445,160,1,137,262,445,0,188,136,429,261,16,431,40,17,137,444,444,292,156,397,257,397,1,445]

theorem envBound56615 : H12AffineFastState.Bounded env56615 := by
  intro p hp
  have h : env56615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56614_56615 : H12AffineEnvironment.transform 8 444 env56614 = env56615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 444 env56614 == env56615) = true)

theorem identity56615 : scanCanonicalize (H12AffineFastState.compose env56615 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56615 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env56616 : List Nat := [2,4,8,16,32,16,128,37,153,189,136,152,160,1,137,35,152,0,188,136,136,32,16,138,40,17,137,153,153,1,156,168,36,168,1,152]

theorem envBound56616 : H12AffineFastState.Bounded env56616 := by
  intro p hp
  have h : env56616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56615_56616 : H12AffineEnvironment.transform 7 37 env56615 = env56616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56615 == env56616) = true)

theorem identity56616 : scanCanonicalize (H12AffineFastState.compose env56616 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56617 : List Nat := [2,4,2,16,32,16,128,37,147,183,130,146,160,1,131,35,146,0,182,130,130,32,16,128,34,17,131,147,147,1,150,162,36,162,1,146]

theorem envBound56617 : H12AffineFastState.Bounded env56617 := by
  intro p hp
  have h : env56617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56616_56617 : H12AffineEnvironment.transform 2 2 env56616 = env56617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56616 == env56617) = true)

theorem identity56617 : scanCanonicalize (H12AffineFastState.compose env56617 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56617 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56618 : List Nat := [2,4,2,16,32,16,2,37,17,53,0,16,34,1,1,35,16,0,52,0,0,32,16,2,34,17,1,17,17,1,20,32,36,32,1,16]

theorem envBound56618 : H12AffineFastState.Bounded env56618 := by
  intro p hp
  have h : env56618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56617_56618 : H12AffineEnvironment.transform 6 2 env56617 = env56618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56617 == env56618) = true)

def env56619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,17,95496,8328,65,4365617,79130,102879,190520,61704,4314198,257,95531,103567,120542]

theorem envBound56619 : H12AffineFastState.Bounded env56619 := by
  intro p hp
  have h : env56619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56603_56619 : H12AffineEnvironment.transform 22 17 env56603 = env56619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56603 == env56619) = true)

theorem identity56619 : scanCanonicalize (H12AffineFastState.compose env56619 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound56619 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10280,1025,29908,77899,4194304,17,95496,8328,65,4352484,79130,91402,138477,1501,4268163,257,95531,90202,74251]

theorem envBound56620 : H12AffineFastState.Bounded env56620 := by
  intro p hp
  have h : env56620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56619_56620 : H12AffineEnvironment.transform 14 29909 env56619 = env56620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env56619 == env56620) = true)

theorem identity56620 : scanCanonicalize (H12AffineFastState.compose env56620 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56620 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env56621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,10280,1025,29908,77899,4194304,17,95496,8328,65,4262398,79130,91402,97527,1501,4268163,257,95531,90202,74251]

theorem envBound56621 : H12AffineFastState.Bounded env56621 := by
  intro p hp
  have h : env56621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56620_56621 : H12AffineEnvironment.transform 16 90138 env56620 = env56621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56620 == env56621) = true)

theorem identity56621 : scanCanonicalize (H12AffineFastState.compose env56621 (packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound56621 : packedSelected [0,1,3,5,8,9,10,11,14,18,19,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env56622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,10280,1025,29908,77899,21793,17,95496,8328,65,89311,79130,91402,97527,1501,95650,257,95531,90202,74251]

theorem envBound56622 : H12AffineFastState.Bounded env56622 := by
  intro p hp
  have h : env56622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56621_56622 : H12AffineEnvironment.transform 21 21793 env56621 = env56622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env56621 == env56622) = true)

theorem identity56622 : scanCanonicalize (H12AffineFastState.compose env56622 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56622 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env56623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21897,65536,82246,2420,1025,21896,69911,21793,17,87124,468,65,89311,70726,83030,89515,1501,87294,257,87159,82182,66391]

theorem envBound56623 : H12AffineFastState.Bounded env56623 := by
  intro p hp
  have h : env56623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56622_56623 : H12AffineEnvironment.transform 12 348 env56622 = env56623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56622 == env56623) = true)

theorem identity56623 : scanCanonicalize (H12AffineFastState.compose env56623 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound56623 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env56624 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,16384,20973,65536,82246,2420,101,20972,69911,20805,17,86064,468,65,88251,69666,81970,88527,441,86170,257,86035,82182,66391]

theorem envBound56624 : H12AffineFastState.Bounded env56624 := by
  intro p hp
  have h : env56624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56623_56624 : H12AffineEnvironment.transform 9 100 env56623 = env56624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env56623 == env56624) = true)

theorem identity56624 : scanCanonicalize (H12AffineFastState.compose env56624 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound56624 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env56625 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,16384,20973,20759,4177,2420,101,20972,16384,20805,17,295,468,65,2476,16693,4389,2264,441,397,257,260,4113,21056]

theorem envBound56625 : H12AffineFastState.Bounded env56625 := by
  intro p hp
  have h : env56625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56624_56625 : H12AffineEnvironment.transform 15 20759 env56624 = env56625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env56624 == env56625) = true)

theorem identity56625 : scanCanonicalize (H12AffineFastState.compose env56625 (packedSelected [2,3,5,6,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 4296) := by decide +kernel

theorem selectedBound56625 : packedSelected [2,3,5,6,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env56626 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,348,4296,293,479,4177,2420,101,292,4296,397,17,295,468,65,2476,4605,4389,2264,441,397,257,260,4113,648]

theorem envBound56626 : H12AffineFastState.Bounded env56626 := by
  intro p hp
  have h : env56626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56625_56626 : H12AffineEnvironment.transform 13 4296 env56625 = env56626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env56625 == env56626) = true)

theorem identity56626 : scanCanonicalize (H12AffineFastState.compose env56626 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56626 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56627 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,40,4296,81,171,4177,2048,101,80,4296,249,17,83,160,65,2264,4233,4177,2264,205,249,117,112,4113,648]

theorem envBound56627 : H12AffineFastState.Bounded env56627 := by
  intro p hp
  have h : env56627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56626_56627 : H12AffineEnvironment.transform 7 116 env56626 = env56627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56626 == env56627) = true)

theorem identity56627 : scanCanonicalize (H12AffineFastState.compose env56627 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56627 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56628 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,4096,40,4249,0,171,4096,2048,52,1,4249,168,17,2,160,16,2185,4233,4096,2185,156,168,36,33,4113,648]

theorem envBound56628 : H12AffineFastState.Bounded env56628 := by
  intro p hp
  have h : env56628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56627_56628 : H12AffineEnvironment.transform 5 17 env56627 = env56628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56627 == env56628) = true)

theorem identity56628 : scanCanonicalize (H12AffineFastState.compose env56628 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56628 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56629 : List Nat := [2,4,8,16,32,17,41,37,512,53,2048,4096,40,4144,0,2,4096,2048,52,1,4144,1,17,2,9,16,2080,4128,4096,2080,53,1,36,33,4113,545]

theorem envBound56629 : H12AffineFastState.Bounded env56629 := by
  intro p hp
  have h : env56629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56628_56629 : H12AffineEnvironment.transform 6 41 env56628 = env56629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56628 == env56629) = true)

def env56630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,8388608,95497,8328,65,12754208,79130,8491471,8579112,8450328,4314198,257,8484154,8492190,8509134]

theorem envBound56630 : H12AffineFastState.Bounded env56630 := by
  intro p hp
  have h : env56630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56602_56630 : H12AffineEnvironment.transform 17 10281 env56602 = env56630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56602 == env56630) = true)

def env56631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,16,95497,8328,65,4365616,79130,102879,190520,61704,4314198,257,95530,103566,120542]

theorem envBound56631 : H12AffineFastState.Bounded env56631 := by
  intro p hp
  have h : env56631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56630_56631 : H12AffineEnvironment.transform 22 16 env56630 = env56631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56630 == env56631) = true)

theorem identity56631 : scanCanonicalize (H12AffineFastState.compose env56631 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169) := by decide +kernel

theorem selectedBound56631 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,169,16,95497,8328,65,171417,79130,102879,190520,61704,120063,257,95530,103566,120542]

theorem envBound56632 : H12AffineFastState.Bounded env56632 := by
  intro p hp
  have h : env56632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56631_56632 : H12AffineEnvironment.transform 21 169 env56631 = env56632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169 env56631 == env56632) = true)

theorem identity56632 : scanCanonicalize (H12AffineFastState.compose env56632 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound56632 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env56633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46277,10281,1025,32769,115871,169,16,95497,8328,65,10588,79130,102879,23805,61704,120063,257,95530,103566,120542]

theorem envBound56633 : H12AffineFastState.Bounded env56633 := by
  intro p hp
  have h : env56633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56632_56633 : H12AffineEnvironment.transform 16 46277 env56632 = env56633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env56632 == env56633) = true)

theorem identity56633 : scanCanonicalize (H12AffineFastState.compose env56633 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound56633 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,46277,10281,1025,32769,102678,169,16,73856,8328,65,10588,79130,102879,2420,42113,98678,257,73891,103566,99159]

theorem envBound56634 : H12AffineFastState.Bounded env56634 := by
  intro p hp
  have h : env56634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56633_56634 : H12AffineEnvironment.transform 13 5513 env56633 = env56634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env56633 == env56634) = true)

def env56635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,17,95497,8328,65,4365617,79130,102878,190521,61705,4314198,257,95531,103567,120543]

theorem envBound56635 : H12AffineFastState.Bounded env56635 := by
  intro p hp
  have h : env56635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56630_56635 : H12AffineEnvironment.transform 22 17 env56630 = env56635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56630 == env56635) = true)

def env56636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,4194304,17,95497,8192,65,4365617,79130,102742,190521,61705,4314198,257,95531,103431,120407]

theorem envBound56636 : H12AffineFastState.Bounded env56636 := by
  intro p hp
  have h : env56636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56635_56636 : H12AffineEnvironment.transform 6 8 env56635 = env56636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56635 == env56636) = true)

theorem identity56636 : scanCanonicalize (H12AffineFastState.compose env56636 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56636 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,91466,4194304,17,95497,8192,65,4340844,79130,77835,149860,20564,4289803,257,95531,79194,96010]

theorem envBound56637 : H12AffineFastState.Bounded env56637 := by
  intro p hp
  have h : env56637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56636_56637 : H12AffineEnvironment.transform 14 8541 env56636 = env56637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56636 == env56637) = true)

theorem identity56637 : scanCanonicalize (H12AffineFastState.compose env56637 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56637 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env56638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1025,8540,91466,4194304,17,95497,8192,65,4283510,79130,77835,76158,20564,4289803,257,95531,79194,96010]

theorem envBound56638 : H12AffineFastState.Bounded env56638 := by
  intro p hp
  have h : env56638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56637_56638 : H12AffineEnvironment.transform 16 90138 env56637 = env56638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56637 == env56638) = true)

theorem identity56638 : scanCanonicalize (H12AffineFastState.compose env56638 (packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound56638 : packedSelected [0,2,3,4,5,6,9,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env56639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1025,8540,91466,65911,17,95497,8192,65,23809,79130,77835,76158,20564,29820,257,95531,79194,96010]

theorem envBound56639 : H12AffineFastState.Bounded env56639 := by
  intro p hp
  have h : env56639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56638_56639 : H12AffineEnvironment.transform 21 65911 env56638 = env56639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env56638 == env56639) = true)

theorem identity56639 : scanCanonicalize (H12AffineFastState.compose env56639 (packedSelected [1,2,5,6,8,9,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56639 : packedSelected [1,2,5,6,8,9,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env56640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,115,24681,10281,1025,8540,25913,260,17,30074,8192,65,23809,13673,12408,10509,20564,29820,257,30040,13609,30585]

theorem envBound56640 : H12AffineFastState.Bounded env56640 := by
  intro p hp
  have h : env56640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56639_56640 : H12AffineEnvironment.transform 15 115 env56639 = env56640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56639 == env56640) = true)

theorem identity56640 : scanCanonicalize (H12AffineFastState.compose env56640 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56640 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env56641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,372,115,16448,2048,1025,373,17680,260,17,21843,41,65,23809,5440,4177,2340,20564,21589,257,21873,5376,22352]

theorem envBound56641 : H12AffineFastState.Bounded env56641 := by
  intro p hp
  have h : env56641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56640_56641 : H12AffineEnvironment.transform 12 41 env56640 = env56641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56640 == env56641) = true)

theorem identity56641 : scanCanonicalize (H12AffineFastState.compose env56641 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56641 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env56642 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,0,115,16448,2048,1025,1,17508,112,17,21543,41,65,23669,5172,4177,2128,20564,21589,117,21509,5236,22052]

theorem envBound56642 : H12AffineFastState.Bounded env56642 := by
  intro p hp
  have h : env56642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56641_56642 : H12AffineEnvironment.transform 7 116 env56641 = env56642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56641 == env56642) = true)

theorem identity56642 : scanCanonicalize (H12AffineFastState.compose env56642 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56642 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56643 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,0,34,16401,2048,1025,1,17461,33,17,21543,41,16,23588,5172,4096,2049,20485,21508,36,21509,5157,22052]

theorem envBound56643 : H12AffineFastState.Bounded env56643 := by
  intro p hp
  have h : env56643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56642_56643 : H12AffineEnvironment.transform 5 17 env56642 = env56643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56642 == env56643) = true)

theorem identity56643 : scanCanonicalize (H12AffineFastState.compose env56643 (packedSelected [4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound56643 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env56644 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,41,16384,0,34,16401,2048,1025,1,17461,33,17,18435,41,16,16384,2064,3108,2049,19489,18464,36,18465,2049,18944]

theorem envBound56644 : H12AffineFastState.Bounded env56644 := by
  intro p hp
  have h : env56644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56643_56644 : H12AffineEnvironment.transform 11 3108 env56643 = env56644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env56643 == env56644) = true)

theorem identity56644 : scanCanonicalize (H12AffineFastState.compose env56644 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56644 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env56645 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2065,41,16384,0,34,16401,2048,52,1,16384,33,17,18435,41,16,16384,2064,2065,2049,18452,18464,36,18465,2049,18944]

theorem envBound56645 : H12AffineFastState.Bounded env56645 := by
  intro p hp
  have h : env56645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56644_56645 : H12AffineEnvironment.transform 9 53 env56644 = env56645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56644 == env56645) = true)

def env56646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115734,4194304,17,95497,8193,65,4365617,79130,102743,190521,61705,4314198,257,95531,103430,120406]

theorem envBound56646 : H12AffineFastState.Bounded env56646 := by
  intro p hp
  have h : env56646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56635_56646 : H12AffineEnvironment.transform 6 9 env56635 = env56646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56635 == env56646) = true)

theorem identity56646 : scanCanonicalize (H12AffineFastState.compose env56646 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound56646 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env56647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4161,4194304,17,41310,8193,65,4365617,57677,17664,190521,61705,4194305,257,41340,16465,513]

theorem envBound56647 : H12AffineFastState.Bounded env56647 := by
  intro p hp
  have h : env56647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56646_56647 : H12AffineEnvironment.transform 15 54359 env56646 = env56647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env56646 == env56647) = true)

def env56648 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,4194304,17,41230,8193,17,4365617,57629,17664,190521,61705,4194305,257,41260,16385,513]

theorem envBound56648 : H12AffineFastState.Bounded env56648 := by
  intro p hp
  have h : env56648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56647_56648 : H12AffineEnvironment.transform 5 16 env56647 = env56648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56647 == env56648) = true)

theorem identity56648 : scanCanonicalize (H12AffineFastState.compose env56648 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound56648 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env56649 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,8493,17,41230,8193,17,179228,57629,17664,190521,61705,8492,257,41260,16385,513]

theorem envBound56649 : H12AffineFastState.Bounded env56649 := by
  intro p hp
  have h : env56649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56648_56649 : H12AffineEnvironment.transform 21 8493 env56648 = env56649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env56648 == env56649) = true)

theorem identity56649 : scanCanonicalize (H12AffineFastState.compose env56649 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound56649 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env56650 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,131072,10281,1025,29708,4113,8493,17,21763,8193,17,149521,5392,17664,138292,1284,8492,257,21793,16385,513]

theorem envBound56650 : H12AffineFastState.Bounded env56650 := by
  intro p hp
  have h : env56650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56649_56650 : H12AffineEnvironment.transform 14 29709 env56649 = env56650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env56649 == env56650) = true)

theorem identity56650 : scanCanonicalize (H12AffineFastState.compose env56650 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56650 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56651 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10281,1025,8461,4113,8493,17,2,8193,17,138512,5392,4097,138292,1284,8492,257,32,5376,513]

theorem envBound56651 : H12AffineFastState.Bounded env56651 := by
  intro p hp
  have h : env56651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56650_56651 : H12AffineEnvironment.transform 13 5377 env56650 = env56651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56650 == env56651) = true)

theorem identity56651 : scanCanonicalize (H12AffineFastState.compose env56651 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56651 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56652 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10281,1025,8461,4113,8493,17,2,8193,17,10508,5392,4097,10280,1284,8492,257,32,5376,513]

theorem envBound56652 : H12AffineFastState.Bounded env56652 := by
  intro p hp
  have h : env56652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56651_56652 : H12AffineEnvironment.transform 16 13340 env56651 = env56652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env56651 == env56652) = true)

theorem identity56652 : scanCanonicalize (H12AffineFastState.compose env56652 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56652 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56653 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1025,0,4113,32,17,2,268,17,2049,5392,4097,2341,1284,33,257,32,5376,513]

theorem envBound56653 : H12AffineFastState.Bounded env56653 := by
  intro p hp
  have h : env56653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56652_56653 : H12AffineEnvironment.transform 12 269 env56652 = env56653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56652 == env56653) = true)

theorem identity56653 : scanCanonicalize (H12AffineFastState.compose env56653 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound56653 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56654 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,5124,1,2,5140,2081,1025,0,4113,32,17,2,9,17,2049,5141,4097,2080,1025,33,4,32,5125,513]

theorem envBound56654 : H12AffineFastState.Bounded env56654 := by
  intro p hp
  have h : env56654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56653_56654 : H12AffineEnvironment.transform 7 5 env56653 = env56654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56653 == env56654) = true)

theorem identity56654 : scanCanonicalize (H12AffineFastState.compose env56654 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56654 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56655 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,4096,8,4144,1,2,4128,2081,53,0,4113,32,17,2,9,17,2049,4129,4097,2080,53,33,4,32,4145,513]

theorem envBound56655 : H12AffineFastState.Bounded env56655 := by
  intro p hp
  have h : env56655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56654_56655 : H12AffineEnvironment.transform 9 52 env56654 = env56655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56654 == env56655) = true)

theorem identity56655 : scanCanonicalize (H12AffineFastState.compose env56655 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound56655 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56656 : List Nat := [2,4,8,16,32,16,9,5,512,52,2048,2609,8,2561,1,2,2577,2081,53,0,2592,32,17,2,9,17,2049,2576,2608,2080,53,33,4,32,2560,513]

theorem envBound56656 : H12AffineFastState.Bounded env56656 := by
  intro p hp
  have h : env56656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56655_56656 : H12AffineEnvironment.transform 11 2609 env56655 = env56656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env56655 == env56656) = true)

theorem identity56656 : scanCanonicalize (H12AffineFastState.compose env56656 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound56656 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56657 : List Nat := [2,4,8,16,32,16,9,5,512,52,513,48,8,0,1,2,16,544,53,0,33,32,17,2,9,17,512,17,49,545,53,33,4,32,1,513]

theorem envBound56657 : H12AffineFastState.Bounded env56657 := by
  intro p hp
  have h : env56657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56656_56657 : H12AffineEnvironment.transform 10 513 env56656 = env56657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env56656 == env56657) = true)

theorem identity56657 : scanCanonicalize (H12AffineFastState.compose env56657 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56657 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56658 : List Nat := [2,4,8,16,32,16,9,5,49,52,48,48,8,0,1,2,16,17,53,0,33,32,17,2,9,17,49,17,49,16,53,33,4,32,1,48]

theorem envBound56658 : H12AffineFastState.Bounded env56658 := by
  intro p hp
  have h : env56658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56657_56658 : H12AffineEnvironment.transform 8 49 env56657 = env56658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56657 == env56658) = true)

theorem identity56658 : scanCanonicalize (H12AffineFastState.compose env56658 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56658 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56659 : List Nat := [2,4,8,16,1,16,9,5,16,21,17,17,8,0,1,2,16,17,20,0,0,1,17,2,9,17,16,17,16,16,20,0,4,1,1,17]

theorem envBound56659 : H12AffineFastState.Bounded env56659 := by
  intro p hp
  have h : env56659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56658_56659 : H12AffineEnvironment.transform 4 1 env56658 = env56659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56658 == env56659) = true)

theorem identity56659 : scanCanonicalize (H12AffineFastState.compose env56659 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56659 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56660 : List Nat := [2,4,8,10,1,10,9,5,10,15,11,11,8,0,1,2,10,11,14,0,0,1,11,2,9,11,10,11,10,10,14,0,4,1,1,11]

theorem envBound56660 : H12AffineFastState.Bounded env56660 := by
  intro p hp
  have h : env56660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56659_56660 : H12AffineEnvironment.transform 3 10 env56659 = env56660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56659 == env56660) = true)

def env56661 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10281,1025,32769,4112,4194304,17,41231,8193,16,4365617,57628,17664,190521,61705,4194305,257,41261,16384,513]

theorem envBound56661 : H12AffineFastState.Bounded env56661 := by
  intro p hp
  have h : env56661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56647_56661 : H12AffineEnvironment.transform 5 17 env56647 = env56661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56647 == env56661) = true)

theorem identity56661 : scanCanonicalize (H12AffineFastState.compose env56661 (packedSelected [0,7,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56661 : packedSelected [0,7,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env56662 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,131072,10281,1025,1,4112,4194304,17,8463,8193,16,4332849,24860,17664,157753,28937,4194305,257,8493,16384,513]

theorem envBound56662 : H12AffineFastState.Bounded env56662 := by
  intro p hp
  have h : env56662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56661_56662 : H12AffineEnvironment.transform 14 0 env56661 = env56662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56661 == env56662) = true)

theorem identity56662 : scanCanonicalize (H12AffineFastState.compose env56662 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound56662 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56663 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,131072,10281,1025,1,4112,136497,17,8463,8193,16,2048,24860,17664,157753,28937,136496,257,8493,16384,513]

theorem envBound56663 : H12AffineFastState.Bounded env56663 := by
  intro p hp
  have h : env56663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56662_56663 : H12AffineEnvironment.transform 21 136497 env56662 = env56663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env56662 == env56663) = true)

theorem identity56663 : scanCanonicalize (H12AffineFastState.compose env56663 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56663 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env56664 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,0,21510,13340,10281,1025,1,4112,8493,17,8463,8193,16,2048,24860,17664,23589,28937,8492,257,8493,16384,513]

theorem envBound56664 : H12AffineFastState.Bounded env56664 := by
  intro p hp
  have h : env56664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56663_56664 : H12AffineEnvironment.transform 16 13340 env56663 = env56664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env56663 == env56664) = true)

theorem identity56664 : scanCanonicalize (H12AffineFastState.compose env56664 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56664 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env56665 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,0,21510,5392,2341,1025,1,4112,33,17,3,269,16,2048,16400,17664,23589,20485,32,257,33,16384,513]

theorem envBound56665 : H12AffineFastState.Bounded env56665 := by
  intro p hp
  have h : env56665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56664_56665 : H12AffineEnvironment.transform 12 268 env56664 = env56665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56664 == env56665) = true)

theorem identity56665 : scanCanonicalize (H12AffineFastState.compose env56665 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56665 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56666 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,16384,0,21510,5173,2048,1025,1,4112,33,17,3,40,16,2048,16400,17445,23589,20485,32,36,33,16384,513]

theorem envBound56666 : H12AffineFastState.Bounded env56666 := by
  intro p hp
  have h : env56666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56665_56666 : H12AffineEnvironment.transform 7 37 env56665 = env56666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56665 == env56666) = true)

theorem identity56666 : scanCanonicalize (H12AffineFastState.compose env56666 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound56666 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env56667 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5157,0,35,5173,2048,1025,1,4112,33,17,3,40,16,2048,5173,4096,2048,1056,32,36,33,5157,513]

theorem envBound56667 : H12AffineFastState.Bounded env56667 := by
  intro p hp
  have h : env56667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56666_56667 : H12AffineEnvironment.transform 13 5157 env56666 = env56667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env56666 == env56667) = true)

def env56668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388278,4194304,8388608,351521,8328,65,12754209,79131,8763878,8830977,8706352,4314199,257,8484155,8492191,8781542]

theorem envBound56668 : H12AffineFastState.Bounded env56668 := by
  intro p hp
  have h : env56668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56601_56668 : H12AffineEnvironment.transform 23 351521 env56601 = env56668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351521 env56601 == env56668) = true)

def env56669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,8388608,95497,8328,65,12754209,79131,8491470,8579113,8450328,4314199,257,8484155,8492191,8509134]

theorem envBound56669 : H12AffineFastState.Bounded env56669 := by
  intro p hp
  have h : env56669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56668_56669 : H12AffineEnvironment.transform 17 10280 env56668 = env56669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env56668 == env56669) = true)

def env56670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,16,95497,8328,65,4365617,79131,102878,190521,61704,4314199,257,95531,103567,120542]

theorem envBound56670 : H12AffineFastState.Bounded env56670 := by
  intro p hp
  have h : env56670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56669_56670 : H12AffineEnvironment.transform 22 16 env56669 = env56670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56669 == env56670) = true)

theorem identity56670 : scanCanonicalize (H12AffineFastState.compose env56670 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound56670 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,73891,16,95497,8328,65,245138,79131,102878,190521,61704,62708,257,95531,103567,120542]

theorem envBound56671 : H12AffineFastState.Bounded env56671 := by
  intro p hp
  have h : env56671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56670_56671 : H12AffineEnvironment.transform 21 73891 env56670 = env56671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env56670 == env56671) = true)

theorem identity56671 : scanCanonicalize (H12AffineFastState.compose env56671 (packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 103630) := by decide +kernel

theorem selectedBound56671 : packedSelected [1,5,8,12,15,17,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env56672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103630,10280,1025,32769,115870,73891,16,95497,8328,65,10588,79131,102878,97527,61704,62708,257,95531,103567,120542]

theorem envBound56672 : H12AffineFastState.Bounded env56672 := by
  intro p hp
  have h : env56672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56671_56672 : H12AffineEnvironment.transform 16 103630 env56671 = env56672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103630 env56671 == env56672) = true)

def env56673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,103494,10280,1025,32769,115734,73771,16,95497,8192,65,10588,79131,102742,97407,61704,62588,257,95531,103431,120406]

theorem envBound56673 : H12AffineFastState.Bounded env56673 := by
  intro p hp
  have h : env56673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56672_56673 : H12AffineEnvironment.transform 6 8 env56672 = env56673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56672 == env56673) = true)

theorem identity56673 : scanCanonicalize (H12AffineFastState.compose env56673 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56673 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,79131,10280,1025,8540,91467,73771,16,95497,8192,65,10588,79131,77835,97407,20565,21793,257,95531,79194,96011]

theorem envBound56674 : H12AffineFastState.Bounded env56674 := by
  intro p hp
  have h : env56674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56673_56674 : H12AffineEnvironment.transform 14 8541 env56673 = env56674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56673 == env56674) = true)

theorem identity56674 : scanCanonicalize (H12AffineFastState.compose env56674 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56674 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,10280,1025,8540,77898,73771,16,73736,8192,65,10588,79131,77835,76158,1364,32,257,73770,79194,74250]

theorem envBound56675 : H12AffineFastState.Bounded env56675 := by
  intro p hp
  have h : env56675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56674_56675 : H12AffineEnvironment.transform 13 5377 env56674 = env56675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56674 == env56675) = true)

theorem identity56675 : scanCanonicalize (H12AffineFastState.compose env56675 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56675 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56676 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,65536,77835,10280,273,8540,77898,73771,16,73736,8192,65,10588,77835,77835,76158,68,32,257,73770,77898,74250]

theorem envBound56676 : H12AffineFastState.Bounded env56676 := by
  intro p hp
  have h : env56676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56675_56676 : H12AffineEnvironment.transform 9 272 env56675 = env56676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56675 == env56676) = true)

theorem identity56676 : scanCanonicalize (H12AffineFastState.compose env56676 (packedSelected [2,4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 10330) := by decide +kernel

theorem selectedBound56676 : packedSelected [2,4,9,11] rootPS < 2^1333 := by decide +kernel

def env56677 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8541,10330,6225,10280,273,8540,6160,2161,16,2130,8192,65,10588,6225,6225,292,68,32,257,2160,6160,2640]

theorem envBound56677 : H12AffineFastState.Bounded env56677 := by
  intro p hp
  have h : env56677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56676_56677 : H12AffineEnvironment.transform 15 10330 env56676 = env56677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10330 env56676 == env56677) = true)

theorem identity56677 : scanCanonicalize (H12AffineFastState.compose env56677 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound56677 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env56678 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2112,8192,2129,8541,10330,17,10280,273,8540,80,2161,16,2130,8192,65,10588,17,17,292,68,32,257,2160,80,2640]

theorem envBound56678 : H12AffineFastState.Bounded env56678 := by
  intro p hp
  have h : env56678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56677_56678 : H12AffineEnvironment.transform 11 2112 env56677 = env56678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env56677 == env56678) = true)

theorem identity56678 : scanCanonicalize (H12AffineFastState.compose env56678 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound56678 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env56679 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,17,8192,0,8541,8203,17,8313,273,8540,80,32,16,3,8192,65,8461,17,17,292,68,32,257,33,80,513]

theorem envBound56679 : H12AffineFastState.Bounded env56679 := by
  intro p hp
  have h : env56679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56678_56679 : H12AffineEnvironment.transform 10 81 env56678 = env56679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env56678 == env56679) = true)

theorem identity56679 : scanCanonicalize (H12AffineFastState.compose env56679 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56680 : List Nat := [2,4,8,16,32,64,8,256,512,272,81,17,268,0,81,263,17,373,273,80,80,32,16,3,268,65,1,17,17,292,68,32,257,33,80,513]

theorem envBound56680 : H12AffineFastState.Bounded env56680 := by
  intro p hp
  have h : env56680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56679_56680 : H12AffineEnvironment.transform 12 268 env56679 = env56680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56679 == env56680) = true)

theorem identity56680 : scanCanonicalize (H12AffineFastState.compose env56680 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56680 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56681 : List Nat := [2,4,8,16,32,64,8,117,512,101,81,17,121,0,81,114,17,0,100,80,80,32,16,3,121,65,1,17,17,81,68,32,116,33,80,513]

theorem envBound56681 : H12AffineFastState.Bounded env56681 := by
  intro p hp
  have h : env56681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56680_56681 : H12AffineEnvironment.transform 7 117 env56680 = env56681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56680 == env56681) = true)

theorem identity56681 : scanCanonicalize (H12AffineFastState.compose env56681 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound56681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56682 : List Nat := [2,4,8,16,32,64,8,117,17,101,81,17,121,0,81,114,17,0,100,80,80,32,16,3,121,65,1,17,17,81,68,32,116,33,80,16]

theorem envBound56682 : H12AffineFastState.Bounded env56682 := by
  intro p hp
  have h : env56682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56681_56682 : H12AffineEnvironment.transform 8 17 env56681 = env56682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env56681 == env56682) = true)

theorem identity56682 : scanCanonicalize (H12AffineFastState.compose env56682 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound56682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56683 : List Nat := [2,4,8,16,32,59,8,14,17,30,42,17,2,0,42,9,17,0,31,43,43,32,16,3,2,58,1,17,17,42,63,32,15,33,43,16]

theorem envBound56683 : H12AffineFastState.Bounded env56683 := by
  intro p hp
  have h : env56683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56682_56683 : H12AffineEnvironment.transform 5 59 env56682 = env56683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env56682 == env56683) = true)

def env56684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103495,10280,1025,32769,115735,73770,16,95497,8193,65,10588,79131,102743,97406,61704,62589,257,95531,103430,120407]

theorem envBound56684 : H12AffineFastState.Bounded env56684 := by
  intro p hp
  have h : env56684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56672_56684 : H12AffineEnvironment.transform 6 9 env56672 = env56684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56672 == env56684) = true)

def env56685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115870,4194304,17,95497,8328,65,4365616,79131,102879,190520,61705,4314199,257,95530,103566,120543]

theorem envBound56685 : H12AffineFastState.Bounded env56685 := by
  intro p hp
  have h : env56685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56669_56685 : H12AffineEnvironment.transform 22 17 env56669 = env56685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56669 == env56685) = true)

theorem identity56685 : scanCanonicalize (H12AffineFastState.compose env56685 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56685 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58516,4194304,17,21763,8328,65,4365616,5393,45525,190520,61705,4256861,257,21792,46212,63189]

theorem envBound56686 : H12AffineFastState.Bounded env56686 := by
  intro p hp
  have h : env56686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56685_56686 : H12AffineEnvironment.transform 15 8202 env56685 = env56686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56685 == env56686) = true)

theorem identity56686 : scanCanonicalize (H12AffineFastState.compose env56686 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound56686 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10280,1025,32769,58516,112,17,21763,8328,65,171328,5393,45525,190520,61705,62509,257,21792,46212,63189]

theorem envBound56687 : H12AffineFastState.Bounded env56687 := by
  intro p hp
  have h : env56687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56686_56687 : H12AffineEnvironment.transform 21 112 env56686 = env56687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env56686 == env56687) = true)

theorem identity56687 : scanCanonicalize (H12AffineFastState.compose env56687 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound56687 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env56688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46276,10280,1025,32769,58516,112,17,21763,8328,65,10628,5393,45525,23804,61705,62509,257,21792,46212,63189]

theorem envBound56688 : H12AffineFastState.Bounded env56688 := by
  intro p hp
  have h : env56688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56687_56688 : H12AffineEnvironment.transform 16 46276 env56687 = env56688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env56687 == env56688) = true)

theorem identity56688 : scanCanonicalize (H12AffineFastState.compose env56688 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound56688 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29004,8202,17800,10280,1025,29005,5592,112,17,21763,8328,65,10628,5393,16537,23804,69,1377,257,21792,17864,1945]

theorem envBound56689 : H12AffineFastState.Bounded env56689 := by
  intro p hp
  have h : env56689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56688_56689 : H12AffineEnvironment.transform 14 29004 env56688 = env56689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env56688 == env56689) = true)

theorem identity56689 : scanCanonicalize (H12AffineFastState.compose env56689 (packedSelected [1,3,4,14,18,20,22,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound56689 : packedSelected [1,3,4,14,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env56690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,21540,1378,17800,3392,1025,21541,5592,112,17,21763,1504,65,3308,5393,16537,23804,69,1377,257,21792,17864,1945]

theorem envBound56690 : H12AffineFastState.Bounded env56690 := by
  intro p hp
  have h : env56690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56689_56690 : H12AffineEnvironment.transform 12 1384 env56689 = env56690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env56689 == env56690) = true)

theorem identity56690 : scanCanonicalize (H12AffineFastState.compose env56690 (packedSelected [0,5,7,8,9,11,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound56690 : packedSelected [0,5,7,8,9,11,18,20,22] rootPS < 2^1333 := by decide +kernel

def env56691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4540,1432,1378,5172,3392,1025,1433,5592,112,17,1215,1504,65,3308,5393,4389,3392,69,1377,257,1180,5236,1945]

theorem envBound56691 : H12AffineFastState.Bounded env56691 := by
  intro p hp
  have h : env56691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56690_56691 : H12AffineEnvironment.transform 13 4540 env56690 = env56691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env56690 == env56691) = true)

theorem identity56691 : scanCanonicalize (H12AffineFastState.compose env56691 (packedSelected [0,1,2,5,6,7,14,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound56691 : packedSelected [0,1,2,5,6,7,14,16,19] rootPS < 2^1333 := by decide +kernel

def env56692 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,40,4540,216,34,4468,2048,321,217,4248,112,17,511,160,65,2476,4177,4389,2048,69,33,257,476,4404,729]

theorem envBound56692 : H12AffineFastState.Bounded env56692 := by
  intro p hp
  have h : env56692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56691_56692 : H12AffineEnvironment.transform 9 320 env56691 = env56692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56691 == env56692) = true)

theorem identity56692 : scanCanonicalize (H12AffineFastState.compose env56692 (packedSelected [5,6,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound56692 : packedSelected [5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env56693 : List Nat := [2,4,8,16,32,64,128,84,512,20,2048,4096,40,4328,216,34,4128,2048,21,217,4248,112,17,171,160,65,2296,4177,4209,2048,69,33,85,136,4192,729]

theorem envBound56693 : H12AffineFastState.Bounded env56693 := by
  intro p hp
  have h : env56693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56692_56693 : H12AffineEnvironment.transform 7 84 env56692 = env56693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env56692 == env56693) = true)

theorem identity56693 : scanCanonicalize (H12AffineFastState.compose env56693 (packedSelected [0,2,5,6,7,8,16] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound56693 : packedSelected [0,2,5,6,7,8,16] rootPS < 2^1333 := by decide +kernel

def env56694 : List Nat := [2,4,8,16,32,49,128,37,512,20,2048,4096,40,4249,169,34,4128,2048,21,168,4248,1,17,171,160,48,2185,4128,4096,2048,52,33,36,136,4113,680]

theorem envBound56694 : H12AffineFastState.Bounded env56694 := by
  intro p hp
  have h : env56694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56693_56694 : H12AffineEnvironment.transform 5 49 env56693 = env56694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56693 == env56694) = true)

theorem identity56694 : scanCanonicalize (H12AffineFastState.compose env56694 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56694 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56695 : List Nat := [2,4,8,16,32,49,40,37,512,20,2048,4096,40,4145,1,34,4128,2048,21,0,4144,1,17,3,8,48,2081,4128,4096,2048,52,33,36,32,4113,512]

theorem envBound56695 : H12AffineFastState.Bounded env56695 := by
  intro p hp
  have h : env56695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56694_56695 : H12AffineEnvironment.transform 6 40 env56694 = env56695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56694 == env56695) = true)

theorem identity56695 : scanCanonicalize (H12AffineFastState.compose env56695 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound56695 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56696 : List Nat := [2,4,8,16,32,49,40,37,512,20,2048,2608,40,2561,1,34,2576,2048,21,0,2560,1,17,3,8,48,2081,2576,2608,2048,52,33,36,32,2593,512]

theorem envBound56696 : H12AffineFastState.Bounded env56696 := by
  intro p hp
  have h : env56696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56695_56696 : H12AffineEnvironment.transform 11 2608 env56695 = env56696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env56695 == env56696) = true)

theorem identity56696 : scanCanonicalize (H12AffineFastState.compose env56696 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound56696 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56697 : List Nat := [2,4,8,16,32,49,40,37,32,20,2048,2064,40,2081,1,34,2096,2048,21,0,2080,1,17,3,8,48,2081,2096,2064,2048,52,33,36,32,2049,32]

theorem envBound56697 : H12AffineFastState.Bounded env56697 := by
  intro p hp
  have h : env56697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56696_56697 : H12AffineEnvironment.transform 8 32 env56696 = env56697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env56696 == env56697) = true)

theorem identity56697 : scanCanonicalize (H12AffineFastState.compose env56697 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56697 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env56698 : List Nat := [2,4,8,16,1,16,9,4,1,20,2048,2064,9,2048,1,3,2065,2048,21,0,2049,1,17,3,8,17,2048,2065,2064,2048,21,0,5,1,2049,1]

theorem envBound56698 : H12AffineFastState.Bounded env56698 := by
  intro p hp
  have h : env56698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56697_56698 : H12AffineEnvironment.transform 4 1 env56697 = env56698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56697 == env56698) = true)

theorem identity56698 : scanCanonicalize (H12AffineFastState.compose env56698 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound56698 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56699 : List Nat := [2,4,8,16,1,16,9,4,1,20,31,15,9,31,1,3,14,31,21,0,30,1,17,3,8,17,31,14,15,31,21,0,5,1,30,1]

theorem envBound56699 : H12AffineFastState.Bounded env56699 := by
  intro p hp
  have h : env56699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56698_56699 : H12AffineEnvironment.transform 10 31 env56698 = env56699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env56698 == env56699) = true)

def leafEnv56699 : List Nat := [2,4,8,16,1,16,9,4,1,20,31,15,9,31,1,3,14,31,21,0,30,1,17,3,20,8,1,17,31,14,15,31,21,0,5,1,5,2,30,1,1,31,0]

def active56699 : List Nat := [0,1,2,3]

def tree56699 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56699 : H12WitnessSearch.Good tree56699 := H12GlobalWitnessIndex.good

theorem leafIdentity56699 : H12AffineFastState.composeSystem env56699 rootObs = leafEnv56699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56699 rootObs == leafEnv56699) = true)

theorem terminalChecked56699 : H12PackedTerminal.terminalCheckFast leafEnv56699 active56699 tree56699 = true := by decide +kernel

def env56700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,8388608,95496,8328,65,12754209,79131,8491471,8579112,8450329,4314199,257,8484155,8492191,8509135]

theorem envBound56700 : H12AffineFastState.Bounded env56700 := by
  intro p hp
  have h : env56700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56668_56700 : H12AffineEnvironment.transform 17 10281 env56668 = env56700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56668 == env56700) = true)

def env56701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,16,95496,8328,65,4365617,79131,102879,190520,61705,4314199,257,95531,103567,120543]

theorem envBound56701 : H12AffineFastState.Bounded env56701 := by
  intro p hp
  have h : env56701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56700_56701 : H12AffineEnvironment.transform 22 16 env56700 = env56701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56700 == env56701) = true)

theorem identity56701 : scanCanonicalize (H12AffineFastState.compose env56701 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 119927) := by decide +kernel

theorem selectedBound56701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,119927,16,95496,8328,65,215366,79131,102879,190520,61705,32,257,95531,103567,120543]

theorem envBound56702 : H12AffineFastState.Bounded env56702 := by
  intro p hp
  have h : env56702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56701_56702 : H12AffineEnvironment.transform 21 119927 env56701 = env56702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119927 env56701 == env56702) = true)

theorem identity56702 : scanCanonicalize (H12AffineFastState.compose env56702 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56702 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env56703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115871,119927,16,95496,8328,65,10588,79131,102879,100386,61705,32,257,95531,103567,120543]

theorem envBound56703 : H12AffineFastState.Bounded env56703 := by
  intro p hp
  have h : env56703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56702_56703 : H12AffineEnvironment.transform 16 90138 env56702 = env56703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56702 == env56703) = true)

theorem identity56703 : scanCanonicalize (H12AffineFastState.compose env56703 (packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56703 : packedSelected [0,3,4,7,10,11,12,15,16,17,18,20,22,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env56704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1025,32769,115734,119927,16,95496,8193,65,10588,79131,102742,100386,61705,32,257,95531,103430,120406]

theorem envBound56704 : H12AffineFastState.Bounded env56704 := by
  intro p hp
  have h : env56704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56703_56704 : H12AffineEnvironment.transform 6 9 env56703 = env56704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56703 == env56704) = true)

theorem identity56704 : scanCanonicalize (H12AffineFastState.compose env56704 (packedSelected [0,1,2,3,6,11,12,14,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound56704 : packedSelected [0,1,2,3,6,11,12,14,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,57677,10281,1025,32769,17729,21792,16,62559,8193,65,10588,46156,4097,2421,61705,32,257,62588,5457,22273]

theorem envBound56705 : H12AffineFastState.Bounded env56705 := by
  intro p hp
  have h : env56705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56704_56705 : H12AffineEnvironment.transform 15 33111 env56704 = env56705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env56704 == env56705) = true)

theorem identity56705 : scanCanonicalize (H12AffineFastState.compose env56705 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56705 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env56706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33111,49168,2420,1025,32769,17729,21792,16,54530,348,65,2049,38161,4097,2421,53332,32,257,54561,5457,22273]

theorem envBound56706 : H12AffineFastState.Bounded env56706 := by
  intro p hp
  have h : env56706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56705_56706 : H12AffineEnvironment.transform 12 349 env56705 = env56706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56705 == env56706) = true)

def env56707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115871,4194304,17,95496,8328,65,4365616,79131,102878,190521,61704,4314199,257,95530,103566,120542]

theorem envBound56707 : H12AffineFastState.Bounded env56707 := by
  intro p hp
  have h : env56707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56700_56707 : H12AffineEnvironment.transform 22 17 env56700 = env56707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56700 == env56707) = true)

theorem identity56707 : scanCanonicalize (H12AffineFastState.compose env56707 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound56707 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4160,4194304,17,41431,8328,65,4365616,57796,17665,190521,61704,4194440,257,41461,16465,513]

theorem envBound56708 : H12AffineFastState.Bounded env56708 := by
  intro p hp
  have h : env56708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56707_56708 : H12AffineEnvironment.transform 15 54495 env56707 = env56708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env56707 == env56708) = true)

def env56709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1025,32769,4160,4194304,17,41311,8192,65,4365616,57676,17665,190521,61704,4194304,257,41341,16465,513]

theorem envBound56709 : H12AffineFastState.Bounded env56709 := by
  intro p hp
  have h : env56709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56708_56709 : H12AffineEnvironment.transform 6 8 env56708 = env56709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56708 == env56709) = true)

theorem identity56709 : scanCanonicalize (H12AffineFastState.compose env56709 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56709 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10281,1025,8540,4160,4194304,17,2,8192,65,4340845,16401,17665,149860,20565,4194304,257,32,16465,513]

theorem envBound56710 : H12AffineFastState.Bounded env56710 := by
  intro p hp
  have h : env56710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56709_56710 : H12AffineEnvironment.transform 14 8541 env56709 = env56710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56709 == env56710) = true)

theorem identity56710 : scanCanonicalize (H12AffineFastState.compose env56710 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56710 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56711 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,131072,10281,273,8540,4160,4194304,17,2,8192,65,4340093,16401,16401,149860,20565,4194304,257,32,16465,513]

theorem envBound56711 : H12AffineFastState.Bounded env56711 := by
  intro p hp
  have h : env56711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56710_56711 : H12AffineEnvironment.transform 9 272 env56710 = env56711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56710 == env56711) = true)

theorem identity56711 : scanCanonicalize (H12AffineFastState.compose env56711 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound56711 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env56712 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,10281,273,8540,4160,4194304,17,2,8192,65,4204925,16401,16401,22884,20565,4194304,257,32,16465,513]

theorem envBound56712 : H12AffineFastState.Bounded env56712 := by
  intro p hp
  have h : env56712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56711_56712 : H12AffineEnvironment.transform 16 4096 env56711 = env56712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env56711 == env56712) = true)

theorem identity56712 : scanCanonicalize (H12AffineFastState.compose env56712 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 2081) := by decide +kernel

theorem selectedBound56712 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56713 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28698,4096,10281,273,8540,4160,2081,17,2,8192,65,8540,16401,16401,22884,20565,2081,257,32,16465,513]

theorem envBound56713 : H12AffineFastState.Bounded env56713 := by
  intro p hp
  have h : env56713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56712_56713 : H12AffineEnvironment.transform 21 2081 env56712 = env56713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2081 env56712 == env56713) = true)

theorem identity56713 : scanCanonicalize (H12AffineFastState.compose env56713 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound56713 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env56714 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,2317,16384,2128,22807,4096,292,273,2129,4160,2081,17,2,2317,65,2129,16401,16401,22884,20565,2081,257,32,16465,513]

theorem envBound56714 : H12AffineFastState.Bounded env56714 := by
  intro p hp
  have h : env56714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56713_56714 : H12AffineEnvironment.transform 12 2317 env56713 = env56714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env56713 == env56714) = true)

theorem identity56714 : scanCanonicalize (H12AffineFastState.compose env56714 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound56714 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56715 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,2317,2048,2128,4375,4096,292,273,2129,4160,2081,17,2,2317,65,2129,2065,2065,4452,6229,2081,257,32,2129,513]

theorem envBound56715 : H12AffineFastState.Bounded env56715 := by
  intro p hp
  have h : env56715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56714_56715 : H12AffineEnvironment.transform 13 2048 env56714 = env56715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env56714 == env56715) = true)

theorem identity56715 : scanCanonicalize (H12AffineFastState.compose env56715 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56715 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56716 : List Nat := [2,4,8,16,32,64,8,256,512,272,0,4096,269,0,80,4375,4096,292,273,81,4160,33,17,2,269,65,81,17,17,4452,4181,33,257,32,81,513]

theorem envBound56716 : H12AffineFastState.Bounded env56716 := by
  intro p hp
  have h : env56716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56715_56716 : H12AffineEnvironment.transform 10 0 env56715 = env56716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56715 == env56716) = true)

theorem identity56716 : scanCanonicalize (H12AffineFastState.compose env56716 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound56716 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env56717 : List Nat := [2,4,8,16,32,64,8,256,292,272,0,4096,269,0,80,4375,4096,292,273,81,4160,33,17,2,269,65,81,17,17,4452,4181,33,257,32,81,293]

theorem envBound56717 : H12AffineFastState.Bounded env56717 := by
  intro p hp
  have h : env56717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56716_56717 : H12AffineEnvironment.transform 8 292 env56716 = env56717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env56716 == env56717) = true)

theorem identity56717 : scanCanonicalize (H12AffineFastState.compose env56717 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 341) := by decide +kernel

theorem selectedBound56717 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56718 : List Nat := [2,4,8,16,32,64,8,256,292,272,0,341,269,0,80,66,341,292,273,81,277,33,17,2,269,65,81,17,17,49,256,33,257,32,81,293]

theorem envBound56718 : H12AffineFastState.Bounded env56718 := by
  intro p hp
  have h : env56718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56717_56718 : H12AffineEnvironment.transform 11 341 env56717 = env56718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 341 env56717 == env56718) = true)

theorem identity56718 : scanCanonicalize (H12AffineFastState.compose env56718 (packedSelected [0,2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56718 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env56719 : List Nat := [2,4,8,16,32,64,8,37,1,53,0,112,40,0,80,66,112,1,52,81,48,33,17,2,40,65,81,17,17,49,37,33,36,32,81,0]

theorem envBound56719 : H12AffineFastState.Bounded env56719 := by
  intro p hp
  have h : env56719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56718_56719 : H12AffineEnvironment.transform 7 37 env56718 = env56719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56718 == env56719) = true)

theorem identity56719 : scanCanonicalize (H12AffineFastState.compose env56719 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56719 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56720 : List Nat := [2,4,8,0,32,64,8,37,1,37,0,96,40,0,64,66,96,1,36,65,32,33,1,2,40,65,65,1,1,33,37,33,36,32,65,0]

theorem envBound56720 : H12AffineFastState.Bounded env56720 := by
  intro p hp
  have h : env56720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56719_56720 : H12AffineEnvironment.transform 3 0 env56719 = env56720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56719 == env56720) = true)

theorem identity56720 : scanCanonicalize (H12AffineFastState.compose env56720 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

end H12CloudChart1