import H12CloudChart1Data137

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans35013_35014 : H12AffineEnvironment.transform 11 554 env35013 = env35014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env35013 == env35014) = true)

def env35015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491429,2098648,4096,2524496,2102684,2142524,256,168,46213,2175562]

theorem envBound35015 : H12AffineFastState.Bounded env35015 := by
  intro p hp
  have h : env35015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34980_35015 : H12AffineEnvironment.transform 21 33 env34980 = env35015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env34980 == env35015) = true)

theorem identity35015 : scanCanonicalize (H12AffineFastState.compose env35015 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound35015 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,33,16,98644,8328,64,398573,5392,4096,431512,1364,41460,256,168,46213,74370]

theorem envBound35016 : H12AffineFastState.Bounded env35016 := by
  intro p hp
  have h : env35016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35015_35016 : H12AffineEnvironment.transform 20 4296 env35015 = env35016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env35015 == env35016) = true)

def env35017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398437,5392,4096,431376,1364,41340,256,32,46093,74250]

theorem envBound35017 : H12AffineFastState.Bounded env35017 := by
  intro p hp
  have h : env35017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35016_35017 : H12AffineEnvironment.transform 6 8 env35016 = env35017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35016 == env35017) = true)

theorem identity35017 : scanCanonicalize (H12AffineFastState.compose env35017 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35017 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,33,16,73737,8192,64,398437,5392,4096,406605,1364,33,256,32,5456,74250]

theorem envBound35018 : H12AffineFastState.Bounded env35018 := by
  intro p hp
  have h : env35018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35017_35018 : H12AffineEnvironment.transform 14 8541 env35017 = env35018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35017 == env35018) = true)

theorem identity35018 : scanCanonicalize (H12AffineFastState.compose env35018 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212030) := by decide +kernel

theorem selectedBound35018 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,212030,1024,8540,4160,33,16,73737,8192,64,75867,5392,4096,67699,1364,33,256,32,5456,74250]

theorem envBound35019 : H12AffineFastState.Bounded env35019 := by
  intro p hp
  have h : env35019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35018_35019 : H12AffineEnvironment.transform 17 212030 env35018 = env35019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212030 env35018 == env35019) = true)

theorem identity35019 : scanCanonicalize (H12AffineFastState.compose env35019 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound35019 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env35020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,70963,10509,1024,8540,4160,33,16,73737,8192,64,75867,5392,4096,67699,1364,33,256,32,5456,74250]

theorem envBound35020 : H12AffineFastState.Bounded env35020 := by
  intro p hp
  have h : env35020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35019_35020 : H12AffineEnvironment.transform 16 70963 env35019 = env35020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env35019 == env35020) = true)

theorem identity35020 : scanCanonicalize (H12AffineFastState.compose env35020 (packedSelected [1,2,3,4,5,6,8,9,10,14,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 9547) := by decide +kernel

theorem selectedBound35020 : packedSelected [1,2,3,4,5,6,8,9,10,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env35021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9547,12408,10509,1024,8540,4160,33,16,1346,8192,64,3344,5392,4096,11576,1364,33,256,32,5456,1857]

theorem envBound35021 : H12AffineFastState.Bounded env35021 := by
  intro p hp
  have h : env35021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35020_35021 : H12AffineEnvironment.transform 15 9547 env35020 = env35021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9547 env35020 == env35021) = true)

def env35022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98644,8193,64,398436,5392,4096,431377,1364,41341,256,33,46092,74251]

theorem envBound35022 : H12AffineFastState.Bounded env35022 := by
  intro p hp
  have h : env35022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35016_35022 : H12AffineEnvironment.transform 6 9 env35016 = env35022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35016 == env35022) = true)

theorem identity35022 : scanCanonicalize (H12AffineFastState.compose env35022 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35022 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env35023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398436,5392,4096,431377,1364,41341,256,33,46092,513]

theorem envBound35023 : H12AffineFastState.Bounded env35023 := by
  intro p hp
  have h : env35023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35022_35023 : H12AffineEnvironment.transform 15 8202 env35022 = env35023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35022 == env35023) = true)

theorem identity35023 : scanCanonicalize (H12AffineFastState.compose env35023 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35023 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398436,5392,4096,406604,1364,32,256,33,5457,513]

theorem envBound35024 : H12AffineFastState.Bounded env35024 := by
  intro p hp
  have h : env35024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35023_35024 : H12AffineEnvironment.transform 14 8541 env35023 = env35024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35023 == env35024) = true)

theorem identity35024 : scanCanonicalize (H12AffineFastState.compose env35024 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35024 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35025 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,33,16,3,8193,16,398388,5392,4096,406556,1284,32,256,33,5377,513]

theorem envBound35025 : H12AffineFastState.Bounded env35025 := by
  intro p hp
  have h : env35025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35024_35025 : H12AffineEnvironment.transform 5 16 env35024 = env35025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35024 == env35025) = true)

theorem identity35025 : scanCanonicalize (H12AffineFastState.compose env35025 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound35025 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35026 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,138292,1024,8460,4113,33,16,3,8193,16,2048,5392,4096,10280,1284,32,256,33,5377,513]

theorem envBound35026 : H12AffineFastState.Bounded env35026 := by
  intro p hp
  have h : env35026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35025_35026 : H12AffineEnvironment.transform 17 138292 env35025 = env35026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env35025 == env35026) = true)

theorem identity35026 : scanCanonicalize (H12AffineFastState.compose env35026 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound35026 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35027 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10280,1024,8460,4113,33,16,3,8193,16,2048,5392,4096,10280,1284,32,256,33,5377,513]

theorem envBound35027 : H12AffineFastState.Bounded env35027 := by
  intro p hp
  have h : env35027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35026_35027 : H12AffineEnvironment.transform 16 13340 env35026 = env35027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env35026 == env35027) = true)

theorem identity35027 : scanCanonicalize (H12AffineFastState.compose env35027 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35027 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35028 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1024,0,4113,33,16,3,269,16,2048,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound35028 : H12AffineFastState.Bounded env35028 := by
  intro p hp
  have h : env35028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35027_35028 : H12AffineEnvironment.transform 12 268 env35027 = env35028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35027 == env35028) = true)

theorem identity35028 : scanCanonicalize (H12AffineFastState.compose env35028 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35028 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35029 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5173,2049,1024,0,4113,33,16,3,40,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound35029 : H12AffineFastState.Bounded env35029 := by
  intro p hp
  have h : env35029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35028_35029 : H12AffineEnvironment.transform 7 37 env35028 = env35029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35028 == env35029) = true)

def env35030 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,1,35,1029,2049,1024,0,33,33,16,3,40,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound35030 : H12AffineFastState.Bounded env35030 := by
  intro p hp
  have h : env35030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35029_35030 : H12AffineEnvironment.transform 11 48 env35029 = env35030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35029 == env35030) = true)

def env35031 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,41,32,1,35,49,2049,52,0,33,33,16,3,40,16,2048,49,48,2049,21,32,37,33,32,513]

theorem envBound35031 : H12AffineFastState.Bounded env35031 := by
  intro p hp
  have h : env35031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35030_35031 : H12AffineEnvironment.transform 9 52 env35030 = env35031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35030 == env35031) = true)

theorem identity35031 : scanCanonicalize (H12AffineFastState.compose env35031 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound35031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35032 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,48,41,32,1,35,49,2049,52,0,33,33,16,3,40,16,2048,49,48,2049,21,32,37,33,32,10]

theorem envBound35032 : H12AffineFastState.Bounded env35032 := by
  intro p hp
  have h : env35032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35031_35032 : H12AffineEnvironment.transform 8 11 env35031 = env35032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env35031 == env35032) = true)

def leafEnv35032 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,48,41,32,1,35,49,2049,52,0,33,33,16,3,21,40,1,16,2048,49,48,2049,21,32,37,33,4,34,32,10,1,33,0]

def active35032 : List Nat := [0,1,2,3,4,10]

def tree35032 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35032 : H12WitnessSearch.Good tree35032 := H12GlobalWitnessIndex.good

theorem leafIdentity35032 : H12AffineFastState.composeSystem env35032 rootObs = leafEnv35032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35032 rootObs == leafEnv35032) = true)

theorem terminalChecked35032 : H12PackedTerminal.terminalCheckFast leafEnv35032 active35032 tree35032 = true := by decide +kernel

def env35033 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,41,33,1,35,48,2049,53,0,33,33,16,3,40,16,2048,48,48,2049,20,32,37,33,33,513]

theorem envBound35033 : H12AffineFastState.Bounded env35033 := by
  intro p hp
  have h : env35033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35030_35033 : H12AffineEnvironment.transform 9 53 env35030 = env35033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35030 == env35033) = true)

theorem identity35033 : scanCanonicalize (H12AffineFastState.compose env35033 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35033 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35034 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,1,1,3,16,2049,21,0,1,1,16,3,8,16,2048,16,16,2049,20,0,5,1,1,513]

theorem envBound35034 : H12AffineFastState.Bounded env35034 := by
  intro p hp
  have h : env35034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35033_35034 : H12AffineEnvironment.transform 4 0 env35033 = env35034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35033 == env35034) = true)

def leafEnv35034 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,1,1,3,16,2049,21,0,1,1,16,3,20,8,1,16,2048,16,16,2049,20,0,5,1,4,2,1,513,1,1,0]

def active35034 : List Nat := [0,1,2,3,8,10]

def tree35034 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35034 : H12WitnessSearch.Good tree35034 := H12GlobalWitnessIndex.good

theorem leafIdentity35034 : H12AffineFastState.composeSystem env35034 rootObs = leafEnv35034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35034 rootObs == leafEnv35034) = true)

theorem terminalChecked35034 : H12PackedTerminal.terminalCheckFast leafEnv35034 active35034 tree35034 = true := by decide +kernel

def env35035 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,1,35,1028,2049,1024,0,32,33,16,3,40,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound35035 : H12AffineFastState.Bounded env35035 := by
  intro p hp
  have h : env35035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35029_35035 : H12AffineEnvironment.transform 11 49 env35029 = env35035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35029 == env35035) = true)

theorem identity35035 : scanCanonicalize (H12AffineFastState.compose env35035 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35036 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,41,33,1,35,48,2049,52,0,32,33,16,3,40,16,2048,48,49,2049,21,32,37,33,33,513]

theorem envBound35036 : H12AffineFastState.Bounded env35036 := by
  intro p hp
  have h : env35036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35035_35036 : H12AffineEnvironment.transform 9 52 env35035 = env35036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35035 == env35036) = true)

theorem identity35036 : scanCanonicalize (H12AffineFastState.compose env35036 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound35036 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35037 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,49,41,33,1,35,48,2049,52,0,32,33,16,3,40,16,2048,48,49,2049,21,32,37,33,33,11]

theorem envBound35037 : H12AffineFastState.Bounded env35037 := by
  intro p hp
  have h : env35037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35036_35037 : H12AffineEnvironment.transform 8 10 env35036 = env35037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env35036 == env35037) = true)

def leafEnv35037 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,49,41,33,1,35,48,2049,52,0,32,33,16,3,21,40,1,16,2048,48,49,2049,21,32,37,33,4,34,33,11,1,32,0]

def active35037 : List Nat := [0,1,2,3,4,10]

def tree35037 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35037 : H12WitnessSearch.Good tree35037 := H12GlobalWitnessIndex.good

theorem leafIdentity35037 : H12AffineFastState.composeSystem env35037 rootObs = leafEnv35037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35037 rootObs == leafEnv35037) = true)

theorem terminalChecked35037 : H12PackedTerminal.terminalCheckFast leafEnv35037 active35037 tree35037 = true := by decide +kernel

def env35038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685700,2098649,4097,2524497,2102684,6336796,256,168,46213,2175562]

theorem envBound35038 : H12AffineFastState.Bounded env35038 := by
  intro p hp
  have h : env35038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34979_35038 : H12AffineEnvironment.transform 22 2101465 env34979 = env35038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env34979 == env35038) = true)

def env35039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491428,2098649,4097,2524497,2102684,2142524,256,168,46213,2175562]

theorem envBound35039 : H12AffineFastState.Bounded env35039 := by
  intro p hp
  have h : env35039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35038_35039 : H12AffineEnvironment.transform 21 32 env35038 = env35039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35038 == env35039) = true)

theorem identity35039 : scanCanonicalize (H12AffineFastState.compose env35039 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35039 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,262144,1024,8540,2097152,32,2101465,73736,8328,64,2491428,2098649,4097,2499596,2102684,2101345,256,168,5592,2175562]

theorem envBound35040 : H12AffineFastState.Bounded env35040 := by
  intro p hp
  have h : env35040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35039_35040 : H12AffineEnvironment.transform 14 8541 env35039 = env35040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35039 == env35040) = true)

def env35041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10400,1024,8540,2097152,32,2101465,73736,8328,64,2239620,2098649,4097,2231468,2102684,2101345,256,168,5592,2175562]

theorem envBound35041 : H12AffineFastState.Bounded env35041 := by
  intro p hp
  have h : env35041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35040_35041 : H12AffineEnvironment.transform 17 10400 env35040 = env35041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35040 == env35041) = true)

theorem identity35041 : scanCanonicalize (H12AffineFastState.compose env35041 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound35041 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10400,1024,8540,4297,32,16,73736,8328,64,146509,5392,4097,138341,1365,168,256,168,5592,74371]

theorem envBound35042 : H12AffineFastState.Bounded env35042 := by
  intro p hp
  have h : env35042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35041_35042 : H12AffineEnvironment.transform 20 4297 env35041 = env35042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env35041 == env35042) = true)

theorem identity35042 : scanCanonicalize (H12AffineFastState.compose env35042 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound35042 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,5393,10400,1024,8540,4297,32,16,73736,8328,64,10588,5392,4097,2420,1365,168,256,168,5592,74371]

theorem envBound35043 : H12AffineFastState.Bounded env35043 := by
  intro p hp
  have h : env35043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35042_35043 : H12AffineEnvironment.transform 16 5393 env35042 = env35043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env35042 == env35043) = true)

theorem identity35043 : scanCanonicalize (H12AffineFastState.compose env35043 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound35043 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,5393,10400,1024,8540,4297,32,16,138,8328,64,10588,5392,4097,2420,1365,168,256,168,5592,513]

theorem envBound35044 : H12AffineFastState.Bounded env35044 := by
  intro p hp
  have h : env35044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35043_35044 : H12AffineEnvironment.transform 15 8322 env35043 = env35044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env35043 == env35044) = true)

theorem identity35044 : scanCanonicalize (H12AffineFastState.compose env35044 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound35044 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,2184,8541,8322,2065,10400,1024,8540,3529,32,16,138,8328,64,10588,2064,3329,2420,1365,168,256,168,2264,513]

theorem envBound35045 : H12AffineFastState.Bounded env35045 := by
  intro p hp
  have h : env35045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35044_35045 : H12AffineEnvironment.transform 11 3328 env35044 = env35045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env35044 == env35045) = true)

theorem identity35045 : scanCanonicalize (H12AffineFastState.compose env35045 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35045 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env35046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,8192,137,8541,8322,16,8353,1024,8540,1480,32,16,138,8328,64,8541,17,1280,373,1365,168,256,168,217,513]

theorem envBound35046 : H12AffineFastState.Bounded env35046 := by
  intro p hp
  have h : env35046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35045_35046 : H12AffineEnvironment.transform 10 1 env35045 = env35046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35045 == env35046) = true)

theorem identity35046 : scanCanonicalize (H12AffineFastState.compose env35046 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound35046 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env35047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1281,1337,137,1124,1467,16,1432,1024,1125,1480,32,16,138,1457,64,1124,17,1280,373,1365,168,256,168,217,513]

theorem envBound35047 : H12AffineFastState.Bounded env35047 := by
  intro p hp
  have h : env35047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35046_35047 : H12AffineEnvironment.transform 12 1337 env35046 = env35047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env35046 == env35047) = true)

theorem identity35047 : scanCanonicalize (H12AffineFastState.compose env35047 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound35047 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env35048 : List Nat := [2,4,8,16,32,64,128,256,512,188,1,445,389,137,216,263,16,292,188,217,372,32,16,138,269,64,216,17,444,373,489,168,256,168,217,513]

theorem envBound35048 : H12AffineFastState.Bounded env35048 := by
  intro p hp
  have h : env35048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35047_35048 : H12AffineEnvironment.transform 9 188 env35047 = env35048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env35047 == env35048) = true)

theorem identity35048 : scanCanonicalize (H12AffineFastState.compose env35048 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35048 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35049 : List Nat := [2,4,8,16,32,64,8,256,512,52,1,309,269,1,80,263,16,292,52,81,372,32,16,2,269,64,80,17,308,373,353,32,256,32,81,513]

theorem envBound35049 : H12AffineFastState.Bounded env35049 := by
  intro p hp
  have h : env35049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35048_35049 : H12AffineEnvironment.transform 6 8 env35048 = env35049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35048 == env35049) = true)

theorem identity35049 : scanCanonicalize (H12AffineFastState.compose env35049 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35049 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35050 : List Nat := [2,4,8,16,32,64,8,36,512,52,1,17,41,1,80,35,16,0,52,81,80,32,16,2,41,64,80,17,16,81,69,32,36,32,81,513]

theorem envBound35050 : H12AffineFastState.Bounded env35050 := by
  intro p hp
  have h : env35050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35049_35050 : H12AffineEnvironment.transform 7 36 env35049 = env35050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35049 == env35050) = true)

def env35051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,2097152,32,2101465,73736,8328,64,2239621,2098649,4097,2231469,2102684,2101345,256,168,5592,2175562]

theorem envBound35051 : H12AffineFastState.Bounded env35051 := by
  intro p hp
  have h : env35051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35040_35051 : H12AffineEnvironment.transform 17 10401 env35040 = env35051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35040 == env35051) = true)

def env35052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,132432,32,136585,73736,8328,64,10709,131209,4097,2557,135372,136497,256,168,5592,210714]

theorem envBound35052 : H12AffineFastState.Bounded env35052 := by
  intro p hp
  have h : env35052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35051_35052 : H12AffineEnvironment.transform 20 132432 env35051 = env35052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132432 env35051 == env35052) = true)

theorem identity35052 : scanCanonicalize (H12AffineFastState.compose env35052 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35052 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env35053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8323,131072,10401,1024,8540,132432,32,136585,139,8328,64,10709,131209,4097,2557,135372,136497,256,168,5592,137113]

theorem envBound35053 : H12AffineFastState.Bounded env35053 := by
  intro p hp
  have h : env35053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35052_35053 : H12AffineEnvironment.transform 15 8323 env35052 = env35053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35052 == env35053) = true)

theorem identity35053 : scanCanonicalize (H12AffineFastState.compose env35053 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound35053 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8323,5392,10401,1024,8540,4160,32,153,139,8328,64,10709,5529,4097,2557,1500,33,256,168,5592,649]

theorem envBound35054 : H12AffineFastState.Bounded env35054 := by
  intro p hp
  have h : env35054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35053_35054 : H12AffineEnvironment.transform 16 5392 env35053 = env35054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env35053 == env35054) = true)

theorem identity35054 : scanCanonicalize (H12AffineFastState.compose env35054 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35054 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35055 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5373,8232,8323,5221,10401,1024,8233,4160,32,153,139,8328,64,10400,5356,4097,2184,1193,33,117,168,5293,649]

theorem envBound35055 : H12AffineFastState.Bounded env35055 := by
  intro p hp
  have h : env35055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35054_35055 : H12AffineEnvironment.transform 7 117 env35054 = env35055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35054 == env35055) = true)

theorem identity35055 : scanCanonicalize (H12AffineFastState.compose env35055 (packedSelected [6,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound35055 : packedSelected [6,11,14,18] rootPS < 2^1333 := by decide +kernel

def env35056 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,5373,216,115,5221,2129,1024,217,4160,32,153,139,120,64,2128,5356,4097,2184,1193,33,117,168,5293,649]

theorem envBound35056 : H12AffineFastState.Bounded env35056 := by
  intro p hp
  have h : env35056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35055_35056 : H12AffineEnvironment.transform 12 240 env35055 = env35056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env35055 == env35056) = true)

def env35057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,132433,32,136584,73736,8328,64,10708,131208,4097,2556,135373,136496,256,168,5592,210715]

theorem envBound35057 : H12AffineFastState.Bounded env35057 := by
  intro p hp
  have h : env35057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35051_35057 : H12AffineEnvironment.transform 20 132433 env35051 = env35057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132433 env35051 == env35057) = true)

theorem identity35057 : scanCanonicalize (H12AffineFastState.compose env35057 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound35057 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env35058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,70862,10401,1024,8540,70047,32,65862,73736,8328,64,10708,70726,4097,2556,66563,66046,256,168,5592,9173]

theorem envBound35058 : H12AffineFastState.Bounded env35058 := by
  intro p hp
  have h : env35058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35057_35058 : H12AffineEnvironment.transform 16 70862 env35057 = env35058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env35057 == env35058) = true)

def env35059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491429,2098649,4097,2524497,2102684,2142525,256,168,46213,2175562]

theorem envBound35059 : H12AffineFastState.Bounded env35059 := by
  intro p hp
  have h : env35059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35038_35059 : H12AffineEnvironment.transform 21 33 env35038 = env35059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35038 == env35059) = true)

theorem identity35059 : scanCanonicalize (H12AffineFastState.compose env35059 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound35059 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,45460,33,41293,98645,8328,64,439729,46157,4097,406725,41992,169,256,168,46213,99294]

theorem envBound35060 : H12AffineFastState.Bounded env35060 := by
  intro p hp
  have h : env35060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35059_35060 : H12AffineEnvironment.transform 20 45460 env35059 = env35060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env35059 == env35060) = true)

theorem identity35060 : scanCanonicalize (H12AffineFastState.compose env35060 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound35060 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,108926,1024,32769,45460,33,41293,98645,8328,64,203983,46157,4097,236987,41992,169,256,168,46213,99294]

theorem envBound35061 : H12AffineFastState.Bounded env35061 := by
  intro p hp
  have h : env35061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35060_35061 : H12AffineEnvironment.transform 17 108926 env35060 = env35061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env35060 == env35061) = true)

theorem identity35061 : scanCanonicalize (H12AffineFastState.compose env35061 (packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound35061 : packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,10401,1024,32769,45460,33,41293,138,8328,64,171280,46157,4097,138340,41992,169,256,168,46213,513]

theorem envBound35062 : H12AffineFastState.Bounded env35062 := by
  intro p hp
  have h : env35062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35061_35062 : H12AffineEnvironment.transform 15 33247 env35061 = env35062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env35061 == env35062) = true)

theorem identity35062 : scanCanonicalize (H12AffineFastState.compose env35062 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35062 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,13341,10401,1024,32769,45460,33,41293,138,8328,64,43277,46157,4097,10361,41992,169,256,168,46213,513]

theorem envBound35063 : H12AffineFastState.Bounded env35063 := by
  intro p hp
  have h : env35063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35062_35063 : H12AffineEnvironment.transform 16 13341 env35062 = env35063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env35062 == env35063) = true)

theorem identity35063 : scanCanonicalize (H12AffineFastState.compose env35063 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound35063 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env35064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,217,262,13341,10401,1024,216,12621,33,8596,138,8328,64,10708,13460,4097,10361,9425,169,256,168,13404,513]

theorem envBound35064 : H12AffineFastState.Bounded env35064 := by
  intro p hp
  have h : env35064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35063_35064 : H12AffineEnvironment.transform 14 217 env35063 = env35064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env35063 == env35064) = true)

theorem identity35064 : scanCanonicalize (H12AffineFastState.compose env35064 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound35064 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35065 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5457,0,262,13341,10360,1024,1,12621,33,8525,83,8273,64,10509,13389,4097,10361,9224,112,256,113,13404,513]

theorem envBound35065 : H12AffineFastState.Bounded env35065 := by
  intro p hp
  have h : env35065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35064_35065 : H12AffineEnvironment.transform 6 89 env35064 = env35065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35064 == env35065) = true)

theorem identity35065 : scanCanonicalize (H12AffineFastState.compose env35065 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35065 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35066 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5457,0,262,5393,2420,1024,1,4161,33,65,83,349,64,2049,5441,4097,2421,1284,112,256,113,5456,513]

theorem envBound35066 : H12AffineFastState.Bounded env35066 := by
  intro p hp
  have h : env35066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35065_35066 : H12AffineEnvironment.transform 12 268 env35065 = env35066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35065 == env35066) = true)

theorem identity35066 : scanCanonicalize (H12AffineFastState.compose env35066 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35066 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35067 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1024,1,4112,33,16,2,268,17,2049,5392,4097,2340,1284,33,256,32,5377,513]

theorem envBound35067 : H12AffineFastState.Bounded env35067 := by
  intro p hp
  have h : env35067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35066_35067 : H12AffineEnvironment.transform 5 17 env35066 = env35067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35066 == env35067) = true)

theorem identity35067 : scanCanonicalize (H12AffineFastState.compose env35067 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35067 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35068 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4113,0,262,4096,2341,273,1,4112,33,16,2,268,17,2049,4097,4097,2340,21,33,256,32,4112,513]

theorem envBound35068 : H12AffineFastState.Bounded env35068 := by
  intro p hp
  have h : env35068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35067_35068 : H12AffineEnvironment.transform 9 273 env35067 = env35068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35067 == env35068) = true)

theorem identity35068 : scanCanonicalize (H12AffineFastState.compose env35068 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35068 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35069 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4113,0,35,4096,2048,52,1,4112,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4112,513]

theorem envBound35069 : H12AffineFastState.Bounded env35069 := by
  intro p hp
  have h : env35069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35068_35069 : H12AffineEnvironment.transform 7 37 env35068 = env35069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35068 == env35069) = true)

theorem identity35069 : scanCanonicalize (H12AffineFastState.compose env35069 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35070 : List Nat := [2,4,8,16,32,17,8,37,49,52,2048,4096,41,4113,0,35,4096,2048,52,1,4112,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4112,48]

theorem envBound35070 : H12AffineFastState.Bounded env35070 := by
  intro p hp
  have h : env35070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35069_35070 : H12AffineEnvironment.transform 8 49 env35069 = env35070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35069 == env35070) = true)

theorem identity35070 : scanCanonicalize (H12AffineFastState.compose env35070 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35071 : List Nat := [2,4,8,16,32,17,8,37,49,52,1,4096,41,4113,0,35,4096,1,52,1,4112,33,16,2,41,17,0,4097,4097,0,21,33,37,32,4112,48]

theorem envBound35071 : H12AffineFastState.Bounded env35071 := by
  intro p hp
  have h : env35071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35070_35071 : H12AffineEnvironment.transform 10 1 env35070 = env35071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35070 == env35071) = true)

theorem identity35071 : scanCanonicalize (H12AffineFastState.compose env35071 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound35071 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35072 : List Nat := [2,4,8,16,32,17,8,37,49,52,1,17,41,0,0,35,17,1,52,1,1,33,16,2,41,17,0,16,16,0,21,33,37,32,1,48]

theorem envBound35072 : H12AffineFastState.Bounded env35072 := by
  intro p hp
  have h : env35072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35071_35072 : H12AffineEnvironment.transform 11 17 env35071 = env35072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env35071 == env35072) = true)

def env35073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685700,8393985,10485977,8820105,2102685,12624325,256,168,46212,2175563]

theorem envBound35073 : H12AffineFastState.Bounded env35073 := by
  intro p hp
  have h : env35073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34978_35073 : H12AffineEnvironment.transform 13 5513 env34978 = env35073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env34978 == env35073) = true)

def env35074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685700,2098649,4097,2524497,2102685,6336797,256,168,46212,2175563]

theorem envBound35074 : H12AffineFastState.Bounded env35074 := by
  intro p hp
  have h : env35074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35073_35074 : H12AffineEnvironment.transform 22 2101464 env35073 = env35074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env35073 == env35074) = true)

def env35075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491428,2098649,4097,2524497,2102685,2142525,256,168,46212,2175563]

theorem envBound35075 : H12AffineFastState.Bounded env35075 := by
  intro p hp
  have h : env35075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35074_35075 : H12AffineEnvironment.transform 21 32 env35074 = env35075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35074 == env35075) = true)

theorem identity35075 : scanCanonicalize (H12AffineFastState.compose env35075 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102679) := by decide +kernel

theorem selectedBound35075 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,102679,32,98767,98645,8328,64,496947,103630,4097,463942,99466,73770,256,168,46212,41820]

theorem envBound35076 : H12AffineFastState.Bounded env35076 := by
  intro p hp
  have h : env35076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35075_35076 : H12AffineEnvironment.transform 20 102679 env35075 = env35076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102679 env35075 == env35076) = true)

def env35077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10400,1024,32769,102679,32,98767,98645,8328,64,245139,103630,4097,212198,99466,73770,256,168,46212,41820]

theorem envBound35077 : H12AffineFastState.Bounded env35077 := by
  intro p hp
  have h : env35077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35076_35077 : H12AffineEnvironment.transform 17 10400 env35076 = env35077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35076 == env35077) = true)

theorem identity35077 : scanCanonicalize (H12AffineFastState.compose env35077 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound35077 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,103631,10400,1024,32769,102679,32,98767,98645,8328,64,10588,103630,4097,43049,99466,73770,256,168,46212,41820]

theorem envBound35078 : H12AffineFastState.Bounded env35078 := by
  intro p hp
  have h : env35078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35077_35078 : H12AffineEnvironment.transform 16 103631 env35077 = env35078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env35077 == env35078) = true)

theorem identity35078 : scanCanonicalize (H12AffineFastState.compose env35078 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound35078 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env35079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,5392,10400,1024,32769,4296,32,16,138,8328,64,10588,5393,4097,43049,1365,41461,256,168,46212,41820]

theorem envBound35079 : H12AffineFastState.Bounded env35079 := by
  intro p hp
  have h : env35079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35078_35079 : H12AffineEnvironment.transform 15 33247 env35078 = env35079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env35078 == env35079) = true)

theorem identity35079 : scanCanonicalize (H12AffineFastState.compose env35079 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound35079 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env35080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,80,399,5392,10400,1024,81,4296,32,16,138,8328,64,10588,5393,4097,10361,1365,8613,256,168,13524,8972]

theorem envBound35080 : H12AffineFastState.Bounded env35080 := by
  intro p hp
  have h : env35080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35079_35080 : H12AffineEnvironment.transform 14 80 env35079 = env35080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env35079 == env35080) = true)

theorem identity35080 : scanCanonicalize (H12AffineFastState.compose env35080 (packedSelected [0,4,5,8,10,12,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35080 : packedSelected [0,4,5,8,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env35081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,80,399,5392,2476,1024,81,4296,32,16,138,388,64,2128,5393,4097,2421,1365,169,256,168,5592,512]

theorem envBound35081 : H12AffineFastState.Bounded env35081 := by
  intro p hp
  have h : env35081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35080_35081 : H12AffineEnvironment.transform 12 268 env35080 = env35081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35080 == env35081) = true)

theorem identity35081 : scanCanonicalize (H12AffineFastState.compose env35081 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35081 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env35082 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,268,5513,80,399,5392,2445,1024,81,4296,1,16,138,388,64,2128,5393,4097,2388,1365,136,256,137,5592,512]

theorem envBound35082 : H12AffineFastState.Bounded env35082 := by
  intro p hp
  have h : env35082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35081_35082 : H12AffineEnvironment.transform 4 1 env35081 = env35082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35081 == env35082) = true)

def env35083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10401,1024,32769,102679,32,98767,98645,8328,64,245138,103630,4097,212199,99466,73770,256,168,46212,41820]

theorem envBound35083 : H12AffineFastState.Bounded env35083 := by
  intro p hp
  have h : env35083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35076_35083 : H12AffineEnvironment.transform 17 10401 env35076 = env35083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35076 == env35083) = true)

def env35084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102679,32,98631,98645,8192,64,245018,103494,4097,212079,99330,73770,256,32,46092,41820]

theorem envBound35084 : H12AffineFastState.Bounded env35084 := by
  intro p hp
  have h : env35084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35083_35084 : H12AffineEnvironment.transform 6 8 env35083 = env35084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35083 == env35084) = true)

theorem identity35084 : scanCanonicalize (H12AffineFastState.compose env35084 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35084 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,32,73754,73736,8192,64,203847,79131,4097,212079,75103,73770,256,32,5457,513]

theorem envBound35085 : H12AffineFastState.Bounded env35085 := by
  intro p hp
  have h : env35085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35084_35085 : H12AffineEnvironment.transform 14 8541 env35084 = env35085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35084 == env35085) = true)

theorem identity35085 : scanCanonicalize (H12AffineFastState.compose env35085 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound35085 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env35086 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,70963,10281,1024,8540,77898,32,73754,73736,8192,64,2420,79131,4097,10588,75103,73770,256,32,5457,513]

theorem envBound35086 : H12AffineFastState.Bounded env35086 := by
  intro p hp
  have h : env35086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35085_35086 : H12AffineEnvironment.transform 16 70963 env35085 = env35086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env35085 == env35086) = true)

theorem identity35086 : scanCanonicalize (H12AffineFastState.compose env35086 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound35086 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35087 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1125,65536,70963,3345,1024,1124,71026,32,66850,66864,1336,64,2420,69667,4097,3172,65639,66834,256,32,5457,513]

theorem envBound35087 : H12AffineFastState.Bounded env35087 := by
  intro p hp
  have h : env35087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35086_35087 : H12AffineEnvironment.transform 12 1336 env35086 = env35087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env35086 == env35087) = true)

theorem identity35087 : scanCanonicalize (H12AffineFastState.compose env35087 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound35087 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env35088 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,121,4160,292,65536,69746,2128,321,293,69683,32,65635,65649,121,64,2420,69667,4097,2341,65639,65619,256,32,4112,513]

theorem envBound35088 : H12AffineFastState.Bounded env35088 := by
  intro p hp
  have h : env35088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35087_35088 : H12AffineEnvironment.transform 9 321 env35087 = env35088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35087 == env35088) = true)

theorem identity35088 : scanCanonicalize (H12AffineFastState.compose env35088 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound35088 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env35089 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,121,2049,292,65536,67635,2128,321,293,67698,32,65635,65649,121,64,2420,67682,2112,2341,65639,65619,256,32,2129,513]

theorem envBound35089 : H12AffineFastState.Bounded env35089 := by
  intro p hp
  have h : env35089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35088_35089 : H12AffineEnvironment.transform 11 2113 env35088 = env35089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env35088 == env35089) = true)

def env35090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102679,32,98630,98645,8193,64,245019,103495,4097,212078,99331,73770,256,33,46093,41820]

theorem envBound35090 : H12AffineFastState.Bounded env35090 := by
  intro p hp
  have h : env35090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35083_35090 : H12AffineEnvironment.transform 6 9 env35083 = env35090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35083 == env35090) = true)

theorem identity35090 : scanCanonicalize (H12AffineFastState.compose env35090 (packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound35090 : packedSelected [0,1,3,7,9,12,14,15,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env35091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,111899,10280,1024,32769,102679,32,98630,98645,8193,64,2048,103495,4097,35189,99331,73770,256,33,46093,41820]

theorem envBound35091 : H12AffineFastState.Bounded env35091 := by
  intro p hp
  have h : env35091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35090_35091 : H12AffineEnvironment.transform 16 111899 env35090 = env35091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env35090 == env35091) = true)

theorem identity35091 : scanCanonicalize (H12AffineFastState.compose env35091 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35091 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,38160,10280,1024,32769,45340,32,41293,41310,8193,64,2048,46156,4097,35189,41992,33,256,33,46093,41820]

theorem envBound35092 : H12AffineFastState.Bounded env35092 := by
  intro p hp
  have h : env35092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35091_35092 : H12AffineEnvironment.transform 15 8203 env35091 = env35092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35091 == env35092) = true)

theorem identity35092 : scanCanonicalize (H12AffineFastState.compose env35092 (packedSelected [0,1,4,6,7,8,9,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35092 : packedSelected [0,1,4,6,7,8,9,19] rootPS < 2^1333 := by decide +kernel

def env35093 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,32768,8203,37989,10280,1024,32769,45161,32,41016,41003,8193,64,2048,46156,4097,34816,41992,33,117,33,46093,41513]

theorem envBound35093 : H12AffineFastState.Bounded env35093 := by
  intro p hp
  have h : env35093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35092_35093 : H12AffineEnvironment.transform 7 117 env35092 = env35093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35092 == env35093) = true)

theorem identity35093 : scanCanonicalize (H12AffineFastState.compose env35093 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35093 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env35094 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,32768,34,37989,2049,1024,32769,36928,32,32785,32770,40,64,2048,37989,4097,34816,33825,33,117,33,37924,33280]

theorem envBound35094 : H12AffineFastState.Bounded env35094 := by
  intro p hp
  have h : env35094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35093_35094 : H12AffineEnvironment.transform 12 41 env35093 = env35094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35093 == env35094) = true)

theorem identity35094 : scanCanonicalize (H12AffineFastState.compose env35094 (packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound35094 : packedSelected [0,1,2,3,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env35095 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,4096,41,5237,32768,34,37989,81,1024,32769,36928,32,32785,32770,40,64,80,37989,4097,32848,33825,33,117,33,37924,33280]

theorem envBound35095 : H12AffineFastState.Bounded env35095 := by
  intro p hp
  have h : env35095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35094_35095 : H12AffineEnvironment.transform 10 80 env35094 = env35095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env35094 == env35095) = true)

theorem identity35095 : scanCanonicalize (H12AffineFastState.compose env35095 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35095 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env35096 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,4096,41,5237,0,34,5221,81,1024,1,4160,32,17,2,40,64,80,5221,4097,80,1057,33,117,33,5156,512]

theorem envBound35096 : H12AffineFastState.Bounded env35096 := by
  intro p hp
  have h : env35096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35095_35096 : H12AffineEnvironment.transform 14 0 env35095 = env35096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35095 == env35096) = true)

theorem identity35096 : scanCanonicalize (H12AffineFastState.compose env35096 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 58) := by decide +kernel

theorem selectedBound35096 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35097 : List Nat := [2,4,8,16,32,64,9,117,512,1024,80,58,41,1103,0,34,1119,81,1024,1,122,32,17,2,40,64,80,1119,59,80,1057,33,117,33,1054,512]

theorem envBound35097 : H12AffineFastState.Bounded env35097 := by
  intro p hp
  have h : env35097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35096_35097 : H12AffineEnvironment.transform 11 58 env35096 = env35097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 58 env35096 == env35097) = true)

theorem identity35097 : scanCanonicalize (H12AffineFastState.compose env35097 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound35097 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35098 : List Nat := [2,4,8,16,32,64,9,117,512,63,80,58,41,112,0,34,96,81,63,1,122,32,17,2,40,64,80,96,59,80,30,33,117,33,33,512]

theorem envBound35098 : H12AffineFastState.Bounded env35098 := by
  intro p hp
  have h : env35098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35097_35098 : H12AffineEnvironment.transform 9 63 env35097 = env35098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env35097 == env35098) = true)

theorem identity35098 : scanCanonicalize (H12AffineFastState.compose env35098 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound35098 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env35099 : List Nat := [2,4,8,16,20,64,9,65,512,11,80,14,29,68,0,22,84,81,11,1,78,20,17,2,28,64,80,84,15,80,30,21,65,21,21,512]

theorem envBound35099 : H12AffineFastState.Bounded env35099 := by
  intro p hp
  have h : env35099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35098_35099 : H12AffineEnvironment.transform 4 20 env35098 = env35099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env35098 == env35099) = true)

theorem identity35099 : scanCanonicalize (H12AffineFastState.compose env35099 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound35099 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35100 : List Nat := [2,4,8,16,20,5,9,4,512,11,21,14,29,1,0,22,17,20,11,1,11,20,17,2,28,5,21,17,15,21,30,21,4,21,21,512]

theorem envBound35100 : H12AffineFastState.Bounded env35100 := by
  intro p hp
  have h : env35100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35099_35100 : H12AffineEnvironment.transform 5 5 env35099 = env35100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env35099 == env35100) = true)

theorem identity35100 : scanCanonicalize (H12AffineFastState.compose env35100 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound35100 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35101 : List Nat := [2,4,8,4,0,5,9,4,512,11,1,14,9,1,0,2,5,0,11,1,11,0,5,2,8,5,1,5,15,1,10,1,4,1,1,512]

theorem envBound35101 : H12AffineFastState.Bounded env35101 := by
  intro p hp
  have h : env35101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35100_35101 : H12AffineEnvironment.transform 3 4 env35100 = env35101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env35100 == env35101) = true)

theorem identity35101 : scanCanonicalize (H12AffineFastState.compose env35101 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35102 : List Nat := [2,1,8,1,0,0,9,1,512,11,1,11,9,1,0,2,0,0,11,1,11,0,0,2,8,0,1,0,10,1,10,1,1,1,1,512]

theorem envBound35102 : H12AffineFastState.Bounded env35102 := by
  intro p hp
  have h : env35102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35101_35102 : H12AffineEnvironment.transform 1 1 env35101 = env35102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35101 == env35102) = true)

theorem identity35102 : scanCanonicalize (H12AffineFastState.compose env35102 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35102 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env35103 : List Nat := [2,1,3,1,0,0,2,1,512,0,1,0,2,1,0,2,0,0,0,1,0,0,0,2,3,0,1,0,1,1,1,1,1,1,1,512]

theorem envBound35103 : H12AffineFastState.Bounded env35103 := by
  intro p hp
  have h : env35103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35102_35103 : H12AffineEnvironment.transform 2 3 env35102 = env35103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35102 == env35103) = true)

theorem identity35103 : scanCanonicalize (H12AffineFastState.compose env35103 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35104 : List Nat := [0,1,1,1,0,0,0,1,512,0,1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,0,1,0,1,1,1,1,1,1,1,512]

theorem envBound35104 : H12AffineFastState.Bounded env35104 := by
  intro p hp
  have h : env35104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35103_35104 : H12AffineEnvironment.transform 0 0 env35103 = env35104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35103 == env35104) = true)

def env35105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491429,2098649,4097,2524497,2102685,2142524,256,168,46212,2175563]

theorem envBound35105 : H12AffineFastState.Bounded env35105 := by
  intro p hp
  have h : env35105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35074_35105 : H12AffineEnvironment.transform 21 33 env35074 = env35105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35074 == env35105) = true)

theorem identity35105 : scanCanonicalize (H12AffineFastState.compose env35105 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound35105 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491429,2098649,4097,2524497,2102685,2142524,256,168,46212,2143124]

theorem envBound35106 : H12AffineFastState.Bounded env35106 := by
  intro p hp
  have h : env35106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35105_35106 : H12AffineEnvironment.transform 15 33247 env35105 = env35106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env35105 == env35106) = true)

theorem identity35106 : scanCanonicalize (H12AffineFastState.compose env35106 (packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound35106 : packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env35107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,10401,1024,32769,2097152,33,2101464,138,8328,64,2239620,2098649,4097,2272752,2102685,2142524,256,168,46212,2143124]

theorem envBound35107 : H12AffineFastState.Bounded env35107 := by
  intro p hp
  have h : env35107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35106_35107 : H12AffineEnvironment.transform 17 10401 env35106 = env35107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35106 == env35107) = true)

theorem identity35107 : scanCanonicalize (H12AffineFastState.compose env35107 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 45461) := by decide +kernel

theorem selectedBound35107 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env35108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,10401,1024,32769,45461,33,41293,138,8328,64,171281,46156,4097,138341,41992,169,256,168,46212,513]

theorem envBound35108 : H12AffineFastState.Bounded env35108 := by
  intro p hp
  have h : env35108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35107_35108 : H12AffineEnvironment.transform 20 45461 env35107 = env35108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45461 env35107 == env35108) = true)

theorem identity35108 : scanCanonicalize (H12AffineFastState.compose env35108 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound35108 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,13340,10401,1024,32769,45461,33,41293,138,8328,64,43277,46156,4097,10361,41992,169,256,168,46212,513]

theorem envBound35109 : H12AffineFastState.Bounded env35109 := by
  intro p hp
  have h : env35109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35108_35109 : H12AffineEnvironment.transform 16 13340 env35108 = env35109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env35108 == env35109) = true)

theorem identity35109 : scanCanonicalize (H12AffineFastState.compose env35109 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound35109 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env35110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,217,262,13340,10401,1024,216,12620,33,8596,138,8328,64,10708,13461,4097,10361,9425,169,256,168,13405,513]

theorem envBound35110 : H12AffineFastState.Bounded env35110 := by
  intro p hp
  have h : env35110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35109_35110 : H12AffineEnvironment.transform 14 217 env35109 = env35110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env35109 == env35110) = true)

theorem identity35110 : scanCanonicalize (H12AffineFastState.compose env35110 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound35110 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env35111 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,0,262,13340,10360,1024,1,12620,33,8525,83,8273,64,10509,13388,4097,10361,9224,112,256,113,13405,513]

theorem envBound35111 : H12AffineFastState.Bounded env35111 := by
  intro p hp
  have h : env35111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35110_35111 : H12AffineEnvironment.transform 6 89 env35110 = env35111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env35110 == env35111) = true)

theorem identity35111 : scanCanonicalize (H12AffineFastState.compose env35111 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35111 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35112 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,0,262,5392,2420,1024,1,4160,33,65,83,349,64,2049,5440,4097,2421,1284,112,256,113,5457,513]

theorem envBound35112 : H12AffineFastState.Bounded env35112 := by
  intro p hp
  have h : env35112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35111_35112 : H12AffineEnvironment.transform 12 268 env35111 = env35112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35111 == env35112) = true)

theorem identity35112 : scanCanonicalize (H12AffineFastState.compose env35112 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35112 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35113 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1024,1,4112,33,17,3,269,16,2049,5392,4097,2341,1284,32,256,33,5377,513]

theorem envBound35113 : H12AffineFastState.Bounded env35113 := by
  intro p hp
  have h : env35113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35112_35113 : H12AffineEnvironment.transform 5 16 env35112 = env35113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35112 == env35113) = true)

theorem identity35113 : scanCanonicalize (H12AffineFastState.compose env35113 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35114 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,34,5172,2048,1024,1,4112,33,17,3,41,16,2049,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound35114 : H12AffineFastState.Bounded env35114 := by
  intro p hp
  have h : env35114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35113_35114 : H12AffineEnvironment.transform 7 36 env35113 = env35114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35113 == env35114) = true)

theorem identity35114 : scanCanonicalize (H12AffineFastState.compose env35114 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound35114 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35115 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1598,4096,40,5156,0,34,5172,1598,1024,1,4112,33,17,3,41,16,1599,5172,4097,1599,1056,32,36,33,5157,513]

theorem envBound35115 : H12AffineFastState.Bounded env35115 := by
  intro p hp
  have h : env35115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35114_35115 : H12AffineEnvironment.transform 10 1598 env35114 = env35115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env35114 == env35115) = true)

theorem identity35115 : scanCanonicalize (H12AffineFastState.compose env35115 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound35115 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35116 : List Nat := [2,4,8,16,32,16,9,36,512,543,33,4096,40,4667,0,34,4651,33,543,1,4112,33,17,3,41,16,32,4651,4097,32,575,32,36,33,4666,513]

theorem envBound35116 : H12AffineFastState.Bounded env35116 := by
  intro p hp
  have h : env35116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35115_35116 : H12AffineEnvironment.transform 9 543 env35115 = env35116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env35115 == env35116) = true)

theorem identity35116 : scanCanonicalize (H12AffineFastState.compose env35116 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound35116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35117 : List Nat := [2,4,8,16,32,16,9,36,2,29,33,4096,40,4153,0,34,4137,33,29,1,4112,33,17,3,41,16,32,4137,4097,32,61,32,36,33,4152,3]

theorem envBound35117 : H12AffineFastState.Bounded env35117 := by
  intro p hp
  have h : env35117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35116_35117 : H12AffineEnvironment.transform 8 2 env35116 = env35117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env35116 == env35117) = true)

theorem identity35117 : scanCanonicalize (H12AffineFastState.compose env35117 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 24) := by decide +kernel

theorem selectedBound35117 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35118 : List Nat := [2,4,8,16,32,16,9,36,2,29,33,24,40,33,0,34,49,33,29,1,8,33,17,3,41,16,32,49,25,32,61,32,36,33,32,3]

theorem envBound35118 : H12AffineFastState.Bounded env35118 := by
  intro p hp
  have h : env35118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35117_35118 : H12AffineEnvironment.transform 11 24 env35117 = env35118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 24 env35117 == env35118) = true)

theorem identity35118 : scanCanonicalize (H12AffineFastState.compose env35118 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound35118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35119 : List Nat := [2,4,8,16,13,16,9,9,2,29,12,24,5,12,0,15,28,12,29,1,8,12,17,3,4,16,13,28,25,13,16,13,9,12,13,3]

theorem envBound35119 : H12AffineFastState.Bounded env35119 := by
  intro p hp
  have h : env35119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35118_35119 : H12AffineEnvironment.transform 4 13 env35118 = env35119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env35118 == env35119) = true)

theorem identity35119 : scanCanonicalize (H12AffineFastState.compose env35119 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35119 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env35120 : List Nat := [2,1,8,16,8,16,9,9,2,24,9,24,0,9,0,10,25,9,24,1,8,9,17,3,1,16,8,25,25,8,16,8,9,9,8,3]

theorem envBound35120 : H12AffineFastState.Bounded env35120 := by
  intro p hp
  have h : env35120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35119_35120 : H12AffineEnvironment.transform 1 1 env35119 = env35120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35119 == env35120) = true)

def env35121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685700,2098648,4096,2524496,2102685,6336796,256,168,46212,2175563]

theorem envBound35121 : H12AffineFastState.Bounded env35121 := by
  intro p hp
  have h : env35121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35073_35121 : H12AffineEnvironment.transform 22 2101465 env35073 = env35121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env35073 == env35121) = true)

def env35122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491428,2098648,4096,2524496,2102685,2142524,256,168,46212,2175563]

theorem envBound35122 : H12AffineFastState.Bounded env35122 := by
  intro p hp
  have h : env35122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35121_35122 : H12AffineEnvironment.transform 21 32 env35121 = env35122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env35121 == env35122) = true)

theorem identity35122 : scanCanonicalize (H12AffineFastState.compose env35122 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound35122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,77898,32,73875,98644,8328,64,472174,79250,4096,505114,75223,98678,256,168,46212,513]

theorem envBound35123 : H12AffineFastState.Bounded env35123 := by
  intro p hp
  have h : env35123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35122_35123 : H12AffineEnvironment.transform 20 77898 env35122 = env35123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env35122 == env35123) = true)

def env35124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472174,79130,4096,505114,75103,98678,256,32,46092,513]

theorem envBound35124 : H12AffineFastState.Bounded env35124 := by
  intro p hp
  have h : env35124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35123_35124 : H12AffineEnvironment.transform 6 8 env35123 = env35124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35123 == env35124) = true)

theorem identity35124 : scanCanonicalize (H12AffineFastState.compose env35124 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound35124 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,77898,32,73755,98644,8192,64,262516,79130,4096,294912,75103,98678,256,32,46092,513]

theorem envBound35125 : H12AffineFastState.Bounded env35125 := by
  intro p hp
  have h : env35125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35124_35125 : H12AffineEnvironment.transform 16 79130 env35124 = env35125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env35124 == env35125) = true)

theorem identity35125 : scanCanonicalize (H12AffineFastState.compose env35125 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33863) := by decide +kernel

theorem selectedBound35125 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env35126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33863,45405,262144,1024,32769,46093,32,42076,1299,8192,64,262516,45405,4096,294912,41240,1329,256,32,46092,513]

theorem envBound35126 : H12AffineFastState.Bounded env35126 := by
  intro p hp
  have h : env35126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35125_35126 : H12AffineEnvironment.transform 15 33863 env35125 = env35126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33863 env35125 == env35126) = true)

theorem identity35126 : scanCanonicalize (H12AffineFastState.compose env35126 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(17+1) ^^^ 44108) := by decide +kernel

theorem selectedBound35126 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env35127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33863,45405,44108,1024,32769,46093,32,42076,1299,8192,64,44344,45405,4096,11340,41240,1329,256,32,46092,513]

theorem envBound35127 : H12AffineFastState.Bounded env35127 := by
  intro p hp
  have h : env35127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35126_35127 : H12AffineEnvironment.transform 17 44108 env35126 = env35127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44108 env35126 == env35127) = true)

theorem identity35127 : scanCanonicalize (H12AffineFastState.compose env35127 (packedSelected [3,5,10,11,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound35127 : packedSelected [3,5,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env35128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1344,263,13341,10508,1024,1345,12621,32,8476,1299,8192,64,10360,13341,4096,11340,9304,1329,256,32,12620,513]

theorem envBound35128 : H12AffineFastState.Bounded env35128 := by
  intro p hp
  have h : env35128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35127_35128 : H12AffineEnvironment.transform 14 1344 env35127 = env35128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env35127 == env35128) = true)

theorem identity35128 : scanCanonicalize (H12AffineFastState.compose env35128 (packedSelected [11,12,15,18,21] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound35128 : packedSelected [11,12,15,18,21] rootPS < 2^1333 := by decide +kernel

def env35129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1344,263,4389,3124,1024,1345,5237,32,1060,1299,1336,64,3392,4389,4096,2420,352,1329,256,32,5236,513]

theorem envBound35129 : H12AffineFastState.Bounded env35129 := by
  intro p hp
  have h : env35129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35128_35129 : H12AffineEnvironment.transform 12 1336 env35128 = env35129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env35128 == env35129) = true)

theorem identity35129 : scanCanonicalize (H12AffineFastState.compose env35129 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound35129 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1336,64,1344,263,1124,3124,1024,1345,308,32,1060,1299,1336,64,3392,1124,1345,2420,352,1329,256,32,309,513]

theorem envBound35130 : H12AffineFastState.Bounded env35130 := by
  intro p hp
  have h : env35130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35129_35130 : H12AffineEnvironment.transform 11 1345 env35129 = env35130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env35129 == env35130) = true)

theorem identity35130 : scanCanonicalize (H12AffineFastState.compose env35130 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35130 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env35131 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1076,1101,64,1077,114,1124,3124,1024,1076,65,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,64,513]

theorem envBound35131 : H12AffineFastState.Bounded env35131 := by
  intro p hp
  have h : env35131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35130_35131 : H12AffineEnvironment.transform 7 117 env35130 = env35131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35130 == env35131) = true)

theorem identity35131 : scanCanonicalize (H12AffineFastState.compose env35131 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound35131 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env35132 : List Nat := [2,4,8,16,32,64,8,117,80,1024,2048,1076,1101,64,1077,114,1124,3124,1024,1076,65,32,1060,1126,1101,64,3125,1124,1076,2049,21,1092,117,32,64,81]

theorem envBound35132 : H12AffineFastState.Bounded env35132 := by
  intro p hp
  have h : env35132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35131_35132 : H12AffineEnvironment.transform 8 80 env35131 = env35132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env35131 == env35132) = true)

theorem identity35132 : scanCanonicalize (H12AffineFastState.compose env35132 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35132 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35133 : List Nat := [2,4,8,16,32,49,8,4,33,1024,2048,1076,1084,49,1077,3,1045,3124,1024,1076,48,32,1060,1047,1084,49,3125,1045,1076,2049,21,1077,4,32,49,32]

theorem envBound35133 : H12AffineFastState.Bounded env35133 := by
  intro p hp
  have h : env35133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35132_35133 : H12AffineEnvironment.transform 5 49 env35132 = env35133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35132 == env35133) = true)

theorem identity35133 : scanCanonicalize (H12AffineFastState.compose env35133 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35134 : List Nat := [2,4,8,16,32,49,8,4,33,53,2048,1,9,49,0,3,32,2049,53,1,48,32,17,34,9,49,2048,32,1,2049,21,0,4,32,49,32]

theorem envBound35134 : H12AffineFastState.Bounded env35134 := by
  intro p hp
  have h : env35134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35133_35134 : H12AffineEnvironment.transform 9 53 env35133 = env35134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35133 == env35134) = true)

def env35135 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98644,8193,64,472174,79131,4096,505114,75102,98678,256,33,46093,513]

theorem envBound35135 : H12AffineFastState.Bounded env35135 := by
  intro p hp
  have h : env35135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35123_35135 : H12AffineEnvironment.transform 6 9 env35123 = env35135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35123 == env35135) = true)

theorem identity35135 : scanCanonicalize (H12AffineFastState.compose env35135 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35135 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env35136 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77898,32,73754,73737,8193,64,472174,79131,4096,463943,75102,73771,256,33,5456,513]

theorem envBound35136 : H12AffineFastState.Bounded env35136 := by
  intro p hp
  have h : env35136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35135_35136 : H12AffineEnvironment.transform 14 8541 env35135 = env35136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35135 == env35136) = true)

theorem identity35136 : scanCanonicalize (H12AffineFastState.compose env35136 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35136 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35137 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,262144,1024,8540,4160,32,16,3,8193,64,398436,5393,4096,406605,1364,33,256,33,5456,513]

theorem envBound35137 : H12AffineFastState.Bounded env35137 := by
  intro p hp
  have h : env35137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35136_35137 : H12AffineEnvironment.transform 15 8202 env35136 = env35137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35136 == env35137) = true)

theorem identity35137 : scanCanonicalize (H12AffineFastState.compose env35137 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35137 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35138 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,262144,1024,8460,4112,32,16,3,8193,16,398388,5393,4096,406557,1284,33,256,33,5376,513]

theorem envBound35138 : H12AffineFastState.Bounded env35138 := by
  intro p hp
  have h : env35138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35137_35138 : H12AffineEnvironment.transform 5 16 env35137 = env35138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35137 == env35138) = true)

theorem identity35138 : scanCanonicalize (H12AffineFastState.compose env35138 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound35138 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env35139 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,131072,10281,1024,8460,4112,32,16,3,8193,16,146461,5393,4096,138292,1284,33,256,33,5376,513]

theorem envBound35139 : H12AffineFastState.Bounded env35139 := by
  intro p hp
  have h : env35139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35138_35139 : H12AffineEnvironment.transform 17 10281 env35138 = env35139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env35138 == env35139) = true)

theorem identity35139 : scanCanonicalize (H12AffineFastState.compose env35139 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35139 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35140 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,13341,10281,1024,8460,4112,32,16,3,8193,16,2048,5393,4096,10281,1284,33,256,33,5376,513]

theorem envBound35140 : H12AffineFastState.Bounded env35140 := by
  intro p hp
  have h : env35140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35139_35140 : H12AffineEnvironment.transform 16 13341 env35139 = env35140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env35139 == env35140) = true)

theorem identity35140 : scanCanonicalize (H12AffineFastState.compose env35140 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound35140 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35141 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,1053,5376,1296,1047,4096,3124,1024,1297,4112,32,16,3,1052,16,2048,5393,4096,3124,1284,33,256,33,5376,513]

theorem envBound35141 : H12AffineFastState.Bounded env35141 := by
  intro p hp
  have h : env35141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35140_35141 : H12AffineEnvironment.transform 12 1053 env35140 = env35141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env35140 == env35141) = true)

theorem identity35141 : scanCanonicalize (H12AffineFastState.compose env35141 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35141 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35142 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,4096,1053,5376,1296,1047,4096,1077,1024,1297,4112,32,16,3,1052,16,1,5393,4096,1077,1284,33,256,33,5376,513]

theorem envBound35142 : H12AffineFastState.Bounded env35142 := by
  intro p hp
  have h : env35142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35141_35142 : H12AffineEnvironment.transform 10 1 env35141 = env35142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35141 == env35142) = true)

theorem identity35142 : scanCanonicalize (H12AffineFastState.compose env35142 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound35142 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env35143 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1281,1053,1,1296,1047,1281,1077,1024,1297,1297,32,16,3,1052,16,1,16,1281,1077,1284,33,256,33,1,513]

theorem envBound35143 : H12AffineFastState.Bounded env35143 := by
  intro p hp
  have h : env35143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35142_35143 : H12AffineEnvironment.transform 11 1281 env35142 = env35143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env35142 == env35143) = true)

def env35144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491429,2098648,4096,2524496,2102685,2142525,256,168,46212,2175563]

theorem envBound35144 : H12AffineFastState.Bounded env35144 := by
  intro p hp
  have h : env35144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35121_35144 : H12AffineEnvironment.transform 21 33 env35121 = env35144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env35121 == env35144) = true)

theorem identity35144 : scanCanonicalize (H12AffineFastState.compose env35144 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35144 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101465,41431,8328,64,2491429,2098648,4096,2524496,2102685,2142525,256,168,46212,2101960]

theorem envBound35145 : H12AffineFastState.Bounded env35145 := by
  intro p hp
  have h : env35145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35144_35145 : H12AffineEnvironment.transform 15 8323 env35144 = env35145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35144 == env35145) = true)

def env35146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101385,41351,8328,16,2491429,2098568,4096,2524416,2102685,2142525,256,168,46212,2101912]

theorem envBound35146 : H12AffineFastState.Bounded env35146 := by
  intro p hp
  have h : env35146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35145_35146 : H12AffineEnvironment.transform 5 16 env35145 = env35146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35145 == env35146) = true)

theorem identity35146 : scanCanonicalize (H12AffineFastState.compose env35146 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound35146 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env35147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35109,1024,32769,2097152,33,2101385,41351,8328,16,2264320,2098568,4096,2231333,2102685,2142525,256,168,46212,2101912]

theorem envBound35147 : H12AffineFastState.Bounded env35147 := by
  intro p hp
  have h : env35147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35146_35147 : H12AffineEnvironment.transform 17 35109 env35146 = env35147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env35146 == env35147) = true)

theorem identity35147 : scanCanonicalize (H12AffineFastState.compose env35147 (packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound35147 : packedSelected [0,3,4,5,7,8,10,11,18,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env35148 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,38160,35109,1024,32769,2097152,33,2101385,41351,8328,16,2103312,2098568,4096,2136373,2102685,2142525,256,168,46212,2101912]

theorem envBound35148 : H12AffineFastState.Bounded env35148 := by
  intro p hp
  have h : env35148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35147_35148 : H12AffineEnvironment.transform 16 38160 env35147 = env35148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env35147 == env35148) = true)

theorem identity35148 : scanCanonicalize (H12AffineFastState.compose env35148 (packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS)) = affineNative (2^(20+1) ^^^ 36881) := by decide +kernel

theorem selectedBound35148 : packedSelected [1,3,4,5,7,8,9,10,16,20,26,27] rootPS < 2^1333 := by decide +kernel

def env35149 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,38160,35109,1024,32769,36881,33,32920,41351,8328,16,34817,38297,4096,2340,34188,8492,256,168,46212,33417]

theorem envBound35149 : H12AffineFastState.Bounded env35149 := by
  intro p hp
  have h : env35149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35148_35149 : H12AffineEnvironment.transform 20 36881 env35148 = env35149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36881 env35148 == env35149) = true)

theorem identity35149 : scanCanonicalize (H12AffineFastState.compose env35149 (packedSelected [0,4,7,16,18,20,21,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound35149 : packedSelected [0,4,7,16,18,20,21,22,23] rootPS < 2^1333 := by decide +kernel

def env35150 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8461,8323,13341,10280,1024,8460,12572,33,8597,138,8328,16,10508,13460,4096,2340,9345,8492,256,168,5513,9092]

theorem envBound35150 : H12AffineFastState.Bounded env35150 := by
  intro p hp
  have h : env35150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35149_35150 : H12AffineEnvironment.transform 14 8461 env35149 = env35150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env35149 == env35150) = true)

theorem identity35150 : scanCanonicalize (H12AffineFastState.compose env35150 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35150 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env35151 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,13341,10280,1024,8460,12572,33,8476,3,8193,16,10508,13341,4096,2340,9224,8492,256,33,5376,8973]

theorem envBound35151 : H12AffineFastState.Bounded env35151 := by
  intro p hp
  have h : env35151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35150_35151 : H12AffineEnvironment.transform 6 9 env35150 = env35151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35150 == env35151) = true)

theorem identity35151 : scanCanonicalize (H12AffineFastState.compose env35151 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35151 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env35152 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5376,292,35,5172,2049,1024,293,4405,33,309,3,40,16,2341,5172,4096,2340,1057,261,256,33,5376,804]

theorem envBound35152 : H12AffineFastState.Bounded env35152 := by
  intro p hp
  have h : env35152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35151_35152 : H12AffineEnvironment.transform 12 41 env35151 = env35152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35151 == env35152) = true)

theorem identity35152 : scanCanonicalize (H12AffineFastState.compose env35152 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35152 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env35153 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,0,35,5172,2049,1024,1,4113,33,17,3,40,16,2049,5172,4096,2048,1057,33,36,33,5156,512]

theorem envBound35153 : H12AffineFastState.Bounded env35153 := by
  intro p hp
  have h : env35153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35152_35153 : H12AffineEnvironment.transform 7 36 env35152 = env35153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35152 == env35153) = true)

theorem identity35153 : scanCanonicalize (H12AffineFastState.compose env35153 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound35153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35154 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,33,41,1029,0,35,1045,2049,1024,1,48,33,17,3,40,16,2049,1045,33,2048,1057,33,36,33,1029,512]

theorem envBound35154 : H12AffineFastState.Bounded env35154 := by
  intro p hp
  have h : env35154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35153_35154 : H12AffineEnvironment.transform 11 33 env35153 = env35154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env35153 == env35154) = true)

theorem identity35154 : scanCanonicalize (H12AffineFastState.compose env35154 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound35154 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35155 : List Nat := [2,4,8,16,32,16,9,36,512,533,2048,33,41,528,0,35,512,2049,533,1,48,33,17,3,40,16,2049,512,33,2048,564,33,36,33,528,512]

theorem envBound35155 : H12AffineFastState.Bounded env35155 := by
  intro p hp
  have h : env35155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35154_35155 : H12AffineEnvironment.transform 9 533 env35154 = env35155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env35154 == env35155) = true)

theorem identity35155 : scanCanonicalize (H12AffineFastState.compose env35155 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35156 : List Nat := [2,4,8,16,0,16,9,4,512,533,2048,1,9,528,0,3,512,2049,533,1,16,1,17,3,8,16,2049,512,1,2048,532,1,4,1,528,512]

theorem envBound35156 : H12AffineFastState.Bounded env35156 := by
  intro p hp
  have h : env35156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35155_35156 : H12AffineEnvironment.transform 4 0 env35155 = env35156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35155 == env35156) = true)

theorem identity35156 : scanCanonicalize (H12AffineFastState.compose env35156 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35156 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35157 : List Nat := [2,4,8,16,0,16,9,4,1,20,2048,1,9,17,0,3,1,2049,20,1,16,1,17,3,8,16,2049,1,1,2048,21,1,4,1,17,1]

theorem envBound35157 : H12AffineFastState.Bounded env35157 := by
  intro p hp
  have h : env35157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35156_35157 : H12AffineEnvironment.transform 8 1 env35156 = env35157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35156 == env35157) = true)

theorem identity35157 : scanCanonicalize (H12AffineFastState.compose env35157 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35158 : List Nat := [2,4,8,16,0,16,9,4,1,20,1,1,9,17,0,3,1,0,20,1,16,1,17,3,8,16,0,1,1,1,21,1,4,1,17,1]

theorem envBound35158 : H12AffineFastState.Bounded env35158 := by
  intro p hp
  have h : env35158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35157_35158 : H12AffineEnvironment.transform 10 1 env35157 = env35158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35157 == env35158) = true)

theorem identity35158 : scanCanonicalize (H12AffineFastState.compose env35158 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound35158 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35159 : List Nat := [2,4,8,15,0,15,9,4,1,11,1,1,9,14,0,3,1,0,11,1,15,1,14,3,8,15,0,1,1,1,10,1,4,1,14,1]

theorem envBound35159 : H12AffineFastState.Bounded env35159 := by
  intro p hp
  have h : env35159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35158_35159 : H12AffineEnvironment.transform 3 15 env35158 = env35159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env35158 == env35159) = true)

def env35160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101384,41350,8328,17,2491429,2098569,4096,2524417,2102685,2142525,256,168,46212,2101913]

theorem envBound35160 : H12AffineFastState.Bounded env35160 := by
  intro p hp
  have h : env35160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35145_35160 : H12AffineEnvironment.transform 5 17 env35145 = env35160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35145 == env35160) = true)

theorem identity35160 : scanCanonicalize (H12AffineFastState.compose env35160 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound35160 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env35161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35244,1024,32769,2097152,33,2101384,41350,8328,17,2264457,2098569,4096,2231469,2102685,2142525,256,168,46212,2101913]

theorem envBound35161 : H12AffineFastState.Bounded env35161 := by
  intro p hp
  have h : env35161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35160_35161 : H12AffineEnvironment.transform 17 35244 env35160 = env35161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env35160 == env35161) = true)

theorem identity35161 : scanCanonicalize (H12AffineFastState.compose env35161 (packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 132489) := by decide +kernel

theorem selectedBound35161 : packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35162 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35244,1024,32769,132489,33,136449,41350,8328,17,34816,131072,4096,2340,135188,177332,256,168,46212,136976]

theorem envBound35162 : H12AffineFastState.Bounded env35162 := by
  intro p hp
  have h : env35162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35161_35162 : H12AffineEnvironment.transform 20 132489 env35161 = env35162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132489 env35161 == env35162) = true)

theorem identity35162 : scanCanonicalize (H12AffineFastState.compose env35162 (packedSelected [1,4,5,7,8,9,16,18,20,21,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound35162 : packedSelected [1,4,5,7,8,9,16,18,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env35163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,46109,35244,1024,32769,45460,33,41244,41350,8328,17,34816,46109,4096,2340,41993,169,256,168,46212,41741]

theorem envBound35163 : H12AffineFastState.Bounded env35163 := by
  intro p hp
  have h : env35163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35162_35163 : H12AffineEnvironment.transform 16 46109 env35162 = env35163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env35162 == env35163) = true)

theorem identity35163 : scanCanonicalize (H12AffineFastState.compose env35163 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1213) := by decide +kernel

theorem selectedBound35163 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env35164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,1213,8323,12448,3345,1024,1212,13609,33,9633,9531,8328,17,3261,12448,4096,2340,8372,169,256,168,12345,10160]

theorem envBound35164 : H12AffineFastState.Bounded env35164 := by
  intro p hp
  have h : env35164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35163_35164 : H12AffineEnvironment.transform 14 1213 env35163 = env35164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1213 env35163 == env35164) = true)

theorem identity35164 : scanCanonicalize (H12AffineFastState.compose env35164 (packedSelected [0,3,5,7,10,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35164 : packedSelected [0,3,5,7,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env35165 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1076,8202,12329,3345,1024,1077,13609,33,9512,9531,8193,17,3124,12329,4096,2340,8253,32,256,33,12345,10041]

theorem envBound35165 : H12AffineFastState.Bounded env35165 := by
  intro p hp
  have h : env35165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35164_35165 : H12AffineEnvironment.transform 6 9 env35164 = env35165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35164 == env35165) = true)

theorem identity35165 : scanCanonicalize (H12AffineFastState.compose env35165 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 7212) := by decide +kernel

theorem selectedBound35165 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35166 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7212,5376,1076,7206,3077,3345,1024,1077,2309,33,6404,6423,7213,17,3124,3077,4096,2340,7185,32,256,33,3093,6933]

theorem envBound35166 : H12AffineFastState.Bounded env35166 := by
  intro p hp
  have h : env35166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35165_35166 : H12AffineEnvironment.transform 12 7212 env35165 = env35166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7212 env35165 == env35166) = true)

theorem identity35166 : scanCanonicalize (H12AffineFastState.compose env35166 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound35166 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env35167 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1281,2349,1,1076,2343,3077,3345,1024,1077,2309,33,3077,3094,2348,17,3124,3077,1281,2340,2320,32,256,33,3093,3604]

theorem envBound35167 : H12AffineFastState.Bounded env35167 := by
  intro p hp
  have h : env35167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35166_35167 : H12AffineEnvironment.transform 11 1281 env35166 = env35167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env35166 == env35167) = true)

theorem identity35167 : scanCanonicalize (H12AffineFastState.compose env35167 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound35167 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env35168 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,1077,2073,1,1076,2067,3077,3109,1024,1077,2097,33,3077,3094,2072,17,3124,3077,1077,2064,2084,32,52,33,3093,3604]

theorem envBound35168 : H12AffineFastState.Bounded env35168 := by
  intro p hp
  have h : env35168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35167_35168 : H12AffineEnvironment.transform 7 52 env35167 = env35168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env35167 == env35168) = true)

theorem identity35168 : scanCanonicalize (H12AffineFastState.compose env35168 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35168 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35169 : List Nat := [2,4,8,0,32,1,9,36,512,1024,2048,1061,2057,1,1060,2051,3077,3109,1024,1061,2081,33,3077,3078,2056,1,3108,3077,1061,2048,2084,32,36,33,3077,3588]

theorem envBound35169 : H12AffineFastState.Bounded env35169 := by
  intro p hp
  have h : env35169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35168_35169 : H12AffineEnvironment.transform 3 0 env35168 = env35169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35168 == env35169) = true)

theorem identity35169 : scanCanonicalize (H12AffineFastState.compose env35169 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound35169 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35170 : List Nat := [2,4,8,0,32,1,9,36,512,549,2048,512,2057,1,513,2051,2592,2560,549,512,2081,33,2592,2595,2056,1,2561,2592,512,2048,2084,32,36,33,2592,2081]

theorem envBound35170 : H12AffineFastState.Bounded env35170 := by
  intro p hp
  have h : env35170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35169_35170 : H12AffineEnvironment.transform 9 549 env35169 = env35170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env35169 == env35170) = true)

theorem identity35170 : scanCanonicalize (H12AffineFastState.compose env35170 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35170 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35171 : List Nat := [2,4,8,0,32,1,9,36,1,36,2048,1,2057,1,0,2051,2081,2049,36,1,2081,33,2081,2082,2056,1,2048,2081,1,2048,2084,32,36,33,2081,2081]

theorem envBound35171 : H12AffineFastState.Bounded env35171 := by
  intro p hp
  have h : env35171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35170_35171 : H12AffineEnvironment.transform 8 1 env35170 = env35171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35170 == env35171) = true)

theorem identity35171 : scanCanonicalize (H12AffineFastState.compose env35171 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35172 : List Nat := [2,4,8,0,0,1,9,4,1,4,2048,1,2057,1,0,2051,2049,2049,4,1,2049,1,2049,2050,2056,1,2048,2049,1,2048,2052,0,4,1,2049,2049]

theorem envBound35172 : H12AffineFastState.Bounded env35172 := by
  intro p hp
  have h : env35172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35171_35172 : H12AffineEnvironment.transform 4 0 env35171 = env35172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35171 == env35172) = true)

theorem identity35172 : scanCanonicalize (H12AffineFastState.compose env35172 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35172 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35173 : List Nat := [2,4,8,0,0,1,9,4,1,4,1,1,8,1,0,2,0,0,4,1,0,1,0,3,9,1,1,0,1,1,5,0,4,1,0,0]

theorem envBound35173 : H12AffineFastState.Bounded env35173 := by
  intro p hp
  have h : env35173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35172_35173 : H12AffineEnvironment.transform 10 1 env35172 = env35173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35172 == env35173) = true)

theorem identity35173 : scanCanonicalize (H12AffineFastState.compose env35173 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35174 : List Nat := [2,4,2,0,0,1,3,4,1,4,1,1,2,1,0,2,0,0,4,1,0,1,0,3,3,1,1,0,1,1,5,0,4,1,0,0]

theorem envBound35174 : H12AffineFastState.Bounded env35174 := by
  intro p hp
  have h : env35174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35173_35174 : H12AffineEnvironment.transform 2 2 env35173 = env35174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35173 == env35174) = true)

def env35175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound35175 : H12AffineFastState.Bounded env35175 := by
  intro p hp
  have h : env35175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34976_35175 : H12AffineEnvironment.transform 18 1025 env34976 = env35175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env34976 == env35175) = true)

theorem identity35175 : scanCanonicalize (H12AffineFastState.compose env35175 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140420) := by decide +kernel

theorem selectedBound35175 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,16777216,8328,64,29868033,17014793,8548820,8830977,25265168,21184837,257,25419817,25362829,25207751]

theorem envBound35176 : H12AffineFastState.Bounded env35176 := by
  intro p hp
  have h : env35176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35175_35176 : H12AffineEnvironment.transform 20 140420 env35175 = env35176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140420 env35175 == env35176) = true)

def env35177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,8388608,8631560,8328,64,4486409,8393985,8548820,8830977,143640,12645453,257,21793,46213,202447]

theorem envBound35177 : H12AffineFastState.Bounded env35177 := by
  intro p hp
  have h : env35177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35176_35177 : H12AffineEnvironment.transform 23 8631560 env35176 = env35177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631560 env35176 == env35177) = true)

def env35178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180224,95496,8328,64,4486409,185601,45524,262145,143640,4338765,257,21793,46213,202447]

theorem envBound35178 : H12AffineFastState.Bounded env35178 := by
  intro p hp
  have h : env35178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35177_35178 : H12AffineEnvironment.transform 22 180224 env35177 = env35178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env35177 == env35178) = true)

def env35179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180224,95496,8328,64,23945,185601,45524,262145,143640,400589,257,21793,46213,202447]

theorem envBound35179 : H12AffineFastState.Bounded env35179 := by
  intro p hp
  have h : env35179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35178_35179 : H12AffineEnvironment.transform 21 272512 env35178 = env35179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35178 == env35179) = true)

theorem identity35179 : scanCanonicalize (H12AffineFastState.compose env35179 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound35179 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272512,17,95496,8328,64,23945,5392,45524,262145,61705,318684,257,21793,46213,120542]

theorem envBound35180 : H12AffineFastState.Bounded env35180 := by
  intro p hp
  have h : env35180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35179_35180 : H12AffineEnvironment.transform 16 49169 env35179 = env35180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35179 == env35180) = true)

def env35181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272392,17,95496,8192,64,23809,5392,45404,262145,61705,318548,257,21793,46093,120406]

theorem envBound35181 : H12AffineFastState.Bounded env35181 := by
  intro p hp
  have h : env35181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35180_35181 : H12AffineEnvironment.transform 6 8 env35180 = env35181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35180 == env35181) = true)

theorem identity35181 : scanCanonicalize (H12AffineFastState.compose env35181 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35181 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58397,32,17,95496,8192,64,23809,5392,45404,10281,61705,62588,257,21793,46093,120406]

theorem envBound35182 : H12AffineFastState.Bounded env35182 := by
  intro p hp
  have h : env35182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35181_35182 : H12AffineEnvironment.transform 17 10280 env35181 = env35182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35181 == env35182) = true)

theorem identity35182 : scanCanonicalize (H12AffineFastState.compose env35182 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound35182 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env35183 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21510,49169,10280,1025,32769,58397,32,17,8462,8192,64,23809,5392,45404,10281,61705,62588,257,21793,46093,33360]

theorem envBound35183 : H12AffineFastState.Bounded env35183 := by
  intro p hp
  have h : env35183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35182_35183 : H12AffineEnvironment.transform 15 21510 env35182 = env35183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env35182 == env35183) = true)

theorem identity35183 : scanCanonicalize (H12AffineFastState.compose env35183 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35183 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env35184 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,21510,49169,10280,1025,32769,58397,32,17,8462,8192,17,23809,5392,45325,10281,61705,62509,257,21793,46093,33281]

theorem envBound35184 : H12AffineFastState.Bounded env35184 := by
  intro p hp
  have h : env35184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35183_35184 : H12AffineEnvironment.transform 5 17 env35183 = env35184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35183 == env35184) = true)

theorem identity35184 : scanCanonicalize (H12AffineFastState.compose env35184 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35184 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env35185 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,21510,16400,10280,1025,0,25628,32,17,8462,8192,17,23809,5392,12556,10281,28936,29740,257,21793,13324,512]

theorem envBound35185 : H12AffineFastState.Bounded env35185 := by
  intro p hp
  have h : env35185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35184_35185 : H12AffineEnvironment.transform 14 1 env35184 = env35185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35184 == env35185) = true)

theorem identity35185 : scanCanonicalize (H12AffineFastState.compose env35185 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound35185 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35186 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,16384,1,21510,16400,2309,1025,0,17713,32,17,35,301,17,23809,5392,4129,2308,20517,21761,257,21793,5409,512]

theorem envBound35186 : H12AffineFastState.Bounded env35186 := by
  intro p hp
  have h : env35186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35185_35186 : H12AffineEnvironment.transform 12 301 env35185 = env35186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env35185 == env35186) = true)

theorem identity35186 : scanCanonicalize (H12AffineFastState.compose env35186 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35186 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35187 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,5377,1,263,5393,2309,1025,0,4144,32,17,35,301,17,2048,5392,4129,2308,1316,0,257,32,5409,512]

theorem envBound35187 : H12AffineFastState.Bounded env35187 := by
  intro p hp
  have h : env35187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35186_35187 : H12AffineEnvironment.transform 13 5377 env35186 = env35187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35186 == env35187) = true)

theorem identity35187 : scanCanonicalize (H12AffineFastState.compose env35187 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound35187 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env35188 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1313,301,32,1,263,48,2309,1025,0,1297,32,17,35,301,17,2048,49,1280,2308,1316,0,257,32,0,512]

theorem envBound35188 : H12AffineFastState.Bounded env35188 := by
  intro p hp
  have h : env35188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35187_35188 : H12AffineEnvironment.transform 11 1313 env35187 = env35188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env35187 == env35188) = true)

theorem identity35188 : scanCanonicalize (H12AffineFastState.compose env35188 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound35188 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35189 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,17,301,32,1,263,48,2309,305,0,33,32,17,35,301,17,2048,49,48,2308,20,0,257,32,0,512]

theorem envBound35189 : H12AffineFastState.Bounded env35189 := by
  intro p hp
  have h : env35189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35188_35189 : H12AffineEnvironment.transform 9 304 env35188 = env35189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env35188 == env35189) = true)

theorem identity35189 : scanCanonicalize (H12AffineFastState.compose env35189 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound35189 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35190 : List Nat := [2,4,8,16,32,17,8,256,512,304,260,17,301,32,1,263,48,1,305,0,33,32,17,35,301,17,260,49,48,0,20,0,257,32,0,512]

theorem envBound35190 : H12AffineFastState.Bounded env35190 := by
  intro p hp
  have h : env35190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35189_35190 : H12AffineEnvironment.transform 10 260 env35189 = env35190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env35189 == env35190) = true)

theorem identity35190 : scanCanonicalize (H12AffineFastState.compose env35190 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35190 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35191 : List Nat := [2,4,8,16,32,17,8,4,512,52,0,17,41,32,1,3,48,1,53,0,33,32,17,35,41,17,0,49,48,0,20,0,5,32,0,512]

theorem envBound35191 : H12AffineFastState.Bounded env35191 := by
  intro p hp
  have h : env35191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35190_35191 : H12AffineEnvironment.transform 7 4 env35190 = env35191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35190 == env35191) = true)

theorem identity35191 : scanCanonicalize (H12AffineFastState.compose env35191 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35191 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env35192 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,17,8,1,1,3,17,1,20,0,0,1,17,2,8,17,0,16,17,0,20,0,5,1,0,512]

theorem envBound35192 : H12AffineFastState.Bounded env35192 := by
  intro p hp
  have h : env35192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35191_35192 : H12AffineEnvironment.transform 4 1 env35191 = env35192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35191 == env35192) = true)

theorem identity35192 : scanCanonicalize (H12AffineFastState.compose env35192 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound35192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35193 : List Nat := [2,4,8,16,1,17,8,4,20,21,0,17,8,1,1,3,17,1,20,0,0,1,17,2,8,17,0,16,17,0,20,0,5,1,0,20]

theorem envBound35193 : H12AffineFastState.Bounded env35193 := by
  intro p hp
  have h : env35193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35192_35193 : H12AffineEnvironment.transform 8 20 env35192 = env35193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env35192 == env35193) = true)

theorem identity35193 : scanCanonicalize (H12AffineFastState.compose env35193 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound35193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35194 : List Nat := [2,4,8,9,1,8,8,4,13,12,0,8,8,1,1,3,8,1,13,0,0,1,8,2,8,8,0,9,8,0,13,0,5,1,0,13]

theorem envBound35194 : H12AffineFastState.Bounded env35194 := by
  intro p hp
  have h : env35194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35193_35194 : H12AffineEnvironment.transform 3 9 env35193 = env35194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env35193 == env35194) = true)

theorem identity35194 : scanCanonicalize (H12AffineFastState.compose env35194 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35194 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35195 : List Nat := [2,2,8,9,1,8,8,2,11,10,0,8,8,1,1,3,8,1,11,0,0,1,8,2,8,8,0,9,8,0,11,0,3,1,0,11]

theorem envBound35195 : H12AffineFastState.Bounded env35195 := by
  intro p hp
  have h : env35195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35194_35195 : H12AffineEnvironment.transform 1 2 env35194 = env35195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35194 == env35195) = true)

theorem identity35195 : scanCanonicalize (H12AffineFastState.compose env35195 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35195 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35196 : List Nat := [2,2,2,3,1,2,2,2,1,0,0,2,2,1,1,3,2,1,1,0,0,1,2,2,2,2,0,3,2,0,1,0,3,1,0,1]

theorem envBound35196 : H12AffineFastState.Bounded env35196 := by
  intro p hp
  have h : env35196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35195_35196 : H12AffineEnvironment.transform 2 2 env35195 = env35196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35195 == env35196) = true)

theorem identity35196 : scanCanonicalize (H12AffineFastState.compose env35196 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35196 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35197 : List Nat := [0,0,0,1,1,0,0,0,1,0,0,0,0,1,1,1,0,1,1,0,0,1,0,0,0,0,0,1,0,0,1,0,1,1,0,1]

theorem envBound35197 : H12AffineFastState.Bounded env35197 := by
  intro p hp
  have h : env35197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35196_35197 : H12AffineEnvironment.transform 0 0 env35196 = env35197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35196 == env35197) = true)

def env35198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272393,17,95496,8193,64,23808,5392,45405,262145,61705,318549,257,21793,46092,120407]

theorem envBound35198 : H12AffineFastState.Bounded env35198 := by
  intro p hp
  have h : env35198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35180_35198 : H12AffineEnvironment.transform 6 9 env35180 = env35198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35180 == env35198) = true)

theorem identity35198 : scanCanonicalize (H12AffineFastState.compose env35198 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound35198 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35199 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,58396,41340,17,95496,8193,64,23808,5392,45405,35188,61705,21792,257,21793,46092,120407]

theorem envBound35199 : H12AffineFastState.Bounded env35199 := by
  intro p hp
  have h : env35199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35198_35199 : H12AffineEnvironment.transform 17 35189 env35198 = env35199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env35198 == env35199) = true)

theorem identity35199 : scanCanonicalize (H12AffineFastState.compose env35199 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35199 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,49169,35189,1025,32769,58396,41340,17,30075,8193,64,23808,5392,45405,35188,61705,21792,257,21793,46092,54820]

theorem envBound35200 : H12AffineFastState.Bounded env35200 := by
  intro p hp
  have h : env35200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35199_35200 : H12AffineEnvironment.transform 15 115 env35199 = env35200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35199 == env35200) = true)

theorem identity35200 : scanCanonicalize (H12AffineFastState.compose env35200 (packedSelected [0,7,9,14,16,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound35200 : packedSelected [0,7,9,14,16,19,22,26] rootPS < 2^1333 := by decide +kernel

def env35201 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,115,24632,10588,1025,8232,17461,341,17,30075,8193,64,23808,5392,4468,10589,20768,21792,257,21793,5157,30221]

theorem envBound35201 : H12AffineFastState.Bounded env35201 := by
  intro p hp
  have h : env35201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35200_35201 : H12AffineEnvironment.transform 14 8233 env35200 = env35201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env35200 == env35201) = true)

theorem identity35201 : scanCanonicalize (H12AffineFastState.compose env35201 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35201 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env35202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8233,115,5220,10588,1025,8232,12393,341,17,295,8193,64,10588,5392,4468,10589,9596,8572,257,8573,5157,593]

theorem envBound35202 : H12AffineFastState.Bounded env35202 := by
  intro p hp
  have h : env35202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35201_35202 : H12AffineEnvironment.transform 13 13404 env35201 = env35202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35201 == env35202) = true)

theorem identity35202 : scanCanonicalize (H12AffineFastState.compose env35202 (packedSelected [1,2,6,8,12,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35202 : packedSelected [1,2,6,8,12,18,19] rootPS < 2^1333 := by decide +kernel

def env35203 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,8233,115,4468,10588,273,8232,12393,341,17,295,8193,64,10588,4096,4468,10589,8300,8572,257,8573,4405,593]

theorem envBound35203 : H12AffineFastState.Bounded env35203 := by
  intro p hp
  have h : env35203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35202_35203 : H12AffineEnvironment.transform 9 272 env35202 = env35203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35202 == env35203) = true)

theorem identity35203 : scanCanonicalize (H12AffineFastState.compose env35203 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound35203 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35204 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,41,4453,0,115,4468,2421,273,1,4160,341,17,295,40,64,2421,4096,4468,2420,69,341,257,340,4405,593]

theorem envBound35204 : H12AffineFastState.Bounded env35204 := by
  intro p hp
  have h : env35204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35203_35204 : H12AffineEnvironment.transform 12 41 env35203 = env35204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env35203 == env35204) = true)

theorem identity35204 : scanCanonicalize (H12AffineFastState.compose env35204 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35204 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35205 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,41,4112,0,115,4097,2048,100,1,4160,32,17,82,40,64,2048,4096,4097,2049,69,32,116,33,4160,593]

theorem envBound35205 : H12AffineFastState.Bounded env35205 := by
  intro p hp
  have h : env35205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35204_35205 : H12AffineEnvironment.transform 7 117 env35204 = env35205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35204 == env35205) = true)

theorem identity35205 : scanCanonicalize (H12AffineFastState.compose env35205 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound35205 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env35206 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2065,41,2049,0,115,2064,2048,100,1,2129,32,17,82,40,64,2048,2065,2064,2049,69,32,116,33,2129,593]

theorem envBound35206 : H12AffineFastState.Bounded env35206 := by
  intro p hp
  have h : env35206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35205_35206 : H12AffineEnvironment.transform 11 2065 env35205 = env35206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env35205 == env35206) = true)

theorem identity35206 : scanCanonicalize (H12AffineFastState.compose env35206 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35206 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env35207 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2065,41,2049,0,35,2064,2048,52,1,2049,32,17,2,40,16,2048,2065,2064,2049,21,32,36,33,2049,513]

theorem envBound35207 : H12AffineFastState.Bounded env35207 := by
  intro p hp
  have h : env35207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35206_35207 : H12AffineEnvironment.transform 5 16 env35206 = env35207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35206 == env35207) = true)

theorem identity35207 : scanCanonicalize (H12AffineFastState.compose env35207 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35207 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35208 : List Nat := [2,4,8,16,32,16,9,37,17,53,2048,2065,41,2049,0,35,2064,2048,52,1,2049,32,17,2,40,16,2048,2065,2064,2049,21,32,36,33,2049,16]

theorem envBound35208 : H12AffineFastState.Bounded env35208 := by
  intro p hp
  have h : env35208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35207_35208 : H12AffineEnvironment.transform 8 17 env35207 = env35208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35207 == env35208) = true)

theorem identity35208 : scanCanonicalize (H12AffineFastState.compose env35208 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound35208 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35209 : List Nat := [2,4,8,16,32,16,9,37,17,53,11,26,41,10,0,35,27,11,52,1,10,32,17,2,40,16,11,26,27,10,21,32,36,33,10,16]

theorem envBound35209 : H12AffineFastState.Bounded env35209 := by
  intro p hp
  have h : env35209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35208_35209 : H12AffineEnvironment.transform 10 11 env35208 = env35209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env35208 == env35209) = true)

theorem identity35209 : scanCanonicalize (H12AffineFastState.compose env35209 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35210 : List Nat := [2,4,2,16,32,16,3,37,17,53,1,16,35,0,0,35,17,1,52,1,0,32,17,2,34,16,1,16,17,0,21,32,36,33,0,16]

theorem envBound35210 : H12AffineFastState.Bounded env35210 := by
  intro p hp
  have h : env35210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35209_35210 : H12AffineEnvironment.transform 2 2 env35209 = env35210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35209 == env35210) = true)

def env35211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272513,180224,95496,8328,64,23944,185601,45524,262145,143640,400588,257,21793,46213,202447]

theorem envBound35211 : H12AffineFastState.Bounded env35211 := by
  intro p hp
  have h : env35211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35178_35211 : H12AffineEnvironment.transform 21 272513 env35178 = env35211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35178 == env35211) = true)

def env35212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272393,180224,95496,8192,64,23808,185601,45404,262145,143640,400452,257,21793,46093,202311]

theorem envBound35212 : H12AffineFastState.Bounded env35212 := by
  intro p hp
  have h : env35212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35211_35212 : H12AffineEnvironment.transform 6 8 env35211 = env35212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35211 == env35212) = true)

def env35213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58396,272393,16,95496,8192,64,23808,5393,45404,262145,61704,318548,257,21793,46093,120407]

theorem envBound35213 : H12AffineFastState.Bounded env35213 := by
  intro p hp
  have h : env35213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35212_35213 : H12AffineEnvironment.transform 16 49168 env35212 = env35213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35212 == env35213) = true)

theorem identity35213 : scanCanonicalize (H12AffineFastState.compose env35213 (packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 64888) := by decide +kernel

theorem selectedBound35213 : packedSelected [0,1,3,4,8,10,12,14,16,18,22,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env35214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,64888,1025,32769,58396,54641,16,95496,8192,64,23808,5393,45404,64889,61704,8492,257,21793,46093,120407]

theorem envBound35214 : H12AffineFastState.Bounded env35214 := by
  intro p hp
  have h : env35214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35213_35214 : H12AffineEnvironment.transform 17 64888 env35213 = env35214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64888 env35213 == env35214) = true)

theorem identity35214 : scanCanonicalize (H12AffineFastState.compose env35214 (packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35214 : packedSelected [1,3,4,5,9,10,12,15,18,20,23,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env35215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,65536,49168,56436,1025,32769,50448,54641,16,87044,268,64,23808,5393,36944,56437,53252,32,257,21793,38145,120407]

theorem envBound35215 : H12AffineFastState.Bounded env35215 := by
  intro p hp
  have h : env35215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35214_35215 : H12AffineEnvironment.transform 12 268 env35214 = env35215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35214 == env35215) = true)

theorem identity35215 : scanCanonicalize (H12AffineFastState.compose env35215 (packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35215 : packedSelected [0,1,3,7,8,9,10,12,14,15,20,22,24] rootPS < 2^1333 := by decide +kernel

def env35216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,32768,65536,38209,35109,1025,32769,36929,32800,16,65877,268,64,2129,5393,36944,35108,34133,32,257,112,38145,99078]

theorem envBound35216 : H12AffineFastState.Bounded env35216 := by
  intro p hp
  have h : env35216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35215_35216 : H12AffineEnvironment.transform 13 5457 env35215 = env35216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35215 == env35216) = true)

theorem identity35216 : scanCanonicalize (H12AffineFastState.compose env35216 (packedSelected [2,3,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7504) := by decide +kernel

theorem selectedBound35216 : packedSelected [2,3,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env35217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,7504,65536,2065,5237,1025,7505,3345,7536,16,65877,268,64,2129,5393,3328,5236,6149,32,257,112,2129,73302]

theorem envBound35217 : H12AffineFastState.Bounded env35217 := by
  intro p hp
  have h : env35217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35216_35217 : H12AffineEnvironment.transform 14 7504 env35216 = env35217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7504 env35216 == env35217) = true)

theorem identity35217 : scanCanonicalize (H12AffineFastState.compose env35217 (packedSelected [3,4,7,8,11,14,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound35217 : packedSelected [3,4,7,8,11,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,7504,263,2065,5237,1025,7505,3345,7536,16,82,268,64,2129,5393,3328,5236,6149,32,257,112,2129,8017]

theorem envBound35218 : H12AffineFastState.Bounded env35218 := by
  intro p hp
  have h : env35218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35217_35218 : H12AffineEnvironment.transform 15 263 env35217 = env35218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env35217 == env35218) = true)

theorem identity35218 : scanCanonicalize (H12AffineFastState.compose env35218 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound35218 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env35219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,268,1076,3125,263,2065,1296,1025,3124,3345,3093,16,82,268,64,2129,1140,3328,1297,2400,32,257,112,2129,3636]

theorem envBound35219 : H12AffineFastState.Bounded env35219 := by
  intro p hp
  have h : env35219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35218_35219 : H12AffineEnvironment.transform 11 357 env35218 = env35219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env35218 == env35219) = true)

theorem identity35219 : scanCanonicalize (H12AffineFastState.compose env35219 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35219 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env35220 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,357,268,293,2340,263,2065,1,272,2341,2048,2308,16,82,268,64,2129,357,2065,0,2400,32,257,112,2129,2853]

theorem envBound35220 : H12AffineFastState.Bounded env35220 := by
  intro p hp
  have h : env35220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35219_35220 : H12AffineEnvironment.transform 9 273 env35219 = env35220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35219 == env35220) = true)

theorem identity35220 : scanCanonicalize (H12AffineFastState.compose env35220 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35220 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env35221 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,357,268,293,292,263,17,1,272,293,0,260,16,82,268,64,81,357,17,0,352,32,257,112,81,805]

theorem envBound35221 : H12AffineFastState.Bounded env35221 := by
  intro p hp
  have h : env35221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35220_35221 : H12AffineEnvironment.transform 10 0 env35220 = env35221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35220 == env35221) = true)

theorem identity35221 : scanCanonicalize (H12AffineFastState.compose env35221 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35221 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35222 : List Nat := [2,4,8,16,32,64,8,116,512,101,0,17,120,81,80,115,17,1,100,81,0,112,16,82,120,64,81,17,17,0,20,32,117,112,81,593]

theorem envBound35222 : H12AffineFastState.Bounded env35222 := by
  intro p hp
  have h : env35222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35221_35222 : H12AffineEnvironment.transform 7 116 env35221 = env35222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35221 == env35222) = true)

theorem identity35222 : scanCanonicalize (H12AffineFastState.compose env35222 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35222 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35223 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,40,1,0,35,17,1,52,1,0,32,16,2,40,16,1,17,17,0,20,32,37,32,1,513]

theorem envBound35223 : H12AffineFastState.Bounded env35223 := by
  intro p hp
  have h : env35223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35222_35223 : H12AffineEnvironment.transform 5 16 env35222 = env35223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35222 == env35223) = true)

theorem identity35223 : scanCanonicalize (H12AffineFastState.compose env35223 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound35223 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35224 : List Nat := [2,4,8,1,32,1,8,36,512,36,0,0,40,1,0,35,0,1,37,1,0,32,1,2,40,1,1,0,0,0,5,32,37,32,1,513]

theorem envBound35224 : H12AffineFastState.Bounded env35224 := by
  intro p hp
  have h : env35224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35223_35224 : H12AffineEnvironment.transform 3 1 env35223 = env35224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35223 == env35224) = true)

theorem identity35224 : scanCanonicalize (H12AffineFastState.compose env35224 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35225 : List Nat := [2,4,8,1,10,1,8,14,512,14,0,0,2,1,0,9,0,1,15,1,0,10,1,2,2,1,1,0,0,0,5,10,15,10,1,513]

theorem envBound35225 : H12AffineFastState.Bounded env35225 := by
  intro p hp
  have h : env35225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35224_35225 : H12AffineEnvironment.transform 4 10 env35224 = env35225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35224 == env35225) = true)

def env35226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58397,272393,17,95496,8192,64,23808,5392,45404,262145,61705,318549,257,21793,46093,120406]

theorem envBound35226 : H12AffineFastState.Bounded env35226 := by
  intro p hp
  have h : env35226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35212_35226 : H12AffineEnvironment.transform 16 49169 env35212 = env35226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35212 == env35226) = true)

theorem identity35226 : scanCanonicalize (H12AffineFastState.compose env35226 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35226 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,58397,33,17,95496,8192,64,23808,5392,45404,10281,61705,62589,257,21793,46093,120406]

theorem envBound35227 : H12AffineFastState.Bounded env35227 := by
  intro p hp
  have h : env35227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35226_35227 : H12AffineEnvironment.transform 17 10280 env35226 = env35227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35226 == env35227) = true)

theorem identity35227 : scanCanonicalize (H12AffineFastState.compose env35227 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound35227 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env35228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,49169,10280,1025,32769,58397,33,17,83,8192,64,23808,5392,45404,10281,61705,62589,257,21793,46093,41741]

theorem envBound35228 : H12AffineFastState.Bounded env35228 := by
  intro p hp
  have h : env35228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35227_35228 : H12AffineEnvironment.transform 15 30043 env35227 = env35228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env35227 == env35228) = true)

theorem identity35228 : scanCanonicalize (H12AffineFastState.compose env35228 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35228 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env35229 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,10280,1025,32769,58397,33,17,3,8192,16,23808,5392,45324,10281,61705,62509,257,21793,46093,41741]

theorem envBound35229 : H12AffineFastState.Bounded env35229 := by
  intro p hp
  have h : env35229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35228_35229 : H12AffineEnvironment.transform 5 16 env35228 = env35229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35228 == env35229) = true)

theorem identity35229 : scanCanonicalize (H12AffineFastState.compose env35229 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 14393) := by decide +kernel

theorem selectedBound35229 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35230 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,14393,29963,30760,10280,1025,14392,23588,33,17,3,8192,16,23808,5392,2357,10281,18736,19476,257,21793,3124,6964]

theorem envBound35230 : H12AffineFastState.Bounded env35230 := by
  intro p hp
  have h : env35230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35229_35230 : H12AffineEnvironment.transform 14 14393 env35229 = env35230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14393 env35229 == env35230) = true)

theorem identity35230 : scanCanonicalize (H12AffineFastState.compose env35230 (packedSelected [2,3,5,6,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound35230 : packedSelected [2,3,5,6,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env35231 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,7425,14393,10250,9513,10280,1025,14392,293,33,17,3,8192,16,1,5392,2357,10281,5169,4373,257,2080,3124,6964]

theorem envBound35231 : H12AffineFastState.Bounded env35231 := by
  intro p hp
  have h : env35231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35230_35231 : H12AffineEnvironment.transform 13 7425 env35230 = env35231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env35230 == env35231) = true)

theorem identity35231 : scanCanonicalize (H12AffineFastState.compose env35231 (packedSelected [0,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound35231 : packedSelected [0,7,11,14] rootPS < 2^1333 := by decide +kernel

def env35232 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,8192,3124,10508,10250,9513,10280,1025,10509,293,33,17,3,8192,16,1,1061,2357,10281,1284,32,257,2080,3124,2561]

theorem envBound35232 : H12AffineFastState.Bounded env35232 := by
  intro p hp
  have h : env35232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35231_35232 : H12AffineEnvironment.transform 11 309 env35231 = env35232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env35231 == env35232) = true)

theorem identity35232 : scanCanonicalize (H12AffineFastState.compose env35232 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35232 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env35233 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,8192,1077,8461,8203,9513,8233,1025,8460,293,33,17,3,8192,16,1,1061,308,8232,1284,32,257,33,1077,512]

theorem envBound35233 : H12AffineFastState.Bounded env35233 := by
  intro p hp
  have h : env35233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35232_35233 : H12AffineEnvironment.transform 10 1 env35232 = env35233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35232 == env35233) = true)

theorem identity35233 : scanCanonicalize (H12AffineFastState.compose env35233 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound35233 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35234 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,309,300,1077,33,295,1029,261,1025,32,293,33,17,3,300,16,1,1061,308,260,1284,32,257,33,1077,512]

theorem envBound35234 : H12AffineFastState.Bounded env35234 := by
  intro p hp
  have h : env35234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35233_35234 : H12AffineEnvironment.transform 12 300 env35233 = env35234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env35233 == env35234) = true)

theorem identity35234 : scanCanonicalize (H12AffineFastState.compose env35234 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35234 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35235 : List Nat := [2,4,8,16,32,16,8,256,512,52,1,309,300,1,33,295,49,261,53,32,293,33,17,3,300,16,1,17,308,260,304,32,257,33,1,512]

theorem envBound35235 : H12AffineFastState.Bounded env35235 := by
  intro p hp
  have h : env35235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35234_35235 : H12AffineEnvironment.transform 9 52 env35234 = env35235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35234 == env35235) = true)

theorem identity35235 : scanCanonicalize (H12AffineFastState.compose env35235 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35235 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env35236 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,16,9,1,33,2,49,32,53,32,0,33,17,3,9,16,1,17,17,33,21,32,36,33,1,512]

theorem envBound35236 : H12AffineFastState.Bounded env35236 := by
  intro p hp
  have h : env35236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35235_35236 : H12AffineEnvironment.transform 7 37 env35235 = env35236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35235 == env35236) = true)

theorem identity35236 : scanCanonicalize (H12AffineFastState.compose env35236 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35236 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35237 : List Nat := [2,4,8,16,1,16,8,4,512,21,1,16,9,1,0,2,16,1,20,1,0,0,17,3,9,16,1,17,17,0,21,1,5,0,1,512]

theorem envBound35237 : H12AffineFastState.Bounded env35237 := by
  intro p hp
  have h : env35237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35236_35237 : H12AffineEnvironment.transform 4 1 env35236 = env35237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35236 == env35237) = true)

theorem identity35237 : scanCanonicalize (H12AffineFastState.compose env35237 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35238 : List Nat := [2,4,8,0,1,0,8,4,512,5,1,0,9,1,0,2,0,1,4,1,0,0,1,3,9,0,1,1,1,0,5,1,5,0,1,512]

theorem envBound35238 : H12AffineFastState.Bounded env35238 := by
  intro p hp
  have h : env35238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35237_35238 : H12AffineEnvironment.transform 3 0 env35237 = env35238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35237 == env35238) = true)

theorem identity35238 : scanCanonicalize (H12AffineFastState.compose env35238 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound35238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35239 : List Nat := [2,1,8,0,1,0,8,1,512,0,1,0,9,1,0,2,0,1,1,1,0,0,1,3,9,0,1,1,1,0,0,1,0,0,1,512]

theorem envBound35239 : H12AffineFastState.Bounded env35239 := by
  intro p hp
  have h : env35239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35238_35239 : H12AffineEnvironment.transform 1 1 env35238 = env35239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env35238 == env35239) = true)

theorem identity35239 : scanCanonicalize (H12AffineFastState.compose env35239 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound35239 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35240 : List Nat := [2,1,8,0,1,0,8,1,1,0,1,0,9,1,0,2,0,1,1,1,0,0,1,3,9,0,1,1,1,0,0,1,0,0,1,1]

theorem envBound35240 : H12AffineFastState.Bounded env35240 := by
  intro p hp
  have h : env35240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35239_35240 : H12AffineEnvironment.transform 8 1 env35239 = env35240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env35239 == env35240) = true)

def env35241 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140301,272392,180224,95496,8193,64,23809,185601,45405,262145,143640,400453,257,21793,46092,202310]

theorem envBound35241 : H12AffineFastState.Bounded env35241 := by
  intro p hp
  have h : env35241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35211_35241 : H12AffineEnvironment.transform 6 9 env35211 = env35241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35211 == env35241) = true)

def env35242 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,58397,272392,16,95496,8193,64,23809,5393,45405,262145,61704,318549,257,21793,46092,120406]

theorem envBound35242 : H12AffineFastState.Bounded env35242 := by
  intro p hp
  have h : env35242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35241_35242 : H12AffineEnvironment.transform 16 49168 env35241 = env35242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35241 == env35242) = true)

theorem identity35242 : scanCanonicalize (H12AffineFastState.compose env35242 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound35242 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35243 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1025,8541,17729,272392,16,95496,8193,64,23809,5393,4097,262145,20564,294153,257,21793,5456,96010]

theorem envBound35243 : H12AffineFastState.Bounded env35243 := by
  intro p hp
  have h : env35243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35242_35243 : H12AffineEnvironment.transform 14 8540 env35242 = env35243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env35242 == env35243) = true)

theorem identity35243 : scanCanonicalize (H12AffineFastState.compose env35243 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound35243 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,23669,1025,8541,17729,29821,16,95496,8193,64,23809,5393,4097,23668,20564,8572,257,21793,5456,96010]

theorem envBound35244 : H12AffineFastState.Bounded env35244 := by
  intro p hp
  have h : env35244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35243_35244 : H12AffineEnvironment.transform 17 23669 env35243 = env35244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env35243 == env35244) = true)

theorem identity35244 : scanCanonicalize (H12AffineFastState.compose env35244 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35244 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env35245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,65536,5392,10281,1025,8541,12573,33,16,65876,8193,64,10589,5393,4097,10280,9224,8572,257,8573,5456,66390]

theorem envBound35245 : H12AffineFastState.Bounded env35245 := by
  intro p hp
  have h : env35245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35244_35245 : H12AffineEnvironment.transform 13 13404 env35244 = env35245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35244 == env35245) = true)

theorem identity35245 : scanCanonicalize (H12AffineFastState.compose env35245 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound35245 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35246 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,12620,8540,65536,4096,10281,273,8541,12573,33,16,65876,8193,64,10589,4097,4097,10280,8472,8572,257,8573,4160,66390]

theorem envBound35246 : H12AffineFastState.Bounded env35246 := by
  intro p hp
  have h : env35246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35245_35246 : H12AffineEnvironment.transform 9 272 env35245 = env35246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env35245 == env35246) = true)

theorem identity35246 : scanCanonicalize (H12AffineFastState.compose env35246 (packedSelected [4,9,11,12,14,15,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35246 : packedSelected [4,9,11,12,14,15,16,23] rootPS < 2^1333 := by decide +kernel

def env35247 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,0,65536,4096,2421,273,1,4161,33,16,65876,349,64,2049,4097,4097,2420,68,32,257,33,4160,66390]

theorem envBound35247 : H12AffineFastState.Bounded env35247 := by
  intro p hp
  have h : env35247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35246_35247 : H12AffineEnvironment.transform 12 348 env35246 = env35247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35246 == env35247) = true)

theorem identity35247 : scanCanonicalize (H12AffineFastState.compose env35247 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound35247 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35248 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,0,115,4096,2421,273,1,4161,33,16,295,349,64,2049,4097,4097,2420,68,32,257,33,4160,805]

theorem envBound35248 : H12AffineFastState.Bounded env35248 := by
  intro p hp
  have h : env35248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35247_35248 : H12AffineEnvironment.transform 15 115 env35247 = env35248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env35247 == env35248) = true)

theorem identity35248 : scanCanonicalize (H12AffineFastState.compose env35248 (packedSelected [2,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound35248 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env35249 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2357,348,2341,0,115,2357,2421,273,1,2420,33,16,295,349,64,2049,2356,2356,2420,68,32,257,33,2421,805]

theorem envBound35249 : H12AffineFastState.Bounded env35249 := by
  intro p hp
  have h : env35249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35248_35249 : H12AffineEnvironment.transform 11 2357 env35248 = env35249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env35248 == env35249) = true)

theorem identity35249 : scanCanonicalize (H12AffineFastState.compose env35249 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35249 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env35250 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2357,268,2341,0,35,2357,2341,273,1,2340,33,16,295,269,16,2049,2356,2356,2340,20,32,257,33,2341,805]

theorem envBound35250 : H12AffineFastState.Bounded env35250 := by
  intro p hp
  have h : env35250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35249_35250 : H12AffineEnvironment.transform 5 16 env35249 = env35250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35249 == env35250) = true)

theorem identity35250 : scanCanonicalize (H12AffineFastState.compose env35250 (packedSelected [2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound35250 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env35251 : List Nat := [2,4,8,16,32,16,9,256,292,272,2048,2357,268,2341,0,35,2357,2341,273,1,2340,33,16,295,269,16,2049,2356,2356,2340,20,32,257,33,2341,1]

theorem envBound35251 : H12AffineFastState.Bounded env35251 := by
  intro p hp
  have h : env35251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35250_35251 : H12AffineEnvironment.transform 8 292 env35250 = env35251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env35250 == env35251) = true)

def env35252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58396,272392,17,95496,8193,64,23809,5392,45405,262145,61705,318548,257,21793,46092,120407]

theorem envBound35252 : H12AffineFastState.Bounded env35252 := by
  intro p hp
  have h : env35252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35241_35252 : H12AffineEnvironment.transform 16 49169 env35241 = env35252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35241 == env35252) = true)

theorem identity35252 : scanCanonicalize (H12AffineFastState.compose env35252 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound35252 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1025,32769,58396,41341,17,95496,8193,64,23809,5392,45405,35188,61705,21793,257,21793,46092,120407]

theorem envBound35253 : H12AffineFastState.Bounded env35253 := by
  intro p hp
  have h : env35253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35252_35253 : H12AffineEnvironment.transform 17 35189 env35252 = env35253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env35252 == env35253) = true)

theorem identity35253 : scanCanonicalize (H12AffineFastState.compose env35253 (packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound35253 : packedSelected [1,5,7,12,14,15,16,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32803,49169,35189,1025,32769,58396,41341,17,62763,8193,64,23809,5392,45405,35188,61705,21793,257,21793,46092,22132]

theorem envBound35254 : H12AffineFastState.Bounded env35254 := by
  intro p hp
  have h : env35254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35253_35254 : H12AffineEnvironment.transform 15 32803 env35253 = env35254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env35253 == env35254) = true)

theorem identity35254 : scanCanonicalize (H12AffineFastState.compose env35254 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound35254 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env35255 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,29963,13625,31837,1025,29993,4404,21589,17,3,8193,64,23809,5392,17525,31836,1057,21793,257,21793,16676,22132]

theorem envBound35255 : H12AffineFastState.Bounded env35255 := by
  intro p hp
  have h : env35255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35254_35255 : H12AffineEnvironment.transform 14 29992 env35254 = env35255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env35254 == env35255) = true)

theorem identity35255 : scanCanonicalize (H12AffineFastState.compose env35255 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound35255 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env35256 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,8192,16384,27724,27759,11357,25913,1025,27725,2128,19761,17,3,8193,64,17509,3188,17525,25912,1057,19525,257,19525,16676,20240]

theorem envBound35256 : H12AffineFastState.Bounded env35256 := by
  intro p hp
  have h : env35256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35255_35256 : H12AffineEnvironment.transform 11 2404 env35255 = env35256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env35255 == env35256) = true)

theorem identity35256 : scanCanonicalize (H12AffineFastState.compose env35256 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound35256 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env35257 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,2169,16384,17461,17430,1060,19776,1025,17460,2128,19761,17,3,2168,64,17509,3188,17525,19777,1057,19525,257,19525,16676,20240]

theorem envBound35257 : H12AffineFastState.Bounded env35257 := by
  intro p hp
  have h : env35257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35256_35257 : H12AffineEnvironment.transform 12 2169 env35256 = env35257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env35256 == env35257) = true)

def env35258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,4194304,180225,95497,8328,64,4486409,185600,45525,262144,143640,4338764,257,21793,46213,202447]

theorem envBound35258 : H12AffineFastState.Bounded env35258 := by
  intro p hp
  have h : env35258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35177_35258 : H12AffineEnvironment.transform 22 180225 env35177 = env35258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env35177 == env35258) = true)

def env35259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140420,272512,180225,95497,8328,64,23945,185600,45525,262144,143640,400588,257,21793,46213,202447]

theorem envBound35259 : H12AffineFastState.Bounded env35259 := by
  intro p hp
  have h : env35259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35258_35259 : H12AffineEnvironment.transform 21 272512 env35258 = env35259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35258 == env35259) = true)

theorem identity35259 : scanCanonicalize (H12AffineFastState.compose env35259 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound35259 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,272512,62661,95497,8328,64,23945,57796,45525,262144,1500,272392,257,21793,46213,74251]

theorem envBound35260 : H12AffineFastState.Bounded env35260 := by
  intro p hp
  have h : env35260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35259_35260 : H12AffineEnvironment.transform 16 13508 env35259 = env35260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env35259 == env35260) = true)

theorem identity35260 : scanCanonicalize (H12AffineFastState.compose env35260 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound35260 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,262144,1025,32769,4160,272512,62661,21763,8328,64,23945,57796,45525,262144,1500,272392,257,21793,46213,513]

theorem envBound35261 : H12AffineFastState.Bounded env35261 := by
  intro p hp
  have h : env35261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35260_35261 : H12AffineEnvironment.transform 15 8202 env35260 = env35261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env35260 == env35261) = true)

theorem identity35261 : scanCanonicalize (H12AffineFastState.compose env35261 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound35261 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env35262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13508,2557,1025,32769,4160,8573,62661,21763,8328,64,23945,57796,45525,2557,1500,8693,257,21793,46213,513]

theorem envBound35262 : H12AffineFastState.Bounded env35262 := by
  intro p hp
  have h : env35262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35261_35262 : H12AffineEnvironment.transform 17 2557 env35261 = env35262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env35261 == env35262) = true)

theorem identity35262 : scanCanonicalize (H12AffineFastState.compose env35262 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound35262 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env35263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,13508,2557,1025,1,4160,8573,29893,21763,8328,64,23945,25028,12757,2557,1500,8693,257,21793,13445,513]

theorem envBound35263 : H12AffineFastState.Bounded env35263 := by
  intro p hp
  have h : env35263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35262_35263 : H12AffineEnvironment.transform 14 0 env35262 = env35263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env35262 == env35263) = true)

theorem identity35263 : scanCanonicalize (H12AffineFastState.compose env35263 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35263 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env35264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,342,5528,2557,1025,1,4160,33,21913,21763,468,64,23945,16536,4233,2557,1500,169,257,21793,5593,513]

theorem envBound35264 : H12AffineFastState.Bounded env35264 := by
  intro p hp
  have h : env35264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35263_35264 : H12AffineEnvironment.transform 12 348 env35263 = env35264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35263 == env35264) = true)

theorem identity35264 : scanCanonicalize (H12AffineFastState.compose env35264 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound35264 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,0,342,5528,2557,1025,1,4160,33,1417,1299,468,64,3481,4232,4233,2557,1500,169,257,1329,5593,513]

theorem envBound35265 : H12AffineFastState.Bounded env35265 := by
  intro p hp
  have h : env35265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35264_35265 : H12AffineEnvironment.transform 13 4112 env35264 = env35265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env35264 == env35265) = true)

theorem identity35265 : scanCanonicalize (H12AffineFastState.compose env35265 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound35265 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35266 : List Nat := [2,4,8,16,32,64,128,236,512,1024,2048,4096,176,4112,0,186,5236,2065,1025,1,4160,33,1125,1279,56,64,3189,4232,4233,2065,1072,169,237,1245,5173,513]

theorem envBound35266 : H12AffineFastState.Bounded env35266 := by
  intro p hp
  have h : env35266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35265_35266 : H12AffineEnvironment.transform 7 236 env35265 = env35266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env35265 == env35266) = true)

theorem identity35266 : scanCanonicalize (H12AffineFastState.compose env35266 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound35266 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35267 : List Nat := [2,4,8,16,32,64,128,236,512,116,2048,4096,176,4112,0,186,4096,2065,117,1,4160,33,17,139,56,64,2049,4232,4233,2065,68,169,237,169,4161,513]

theorem envBound35267 : H12AffineFastState.Bounded env35267 := by
  intro p hp
  have h : env35267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35266_35267 : H12AffineEnvironment.transform 9 116 env35266 = env35267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env35266 == env35267) = true)

theorem identity35267 : scanCanonicalize (H12AffineFastState.compose env35267 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2123) := by decide +kernel

theorem selectedBound35267 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35268 : List Nat := [2,4,8,16,32,64,128,236,512,116,2048,2123,176,2139,0,186,2123,2065,117,1,2059,33,17,139,56,64,2049,2243,2242,2065,68,169,237,169,2058,513]

theorem envBound35268 : H12AffineFastState.Bounded env35268 := by
  intro p hp
  have h : env35268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1