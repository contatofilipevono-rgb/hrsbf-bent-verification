import H12CloudChart1Data200

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env50922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,4161,62708,120014,16777216,8328,64,16959643,16880844,102878,212079,16797918,16875893,256,16777250,16834951,16873224]

theorem envBound50922 : H12AffineFastState.Bounded env50922 := by
  intro p hp
  have h : env50922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50899_50922 : H12AffineEnvironment.transform 17 10401 env50899 = env50922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env50899 == env50922) = true)

def env50923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62588,119878,16777216,8192,64,16959507,16880708,102742,212079,16797782,16875893,256,16777250,16834831,16873224]

theorem envBound50923 : H12AffineFastState.Bounded env50923 := by
  intro p hp
  have h : env50923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50922_50923 : H12AffineEnvironment.transform 6 8 env50922 = env50923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50922 == env50923) = true)

theorem identity50923 : scanCanonicalize (H12AffineFastState.compose env50923 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50923 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,4161,21793,95515,16777216,8192,64,16935246,16856345,77835,212079,16797782,16850984,256,16777250,16793682,16873224]

theorem envBound50924 : H12AffineFastState.Bounded env50924 := by
  intro p hp
  have h : env50924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50923_50924 : H12AffineEnvironment.transform 14 8541 env50923 = env50924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50923 == env50924) = true)

theorem identity50924 : scanCanonicalize (H12AffineFastState.compose env50924 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound50924 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,4161,21793,95515,95497,8192,64,203847,16400,77835,212079,75103,21793,256,95531,79195,513]

theorem envBound50925 : H12AffineFastState.Bounded env50925 := by
  intro p hp
  have h : env50925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50924_50925 : H12AffineEnvironment.transform 23 95497 env50924 = env50925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env50924 == env50925) = true)

theorem identity50925 : scanCanonicalize (H12AffineFastState.compose env50925 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50925 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10281,1024,8540,4161,21793,95515,95497,8192,64,31836,16400,77835,23668,75103,21793,256,95531,79195,513]

theorem envBound50926 : H12AffineFastState.Bounded env50926 := by
  intro p hp
  have h : env50926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50925_50926 : H12AffineEnvironment.transform 16 90139 env50925 = env50926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50925 == env50926) = true)

theorem identity50926 : scanCanonicalize (H12AffineFastState.compose env50926 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound50926 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28699,4096,10281,1024,8540,4161,21793,1280,1298,8192,64,31836,16400,16400,23668,21828,21793,256,1328,17728,513]

theorem envBound50927 : H12AffineFastState.Bounded env50927 := by
  intro p hp
  have h : env50927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50926_50927 : H12AffineEnvironment.transform 15 28699 env50926 = env50927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env50926 == env50927) = true)

theorem identity50927 : scanCanonicalize (H12AffineFastState.compose env50927 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 10509) := by decide +kernel

theorem selectedBound50927 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env50928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10509,8541,6422,4096,10281,1024,8540,4161,15404,1280,1298,8192,64,5457,10525,10525,13689,15433,15404,256,1328,11341,513]

theorem envBound50928 : H12AffineFastState.Bounded env50928 := by
  intro p hp
  have h : env50928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50927_50928 : H12AffineEnvironment.transform 13 10509 env50927 = env50928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10509 env50927 == env50928) = true)

def env50929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119879,16777216,8193,64,16959506,16880709,102743,212079,16797783,16875893,256,16777250,16834830,16873224]

theorem envBound50929 : H12AffineFastState.Bounded env50929 := by
  intro p hp
  have h : env50929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50922_50929 : H12AffineEnvironment.transform 6 9 env50922 = env50929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50922 == env50929) = true)

def env50930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119879,95496,8193,64,245018,57677,102743,212079,75103,62589,256,95530,103430,512]

theorem envBound50930 : H12AffineFastState.Bounded env50930 := by
  intro p hp
  have h : env50930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50929_50930 : H12AffineEnvironment.transform 23 95496 env50929 = env50930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env50929 == env50930) = true)

theorem identity50930 : scanCanonicalize (H12AffineFastState.compose env50930 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound50930 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62589,41292,3,8193,64,182289,57677,58460,149860,20564,62589,256,33,57613,512]

theorem envBound50931 : H12AffineFastState.Bounded env50931 := by
  intro p hp
  have h : env50931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50930_50931 : H12AffineEnvironment.transform 15 29963 env50930 = env50931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env50930 == env50931) = true)

theorem identity50931 : scanCanonicalize (H12AffineFastState.compose env50931 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58381) := by decide +kernel

theorem selectedBound50931 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env50932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29963,58381,10280,1024,32769,4161,62589,41292,3,8193,64,11292,57677,58460,44393,20564,62589,256,33,57613,512]

theorem envBound50932 : H12AffineFastState.Bounded env50932 := by
  intro p hp
  have h : env50932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50931_50932 : H12AffineEnvironment.transform 16 58381 env50931 = env50932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58381 env50931 == env50932) = true)

theorem identity50932 : scanCanonicalize (H12AffineFastState.compose env50932 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22805) := by decide +kernel

theorem selectedBound50932 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env50933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,22805,29963,15640,10280,1024,22804,4161,11624,30809,3,8193,64,11292,14424,15689,29820,20564,11624,256,33,14360,512]

theorem envBound50933 : H12AffineFastState.Bounded env50933 := by
  intro p hp
  have h : env50933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50932_50933 : H12AffineEnvironment.transform 14 22805 env50932 = env50933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22805 env50932 == env50933) = true)

theorem identity50933 : scanCanonicalize (H12AffineFastState.compose env50933 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound50933 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env50934 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,22805,28746,14425,10280,321,22804,4161,10281,30809,3,8193,64,10589,14424,14344,28989,20564,10281,256,33,14360,512]

theorem envBound50934 : H12AffineFastState.Bounded env50934 := by
  intro p hp
  have h : env50934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50933_50934 : H12AffineEnvironment.transform 9 321 env50933 = env50934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env50933 == env50934) = true)

theorem identity50934 : scanCanonicalize (H12AffineFastState.compose env50934 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50934 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env50935 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,8192,16384,18693,24666,10313,10280,321,18692,81,10281,26697,3,8193,64,10589,10312,10264,24877,16452,10281,256,33,10248,512]

theorem envBound50935 : H12AffineFastState.Bounded env50935 := by
  intro p hp
  have h : env50935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50934_50935 : H12AffineEnvironment.transform 11 16 env50934 = env50935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50934 == env50935) = true)

theorem identity50935 : scanCanonicalize (H12AffineFastState.compose env50935 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 10329) := by decide +kernel

theorem selectedBound50935 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env50936 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,8192,10329,8540,2051,10313,10280,321,8541,81,10281,16,3,8193,64,10589,10312,10264,2420,10269,10281,256,33,10248,512]

theorem envBound50936 : H12AffineFastState.Bounded env50936 := by
  intro p hp
  have h : env50936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50935_50936 : H12AffineEnvironment.transform 13 10329 env50935 = env50936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10329 env50935 == env50936) = true)

theorem identity50936 : scanCanonicalize (H12AffineFastState.compose env50936 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound50936 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50937 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,16,2056,81,2388,2051,65,32,321,2389,81,33,16,3,2057,64,341,64,16,2420,21,33,256,33,0,512]

theorem envBound50937 : H12AffineFastState.Bounded env50937 := by
  intro p hp
  have h : env50937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50936_50937 : H12AffineEnvironment.transform 12 2056 env50936 = env50937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env50936 == env50937) = true)

theorem identity50937 : scanCanonicalize (H12AffineFastState.compose env50937 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound50937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50938 : List Nat := [2,4,8,16,32,64,9,256,512,321,32,16,40,81,372,35,65,32,321,373,81,33,16,3,41,64,341,64,16,340,21,33,256,33,0,512]

theorem envBound50938 : H12AffineFastState.Bounded env50938 := by
  intro p hp
  have h : env50938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50937_50938 : H12AffineEnvironment.transform 10 32 env50937 = env50938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env50937 == env50938) = true)

theorem identity50938 : scanCanonicalize (H12AffineFastState.compose env50938 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound50938 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50939 : List Nat := [2,4,8,16,32,64,9,256,90,321,32,16,40,81,372,35,65,32,321,373,81,33,16,3,41,64,341,64,16,340,21,33,256,33,0,90]

theorem envBound50939 : H12AffineFastState.Bounded env50939 := by
  intro p hp
  have h : env50939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50938_50939 : H12AffineEnvironment.transform 8 90 env50938 = env50939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env50938 == env50939) = true)

theorem identity50939 : scanCanonicalize (H12AffineFastState.compose env50939 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50939 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50940 : List Nat := [2,4,8,16,0,64,9,256,90,321,0,16,8,81,340,3,65,0,321,341,81,1,16,3,9,64,341,64,16,340,21,1,256,1,0,90]

theorem envBound50940 : H12AffineFastState.Bounded env50940 := by
  intro p hp
  have h : env50940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50939_50940 : H12AffineEnvironment.transform 4 0 env50939 = env50940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50939 == env50940) = true)

theorem identity50940 : scanCanonicalize (H12AffineFastState.compose env50940 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound50940 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50941 : List Nat := [2,4,8,16,0,27,9,256,1,282,0,16,8,10,271,3,26,0,282,270,10,1,16,3,9,27,270,27,16,271,21,1,256,1,0,1]

theorem envBound50941 : H12AffineFastState.Bounded env50941 := by
  intro p hp
  have h : env50941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50940_50941 : H12AffineEnvironment.transform 5 27 env50940 = env50941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env50940 == env50941) = true)

theorem identity50941 : scanCanonicalize (H12AffineFastState.compose env50941 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50941 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50942 : List Nat := [2,4,8,0,0,11,9,256,1,266,0,0,8,10,271,3,10,0,266,270,10,1,0,3,9,11,270,11,0,271,5,1,256,1,0,1]

theorem envBound50942 : H12AffineFastState.Bounded env50942 := by
  intro p hp
  have h : env50942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50941_50942 : H12AffineEnvironment.transform 3 0 env50941 = env50942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50941 == env50942) = true)

theorem identity50942 : scanCanonicalize (H12AffineFastState.compose env50942 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound50942 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50943 : List Nat := [0,4,8,0,0,9,9,256,1,264,0,0,8,8,269,1,8,0,264,268,8,1,0,1,9,9,268,9,0,269,5,1,256,1,0,1]

theorem envBound50943 : H12AffineFastState.Bounded env50943 := by
  intro p hp
  have h : env50943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50942_50943 : H12AffineEnvironment.transform 0 0 env50942 = env50943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env50942 == env50943) = true)

theorem identity50943 : scanCanonicalize (H12AffineFastState.compose env50943 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50943 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50944 : List Nat := [0,4,8,0,0,9,9,4,1,12,0,0,8,8,9,1,8,0,12,8,8,1,0,1,9,9,8,9,0,9,5,1,4,1,0,1]

theorem envBound50944 : H12AffineFastState.Bounded env50944 := by
  intro p hp
  have h : env50944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50943_50944 : H12AffineEnvironment.transform 7 4 env50943 = env50944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50943 == env50944) = true)

theorem identity50944 : scanCanonicalize (H12AffineFastState.compose env50944 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound50944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50945 : List Nat := [0,4,4,0,0,5,5,4,1,0,0,0,4,4,5,1,4,0,0,4,4,1,0,1,5,5,4,5,0,5,5,1,4,1,0,1]

theorem envBound50945 : H12AffineFastState.Bounded env50945 := by
  intro p hp
  have h : env50945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50944_50945 : H12AffineEnvironment.transform 2 4 env50944 = env50945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env50944 == env50945) = true)

def env50946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119879,95497,8193,64,245019,57676,102743,212079,75102,62588,256,95531,103431,513]

theorem envBound50946 : H12AffineFastState.Bounded env50946 := by
  intro p hp
  have h : env50946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50929_50946 : H12AffineEnvironment.transform 23 95497 env50929 = env50946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env50929 == env50946) = true)

theorem identity50946 : scanCanonicalize (H12AffineFastState.compose env50946 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50946 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env50947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,4161,21793,95515,95497,8193,64,203847,16400,77835,212079,75102,21792,256,95531,79195,513]

theorem envBound50947 : H12AffineFastState.Bounded env50947 := by
  intro p hp
  have h : env50947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50946_50947 : H12AffineEnvironment.transform 14 8540 env50946 = env50947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50946 == env50947) = true)

theorem identity50947 : scanCanonicalize (H12AffineFastState.compose env50947 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound50947 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env50948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,65536,131072,10280,1024,8541,4161,113,73803,73817,8193,64,203847,5440,77835,212079,75102,112,256,73851,79195,513]

theorem envBound50948 : H12AffineFastState.Bounded env50948 := by
  intro p hp
  have h : env50948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50947_50948 : H12AffineEnvironment.transform 13 5456 env50947 = env50948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env50947 == env50948) = true)

theorem identity50948 : scanCanonicalize (H12AffineFastState.compose env50948 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50948 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50949 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,65536,131072,10280,1024,8461,4113,33,73755,73737,8193,16,203799,5392,77835,212031,75022,32,256,73771,79115,513]

theorem envBound50949 : H12AffineFastState.Bounded env50949 := by
  intro p hp
  have h : env50949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50948_50949 : H12AffineEnvironment.transform 5 16 env50948 = env50949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50948 == env50949) = true)

theorem identity50949 : scanCanonicalize (H12AffineFastState.compose env50949 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound50949 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50950 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,65536,70678,10280,1024,8461,4113,33,73755,73737,8193,16,2049,5392,77835,10281,75022,32,256,73771,79115,513]

theorem envBound50950 : H12AffineFastState.Bounded env50950 := by
  intro p hp
  have h : env50950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50949_50950 : H12AffineEnvironment.transform 16 70678 env50949 = env50950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env50949 == env50950) = true)

theorem identity50950 : scanCanonicalize (H12AffineFastState.compose env50950 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50950 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50951 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8203,13341,10280,1024,8461,4113,33,16,2,8193,16,2049,5392,4096,10281,1285,32,256,32,5376,513]

theorem envBound50951 : H12AffineFastState.Bounded env50951 := by
  intro p hp
  have h : env50951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50950_50951 : H12AffineEnvironment.transform 15 8203 env50950 = env50951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50950 == env50951) = true)

def env50952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411541,2213007,16777216,8328,64,16959642,18973837,102878,2557071,18890911,17148373,256,16777250,16834951,18966345]

theorem envBound50952 : H12AffineFastState.Bounded env50952 := by
  intro p hp
  have h : env50952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50855_50952 : H12AffineEnvironment.transform 21 2411541 env50855 = env50952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411541 env50855 == env50952) = true)

theorem identity50952 : scanCanonicalize (H12AffineFastState.compose env50952 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound50952 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env50953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,16777216,8328,64,16959642,16793618,102878,442384,16876544,17148373,256,16777250,16834951,16819158]

theorem envBound50953 : H12AffineFastState.Bounded env50953 := by
  intro p hp
  have h : env50953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50952_50953 : H12AffineEnvironment.transform 20 115871 env50952 = env50953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env50952 == env50953) = true)

def env50954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,95496,8328,64,245138,79130,102878,442384,61704,318685,256,95530,103567,120542]

theorem envBound50954 : H12AffineFastState.Bounded env50954 := by
  intro p hp
  have h : env50954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50953_50954 : H12AffineEnvironment.transform 23 95496 env50953 = env50954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env50953 == env50954) = true)

def env50955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,329730,16,95496,8192,64,245018,79130,102742,442384,61704,318549,256,95530,103431,120406]

theorem envBound50955 : H12AffineFastState.Bounded env50955 := by
  intro p hp
  have h : env50955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50954_50955 : H12AffineEnvironment.transform 6 8 env50954 = env50955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50954 == env50955) = true)

theorem identity50955 : scanCanonicalize (H12AffineFastState.compose env50955 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50955 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,91466,329730,16,95496,8192,64,203847,79130,77835,418125,20565,294152,256,95530,79194,96011]

theorem envBound50956 : H12AffineFastState.Bounded env50956 := by
  intro p hp
  have h : env50956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50955_50956 : H12AffineEnvironment.transform 14 8541 env50955 = env50956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50955 == env50956) = true)

def env50957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1024,8540,91466,329730,16,95496,8192,64,89175,79130,77835,270685,20565,294152,256,95530,79194,96011]

theorem envBound50957 : H12AffineFastState.Bounded env50957 := by
  intro p hp
  have h : env50957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50956_50957 : H12AffineEnvironment.transform 16 16400 env50956 = env50957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50956 == env50957) = true)

theorem identity50957 : scanCanonicalize (H12AffineFastState.compose env50957 (packedSelected [0,1,7,8,9,12,14,16,19,22,38] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound50957 : packedSelected [0,1,7,8,9,12,14,16,19,22,38] rootPS < 2^1333 := by decide +kernel

def env50958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29822,16400,262144,1024,8540,4404,294012,16,374,8192,64,10281,16740,17525,270685,20565,294152,256,340,16676,885]

theorem envBound50958 : H12AffineFastState.Bounded env50958 := by
  intro p hp
  have h : env50958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50957_50958 : H12AffineEnvironment.transform 15 29822 env50957 = env50958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env50957 == env50958) = true)

theorem identity50958 : scanCanonicalize (H12AffineFastState.compose env50958 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50958 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env50959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8575,5393,262144,1024,8540,4404,272765,16,374,8192,64,10281,5221,4468,270685,1364,272393,256,340,5157,885]

theorem envBound50959 : H12AffineFastState.Bounded env50959 := by
  intro p hp
  have h : env50959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50958_50959 : H12AffineEnvironment.transform 13 5377 env50958 = env50959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50958 == env50959) = true)

theorem identity50959 : scanCanonicalize (H12AffineFastState.compose env50959 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50959 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50960 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8233,8203,5221,262144,1024,8232,4160,272393,16,2,8192,64,10281,5221,4096,270377,1056,272393,116,32,5157,513]

theorem envBound50960 : H12AffineFastState.Bounded env50960 := by
  intro p hp
  have h : env50960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50959_50960 : H12AffineEnvironment.transform 7 116 env50959 = env50960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50959 == env50960) = true)

theorem identity50960 : scanCanonicalize (H12AffineFastState.compose env50960 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound50960 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50961 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5237,8233,8203,5221,10280,1024,8232,4160,33,16,2,8192,64,10281,5221,4096,2049,1056,33,116,32,5157,513]

theorem envBound50961 : H12AffineFastState.Bounded env50961 := by
  intro p hp
  have h : env50961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50960_50961 : H12AffineEnvironment.transform 17 10280 env50960 = env50961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50960 == env50961) = true)

theorem identity50961 : scanCanonicalize (H12AffineFastState.compose env50961 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound50961 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50962 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1,8192,1140,8233,8203,1124,10280,1024,8232,65,33,16,2,8192,64,10281,1124,1,2049,1056,33,116,32,1060,513]

theorem envBound50962 : H12AffineFastState.Bounded env50962 := by
  intro p hp
  have h : env50962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50961_50962 : H12AffineEnvironment.transform 11 1 env50961 = env50962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50961 == env50962) = true)

theorem identity50962 : scanCanonicalize (H12AffineFastState.compose env50962 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2681) := by decide +kernel

theorem selectedBound50962 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50963 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1,2681,1140,2640,2674,1124,593,1024,2641,65,33,16,2,2681,64,592,1124,1,2049,1056,33,116,32,1060,513]

theorem envBound50963 : H12AffineFastState.Bounded env50963 := by
  intro p hp
  have h : env50963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50962_50963 : H12AffineEnvironment.transform 12 2681 env50962 = env50963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2681 env50962 == env50963) = true)

theorem identity50963 : scanCanonicalize (H12AffineFastState.compose env50963 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 593) := by decide +kernel

theorem selectedBound50963 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50964 : List Nat := [2,4,8,16,32,64,8,116,512,1024,593,1,40,1140,1,35,1124,593,1024,0,65,33,16,2,40,64,592,1124,1,592,1056,33,116,32,1060,513]

theorem envBound50964 : H12AffineFastState.Bounded env50964 := by
  intro p hp
  have h : env50964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50963_50964 : H12AffineEnvironment.transform 10 593 env50963 = env50964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 593 env50963 == env50964) = true)

theorem identity50964 : scanCanonicalize (H12AffineFastState.compose env50964 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound50964 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50965 : List Nat := [2,4,8,16,32,64,8,116,512,564,593,1,40,576,1,35,592,593,564,0,65,33,16,2,40,64,592,592,1,592,532,33,116,32,528,513]

theorem envBound50965 : H12AffineFastState.Bounded env50965 := by
  intro p hp
  have h : env50965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50964_50965 : H12AffineEnvironment.transform 9 564 env50964 = env50965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env50964 == env50965) = true)

theorem identity50965 : scanCanonicalize (H12AffineFastState.compose env50965 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound50965 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50966 : List Nat := [2,4,8,16,32,64,8,116,0,52,81,1,40,64,1,35,80,81,52,0,65,33,16,2,40,64,80,80,1,80,20,33,116,32,16,1]

theorem envBound50966 : H12AffineFastState.Bounded env50966 := by
  intro p hp
  have h : env50966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50965_50966 : H12AffineEnvironment.transform 8 0 env50965 = env50966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env50965 == env50966) = true)

theorem identity50966 : scanCanonicalize (H12AffineFastState.compose env50966 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50967 : List Nat := [2,4,8,1,32,64,8,101,0,37,64,1,40,64,1,35,65,64,37,0,65,33,1,2,40,64,65,65,1,65,5,33,101,32,1,1]

theorem envBound50967 : H12AffineFastState.Bounded env50967 := by
  intro p hp
  have h : env50967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50966_50967 : H12AffineEnvironment.transform 3 1 env50966 = env50967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50966 == env50967) = true)

theorem identity50967 : scanCanonicalize (H12AffineFastState.compose env50967 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound50967 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50968 : List Nat := [2,4,8,1,32,0,8,37,0,37,0,1,40,0,1,35,1,0,37,0,1,33,1,2,40,0,1,1,1,1,5,33,37,32,1,1]

theorem envBound50968 : H12AffineFastState.Bounded env50968 := by
  intro p hp
  have h : env50968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50967_50968 : H12AffineEnvironment.transform 5 0 env50967 = env50968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env50967 == env50968) = true)

theorem identity50968 : scanCanonicalize (H12AffineFastState.compose env50968 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50969 : List Nat := [2,4,8,1,0,0,8,5,0,5,0,1,8,0,1,3,1,0,5,0,1,1,1,2,8,0,1,1,1,1,5,1,5,0,1,1]

theorem envBound50969 : H12AffineFastState.Bounded env50969 := by
  intro p hp
  have h : env50969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50968_50969 : H12AffineEnvironment.transform 4 0 env50968 = env50969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50968 == env50969) = true)

def env50970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,91466,329730,16,95496,8192,64,89174,79130,77835,270684,20565,294152,256,95530,79194,96011]

theorem envBound50970 : H12AffineFastState.Bounded env50970 := by
  intro p hp
  have h : env50970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50956_50970 : H12AffineEnvironment.transform 16 16401 env50956 = env50970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50956 == env50970) = true)

theorem identity50970 : scanCanonicalize (H12AffineFastState.compose env50970 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound50970 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env50971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,16401,262144,1024,8540,4160,294152,16,2,8192,64,10588,16400,17665,270684,20565,294152,256,32,16464,513]

theorem envBound50971 : H12AffineFastState.Bounded env50971 := by
  intro p hp
  have h : env50971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50970_50971 : H12AffineEnvironment.transform 15 29962 env50970 = env50971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env50970 == env50971) = true)

theorem identity50971 : scanCanonicalize (H12AffineFastState.compose env50971 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound50971 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29962,16401,22885,1024,8540,4160,9325,16,2,8192,64,10588,16400,17665,30777,20565,9325,256,32,16464,513]

theorem envBound50972 : H12AffineFastState.Bounded env50972 := by
  intro p hp
  have h : env50972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50971_50972 : H12AffineEnvironment.transform 17 22885 env50971 = env50972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env50971 == env50972) = true)

theorem identity50972 : scanCanonicalize (H12AffineFastState.compose env50972 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50972 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50973 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,8541,28699,16401,22885,273,8540,4160,8572,16,2,8192,64,10588,16400,16400,30777,20565,8572,256,32,16464,513]

theorem envBound50973 : H12AffineFastState.Bounded env50973 := by
  intro p hp
  have h : env50973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50972_50973 : H12AffineEnvironment.transform 9 273 env50972 = env50973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50972 == env50973) = true)

theorem identity50973 : scanCanonicalize (H12AffineFastState.compose env50973 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound50973 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env50974 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8541,8202,4096,2420,273,8540,4160,8572,16,2,8192,64,10588,4097,4097,10280,68,8572,256,32,4161,513]

theorem envBound50974 : H12AffineFastState.Bounded env50974 := by
  intro p hp
  have h : env50974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50973_50974 : H12AffineEnvironment.transform 13 4113 env50973 = env50974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env50973 == env50974) = true)

theorem identity50974 : scanCanonicalize (H12AffineFastState.compose env50974 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50974 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50975 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4113,81,262,4096,2420,273,80,4160,112,16,2,268,64,2128,4097,4097,2340,68,112,256,32,4161,513]

theorem envBound50975 : H12AffineFastState.Bounded env50975 := by
  intro p hp
  have h : env50975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50974_50975 : H12AffineEnvironment.transform 12 268 env50974 = env50975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50974 == env50975) = true)

theorem identity50975 : scanCanonicalize (H12AffineFastState.compose env50975 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50975 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50976 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,120,4113,81,114,4096,2048,101,80,4160,112,16,2,120,64,2128,4097,4097,2128,68,112,116,32,4161,513]

theorem envBound50976 : H12AffineFastState.Bounded env50976 := by
  intro p hp
  have h : env50976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50975_50976 : H12AffineEnvironment.transform 7 116 env50975 = env50976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50975 == env50976) = true)

theorem identity50976 : scanCanonicalize (H12AffineFastState.compose env50976 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50976 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env50977 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4113,1,34,4096,2048,53,0,4112,32,16,2,40,16,2048,4097,4097,2048,20,32,36,32,4113,513]

theorem envBound50977 : H12AffineFastState.Bounded env50977 := by
  intro p hp
  have h : env50977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50976_50977 : H12AffineEnvironment.transform 5 16 env50976 = env50977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50976 == env50977) = true)

theorem identity50977 : scanCanonicalize (H12AffineFastState.compose env50977 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound50977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50978 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2096,40,2081,1,34,2096,2048,53,0,2080,32,16,2,40,16,2048,2097,2097,2048,20,32,36,32,2081,513]

theorem envBound50978 : H12AffineFastState.Bounded env50978 := by
  intro p hp
  have h : env50978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50977_50978 : H12AffineEnvironment.transform 11 2096 env50977 = env50978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env50977 == env50978) = true)

theorem identity50978 : scanCanonicalize (H12AffineFastState.compose env50978 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50978 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50979 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,2096,40,2081,1,34,2096,2048,53,0,2080,32,16,2,40,16,2048,2097,2097,2048,20,32,36,32,2081,49]

theorem envBound50979 : H12AffineFastState.Bounded env50979 := by
  intro p hp
  have h : env50979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50978_50979 : H12AffineEnvironment.transform 8 48 env50978 = env50979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50978 == env50979) = true)

def env50980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,329731,16,95496,8193,64,245019,79130,102743,442384,61704,318548,256,95530,103430,120407]

theorem envBound50980 : H12AffineFastState.Bounded env50980 := by
  intro p hp
  have h : env50980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50954_50980 : H12AffineEnvironment.transform 6 9 env50954 = env50980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50954 == env50980) = true)

def env50981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,329731,16,95496,8193,64,130315,79130,102743,294912,61704,318548,256,95530,103430,120407]

theorem envBound50981 : H12AffineFastState.Bounded env50981 := by
  intro p hp
  have h : env50981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50980_50981 : H12AffineEnvironment.transform 16 16400 env50980 = env50981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env50980 == env50981) = true)

def env50982 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,329731,16,95356,8193,64,130175,78958,102435,294912,61564,318548,116,95326,103430,120407]

theorem envBound50982 : H12AffineFastState.Bounded env50982 := by
  intro p hp
  have h : env50982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50981_50982 : H12AffineEnvironment.transform 7 116 env50981 = env50982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50981 == env50982) = true)

theorem identity50982 : scanCanonicalize (H12AffineFastState.compose env50982 (packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound50982 : packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50983 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54358,16400,262144,1024,32769,4160,318549,16,41002,8193,64,10281,57400,17525,294912,61564,318548,116,40968,16464,513]

theorem envBound50983 : H12AffineFastState.Bounded env50983 := by
  intro p hp
  have h : env50983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50982_50983 : H12AffineEnvironment.transform 15 54358 env50982 = env50983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env50982 == env50983) = true)

theorem identity50983 : scanCanonicalize (H12AffineFastState.compose env50983 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound50983 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env50984 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54358,16400,43048,1024,32769,4160,29821,16,41002,8193,64,10281,57400,17525,10280,61564,29820,116,40968,16464,513]

theorem envBound50984 : H12AffineFastState.Bounded env50984 := by
  intro p hp
  have h : env50984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50983_50984 : H12AffineEnvironment.transform 17 43048 env50983 = env50984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env50983 == env50984) = true)

theorem identity50984 : scanCanonicalize (H12AffineFastState.compose env50984 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound50984 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env50985 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,8202,16400,23668,1024,29789,4160,29821,16,21622,8193,64,10281,5220,17525,10280,1056,29820,116,21588,16464,513]

theorem envBound50985 : H12AffineFastState.Bounded env50985 := by
  intro p hp
  have h : env50985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50984_50985 : H12AffineEnvironment.transform 14 29788 env50984 = env50985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env50984 == env50985) = true)

theorem identity50985 : scanCanonicalize (H12AffineFastState.compose env50985 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50985 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50986 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,16384,21540,114,16400,23668,1024,21541,4160,21509,16,21622,121,64,2129,5220,17525,2128,1056,21508,116,21588,16464,513]

theorem envBound50986 : H12AffineFastState.Bounded env50986 := by
  intro p hp
  have h : env50986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50985_50986 : H12AffineEnvironment.transform 12 120 env50985 = env50986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50985 == env50986) = true)

theorem identity50986 : scanCanonicalize (H12AffineFastState.compose env50986 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50986 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50987 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,4096,120,16384,20496,114,16400,22592,52,20497,4160,20529,16,20546,121,64,2129,4176,16449,2128,20,20528,116,20576,16464,513]

theorem envBound50987 : H12AffineFastState.Bounded env50987 := by
  intro p hp
  have h : env50987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50986_50987 : H12AffineEnvironment.transform 9 52 env50986 = env50987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50986 == env50987) = true)

theorem identity50987 : scanCanonicalize (H12AffineFastState.compose env50987 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound50987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50988 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,80,120,16384,16448,114,16400,18448,52,16449,16,16481,16,16402,121,64,2129,0,16449,2128,20,16480,116,16432,16464,513]

theorem envBound50988 : H12AffineFastState.Bounded env50988 := by
  intro p hp
  have h : env50988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50987_50988 : H12AffineEnvironment.transform 11 80 env50987 = env50988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env50987 == env50988) = true)

theorem identity50988 : scanCanonicalize (H12AffineFastState.compose env50988 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2075) := by decide +kernel

theorem selectedBound50988 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50989 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,80,120,2075,2139,114,2059,11,52,2138,16,2170,16,2057,121,64,2129,0,2138,2128,20,2171,116,2091,2123,513]

theorem envBound50989 : H12AffineFastState.Bounded env50989 := by
  intro p hp
  have h : env50989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50988_50989 : H12AffineEnvironment.transform 13 2075 env50988 = env50989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2075 env50988 == env50989) = true)

theorem identity50989 : scanCanonicalize (H12AffineFastState.compose env50989 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50989 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50990 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,0,40,2075,2059,34,2059,11,52,2058,16,2090,16,2057,41,16,2049,0,2058,2048,20,2091,36,2091,2075,513]

theorem envBound50990 : H12AffineFastState.Bounded env50990 := by
  intro p hp
  have h : env50990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50989_50990 : H12AffineEnvironment.transform 5 16 env50989 = env50990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50989 == env50990) = true)

theorem identity50990 : scanCanonicalize (H12AffineFastState.compose env50990 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound50990 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50991 : List Nat := [2,4,8,16,32,16,9,36,512,52,48,0,40,43,59,34,59,11,52,58,16,26,16,57,41,16,49,0,58,48,20,27,36,27,43,513]

theorem envBound50991 : H12AffineFastState.Bounded env50991 := by
  intro p hp
  have h : env50991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50990_50991 : H12AffineEnvironment.transform 10 48 env50990 = env50991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env50990 == env50991) = true)

theorem identity50991 : scanCanonicalize (H12AffineFastState.compose env50991 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound50991 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env50992 : List Nat := [2,2,8,16,32,16,9,34,512,50,48,0,40,43,59,34,59,11,50,58,16,26,16,57,41,16,49,0,58,48,18,27,34,27,43,513]

theorem envBound50992 : H12AffineFastState.Bounded env50992 := by
  intro p hp
  have h : env50992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50991_50992 : H12AffineEnvironment.transform 1 2 env50991 = env50992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env50991 == env50992) = true)

theorem identity50992 : scanCanonicalize (H12AffineFastState.compose env50992 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound50992 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50993 : List Nat := [2,2,8,16,26,16,9,24,512,8,10,0,18,17,1,24,1,11,8,0,16,26,16,3,19,16,11,0,0,10,18,27,24,27,17,513]

theorem envBound50993 : H12AffineFastState.Bounded env50993 := by
  intro p hp
  have h : env50993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50992_50993 : H12AffineEnvironment.transform 4 26 env50992 = env50993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env50992 == env50993) = true)

theorem identity50993 : scanCanonicalize (H12AffineFastState.compose env50993 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound50993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50994 : List Nat := [2,2,8,16,26,16,9,24,8,8,10,0,18,17,1,24,1,11,8,0,16,26,16,3,19,16,11,0,0,10,18,27,24,27,17,9]

theorem envBound50994 : H12AffineFastState.Bounded env50994 := by
  intro p hp
  have h : env50994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50993_50994 : H12AffineEnvironment.transform 8 8 env50993 = env50994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env50993 == env50994) = true)

theorem identity50994 : scanCanonicalize (H12AffineFastState.compose env50994 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50994 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env50995 : List Nat := [2,2,2,16,16,16,3,18,2,2,0,0,18,17,1,18,1,1,2,0,16,16,16,3,19,16,1,0,0,0,18,17,18,17,17,3]

theorem envBound50995 : H12AffineFastState.Bounded env50995 := by
  intro p hp
  have h : env50995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50994_50995 : H12AffineEnvironment.transform 2 2 env50994 = env50995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50994 == env50995) = true)

theorem identity50995 : scanCanonicalize (H12AffineFastState.compose env50995 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50995 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env50996 : List Nat := [2,2,2,1,1,1,3,3,2,2,0,0,3,0,1,3,1,1,2,0,1,1,1,3,2,1,1,0,0,0,3,0,3,0,0,3]

theorem envBound50996 : H12AffineFastState.Bounded env50996 := by
  intro p hp
  have h : env50996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50995_50996 : H12AffineEnvironment.transform 3 1 env50995 = env50996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50995 == env50996) = true)

def env50997 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115734,329731,16,95357,8193,64,130174,78959,102434,294912,61565,318548,117,95327,103430,120407]

theorem envBound50997 : H12AffineFastState.Bounded env50997 := by
  intro p hp
  have h : env50997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50981_50997 : H12AffineEnvironment.transform 7 117 env50981 = env50997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50981 == env50997) = true)

theorem identity50997 : scanCanonicalize (H12AffineFastState.compose env50997 (packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 31836) := by decide +kernel

theorem selectedBound50997 : packedSelected [0,1,2,3,5,7,8,9,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50998 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,31836,1024,32769,115734,95327,16,95357,8193,64,130174,78959,102434,64604,61565,40968,117,95327,103430,120407]

theorem envBound50998 : H12AffineFastState.Bounded env50998 := by
  intro p hp
  have h : env50998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50997_50998 : H12AffineEnvironment.transform 17 31836 env50997 = env50998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31836 env50997 == env50998) = true)

theorem identity50998 : scanCanonicalize (H12AffineFastState.compose env50998 (packedSelected [0,1,2,3,5,6,8,10,11,14,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound50998 : packedSelected [0,1,2,3,5,6,8,10,11,14,18,19,27] rootPS < 2^1333 := by decide +kernel

def env50999 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,65536,16400,31836,1024,8232,91199,95327,16,95357,8193,64,89175,78959,77835,23669,20564,33,117,95327,78895,95870]

theorem envBound50999 : H12AffineFastState.Bounded env50999 := by
  intro p hp
  have h : env50999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50998_50999 : H12AffineEnvironment.transform 14 8233 env50998 = env50999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env50998 == env50999) = true)

theorem identity50999 : scanCanonicalize (H12AffineFastState.compose env50999 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50999 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env51000 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,8203,16400,31836,1024,8232,17460,21588,16,21622,8193,64,31836,5220,4096,23669,20564,33,117,21588,5156,22133]

theorem envBound51000 : H12AffineFastState.Bounded env51000 := by
  intro p hp
  have h : env51000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50999_51000 : H12AffineEnvironment.transform 15 8203 env50999 = env51000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50999 == env51000) = true)

theorem identity51000 : scanCanonicalize (H12AffineFastState.compose env51000 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound51000 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env51001 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,8233,8203,13388,2048,1024,8232,12392,8200,16,8234,8193,64,2048,5220,4096,10281,9224,33,117,8200,5156,8745]

theorem envBound51001 : H12AffineFastState.Bounded env51001 := by
  intro p hp
  have h : env51001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51000_51001 : H12AffineEnvironment.transform 13 13404 env51000 = env51001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env51000 == env51001) = true)

theorem identity51001 : scanCanonicalize (H12AffineFastState.compose env51001 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51001 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51002 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,1,35,5220,2048,1024,0,4160,32,16,2,41,64,2048,5220,4096,2049,1056,33,117,32,5156,513]

theorem envBound51002 : H12AffineFastState.Bounded env51002 := by
  intro p hp
  have h : env51002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51001_51002 : H12AffineEnvironment.transform 12 40 env51001 = env51002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51001 == env51002) = true)

theorem identity51002 : scanCanonicalize (H12AffineFastState.compose env51002 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound51002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51003 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,529,40,1637,1,35,1653,2048,1024,0,593,32,16,2,41,64,2048,1653,529,2049,1056,33,117,32,1589,513]

theorem envBound51003 : H12AffineFastState.Bounded env51003 := by
  intro p hp
  have h : env51003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51002_51003 : H12AffineEnvironment.transform 11 529 env51002 = env51003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env51002 == env51003) = true)

def env51004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115734,329731,16,95496,8193,64,130314,79130,102743,294913,61704,318548,256,95530,103430,120407]

theorem envBound51004 : H12AffineFastState.Bounded env51004 := by
  intro p hp
  have h : env51004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50980_51004 : H12AffineEnvironment.transform 16 16401 env50980 = env51004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50980 == env51004) = true)

theorem identity51004 : scanCanonicalize (H12AffineFastState.compose env51004 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound51004 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env51005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,262144,1024,32769,4160,318549,16,41310,8193,64,10588,57676,17665,294913,61704,318548,256,41340,16464,513]

theorem envBound51005 : H12AffineFastState.Bounded env51005 := by
  intro p hp
  have h : env51005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51004_51005 : H12AffineEnvironment.transform 15 54358 env51004 = env51005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env51004 == env51005) = true)

theorem identity51005 : scanCanonicalize (H12AffineFastState.compose env51005 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 64808) := by decide +kernel

theorem selectedBound51005 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env51006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,16401,64808,1024,32769,4160,8573,16,41310,8193,64,10588,57676,17665,32041,61704,8572,256,41340,16464,513]

theorem envBound51006 : H12AffineFastState.Bounded env51006 := by
  intro p hp
  have h : env51006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51005_51006 : H12AffineEnvironment.transform 17 64808 env51005 = env51006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64808 env51005 == env51006) = true)

theorem identity51006 : scanCanonicalize (H12AffineFastState.compose env51006 (packedSelected [1,2,3,4,5,6,8,9,10,14,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51006 : packedSelected [1,2,3,4,5,6,8,9,10,14,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51007 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5392,43049,1024,32769,4160,8573,16,41310,8193,64,10588,46157,4096,10280,41993,8572,256,41340,5457,513]

theorem envBound51007 : H12AffineFastState.Bounded env51007 := by
  intro p hp
  have h : env51007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51006_51007 : H12AffineEnvironment.transform 13 5377 env51006 = env51007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51006 == env51007) = true)

theorem identity51007 : scanCanonicalize (H12AffineFastState.compose env51007 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound51007 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33111,5392,35189,1024,32769,4160,33,16,32770,349,64,2048,38161,4096,2420,34133,32,256,32800,5457,513]

theorem envBound51008 : H12AffineFastState.Bounded env51008 := by
  intro p hp
  have h : env51008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51007_51008 : H12AffineEnvironment.transform 12 348 env51007 = env51008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env51007 == env51008) = true)

theorem identity51008 : scanCanonicalize (H12AffineFastState.compose env51008 (packedSelected [2,3,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51008 : packedSelected [2,3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env51009 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,32768,32802,5221,34816,1024,32769,4160,33,16,32770,40,64,2048,37988,4096,2049,33824,32,117,32800,5156,513]

theorem envBound51009 : H12AffineFastState.Bounded env51009 := by
  intro p hp
  have h : env51009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51008_51009 : H12AffineEnvironment.transform 7 117 env51008 = env51009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51008 == env51009) = true)

theorem identity51009 : scanCanonicalize (H12AffineFastState.compose env51009 (packedSelected [2,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51009 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env51010 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5236,1,35,5221,2049,1024,0,4160,33,16,3,40,64,2048,5221,4096,2049,1057,32,117,33,5156,513]

theorem envBound51010 : H12AffineFastState.Bounded env51010 := by
  intro p hp
  have h : env51010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51009_51010 : H12AffineEnvironment.transform 14 1 env51009 = env51010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51009 == env51010) = true)

def env51011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,329866,16,95497,8328,64,245139,79131,102878,442384,61705,318684,256,95531,103566,120543]

theorem envBound51011 : H12AffineFastState.Bounded env51011 := by
  intro p hp
  have h : env51011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50953_51011 : H12AffineEnvironment.transform 23 95497 env50953 = env51011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env50953 == env51011) = true)

theorem identity51011 : scanCanonicalize (H12AffineFastState.compose env51011 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound51011 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4161,318548,16,41431,8328,64,158029,57797,17664,442384,61705,318684,256,41461,16464,513]

theorem envBound51012 : H12AffineFastState.Bounded env51012 := by
  intro p hp
  have h : env51012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51011_51012 : H12AffineEnvironment.transform 15 54494 env51011 = env51012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env51011 == env51012) = true)

def env51013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,318548,16,41311,8192,64,158029,57677,17664,442384,61705,318548,256,41341,16464,513]

theorem envBound51013 : H12AffineFastState.Bounded env51013 := by
  intro p hp
  have h : env51013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51012_51013 : H12AffineEnvironment.transform 6 8 env51012 = env51013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51012 == env51013) = true)

theorem identity51013 : scanCanonicalize (H12AffineFastState.compose env51013 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51013 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,262144,1024,8540,4161,294153,16,2,8192,64,158029,16400,17664,418125,20564,294153,256,32,16464,513]

theorem envBound51014 : H12AffineFastState.Bounded env51014 := by
  intro p hp
  have h : env51014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51013_51014 : H12AffineEnvironment.transform 14 8541 env51013 = env51014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51013 == env51014) = true)

theorem identity51014 : scanCanonicalize (H12AffineFastState.compose env51014 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound51014 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51015 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,131072,262144,272,8540,4161,292889,16,2,8192,64,158029,16400,16400,418125,20564,292889,256,32,16464,513]

theorem envBound51015 : H12AffineFastState.Bounded env51015 := by
  intro p hp
  have h : env51015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51014_51015 : H12AffineEnvironment.transform 9 272 env51014 = env51015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env51014 == env51015) = true)

theorem identity51015 : scanCanonicalize (H12AffineFastState.compose env51015 (packedSelected [9,14,22] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound51015 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env51016 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,4096,262144,272,8540,4161,292889,16,2,8192,64,31053,16400,16400,291149,20564,292889,256,32,16464,513]

theorem envBound51016 : H12AffineFastState.Bounded env51016 := by
  intro p hp
  have h : env51016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51015_51016 : H12AffineEnvironment.transform 16 4096 env51015 = env51016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env51015 == env51016) = true)

theorem identity51016 : scanCanonicalize (H12AffineFastState.compose env51016 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22885) := by decide +kernel

theorem selectedBound51016 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51017 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,4096,22885,272,8540,4161,8572,16,2,8192,64,31053,16400,16400,10280,20564,8572,256,32,16464,513]

theorem envBound51017 : H12AffineFastState.Bounded env51017 := by
  intro p hp
  have h : env51017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51016_51017 : H12AffineEnvironment.transform 17 22885 env51016 = env51017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22885 env51016 == env51017) = true)

theorem identity51017 : scanCanonicalize (H12AffineFastState.compose env51017 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound51017 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env51018 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12573,8541,262,4096,10360,272,8540,4161,8572,16,2,8192,64,2128,12557,12557,10280,8521,8572,256,32,12621,513]

theorem envBound51018 : H12AffineFastState.Bounded env51018 := by
  intro p hp
  have h : env51018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51017_51018 : H12AffineEnvironment.transform 13 12573 env51017 = env51018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env51017 == env51018) = true)

theorem identity51018 : scanCanonicalize (H12AffineFastState.compose env51018 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound51018 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env51019 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4404,372,262,4096,2129,272,373,4161,341,16,2,41,64,2128,4388,4388,2049,352,341,256,32,4452,513]

theorem envBound51019 : H12AffineFastState.Bounded env51019 := by
  intro p hp
  have h : env51019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51018_51019 : H12AffineEnvironment.transform 12 41 env51018 = env51019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env51018 == env51019) = true)

theorem identity51019 : scanCanonicalize (H12AffineFastState.compose env51019 (packedSelected [0,1,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound51019 : packedSelected [0,1,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env51020 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,357,41,81,372,262,357,2129,272,373,292,341,16,2,41,64,2128,65,65,2049,352,341,256,32,1,513]

theorem envBound51020 : H12AffineFastState.Bounded env51020 := by
  intro p hp
  have h : env51020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51019_51020 : H12AffineEnvironment.transform 11 357 env51019 = env51020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env51019 == env51020) = true)

theorem identity51020 : scanCanonicalize (H12AffineFastState.compose env51020 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound51020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51021 : List Nat := [2,4,8,16,32,64,8,256,96,272,2048,357,41,81,372,262,357,2129,272,373,292,341,16,2,41,64,2128,65,65,2049,352,341,256,32,1,97]

theorem envBound51021 : H12AffineFastState.Bounded env51021 := by
  intro p hp
  have h : env51021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51020_51021 : H12AffineEnvironment.transform 8 96 env51020 = env51021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env51020 == env51021) = true)

theorem identity51021 : scanCanonicalize (H12AffineFastState.compose env51021 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51021 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51022 : List Nat := [2,4,8,16,32,64,8,37,96,53,2048,64,41,81,81,35,64,2129,53,80,1,112,16,2,41,64,2128,65,65,2049,69,112,37,32,1,97]

theorem envBound51022 : H12AffineFastState.Bounded env51022 := by
  intro p hp
  have h : env51022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51021_51022 : H12AffineEnvironment.transform 7 37 env51021 = env51022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51021 == env51022) = true)

theorem identity51022 : scanCanonicalize (H12AffineFastState.compose env51022 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51022 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51023 : List Nat := [2,4,8,16,32,17,8,37,49,53,2048,17,41,0,0,35,17,2048,53,1,1,33,16,2,41,17,2049,16,16,2049,20,33,37,32,1,48]

theorem envBound51023 : H12AffineFastState.Bounded env51023 := by
  intro p hp
  have h : env51023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51022_51023 : H12AffineEnvironment.transform 5 17 env51022 = env51023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51022 == env51023) = true)

theorem identity51023 : scanCanonicalize (H12AffineFastState.compose env51023 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51023 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51024 : List Nat := [2,4,8,16,32,17,8,37,49,53,1,17,41,0,0,35,17,1,53,1,1,33,16,2,41,17,0,16,16,0,20,33,37,32,1,48]

theorem envBound51024 : H12AffineFastState.Bounded env51024 := by
  intro p hp
  have h : env51024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51023_51024 : H12AffineEnvironment.transform 10 1 env51023 = env51024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51023 == env51024) = true)

def env51025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,318548,16,41310,8193,64,158029,57676,17664,442384,61705,318549,256,41340,16464,513]

theorem envBound51025 : H12AffineFastState.Bounded env51025 := by
  intro p hp
  have h : env51025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51012_51025 : H12AffineEnvironment.transform 6 9 env51012 = env51025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51012 == env51025) = true)

def env51026 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4113,318468,16,41230,8193,16,157981,57628,17664,442384,61705,318469,256,41260,16384,513]

theorem envBound51026 : H12AffineFastState.Bounded env51026 := by
  intro p hp
  have h : env51026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51025_51026 : H12AffineEnvironment.transform 5 16 env51025 = env51026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51025 == env51026) = true)

theorem identity51026 : scanCanonicalize (H12AffineFastState.compose env51026 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound51026 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51027 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,54279,131072,64809,1024,32769,4113,8493,16,41230,8193,16,157981,57628,17664,146745,61705,8492,256,41260,16384,513]

theorem envBound51027 : H12AffineFastState.Bounded env51027 := by
  intro p hp
  have h : env51027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51026_51027 : H12AffineEnvironment.transform 17 64809 env51026 = env51027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env51026 == env51027) = true)

theorem identity51027 : scanCanonicalize (H12AffineFastState.compose env51027 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51027 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env51028 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,131072,43049,1024,32769,4113,8493,16,41230,8193,16,146461,46108,4096,146745,41993,8492,256,41260,5376,513]

theorem envBound51028 : H12AffineFastState.Bounded env51028 := by
  intro p hp
  have h : env51028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51027_51028 : H12AffineEnvironment.transform 13 5376 env51027 = env51028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51027 == env51028) = true)

theorem identity51028 : scanCanonicalize (H12AffineFastState.compose env51028 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound51028 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51029 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,32768,33031,38160,43049,1024,32769,4113,8493,16,41230,8193,16,43277,46108,4096,43049,41993,8492,256,41260,5376,513]

theorem envBound51029 : H12AffineFastState.Bounded env51029 := by
  intro p hp
  have h : env51029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51028_51029 : H12AffineEnvironment.transform 16 38160 env51028 = env51029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env51028 == env51029) = true)

theorem identity51029 : scanCanonicalize (H12AffineFastState.compose env51029 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51029 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51030 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,1,262,5393,10280,1024,0,4113,8493,16,8463,8193,16,10508,13341,4096,10280,9224,8492,256,8493,5376,513]

theorem envBound51030 : H12AffineFastState.Bounded env51030 := by
  intro p hp
  have h : env51030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51029_51030 : H12AffineEnvironment.transform 14 1 env51029 = env51030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51029 == env51030) = true)

theorem identity51030 : scanCanonicalize (H12AffineFastState.compose env51030 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51030 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51031 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1024,0,4113,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound51031 : H12AffineFastState.Bounded env51031 := by
  intro p hp
  have h : env51031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51030_51031 : H12AffineEnvironment.transform 12 268 env51030 = env51031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51030 == env51031) = true)

theorem identity51031 : scanCanonicalize (H12AffineFastState.compose env51031 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51032 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5172,2049,1024,0,4113,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound51032 : H12AffineFastState.Bounded env51032 := by
  intro p hp
  have h : env51032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51031_51032 : H12AffineEnvironment.transform 7 37 env51031 = env51032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51031 == env51032) = true)

def env51033 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,1,35,1028,2049,1024,0,33,33,16,3,40,16,2048,1028,48,2049,1057,32,37,33,1045,513]

theorem envBound51033 : H12AffineFastState.Bounded env51033 := by
  intro p hp
  have h : env51033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51032_51033 : H12AffineEnvironment.transform 11 48 env51032 = env51033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51032 == env51033) = true)

theorem identity51033 : scanCanonicalize (H12AffineFastState.compose env51033 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51034 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,41,32,1,35,49,2049,53,0,33,33,16,3,40,16,2048,49,48,2049,20,32,37,33,32,513]

theorem envBound51034 : H12AffineFastState.Bounded env51034 := by
  intro p hp
  have h : env51034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51033_51034 : H12AffineEnvironment.transform 9 53 env51033 = env51034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51033 == env51034) = true)

theorem identity51034 : scanCanonicalize (H12AffineFastState.compose env51034 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51035 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,48,41,32,1,35,49,2049,53,0,33,33,16,3,40,16,2048,49,48,2049,20,32,37,33,32,11]

theorem envBound51035 : H12AffineFastState.Bounded env51035 := by
  intro p hp
  have h : env51035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51034_51035 : H12AffineEnvironment.transform 8 10 env51034 = env51035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51034 == env51035) = true)

def leafEnv51035 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,48,41,32,1,35,49,2049,53,0,33,33,16,3,20,40,1,16,2048,49,48,2049,20,32,37,33,4,34,32,11,1,33,0]

def active51035 : List Nat := [0,1,2,3,4,10]

def tree51035 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51035 : H12WitnessSearch.Good tree51035 := H12GlobalWitnessIndex.good

theorem leafIdentity51035 : H12AffineFastState.composeSystem env51035 rootObs = leafEnv51035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51035 rootObs == leafEnv51035) = true)

theorem terminalChecked51035 : H12PackedTerminal.terminalCheckFast leafEnv51035 active51035 tree51035 = true := by decide +kernel

def env51036 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,1,35,1029,2049,1024,0,32,33,16,3,40,16,2048,1029,49,2049,1057,32,37,33,1044,513]

theorem envBound51036 : H12AffineFastState.Bounded env51036 := by
  intro p hp
  have h : env51036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51032_51036 : H12AffineEnvironment.transform 11 49 env51032 = env51036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51032 == env51036) = true)

def env51037 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,41,32,1,35,49,2049,52,0,32,33,16,3,40,16,2048,49,49,2049,21,32,37,33,32,513]

theorem envBound51037 : H12AffineFastState.Bounded env51037 := by
  intro p hp
  have h : env51037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51036_51037 : H12AffineEnvironment.transform 9 52 env51036 = env51037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51036 == env51037) = true)

theorem identity51037 : scanCanonicalize (H12AffineFastState.compose env51037 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51038 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,0,1,3,17,2049,20,0,0,1,16,3,8,16,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound51038 : H12AffineFastState.Bounded env51038 := by
  intro p hp
  have h : env51038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51037_51038 : H12AffineEnvironment.transform 4 0 env51037 = env51038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51037 == env51038) = true)

def leafEnv51038 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,9,0,1,3,17,2049,20,0,0,1,16,3,21,8,1,16,2048,17,17,2049,21,0,5,1,4,2,0,513,1,0,0]

def active51038 : List Nat := [0,1,2,3,8,10]

def tree51038 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51038 : H12WitnessSearch.Good tree51038 := H12GlobalWitnessIndex.good

theorem leafIdentity51038 : H12AffineFastState.composeSystem env51038 rootObs = leafEnv51038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51038 rootObs == leafEnv51038) = true)

theorem terminalChecked51038 : H12PackedTerminal.terminalCheckFast leafEnv51038 active51038 tree51038 = true := by decide +kernel

def env51039 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,41,33,1,35,48,2049,53,0,32,33,16,3,40,16,2048,48,49,2049,20,32,37,33,33,513]

theorem envBound51039 : H12AffineFastState.Bounded env51039 := by
  intro p hp
  have h : env51039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51036_51039 : H12AffineEnvironment.transform 9 53 env51036 = env51039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51036 == env51039) = true)

theorem identity51039 : scanCanonicalize (H12AffineFastState.compose env51039 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound51039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51040 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,49,41,33,1,35,48,2049,53,0,32,33,16,3,40,16,2048,48,49,2049,20,32,37,33,33,10]

theorem envBound51040 : H12AffineFastState.Bounded env51040 := by
  intro p hp
  have h : env51040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51039_51040 : H12AffineEnvironment.transform 8 11 env51039 = env51040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env51039 == env51040) = true)

def leafEnv51040 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,49,41,33,1,35,48,2049,53,0,32,33,16,3,20,40,1,16,2048,48,49,2049,20,32,37,33,4,34,33,10,1,32,0]

def active51040 : List Nat := [0,1,2,3,4,10]

def tree51040 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51040 : H12WitnessSearch.Good tree51040 := H12GlobalWitnessIndex.good

theorem leafIdentity51040 : H12AffineFastState.composeSystem env51040 rootObs = leafEnv51040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51040 rootObs == leafEnv51040) = true)

theorem terminalChecked51040 : H12PackedTerminal.terminalCheckFast leafEnv51040 active51040 tree51040 = true := by decide +kernel

def env51041 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4112,318469,16,41231,8193,17,157980,57629,17664,442384,61705,318468,256,41261,16385,513]

theorem envBound51041 : H12AffineFastState.Bounded env51041 := by
  intro p hp
  have h : env51041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51025_51041 : H12AffineEnvironment.transform 5 17 env51025 = env51041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51025 == env51041) = true)

theorem identity51041 : scanCanonicalize (H12AffineFastState.compose env51041 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound51041 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51042 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,54278,131072,2340,1024,32769,4112,54561,16,41231,8193,17,157980,57629,17664,182580,61705,54560,256,41261,16385,513]

theorem envBound51042 : H12AffineFastState.Bounded env51042 := by
  intro p hp
  have h : env51042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51041_51042 : H12AffineEnvironment.transform 17 2340 env51041 = env51042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env51041 == env51042) = true)

theorem identity51042 : scanCanonicalize (H12AffineFastState.compose env51042 (packedSelected [0,1,5,7,8,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51042 : packedSelected [0,1,5,7,8,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env51043 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,131072,2340,1024,32769,4112,32800,16,41231,8193,17,146461,46108,4097,171061,41992,32801,256,41261,5376,513]

theorem envBound51043 : H12AffineFastState.Bounded env51043 := by
  intro p hp
  have h : env51043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51042_51043 : H12AffineEnvironment.transform 13 5377 env51042 = env51043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51042 == env51043) = true)

theorem identity51043 : scanCanonicalize (H12AffineFastState.compose env51043 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound51043 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env51044 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,46393,2340,1024,32769,4112,32800,16,41231,8193,17,35108,46108,4097,10508,41992,32801,256,41261,5376,513]

theorem envBound51044 : H12AffineFastState.Bounded env51044 := by
  intro p hp
  have h : env51044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51043_51044 : H12AffineEnvironment.transform 16 46393 env51043 = env51044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env51043 == env51044) = true)

theorem identity51044 : scanCanonicalize (H12AffineFastState.compose env51044 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound51044 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env51045 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,292,35,13341,2340,1024,293,4112,260,16,8235,8193,17,2048,13624,4097,10508,9516,261,256,8201,5376,513]

theorem envBound51045 : H12AffineFastState.Bounded env51045 := by
  intro p hp
  have h : env51045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51044_51045 : H12AffineEnvironment.transform 14 292 env51044 = env51045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env51044 == env51045) = true)

theorem identity51045 : scanCanonicalize (H12AffineFastState.compose env51045 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51045 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51046 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,292,35,5392,2340,1024,293,4112,260,16,294,268,17,2048,5173,4097,2049,1057,261,256,260,5376,513]

theorem envBound51046 : H12AffineFastState.Bounded env51046 := by
  intro p hp
  have h : env51046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51045_51046 : H12AffineEnvironment.transform 12 269 env51045 = env51046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51045 == env51046) = true)

theorem identity51046 : scanCanonicalize (H12AffineFastState.compose env51046 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51046 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env51047 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,292,35,4389,2340,53,293,4112,260,16,294,268,17,2048,4096,4097,2049,20,261,256,260,4405,513]

theorem envBound51047 : H12AffineFastState.Bounded env51047 := by
  intro p hp
  have h : env51047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51046_51047 : H12AffineEnvironment.transform 9 53 env51046 = env51047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51046 == env51047) = true)

theorem identity51047 : scanCanonicalize (H12AffineFastState.compose env51047 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound51047 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env51048 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2357,269,2049,292,35,2064,2340,53,293,2341,260,16,294,268,17,2048,2357,2356,2049,20,261,256,260,2048,513]

theorem envBound51048 : H12AffineFastState.Bounded env51048 := by
  intro p hp
  have h : env51048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51047_51048 : H12AffineEnvironment.transform 11 2357 env51047 = env51048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env51047 == env51048) = true)

theorem identity51048 : scanCanonicalize (H12AffineFastState.compose env51048 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51048 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51049 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,308,269,0,292,35,17,293,53,293,292,260,16,294,268,17,1,308,309,0,20,261,256,260,1,513]

theorem envBound51049 : H12AffineFastState.Bounded env51049 := by
  intro p hp
  have h : env51049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51048_51049 : H12AffineEnvironment.transform 10 1 env51048 = env51049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51048 == env51049) = true)

theorem identity51049 : scanCanonicalize (H12AffineFastState.compose env51049 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51050 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,16,41,0,0,35,17,1,53,1,0,32,16,2,40,17,1,16,17,0,20,33,36,32,1,513]

theorem envBound51050 : H12AffineFastState.Bounded env51050 := by
  intro p hp
  have h : env51050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51049_51050 : H12AffineEnvironment.transform 7 36 env51049 = env51050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51049 == env51050) = true)

theorem identity51050 : scanCanonicalize (H12AffineFastState.compose env51050 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51051 : List Nat := [2,4,8,16,32,17,9,36,16,53,1,16,41,0,0,35,17,1,53,1,0,32,16,2,40,17,1,16,17,0,20,33,36,32,1,17]

theorem envBound51051 : H12AffineFastState.Bounded env51051 := by
  intro p hp
  have h : env51051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51050_51051 : H12AffineEnvironment.transform 8 16 env51050 = env51051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51050 == env51051) = true)

theorem identity51051 : scanCanonicalize (H12AffineFastState.compose env51051 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51052 : List Nat := [2,4,8,10,32,11,9,36,10,47,1,10,41,0,0,35,11,1,47,1,0,32,10,2,40,11,1,10,11,0,14,33,36,32,1,11]

theorem envBound51052 : H12AffineFastState.Bounded env51052 := by
  intro p hp
  have h : env51052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51051_51052 : H12AffineEnvironment.transform 3 10 env51051 = env51052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51051 == env51052) = true)

def env51053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound51053 : H12AffineFastState.Bounded env51053 := by
  intro p hp
  have h : env51053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50853_51053 : H12AffineEnvironment.transform 18 1025 env50853 = env51053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env50853 == env51053) = true)

theorem identity51053 : scanCanonicalize (H12AffineFastState.compose env51053 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237455) := by decide +kernel

theorem selectedBound51053 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237455,8328,64,15066126,237699,10507601,8830977,10723359,4407759,257,8642723,8585479,10651592]

theorem envBound51054 : H12AffineFastState.Bounded env51054 := by
  intro p hp
  have h : env51054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51053_51054 : H12AffineEnvironment.transform 23 2237455 env51053 = env51054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237455 env51053 == env51054) = true)

def env51055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15066126,115151,10507601,8692045,10600787,4268163,257,8487407,8478795,10544772]

theorem envBound51055 : H12AffineFastState.Bounded env51055 := by
  intro p hp
  have h : env51055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51054_51055 : H12AffineEnvironment.transform 16 24908 env51054 = env51055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env51054 == env51055) = true)

def env51056 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114835,8328,16,15066126,115103,10507521,8691997,10600707,4268163,257,8487359,8478747,10544772]

theorem envBound51056 : H12AffineFastState.Bounded env51056 := by
  intro p hp
  have h : env51056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51055_51056 : H12AffineEnvironment.transform 5 16 env51055 = env51056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51055 == env51056) = true)

theorem identity51056 : scanCanonicalize (H12AffineFastState.compose env51056 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2155533) := by decide +kernel

theorem selectedBound51056 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env51057 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2155533,2114835,8328,16,4521987,115103,45324,2376976,75022,4268163,257,2188722,2196502,649]

theorem envBound51057 : H12AffineFastState.Bounded env51057 := by
  intro p hp
  have h : env51057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51056_51057 : H12AffineEnvironment.transform 22 2155533 env51056 = env51057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2155533 env51056 == env51057) = true)

def env51058 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114864,2155533,2114835,8328,16,2442547,115103,45324,2376976,75022,2188723,257,2188722,2196502,649]

theorem envBound51058 : H12AffineFastState.Bounded env51058 := by
  intro p hp
  have h : env51058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51057_51058 : H12AffineEnvironment.transform 21 2114864 env51057 = env51058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114864 env51057 == env51058) = true)

theorem identity51058 : scanCanonicalize (H12AffineFastState.compose env51058 (packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51058 : packedSelected [10,11,15,17,18,19,21,23,26,31,32,38] rootPS < 2^1333 := by decide +kernel

def env51059 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2114864,2155533,2114835,8328,16,2190619,115103,45324,2125112,75022,2188723,257,2188722,2196502,649]

theorem envBound51059 : H12AffineFastState.Bounded env51059 := by
  intro p hp
  have h : env51059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51058_51059 : H12AffineEnvironment.transform 17 10280 env51058 = env51059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51058 == env51059) = true)

theorem identity51059 : scanCanonicalize (H12AffineFastState.compose env51059 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51059 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env51060 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,2097152,2114864,2155533,2114835,8192,16,2190619,114967,45324,2125112,75022,2188603,257,2188602,2196502,513]

theorem envBound51060 : H12AffineFastState.Bounded env51060 := by
  intro p hp
  have h : env51060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51059_51060 : H12AffineEnvironment.transform 6 8 env51059 = env51060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51059 == env51060) = true)

theorem identity51060 : scanCanonicalize (H12AffineFastState.compose env51060 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound51060 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51061 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,10280,1025,32769,91419,73771,98582,73736,8192,16,2048,114967,45324,67619,75022,32,257,33,57613,513]

theorem envBound51061 : H12AffineFastState.Bounded env51061 := by
  intro p hp
  have h : env51061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51060_51061 : H12AffineEnvironment.transform 20 91419 env51060 = env51061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env51060 == env51061) = true)

theorem identity51061 : scanCanonicalize (H12AffineFastState.compose env51061 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound51061 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51062 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,24860,10280,1025,32769,58396,41260,17,41231,8192,16,2048,16400,45324,35108,41993,32,257,33,57613,513]

theorem envBound51062 : H12AffineFastState.Bounded env51062 := by
  intro p hp
  have h : env51062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51061_51062 : H12AffineEnvironment.transform 15 33031 env51061 = env51062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env51061 == env51062) = true)

theorem identity51062 : scanCanonicalize (H12AffineFastState.compose env51062 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound51062 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env51063 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8203,24860,10280,1025,8461,17680,32,17,3,8192,16,2048,16400,4096,10280,1285,32,257,33,16385,513]

theorem envBound51063 : H12AffineFastState.Bounded env51063 := by
  intro p hp
  have h : env51063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51062_51063 : H12AffineEnvironment.transform 14 8460 env51062 = env51063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env51062 == env51063) = true)

theorem identity51063 : scanCanonicalize (H12AffineFastState.compose env51063 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound51063 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51064 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4404,8460,8203,12328,10280,1025,8461,5156,32,17,3,8192,16,2048,4388,4096,10280,1285,32,257,33,4405,513]

theorem envBound51064 : H12AffineFastState.Bounded env51064 := by
  intro p hp
  have h : env51064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51063_51064 : H12AffineEnvironment.transform 13 4404 env51063 = env51064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env51063 == env51064) = true)

theorem identity51064 : scanCanonicalize (H12AffineFastState.compose env51064 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51064 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51065 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4404,8460,8203,12328,10280,53,8461,4112,32,17,3,8192,16,2048,4388,4096,10280,305,32,257,33,4405,513]

theorem envBound51065 : H12AffineFastState.Bounded env51065 := by
  intro p hp
  have h : env51065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51064_51065 : H12AffineEnvironment.transform 9 52 env51064 = env51065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51064 == env51065) = true)

theorem identity51065 : scanCanonicalize (H12AffineFastState.compose env51065 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51065 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51066 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,8192,4372,8460,8203,12296,10248,21,8461,4112,0,17,3,8192,16,2048,4356,4096,10248,273,0,257,1,4373,513]

theorem envBound51066 : H12AffineFastState.Bounded env51066 := by
  intro p hp
  have h : env51066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51065_51066 : H12AffineEnvironment.transform 4 0 env51065 = env51066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51065 == env51066) = true)

theorem identity51066 : scanCanonicalize (H12AffineFastState.compose env51066 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51066 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env51067 : List Nat := [2,4,8,16,0,16,8,256,512,20,2048,4096,269,4372,1,262,4357,2309,21,0,4112,0,17,3,269,16,2048,4356,4096,2309,273,0,257,1,4373,513]

theorem envBound51067 : H12AffineFastState.Bounded env51067 := by
  intro p hp
  have h : env51067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51066_51067 : H12AffineEnvironment.transform 12 269 env51066 = env51067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51066 == env51067) = true)

theorem identity51067 : scanCanonicalize (H12AffineFastState.compose env51067 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound51067 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51068 : List Nat := [2,4,8,16,0,16,8,256,512,20,783,4096,269,4372,1,262,4357,522,21,0,4112,0,17,3,269,16,783,4356,4096,522,273,0,257,1,4373,513]

theorem envBound51068 : H12AffineFastState.Bounded env51068 := by
  intro p hp
  have h : env51068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51067_51068 : H12AffineEnvironment.transform 10 783 env51067 = env51068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env51067 == env51068) = true)

theorem identity51068 : scanCanonicalize (H12AffineFastState.compose env51068 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound51068 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51069 : List Nat := [2,4,8,16,0,16,8,256,261,20,10,4096,269,4372,1,262,4357,271,21,0,4112,0,17,3,269,16,10,4356,4096,271,273,0,257,1,4373,260]

theorem envBound51069 : H12AffineFastState.Bounded env51069 := by
  intro p hp
  have h : env51069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51068_51069 : H12AffineEnvironment.transform 8 261 env51068 = env51069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env51068 == env51069) = true)

theorem identity51069 : scanCanonicalize (H12AffineFastState.compose env51069 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound51069 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51070 : List Nat := [2,4,8,16,0,16,8,256,261,20,10,260,269,16,1,262,1,271,21,0,276,0,17,3,269,16,10,0,260,271,273,0,257,1,17,260]

theorem envBound51070 : H12AffineFastState.Bounded env51070 := by
  intro p hp
  have h : env51070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51069_51070 : H12AffineEnvironment.transform 11 260 env51069 = env51070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env51069 == env51070) = true)

theorem identity51070 : scanCanonicalize (H12AffineFastState.compose env51070 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound51070 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env51071 : List Nat := [2,4,8,16,0,16,8,9,12,20,10,13,4,16,1,15,1,6,21,0,29,0,17,3,4,16,10,0,13,6,24,0,8,1,17,13]

theorem envBound51071 : H12AffineFastState.Bounded env51071 := by
  intro p hp
  have h : env51071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51070_51071 : H12AffineEnvironment.transform 7 9 env51070 = env51071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env51070 == env51071) = true)

def env51072 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114865,2155533,2114835,8328,16,2442546,115103,45324,2376976,75022,2188722,257,2188722,2196502,649]

theorem envBound51072 : H12AffineFastState.Bounded env51072 := by
  intro p hp
  have h : env51072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51057_51072 : H12AffineEnvironment.transform 21 2114865 env51057 = env51072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114865 env51057 == env51072) = true)

theorem identity51072 : scanCanonicalize (H12AffineFastState.compose env51072 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51072 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51073 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,2114865,2155533,2114835,8192,16,2442546,114967,45324,2376976,75022,2188602,257,2188602,2196502,513]

theorem envBound51073 : H12AffineFastState.Bounded env51073 := by
  intro p hp
  have h : env51073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51072_51073 : H12AffineEnvironment.transform 6 8 env51072 = env51073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51072 == env51073) = true)

theorem identity51073 : scanCanonicalize (H12AffineFastState.compose env51073 (packedSelected [0,7,16,19,21,26] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound51073 : packedSelected [0,7,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env51074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,35109,1025,32769,2097152,2114865,2155533,2114835,8192,16,2214935,114967,45324,2149429,75022,2188602,257,2188602,2196502,513]

theorem envBound51074 : H12AffineFastState.Bounded env51074 := by
  intro p hp
  have h : env51074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51073_51074 : H12AffineEnvironment.transform 17 35109 env51073 = env51074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env51073 == env51074) = true)

theorem identity51074 : scanCanonicalize (H12AffineFastState.compose env51074 (packedSelected [3,4,5,9,10,11,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 15406) := by decide +kernel

theorem selectedBound51074 : packedSelected [3,4,5,9,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,15406,24860,35109,1025,32769,2097152,2114865,2155533,2114835,8192,16,2158649,64825,45324,2149429,6432,2119956,257,2119956,2144312,513]

theorem envBound51075 : H12AffineFastState.Bounded env51075 := by
  intro p hp
  have h : env51075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51074_51075 : H12AffineEnvironment.transform 15 15406 env51074 = env51075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15406 env51074 == env51075) = true)

theorem identity51075 : scanCanonicalize (H12AffineFastState.compose env51075 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 15656) := by decide +kernel

theorem selectedBound51075 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env51076 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,15656,15406,24860,13325,1025,15657,2097152,2114865,2119973,2114835,8192,16,2116881,16401,3108,2126109,6432,2119956,257,2119956,2098448,513]

theorem envBound51076 : H12AffineFastState.Bounded env51076 := by
  intro p hp
  have h : env51076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51075_51076 : H12AffineEnvironment.transform 14 15656 env51075 = env51076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15656 env51075 == env51076) = true)

theorem identity51076 : scanCanonicalize (H12AffineFastState.compose env51076 (packedSelected [1,2,3,4,5,6,8,9,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 7464) := by decide +kernel

theorem selectedBound51076 : packedSelected [1,2,3,4,5,6,8,9,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env51077 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7464,16384,0,262,23604,2341,1025,1,2097152,2114865,2119973,2114835,7464,16,2116881,16401,3108,2116661,6432,2119956,257,2119956,2098448,513]

theorem envBound51077 : H12AffineFastState.Bounded env51077 := by
  intro p hp
  have h : env51077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51076_51077 : H12AffineEnvironment.transform 12 7464 env51076 = env51077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7464 env51076 == env51077) = true)

theorem identity51077 : scanCanonicalize (H12AffineFastState.compose env51077 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound51077 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51078 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,16384,0,262,16400,2341,1025,1,2097152,2114865,2114817,2114835,268,16,2116881,16401,3108,2116661,1284,2114864,257,2114864,2098448,513]

theorem envBound51078 : H12AffineFastState.Bounded env51078 := by
  intro p hp
  have h : env51078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51077_51078 : H12AffineEnvironment.transform 11 3108 env51077 = env51078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env51077 == env51078) = true)

theorem identity51078 : scanCanonicalize (H12AffineFastState.compose env51078 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound51078 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51079 : List Nat := [2,4,8,16,32,16,8,256,512,1024,270,1322,268,16384,0,262,16400,43,1025,1,2097152,2114865,2114817,2114835,268,16,2114591,16401,1322,2114875,1284,2114864,257,2114864,2098448,513]

theorem envBound51079 : H12AffineFastState.Bounded env51079 := by
  intro p hp
  have h : env51079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51078_51079 : H12AffineEnvironment.transform 10 270 env51078 = env51079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env51078 == env51079) = true)

theorem identity51079 : scanCanonicalize (H12AffineFastState.compose env51079 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound51079 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env51080 : List Nat := [2,4,8,16,32,16,8,63,512,1024,49,1045,51,16384,0,57,16400,43,1025,1,2097152,2114574,2114622,2114604,51,16,2114591,16401,1045,2114564,1083,2114575,62,2114575,2098223,513]

theorem envBound51080 : H12AffineFastState.Bounded env51080 := by
  intro p hp
  have h : env51080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51079_51080 : H12AffineEnvironment.transform 7 63 env51079 = env51080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env51079 == env51080) = true)

theorem identity51080 : scanCanonicalize (H12AffineFastState.compose env51080 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 1044) := by decide +kernel

theorem selectedBound51080 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51081 : List Nat := [2,4,8,16,32,16,8,63,512,1024,49,1045,51,1044,0,57,1028,43,1025,1,2097152,2097178,2097194,2097208,51,16,2097163,1029,1045,2097168,1083,2097179,62,2097179,2098223,513]

theorem envBound51081 : H12AffineFastState.Bounded env51081 := by
  intro p hp
  have h : env51081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51080_51081 : H12AffineEnvironment.transform 13 1044 env51080 = env51081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1044 env51080 == env51081) = true)

theorem identity51081 : scanCanonicalize (H12AffineFastState.compose env51081 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51081 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env51082 : List Nat := [2,4,8,16,32,16,8,63,512,53,49,32,51,33,0,57,49,43,52,1,2097152,2097178,2097194,2097208,51,16,2097163,48,32,2097168,14,2097179,62,2097179,2097178,513]

theorem envBound51082 : H12AffineFastState.Bounded env51082 := by
  intro p hp
  have h : env51082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51081_51082 : H12AffineEnvironment.transform 9 53 env51081 = env51082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51081 == env51082) = true)

theorem identity51082 : scanCanonicalize (H12AffineFastState.compose env51082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 43) := by decide +kernel

theorem selectedBound51082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51083 : List Nat := [2,4,8,16,32,16,8,63,512,53,49,32,51,33,0,57,49,43,52,1,43,49,1,19,51,16,32,48,32,59,14,48,62,48,49,513]

theorem envBound51083 : H12AffineFastState.Bounded env51083 := by
  intro p hp
  have h : env51083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51082_51083 : H12AffineEnvironment.transform 20 43 env51082 = env51083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 43 env51082 == env51083) = true)

theorem identity51083 : scanCanonicalize (H12AffineFastState.compose env51083 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51084 : List Nat := [2,4,8,10,32,10,8,37,512,47,43,32,41,33,0,35,43,43,46,1,43,43,1,9,41,10,32,42,32,33,14,42,36,42,43,513]

theorem envBound51084 : H12AffineFastState.Bounded env51084 := by
  intro p hp
  have h : env51084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51083_51084 : H12AffineEnvironment.transform 3 10 env51083 = env51084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51083 == env51084) = true)

theorem identity51084 : scanCanonicalize (H12AffineFastState.compose env51084 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound51084 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env51085 : List Nat := [2,4,8,10,32,10,8,37,37,47,43,32,41,33,0,35,43,43,46,1,43,43,1,9,41,10,32,42,32,33,14,42,36,42,43,36]

theorem envBound51085 : H12AffineFastState.Bounded env51085 := by
  intro p hp
  have h : env51085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51084_51085 : H12AffineEnvironment.transform 8 37 env51084 = env51085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env51084 == env51085) = true)

theorem identity51085 : scanCanonicalize (H12AffineFastState.compose env51085 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound51085 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env51086 : List Nat := [2,4,1,3,32,3,1,37,37,38,34,32,32,33,0,35,34,34,39,1,34,34,1,0,32,3,32,35,32,33,7,35,36,35,34,36]

theorem envBound51086 : H12AffineFastState.Bounded env51086 := by
  intro p hp
  have h : env51086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51085_51086 : H12AffineEnvironment.transform 2 1 env51085 = env51086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env51085 == env51086) = true)

theorem identity51086 : scanCanonicalize (H12AffineFastState.compose env51086 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound51086 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env51087 : List Nat := [2,4,1,3,2,3,1,7,7,4,0,2,2,3,0,1,0,0,5,1,0,0,1,0,2,3,2,1,2,3,7,1,6,1,0,6]

theorem envBound51087 : H12AffineFastState.Bounded env51087 := by
  intro p hp
  have h : env51087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51086_51087 : H12AffineEnvironment.transform 4 2 env51086 = env51087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env51086 == env51087) = true)

theorem identity51087 : scanCanonicalize (H12AffineFastState.compose env51087 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51088 : List Nat := [1,4,1,0,1,0,1,4,4,4,0,1,1,0,0,1,0,0,5,1,0,0,1,0,1,0,1,1,1,0,4,1,5,1,0,5]

theorem envBound51088 : H12AffineFastState.Bounded env51088 := by
  intro p hp
  have h : env51088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51087_51088 : H12AffineEnvironment.transform 0 1 env51087 = env51088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51087 == env51088) = true)

def env51089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114834,8328,17,15066126,115102,10507520,8691996,10600706,4268163,257,8487358,8478746,10544772]

theorem envBound51089 : H12AffineFastState.Bounded env51089 := by
  intro p hp
  have h : env51089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51055_51089 : H12AffineEnvironment.transform 5 17 env51055 = env51089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51055 == env51089) = true)

theorem identity51089 : scanCanonicalize (H12AffineFastState.compose env51089 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(22+1) ^^^ 2411557) := by decide +kernel

theorem selectedBound51089 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env51090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,2411557,2114834,8328,17,4270123,115102,301349,2125113,331047,4268163,257,2444699,2468927,273057]

theorem envBound51090 : H12AffineFastState.Bounded env51090 := by
  intro p hp
  have h : env51090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51089_51090 : H12AffineEnvironment.transform 22 2411557 env51089 = env51090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2411557 env51089 == env51090) = true)

def env51091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,32,2411557,2114834,8328,17,75787,115102,301349,2125113,331047,73891,257,2444699,2468927,273057]

theorem envBound51091 : H12AffineFastState.Bounded env51091 := by
  intro p hp
  have h : env51091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51090_51091 : H12AffineEnvironment.transform 21 32 env51090 = env51091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51090 == env51091) = true)

theorem identity51091 : scanCanonicalize (H12AffineFastState.compose env51091 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 322872) := by decide +kernel

theorem selectedBound51091 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,322872,32,8477,305194,8328,17,75787,115102,301349,294913,331047,73891,257,106659,82183,273057]

theorem envBound51092 : H12AffineFastState.Bounded env51092 := by
  intro p hp
  have h : env51092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51091_51092 : H12AffineEnvironment.transform 20 322872 env51091 = env51092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 322872 env51091 == env51092) = true)

theorem identity51092 : scanCanonicalize (H12AffineFastState.compose env51092 (packedSelected [0,1,4,7,8,9,10,11,15,16,19,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound51092 : packedSelected [0,1,4,7,8,9,10,11,15,16,19,21,26] rootPS < 2^1333 := by decide +kernel

def env51093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8322,24861,262144,1025,32769,322872,32,8477,305194,8328,17,2185,57628,301349,294913,273829,33,257,32801,24965,273057]

theorem envBound51093 : H12AffineFastState.Bounded env51093 := by
  intro p hp
  have h : env51093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51092_51093 : H12AffineEnvironment.transform 15 8322 env51092 = env51093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env51092 == env51093) = true)

theorem identity51093 : scanCanonicalize (H12AffineFastState.compose env51093 (packedSelected [11,12,15,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51093 : packedSelected [11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env51094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,8322,24861,262144,1025,0,290105,32,8477,272427,8328,17,2185,24861,268580,262144,273829,33,257,32,24965,273057]

theorem envBound51094 : H12AffineFastState.Bounded env51094 := by
  intro p hp
  have h : env51094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51093_51094 : H12AffineEnvironment.transform 14 1 env51093 = env51094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51093 == env51094) = true)

theorem identity51094 : scanCanonicalize (H12AffineFastState.compose env51094 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound51094 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env51095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,1,8322,24861,2340,1025,0,25629,32,8477,8463,8328,17,2185,24861,4096,2340,9345,33,257,32,24965,9093]

theorem envBound51095 : H12AffineFastState.Bounded env51095 := by
  intro p hp
  have h : env51095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51094_51095 : H12AffineEnvironment.transform 17 2340 env51094 = env51095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env51094 == env51095) = true)

theorem identity51095 : scanCanonicalize (H12AffineFastState.compose env51095 (packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51095 : packedSelected [0,1,2,3,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env51096 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,8203,24861,2340,1025,0,25629,32,8477,8463,8193,17,2048,24861,4096,2340,9224,33,257,32,24844,8972]

theorem envBound51096 : H12AffineFastState.Bounded env51096 := by
  intro p hp
  have h : env51096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51095_51096 : H12AffineEnvironment.transform 6 9 env51095 = env51096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51095 == env51096) = true)

theorem identity51096 : scanCanonicalize (H12AffineFastState.compose env51096 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 4372) := by decide +kernel

theorem selectedBound51096 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env51097 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4372,1,8203,12297,2340,1025,0,13577,32,8477,8463,8193,17,2048,12297,4096,2340,9224,33,257,32,12312,8972]

theorem envBound51097 : H12AffineFastState.Bounded env51097 := by
  intro p hp
  have h : env51097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51096_51097 : H12AffineEnvironment.transform 13 4372 env51096 = env51097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4372 env51096 == env51097) = true)

theorem identity51097 : scanCanonicalize (H12AffineFastState.compose env51097 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound51097 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env51098 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,8192,4372,1,8203,12297,2340,305,0,12345,32,8477,8463,8193,17,2048,12297,4096,2340,8504,33,257,32,12312,8972]

theorem envBound51098 : H12AffineFastState.Bounded env51098 := by
  intro p hp
  have h : env51098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51097_51098 : H12AffineEnvironment.transform 9 304 env51097 = env51098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env51097 == env51098) = true)

theorem identity51098 : scanCanonicalize (H12AffineFastState.compose env51098 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound51098 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51099 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,301,4372,1,294,4388,2340,305,0,4372,32,48,34,300,17,2048,4388,4096,2340,21,33,257,32,4405,545]

theorem envBound51099 : H12AffineFastState.Bounded env51099 := by
  intro p hp
  have h : env51099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51098_51099 : H12AffineEnvironment.transform 12 301 env51098 = env51099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env51098 == env51099) = true)

theorem identity51099 : scanCanonicalize (H12AffineFastState.compose env51099 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51099 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51100 : List Nat := [2,4,8,16,32,17,9,5,512,53,2048,4096,40,4113,1,35,4129,2081,52,0,4113,32,48,34,41,17,2048,4129,4096,2081,21,33,4,32,4144,545]

theorem envBound51100 : H12AffineFastState.Bounded env51100 := by
  intro p hp
  have h : env51100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51099_51100 : H12AffineEnvironment.transform 7 5 env51099 = env51100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51099 == env51100) = true)

theorem identity51100 : scanCanonicalize (H12AffineFastState.compose env51100 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound51100 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env51101 : List Nat := [2,4,8,16,32,17,9,5,512,53,561,4096,40,4113,1,35,4129,528,52,0,4113,32,48,34,41,17,561,4129,4096,528,21,33,4,32,4144,545]

theorem envBound51101 : H12AffineFastState.Bounded env51101 := by
  intro p hp
  have h : env51101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51100_51101 : H12AffineEnvironment.transform 10 561 env51100 = env51101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env51100 == env51101) = true)

theorem identity51101 : scanCanonicalize (H12AffineFastState.compose env51101 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound51101 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env51102 : List Nat := [2,4,8,16,32,17,9,5,512,53,561,528,40,513,1,35,561,528,52,0,513,32,48,34,41,17,561,561,528,528,21,33,4,32,544,545]

theorem envBound51102 : H12AffineFastState.Bounded env51102 := by
  intro p hp
  have h : env51102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51101_51102 : H12AffineEnvironment.transform 11 528 env51101 = env51102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env51101 == env51102) = true)

theorem identity51102 : scanCanonicalize (H12AffineFastState.compose env51102 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound51102 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env51103 : List Nat := [2,4,8,16,32,17,9,5,33,53,16,49,40,32,1,35,16,49,52,0,32,32,48,34,41,17,16,16,49,49,21,33,4,32,1,0]

theorem envBound51103 : H12AffineFastState.Bounded env51103 := by
  intro p hp
  have h : env51103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51102_51103 : H12AffineEnvironment.transform 8 33 env51102 = env51103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env51102 == env51103) = true)

theorem identity51103 : scanCanonicalize (H12AffineFastState.compose env51103 (packedSelected [0,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51103 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env51104 : List Nat := [2,4,8,1,32,0,9,5,33,36,1,32,40,32,1,35,1,32,37,0,32,32,33,34,41,0,1,1,32,32,4,33,4,32,1,0]

theorem envBound51104 : H12AffineFastState.Bounded env51104 := by
  intro p hp
  have h : env51104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51103_51104 : H12AffineEnvironment.transform 3 1 env51103 = env51104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51103 == env51104) = true)

theorem identity51104 : scanCanonicalize (H12AffineFastState.compose env51104 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51105 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,1,9,1,1,2,1,1,4,0,1,1,0,3,8,0,1,1,1,1,4,0,4,1,1,0]

theorem envBound51105 : H12AffineFastState.Bounded env51105 := by
  intro p hp
  have h : env51105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51104_51105 : H12AffineEnvironment.transform 4 1 env51104 = env51105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51104 == env51105) = true)

theorem identity51105 : scanCanonicalize (H12AffineFastState.compose env51105 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound51105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51106 : List Nat := [2,0,8,1,1,0,9,1,0,1,1,1,9,1,1,2,1,1,0,0,1,1,0,3,8,0,1,1,1,1,0,0,0,1,1,0]

theorem envBound51106 : H12AffineFastState.Bounded env51106 := by
  intro p hp
  have h : env51106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51105_51106 : H12AffineEnvironment.transform 1 0 env51105 = env51106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env51105 == env51106) = true)

def env51107 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,33,2411557,2114834,8328,17,75786,115102,301349,2125113,331047,73890,257,2444699,2468927,273057]

theorem envBound51107 : H12AffineFastState.Bounded env51107 := by
  intro p hp
  have h : env51107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51090_51107 : H12AffineEnvironment.transform 21 33 env51090 = env51107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env51090 == env51107) = true)

theorem identity51107 : scanCanonicalize (H12AffineFastState.compose env51107 (packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 91539) := by decide +kernel

theorem selectedBound51107 : packedSelected [1,2,5,6,7,9,10,11,12,15,16,17,19,21,22,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51108 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,91539,33,371126,73857,8328,17,75786,115102,301349,67754,331047,73890,257,272392,313772,273057]

theorem envBound51108 : H12AffineFastState.Bounded env51108 := by
  intro p hp
  have h : env51108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51107_51108 : H12AffineEnvironment.transform 20 91539 env51107 = env51108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91539 env51107 == env51108) = true)

theorem identity51108 : scanCanonicalize (H12AffineFastState.compose env51108 (packedSelected [1,3,8,9,14,15,19,20,22,24,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound51108 : packedSelected [1,3,8,9,14,15,19,20,22,24,32,35] rootPS < 2^1333 := by decide +kernel

def env51109 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,35108,1025,32769,91539,33,73874,73857,8328,17,75786,115102,4097,67754,99331,73890,257,41260,16520,41861]

theorem envBound51109 : H12AffineFastState.Bounded env51109 := by
  intro p hp
  have h : env51109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51108_51109 : H12AffineEnvironment.transform 17 35108 env51108 = env51109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env51108 == env51109) = true)

theorem identity51109 : scanCanonicalize (H12AffineFastState.compose env51109 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound51109 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env51110 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,65536,24861,2477,1025,136,91539,33,73874,73857,8328,17,75786,82199,4097,67754,66698,73890,257,8613,16520,8972]

theorem envBound51110 : H12AffineFastState.Bounded env51110 := by
  intro p hp
  have h : env51110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51109_51110 : H12AffineEnvironment.transform 14 137 env51109 = env51110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env51109 == env51110) = true)

theorem identity51110 : scanCanonicalize (H12AffineFastState.compose env51110 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound51110 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env51111 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,262,24861,2477,1025,136,25749,33,8596,8583,8328,17,10508,16401,4097,2476,1420,8612,257,8613,16520,8972]

theorem envBound51111 : H12AffineFastState.Bounded env51111 := by
  intro p hp
  have h : env51111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51110_51111 : H12AffineEnvironment.transform 15 262 env51110 = env51111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env51110 == env51111) = true)

theorem identity51111 : scanCanonicalize (H12AffineFastState.compose env51111 (packedSelected [1,2,4,8,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound51111 : packedSelected [1,2,4,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51112 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,137,262,16828,2477,1025,136,17460,33,309,294,41,17,2477,16401,4097,2476,1420,261,257,260,16520,941]

theorem envBound51112 : H12AffineFastState.Bounded env51112 := by
  intro p hp
  have h : env51112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51111_51112 : H12AffineEnvironment.transform 12 161 env51111 = env51112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env51111 == env51112) = true)

theorem identity51112 : scanCanonicalize (H12AffineFastState.compose env51112 (packedSelected [0,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2476) := by decide +kernel

theorem selectedBound51112 : packedSelected [0,9,10,11] rootPS < 2^1333 := by decide +kernel

def env51113 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,2476,137,262,2064,2477,1025,136,3480,33,309,294,41,17,2477,2493,4097,2476,1420,261,257,260,2340,941]

theorem envBound51113 : H12AffineFastState.Bounded env51113 := by
  intro p hp
  have h : env51113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51112_51113 : H12AffineEnvironment.transform 13 2476 env51112 = env51113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2476 env51112 == env51113) = true)

theorem identity51113 : scanCanonicalize (H12AffineFastState.compose env51113 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound51113 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env51114 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,161,2476,137,262,2064,2477,1025,136,3480,33,309,294,41,17,2477,2493,3464,2476,1420,261,257,260,2340,941]

theorem envBound51114 : H12AffineFastState.Bounded env51114 := by
  intro p hp
  have h : env51114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51113_51114 : H12AffineEnvironment.transform 11 3465 env51113 = env51114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env51113 == env51114) = true)

theorem identity51114 : scanCanonicalize (H12AffineFastState.compose env51114 (packedSelected [1,2,3,4,5,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51114 : packedSelected [1,2,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env51115 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3329,41,2340,1,262,2064,2341,1025,0,3344,33,309,294,41,17,2341,2357,3328,2340,1284,261,257,260,2340,805]

theorem envBound51115 : H12AffineFastState.Bounded env51115 := by
  intro p hp
  have h : env51115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51114_51115 : H12AffineEnvironment.transform 6 8 env51114 = env51115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51114 == env51115) = true)

theorem identity51115 : scanCanonicalize (H12AffineFastState.compose env51115 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound51115 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51116 : List Nat := [2,4,8,16,32,17,8,256,512,1024,292,1061,41,0,1,262,308,1,1025,0,1076,33,309,294,41,17,1,17,1060,0,1284,261,257,260,0,805]

theorem envBound51116 : H12AffineFastState.Bounded env51116 := by
  intro p hp
  have h : env51116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51115_51116 : H12AffineEnvironment.transform 10 292 env51115 = env51116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env51115 == env51116) = true)

theorem identity51116 : scanCanonicalize (H12AffineFastState.compose env51116 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51116 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env51117 : List Nat := [2,4,8,16,32,17,8,256,512,53,292,16,41,0,1,262,308,1,52,0,1,33,309,294,41,17,1,17,17,0,305,261,257,260,0,805]

theorem envBound51117 : H12AffineFastState.Bounded env51117 := by
  intro p hp
  have h : env51117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51116_51117 : H12AffineEnvironment.transform 9 53 env51116 = env51117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51116 == env51117) = true)

theorem identity51117 : scanCanonicalize (H12AffineFastState.compose env51117 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51117 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51118 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,16,41,0,1,34,16,1,52,0,1,33,17,2,41,17,1,17,17,0,21,33,37,32,0,513]

theorem envBound51118 : H12AffineFastState.Bounded env51118 := by
  intro p hp
  have h : env51118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51117_51118 : H12AffineEnvironment.transform 7 36 env51117 = env51118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51117 == env51118) = true)

theorem identity51118 : scanCanonicalize (H12AffineFastState.compose env51118 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51119 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,16,8,0,1,3,16,1,21,0,1,0,17,2,8,17,1,17,17,0,21,0,4,1,0,513]

theorem envBound51119 : H12AffineFastState.Bounded env51119 := by
  intro p hp
  have h : env51119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51118_51119 : H12AffineEnvironment.transform 4 1 env51118 = env51119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51118 == env51119) = true)

def env51120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066126,115150,10507601,8692044,10600786,4268162,257,8487406,8478794,10544773]

theorem envBound51120 : H12AffineFastState.Bounded env51120 := by
  intro p hp
  have h : env51120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51054_51120 : H12AffineEnvironment.transform 16 24909 env51054 = env51120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env51054 == env51120) = true)

def env51121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,262144,1025,32769,2097152,4194304,8388608,2114834,8328,16,15066126,115102,10507521,8691996,10600706,4268162,257,8487358,8478746,10544773]

theorem envBound51121 : H12AffineFastState.Bounded env51121 := by
  intro p hp
  have h : env51121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51120_51121 : H12AffineEnvironment.transform 5 16 env51120 = env51121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51120 == env51121) = true)

theorem identity51121 : scanCanonicalize (H12AffineFastState.compose env51121 (packedSelected [1,3,12,17,21,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51121 : packedSelected [1,3,12,17,21,24,28,41] rootPS < 2^1333 := by decide +kernel

def env51122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8328,16,14797862,115102,10507521,8423732,10600706,4268162,257,8487358,8478746,10544773]

theorem envBound51122 : H12AffineFastState.Bounded env51122 := by
  intro p hp
  have h : env51122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51121_51122 : H12AffineEnvironment.transform 17 10280 env51121 = env51122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51121 == env51122) = true)

def env51123 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8192,16,14797862,114966,10507521,8423732,10600706,4268042,257,8487222,8478746,10544653]

theorem envBound51123 : H12AffineFastState.Bounded env51123 := by
  intro p hp
  have h : env51123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51122_51123 : H12AffineEnvironment.transform 6 8 env51122 = env51123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51122 == env51123) = true)

def env51124 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50448,4194304,8388608,32770,8192,16,12650806,114966,8425489,8423732,8455186,4268042,257,8487222,8478746,8397597]

theorem envBound51124 : H12AffineFastState.Bounded env51124 := by
  intro p hp
  have h : env51124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51123_51124 : H12AffineEnvironment.transform 20 50448 env51123 = env51124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env51123 == env51124) = true)

theorem identity51124 : scanCanonicalize (H12AffineFastState.compose env51124 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235581) := by decide +kernel

theorem selectedBound51124 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env51125 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50448,4194304,4235581,32770,8192,16,108555,114966,4206892,4204553,4302127,4268042,257,4268043,4309287,4227616]

theorem envBound51125 : H12AffineFastState.Bounded env51125 := by
  intro p hp
  have h : env51125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51124_51125 : H12AffineEnvironment.transform 22 4235581 env51124 = env51125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235581 env51124 == env51125) = true)

theorem identity51125 : scanCanonicalize (H12AffineFastState.compose env51125 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51125 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51126 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,65536,24861,10280,1025,1,17680,4194304,4202813,2,8192,16,75787,82198,4206892,4204553,4269359,4268042,257,4268043,4276519,4194848]

theorem envBound51126 : H12AffineFastState.Bounded env51126 := by
  intro p hp
  have h : env51126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51125_51126 : H12AffineEnvironment.transform 14 0 env51125 = env51126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51125 == env51126) = true)

theorem identity51126 : scanCanonicalize (H12AffineFastState.compose env51126 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound51126 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env51127 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,263,24861,10280,1025,1,17680,4194304,4202813,2,8192,16,10508,16401,4206892,4204553,4203560,4202765,257,4202764,4210720,4194848]

theorem envBound51127 : H12AffineFastState.Bounded env51127 := by
  intro p hp
  have h : env51127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51126_51127 : H12AffineEnvironment.transform 15 263 env51126 = env51127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env51126 == env51127) = true)

def env51128 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50449,4194304,8388608,32771,8192,16,12650807,114966,8425488,8423732,8455187,4268042,257,8487222,8478746,8397596]

theorem envBound51128 : H12AffineFastState.Bounded env51128 := by
  intro p hp
  have h : env51128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51123_51128 : H12AffineEnvironment.transform 20 50449 env51123 = env51128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env51123 == env51128) = true)

theorem identity51128 : scanCanonicalize (H12AffineFastState.compose env51128 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 41244) := by decide +kernel

theorem selectedBound51128 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env51129 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,50449,4194304,41244,32771,8192,16,4302891,114966,12556,10280,107791,4268042,257,73770,114950,33280]

theorem envBound51129 : H12AffineFastState.Bounded env51129 := by
  intro p hp
  have h : env51129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51128_51129 : H12AffineEnvironment.transform 22 41244 env51128 = env51129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41244 env51128 == env51129) = true)

def env51130 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,8388608,2114834,8193,16,14797862,114967,10507521,8423732,10600706,4268043,257,8487223,8478746,10544652]

theorem envBound51130 : H12AffineFastState.Bounded env51130 := by
  intro p hp
  have h : env51130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51122_51130 : H12AffineEnvironment.transform 6 9 env51122 = env51130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51122 == env51130) = true)

theorem identity51130 : scanCanonicalize (H12AffineFastState.compose env51130 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 41244) := by decide +kernel

theorem selectedBound51130 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51131 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24861,10280,1025,32769,2097152,4194304,41244,2114834,8193,16,6384954,114967,2159645,10280,2187294,4268043,257,73771,114950,2115344]

theorem envBound51131 : H12AffineFastState.Bounded env51131 := by
  intro p hp
  have h : env51131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51130_51131 : H12AffineEnvironment.transform 22 41244 env51130 = env51131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41244 env51130 == env51131) = true)

theorem identity51131 : scanCanonicalize (H12AffineFastState.compose env51131 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound51131 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env51132 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,292,65536,24861,10280,1025,293,2097152,4194304,8248,2114834,8193,16,6384954,81971,2127161,10280,2187294,4268043,257,73771,81954,2115344]

theorem envBound51132 : H12AffineFastState.Bounded env51132 := by
  intro p hp
  have h : env51132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51131_51132 : H12AffineEnvironment.transform 14 292 env51131 = env51132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env51131 == env51132) = true)

theorem identity51132 : scanCanonicalize (H12AffineFastState.compose env51132 (packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound51132 : packedSelected [0,3,7,8,9,14,16,18,19,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env51133 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,292,65536,24861,10280,1025,293,2097152,8200,8248,2114834,8193,16,2182450,81971,2127161,10280,2187294,65539,257,73771,81954,2115344]

theorem envBound51133 : H12AffineFastState.Bounded env51133 := by
  intro p hp
  have h : env51133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51132_51133 : H12AffineEnvironment.transform 21 8200 env51132 = env51133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env51132 == env51133) = true)

theorem identity51133 : scanCanonicalize (H12AffineFastState.compose env51133 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound51133 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env51134 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,292,21795,24861,10280,1025,293,2097152,8200,8248,2114834,8193,16,2103313,5392,2127161,10280,2110781,21792,257,29960,5377,2115344]

theorem envBound51134 : H12AffineFastState.Bounded env51134 := by
  intro p hp
  have h : env51134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51133_51134 : H12AffineEnvironment.transform 15 21795 env51133 = env51134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env51133 == env51134) = true)

theorem identity51134 : scanCanonicalize (H12AffineFastState.compose env51134 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(20+1) ^^^ 12345) := by decide +kernel

theorem selectedBound51134 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env51135 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,292,21795,24861,10280,1025,293,12345,8200,8248,29995,8193,16,10280,5392,17664,10280,1284,21792,257,29960,5377,30505]

theorem envBound51135 : H12AffineFastState.Bounded env51135 := by
  intro p hp
  have h : env51135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51134_51135 : H12AffineEnvironment.transform 20 12345 env51134 = env51135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12345 env51134 == env51135) = true)

theorem identity51135 : scanCanonicalize (H12AffineFastState.compose env51135 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound51135 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51136 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13608,292,8203,5173,10280,1025,293,12345,8200,8248,3,8193,16,10280,5392,12328,10280,1284,8200,257,32,5377,513]

theorem envBound51136 : H12AffineFastState.Bounded env51136 := by
  intro p hp
  have h : env51136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51135_51136 : H12AffineEnvironment.transform 13 13608 env51135 = env51136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env51135 == env51136) = true)

theorem identity51136 : scanCanonicalize (H12AffineFastState.compose env51136 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound51136 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51137 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,8192,8460,292,8203,17,10280,1025,293,9245,8200,8248,3,8193,16,10280,308,9228,10280,1284,8200,257,32,293,513]

theorem envBound51137 : H12AffineFastState.Bounded env51137 := by
  intro p hp
  have h : env51137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51136_51137 : H12AffineEnvironment.transform 11 1060 env51136 = env51137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env51136 == env51137) = true)

theorem identity51137 : scanCanonicalize (H12AffineFastState.compose env51137 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51137 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51138 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1,1060,8192,8460,292,8203,17,8233,1025,293,9245,8200,8248,3,8193,16,8233,308,9228,8233,1284,8200,257,32,293,513]

theorem envBound51138 : H12AffineFastState.Bounded env51138 := by
  intro p hp
  have h : env51138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51137_51138 : H12AffineEnvironment.transform 10 1 env51137 = env51138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51137 == env51138) = true)

theorem identity51138 : scanCanonicalize (H12AffineFastState.compose env51138 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51138 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env51139 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,16,8192,8460,292,8203,17,8233,53,293,8233,8200,8248,3,8193,16,8233,308,8248,8233,304,8200,257,32,293,513]

theorem envBound51139 : H12AffineFastState.Bounded env51139 := by
  intro p hp
  have h : env51139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51138_51139 : H12AffineEnvironment.transform 9 52 env51138 = env51139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51138 == env51139) = true)

theorem identity51139 : scanCanonicalize (H12AffineFastState.compose env51139 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51139 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env51140 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,16,269,1,292,262,17,292,53,293,292,261,309,3,268,16,292,308,309,292,304,261,257,32,293,513]

theorem envBound51140 : H12AffineFastState.Bounded env51140 := by
  intro p hp
  have h : env51140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51139_51140 : H12AffineEnvironment.transform 12 269 env51139 = env51140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51139 == env51140) = true)

theorem identity51140 : scanCanonicalize (H12AffineFastState.compose env51140 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound51140 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env51141 : List Nat := [2,4,8,16,32,16,9,256,277,52,1,16,269,1,292,262,17,292,53,293,292,261,309,3,268,16,292,308,309,292,304,261,257,32,293,276]

theorem envBound51141 : H12AffineFastState.Bounded env51141 := by
  intro p hp
  have h : env51141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51140_51141 : H12AffineEnvironment.transform 8 277 env51140 = env51141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env51140 == env51141) = true)

theorem identity51141 : scanCanonicalize (H12AffineFastState.compose env51141 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51141 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51142 : List Nat := [2,4,8,16,32,16,9,37,48,52,1,16,40,1,1,35,17,1,53,0,1,32,16,3,41,16,1,17,16,1,21,32,36,32,0,49]

theorem envBound51142 : H12AffineFastState.Bounded env51142 := by
  intro p hp
  have h : env51142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51141_51142 : H12AffineEnvironment.transform 7 37 env51141 = env51142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51141 == env51142) = true)

def env51143 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,8388608,2114835,8328,17,15066126,115103,10507520,8691997,10600707,4268162,257,8487359,8478747,10544773]

theorem envBound51143 : H12AffineFastState.Bounded env51143 := by
  intro p hp
  have h : env51143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51120_51143 : H12AffineEnvironment.transform 5 17 env51120 = env51143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51120 == env51143) = true)

def env51144 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2101248,2114835,8328,17,4584462,115103,17664,2404637,119043,4268162,257,2199999,2191387,63109]

theorem envBound51144 : H12AffineFastState.Bounded env51144 := by
  intro p hp
  have h : env51144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51143_51144 : H12AffineEnvironment.transform 22 2101248 env51143 = env51144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101248 env51143 == env51144) = true)

def env51145 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,121998,115103,17664,2404637,119043,329730,257,2199999,2191387,63109]

theorem envBound51145 : H12AffineFastState.Bounded env51145 := by
  intro p hp
  have h : env51145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51144_51145 : H12AffineEnvironment.transform 21 272512 env51144 = env51145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51144 == env51145) = true)

theorem identity51145 : scanCanonicalize (H12AffineFastState.compose env51145 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound51145 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51146 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,24860,262144,1025,32769,2097152,272512,2101248,2114835,8328,17,2048,5393,17664,2404637,1421,318604,257,2114865,2139285,63109]

theorem envBound51146 : H12AffineFastState.Bounded env51146 := by
  intro p hp
  have h : env51146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51145_51146 : H12AffineEnvironment.transform 15 54414 env51145 = env51146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env51145 == env51146) = true)

theorem identity51146 : scanCanonicalize (H12AffineFastState.compose env51146 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound51146 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env51147 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24860,262144,1025,29829,2097152,272512,2101248,2114835,8328,17,2048,5393,17664,2377113,1421,272392,257,2114865,2117649,513]

theorem envBound51147 : H12AffineFastState.Bounded env51147 := by
  intro p hp
  have h : env51147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51146_51147 : H12AffineEnvironment.transform 14 29828 env51146 = env51147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env51146 == env51147) = true)

theorem identity51147 : scanCanonicalize (H12AffineFastState.compose env51147 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound51147 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env51148 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,24860,262144,1025,29829,281653,272512,285749,264486,8328,17,2048,5393,17664,2476,1421,272392,257,264452,269348,513]

theorem envBound51148 : H12AffineFastState.Bounded env51148 := by
  intro p hp
  have h : env51148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51147_51148 : H12AffineEnvironment.transform 20 281653 env51147 = env51148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env51147 == env51148) = true)

theorem identity51148 : scanCanonicalize (H12AffineFastState.compose env51148 (packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound51148 : packedSelected [0,1,2,3,5,6,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env51149 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,398,16536,262144,1025,21761,281653,264452,285749,264486,268,17,2048,5393,17664,2476,1421,264588,257,264452,269348,513]

theorem envBound51149 : H12AffineFastState.Bounded env51149 := by
  intro p hp
  have h : env51149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51148_51149 : H12AffineEnvironment.transform 12 388 env51148 = env51149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env51148 == env51149) = true)

theorem identity51149 : scanCanonicalize (H12AffineFastState.compose env51149 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound51149 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env51150 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21760,398,16536,23589,1025,21761,4112,21793,16,21763,268,17,2048,5393,17664,2476,1421,21929,257,21793,16385,513]

theorem envBound51150 : H12AffineFastState.Bounded env51150 := by
  intro p hp
  have h : env51150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51149_51150 : H12AffineEnvironment.transform 17 23589 env51149 = env51150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env51149 == env51150) = true)

theorem identity51150 : scanCanonicalize (H12AffineFastState.compose env51150 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound51150 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env51151 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,16384,21677,35,16536,23589,1025,21676,4112,21644,16,21678,161,17,2048,5308,17581,2049,1056,21508,172,21644,16385,513]

theorem envBound51151 : H12AffineFastState.Bounded env51151 := by
  intro p hp
  have h : env51151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51150_51151 : H12AffineEnvironment.transform 7 173 env51150 = env51151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51150 == env51151) = true)

theorem identity51151 : scanCanonicalize (H12AffineFastState.compose env51151 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound51151 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env51152 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,137,35,5308,2049,1025,136,4112,168,16,138,161,17,2048,5308,4233,2049,1056,32,172,168,5157,513]

theorem envBound51152 : H12AffineFastState.Bounded env51152 := by
  intro p hp
  have h : env51152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51151_51152 : H12AffineEnvironment.transform 13 5156 env51151 = env51152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env51151 == env51152) = true)

theorem identity51152 : scanCanonicalize (H12AffineFastState.compose env51152 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51152 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51153 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5173,2049,1025,1,4112,33,16,3,40,17,2048,5173,4096,2049,1056,32,37,33,5157,513]

theorem envBound51153 : H12AffineFastState.Bounded env51153 := by
  intro p hp
  have h : env51153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51152_51153 : H12AffineEnvironment.transform 6 9 env51152 = env51153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51152 == env51153) = true)

theorem identity51153 : scanCanonicalize (H12AffineFastState.compose env51153 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51153 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51154 : List Nat := [2,4,8,1,32,0,9,36,512,1024,2048,4096,41,5156,0,35,5156,2049,1025,1,4097,33,1,3,40,0,2048,5156,4096,2049,1056,32,37,33,5157,513]

theorem envBound51154 : H12AffineFastState.Bounded env51154 := by
  intro p hp
  have h : env51154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51153_51154 : H12AffineEnvironment.transform 3 1 env51153 = env51154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51153 == env51154) = true)

theorem identity51154 : scanCanonicalize (H12AffineFastState.compose env51154 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound51154 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51155 : List Nat := [2,4,8,1,32,0,9,36,0,1024,2048,4096,41,5156,0,35,5156,2049,1025,1,4097,33,1,3,40,0,2048,5156,4096,2049,1056,32,37,33,5157,1]

theorem envBound51155 : H12AffineFastState.Bounded env51155 := by
  intro p hp
  have h : env51155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51154_51155 : H12AffineEnvironment.transform 8 0 env51154 = env51155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env51154 == env51155) = true)

theorem identity51155 : scanCanonicalize (H12AffineFastState.compose env51155 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound51155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51156 : List Nat := [2,4,8,1,32,0,9,36,0,1024,2048,1060,41,0,0,35,0,2049,1025,1,1061,33,1,3,40,0,2048,0,1060,2049,1056,32,37,33,1,1]

theorem envBound51156 : H12AffineFastState.Bounded env51156 := by
  intro p hp
  have h : env51156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51155_51156 : H12AffineEnvironment.transform 11 1060 env51155 = env51156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env51155 == env51156) = true)

theorem identity51156 : scanCanonicalize (H12AffineFastState.compose env51156 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound51156 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51157 : List Nat := [2,4,8,1,32,0,9,36,0,37,2048,1,41,0,0,35,0,2049,36,1,0,33,1,3,40,0,2048,0,1,2049,5,32,37,33,1,1]

theorem envBound51157 : H12AffineFastState.Bounded env51157 := by
  intro p hp
  have h : env51157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51156_51157 : H12AffineEnvironment.transform 9 37 env51156 = env51157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env51156 == env51157) = true)

theorem identity51157 : scanCanonicalize (H12AffineFastState.compose env51157 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51157 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51158 : List Nat := [2,4,8,1,1,0,9,5,0,4,2048,1,8,0,0,2,0,2049,5,1,0,0,1,3,9,0,2048,0,1,2049,5,1,4,0,1,1]

theorem envBound51158 : H12AffineFastState.Bounded env51158 := by
  intro p hp
  have h : env51158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51157_51158 : H12AffineEnvironment.transform 4 1 env51157 = env51158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51157 == env51158) = true)

theorem identity51158 : scanCanonicalize (H12AffineFastState.compose env51158 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51158 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51159 : List Nat := [2,4,8,1,1,0,9,5,0,4,1,1,8,0,0,2,0,0,5,1,0,0,1,3,9,0,1,0,1,0,5,1,4,0,1,1]

theorem envBound51159 : H12AffineFastState.Bounded env51159 := by
  intro p hp
  have h : env51159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51158_51159 : H12AffineEnvironment.transform 10 1 env51158 = env51159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51158 == env51159) = true)

def env51160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272513,2101248,2114835,8328,17,121999,115103,17664,2404637,119043,329731,257,2199999,2191387,63109]

theorem envBound51160 : H12AffineFastState.Bounded env51160 := by
  intro p hp
  have h : env51160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51144_51160 : H12AffineEnvironment.transform 21 272513 env51144 = env51160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51144 == env51160) = true)

theorem identity51160 : scanCanonicalize (H12AffineFastState.compose env51160 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound51160 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115871,272513,119967,98700,8328,17,121999,115103,17664,357762,119043,329731,257,21792,46212,63109]

theorem envBound51161 : H12AffineFastState.Bounded env51161 := by
  intro p hp
  have h : env51161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51160_51161 : H12AffineEnvironment.transform 20 115871 env51160 = env51161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env51160 == env51161) = true)

def env51162 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115735,272393,119831,98564,8192,17,121863,114967,17664,357642,119043,329731,257,21792,46092,62989]

theorem envBound51162 : H12AffineFastState.Bounded env51162 := by
  intro p hp
  have h : env51162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51161_51162 : H12AffineEnvironment.transform 6 8 env51161 = env51162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51161 == env51162) = true)

theorem identity51162 : scanCanonicalize (H12AffineFastState.compose env51162 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51162 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env51163 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24860,262144,1025,8460,91418,272393,95514,73737,8192,17,97546,90138,17664,357642,94222,329731,257,21792,5377,22272]

theorem envBound51163 : H12AffineFastState.Bounded env51163 := by
  intro p hp
  have h : env51163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51162_51163 : H12AffineEnvironment.transform 14 8461 env51162 = env51163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env51162 == env51163) = true)

theorem identity51163 : scanCanonicalize (H12AffineFastState.compose env51163 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound51163 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env51164 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24860,2340,1025,8460,91418,8493,95514,73737,8192,17,97546,90138,17664,97326,94222,65831,257,21792,5377,22272]

theorem envBound51164 : H12AffineFastState.Bounded env51164 := by
  intro p hp
  have h : env51164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51163_51164 : H12AffineEnvironment.transform 17 2340 env51163 = env51164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env51163 == env51164) = true)

theorem identity51164 : scanCanonicalize (H12AffineFastState.compose env51164 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51164 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env51165 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8203,24860,2340,1025,8460,17681,8493,21777,2,8192,17,23809,16401,17664,23589,20485,8492,257,21792,5377,22272]

theorem envBound51165 : H12AffineFastState.Bounded env51165 := by
  intro p hp
  have h : env51165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51164_51165 : H12AffineEnvironment.transform 15 8203 env51164 = env51165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51164 == env51165) = true)

theorem identity51165 : scanCanonicalize (H12AffineFastState.compose env51165 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51165 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51166 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13325,8461,8203,5393,2340,1025,8460,12572,8493,8476,2,8192,17,10508,13340,12557,10280,9224,8492,257,8493,5377,8973]

theorem envBound51166 : H12AffineFastState.Bounded env51166 := by
  intro p hp
  have h : env51166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51165_51166 : H12AffineEnvironment.transform 13 13325 env51165 = env51166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51165 == env51166) = true)

theorem identity51166 : scanCanonicalize (H12AffineFastState.compose env51166 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51166 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51167 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4112,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound51167 : H12AffineFastState.Bounded env51167 := by
  intro p hp
  have h : env51167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51166_51167 : H12AffineEnvironment.transform 12 268 env51166 = env51167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51166 == env51167) = true)

theorem identity51167 : scanCanonicalize (H12AffineFastState.compose env51167 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51168 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,35,5173,2048,1025,0,4112,33,16,2,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound51168 : H12AffineFastState.Bounded env51168 := by
  intro p hp
  have h : env51168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51167_51168 : H12AffineEnvironment.transform 7 36 env51167 = env51168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51167 == env51168) = true)

def env51169 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1045,1,35,1029,2048,1025,0,32,33,16,2,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound51169 : H12AffineFastState.Bounded env51169 := by
  intro p hp
  have h : env51169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51168_51169 : H12AffineEnvironment.transform 11 48 env51168 = env51169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env51168 == env51169) = true)

theorem identity51169 : scanCanonicalize (H12AffineFastState.compose env51169 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound51169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51170 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,40,1045,1,35,1029,1077,1025,0,32,33,16,2,40,17,1077,1028,49,1077,1056,32,37,33,1045,513]

theorem envBound51170 : H12AffineFastState.Bounded env51170 := by
  intro p hp
  have h : env51170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51169_51170 : H12AffineEnvironment.transform 10 1077 env51169 = env51170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env51169 == env51170) = true)

def env51171 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,40,33,1,35,49,1,53,0,32,33,16,2,40,17,1,48,49,1,20,32,37,33,33,513]

theorem envBound51171 : H12AffineFastState.Bounded env51171 := by
  intro p hp
  have h : env51171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51170_51171 : H12AffineEnvironment.transform 9 52 env51170 = env51171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51170 == env51171) = true)

theorem identity51171 : scanCanonicalize (H12AffineFastState.compose env51171 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51172 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,8,1,1,3,17,1,21,0,0,1,16,2,8,17,1,16,17,1,20,0,5,1,1,513]

theorem envBound51172 : H12AffineFastState.Bounded env51172 := by
  intro p hp
  have h : env51172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51171_51172 : H12AffineEnvironment.transform 4 0 env51171 = env51172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51171 == env51172) = true)

def leafEnv51172 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,8,1,1,3,17,1,21,0,0,1,16,2,21,8,1,17,1,16,17,1,20,0,5,1,5,3,1,513,1,0,0]

def active51172 : List Nat := [0,1,2,3,8]

def tree51172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51172 : H12WitnessSearch.Good tree51172 := H12GlobalWitnessIndex.good

theorem leafIdentity51172 : H12AffineFastState.composeSystem env51172 rootObs = leafEnv51172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51172 rootObs == leafEnv51172) = true)

theorem terminalChecked51172 : H12PackedTerminal.terminalCheckFast leafEnv51172 active51172 tree51172 = true := by decide +kernel

def env51173 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,32,1,35,48,0,52,0,32,33,16,2,40,17,0,49,49,0,21,32,37,33,32,513]

theorem envBound51173 : H12AffineFastState.Bounded env51173 := by
  intro p hp
  have h : env51173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51170_51173 : H12AffineEnvironment.transform 9 53 env51170 = env51173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51170 == env51173) = true)

theorem identity51173 : scanCanonicalize (H12AffineFastState.compose env51173 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51174 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,40,32,1,35,48,0,52,0,32,33,16,2,40,17,0,49,49,0,21,32,37,33,32,11]

theorem envBound51174 : H12AffineFastState.Bounded env51174 := by
  intro p hp
  have h : env51174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51173_51174 : H12AffineEnvironment.transform 8 10 env51173 = env51174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51173 == env51174) = true)

def leafEnv51174 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,40,32,1,35,48,0,52,0,32,33,16,2,20,40,1,17,0,49,49,0,21,32,37,33,5,35,32,11,1,32,0]

def active51174 : List Nat := [0,1,2,3,4]

def tree51174 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

end H12CloudChart1