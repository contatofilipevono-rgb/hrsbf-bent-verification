import H12CloudChart1Data146

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity37275 : scanCanonicalize (H12AffineFastState.compose env37275 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37275 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env37276 : List Nat := [2,4,8,16,32,49,41,37,512,53,561,512,9,528,0,34,513,529,53,1,561,33,16,3,40,48,528,512,513,529,21,33,37,32,528,545]

theorem envBound37276 : H12AffineFastState.Bounded env37276 := by
  intro p hp
  have h : env37276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37275_37276 : H12AffineEnvironment.transform 7 37 env37275 = env37276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37275 == env37276) = true)

theorem identity37276 : scanCanonicalize (H12AffineFastState.compose env37276 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37276 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env37277 : List Nat := [2,4,8,16,17,0,24,20,512,4,512,512,9,528,0,19,513,529,4,1,512,16,16,3,25,1,528,512,513,529,21,16,20,17,528,528]

theorem envBound37277 : H12AffineFastState.Bounded env37277 := by
  intro p hp
  have h : env37277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37276_37277 : H12AffineEnvironment.transform 4 17 env37276 = env37277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37276 == env37277) = true)

theorem identity37277 : scanCanonicalize (H12AffineFastState.compose env37277 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37278 : List Nat := [2,4,8,16,17,0,24,20,17,4,17,17,9,1,0,19,16,0,4,1,17,16,16,3,25,1,1,17,16,0,21,16,20,17,1,1]

theorem envBound37278 : H12AffineFastState.Bounded env37278 := by
  intro p hp
  have h : env37278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37277_37278 : H12AffineEnvironment.transform 8 17 env37277 = env37278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37277 == env37278) = true)

def env37279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400500,499129,8328,65,295421,395636,416100,56437,1500,272393,256,21792,46213,74251]

theorem envBound37279 : H12AffineFastState.Bounded env37279 := by
  intro p hp
  have h : env37279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37228_37279 : H12AffineEnvironment.transform 20 4161 env37228 = env37279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37228 == env37279) = true)

theorem identity37279 : scanCanonicalize (H12AffineFastState.compose env37279 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound37279 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,180272,62661,95496,8328,65,158028,57797,45525,56437,1500,180408,256,21792,46213,74251]

theorem envBound37280 : H12AffineFastState.Bounded env37280 := by
  intro p hp
  have h : env37280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37279_37280 : H12AffineEnvironment.transform 17 190641 env37279 = env37280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env37279 == env37280) = true)

theorem identity37280 : scanCanonicalize (H12AffineFastState.compose env37280 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37280 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1024,32769,4161,180272,62661,21762,8328,65,158028,57797,45525,56437,1500,180408,256,21792,46213,513]

theorem envBound37281 : H12AffineFastState.Bounded env37281 := by
  intro p hp
  have h : env37281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37280_37281 : H12AffineEnvironment.transform 15 8202 env37280 = env37281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37280 == env37281) = true)

theorem identity37281 : scanCanonicalize (H12AffineFastState.compose env37281 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound37281 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8202,131072,138477,1024,29789,4161,144492,153,21762,8328,65,158028,5529,17801,10281,1500,144612,256,21792,16601,513]

theorem envBound37282 : H12AffineFastState.Bounded env37282 := by
  intro p hp
  have h : env37282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37281_37282 : H12AffineEnvironment.transform 14 29788 env37281 = env37282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env37281 == env37282) = true)

theorem identity37282 : scanCanonicalize (H12AffineFastState.compose env37282 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5576) := by decide +kernel

theorem selectedBound37282 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env37283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8202,5576,2341,1024,29789,4161,8612,153,21762,8328,65,31876,5529,17801,10281,1500,8492,256,21792,16601,513]

theorem envBound37283 : H12AffineFastState.Bounded env37283 := by
  intro p hp
  have h : env37283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37282_37283 : H12AffineEnvironment.transform 16 5576 env37282 = env37283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5576 env37282 == env37283) = true)

theorem identity37283 : scanCanonicalize (H12AffineFastState.compose env37283 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37283 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env37284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21896,478,5576,2341,1024,21897,4161,112,153,21762,348,65,23888,5529,17801,2557,1500,248,256,21792,16601,513]

theorem envBound37284 : H12AffineFastState.Bounded env37284 := by
  intro p hp
  have h : env37284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37283_37284 : H12AffineEnvironment.transform 12 468 env37283 = env37284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37283 == env37284) = true)

theorem identity37284 : scanCanonicalize (H12AffineFastState.compose env37284 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound37284 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env37285 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,16384,21840,262,5392,2341,1024,21841,4161,112,65,21762,348,65,23888,5441,17745,2341,1284,32,256,21792,16385,513]

theorem envBound37285 : H12AffineFastState.Bounded env37285 := by
  intro p hp
  have h : env37285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37284_37285 : H12AffineEnvironment.transform 6 88 env37284 = env37285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env37284 == env37285) = true)

theorem identity37285 : scanCanonicalize (H12AffineFastState.compose env37285 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37285 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37286 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,262,5392,2341,1024,21760,4112,33,16,21762,269,16,23809,5392,17664,2341,1284,32,256,21792,16385,513]

theorem envBound37286 : H12AffineFastState.Bounded env37286 := by
  intro p hp
  have h : env37286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37285_37286 : H12AffineEnvironment.transform 5 17 env37285 = env37286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37285 == env37286) = true)

theorem identity37286 : scanCanonicalize (H12AffineFastState.compose env37286 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37286 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37287 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1024,1,4112,33,16,3,269,16,2048,5392,4097,2341,1284,32,256,33,5376,513]

theorem envBound37287 : H12AffineFastState.Bounded env37287 := by
  intro p hp
  have h : env37287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37286_37287 : H12AffineEnvironment.transform 13 5377 env37286 = env37287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37286 == env37287) = true)

theorem identity37287 : scanCanonicalize (H12AffineFastState.compose env37287 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37288 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,41,5156,0,35,5173,2048,1024,1,4112,33,16,3,40,16,2048,5173,4097,2048,1057,32,37,33,5157,513]

theorem envBound37288 : H12AffineFastState.Bounded env37288 := by
  intro p hp
  have h : env37288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37287_37288 : H12AffineEnvironment.transform 7 37 env37287 = env37288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37287 == env37288) = true)

theorem identity37288 : scanCanonicalize (H12AffineFastState.compose env37288 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37288 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37289 : List Nat := [2,4,8,16,32,17,9,37,512,1024,522,4096,41,5156,0,35,5173,522,1024,1,4112,33,16,3,40,16,522,5173,4097,522,1057,32,37,33,5157,513]

theorem envBound37289 : H12AffineFastState.Bounded env37289 := by
  intro p hp
  have h : env37289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37288_37289 : H12AffineEnvironment.transform 10 522 env37288 = env37289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37288 == env37289) = true)

theorem identity37289 : scanCanonicalize (H12AffineFastState.compose env37289 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37289 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37290 : List Nat := [2,4,8,16,0,17,9,5,512,1024,522,4096,9,5124,0,3,5141,522,1024,1,4112,1,16,3,8,16,522,5141,4097,522,1025,0,5,1,5125,513]

theorem envBound37290 : H12AffineFastState.Bounded env37290 := by
  intro p hp
  have h : env37290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37289_37290 : H12AffineEnvironment.transform 4 0 env37289 = env37290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37289 == env37290) = true)

def env37291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493493,499129,8328,65,2396605,2496821,416100,2149428,2102685,2373705,256,21792,46213,2175562]

theorem envBound37291 : H12AffineFastState.Bounded env37291 := by
  intro p hp
  have h : env37291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37227_37291 : H12AffineEnvironment.transform 21 180273 env37227 = env37291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env37227 == env37291) = true)

def env37292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400501,499129,8328,65,295421,395637,416100,56436,1501,272393,256,21792,46213,74250]

theorem envBound37292 : H12AffineFastState.Bounded env37292 := by
  intro p hp
  have h : env37292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37291_37292 : H12AffineEnvironment.transform 20 4160 env37291 = env37292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37291 == env37292) = true)

theorem identity37292 : scanCanonicalize (H12AffineFastState.compose env37292 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound37292 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180273,16,98780,8328,65,171416,5392,17665,56436,1501,144492,256,21792,46213,74250]

theorem envBound37293 : H12AffineFastState.Bounded env37293 := by
  intro p hp
  have h : env37293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37292_37293 : H12AffineEnvironment.transform 17 138341 env37292 = env37293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env37292 == env37293) = true)

def env37294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180273,16,98644,8192,65,171280,5392,17665,56436,1365,144492,256,21792,46093,74250]

theorem envBound37294 : H12AffineFastState.Bounded env37294 := by
  intro p hp
  have h : env37294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37293_37294 : H12AffineEnvironment.transform 6 8 env37293 = env37294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37293 == env37294) = true)

theorem identity37294 : scanCanonicalize (H12AffineFastState.compose env37294 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound37294 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1024,32769,4160,21792,16,98644,8192,65,2049,5392,17665,56436,1365,41341,256,21792,46093,74250]

theorem envBound37295 : H12AffineFastState.Bounded env37295 := by
  intro p hp
  have h : env37295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37294_37295 : H12AffineEnvironment.transform 16 38161 env37294 = env37295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env37294 == env37295) = true)

theorem identity37295 : scanCanonicalize (H12AffineFastState.compose env37295 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37295 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35188,1024,32769,4160,33,16,98644,8192,65,2049,5392,4096,35189,1365,41341,256,33,46093,74250]

theorem envBound37296 : H12AffineFastState.Bounded env37296 := by
  intro p hp
  have h : env37296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37295_37296 : H12AffineEnvironment.transform 13 5377 env37295 = env37296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37295 == env37296) = true)

theorem identity37296 : scanCanonicalize (H12AffineFastState.compose env37296 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound37296 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,41050,38161,35188,1024,32769,4160,33,16,8462,8192,65,2049,5392,4096,35189,1365,41341,256,33,46093,33360]

theorem envBound37297 : H12AffineFastState.Bounded env37297 := by
  intro p hp
  have h : env37297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37296_37297 : H12AffineEnvironment.transform 15 41050 env37296 = env37297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env37296 == env37297) = true)

theorem identity37297 : scanCanonicalize (H12AffineFastState.compose env37297 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound37297 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env37298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,32768,32802,38161,35188,1024,32769,4160,33,16,374,120,65,2049,5392,4096,35189,1365,33029,256,33,38005,33360]

theorem envBound37298 : H12AffineFastState.Bounded env37298 := by
  intro p hp
  have h : env37298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37297_37298 : H12AffineEnvironment.transform 12 120 env37297 = env37298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env37297 == env37298) = true)

theorem identity37298 : scanCanonicalize (H12AffineFastState.compose env37298 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37298 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5377,1,35,5392,2421,1024,0,4160,33,16,374,120,65,2049,5392,4096,2420,1365,260,256,33,5236,593]

theorem envBound37299 : H12AffineFastState.Bounded env37299 := by
  intro p hp
  have h : env37299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37298_37299 : H12AffineEnvironment.transform 14 1 env37298 = env37299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37298 == env37299) = true)

theorem identity37299 : scanCanonicalize (H12AffineFastState.compose env37299 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37299 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env37300 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5377,1,35,5392,2340,1024,0,4113,33,16,295,41,16,2049,5392,4096,2341,1284,260,256,33,5157,512]

theorem envBound37300 : H12AffineFastState.Bounded env37300 := by
  intro p hp
  have h : env37300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37299_37300 : H12AffineEnvironment.transform 5 17 env37299 = env37300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37299 == env37300) = true)

theorem identity37300 : scanCanonicalize (H12AffineFastState.compose env37300 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound37300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37301 : List Nat := [2,4,8,16,32,17,8,256,33,1024,2048,4096,41,5377,1,35,5392,2340,1024,0,4113,33,16,295,41,16,2049,5392,4096,2341,1284,260,256,33,5157,33]

theorem envBound37301 : H12AffineFastState.Bounded env37301 := by
  intro p hp
  have h : env37301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37300_37301 : H12AffineEnvironment.transform 8 33 env37300 = env37301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env37300 == env37301) = true)

theorem identity37301 : scanCanonicalize (H12AffineFastState.compose env37301 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37301 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37302 : List Nat := [2,4,8,16,0,17,8,256,1,1024,2048,4096,9,5377,1,3,5392,2308,1024,0,4113,1,16,263,9,16,2049,5392,4096,2309,1284,260,256,1,5125,1]

theorem envBound37302 : H12AffineFastState.Bounded env37302 := by
  intro p hp
  have h : env37302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37301_37302 : H12AffineEnvironment.transform 4 0 env37301 = env37302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37301 == env37302) = true)

theorem identity37302 : scanCanonicalize (H12AffineFastState.compose env37302 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound37302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37303 : List Nat := [2,4,8,16,0,17,8,256,1,1024,2048,1044,9,277,1,3,260,2308,1024,0,1029,1,16,263,9,16,2049,260,1044,2309,1284,260,256,1,17,1]

theorem envBound37303 : H12AffineFastState.Bounded env37303 := by
  intro p hp
  have h : env37303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37302_37303 : H12AffineEnvironment.transform 11 1044 env37302 = env37303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env37302 == env37303) = true)

theorem identity37303 : scanCanonicalize (H12AffineFastState.compose env37303 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37303 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37304 : List Nat := [2,4,8,16,0,17,8,4,1,1024,2048,1044,9,17,1,3,0,2048,1024,0,1029,1,16,3,9,16,2049,0,1044,2049,1024,0,4,1,17,1]

theorem envBound37304 : H12AffineFastState.Bounded env37304 := by
  intro p hp
  have h : env37304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37303_37304 : H12AffineEnvironment.transform 7 4 env37303 = env37304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37303 == env37304) = true)

theorem identity37304 : scanCanonicalize (H12AffineFastState.compose env37304 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37304 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37305 : List Nat := [2,4,8,16,0,17,8,4,1,20,2048,0,9,17,1,3,0,2048,20,0,17,1,16,3,9,16,2049,0,0,2049,20,0,4,1,17,1]

theorem envBound37305 : H12AffineFastState.Bounded env37305 := by
  intro p hp
  have h : env37305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37304_37305 : H12AffineEnvironment.transform 9 20 env37304 = env37305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37304 == env37305) = true)

theorem identity37305 : scanCanonicalize (H12AffineFastState.compose env37305 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37306 : List Nat := [2,4,8,0,0,1,8,4,1,4,2048,0,9,1,1,3,0,2048,4,0,1,1,0,3,9,0,2049,0,0,2049,4,0,4,1,1,1]

theorem envBound37306 : H12AffineFastState.Bounded env37306 := by
  intro p hp
  have h : env37306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37305_37306 : H12AffineEnvironment.transform 3 0 env37305 = env37306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37305 == env37306) = true)

theorem identity37306 : scanCanonicalize (H12AffineFastState.compose env37306 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37307 : List Nat := [2,1,8,0,0,1,8,1,1,1,2048,0,9,1,1,3,0,2048,1,0,1,1,0,3,9,0,2049,0,0,2049,1,0,1,1,1,1]

theorem envBound37307 : H12AffineFastState.Bounded env37307 := by
  intro p hp
  have h : env37307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37306_37307 : H12AffineEnvironment.transform 1 1 env37306 = env37307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37306 == env37307) = true)

def env37308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180273,16,98645,8193,65,171281,5392,17665,56436,1364,144492,256,21792,46092,74250]

theorem envBound37308 : H12AffineFastState.Bounded env37308 := by
  intro p hp
  have h : env37308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37293_37308 : H12AffineEnvironment.transform 6 9 env37293 = env37308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37293 == env37308) = true)

theorem identity37308 : scanCanonicalize (H12AffineFastState.compose env37308 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound37308 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1024,32769,4160,62589,16,98645,8193,65,43357,5392,17665,56436,1364,32,256,21792,46092,74250]

theorem envBound37309 : H12AffineFastState.Bounded env37309 := by
  intro p hp
  have h : env37309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37308_37309 : H12AffineEnvironment.transform 16 13388 env37308 = env37309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env37308 == env37309) = true)

theorem identity37309 : scanCanonicalize (H12AffineFastState.compose env37309 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound37309 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env37310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1024,29789,4160,33,16,95497,8193,65,23809,5392,17665,10280,1364,32,256,21792,16464,74250]

theorem envBound37310 : H12AffineFastState.Bounded env37310 := by
  intro p hp
  have h : env37310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37309_37310 : H12AffineEnvironment.transform 14 29788 env37309 = env37310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env37309 == env37310) = true)

theorem identity37310 : scanCanonicalize (H12AffineFastState.compose env37310 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound37310 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,21590,13388,10281,1024,29789,4160,33,16,8543,8193,65,23809,5392,17665,10280,1364,32,256,21792,16464,30300]

theorem envBound37311 : H12AffineFastState.Bounded env37311 := by
  intro p hp
  have h : env37311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37310_37311 : H12AffineEnvironment.transform 15 21590 env37310 = env37311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env37310 == env37311) = true)

theorem identity37311 : scanCanonicalize (H12AffineFastState.compose env37311 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37311 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env37312 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,21511,13341,10281,1024,29708,4113,33,16,8462,8193,16,23809,5392,17665,10280,1285,32,256,21792,16385,30221]

theorem envBound37312 : H12AffineFastState.Bounded env37312 := by
  intro p hp
  have h : env37312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37311_37312 : H12AffineEnvironment.transform 5 17 env37311 = env37312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37311 == env37312) = true)

def env37313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400500,499129,8328,65,295420,395636,416100,56437,1500,272392,256,21792,46213,74251]

theorem envBound37313 : H12AffineFastState.Bounded env37313 := by
  intro p hp
  have h : env37313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37291_37313 : H12AffineEnvironment.transform 20 4161 env37291 = env37313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37291 == env37313) = true)

theorem identity37313 : scanCanonicalize (H12AffineFastState.compose env37313 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37313 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4161,144612,400500,485740,8328,65,292137,395636,416100,10400,1500,272392,256,21792,16464,74251]

theorem envBound37314 : H12AffineFastState.Bounded env37314 := by
  intro p hp
  have h : env37314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37313_37314 : H12AffineEnvironment.transform 14 29909 env37313 = env37314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37313 == env37314) = true)

def env37315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144492,400500,485740,8192,65,292137,395636,416100,10280,1364,272392,256,21792,16464,74251]

theorem envBound37315 : H12AffineFastState.Bounded env37315 := by
  intro p hp
  have h : env37315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37314_37315 : H12AffineEnvironment.transform 6 8 env37314 = env37315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37314 == env37315) = true)

theorem identity37315 : scanCanonicalize (H12AffineFastState.compose env37315 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound37315 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,215090,1024,29788,4161,144492,87110,8542,8192,65,212251,82246,69974,10280,1364,221242,256,21792,16464,74251]

theorem envBound37316 : H12AffineFastState.Bounded env37316 := by
  intro p hp
  have h : env37316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37315_37316 : H12AffineEnvironment.transform 17 215090 env37315 = env37316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env37315 == env37316) = true)

theorem identity37316 : scanCanonicalize (H12AffineFastState.compose env37316 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37316 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,16400,67618,1024,29788,4161,29820,87110,8542,8192,65,97547,82246,69974,10280,1364,73770,256,21792,16464,74251]

theorem envBound37317 : H12AffineFastState.Bounded env37317 := by
  intro p hp
  have h : env37317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37316_37317 : H12AffineEnvironment.transform 16 16400 env37316 = env37317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37316 == env37317) = true)

theorem identity37317 : scanCanonicalize (H12AffineFastState.compose env37317 (packedSelected [0,1,4,7,8,9,10,11,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound37317 : packedSelected [0,1,4,7,8,9,10,11,15,17,20] rootPS < 2^1333 := by decide +kernel

def env37318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,65536,5441,67618,1024,8461,4161,8493,65815,8542,8192,65,75866,70679,69974,10280,1364,73770,256,113,5377,74251]

theorem envBound37318 : H12AffineFastState.Bounded env37318 := by
  intro p hp
  have h : env37318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37317_37318 : H12AffineEnvironment.transform 13 5457 env37317 = env37318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env37317 == env37318) = true)

theorem identity37318 : scanCanonicalize (H12AffineFastState.compose env37318 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37318 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37319 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5237,8232,65536,5221,67618,1024,8233,4161,8201,65587,8314,8192,65,75866,70679,69746,10280,1136,73770,36,113,5157,74251]

theorem envBound37319 : H12AffineFastState.Bounded env37319 := by
  intro p hp
  have h : env37319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37318_37319 : H12AffineEnvironment.transform 7 36 env37318 = env37319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37318 == env37319) = true)

theorem identity37319 : scanCanonicalize (H12AffineFastState.compose env37319 (packedSelected [1,2,4,6,8,9,10,11,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37319 : packedSelected [1,2,4,6,8,9,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env37320 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,81,65536,5221,67618,1024,80,4161,112,65587,3,121,65,67619,70679,69746,2129,1136,65619,36,113,5157,66162]

theorem envBound37320 : H12AffineFastState.Bounded env37320 := by
  intro p hp
  have h : env37320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37319_37320 : H12AffineEnvironment.transform 12 121 env37319 = env37320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37319 == env37320) = true)

theorem identity37320 : scanCanonicalize (H12AffineFastState.compose env37320 (packedSelected [0,2,4,6,7,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound37320 : packedSelected [0,2,4,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37321 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,81,1094,5221,3172,1024,80,4161,112,1141,3,121,65,3173,4177,5172,2129,1136,1045,36,113,5157,1588]

theorem envBound37321 : H12AffineFastState.Bounded env37321 := by
  intro p hp
  have h : env37321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37320_37321 : H12AffineEnvironment.transform 15 1094 env37320 = env37321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env37320 == env37321) = true)

theorem identity37321 : scanCanonicalize (H12AffineFastState.compose env37321 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37321 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37322 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,4096,121,4112,81,35,4096,2049,101,80,4161,112,16,3,121,65,2048,4177,4177,2129,21,112,36,113,4160,593]

theorem envBound37322 : H12AffineFastState.Bounded env37322 := by
  intro p hp
  have h : env37322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37321_37322 : H12AffineEnvironment.transform 9 101 env37321 = env37322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37321 == env37322) = true)

theorem identity37322 : scanCanonicalize (H12AffineFastState.compose env37322 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37322 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37323 : List Nat := [2,4,8,16,1,64,8,5,512,68,2048,4096,88,4112,81,2,4096,2049,68,80,4161,81,16,3,88,65,2048,4177,4177,2129,21,81,5,80,4160,593]

theorem envBound37323 : H12AffineFastState.Bounded env37323 := by
  intro p hp
  have h : env37323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37322_37323 : H12AffineEnvironment.transform 4 1 env37322 = env37323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37322 == env37323) = true)

theorem identity37323 : scanCanonicalize (H12AffineFastState.compose env37323 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37323 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env37324 : List Nat := [2,4,8,16,1,16,8,5,512,20,2048,4096,8,4112,1,2,4096,2049,20,0,4113,1,16,3,8,17,2048,4097,4097,2049,21,1,5,0,4112,513]

theorem envBound37324 : H12AffineFastState.Bounded env37324 := by
  intro p hp
  have h : env37324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37323_37324 : H12AffineEnvironment.transform 5 16 env37323 = env37324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37323 == env37324) = true)

theorem identity37324 : scanCanonicalize (H12AffineFastState.compose env37324 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37324 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37325 : List Nat := [2,4,8,16,1,16,8,5,17,20,2048,4096,8,4112,1,2,4096,2049,20,0,4113,1,16,3,8,17,2048,4097,4097,2049,21,1,5,0,4112,16]

theorem envBound37325 : H12AffineFastState.Bounded env37325 := by
  intro p hp
  have h : env37325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37324_37325 : H12AffineEnvironment.transform 8 17 env37324 = env37325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37324 == env37325) = true)

theorem identity37325 : scanCanonicalize (H12AffineFastState.compose env37325 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound37325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37326 : List Nat := [2,4,8,16,1,16,8,5,17,20,2048,2049,8,2065,1,2,2049,2049,20,0,2064,1,16,3,8,17,2048,2048,2048,2049,21,1,5,0,2065,16]

theorem envBound37326 : H12AffineFastState.Bounded env37326 := by
  intro p hp
  have h : env37326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37325_37326 : H12AffineEnvironment.transform 11 2049 env37325 = env37326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env37325 == env37326) = true)

theorem identity37326 : scanCanonicalize (H12AffineFastState.compose env37326 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37327 : List Nat := [2,4,8,16,1,16,8,5,17,20,1,0,8,16,1,2,0,0,20,0,17,1,16,3,8,17,1,1,1,0,21,1,5,0,16,16]

theorem envBound37327 : H12AffineFastState.Bounded env37327 := by
  intro p hp
  have h : env37327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37326_37327 : H12AffineEnvironment.transform 10 1 env37326 = env37327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37326 == env37327) = true)

theorem identity37327 : scanCanonicalize (H12AffineFastState.compose env37327 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37327 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37328 : List Nat := [2,4,8,1,1,1,8,5,0,5,1,0,8,1,1,2,0,0,5,0,0,1,1,3,8,0,1,1,1,0,4,1,5,0,1,1]

theorem envBound37328 : H12AffineFastState.Bounded env37328 := by
  intro p hp
  have h : env37328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37327_37328 : H12AffineEnvironment.transform 3 1 env37327 = env37328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37327 == env37328) = true)

def env37329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,400500,485740,8193,65,292137,395636,416100,10281,1365,272392,256,21792,16464,74251]

theorem envBound37329 : H12AffineFastState.Bounded env37329 := by
  intro p hp
  have h : env37329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37314_37329 : H12AffineEnvironment.transform 6 9 env37314 = env37329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37314 == env37329) = true)

theorem identity37329 : scanCanonicalize (H12AffineFastState.compose env37329 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound37329 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5440,262144,1024,29789,4161,8493,264500,359468,8193,65,292137,269364,281636,10281,1365,272392,256,21792,16464,74251]

theorem envBound37330 : H12AffineFastState.Bounded env37330 := by
  intro p hp
  have h : env37330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37329_37330 : H12AffineEnvironment.transform 16 5440 env37329 = env37330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env37329 == env37330) = true)

theorem identity37330 : scanCanonicalize (H12AffineFastState.compose env37330 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound37330 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env37331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,5440,89459,1024,29789,4161,8493,87111,8543,8193,65,75866,82247,69975,10281,1365,95611,256,21792,16464,74251]

theorem envBound37331 : H12AffineFastState.Bounded env37331 := by
  intro p hp
  have h : env37331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37330_37331 : H12AffineEnvironment.transform 17 89459 env37330 = env37331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env37330 == env37331) = true)

theorem identity37331 : scanCanonicalize (H12AffineFastState.compose env37331 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37331 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37332 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,5392,89379,1024,29709,4113,8493,87063,8463,8193,17,75786,82199,69895,10281,1285,95531,256,21792,16384,74251]

theorem envBound37332 : H12AffineFastState.Bounded env37332 := by
  intro p hp
  have h : env37332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37331_37332 : H12AffineEnvironment.transform 5 16 env37331 = env37332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37331 == env37332) = true)

theorem identity37332 : scanCanonicalize (H12AffineFastState.compose env37332 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound37332 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env37333 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,29962,5392,10281,1024,29709,4113,8493,8477,8463,8193,17,23808,13341,25613,10281,1285,33,256,21792,16384,22273]

theorem envBound37333 : H12AffineFastState.Bounded env37333 := by
  intro p hp
  have h : env37333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37332_37333 : H12AffineEnvironment.transform 15 29962 env37332 = env37333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env37332 == env37333) = true)

theorem identity37333 : scanCanonicalize (H12AffineFastState.compose env37333 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37333 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37334 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,8202,5392,10281,1024,8461,4113,8493,8477,8463,8193,17,2048,13341,12557,10281,1285,33,256,32,5376,513]

theorem envBound37334 : H12AffineFastState.Bounded env37334 := by
  intro p hp
  have h : env37334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37333_37334 : H12AffineEnvironment.transform 13 5376 env37333 = env37334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37333 == env37334) = true)

theorem identity37334 : scanCanonicalize (H12AffineFastState.compose env37334 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37334 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37335 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1024,1,4113,33,17,3,269,17,2048,5393,4097,2341,1285,33,256,32,5376,513]

theorem envBound37335 : H12AffineFastState.Bounded env37335 := by
  intro p hp
  have h : env37335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37334_37335 : H12AffineEnvironment.transform 12 268 env37334 = env37335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37334 == env37335) = true)

theorem identity37335 : scanCanonicalize (H12AffineFastState.compose env37335 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37336 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4113,33,17,3,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound37336 : H12AffineFastState.Bounded env37336 := by
  intro p hp
  have h : env37336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37335_37336 : H12AffineEnvironment.transform 7 36 env37335 = env37336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37335 == env37336) = true)

def env37337 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1044,0,34,1028,2049,1024,1,33,33,17,3,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound37337 : H12AffineFastState.Bounded env37337 := by
  intro p hp
  have h : env37337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37336_37337 : H12AffineEnvironment.transform 11 48 env37336 = env37337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37336 == env37337) = true)

theorem identity37337 : scanCanonicalize (H12AffineFastState.compose env37337 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37338 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,17,9,1044,0,3,1028,2049,1024,1,0,0,17,3,8,17,2048,1029,16,2049,1024,0,5,1,1044,513]

theorem envBound37338 : H12AffineFastState.Bounded env37338 := by
  intro p hp
  have h : env37338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37337_37338 : H12AffineEnvironment.transform 4 1 env37337 = env37338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37337 == env37338) = true)

def env37339 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,17,9,0,0,3,16,2049,20,1,0,0,17,3,8,17,2048,17,16,2049,20,0,5,1,0,513]

theorem envBound37339 : H12AffineFastState.Bounded env37339 := by
  intro p hp
  have h : env37339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37338_37339 : H12AffineEnvironment.transform 9 20 env37338 = env37339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37338 == env37339) = true)

theorem identity37339 : scanCanonicalize (H12AffineFastState.compose env37339 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37340 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,9,0,0,3,16,1,20,1,0,0,17,3,8,17,0,17,16,1,20,0,5,1,0,513]

theorem envBound37340 : H12AffineFastState.Bounded env37340 := by
  intro p hp
  have h : env37340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37339_37340 : H12AffineEnvironment.transform 10 0 env37339 = env37340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37339 == env37340) = true)

def leafEnv37340 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,17,9,0,0,3,16,1,20,1,0,0,17,3,20,8,1,17,0,17,16,1,20,0,5,1,4,2,0,513,1,0,0]

def active37340 : List Nat := [0,1,2,3,8]

def tree37340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37340 : H12WitnessSearch.Good tree37340 := H12GlobalWitnessIndex.good

theorem leafIdentity37340 : H12AffineFastState.composeSystem env37340 rootObs = leafEnv37340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37340 rootObs == leafEnv37340) = true)

theorem terminalChecked37340 : H12PackedTerminal.terminalCheckFast leafEnv37340 active37340 tree37340 = true := by decide +kernel

def env37341 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,17,9,1,0,3,17,2049,21,1,0,0,17,3,8,17,2048,16,16,2049,21,0,5,1,1,513]

theorem envBound37341 : H12AffineFastState.Bounded env37341 := by
  intro p hp
  have h : env37341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37338_37341 : H12AffineEnvironment.transform 9 21 env37338 = env37341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37338 == env37341) = true)

theorem identity37341 : scanCanonicalize (H12AffineFastState.compose env37341 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37342 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,17,9,1,0,3,17,523,21,1,0,0,17,3,8,17,522,16,16,523,21,0,5,1,1,513]

theorem envBound37342 : H12AffineFastState.Bounded env37342 := by
  intro p hp
  have h : env37342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37341_37342 : H12AffineEnvironment.transform 10 522 env37341 = env37342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37341 == env37342) = true)

def leafEnv37342 : List Nat := [2,4,8,16,1,16,9,5,512,21,522,17,9,1,0,3,17,523,21,1,0,0,17,3,21,8,1,17,522,16,16,523,21,0,5,1,4,2,1,513,1,0,0]

def active37342 : List Nat := [0,1,2,3,8]

def tree37342 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37342 : H12WitnessSearch.Good tree37342 := H12GlobalWitnessIndex.good

theorem leafIdentity37342 : H12AffineFastState.composeSystem env37342 rootObs = leafEnv37342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37342 rootObs == leafEnv37342) = true)

theorem terminalChecked37342 : H12PackedTerminal.terminalCheckFast leafEnv37342 active37342 tree37342 = true := by decide +kernel

def env37343 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1045,0,34,1029,2049,1024,1,32,33,17,3,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound37343 : H12AffineFastState.Bounded env37343 := by
  intro p hp
  have h : env37343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37336_37343 : H12AffineEnvironment.transform 11 49 env37336 = env37343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37336 == env37343) = true)

theorem identity37343 : scanCanonicalize (H12AffineFastState.compose env37343 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37344 : List Nat := [2,4,8,16,32,16,9,36,512,20,2048,49,40,1,0,34,17,2049,20,1,32,33,17,3,41,17,2048,16,48,2049,53,33,36,32,1,513]

theorem envBound37344 : H12AffineFastState.Bounded env37344 := by
  intro p hp
  have h : env37344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37343_37344 : H12AffineEnvironment.transform 9 20 env37343 = env37344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37343 == env37344) = true)

def env37345 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,17,8,1,0,2,17,2049,20,1,0,1,17,3,9,17,2048,16,16,2049,21,1,4,0,1,513]

theorem envBound37345 : H12AffineFastState.Bounded env37345 := by
  intro p hp
  have h : env37345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37344_37345 : H12AffineEnvironment.transform 4 0 env37344 = env37345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37344 == env37345) = true)

theorem identity37345 : scanCanonicalize (H12AffineFastState.compose env37345 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37345 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37346 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,17,8,1,0,2,17,523,20,1,0,1,17,3,9,17,522,16,16,523,21,1,4,0,1,513]

theorem envBound37346 : H12AffineFastState.Bounded env37346 := by
  intro p hp
  have h : env37346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37345_37346 : H12AffineEnvironment.transform 10 522 env37345 = env37346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37345 == env37346) = true)

def leafEnv37346 : List Nat := [2,4,8,16,0,16,9,4,512,20,522,17,8,1,0,2,17,523,20,1,0,1,17,3,21,9,1,17,522,16,16,523,21,1,4,0,4,3,1,513,1,0,0]

def active37346 : List Nat := [0,1,2,3,8]

def tree37346 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37346 : H12WitnessSearch.Good tree37346 := H12GlobalWitnessIndex.good

theorem leafIdentity37346 : H12AffineFastState.composeSystem env37346 rootObs = leafEnv37346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37346 rootObs == leafEnv37346) = true)

theorem terminalChecked37346 : H12PackedTerminal.terminalCheckFast leafEnv37346 active37346 tree37346 = true := by decide +kernel

def env37347 : List Nat := [2,4,8,16,1,16,9,5,512,20,2048,16,9,1,0,3,17,2049,20,1,1,0,17,3,8,17,2048,16,17,2049,20,0,5,1,1,513]

theorem envBound37347 : H12AffineFastState.Bounded env37347 := by
  intro p hp
  have h : env37347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37344_37347 : H12AffineEnvironment.transform 4 1 env37344 = env37347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37344 == env37347) = true)

theorem identity37347 : scanCanonicalize (H12AffineFastState.compose env37347 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37347 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37348 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,9,1,0,3,17,0,20,1,1,0,17,3,8,17,1,16,17,0,20,0,5,1,1,513]

theorem envBound37348 : H12AffineFastState.Bounded env37348 := by
  intro p hp
  have h : env37348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37347_37348 : H12AffineEnvironment.transform 10 1 env37347 = env37348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37347 == env37348) = true)

def leafEnv37348 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,16,9,1,0,3,17,0,20,1,1,0,17,3,20,8,1,17,1,16,17,0,20,0,5,1,4,2,1,513,1,1,0]

def active37348 : List Nat := [0,1,2,3,8]

def tree37348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37348 : H12WitnessSearch.Good tree37348 := H12GlobalWitnessIndex.good

theorem leafIdentity37348 : H12AffineFastState.composeSystem env37348 rootObs = leafEnv37348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37348 rootObs == leafEnv37348) = true)

theorem terminalChecked37348 : H12PackedTerminal.terminalCheckFast leafEnv37348 active37348 tree37348 = true := by decide +kernel

def env37349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound37349 : H12AffineFastState.Bounded env37349 := by
  intro p hp
  have h : env37349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37114_37349 : H12AffineEnvironment.transform 18 1025 env37114 = env37349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37114 == env37349) = true)

theorem identity37349 : scanCanonicalize (H12AffineFastState.compose env37349 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2485429) := by decide +kernel

theorem selectedBound37349 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2485429,8328,65,14822580,288824,10507601,8830976,10774692,4491636,257,8661016,8702396,10833778]

theorem envBound37350 : H12AffineFastState.Bounded env37350 := by
  intro p hp
  have h : env37350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37349_37350 : H12AffineEnvironment.transform 23 2485429 env37349 = env37350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2485429 env37349 == env37350) = true)

def env37351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294200,2485429,8328,65,6705548,288824,2369641,179512,2102684,4491636,257,21792,46212,2175562]

theorem envBound37351 : H12AffineFastState.Bounded env37351 := by
  intro p hp
  have h : env37351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37350_37351 : H12AffineEnvironment.transform 22 294200 env37350 = env37351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294200 env37350 == env37351) = true)

def env37352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294200,98781,8328,65,4340964,288824,17665,179512,293108,4491636,257,21792,46212,352034]

theorem envBound37352 : H12AffineFastState.Bounded env37352 := by
  intro p hp
  have h : env37352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37351_37352 : H12AffineEnvironment.transform 20 290152 env37351 = env37352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env37351 == env37352) = true)

def env37353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294200,98781,8328,65,398436,288824,17665,179512,293108,41460,257,21792,46212,352034]

theorem envBound37353 : H12AffineFastState.Bounded env37353 := by
  intro p hp
  have h : env37353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37352_37353 : H12AffineEnvironment.transform 21 272512 env37352 = env37353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37352 == env37353) = true)

theorem identity37353 : scanCanonicalize (H12AffineFastState.compose env37353 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37353 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,290152,272512,294200,21762,8328,65,398436,288824,17665,179512,293108,41460,257,21792,46212,297981]

theorem envBound37354 : H12AffineFastState.Bounded env37354 := by
  intro p hp
  have h : env37354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37353_37354 : H12AffineEnvironment.transform 15 54495 env37353 = env37354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37353 == env37354) = true)

def env37355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146864,1025,32769,151768,136496,147592,21762,8328,65,10708,152968,17665,179512,148804,41460,257,21792,46212,177741]

theorem envBound37355 : H12AffineFastState.Bounded env37355 := by
  intro p hp
  have h : env37355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37354_37355 : H12AffineEnvironment.transform 17 146864 env37354 = env37355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env37354 == env37355) = true)

theorem identity37355 : scanCanonicalize (H12AffineFastState.compose env37355 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound37355 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46156,35324,1025,32769,58516,41340,62660,21762,8328,65,10708,57796,17665,2420,61704,41460,257,21792,46212,513]

theorem envBound37356 : H12AffineFastState.Bounded env37356 := by
  intro p hp
  have h : env37356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37355_37356 : H12AffineEnvironment.transform 16 46156 env37355 = env37356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env37355 == env37356) = true)

theorem identity37356 : scanCanonicalize (H12AffineFastState.compose env37356 (packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound37356 : packedSelected [1,3,4,5,8,9,10,11,14,16,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env37357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33111,46156,35324,1025,32769,45340,41340,41292,138,8328,65,10708,46156,4233,2420,42112,41460,257,168,46212,513]

theorem envBound37357 : H12AffineFastState.Bounded env37357 := by
  intro p hp
  have h : env37357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37356_37357 : H12AffineEnvironment.transform 13 5512 env37356 = env37357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env37356 == env37357) = true)

theorem identity37357 : scanCanonicalize (H12AffineFastState.compose env37357 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37357 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,5392,10400,1025,8541,4160,32,16,138,8328,65,10708,5392,4233,2420,1500,168,257,168,5592,513]

theorem envBound37358 : H12AffineFastState.Bounded env37358 := by
  intro p hp
  have h : env37358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37357_37358 : H12AffineEnvironment.transform 14 8540 env37357 = env37358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37357 == env37358) = true)

theorem identity37358 : scanCanonicalize (H12AffineFastState.compose env37358 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37358 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1025,8541,4160,32,16,3,8193,65,10589,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound37359 : H12AffineFastState.Bounded env37359 := by
  intro p hp
  have h : env37359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37358_37359 : H12AffineEnvironment.transform 6 9 env37358 = env37359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37358 == env37359) = true)

theorem identity37359 : scanCanonicalize (H12AffineFastState.compose env37359 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37359 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5377,293,114,5392,2128,1025,292,4160,32,16,3,120,65,2340,5392,4096,2420,1365,33,257,33,5457,513]

theorem envBound37360 : H12AffineFastState.Bounded env37360 := by
  intro p hp
  have h : env37360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37359_37360 : H12AffineEnvironment.transform 12 121 env37359 = env37360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37359 == env37360) = true)

theorem identity37360 : scanCanonicalize (H12AffineFastState.compose env37360 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1809) := by decide +kernel

theorem selectedBound37360 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1809,121,528,293,114,513,2128,1025,292,1873,32,16,3,120,65,2340,513,1809,2420,1365,33,257,33,576,513]

theorem envBound37361 : H12AffineFastState.Bounded env37361 := by
  intro p hp
  have h : env37361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37360_37361 : H12AffineEnvironment.transform 11 1809 env37360 = env37361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1809 env37360 == env37361) = true)

def env37362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146865,1025,32769,151769,136497,147593,21762,8328,65,10709,152969,17665,179512,148805,41460,257,21792,46212,177740]

theorem envBound37362 : H12AffineFastState.Bounded env37362 := by
  intro p hp
  have h : env37362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37354_37362 : H12AffineEnvironment.transform 17 146865 env37354 = env37362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env37354 == env37362) = true)

theorem identity37362 : scanCanonicalize (H12AffineFastState.compose env37362 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound37362 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,46277,35188,1025,32769,58396,41460,62540,21762,8328,65,10709,57676,17665,2557,61824,41460,257,21792,46212,649]

theorem envBound37363 : H12AffineFastState.Bounded env37363 := by
  intro p hp
  have h : env37363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37362_37363 : H12AffineEnvironment.transform 16 46277 env37362 = env37363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env37362 == env37363) = true)

theorem identity37363 : scanCanonicalize (H12AffineFastState.compose env37363 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37363 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env37364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46157,35188,1025,32769,58396,41340,62540,21762,8192,65,10589,57676,17665,2421,61704,41340,257,21792,46092,513]

theorem envBound37364 : H12AffineFastState.Bounded env37364 := by
  intro p hp
  have h : env37364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37363_37364 : H12AffineEnvironment.transform 6 8 env37363 = env37364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37363 == env37364) = true)

theorem identity37364 : scanCanonicalize (H12AffineFastState.compose env37364 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound37364 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env37365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30042,5440,10361,1025,8460,17681,113,21825,21762,8192,65,10589,16449,17665,2421,20485,113,257,21792,5377,513]

theorem envBound37365 : H12AffineFastState.Bounded env37365 := by
  intro p hp
  have h : env37365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37364_37365 : H12AffineEnvironment.transform 14 8461 env37364 = env37365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env37364 == env37365) = true)

theorem identity37365 : scanCanonicalize (H12AffineFastState.compose env37365 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound37365 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env37366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8461,8202,5440,10361,1025,8460,4161,113,17,82,8192,65,10589,5393,4177,2421,1365,113,257,112,5377,513]

theorem envBound37366 : H12AffineFastState.Bounded env37366 := by
  intro p hp
  have h : env37366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37365_37366 : H12AffineEnvironment.transform 13 5456 env37365 = env37366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env37365 == env37366) = true)

theorem identity37366 : scanCanonicalize (H12AffineFastState.compose env37366 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound37366 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37367 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,4096,8192,5221,8248,8202,5237,10361,1025,8249,4161,113,17,82,8192,65,10344,5156,4177,2112,1120,113,52,112,5172,513]

theorem envBound37367 : H12AffineFastState.Bounded env37367 := by
  intro p hp
  have h : env37367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37366_37367 : H12AffineEnvironment.transform 7 53 env37366 = env37367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env37366 == env37367) = true)

theorem identity37367 : scanCanonicalize (H12AffineFastState.compose env37367 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 3660) := by decide +kernel

theorem selectedBound37367 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env37368 : List Nat := [2,4,8,16,32,64,8,53,512,1024,2048,4096,3660,5221,3700,3654,5237,1589,1025,3701,4161,113,17,82,3660,65,1572,5156,4177,2112,1120,113,52,112,5172,513]

theorem envBound37368 : H12AffineFastState.Bounded env37368 := by
  intro p hp
  have h : env37368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37367_37368 : H12AffineEnvironment.transform 12 3660 env37367 = env37368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3660 env37367 == env37368) = true)

theorem identity37368 : scanCanonicalize (H12AffineFastState.compose env37368 (packedSelected [14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37368 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env37369 : List Nat := [2,4,8,16,32,17,8,53,512,1024,2048,4096,3613,5172,3621,3607,5156,1589,1025,3620,4112,32,17,3,3613,16,1572,5156,4096,2065,1073,32,52,33,5172,513]

theorem envBound37369 : H12AffineFastState.Bounded env37369 := by
  intro p hp
  have h : env37369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37368_37369 : H12AffineEnvironment.transform 5 17 env37368 = env37369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37368 == env37369) = true)

theorem identity37369 : scanCanonicalize (H12AffineFastState.compose env37369 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37370 : List Nat := [2,4,8,16,16,17,8,5,512,1024,2048,4096,3613,5124,3605,3607,5140,1541,1025,3604,4112,16,17,3,3613,16,1556,5140,4096,2065,1025,16,4,17,5124,513]

theorem envBound37370 : H12AffineFastState.Bounded env37370 := by
  intro p hp
  have h : env37370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37369_37370 : H12AffineEnvironment.transform 4 16 env37369 = env37370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37369 == env37370) = true)

theorem identity37370 : scanCanonicalize (H12AffineFastState.compose env37370 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound37370 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37371 : List Nat := [2,4,8,16,16,17,8,5,512,1024,1556,4096,9,5124,1,3,5140,1541,1025,0,4112,16,17,3,9,16,1556,5140,4096,1541,1025,16,4,17,5124,513]

theorem envBound37371 : H12AffineFastState.Bounded env37371 := by
  intro p hp
  have h : env37371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37370_37371 : H12AffineEnvironment.transform 10 1556 env37370 = env37371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env37370 == env37371) = true)

theorem identity37371 : scanCanonicalize (H12AffineFastState.compose env37371 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound37371 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37372 : List Nat := [2,4,8,16,16,17,8,5,512,533,1,4096,9,4625,1,3,4609,16,532,0,4112,16,17,3,9,16,1,4609,4096,16,532,16,4,17,4625,513]

theorem envBound37372 : H12AffineFastState.Bounded env37372 := by
  intro p hp
  have h : env37372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37371_37372 : H12AffineEnvironment.transform 9 533 env37371 = env37372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env37371 == env37372) = true)

theorem identity37372 : scanCanonicalize (H12AffineFastState.compose env37372 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37372 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37373 : List Nat := [2,4,8,16,16,17,8,5,1,20,1,4096,9,4112,1,3,4096,16,21,0,4112,16,17,3,9,16,1,4096,4096,16,21,16,4,17,4112,0]

theorem envBound37373 : H12AffineFastState.Bounded env37373 := by
  intro p hp
  have h : env37373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37372_37373 : H12AffineEnvironment.transform 8 1 env37372 = env37373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37372 == env37373) = true)

theorem identity37373 : scanCanonicalize (H12AffineFastState.compose env37373 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound37373 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37374 : List Nat := [2,4,8,16,16,17,8,5,1,20,1,0,9,16,1,3,0,16,21,0,16,16,17,3,9,16,1,0,0,16,21,16,4,17,16,0]

theorem envBound37374 : H12AffineFastState.Bounded env37374 := by
  intro p hp
  have h : env37374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37373_37374 : H12AffineEnvironment.transform 11 0 env37373 = env37374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env37373 == env37374) = true)

def env37375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294200,98781,8328,65,398437,288824,17665,179512,293108,41461,257,21792,46212,352034]

theorem envBound37375 : H12AffineFastState.Bounded env37375 := by
  intro p hp
  have h : env37375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37352_37375 : H12AffineEnvironment.transform 21 272513 env37352 = env37375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37352 == env37375) = true)

theorem identity37375 : scanCanonicalize (H12AffineFastState.compose env37375 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109046) := by decide +kernel

theorem selectedBound37375 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109046,1025,32769,115870,98679,120014,98781,8328,65,245139,115150,17665,179512,119042,41461,257,21792,46212,63188]

theorem envBound37376 : H12AffineFastState.Bounded env37376 := by
  intro p hp
  have h : env37376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37375_37376 : H12AffineEnvironment.transform 17 109046 env37375 = env37376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109046 env37375 == env37376) = true)

def env37377 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108966,1025,32769,115870,98599,119966,98701,8328,17,245139,115102,17665,179512,119042,41381,257,21792,46212,63108]

theorem envBound37377 : H12AffineFastState.Bounded env37377 := by
  intro p hp
  have h : env37377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37376_37377 : H12AffineEnvironment.transform 5 16 env37376 = env37377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37376 == env37377) = true)

theorem identity37377 : scanCanonicalize (H12AffineFastState.compose env37377 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound37377 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37378 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,46109,108966,1025,32769,115870,98599,119966,98701,8328,17,67982,115102,17665,2341,119042,41381,257,21792,46212,63108]

theorem envBound37378 : H12AffineFastState.Bounded env37378 := by
  intro p hp
  have h : env37378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37377_37378 : H12AffineEnvironment.transform 16 46109 env37377 = env37378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env37377 == env37378) = true)

theorem identity37378 : scanCanonicalize (H12AffineFastState.compose env37378 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound37378 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env37379 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8322,46109,35108,1025,32769,58396,41381,62492,41231,8328,17,10508,57628,17665,2341,61824,41381,257,21792,46212,63108]

theorem envBound37379 : H12AffineFastState.Bounded env37379 := by
  intro p hp
  have h : env37379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37378_37379 : H12AffineEnvironment.transform 15 8322 env37378 = env37379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env37378 == env37379) = true)

theorem identity37379 : scanCanonicalize (H12AffineFastState.compose env37379 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37379 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env37380 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,32768,399,38160,35108,1025,32769,50449,32936,54545,32770,389,17,2049,49169,17665,2341,53389,32936,257,21792,38281,55177]

theorem envBound37380 : H12AffineFastState.Bounded env37380 := by
  intro p hp
  have h : env37380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37379_37380 : H12AffineEnvironment.transform 12 269 env37379 = env37380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37379 == env37380) = true)

theorem identity37380 : scanCanonicalize (H12AffineFastState.compose env37380 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound37380 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37381 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21760,399,16400,23588,1025,21761,4113,21928,17,21762,389,17,2049,5393,17665,2341,1421,21928,257,21792,16521,649]

theorem envBound37381 : H12AffineFastState.Bounded env37381 := by
  intro p hp
  have h : env37381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37380_37381 : H12AffineEnvironment.transform 14 21760 env37380 = env37381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env37380 == env37381) = true)

theorem identity37381 : scanCanonicalize (H12AffineFastState.compose env37381 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound37381 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37382 : List Nat := [2,4,8,16,32,16,128,256,512,564,2048,4096,269,16384,21300,399,16400,23056,565,21301,4113,21404,17,21302,389,17,2049,4901,17205,2341,953,21404,257,21268,16521,649]

theorem envBound37382 : H12AffineFastState.Bounded env37382 := by
  intro p hp
  have h : env37382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37381_37382 : H12AffineEnvironment.transform 9 564 env37381 = env37382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env37381 == env37382) = true)

theorem identity37382 : scanCanonicalize (H12AffineFastState.compose env37382 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5053) := by decide +kernel

theorem selectedBound37382 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37383 : List Nat := [2,4,8,16,32,16,128,256,512,564,2048,4096,269,5053,137,399,5037,2477,565,136,4113,33,17,139,389,17,2049,4901,4232,2341,953,33,257,169,4916,649]

theorem envBound37383 : H12AffineFastState.Bounded env37383 := by
  intro p hp
  have h : env37383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37382_37383 : H12AffineEnvironment.transform 13 5053 env37382 = env37383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5053 env37382 == env37383) = true)

theorem identity37383 : scanCanonicalize (H12AffineFastState.compose env37383 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound37383 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37384 : List Nat := [2,4,8,16,32,16,128,256,293,273,2048,4096,269,4248,137,399,4232,2477,272,136,4113,33,17,139,389,17,2049,4096,4232,2341,156,33,257,169,4113,428]

theorem envBound37384 : H12AffineFastState.Bounded env37384 := by
  intro p hp
  have h : env37384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37383_37384 : H12AffineEnvironment.transform 8 293 env37383 = env37384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env37383 == env37384) = true)

theorem identity37384 : scanCanonicalize (H12AffineFastState.compose env37384 (packedSelected [0,1,2,5,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound37384 : packedSelected [0,1,2,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env37385 : List Nat := [2,4,8,16,32,16,128,256,293,273,2048,429,269,309,137,399,293,2477,272,136,444,33,17,139,389,17,2049,429,293,2341,156,33,257,169,444,428]

theorem envBound37385 : H12AffineFastState.Bounded env37385 := by
  intro p hp
  have h : env37385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37384_37385 : H12AffineEnvironment.transform 11 429 env37384 = env37385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env37384 == env37385) = true)

theorem identity37385 : scanCanonicalize (H12AffineFastState.compose env37385 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37385 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env37386 : List Nat := [2,4,8,16,32,16,8,256,293,273,2048,293,269,309,1,263,293,2341,272,0,308,33,17,3,269,17,2049,293,293,2341,20,33,257,33,308,292]

theorem envBound37386 : H12AffineFastState.Bounded env37386 := by
  intro p hp
  have h : env37386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37385_37386 : H12AffineEnvironment.transform 6 8 env37385 = env37386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37385 == env37386) = true)

theorem identity37386 : scanCanonicalize (H12AffineFastState.compose env37386 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound37386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37387 : List Nat := [2,4,8,16,32,16,8,53,16,36,2048,16,56,0,1,50,16,2064,37,0,1,33,17,3,56,17,2049,16,16,2064,20,33,52,33,1,17]

theorem envBound37387 : H12AffineFastState.Bounded env37387 := by
  intro p hp
  have h : env37387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37386_37387 : H12AffineEnvironment.transform 7 53 env37386 = env37387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env37386 == env37387) = true)

theorem identity37387 : scanCanonicalize (H12AffineFastState.compose env37387 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound37387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37388 : List Nat := [2,4,8,16,32,16,8,53,16,36,49,16,56,0,1,50,16,33,37,0,1,33,17,3,56,17,48,16,16,33,20,33,52,33,1,17]

theorem envBound37388 : H12AffineFastState.Bounded env37388 := by
  intro p hp
  have h : env37388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37387_37388 : H12AffineEnvironment.transform 10 49 env37387 = env37388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env37387 == env37388) = true)

theorem identity37388 : scanCanonicalize (H12AffineFastState.compose env37388 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37388 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37389 : List Nat := [2,4,8,1,32,1,8,36,1,36,32,1,41,0,1,35,1,33,37,0,1,33,0,3,41,0,33,1,1,33,5,33,37,33,1,0]

theorem envBound37389 : H12AffineFastState.Bounded env37389 := by
  intro p hp
  have h : env37389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37388_37389 : H12AffineEnvironment.transform 3 1 env37388 = env37389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37388 == env37389) = true)

theorem identity37389 : scanCanonicalize (H12AffineFastState.compose env37389 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37390 : List Nat := [2,4,8,1,1,1,8,5,1,5,1,1,8,0,1,2,1,0,4,0,1,0,0,3,8,0,0,1,1,0,5,0,4,0,1,0]

theorem envBound37390 : H12AffineFastState.Bounded env37390 := by
  intro p hp
  have h : env37390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37389_37390 : H12AffineEnvironment.transform 4 1 env37389 = env37390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37389 == env37390) = true)

def env37391 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,108967,1025,32769,115870,98598,119967,98700,8328,16,245139,115103,17665,179512,119042,41380,257,21792,46212,63109]

theorem envBound37391 : H12AffineFastState.Bounded env37391 := by
  intro p hp
  have h : env37391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37376_37391 : H12AffineEnvironment.transform 5 17 env37376 = env37391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37376 == env37391) = true)

theorem identity37391 : scanCanonicalize (H12AffineFastState.compose env37391 (packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound37391 : packedSelected [1,4,7,9,11,16,17,18,19,20,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37392 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,103446,108967,1025,32769,115870,98598,119967,98700,8328,16,10629,115103,17665,76078,119042,41380,257,21792,46212,63109]

theorem envBound37392 : H12AffineFastState.Bounded env37392 := by
  intro p hp
  have h : env37392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37391_37392 : H12AffineEnvironment.transform 16 103446 env37391 = env37392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env37391 == env37392) = true)

theorem identity37392 : scanCanonicalize (H12AffineFastState.compose env37392 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37392 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37393 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,103446,108847,1025,32769,115734,98598,119831,98564,8192,16,10509,114967,17665,76078,119042,41260,257,21792,46092,62989]

theorem envBound37393 : H12AffineFastState.Bounded env37393 := by
  intro p hp
  have h : env37393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37392_37393 : H12AffineEnvironment.transform 6 8 env37392 = env37393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37392 == env37393) = true)

theorem identity37393 : scanCanonicalize (H12AffineFastState.compose env37393 (packedSelected [3,5,7,10,12,14,15,17,18,20,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound37393 : packedSelected [3,5,7,10,12,14,15,17,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env37394 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21761,65536,82199,97326,1025,21760,69911,87079,65814,87045,8192,16,10509,70678,17665,76078,66563,29741,257,21792,24845,8972]

theorem envBound37394 : H12AffineFastState.Bounded env37394 := by
  intro p hp
  have h : env37394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37393_37394 : H12AffineEnvironment.transform 14 21761 env37393 = env37394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env37393 == env37394) = true)

theorem identity37394 : scanCanonicalize (H12AffineFastState.compose env37394 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound37394 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37395 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21761,21510,5393,10280,1025,21760,17681,33,21776,3,8192,16,10509,16400,17665,32040,20485,29741,257,21792,24845,8972]

theorem envBound37395 : H12AffineFastState.Bounded env37395 := by
  intro p hp
  have h : env37395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37394_37395 : H12AffineEnvironment.transform 15 21510 env37394 = env37395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env37394 == env37395) = true)

theorem identity37395 : scanCanonicalize (H12AffineFastState.compose env37395 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37395 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37396 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,8192,16384,20496,20759,4096,10280,272,20497,16384,33,20481,3,8192,16,10509,16400,16400,30777,20485,28988,257,20529,24845,8972]

theorem envBound37396 : H12AffineFastState.Bounded env37396 := by
  intro p hp
  have h : env37396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37395_37396 : H12AffineEnvironment.transform 9 273 env37395 = env37396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37395 == env37396) = true)

theorem identity37396 : scanCanonicalize (H12AffineFastState.compose env37396 (packedSelected [1,3,4,5,8,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound37396 : packedSelected [1,3,4,5,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env37397 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,8192,12573,8461,8202,4096,10280,272,8460,12573,33,8476,3,8192,16,10509,12557,12557,2340,8472,33,257,8492,4112,8972]

theorem envBound37397 : H12AffineFastState.Bounded env37397 := by
  intro p hp
  have h : env37397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37396_37397 : H12AffineEnvironment.transform 13 12573 env37396 = env37397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env37396 == env37397) = true)

theorem identity37397 : scanCanonicalize (H12AffineFastState.compose env37397 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound37397 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env37398 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,6429,2048,6160,6423,4096,4405,272,6161,2048,33,6145,3,6429,16,4112,2064,2064,2340,6149,33,257,6193,4112,6673]

theorem envBound37398 : H12AffineFastState.Bounded env37398 := by
  intro p hp
  have h : env37398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37397_37398 : H12AffineEnvironment.transform 12 6429 env37397 = env37398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env37397 == env37398) = true)

theorem identity37398 : scanCanonicalize (H12AffineFastState.compose env37398 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37398 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37399 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,2064,269,2048,0,263,2064,2341,272,1,2048,33,17,3,269,16,2048,2064,2064,2340,21,33,257,33,2048,513]

theorem envBound37399 : H12AffineFastState.Bounded env37399 := by
  intro p hp
  have h : env37399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37398_37399 : H12AffineEnvironment.transform 11 2064 env37398 = env37399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37398 == env37399) = true)

theorem identity37399 : scanCanonicalize (H12AffineFastState.compose env37399 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound37399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37400 : List Nat := [2,4,8,16,32,17,8,52,512,37,2048,2064,57,2048,0,51,2064,2065,36,1,2048,33,17,3,57,16,2048,2064,2064,2064,21,33,53,33,2048,513]

theorem envBound37400 : H12AffineFastState.Bounded env37400 := by
  intro p hp
  have h : env37400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37399_37400 : H12AffineEnvironment.transform 7 52 env37399 = env37400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env37399 == env37400) = true)

theorem identity37400 : scanCanonicalize (H12AffineFastState.compose env37400 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37400 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37401 : List Nat := [2,4,8,16,16,17,8,4,512,21,2048,2064,9,2048,0,3,2064,2065,20,1,2048,17,17,3,9,16,2048,2064,2064,2064,21,17,5,17,2048,513]

theorem envBound37401 : H12AffineFastState.Bounded env37401 := by
  intro p hp
  have h : env37401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37400_37401 : H12AffineEnvironment.transform 4 16 env37400 = env37401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37400 == env37401) = true)

theorem identity37401 : scanCanonicalize (H12AffineFastState.compose env37401 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound37401 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37402 : List Nat := [2,4,8,16,16,17,8,4,512,21,513,529,9,513,0,3,529,528,20,1,513,17,17,3,9,16,513,529,529,529,21,17,5,17,513,513]

theorem envBound37402 : H12AffineFastState.Bounded env37402 := by
  intro p hp
  have h : env37402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37401_37402 : H12AffineEnvironment.transform 10 513 env37401 = env37402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env37401 == env37402) = true)

theorem identity37402 : scanCanonicalize (H12AffineFastState.compose env37402 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37403 : List Nat := [2,4,8,16,16,17,8,4,16,21,17,1,9,17,0,3,1,0,20,1,17,17,17,3,9,16,17,1,1,1,21,17,5,17,17,17]

theorem envBound37403 : H12AffineFastState.Bounded env37403 := by
  intro p hp
  have h : env37403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37402_37403 : H12AffineEnvironment.transform 8 16 env37402 = env37403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37402 == env37403) = true)

def env37404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294200,98780,8328,65,4340965,288824,17664,179512,293109,4491636,257,21792,46212,352035]

theorem envBound37404 : H12AffineFastState.Bounded env37404 := by
  intro p hp
  have h : env37404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37351_37404 : H12AffineEnvironment.transform 20 290153 env37351 = env37404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env37351 == env37404) = true)

def env37405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294200,98780,8328,65,398437,288824,17664,179512,293109,41460,257,21792,46212,352035]

theorem envBound37405 : H12AffineFastState.Bounded env37405 := by
  intro p hp
  have h : env37405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37404_37405 : H12AffineEnvironment.transform 21 272512 env37404 = env37405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37404 == env37405) = true)

theorem identity37405 : scanCanonicalize (H12AffineFastState.compose env37405 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37405 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272512,294200,41431,8328,65,398437,288824,17664,179512,293109,41460,257,21792,46212,294696]

theorem envBound37406 : H12AffineFastState.Bounded env37406 := by
  intro p hp
  have h : env37406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37405_37406 : H12AffineEnvironment.transform 15 8203 env37405 = env37406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37405 == env37406) = true)

def env37407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272392,294200,41311,8192,65,398437,288824,17664,179512,292989,41340,257,21792,46092,294696]

theorem envBound37407 : H12AffineFastState.Bounded env37407 := by
  intro p hp
  have h : env37407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37406_37407 : H12AffineEnvironment.transform 6 8 env37406 = env37407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37406 == env37407) = true)

theorem identity37407 : scanCanonicalize (H12AffineFastState.compose env37407 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound37407 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37408 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,131072,262144,1025,29709,290153,272392,294200,21843,8192,65,398437,288824,17664,149812,292989,21872,257,21792,16384,294696]

theorem envBound37408 : H12AffineFastState.Bounded env37408 := by
  intro p hp
  have h : env37408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37407_37408 : H12AffineEnvironment.transform 14 29708 env37407 = env37408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env37407 == env37408) = true)

theorem identity37408 : scanCanonicalize (H12AffineFastState.compose env37408 (packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound37408 : packedSelected [0,4,5,12,14,15,16,17,19,22,24,27] rootPS < 2^1333 := by decide +kernel

def env37409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,131072,157801,1025,29709,132352,147553,136529,21843,8192,65,31756,131153,17664,149812,135188,21872,257,21792,16384,137025]

theorem envBound37409 : H12AffineFastState.Bounded env37409 := by
  intro p hp
  have h : env37409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37408_37409 : H12AffineEnvironment.transform 17 157801 env37408 = env37409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env37408 == env37409) = true)

theorem identity37409 : scanCanonicalize (H12AffineFastState.compose env37409 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37409 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env37410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,81,8203,131072,138292,1025,80,132352,144444,136529,8462,8192,65,2129,131153,12637,146793,135188,8493,257,8573,13405,137025]

theorem envBound37410 : H12AffineFastState.Bounded env37410 := by
  intro p hp
  have h : env37410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37409_37410 : H12AffineEnvironment.transform 13 13405 env37409 = env37410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37409 == env37410) = true)

theorem identity37410 : scanCanonicalize (H12AffineFastState.compose env37410 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound37410 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env37411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,81,8203,13388,10360,1025,80,12620,112,8477,8462,8192,65,2129,13341,12637,2341,9304,8493,257,8573,13405,8973]

theorem envBound37411 : H12AffineFastState.Bounded env37411 := by
  intro p hp
  have h : env37411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37410_37411 : H12AffineEnvironment.transform 16 13388 env37410 = env37411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env37410 == env37411) = true)

theorem identity37411 : scanCanonicalize (H12AffineFastState.compose env37411 (packedSelected [0,2,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37411 : packedSelected [0,2,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5236,81,34,5221,2129,1025,80,4453,112,308,295,41,65,2129,5172,4468,2341,1137,260,257,340,5236,804]

theorem envBound37412 : H12AffineFastState.Bounded env37412 := by
  intro p hp
  have h : env37412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37411_37412 : H12AffineEnvironment.transform 12 41 env37411 = env37412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37411 == env37412) = true)

theorem identity37412 : scanCanonicalize (H12AffineFastState.compose env37412 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound37412 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env37413 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5236,81,34,5221,2129,1025,80,4113,112,64,83,41,65,2129,5172,4096,2129,1137,112,117,32,5236,592]

theorem envBound37413 : H12AffineFastState.Bounded env37413 := by
  intro p hp
  have h : env37413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37412_37413 : H12AffineEnvironment.transform 7 116 env37412 = env37413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env37412 == env37413) = true)

def env37414 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,290153,272393,294200,41310,8193,65,398437,288824,17664,179512,292988,41341,257,21792,46093,294696]

theorem envBound37414 : H12AffineFastState.Bounded env37414 := by
  intro p hp
  have h : env37414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37406_37414 : H12AffineEnvironment.transform 6 9 env37406 = env37414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37406 == env37414) = true)

theorem identity37414 : scanCanonicalize (H12AffineFastState.compose env37414 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound37414 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8203,131072,262144,1025,32769,276536,272393,272489,41310,8193,65,398437,277865,4177,179512,273709,41341,257,113,46093,273017]

theorem envBound37415 : H12AffineFastState.Bounded env37415 := by
  intro p hp
  have h : env37415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37414_37415 : H12AffineEnvironment.transform 13 5457 env37414 = env37415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env37414 == env37415) = true)

theorem identity37415 : scanCanonicalize (H12AffineFastState.compose env37415 (packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound37415 : packedSelected [3,4,5,7,8,9,16,19,20,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8203,46109,262144,1025,32769,276536,272393,272489,41310,8193,65,303224,277865,4177,2341,273709,41341,257,113,46093,273017]

theorem envBound37416 : H12AffineFastState.Bounded env37416 := by
  intro p hp
  have h : env37416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37415_37416 : H12AffineEnvironment.transform 16 46109 env37415 = env37416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env37415 == env37416) = true)

theorem identity37416 : scanCanonicalize (H12AffineFastState.compose env37416 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37416 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env37417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,8203,5440,262144,1025,8540,276536,272393,272489,3,8193,65,262437,277865,4177,2341,273709,32,257,113,5456,273017]

theorem envBound37417 : H12AffineFastState.Bounded env37417 := by
  intro p hp
  have h : env37417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37416_37417 : H12AffineEnvironment.transform 14 8541 env37416 = env37417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37416 == env37417) = true)

theorem identity37417 : scanCanonicalize (H12AffineFastState.compose env37417 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37417 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env37418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,373,35,5440,262144,1025,372,268304,264225,264257,3,41,65,262437,269633,4177,2341,265477,32,257,113,5456,264785]

theorem envBound37418 : H12AffineFastState.Bounded env37418 := by
  intro p hp
  have h : env37418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37417_37418 : H12AffineEnvironment.transform 12 40 env37417 = env37418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37417 == env37418) = true)

theorem identity37418 : scanCanonicalize (H12AffineFastState.compose env37418 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound37418 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5457,373,35,5440,2049,1025,372,4113,32,64,3,41,65,2340,5440,4177,2341,1284,32,257,113,5456,592]

theorem envBound37419 : H12AffineFastState.Bounded env37419 := by
  intro p hp
  have h : env37419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37418_37419 : H12AffineEnvironment.transform 17 2049 env37418 = env37419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env37418 == env37419) = true)

theorem identity37419 : scanCanonicalize (H12AffineFastState.compose env37419 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37419 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37420 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,40,4160,373,35,4177,2049,272,372,4113,32,64,3,41,65,2340,4177,4177,2341,21,32,257,113,4161,592]

theorem envBound37420 : H12AffineFastState.Bounded env37420 := by
  intro p hp
  have h : env37420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37419_37420 : H12AffineEnvironment.transform 9 273 env37419 = env37420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37419 == env37420) = true)

theorem identity37420 : scanCanonicalize (H12AffineFastState.compose env37420 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37420 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37421 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,40,4112,293,35,4097,2049,272,292,4113,32,16,3,41,17,2340,4097,4097,2341,21,32,257,33,4113,512]

theorem envBound37421 : H12AffineFastState.Bounded env37421 := by
  intro p hp
  have h : env37421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37420_37421 : H12AffineEnvironment.transform 5 16 env37420 = env37421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37420 == env37421) = true)

theorem identity37421 : scanCanonicalize (H12AffineFastState.compose env37421 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37422 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,9,4112,260,2,4097,2049,272,261,4113,1,16,3,8,17,2309,4097,4097,2308,21,1,257,0,4113,512]

theorem envBound37422 : H12AffineFastState.Bounded env37422 := by
  intro p hp
  have h : env37422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37421_37422 : H12AffineEnvironment.transform 4 1 env37421 = env37422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37421 == env37422) = true)

theorem identity37422 : scanCanonicalize (H12AffineFastState.compose env37422 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37422 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37423 : List Nat := [2,4,8,16,1,16,9,256,512,273,523,4096,9,4112,260,2,4097,522,272,261,4113,1,16,3,8,17,782,4097,4097,783,21,1,257,0,4113,512]

theorem envBound37423 : H12AffineFastState.Bounded env37423 := by
  intro p hp
  have h : env37423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37422_37423 : H12AffineEnvironment.transform 10 523 env37422 = env37423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37422 == env37423) = true)

theorem identity37423 : scanCanonicalize (H12AffineFastState.compose env37423 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37423 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env37424 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,4096,9,4112,1,2,4097,522,21,0,4113,1,16,3,8,17,523,4097,4097,522,21,1,4,0,4113,512]

theorem envBound37424 : H12AffineFastState.Bounded env37424 := by
  intro p hp
  have h : env37424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37423_37424 : H12AffineEnvironment.transform 7 5 env37423 = env37424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37423 == env37424) = true)

theorem identity37424 : scanCanonicalize (H12AffineFastState.compose env37424 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 21) := by decide +kernel

theorem selectedBound37424 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37425 : List Nat := [2,4,8,16,1,16,9,5,512,20,523,21,9,5,1,2,20,522,21,0,4,1,16,3,8,17,523,20,20,522,21,1,4,0,4,512]

theorem envBound37425 : H12AffineFastState.Bounded env37425 := by
  intro p hp
  have h : env37425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37424_37425 : H12AffineEnvironment.transform 11 21 env37424 = env37425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 21 env37424 == env37425) = true)

theorem identity37425 : scanCanonicalize (H12AffineFastState.compose env37425 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound37425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37426 : List Nat := [2,4,8,16,1,16,9,5,28,20,23,21,9,5,1,2,20,22,21,0,4,1,16,3,8,17,23,20,20,22,21,1,4,0,4,28]

theorem envBound37426 : H12AffineFastState.Bounded env37426 := by
  intro p hp
  have h : env37426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37425_37426 : H12AffineEnvironment.transform 8 28 env37425 = env37426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env37425 == env37426) = true)

theorem identity37426 : scanCanonicalize (H12AffineFastState.compose env37426 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37426 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37427 : List Nat := [2,4,8,7,1,7,9,5,11,3,0,2,9,5,1,2,3,1,2,0,4,1,7,3,8,6,0,3,3,1,2,1,4,0,4,11]

theorem envBound37427 : H12AffineFastState.Bounded env37427 := by
  intro p hp
  have h : env37427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37426_37427 : H12AffineEnvironment.transform 3 7 env37426 = env37427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37426 == env37427) = true)

theorem identity37427 : scanCanonicalize (H12AffineFastState.compose env37427 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37427 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37428 : List Nat := [2,0,8,3,1,3,9,1,11,3,0,2,9,1,1,2,3,1,2,0,0,1,3,3,8,2,0,3,3,1,2,1,0,0,0,11]

theorem envBound37428 : H12AffineFastState.Bounded env37428 := by
  intro p hp
  have h : env37428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37427_37428 : H12AffineEnvironment.transform 1 0 env37427 = env37428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37427 == env37428) = true)

def env37429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294200,98780,8328,65,398436,288824,17664,179512,293109,41461,257,21792,46212,352035]

theorem envBound37429 : H12AffineFastState.Bounded env37429 := by
  intro p hp
  have h : env37429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37404_37429 : H12AffineEnvironment.transform 21 272513 env37404 = env37429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37404 == env37429) = true)

theorem identity37429 : scanCanonicalize (H12AffineFastState.compose env37429 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound37429 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95651,73754,98780,8328,65,215366,79130,17664,179512,75223,41461,257,21792,46212,513]

theorem envBound37430 : H12AffineFastState.Bounded env37430 := by
  intro p hp
  have h : env37430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37429_37430 : H12AffineEnvironment.transform 17 89378 env37429 = env37430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env37429 == env37430) = true)

def env37431 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95531,73754,98644,8192,65,215366,79130,17664,179512,75103,41341,257,21792,46092,513]

theorem envBound37431 : H12AffineFastState.Bounded env37431 := by
  intro p hp
  have h : env37431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37430_37431 : H12AffineEnvironment.transform 6 8 env37430 = env37431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37430 == env37431) = true)

theorem identity37431 : scanCanonicalize (H12AffineFastState.compose env37431 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound37431 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35188,1025,32769,58397,41341,62540,21762,8192,65,171280,57676,17664,179512,61705,41341,257,21792,46092,513]

theorem envBound37432 : H12AffineFastState.Bounded env37432 := by
  intro p hp
  have h : env37432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37431_37432 : H12AffineEnvironment.transform 15 54358 env37431 = env37432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env37431 == env37432) = true)

theorem identity37432 : scanCanonicalize (H12AffineFastState.compose env37432 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37432 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env37433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,35188,1025,32769,45341,41341,41292,2,8192,65,171280,46156,4096,179512,41993,41341,257,32,46092,513]

theorem envBound37433 : H12AffineFastState.Bounded env37433 := by
  intro p hp
  have h : env37433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37432_37433 : H12AffineEnvironment.transform 13 5376 env37432 = env37433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37432 == env37433) = true)

theorem identity37433 : scanCanonicalize (H12AffineFastState.compose env37433 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound37433 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8460,8282,131072,10360,1025,8461,4113,113,64,2,8192,65,146460,5440,4096,138292,1285,113,257,32,5376,513]

theorem envBound37434 : H12AffineFastState.Bounded env37434 := by
  intro p hp
  have h : env37434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37433_37434 : H12AffineEnvironment.transform 14 8460 env37433 = env37434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env37433 == env37434) = true)

theorem identity37434 : scanCanonicalize (H12AffineFastState.compose env37434 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37435 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,131072,10281,1025,8461,4113,32,17,2,8192,16,146460,5393,4096,138292,1285,32,257,32,5376,513]

theorem envBound37435 : H12AffineFastState.Bounded env37435 := by
  intro p hp
  have h : env37435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37434_37435 : H12AffineEnvironment.transform 5 17 env37434 = env37435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37434 == env37435) = true)

theorem identity37435 : scanCanonicalize (H12AffineFastState.compose env37435 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13592) := by decide +kernel

theorem selectedBound37435 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37436 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,13592,10281,1025,8461,4113,32,17,2,8192,16,2308,5393,4096,10540,1285,32,257,32,5376,513]

theorem envBound37436 : H12AffineFastState.Bounded env37436 := by
  intro p hp
  have h : env37436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37435_37436 : H12AffineEnvironment.transform 16 13592 env37435 = env37436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13592 env37435 == env37436) = true)

def env37437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,77899,95530,73754,98645,8193,65,215366,79130,17664,179512,75102,41340,257,21792,46093,513]

theorem envBound37437 : H12AffineFastState.Bounded env37437 := by
  intro p hp
  have h : env37437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37430_37437 : H12AffineEnvironment.transform 6 9 env37430 = env37437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37430 == env37437) = true)

theorem identity37437 : scanCanonicalize (H12AffineFastState.compose env37437 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound37437 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37438 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,9499,131072,30777,1025,32769,5456,20529,1281,42062,8193,65,158813,4097,17664,179512,69,41340,257,21792,46093,513]

theorem envBound37438 : H12AffineFastState.Bounded env37438 := by
  intro p hp
  have h : env37438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37437_37438 : H12AffineEnvironment.transform 15 9499 env37437 = env37438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env37437 == env37438) = true)

theorem identity37438 : scanCanonicalize (H12AffineFastState.compose env37438 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 17665) := by decide +kernel

theorem selectedBound37438 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env37439 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,9499,17665,30777,1025,32769,5456,20529,1281,42062,8193,65,10588,4097,17664,63545,69,41340,257,21792,46093,513]

theorem envBound37439 : H12AffineFastState.Bounded env37439 := by
  intro p hp
  have h : env37439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37438_37439 : H12AffineEnvironment.transform 16 17665 env37438 = env37439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17665 env37438 == env37439) = true)

theorem identity37439 : scanCanonicalize (H12AffineFastState.compose env37439 (packedSelected [3,5,10,11,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37439 : packedSelected [3,5,10,11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env37440 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,9499,17665,30777,1025,8541,5456,20529,1281,1298,8193,65,10588,4097,17664,22885,69,32,257,21792,5457,513]

theorem envBound37440 : H12AffineFastState.Bounded env37440 := by
  intro p hp
  have h : env37440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37439_37440 : H12AffineEnvironment.transform 14 8540 env37439 = env37440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37439 == env37440) = true)

theorem identity37440 : scanCanonicalize (H12AffineFastState.compose env37440 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37440 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37441 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,8540,8203,16401,30777,273,8541,4160,20529,17,2,8193,65,10588,4097,16400,22885,69,32,257,20528,4161,513]

theorem envBound37441 : H12AffineFastState.Bounded env37441 := by
  intro p hp
  have h : env37441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37440_37441 : H12AffineEnvironment.transform 9 272 env37440 = env37441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37440 == env37441) = true)

theorem identity37441 : scanCanonicalize (H12AffineFastState.compose env37441 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37442 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,8192,16384,8540,8203,16401,30745,273,8541,4160,20497,17,2,8193,65,10588,4097,16400,22853,69,0,257,20496,4161,513]

theorem envBound37442 : H12AffineFastState.Bounded env37442 := by
  intro p hp
  have h : env37442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37441_37442 : H12AffineEnvironment.transform 4 0 env37441 = env37442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37441 == env37442) = true)

theorem identity37442 : scanCanonicalize (H12AffineFastState.compose env37442 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37443 : List Nat := [2,4,8,16,0,64,9,256,512,272,2048,4096,268,16384,80,263,16401,22805,273,81,4160,20497,17,2,269,65,2128,4097,16400,22853,69,0,257,20496,4161,513]

theorem envBound37443 : H12AffineFastState.Bounded env37443 := by
  intro p hp
  have h : env37443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37442_37443 : H12AffineEnvironment.transform 12 268 env37442 = env37443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37442 == env37443) = true)

theorem identity37443 : scanCanonicalize (H12AffineFastState.compose env37443 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37443 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37444 : List Nat := [2,4,8,16,0,17,9,256,512,272,2048,4096,268,16384,1,263,16401,22805,273,0,4113,20497,17,2,269,16,2049,4097,16400,22804,20,0,257,20496,4112,513]

theorem envBound37444 : H12AffineFastState.Bounded env37444 := by
  intro p hp
  have h : env37444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37443_37444 : H12AffineEnvironment.transform 5 17 env37443 = env37444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37443 == env37444) = true)

theorem identity37444 : scanCanonicalize (H12AffineFastState.compose env37444 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound37444 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env37445 : List Nat := [2,4,8,16,0,17,9,256,512,272,2048,4096,268,4373,1,263,4356,2048,273,0,4113,260,17,2,269,16,2049,4097,4357,2049,20,0,257,261,4112,513]

theorem envBound37445 : H12AffineFastState.Bounded env37445 := by
  intro p hp
  have h : env37445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37444_37445 : H12AffineEnvironment.transform 13 4373 env37444 = env37445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env37444 == env37445) = true)

theorem identity37445 : scanCanonicalize (H12AffineFastState.compose env37445 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37445 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37446 : List Nat := [2,4,8,16,0,17,9,5,512,21,2048,4096,9,4112,1,2,4097,2048,20,0,4113,1,17,2,8,16,2049,4097,4096,2049,20,0,4,0,4112,513]

theorem envBound37446 : H12AffineFastState.Bounded env37446 := by
  intro p hp
  have h : env37446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37445_37446 : H12AffineEnvironment.transform 7 5 env37445 = env37446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37445 == env37446) = true)

theorem identity37446 : scanCanonicalize (H12AffineFastState.compose env37446 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37447 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,4096,9,4097,1,2,4097,2048,5,0,4096,1,0,2,8,1,2049,4097,4096,2049,5,0,4,0,4097,513]

theorem envBound37447 : H12AffineFastState.Bounded env37447 := by
  intro p hp
  have h : env37447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37446_37447 : H12AffineEnvironment.transform 3 1 env37446 = env37447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37446 == env37447) = true)

theorem identity37447 : scanCanonicalize (H12AffineFastState.compose env37447 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound37447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37448 : List Nat := [2,4,8,1,0,0,9,5,512,4,2048,11,9,10,1,2,10,2048,5,0,11,1,0,2,8,1,2049,10,11,2049,5,0,4,0,10,513]

theorem envBound37448 : H12AffineFastState.Bounded env37448 := by
  intro p hp
  have h : env37448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37447_37448 : H12AffineEnvironment.transform 11 11 env37447 = env37448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env37447 == env37448) = true)

theorem identity37448 : scanCanonicalize (H12AffineFastState.compose env37448 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound37448 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37449 : List Nat := [2,4,8,1,0,0,9,5,512,4,513,11,9,10,1,2,10,513,5,0,11,1,0,2,8,1,512,10,11,512,5,0,4,0,10,513]

theorem envBound37449 : H12AffineFastState.Bounded env37449 := by
  intro p hp
  have h : env37449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37448_37449 : H12AffineEnvironment.transform 10 513 env37448 = env37449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env37448 == env37449) = true)

def env37450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,294201,2485429,8328,65,6705549,288824,2369640,179513,2102685,4491636,257,21793,46213,2175563]

theorem envBound37450 : H12AffineFastState.Bounded env37450 := by
  intro p hp
  have h : env37450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37350_37450 : H12AffineEnvironment.transform 22 294201 env37350 = env37450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 294201 env37350 == env37450) = true)

def env37451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,4194304,294201,98781,8328,65,4340965,288824,17664,179513,293109,4491636,257,21793,46213,352035]

theorem envBound37451 : H12AffineFastState.Bounded env37451 := by
  intro p hp
  have h : env37451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37450_37451 : H12AffineEnvironment.transform 20 290152 env37450 = env37451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290152 env37450 == env37451) = true)

def env37452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272512,294201,98781,8328,65,398437,288824,17664,179513,293109,41460,257,21793,46213,352035]

theorem envBound37452 : H12AffineFastState.Bounded env37452 := by
  intro p hp
  have h : env37452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37451_37452 : H12AffineEnvironment.transform 21 272512 env37451 = env37452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37451 == env37452) = true)

theorem identity37452 : scanCanonicalize (H12AffineFastState.compose env37452 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound37452 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,58516,41340,62661,98781,8328,65,171417,57796,17664,179513,61705,41460,257,21793,46213,120543]

theorem envBound37453 : H12AffineFastState.Bounded env37453 := by
  intro p hp
  have h : env37453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37452_37453 : H12AffineEnvironment.transform 17 35324 env37452 = env37453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env37452 == env37453) = true)

def env37454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35324,1025,32769,45460,41340,41413,98781,8328,65,171417,46276,4096,179513,41993,41460,257,33,46213,99295]

theorem envBound37454 : H12AffineFastState.Bounded env37454 := by
  intro p hp
  have h : env37454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37453_37454 : H12AffineEnvironment.transform 13 5376 env37453 = env37454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37453 == env37454) = true)

def env37455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46276,35324,1025,32769,45460,41340,41413,98781,8328,65,10589,46276,4096,2557,41993,41460,257,33,46213,99295]

theorem envBound37455 : H12AffineFastState.Bounded env37455 := by
  intro p hp
  have h : env37455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37454_37455 : H12AffineEnvironment.transform 16 46276 env37454 = env37455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env37454 == env37455) = true)

def env37456 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5372,32768,65536,46276,34816,1025,32769,45160,41088,41017,98337,8328,65,10401,46276,4096,2049,41993,40968,253,33,46213,98851]

theorem envBound37456 : H12AffineFastState.Bounded env37456 := by
  intro p hp
  have h : env37456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37455_37456 : H12AffineEnvironment.transform 7 252 env37455 = env37456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env37455 == env37456) = true)

theorem identity37456 : scanCanonicalize (H12AffineFastState.compose env37456 (packedSelected [1,4,5,9,10,11,14,15,20,24,28,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound37456 : packedSelected [1,4,5,9,10,11,14,15,20,24,28,32,41] rootPS < 2^1333 := by decide +kernel

def env37457 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5372,32768,170,46276,34816,1025,32769,45160,41088,41017,32907,8328,65,10401,46276,4096,2049,41993,40968,253,33,46213,33417]

theorem envBound37457 : H12AffineFastState.Bounded env37457 := by
  intro p hp
  have h : env37457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37456_37457 : H12AffineEnvironment.transform 15 170 env37456 = env37457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env37456 == env37457) = true)

theorem identity37457 : scanCanonicalize (H12AffineFastState.compose env37457 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound37457 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37458 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,32768,170,37989,34816,1025,32769,37065,32801,32920,32907,41,65,2048,37989,4096,2049,33960,32937,253,33,37924,33417]

theorem envBound37458 : H12AffineFastState.Bounded env37458 := by
  intro p hp
  have h : env37458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37457_37458 : H12AffineEnvironment.transform 12 161 env37457 = env37458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env37457 == env37458) = true)

theorem identity37458 : scanCanonicalize (H12AffineFastState.compose env37458 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound37458 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37459 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,5372,81,170,5172,2129,1025,80,4248,112,201,218,41,65,2048,5172,4096,2049,1273,248,253,33,5237,728]

theorem envBound37459 : H12AffineFastState.Bounded env37459 := by
  intro p hp
  have h : env37459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37458_37459 : H12AffineEnvironment.transform 14 81 env37458 = env37459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env37458 == env37459) = true)

theorem identity37459 : scanCanonicalize (H12AffineFastState.compose env37459 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37459 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env37460 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5236,81,34,5172,2129,1025,80,4112,112,65,82,41,65,2048,5172,4096,2049,1137,112,117,33,5237,592]

theorem envBound37460 : H12AffineFastState.Bounded env37460 := by
  intro p hp
  have h : env37460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37459_37460 : H12AffineEnvironment.transform 6 8 env37459 = env37460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37459 == env37460) = true)

theorem identity37460 : scanCanonicalize (H12AffineFastState.compose env37460 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37460 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env37461 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2064,41,3172,81,34,3108,2129,1025,80,2048,112,65,82,41,65,2048,3108,2064,2049,1137,112,117,33,3173,592]

theorem envBound37461 : H12AffineFastState.Bounded env37461 := by
  intro p hp
  have h : env37461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37460_37461 : H12AffineEnvironment.transform 11 2064 env37460 = env37461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37460 == env37461) = true)

theorem identity37461 : scanCanonicalize (H12AffineFastState.compose env37461 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37461 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env37462 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2064,41,3124,1,34,3108,2049,1025,0,2048,32,17,2,41,17,2048,3108,2064,2049,1057,32,37,33,3125,512]

theorem envBound37462 : H12AffineFastState.Bounded env37462 := by
  intro p hp
  have h : env37462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37461_37462 : H12AffineEnvironment.transform 5 16 env37461 = env37462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37461 == env37462) = true)

theorem identity37462 : scanCanonicalize (H12AffineFastState.compose env37462 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37463 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,2064,8,3093,1,3,3077,2049,1025,0,2048,1,17,2,8,17,2048,3077,2064,2049,1024,1,4,0,3092,512]

theorem envBound37463 : H12AffineFastState.Bounded env37463 := by
  intro p hp
  have h : env37463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37462_37463 : H12AffineEnvironment.transform 4 1 env37462 = env37463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37462 == env37463) = true)

theorem identity37463 : scanCanonicalize (H12AffineFastState.compose env37463 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound37463 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37464 : List Nat := [2,4,8,16,1,16,8,5,512,21,2048,2064,8,2048,1,3,2064,2049,20,0,2048,1,17,2,8,17,2048,2064,2064,2049,21,1,4,0,2049,512]

theorem envBound37464 : H12AffineFastState.Bounded env37464 := by
  intro p hp
  have h : env37464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37463_37464 : H12AffineEnvironment.transform 9 21 env37463 = env37464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37463 == env37464) = true)

theorem identity37464 : scanCanonicalize (H12AffineFastState.compose env37464 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37465 : List Nat := [2,4,8,16,1,16,8,5,1,21,2048,2064,8,2048,1,3,2064,2049,20,0,2048,1,17,2,8,17,2048,2064,2064,2049,21,1,4,0,2049,1]

theorem envBound37465 : H12AffineFastState.Bounded env37465 := by
  intro p hp
  have h : env37465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37464_37465 : H12AffineEnvironment.transform 8 1 env37464 = env37465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37464 == env37465) = true)

theorem identity37465 : scanCanonicalize (H12AffineFastState.compose env37465 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound37465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37466 : List Nat := [2,4,8,5,1,5,8,5,1,0,2048,2053,8,2048,1,3,2053,2049,1,0,2048,1,4,2,8,4,2048,2053,2053,2049,0,1,4,0,2049,1]

theorem envBound37466 : H12AffineFastState.Bounded env37466 := by
  intro p hp
  have h : env37466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37465_37466 : H12AffineEnvironment.transform 3 5 env37465 = env37466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37465 == env37466) = true)

def leafEnv37466 : List Nat := [2,4,8,5,1,5,8,5,1,0,2048,2053,8,2048,1,3,2053,2049,1,0,2048,1,4,2,1,8,1,4,2048,2053,2053,2049,0,1,4,0,5,3,2049,1,1,2049,0]

def active37466 : List Nat := [0,1,2,10]

def tree37466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37466 : H12WitnessSearch.Good tree37466 := H12GlobalWitnessIndex.good

theorem leafIdentity37466 : H12AffineFastState.composeSystem env37466 rootObs = leafEnv37466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37466 rootObs == leafEnv37466) = true)

theorem terminalChecked37466 : H12PackedTerminal.terminalCheckFast leafEnv37466 active37466 tree37466 = true := by decide +kernel

def env37467 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,32768,65536,46276,34817,1025,32769,45161,41089,41016,98336,8328,65,10400,46276,4096,2048,41993,40969,252,33,46213,98850]

theorem envBound37467 : H12AffineFastState.Bounded env37467 := by
  intro p hp
  have h : env37467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37455_37467 : H12AffineEnvironment.transform 7 253 env37455 = env37467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env37455 == env37467) = true)

theorem identity37467 : scanCanonicalize (H12AffineFastState.compose env37467 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound37467 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37468 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,32768,32803,46276,34817,1025,32769,45161,41089,41016,3,8328,65,10400,46276,4096,2048,41993,40969,252,33,46213,513]

theorem envBound37468 : H12AffineFastState.Bounded env37468 := by
  intro p hp
  have h : env37468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37467_37468 : H12AffineEnvironment.transform 15 32803 env37467 = env37468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env37467 == env37468) = true)

theorem identity37468 : scanCanonicalize (H12AffineFastState.compose env37468 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound37468 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env37469 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,81,114,13461,2128,1025,80,12344,8400,8297,3,8328,65,10400,13461,4096,2048,9304,8280,252,33,13524,513]

theorem envBound37469 : H12AffineFastState.Bounded env37469 := by
  intro p hp
  have h : env37469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37468_37469 : H12AffineEnvironment.transform 14 81 env37468 = env37469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env37468 == env37469) = true)

theorem identity37469 : scanCanonicalize (H12AffineFastState.compose env37469 (packedSelected [0,1,2,3,5,6,7,8,12,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound37469 : packedSelected [0,1,2,3,5,6,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env37470 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,4096,8192,4312,81,114,12464,2128,36,80,12344,8400,8297,3,8328,65,10400,12464,4096,2048,8317,8280,252,33,12529,513]

theorem envBound37470 : H12AffineFastState.Bounded env37470 := by
  intro p hp
  have h : env37470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37469_37470 : H12AffineEnvironment.transform 9 37 env37469 = env37470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env37469 == env37470) = true)

theorem identity37470 : scanCanonicalize (H12AffineFastState.compose env37470 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37470 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env37471 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,4096,40,4312,81,114,4248,2128,36,80,4112,248,65,3,160,65,2184,4248,4096,2048,85,112,252,33,4313,513]

theorem envBound37471 : H12AffineFastState.Bounded env37471 := by
  intro p hp
  have h : env37471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37470_37471 : H12AffineEnvironment.transform 12 40 env37470 = env37471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37470 == env37471) = true)

theorem identity37471 : scanCanonicalize (H12AffineFastState.compose env37471 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37471 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env37472 : List Nat := [2,4,8,16,32,64,128,253,512,37,2048,2064,40,2248,81,114,2184,2128,36,80,2048,248,65,3,160,65,2184,2184,2064,2048,85,112,252,33,2249,513]

theorem envBound37472 : H12AffineFastState.Bounded env37472 := by
  intro p hp
  have h : env37472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37471_37472 : H12AffineEnvironment.transform 11 2064 env37471 = env37472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37471 == env37472) = true)

theorem identity37472 : scanCanonicalize (H12AffineFastState.compose env37472 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound37472 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env37473 : List Nat := [2,4,8,16,32,64,128,253,512,37,664,648,40,592,81,114,528,712,36,80,664,248,65,3,160,65,528,528,648,664,85,112,252,33,593,513]

theorem envBound37473 : H12AffineFastState.Bounded env37473 := by
  intro p hp
  have h : env37473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37472_37473 : H12AffineEnvironment.transform 10 664 env37472 = env37473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env37472 == env37473) = true)

theorem identity37473 : scanCanonicalize (H12AffineFastState.compose env37473 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37473 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env37474 : List Nat := [2,4,8,16,32,16,128,173,512,37,664,648,40,512,1,34,528,664,36,0,664,168,17,3,160,17,528,528,648,664,5,32,172,33,513,513]

theorem envBound37474 : H12AffineFastState.Bounded env37474 := by
  intro p hp
  have h : env37474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37473_37474 : H12AffineEnvironment.transform 5 16 env37473 = env37474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37473 == env37474) = true)

theorem identity37474 : scanCanonicalize (H12AffineFastState.compose env37474 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37474 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37475 : List Nat := [2,4,8,16,32,16,8,37,512,37,528,512,40,512,1,34,528,528,36,0,528,32,17,3,40,17,528,528,512,528,5,32,36,33,513,513]

theorem envBound37475 : H12AffineFastState.Bounded env37475 := by
  intro p hp
  have h : env37475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37474_37475 : H12AffineEnvironment.transform 6 8 env37474 = env37475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37474 == env37475) = true)

theorem identity37475 : scanCanonicalize (H12AffineFastState.compose env37475 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37476 : List Nat := [2,4,8,16,0,16,8,5,512,5,528,512,8,512,1,2,528,528,4,0,528,0,17,3,8,17,528,528,512,528,5,0,4,1,513,513]

theorem envBound37476 : H12AffineFastState.Bounded env37476 := by
  intro p hp
  have h : env37476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37475_37476 : H12AffineEnvironment.transform 4 0 env37475 = env37476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37475 == env37476) = true)

theorem identity37476 : scanCanonicalize (H12AffineFastState.compose env37476 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37476 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37477 : List Nat := [2,4,8,16,0,16,8,5,16,5,0,16,8,16,1,2,0,0,4,0,0,0,17,3,8,17,0,0,16,0,5,0,4,1,17,17]

theorem envBound37477 : H12AffineFastState.Bounded env37477 := by
  intro p hp
  have h : env37477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37476_37477 : H12AffineEnvironment.transform 8 16 env37476 = env37477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37476 == env37477) = true)

theorem identity37477 : scanCanonicalize (H12AffineFastState.compose env37477 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37477 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37478 : List Nat := [2,4,8,0,0,0,8,5,0,5,0,0,8,0,1,2,0,0,4,0,0,0,1,3,8,1,0,0,0,0,5,0,4,1,1,1]

theorem envBound37478 : H12AffineFastState.Bounded env37478 := by
  intro p hp
  have h : env37478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37477_37478 : H12AffineEnvironment.transform 3 0 env37477 = env37478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37477 == env37478) = true)

def env37479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,46277,35324,1025,32769,45460,41340,41413,98781,8328,65,10588,46276,4096,2556,41993,41460,257,33,46213,99295]

theorem envBound37479 : H12AffineFastState.Bounded env37479 := by
  intro p hp
  have h : env37479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37454_37479 : H12AffineEnvironment.transform 16 46277 env37454 = env37479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env37454 == env37479) = true)

theorem identity37479 : scanCanonicalize (H12AffineFastState.compose env37479 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37479 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env37480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5528,10401,1025,8540,4297,33,152,73856,8328,65,10588,5529,4096,2556,1364,169,257,33,5592,74370]

theorem envBound37480 : H12AffineFastState.Bounded env37480 := by
  intro p hp
  have h : env37480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37479_37480 : H12AffineEnvironment.transform 14 8541 env37479 = env37480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37479 == env37480) = true)

theorem identity37480 : scanCanonicalize (H12AffineFastState.compose env37480 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37480 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5528,10401,1025,8540,4297,33,152,139,8328,65,10588,5529,4096,2556,1364,169,257,33,5592,649]

theorem envBound37481 : H12AffineFastState.Bounded env37481 := by
  intro p hp
  have h : env37481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37480_37481 : H12AffineEnvironment.transform 15 8203 env37480 = env37481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37480 == env37481) = true)

theorem identity37481 : scanCanonicalize (H12AffineFastState.compose env37481 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37481 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37482 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,8313,8203,5308,10401,1025,8312,4297,33,152,139,8328,65,10360,5309,4096,2264,1136,169,37,33,5372,649]

theorem envBound37482 : H12AffineFastState.Bounded env37482 := by
  intro p hp
  have h : env37482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37481_37482 : H12AffineEnvironment.transform 7 36 env37481 = env37482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37481 == env37482) = true)

theorem identity37482 : scanCanonicalize (H12AffineFastState.compose env37482 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound37482 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env37483 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,121,5156,0,114,5308,2264,1025,1,4297,33,152,139,241,65,2049,5309,4096,2264,1136,169,37,33,5372,649]

theorem envBound37483 : H12AffineFastState.Bounded env37483 := by
  intro p hp
  have h : env37483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37482_37483 : H12AffineEnvironment.transform 12 121 env37482 = env37483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env37482 == env37483) = true)

theorem identity37483 : scanCanonicalize (H12AffineFastState.compose env37483 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1276) := by decide +kernel

theorem selectedBound37483 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env37484 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,1276,121,216,0,114,64,2264,1025,1,1077,33,152,139,241,65,2049,65,1276,2264,1136,169,37,33,0,649]

theorem envBound37484 : H12AffineFastState.Bounded env37484 := by
  intro p hp
  have h : env37484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37483_37484 : H12AffineEnvironment.transform 11 1276 env37483 = env37484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1276 env37483 == env37484) = true)

theorem identity37484 : scanCanonicalize (H12AffineFastState.compose env37484 (packedSelected [3,4,5,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37484 : packedSelected [3,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env37485 : List Nat := [2,4,8,16,32,64,128,36,512,20,2048,232,121,216,0,114,64,2264,21,1,33,33,152,139,241,65,2049,65,232,2264,100,169,37,33,0,649]

theorem envBound37485 : H12AffineFastState.Bounded env37485 := by
  intro p hp
  have h : env37485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37484_37485 : H12AffineEnvironment.transform 9 20 env37484 = env37485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37484 == env37485) = true)

theorem identity37485 : scanCanonicalize (H12AffineFastState.compose env37485 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37485 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37486 : List Nat := [2,4,8,16,32,17,128,36,512,20,2048,185,40,137,0,35,17,2185,21,1,33,33,152,139,160,16,2049,16,185,2185,53,169,37,33,0,649]

theorem envBound37486 : H12AffineFastState.Bounded env37486 := by
  intro p hp
  have h : env37486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37485_37486 : H12AffineEnvironment.transform 5 17 env37485 = env37486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37485 == env37486) = true)

theorem identity37486 : scanCanonicalize (H12AffineFastState.compose env37486 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound37486 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37487 : List Nat := [2,4,8,16,32,17,13,36,512,20,2048,52,40,4,0,35,17,2052,21,1,33,33,21,6,45,16,2049,16,52,2052,53,36,37,33,0,516]

theorem envBound37487 : H12AffineFastState.Bounded env37487 := by
  intro p hp
  have h : env37487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37486_37487 : H12AffineEnvironment.transform 6 13 env37486 = env37487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env37486 == env37487) = true)

theorem identity37487 : scanCanonicalize (H12AffineFastState.compose env37487 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound37487 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env37488 : List Nat := [2,4,8,16,4,17,13,0,512,20,2048,16,12,4,0,7,17,2052,21,1,5,5,21,6,9,16,2049,16,16,2052,17,0,1,5,0,516]

theorem envBound37488 : H12AffineFastState.Bounded env37488 := by
  intro p hp
  have h : env37488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37487_37488 : H12AffineEnvironment.transform 4 4 env37487 = env37488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env37487 == env37488) = true)

theorem identity37488 : scanCanonicalize (H12AffineFastState.compose env37488 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37488 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env37489 : List Nat := [2,0,8,16,0,17,9,0,512,16,2048,16,8,0,0,3,17,2048,17,1,1,1,17,2,9,16,2049,16,16,2048,17,0,1,1,0,512]

theorem envBound37489 : H12AffineFastState.Bounded env37489 := by
  intro p hp
  have h : env37489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37488_37489 : H12AffineEnvironment.transform 1 0 env37488 = env37489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37488 == env37489) = true)

theorem identity37489 : scanCanonicalize (H12AffineFastState.compose env37489 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound37489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37490 : List Nat := [2,0,8,16,0,17,9,0,512,16,17,16,8,0,0,3,17,17,17,1,1,1,17,2,9,16,16,16,16,17,17,0,1,1,0,512]

theorem envBound37490 : H12AffineFastState.Bounded env37490 := by
  intro p hp
  have h : env37490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37489_37490 : H12AffineEnvironment.transform 10 17 env37489 = env37490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env37489 == env37490) = true)

theorem identity37490 : scanCanonicalize (H12AffineFastState.compose env37490 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37491 : List Nat := [1,0,8,16,0,17,9,0,512,16,17,16,8,0,0,0,17,17,17,1,1,1,17,1,9,16,16,16,16,17,17,0,1,1,0,512]

theorem envBound37491 : H12AffineFastState.Bounded env37491 := by
  intro p hp
  have h : env37491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37490_37491 : H12AffineEnvironment.transform 0 1 env37490 = env37491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37490 == env37491) = true)

theorem identity37491 : scanCanonicalize (H12AffineFastState.compose env37491 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37492 : List Nat := [1,0,8,1,0,0,9,0,512,1,0,1,8,0,0,0,0,0,0,1,1,1,0,1,9,1,1,1,1,0,0,0,1,1,0,512]

theorem envBound37492 : H12AffineFastState.Bounded env37492 := by
  intro p hp
  have h : env37492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37491_37492 : H12AffineEnvironment.transform 3 1 env37491 = env37492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37491 == env37492) = true)

theorem identity37492 : scanCanonicalize (H12AffineFastState.compose env37492 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37492 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37493 : List Nat := [1,0,1,1,0,0,0,0,512,1,0,1,1,0,0,0,0,0,0,1,1,1,0,1,0,1,1,1,1,0,0,0,1,1,0,512]

theorem envBound37493 : H12AffineFastState.Bounded env37493 := by
  intro p hp
  have h : env37493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37492_37493 : H12AffineEnvironment.transform 2 1 env37492 = env37493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37492 == env37493) = true)

def env37494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35324,1025,32769,45461,41340,41412,98781,8328,65,171417,46277,4097,179513,41992,41460,257,32,46213,99294]

theorem envBound37494 : H12AffineFastState.Bounded env37494 := by
  intro p hp
  have h : env37494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37453_37494 : H12AffineEnvironment.transform 13 5377 env37453 = env37494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37453 == env37494) = true)

theorem identity37494 : scanCanonicalize (H12AffineFastState.compose env37494 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37494 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10401,1025,8540,4296,33,153,73856,8328,65,146628,5528,4097,138340,1365,169,257,32,5592,74371]

theorem envBound37495 : H12AffineFastState.Bounded env37495 := by
  intro p hp
  have h : env37495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37494_37495 : H12AffineEnvironment.transform 14 8541 env37494 = env37495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37494 == env37495) = true)

theorem identity37495 : scanCanonicalize (H12AffineFastState.compose env37495 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound37495 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env37496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,10401,1025,8540,4296,33,153,2,8328,65,146628,5528,4097,138340,1365,169,257,32,5592,513]

theorem envBound37496 : H12AffineFastState.Bounded env37496 := by
  intro p hp
  have h : env37496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37495_37496 : H12AffineEnvironment.transform 15 8322 env37495 = env37496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env37495 == env37496) = true)

theorem identity37496 : scanCanonicalize (H12AffineFastState.compose env37496 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound37496 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env37497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,13341,10401,1025,8540,4296,33,153,2,8328,65,2265,5528,4097,10361,1365,169,257,32,5592,513]

theorem envBound37497 : H12AffineFastState.Bounded env37497 := by
  intro p hp
  have h : env37497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37496_37497 : H12AffineEnvironment.transform 16 13341 env37496 = env37497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env37496 == env37497) = true)

theorem identity37497 : scanCanonicalize (H12AffineFastState.compose env37497 (packedSelected [4,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37497 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env37498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,342,5577,2421,1025,136,4296,33,153,2,348,65,2265,5528,4097,2477,1365,169,257,32,5592,513]

theorem envBound37498 : H12AffineFastState.Bounded env37498 := by
  intro p hp
  have h : env37498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37497_37498 : H12AffineEnvironment.transform 12 468 env37497 = env37498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37497 == env37498) = true)

theorem identity37498 : scanCanonicalize (H12AffineFastState.compose env37498 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37498 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env37499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5440,2421,1025,1,4161,33,16,2,348,65,2128,5393,4097,2340,1365,32,257,32,5457,513]

theorem envBound37499 : H12AffineFastState.Bounded env37499 := by
  intro p hp
  have h : env37499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37498_37499 : H12AffineEnvironment.transform 6 9 env37498 = env37499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37498 == env37499) = true)

theorem identity37499 : scanCanonicalize (H12AffineFastState.compose env37499 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound37499 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,349,2129,0,342,2064,2421,1025,1,3345,33,16,2,348,65,2128,2113,3409,2340,1365,32,257,32,2049,513]

theorem envBound37500 : H12AffineFastState.Bounded env37500 := by
  intro p hp
  have h : env37500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37499_37500 : H12AffineEnvironment.transform 11 3408 env37499 = env37500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env37499 == env37500) = true)

theorem identity37500 : scanCanonicalize (H12AffineFastState.compose env37500 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound37500 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1281,349,0,0,342,65,292,1025,1,1344,33,16,2,348,65,1,16,1280,373,1365,32,257,32,80,513]

theorem envBound37501 : H12AffineFastState.Bounded env37501 := by
  intro p hp
  have h : env37501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37500_37501 : H12AffineEnvironment.transform 10 81 env37500 = env37501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env37500 == env37501) = true)

theorem identity37501 : scanCanonicalize (H12AffineFastState.compose env37501 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37501 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37502 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1281,268,0,0,263,16,292,1025,1,1297,33,16,2,269,16,1,16,1280,292,1284,32,257,32,1,513]

theorem envBound37502 : H12AffineFastState.Bounded env37502 := by
  intro p hp
  have h : env37502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37501_37502 : H12AffineEnvironment.transform 5 17 env37501 = env37502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37501 == env37502) = true)

theorem identity37502 : scanCanonicalize (H12AffineFastState.compose env37502 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37503 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,309,268,0,0,263,16,292,53,1,293,33,16,2,269,16,1,16,308,292,304,32,257,32,1,513]

theorem envBound37503 : H12AffineFastState.Bounded env37503 := by
  intro p hp
  have h : env37503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37502_37503 : H12AffineEnvironment.transform 9 52 env37502 = env37503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37502 == env37503) = true)

theorem identity37503 : scanCanonicalize (H12AffineFastState.compose env37503 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound37503 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37504 : List Nat := [2,4,8,16,32,17,9,256,11,52,0,309,268,0,0,263,16,292,53,1,293,33,16,2,269,16,1,16,308,292,304,32,257,32,1,10]

theorem envBound37504 : H12AffineFastState.Bounded env37504 := by
  intro p hp
  have h : env37504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37503_37504 : H12AffineEnvironment.transform 8 11 env37503 = env37504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env37503 == env37504) = true)

theorem identity37504 : scanCanonicalize (H12AffineFastState.compose env37504 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37504 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37505 : List Nat := [2,4,8,16,1,17,9,256,11,21,0,276,268,0,0,263,16,261,20,1,260,0,16,2,269,16,1,16,277,261,273,1,257,1,1,10]

theorem envBound37505 : H12AffineFastState.Bounded env37505 := by
  intro p hp
  have h : env37505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37504_37505 : H12AffineEnvironment.transform 4 1 env37504 = env37505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37504 == env37505) = true)

theorem identity37505 : scanCanonicalize (H12AffineFastState.compose env37505 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37505 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37506 : List Nat := [2,4,8,16,1,17,9,4,11,21,0,16,8,0,0,3,16,1,20,1,0,0,16,2,9,16,1,16,17,1,21,1,5,1,1,10]

theorem envBound37506 : H12AffineFastState.Bounded env37506 := by
  intro p hp
  have h : env37506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37505_37506 : H12AffineEnvironment.transform 7 4 env37505 = env37506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37505 == env37506) = true)

theorem identity37506 : scanCanonicalize (H12AffineFastState.compose env37506 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound37506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37507 : List Nat := [2,4,8,14,1,15,9,4,11,11,0,14,8,0,0,3,14,1,10,1,0,0,14,2,9,14,1,14,15,1,11,1,5,1,1,10]

theorem envBound37507 : H12AffineFastState.Bounded env37507 := by
  intro p hp
  have h : env37507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37506_37507 : H12AffineEnvironment.transform 3 14 env37506 = env37507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env37506 == env37507) = true)

theorem identity37507 : scanCanonicalize (H12AffineFastState.compose env37507 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37508 : List Nat := [2,4,4,2,1,3,5,4,7,7,0,2,4,0,0,3,2,1,6,1,0,0,2,2,5,2,1,2,3,1,7,1,5,1,1,6]

theorem envBound37508 : H12AffineFastState.Bounded env37508 := by
  intro p hp
  have h : env37508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37507_37508 : H12AffineEnvironment.transform 2 4 env37507 = env37508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37507 == env37508) = true)

def env37509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290152,272513,294201,98781,8328,65,398436,288824,17664,179513,293109,41461,257,21793,46213,352035]

theorem envBound37509 : H12AffineFastState.Bounded env37509 := by
  intro p hp
  have h : env37509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37451_37509 : H12AffineEnvironment.transform 21 272513 env37451 = env37509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37451 == env37509) = true)

theorem identity37509 : scanCanonicalize (H12AffineFastState.compose env37509 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound37509 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,290152,272513,294201,95497,8328,65,398436,288824,17664,149997,293109,21793,257,21793,16465,352035]

theorem envBound37510 : H12AffineFastState.Bounded env37510 := by
  intro p hp
  have h : env37510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37509_37510 : H12AffineEnvironment.transform 14 29908 env37509 = env37510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env37509 == env37510) = true)

theorem identity37510 : scanCanonicalize (H12AffineFastState.compose env37510 (packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound37510 : packedSelected [0,1,3,4,5,7,8,10,11,15,16,19,20,22,32,38] rootPS < 2^1333 := by decide +kernel

def env37511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,131072,262144,1025,29909,290152,272513,294201,139,8328,65,398436,288824,17664,149997,293109,21793,257,21793,16465,273057]

theorem envBound37511 : H12AffineFastState.Bounded env37511 := by
  intro p hp
  have h : env37511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37510_37511 : H12AffineEnvironment.transform 15 30082 env37510 = env37511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env37510 == env37511) = true)

theorem identity37511 : scanCanonicalize (H12AffineFastState.compose env37511 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound37511 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30082,131072,2476,1025,29909,25796,8493,29845,139,8328,65,138696,24980,17664,149997,29017,21793,257,21793,16465,8973]

theorem envBound37512 : H12AffineFastState.Bounded env37512 := by
  intro p hp
  have h : env37512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37511_37512 : H12AffineEnvironment.transform 17 2476 env37511 = env37512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env37511 == env37512) = true)

theorem identity37512 : scanCanonicalize (H12AffineFastState.compose env37512 (packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 12512) := by decide +kernel

theorem selectedBound37512 : packedSelected [1,5,8,11,12,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env37513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12512,1076,1378,131072,2476,1025,1077,5156,8493,1141,139,8328,65,138696,4468,13792,145677,441,9665,257,9665,12465,8973]

theorem envBound37513 : H12AffineFastState.Bounded env37513 := by
  intro p hp
  have h : env37513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37512_37513 : H12AffineEnvironment.transform 13 12512 env37512 = env37513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12512 env37512 == env37513) = true)

theorem identity37513 : scanCanonicalize (H12AffineFastState.compose env37513 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 12328) := by decide +kernel

theorem selectedBound37513 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env37514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12512,1076,1378,12328,2476,1025,1077,5156,8493,1141,139,8328,65,11744,4468,13792,2341,441,9665,257,9665,12465,8973]

theorem envBound37514 : H12AffineFastState.Bounded env37514 := by
  intro p hp
  have h : env37514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37513_37514 : H12AffineEnvironment.transform 16 12328 env37513 = env37514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12328 env37513 == env37514) = true)

theorem identity37514 : scanCanonicalize (H12AffineFastState.compose env37514 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 7380) := by decide +kernel

theorem selectedBound37514 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env37515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7380,3124,1076,1378,3324,2476,1025,1077,5156,7673,1141,139,7260,65,4404,4468,2356,2341,441,6421,257,6421,3173,8153]

theorem envBound37515 : H12AffineFastState.Bounded env37515 := by
  intro p hp
  have h : env37515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37514_37515 : H12AffineEnvironment.transform 12 7380 env37514 = env37515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7380 env37514 == env37515) = true)

theorem identity37515 : scanCanonicalize (H12AffineFastState.compose env37515 (packedSelected [1,2,3,4,5,6,8,9,10,11,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound37515 : packedSelected [1,2,3,4,5,6,8,9,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env37516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,309,3553,3124,1076,1378,3324,2476,1025,1077,1297,3276,1141,139,3433,65,1,65,2356,2341,441,2080,257,2080,3173,3820]

theorem envBound37516 : H12AffineFastState.Bounded env37516 := by
  intro p hp
  have h : env37516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37515_37516 : H12AffineEnvironment.transform 11 309 env37515 = env37516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env37515 == env37516) = true)

theorem identity37516 : scanCanonicalize (H12AffineFastState.compose env37516 (packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound37516 : packedSelected [0,1,2,3,5,6,7,8,9,11,12,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37517 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,309,2088,2557,509,171,2357,2476,456,508,216,2309,444,139,2208,65,1,65,2356,2341,441,2080,257,2080,2476,2853]

theorem envBound37517 : H12AffineFastState.Bounded env37517 := by
  intro p hp
  have h : env37517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37516_37517 : H12AffineEnvironment.transform 9 457 env37516 = env37517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env37516 == env37517) = true)

theorem identity37517 : scanCanonicalize (H12AffineFastState.compose env37517 (packedSelected [0,1,3,4,5,7,8,9,11,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37517 : packedSelected [0,1,3,4,5,7,8,9,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env37518 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,17,2088,2265,217,171,2065,2184,236,216,216,2081,152,139,2208,65,1,65,2064,2049,157,2080,37,2080,2184,2561]

theorem envBound37518 : H12AffineFastState.Bounded env37518 := by
  intro p hp
  have h : env37518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37517_37518 : H12AffineEnvironment.transform 7 36 env37517 = env37518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37517 == env37518) = true)

theorem identity37518 : scanCanonicalize (H12AffineFastState.compose env37518 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound37518 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37519 : List Nat := [2,4,8,16,32,64,128,36,512,237,80,17,120,137,217,171,65,216,236,216,216,113,152,139,240,65,1,65,64,81,157,112,37,112,216,593]

theorem envBound37519 : H12AffineFastState.Bounded env37519 := by
  intro p hp
  have h : env37519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37518_37519 : H12AffineEnvironment.transform 10 80 env37518 = env37519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env37518 == env37519) = true)

theorem identity37519 : scanCanonicalize (H12AffineFastState.compose env37519 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound37519 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37520 : List Nat := [2,4,8,16,32,64,89,36,512,52,80,17,120,80,0,114,65,1,53,1,1,113,65,82,41,65,1,65,64,81,68,112,37,112,1,593]

theorem envBound37520 : H12AffineFastState.Bounded env37520 := by
  intro p hp
  have h : env37520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37519_37520 : H12AffineEnvironment.transform 6 89 env37519 = env37520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env37519 == env37520) = true)

theorem identity37520 : scanCanonicalize (H12AffineFastState.compose env37520 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37520 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37521 : List Nat := [2,4,8,16,0,64,89,4,512,20,80,17,88,80,0,82,65,1,21,1,1,81,65,82,9,65,1,65,64,81,68,80,5,80,1,593]

theorem envBound37521 : H12AffineFastState.Bounded env37521 := by
  intro p hp
  have h : env37521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37520_37521 : H12AffineEnvironment.transform 4 0 env37520 = env37521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37520 == env37521) = true)

theorem identity37521 : scanCanonicalize (H12AffineFastState.compose env37521 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37521 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37522 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,17,9,1,0,3,16,1,21,1,1,0,16,3,9,16,1,16,17,0,21,1,5,1,1,512]

theorem envBound37522 : H12AffineFastState.Bounded env37522 := by
  intro p hp
  have h : env37522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37521_37522 : H12AffineEnvironment.transform 5 17 env37521 = env37522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37521 == env37522) = true)

theorem identity37522 : scanCanonicalize (H12AffineFastState.compose env37522 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37523 : List Nat := [2,4,8,1,0,0,8,4,512,5,1,0,9,1,0,3,1,1,4,1,1,0,1,3,9,1,1,1,0,0,4,1,5,1,1,512]

theorem envBound37523 : H12AffineFastState.Bounded env37523 := by
  intro p hp
  have h : env37523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37522_37523 : H12AffineEnvironment.transform 3 1 env37522 = env37523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37522 == env37523) = true)

theorem identity37523 : scanCanonicalize (H12AffineFastState.compose env37523 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37523 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37524 : List Nat := [2,1,8,1,0,0,8,1,512,0,1,0,9,1,0,3,1,1,1,1,1,0,1,3,9,1,1,1,0,0,1,1,0,1,1,512]

theorem envBound37524 : H12AffineFastState.Bounded env37524 := by
  intro p hp
  have h : env37524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37523_37524 : H12AffineEnvironment.transform 1 1 env37523 = env37524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37523 == env37524) = true)

def env37525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,4194304,294201,98780,8328,65,4340964,288824,17665,179513,293108,4491636,257,21793,46213,352034]

theorem envBound37525 : H12AffineFastState.Bounded env37525 := by
  intro p hp
  have h : env37525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37450_37525 : H12AffineEnvironment.transform 20 290153 env37450 = env37525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290153 env37450 == env37525) = true)

def env37526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272512,294201,98780,8328,65,398436,288824,17665,179513,293108,41460,257,21793,46213,352034]

theorem envBound37526 : H12AffineFastState.Bounded env37526 := by
  intro p hp
  have h : env37526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1