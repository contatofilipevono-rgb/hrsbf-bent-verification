import H12CloudChart1Data097

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound24819 : H12AffineFastState.Bounded env24819 := by
  intro p hp
  have h : env24819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24818_24819 : H12AffineEnvironment.transform 4 1 env24818 = env24819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24818 == env24819) = true)

def env24820 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1044,0,3,1028,2048,1024,1,0,1,16,3,9,16,2049,1028,16,2049,1024,1,4,0,1044,512]

theorem envBound24820 : H12AffineFastState.Bounded env24820 := by
  intro p hp
  have h : env24820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24819_24820 : H12AffineEnvironment.transform 11 16 env24819 = env24820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env24819 == env24820) = true)

theorem identity24820 : scanCanonicalize (H12AffineFastState.compose env24820 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24821 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,1,0,3,17,2048,21,1,0,1,16,3,9,16,2049,17,16,2049,21,1,4,0,1,512]

theorem envBound24821 : H12AffineFastState.Bounded env24821 := by
  intro p hp
  have h : env24821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24820_24821 : H12AffineEnvironment.transform 9 21 env24820 = env24821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24820 == env24821) = true)

theorem identity24821 : scanCanonicalize (H12AffineFastState.compose env24821 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound24821 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24822 : List Nat := [2,4,8,16,1,16,9,4,30,21,2048,16,8,1,0,3,17,2048,21,1,0,1,16,3,9,16,2049,17,16,2049,21,1,4,0,1,30]

theorem envBound24822 : H12AffineFastState.Bounded env24822 := by
  intro p hp
  have h : env24822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24821_24822 : H12AffineEnvironment.transform 8 30 env24821 = env24822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env24821 == env24822) = true)

def leafEnv24822 : List Nat := [2,4,8,16,1,16,9,4,30,21,2048,16,8,1,0,3,17,2048,21,1,0,1,16,3,21,9,1,16,2049,17,16,2049,21,1,4,0,4,2,1,30,1,0,0]

def active24822 : List Nat := [0,1,2,3,10]

def tree24822 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24822 : H12WitnessSearch.Good tree24822 := H12GlobalWitnessIndex.good

theorem leafIdentity24822 : H12AffineFastState.composeSystem env24822 rootObs = leafEnv24822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24822 rootObs == leafEnv24822) = true)

theorem terminalChecked24822 : H12PackedTerminal.terminalCheckFast leafEnv24822 active24822 tree24822 = true := by decide +kernel

def env24823 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1045,0,3,1029,2048,1024,1,1,1,16,3,9,16,2049,1029,17,2049,1024,1,4,0,1045,512]

theorem envBound24823 : H12AffineFastState.Bounded env24823 := by
  intro p hp
  have h : env24823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24819_24823 : H12AffineEnvironment.transform 11 17 env24819 = env24823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24819 == env24823) = true)

def env24824 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,1,0,3,17,2048,20,1,1,1,16,3,9,16,2049,17,17,2049,20,1,4,0,1,512]

theorem envBound24824 : H12AffineFastState.Bounded env24824 := by
  intro p hp
  have h : env24824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24823_24824 : H12AffineEnvironment.transform 9 20 env24823 = env24824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24823 == env24824) = true)

theorem identity24824 : scanCanonicalize (H12AffineFastState.compose env24824 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound24824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24825 : List Nat := [2,4,8,5,1,5,9,4,512,1,2048,4,8,1,0,3,4,2048,1,1,1,1,5,3,9,5,2049,4,4,2049,1,1,4,0,1,512]

theorem envBound24825 : H12AffineFastState.Bounded env24825 := by
  intro p hp
  have h : env24825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24824_24825 : H12AffineEnvironment.transform 3 5 env24824 = env24825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env24824 == env24825) = true)

def leafEnv24825 : List Nat := [2,4,8,5,1,5,9,4,512,1,2048,4,8,1,0,3,4,2048,1,1,1,1,5,3,1,9,1,5,2049,4,4,2049,1,1,4,0,4,2,1,512,1,1,0]

def active24825 : List Nat := [0,1,2,8,10]

def tree24825 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24825 : H12WitnessSearch.Good tree24825 := H12GlobalWitnessIndex.good

theorem leafIdentity24825 : H12AffineFastState.composeSystem env24825 rootObs = leafEnv24825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24825 rootObs == leafEnv24825) = true)

theorem terminalChecked24825 : H12PackedTerminal.terminalCheckFast leafEnv24825 active24825 tree24825 = true := by decide +kernel

def env24826 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,0,0,3,16,2048,21,1,1,1,16,3,9,16,2049,16,17,2049,21,1,4,0,0,512]

theorem envBound24826 : H12AffineFastState.Bounded env24826 := by
  intro p hp
  have h : env24826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24823_24826 : H12AffineEnvironment.transform 9 21 env24823 = env24826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24823 == env24826) = true)

theorem identity24826 : scanCanonicalize (H12AffineFastState.compose env24826 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound24826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24827 : List Nat := [2,4,8,16,1,16,9,4,31,21,2048,17,8,0,0,3,16,2048,21,1,1,1,16,3,9,16,2049,16,17,2049,21,1,4,0,0,31]

theorem envBound24827 : H12AffineFastState.Bounded env24827 := by
  intro p hp
  have h : env24827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24826_24827 : H12AffineEnvironment.transform 8 31 env24826 = env24827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env24826 == env24827) = true)

def leafEnv24827 : List Nat := [2,4,8,16,1,16,9,4,31,21,2048,17,8,0,0,3,16,2048,21,1,1,1,16,3,21,9,1,16,2049,16,17,2049,21,1,4,0,4,2,0,31,1,1,0]

def active24827 : List Nat := [0,1,2,3,10]

def tree24827 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24827 : H12WitnessSearch.Good tree24827 := H12GlobalWitnessIndex.good

theorem leafIdentity24827 : H12AffineFastState.composeSystem env24827 rootObs = leafEnv24827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24827 rootObs == leafEnv24827) = true)

theorem terminalChecked24827 : H12PackedTerminal.terminalCheckFast leafEnv24827 active24827 tree24827 = true := by decide +kernel

def env24828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8193,64,4677966,2172251,2118977,442384,75102,6407191,256,2188651,2196550,513]

theorem envBound24828 : H12AffineFastState.Bounded env24828 := by
  intro p hp
  have h : env24828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24807_24828 : H12AffineEnvironment.transform 22 17 env24807 = env24828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24807 == env24828) = true)

theorem identity24828 : scanCanonicalize (H12AffineFastState.compose env24828 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24828 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,2097152,4194304,17,41311,8193,64,4456788,2172251,2118977,368650,75102,6407191,256,2188651,2196550,513]

theorem envBound24829 : H12AffineFastState.Bounded env24829 := by
  intro p hp
  have h : env24829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24828_24829 : H12AffineEnvironment.transform 16 90138 env24828 = env24829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24828 == env24829) = true)

theorem identity24829 : scanCanonicalize (H12AffineFastState.compose env24829 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound24829 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,262144,1024,29005,2097152,4194304,17,20499,8193,64,4456788,2172251,2118977,348486,75102,6370651,256,2188651,2192650,513]

theorem envBound24830 : H12AffineFastState.Bounded env24830 := by
  intro p hp
  have h : env24830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24829_24830 : H12AffineEnvironment.transform 14 29004 env24829 = env24830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env24829 == env24830) = true)

theorem identity24830 : scanCanonicalize (H12AffineFastState.compose env24830 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 30777) := by decide +kernel

theorem selectedBound24830 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,2097152,4194304,17,20499,8193,64,4225389,2172251,2118977,76159,75102,6370651,256,2188651,2192650,513]

theorem envBound24831 : H12AffineFastState.Bounded env24831 := by
  intro p hp
  have h : env24831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24830_24831 : H12AffineEnvironment.transform 17 30777 env24830 = env24831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30777 env24830 == env24831) = true)

def env24832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5456,4194304,17,20499,8193,64,4225389,77835,16401,76159,75102,4268043,256,94267,90202,513]

theorem envBound24832 : H12AffineFastState.Bounded env24832 := by
  intro p hp
  have h : env24832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24831_24832 : H12AffineEnvironment.transform 20 5456 env24831 = env24832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env24831 == env24832) = true)

theorem identity24832 : scanCanonicalize (H12AffineFastState.compose env24832 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 94266) := by decide +kernel

theorem selectedBound24832 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5456,94266,17,20499,8193,64,67927,77835,16401,76159,75102,20529,256,94267,90202,513]

theorem envBound24833 : H12AffineFastState.Bounded env24833 := by
  intro p hp
  have h : env24833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24832_24833 : H12AffineEnvironment.transform 21 94266 env24832 = env24833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 94266 env24832 == env24833) = true)

theorem identity24833 : scanCanonicalize (H12AffineFastState.compose env24833 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24833 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30777,1024,29005,5456,20529,17,20499,8193,64,10588,4096,16401,2420,1365,20529,256,20528,16465,513]

theorem envBound24834 : H12AffineFastState.Bounded env24834 := by
  intro p hp
  have h : env24834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24833_24834 : H12AffineEnvironment.transform 15 8203 env24833 = env24834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24833 == env24834) = true)

theorem identity24834 : scanCanonicalize (H12AffineFastState.compose env24834 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound24834 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8540,8203,4097,10281,1024,8541,5456,33,17,3,8193,64,10588,4096,4097,2420,1365,33,256,32,4161,513]

theorem envBound24835 : H12AffineFastState.Bounded env24835 := by
  intro p hp
  have h : env24835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24834_24835 : H12AffineEnvironment.transform 13 4112 env24834 = env24835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env24834 == env24835) = true)

def env24836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5457,4194304,17,20499,8193,64,4225389,77834,16400,76159,75102,4268042,256,94266,90203,513]

theorem envBound24836 : H12AffineFastState.Bounded env24836 := by
  intro p hp
  have h : env24836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24831_24836 : H12AffineEnvironment.transform 20 5457 env24831 = env24836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env24831 == env24836) = true)

theorem identity24836 : scanCanonicalize (H12AffineFastState.compose env24836 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound24836 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30777,1024,29005,5457,73770,17,20499,8193,64,88391,77834,16400,76159,75102,32,256,94266,90203,513]

theorem envBound24837 : H12AffineFastState.Bounded env24837 := by
  intro p hp
  have h : env24837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24836_24837 : H12AffineEnvironment.transform 21 73770 env24836 = env24837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env24836 == env24837) = true)

theorem identity24837 : scanCanonicalize (H12AffineFastState.compose env24837 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound24837 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,65536,77835,10280,1024,8540,5457,73770,17,2,8193,64,67926,77834,4097,76159,75102,32,256,73771,77898,513]

theorem envBound24838 : H12AffineFastState.Bounded env24838 := by
  intro p hp
  have h : env24838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24837_24838 : H12AffineEnvironment.transform 13 4113 env24837 = env24838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env24837 == env24838) = true)

theorem identity24838 : scanCanonicalize (H12AffineFastState.compose env24838 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound24838 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env24839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,8192,3172,8541,65536,76926,10280,1024,8540,2340,73770,17,2,8193,64,67926,76927,3188,76159,75102,32,256,73771,76863,513]

theorem envBound24839 : H12AffineFastState.Bounded env24839 := by
  intro p hp
  have h : env24839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24838_24839 : H12AffineEnvironment.transform 11 3189 env24838 = env24839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env24838 == env24839) = true)

def env24840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound24840 : H12AffineFastState.Bounded env24840 := by
  intro p hp
  have h : env24840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24726_24840 : H12AffineEnvironment.transform 18 1025 env24726 = env24840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24726 == env24840) = true)

theorem identity24840 : scanCanonicalize (H12AffineFastState.compose env24840 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 213470) := by decide +kernel

theorem selectedBound24840 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,213470,16777216,8328,64,21266911,18973836,2299022,360926,16958926,23160257,257,19039603,19031254,17031705]

theorem envBound24841 : H12AffineFastState.Bounded env24841 := by
  intro p hp
  have h : env24841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24840_24841 : H12AffineEnvironment.transform 22 213470 env24840 = env24841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 213470 env24840 == env24841) = true)

def env24842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411972,213470,16777216,8328,64,16959643,18973836,2299022,360926,16958926,19344517,257,19039603,19031254,17031705]

theorem envBound24842 : H12AffineFastState.Bounded env24842 := by
  intro p hp
  have h : env24842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24841_24842 : H12AffineEnvironment.transform 21 411972 env24841 = env24842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411972 env24841 == env24842) = true)

def env24843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213470,16777216,8328,64,16959643,16974300,102878,360926,16958926,17148373,257,16777251,16834950,17031705]

theorem envBound24843 : H12AffineFastState.Bounded env24843 := by
  intro p hp
  have h : env24843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24842_24843 : H12AffineEnvironment.transform 20 165200 env24842 = env24843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env24842 == env24843) = true)

theorem identity24843 : scanCanonicalize (H12AffineFastState.compose env24843 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106505) := by decide +kernel

theorem selectedBound24843 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env24844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411972,213470,106505,8328,64,223378,172501,102878,360926,222663,264668,257,106538,82319,147984]

theorem envBound24844 : H12AffineFastState.Bounded env24844 := by
  intro p hp
  have h : env24844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24843_24844 : H12AffineEnvironment.transform 23 106505 env24843 = env24844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106505 env24843 == env24844) = true)

def env24845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,131072,262144,1025,21761,151632,411972,213470,95497,8328,64,223378,160981,83166,349406,222663,264668,257,95530,82319,147984]

theorem envBound24845 : H12AffineFastState.Bounded env24845 := by
  intro p hp
  have h : env24845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24844_24845 : H12AffineEnvironment.transform 14 21760 env24844 = env24845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env24844 == env24845) = true)

theorem identity24845 : scanCanonicalize (H12AffineFastState.compose env24845 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24845 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,262144,1025,21761,151632,411972,156117,21762,8328,64,149657,160981,25813,292053,148940,264668,257,21793,24964,147984]

theorem envBound24846 : H12AffineFastState.Bounded env24846 := by
  intro p hp
  have h : env24846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24845_24846 : H12AffineEnvironment.transform 15 8203 env24845 = env24846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24845 == env24846) = true)

def env24847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,10280,1025,21761,151632,156012,156117,21762,8328,64,149657,160981,25813,23805,148940,8692,257,21793,24964,147984]

theorem envBound24847 : H12AffineFastState.Bounded env24847 := by
  intro p hp
  have h : env24847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24846_24847 : H12AffineEnvironment.transform 17 10280 env24846 = env24847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24846 == env24847) = true)

theorem identity24847 : scanCanonicalize (H12AffineFastState.compose env24847 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 17800) := by decide +kernel

theorem selectedBound24847 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,17800,10280,1025,21761,5592,9444,9309,21762,8328,64,3345,12637,25813,23805,68,8692,257,21793,24964,1944]

theorem envBound24848 : H12AffineFastState.Bounded env24848 := by
  intro p hp
  have h : env24848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24847_24848 : H12AffineEnvironment.transform 16 17800 env24847 = env24848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17800 env24847 == env24848) = true)

theorem identity24848 : scanCanonicalize (H12AffineFastState.compose env24848 (packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound24848 : packedSelected [1,2,4,6,8,11,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,21760,1467,17800,3480,1025,21761,5592,340,493,21762,1336,64,3345,5357,16741,23805,68,1092,257,21793,17460,1944]

theorem envBound24849 : H12AffineFastState.Bounded env24849 := by
  intro p hp
  have h : env24849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24848_24849 : H12AffineEnvironment.transform 12 1456 env24848 = env24849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env24848 == env24849) = true)

theorem identity24849 : scanCanonicalize (H12AffineFastState.compose env24849 (packedSelected [1,3,4,7,9,12,15,17,24,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound24849 : packedSelected [1,3,4,7,9,12,15,17,24,27,28] rootPS < 2^1333 := by decide +kernel

def env24850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,4405,1077,1467,5309,3480,1025,1076,5592,340,493,1079,1336,64,3345,5357,4176,3528,68,1092,257,1044,5377,1944]

theorem envBound24850 : H12AffineFastState.Bounded env24850 := by
  intro p hp
  have h : env24850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24849_24850 : H12AffineEnvironment.transform 13 4405 env24849 = env24850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env24849 == env24850) = true)

theorem identity24850 : scanCanonicalize (H12AffineFastState.compose env24850 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound24850 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24851 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1100,4297,1077,1095,5309,3172,1025,1076,5156,168,17,1079,1220,64,3309,5357,4176,3124,68,1092,253,1044,5373,1636]

theorem envBound24851 : H12AffineFastState.Bounded env24851 := by
  intro p hp
  have h : env24851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24850_24851 : H12AffineEnvironment.transform 7 252 env24850 = env24851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24850 == env24851) = true)

theorem identity24851 : scanCanonicalize (H12AffineFastState.compose env24851 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound24851 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env24852 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,4096,161,4297,216,170,4176,2185,236,217,4297,168,17,218,41,64,2048,4096,4176,2265,68,169,253,249,4112,649]

theorem envBound24852 : H12AffineFastState.Bounded env24852 := by
  intro p hp
  have h : env24852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24851_24852 : H12AffineEnvironment.transform 9 237 env24851 = env24852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env24851 == env24852) = true)

theorem identity24852 : scanCanonicalize (H12AffineFastState.compose env24852 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound24852 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env24853 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,2064,161,2265,216,170,2112,2185,236,217,2265,168,17,218,41,64,2048,2064,2112,2265,68,169,253,249,2048,649]

theorem envBound24853 : H12AffineFastState.Bounded env24853 := by
  intro p hp
  have h : env24853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24852_24853 : H12AffineEnvironment.transform 11 2064 env24852 = env24853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env24852 == env24853) = true)

theorem identity24853 : scanCanonicalize (H12AffineFastState.compose env24853 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24853 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24854 : List Nat := [2,4,8,16,32,64,88,36,512,53,2048,2064,121,2049,0,114,2112,2129,52,1,2049,112,17,2,41,64,2048,2064,2112,2049,68,113,37,33,2048,593]

theorem envBound24854 : H12AffineFastState.Bounded env24854 := by
  intro p hp
  have h : env24854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24853_24854 : H12AffineEnvironment.transform 6 88 env24853 = env24854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24853 == env24854) = true)

theorem identity24854 : scanCanonicalize (H12AffineFastState.compose env24854 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound24854 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env24855 : List Nat := [2,4,8,16,32,64,88,36,512,53,81,65,121,80,0,114,17,0,52,1,80,112,17,2,41,64,81,65,17,80,68,113,37,33,81,593]

theorem envBound24855 : H12AffineFastState.Bounded env24855 := by
  intro p hp
  have h : env24855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24854_24855 : H12AffineEnvironment.transform 10 81 env24854 = env24855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24854 == env24855) = true)

theorem identity24855 : scanCanonicalize (H12AffineFastState.compose env24855 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24855 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24856 : List Nat := [2,4,8,16,32,17,9,36,512,53,0,16,40,1,0,35,17,0,52,1,1,33,17,2,41,17,0,16,17,1,21,32,37,33,0,512]

theorem envBound24856 : H12AffineFastState.Bounded env24856 := by
  intro p hp
  have h : env24856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24855_24856 : H12AffineEnvironment.transform 5 17 env24855 = env24856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24855 == env24856) = true)

theorem identity24856 : scanCanonicalize (H12AffineFastState.compose env24856 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24856 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24857 : List Nat := [2,4,8,16,32,17,9,36,1,53,0,16,40,1,0,35,17,0,52,1,1,33,17,2,41,17,0,16,17,1,21,32,37,33,0,1]

theorem envBound24857 : H12AffineFastState.Bounded env24857 := by
  intro p hp
  have h : env24857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24856_24857 : H12AffineEnvironment.transform 8 1 env24856 = env24857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24856 == env24857) = true)

theorem identity24857 : scanCanonicalize (H12AffineFastState.compose env24857 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound24857 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24858 : List Nat := [2,4,8,16,30,17,9,26,1,11,0,16,22,1,0,29,17,0,10,1,1,31,17,2,23,17,0,16,17,1,21,30,27,31,0,1]

theorem envBound24858 : H12AffineFastState.Bounded env24858 := by
  intro p hp
  have h : env24858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24857_24858 : H12AffineEnvironment.transform 4 30 env24857 = env24858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env24857 == env24858) = true)

theorem identity24858 : scanCanonicalize (H12AffineFastState.compose env24858 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound24858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24859 : List Nat := [2,4,8,15,1,14,9,5,1,11,0,15,9,1,0,2,14,0,10,1,1,0,14,2,8,14,0,15,14,1,10,1,4,0,0,1]

theorem envBound24859 : H12AffineFastState.Bounded env24859 := by
  intro p hp
  have h : env24859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24858_24859 : H12AffineEnvironment.transform 3 15 env24858 = env24859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env24858 == env24859) = true)

def env24860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,131072,10281,1025,21761,151632,156013,156117,21762,8328,64,149657,160981,25813,23804,148940,8693,257,21793,24964,147984]

theorem envBound24860 : H12AffineFastState.Bounded env24860 := by
  intro p hp
  have h : env24860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24846_24860 : H12AffineEnvironment.transform 17 10281 env24846 = env24860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24846 == env24860) = true)

theorem identity24860 : scanCanonicalize (H12AffineFastState.compose env24860 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound24860 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,13388,10281,1025,21761,25628,21793,21913,21762,8328,64,31957,16537,25813,23804,29056,8693,257,21793,24964,30300]

theorem envBound24861 : H12AffineFastState.Bounded env24861 := by
  intro p hp
  have h : env24861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24860_24861 : H12AffineEnvironment.transform 16 13388 env24860 = env24861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env24860 == env24861) = true)

def env24862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,131072,262144,1025,21760,151633,411972,213470,95496,8328,64,223378,160980,83167,349407,222663,264668,257,95531,82319,147984]

theorem envBound24862 : H12AffineFastState.Bounded env24862 := by
  intro p hp
  have h : env24862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24844_24862 : H12AffineEnvironment.transform 14 21761 env24844 = env24862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env24844 == env24862) = true)

theorem identity24862 : scanCanonicalize (H12AffineFastState.compose env24862 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24862 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77899,338270,8644,95496,8328,64,2184,70862,83167,349407,1501,264668,257,95531,82319,74250]

theorem envBound24863 : H12AffineFastState.Bounded env24863 := by
  intro p hp
  have h : env24863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24862_24863 : H12AffineEnvironment.transform 16 90138 env24862 = env24863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24862 == env24863) = true)

theorem identity24863 : scanCanonicalize (H12AffineFastState.compose env24863 (packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 32241) := by decide +kernel

theorem selectedBound24863 : packedSelected [0,1,9,10,11,12,15,17,19,22,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env24864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90138,32241,1025,21760,77899,87215,8644,95496,8328,64,2184,70862,83167,76078,1501,29741,257,95531,82319,74250]

theorem envBound24864 : H12AffineFastState.Bounded env24864 := by
  intro p hp
  have h : env24864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24863_24864 : H12AffineEnvironment.transform 17 32241 env24863 = env24864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env24863 == env24864) = true)

theorem identity24864 : scanCanonicalize (H12AffineFastState.compose env24864 (packedSelected [0,4,7,17,18,19,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound24864 : packedSelected [0,4,7,17,18,19,22,23,26] rootPS < 2^1333 := by decide +kernel

def env24865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,65536,70727,2476,1025,8541,77899,73970,8644,65877,8328,64,2184,70862,77954,76078,1501,112,257,65910,79314,74250]

theorem envBound24865 : H12AffineFastState.Bounded env24865 := by
  intro p hp
  have h : env24865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24864_24865 : H12AffineEnvironment.transform 13 13405 env24864 = env24865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env24864 == env24865) = true)

theorem identity24865 : scanCanonicalize (H12AffineFastState.compose env24865 (packedSelected [10,11,12,14,15,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound24865 : packedSelected [10,11,12,14,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env24866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,478,5529,2476,1025,8541,12693,8492,8644,139,8328,64,2184,5392,12636,10480,1501,112,257,168,13324,9172]

theorem envBound24866 : H12AffineFastState.Bounded env24866 := by
  intro p hp
  have h : env24866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24865_24866 : H12AffineEnvironment.transform 15 478 env24865 = env24866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env24865 == env24866) = true)

theorem identity24866 : scanCanonicalize (H12AffineFastState.compose env24866 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24866 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24867 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13405,8540,263,5440,2421,1025,8541,12620,8492,8477,82,8273,64,2129,5392,12636,10281,1284,112,257,113,13324,8973]

theorem envBound24867 : H12AffineFastState.Bounded env24867 := by
  intro p hp
  have h : env24867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24866_24867 : H12AffineEnvironment.transform 6 89 env24866 = env24867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24866 == env24867) = true)

theorem identity24867 : scanCanonicalize (H12AffineFastState.compose env24867 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24867 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24868 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,8461,263,5393,2340,1025,8460,12573,8492,8477,3,8192,17,2048,5392,12557,10281,1284,33,257,32,13324,8973]

theorem envBound24868 : H12AffineFastState.Bounded env24868 := by
  intro p hp
  have h : env24868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24867_24868 : H12AffineEnvironment.transform 5 17 env24867 = env24868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24867 == env24868) = true)

theorem identity24868 : scanCanonicalize (H12AffineFastState.compose env24868 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24868 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env24869 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,13324,8233,35,5173,2048,1025,8232,12345,8200,8249,3,8192,17,2048,5172,12329,10281,1056,33,37,32,13324,8745]

theorem envBound24869 : H12AffineFastState.Bounded env24869 := by
  intro p hp
  have h : env24869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24868_24869 : H12AffineEnvironment.transform 7 36 env24868 = env24869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24868 == env24869) = true)

theorem identity24869 : scanCanonicalize (H12AffineFastState.compose env24869 (packedSelected [3,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound24869 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env24870 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,7180,2048,7205,35,5173,2048,1025,7204,3125,7172,7221,3,7180,17,2048,5172,3109,5157,1056,33,37,32,2048,7717]

theorem envBound24870 : H12AffineFastState.Bounded env24870 := by
  intro p hp
  have h : env24870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24869_24870 : H12AffineEnvironment.transform 12 7180 env24869 = env24870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env24869 == env24870) = true)

theorem identity24870 : scanCanonicalize (H12AffineFastState.compose env24870 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound24870 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env24871 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,3108,40,2048,1,35,2065,2048,1025,0,3125,32,17,3,40,17,2048,2064,3109,2049,1056,33,37,32,2048,513]

theorem envBound24871 : H12AffineFastState.Bounded env24871 := by
  intro p hp
  have h : env24871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24870_24871 : H12AffineEnvironment.transform 11 3108 env24870 = env24871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env24870 == env24871) = true)

theorem identity24871 : scanCanonicalize (H12AffineFastState.compose env24871 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24872 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,17,40,1077,1,35,1060,1077,1025,0,0,32,17,3,40,17,1077,1061,16,1076,1056,33,37,32,1077,513]

theorem envBound24872 : H12AffineFastState.Bounded env24872 := by
  intro p hp
  have h : env24872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24871_24872 : H12AffineEnvironment.transform 10 1077 env24871 = env24872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env24871 == env24872) = true)

theorem identity24872 : scanCanonicalize (H12AffineFastState.compose env24872 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24872 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24873 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,40,0,1,35,17,0,52,0,0,32,17,3,40,17,0,16,16,1,21,33,37,32,0,513]

theorem envBound24873 : H12AffineFastState.Bounded env24873 := by
  intro p hp
  have h : env24873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24872_24873 : H12AffineEnvironment.transform 9 53 env24872 = env24873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24872 == env24873) = true)

theorem identity24873 : scanCanonicalize (H12AffineFastState.compose env24873 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24873 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24874 : List Nat := [2,4,8,16,16,17,8,20,512,5,0,17,24,0,1,19,17,0,4,0,0,16,17,3,24,17,0,16,16,1,21,17,21,16,0,513]

theorem envBound24874 : H12AffineFastState.Bounded env24874 := by
  intro p hp
  have h : env24874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24873_24874 : H12AffineEnvironment.transform 4 16 env24873 = env24874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24873 == env24874) = true)

def env24875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411972,213470,16777216,8328,64,16959643,16974301,102879,360926,16958926,17148372,257,16777250,16834951,17031705]

theorem envBound24875 : H12AffineFastState.Bounded env24875 := by
  intro p hp
  have h : env24875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24842_24875 : H12AffineEnvironment.transform 20 165201 env24842 = env24875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env24842 == env24875) = true)

theorem identity24875 : scanCanonicalize (H12AffineFastState.compose env24875 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound24875 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env24876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115870,329867,17,16777216,8328,64,16877908,16793618,102879,360926,16876545,17148372,257,16777250,16834951,16819158]

theorem envBound24876 : H12AffineFastState.Bounded env24876 := by
  intro p hp
  have h : env24876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24875_24876 : H12AffineEnvironment.transform 16 82383 env24875 = env24876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env24875 == env24876) = true)

def env24877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115870,329867,17,95496,8328,64,64604,79130,102879,360926,61705,318684,257,95530,103567,120542]

theorem envBound24877 : H12AffineFastState.Bounded env24877 := by
  intro p hp
  have h : env24877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24876_24877 : H12AffineEnvironment.transform 23 95496 env24876 = env24877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env24876 == env24877) = true)

theorem identity24877 : scanCanonicalize (H12AffineFastState.compose env24877 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound24877 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,38160,262144,1025,32769,4161,318548,17,41431,8328,64,64604,57797,17664,283905,61705,318684,257,41461,16464,513]

theorem envBound24878 : H12AffineFastState.Bounded env24878 := by
  intro p hp
  have h : env24878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24877_24878 : H12AffineEnvironment.transform 15 54495 env24877 = env24878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env24877 == env24878) = true)

def env24879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,262144,1025,32769,4161,318548,17,41311,8192,64,64604,57677,17664,283905,61705,318548,257,41341,16464,513]

theorem envBound24879 : H12AffineFastState.Bounded env24879 := by
  intro p hp
  have h : env24879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24878_24879 : H12AffineEnvironment.transform 6 8 env24878 = env24879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24878 == env24879) = true)

theorem identity24879 : scanCanonicalize (H12AffineFastState.compose env24879 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound24879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,35188,1025,32769,4161,21792,17,41311,8192,64,64604,57677,17664,56437,61705,21792,257,41341,16464,513]

theorem envBound24880 : H12AffineFastState.Bounded env24880 := by
  intro p hp
  have h : env24880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24879_24880 : H12AffineEnvironment.transform 17 35188 env24879 = env24880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env24879 == env24880) = true)

theorem identity24880 : scanCanonicalize (H12AffineFastState.compose env24880 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound24880 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env24881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,28698,12637,11577,1025,9292,4161,21792,17,1298,8192,64,22545,17664,17664,30776,21828,21792,257,1328,16464,513]

theorem envBound24881 : H12AffineFastState.Bounded env24881 := by
  intro p hp
  have h : env24881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24880_24881 : H12AffineEnvironment.transform 14 9293 env24880 = env24881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env24880 == env24881) = true)

theorem identity24881 : scanCanonicalize (H12AffineFastState.compose env24881 (packedSelected [1,8,9,14,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24881 : packedSelected [1,8,9,14,19,22] rootPS < 2^1333 := by decide +kernel

def env24882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1296,20807,4096,3172,1025,1297,4161,21792,17,1298,349,64,22545,17664,17664,22885,21828,21792,257,1328,16464,513]

theorem envBound24882 : H12AffineFastState.Bounded env24882 := by
  intro p hp
  have h : env24882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24881_24882 : H12AffineEnvironment.transform 12 349 env24881 = env24882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24881 == env24882) = true)

def env24883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,4161,318548,17,41310,8193,64,64604,57676,17664,283905,61705,318549,257,41340,16464,513]

theorem envBound24883 : H12AffineFastState.Bounded env24883 := by
  intro p hp
  have h : env24883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24878_24883 : H12AffineEnvironment.transform 6 9 env24878 = env24883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24878 == env24883) = true)

theorem identity24883 : scanCanonicalize (H12AffineFastState.compose env24883 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound24883 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10281,1025,32769,4161,62589,17,41310,8193,64,64604,57676,17664,32040,61705,62588,257,41340,16464,513]

theorem envBound24884 : H12AffineFastState.Bounded env24884 := by
  intro p hp
  have h : env24884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24883_24884 : H12AffineEnvironment.transform 17 10281 env24883 = env24884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24883 == env24884) = true)

theorem identity24884 : scanCanonicalize (H12AffineFastState.compose env24884 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24884 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env24885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,38160,10281,1025,32769,4161,41341,17,41310,8193,64,43356,46156,4096,10280,41993,41340,257,41340,5456,513]

theorem envBound24885 : H12AffineFastState.Bounded env24885 := by
  intro p hp
  have h : env24885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24884_24885 : H12AffineEnvironment.transform 13 5376 env24884 = env24885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24884 == env24885) = true)

theorem identity24885 : scanCanonicalize (H12AffineFastState.compose env24885 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound24885 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,373,35,5221,10281,1025,372,4161,8200,17,8235,8193,64,10281,13625,4096,10280,9596,8201,257,8201,5456,513]

theorem envBound24886 : H12AffineFastState.Bounded env24886 := by
  intro p hp
  have h : env24886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24885_24886 : H12AffineEnvironment.transform 14 373 env24885 = env24886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env24885 == env24886) = true)

theorem identity24886 : scanCanonicalize (H12AffineFastState.compose env24886 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24886 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env24887 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,81,35,5221,10281,1025,80,4161,8200,17,8235,8193,64,10281,13341,4096,10280,9304,8201,37,8201,5236,513]

theorem envBound24887 : H12AffineFastState.Bounded env24887 := by
  intro p hp
  have h : env24887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24886_24887 : H12AffineEnvironment.transform 7 36 env24886 = env24887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24886 == env24887) = true)

theorem identity24887 : scanCanonicalize (H12AffineFastState.compose env24887 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound24887 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env24888 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5156,81,35,5221,2049,1025,80,4161,32,17,3,41,64,2049,5173,4096,2048,1136,33,37,33,5236,513]

theorem envBound24888 : H12AffineFastState.Bounded env24888 := by
  intro p hp
  have h : env24888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24887_24888 : H12AffineEnvironment.transform 12 40 env24887 = env24888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env24887 == env24888) = true)

theorem identity24888 : scanCanonicalize (H12AffineFastState.compose env24888 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound24888 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24889 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,64,40,1124,81,35,1061,2049,1025,80,1,32,17,3,41,64,2049,1141,64,2048,1136,33,37,33,1076,513]

theorem envBound24889 : H12AffineFastState.Bounded env24889 := by
  intro p hp
  have h : env24889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24888_24889 : H12AffineEnvironment.transform 11 64 env24888 = env24889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env24888 == env24889) = true)

theorem identity24889 : scanCanonicalize (H12AffineFastState.compose env24889 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24889 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env24890 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1124,64,40,1124,81,35,1061,1125,1025,80,1,32,17,3,41,64,1125,1141,64,1124,1136,33,37,33,1076,513]

theorem envBound24890 : H12AffineFastState.Bounded env24890 := by
  intro p hp
  have h : env24890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24889_24890 : H12AffineEnvironment.transform 10 1124 env24889 = env24890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env24889 == env24890) = true)

theorem identity24890 : scanCanonicalize (H12AffineFastState.compose env24890 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24890 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env24891 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1077,17,40,1077,0,35,1061,1076,1025,1,1,32,17,3,41,17,1076,1060,17,1077,1057,33,37,33,1076,513]

theorem envBound24891 : H12AffineFastState.Bounded env24891 := by
  intro p hp
  have h : env24891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24890_24891 : H12AffineEnvironment.transform 5 17 env24890 = env24891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24890 == env24891) = true)

theorem identity24891 : scanCanonicalize (H12AffineFastState.compose env24891 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24892 : List Nat := [2,4,8,0,32,1,9,36,512,1024,1061,1,40,1061,0,35,1061,1060,1025,1,1,32,1,3,41,1,1060,1060,1,1061,1057,33,37,33,1060,513]

theorem envBound24892 : H12AffineFastState.Bounded env24892 := by
  intro p hp
  have h : env24892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24891_24892 : H12AffineEnvironment.transform 3 0 env24891 = env24892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24891 == env24892) = true)

theorem identity24892 : scanCanonicalize (H12AffineFastState.compose env24892 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound24892 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24893 : List Nat := [2,4,8,0,32,1,9,36,512,46,11,1,40,11,0,35,11,10,47,1,1,32,1,3,41,1,10,10,1,11,15,33,37,33,10,513]

theorem envBound24893 : H12AffineFastState.Bounded env24893 := by
  intro p hp
  have h : env24893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24892_24893 : H12AffineEnvironment.transform 9 46 env24892 = env24893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env24892 == env24893) = true)

theorem identity24893 : scanCanonicalize (H12AffineFastState.compose env24893 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound24893 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24894 : List Nat := [2,4,8,0,10,1,9,14,512,4,11,1,2,11,0,9,11,10,5,1,1,10,1,3,3,1,10,10,1,11,15,11,15,11,10,513]

theorem envBound24894 : H12AffineFastState.Bounded env24894 := by
  intro p hp
  have h : env24894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24893_24894 : H12AffineEnvironment.transform 4 10 env24893 = env24894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env24893 == env24894) = true)

theorem identity24894 : scanCanonicalize (H12AffineFastState.compose env24894 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound24894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24895 : List Nat := [2,4,8,0,10,1,9,14,14,4,11,1,2,11,0,9,11,10,5,1,1,10,1,3,3,1,10,10,1,11,15,11,15,11,10,15]

theorem envBound24895 : H12AffineFastState.Bounded env24895 := by
  intro p hp
  have h : env24895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24894_24895 : H12AffineEnvironment.transform 8 14 env24894 = env24895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env24894 == env24895) = true)

theorem identity24895 : scanCanonicalize (H12AffineFastState.compose env24895 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound24895 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24896 : List Nat := [2,4,3,0,1,1,2,5,5,4,0,1,2,0,0,2,0,1,5,1,1,1,1,3,3,1,1,1,1,0,4,0,4,0,1,4]

theorem envBound24896 : H12AffineFastState.Bounded env24896 := by
  intro p hp
  have h : env24896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24895_24896 : H12AffineEnvironment.transform 2 3 env24895 = env24896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env24895 == env24896) = true)

theorem identity24896 : scanCanonicalize (H12AffineFastState.compose env24896 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound24896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24897 : List Nat := [1,4,0,0,1,1,1,5,5,4,0,1,1,0,0,1,0,1,5,1,1,1,1,0,0,1,1,1,1,0,4,0,4,0,1,4]

theorem envBound24897 : H12AffineFastState.Bounded env24897 := by
  intro p hp
  have h : env24897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24896_24897 : H12AffineEnvironment.transform 0 1 env24896 = env24897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env24896 == env24897) = true)

def env24898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115870,329867,17,95497,8328,64,64605,79131,102879,360926,61704,318685,257,95531,103566,120543]

theorem envBound24898 : H12AffineFastState.Bounded env24898 := by
  intro p hp
  have h : env24898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24876_24898 : H12AffineEnvironment.transform 23 95497 env24876 = env24898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env24876 == env24898) = true)

def env24899 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,115734,329731,17,95497,8192,64,64605,79131,102743,360790,61704,318549,257,95531,103430,120407]

theorem envBound24899 : H12AffineFastState.Bounded env24899 := by
  intro p hp
  have h : env24899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24898_24899 : H12AffineEnvironment.transform 6 8 env24898 = env24899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24898 == env24899) = true)

theorem identity24899 : scanCanonicalize (H12AffineFastState.compose env24899 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound24899 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24900 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,89378,1025,32769,115734,21793,17,95497,8192,64,64605,79131,102743,56436,61704,98679,257,95531,103430,120407]

theorem envBound24900 : H12AffineFastState.Bounded env24900 := by
  intro p hp
  have h : env24900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24899_24900 : H12AffineEnvironment.transform 17 89378 env24899 = env24900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env24899 == env24900) = true)

theorem identity24900 : scanCanonicalize (H12AffineFastState.compose env24900 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24900 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,89378,1025,32769,115734,21793,17,87124,349,64,56576,70726,102743,56436,53333,98679,257,87158,103430,120407]

theorem envBound24901 : H12AffineFastState.Bounded env24901 := by
  intro p hp
  have h : env24901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24900_24901 : H12AffineEnvironment.transform 12 349 env24900 = env24901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24900 == env24901) = true)

def env24902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115735,329730,17,95497,8193,64,64605,79131,102742,360791,61704,318548,257,95531,103431,120406]

theorem envBound24902 : H12AffineFastState.Bounded env24902 := by
  intro p hp
  have h : env24902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24898_24902 : H12AffineEnvironment.transform 6 9 env24898 = env24902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24898 == env24902) = true)

theorem identity24902 : scanCanonicalize (H12AffineFastState.compose env24902 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound24902 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130174,1025,32769,115735,62588,17,95497,8193,64,64605,79131,102742,32041,61704,73770,257,95531,103431,120406]

theorem envBound24903 : H12AffineFastState.Bounded env24903 := by
  intro p hp
  have h : env24903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24902_24903 : H12AffineEnvironment.transform 17 130174 env24902 = env24903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env24902 == env24903) = true)

theorem identity24903 : scanCanonicalize (H12AffineFastState.compose env24903 (packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24903 : packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env24904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,65536,82246,122227,1025,32769,115735,54641,17,87044,268,64,56656,70678,102742,23588,53253,65831,257,87078,103431,120406]

theorem envBound24904 : H12AffineFastState.Bounded env24904 := by
  intro p hp
  have h : env24904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24903_24904 : H12AffineEnvironment.transform 12 269 env24903 = env24904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24903 == env24904) = true)

theorem identity24904 : scanCanonicalize (H12AffineFastState.compose env24904 (packedSelected [1,2,4,6,8,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24904 : packedSelected [1,2,4,6,8,16,19,22] rootPS < 2^1333 := by decide +kernel

def env24905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,65536,82246,89458,1025,0,82966,21872,17,87044,268,64,23889,70678,69975,23588,20484,65831,257,87078,70662,87639]

theorem envBound24905 : H12AffineFastState.Bounded env24905 := by
  intro p hp
  have h : env24905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24904_24905 : H12AffineEnvironment.transform 14 1 env24904 = env24905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24904 == env24905) = true)

theorem identity24905 : scanCanonicalize (H12AffineFastState.compose env24905 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound24905 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,21510,5440,2420,1025,0,4112,21872,17,2,268,64,23889,16400,17745,23588,20484,21793,257,32,16384,593]

theorem envBound24906 : H12AffineFastState.Bounded env24906 := by
  intro p hp
  have h : env24906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24905_24906 : H12AffineEnvironment.transform 15 21510 env24905 = env24906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env24905 == env24906) = true)

theorem identity24906 : scanCanonicalize (H12AffineFastState.compose env24906 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound24906 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,3344,1,6422,5440,2420,1025,0,4112,6240,17,2,268,64,4161,3328,2113,4404,7444,6193,257,32,3344,593]

theorem envBound24907 : H12AffineFastState.Bounded env24907 := by
  intro p hp
  have h : env24907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24906_24907 : H12AffineEnvironment.transform 13 3344 env24906 = env24907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env24906 == env24907) = true)

theorem identity24907 : scanCanonicalize (H12AffineFastState.compose env24907 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound24907 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,269,3344,1,343,3329,2420,1025,0,2129,33,17,2,268,64,2048,3328,2113,2421,1365,112,257,32,3344,593]

theorem envBound24908 : H12AffineFastState.Bounded env24908 := by
  intro p hp
  have h : env24908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24907_24908 : H12AffineEnvironment.transform 11 2113 env24907 = env24908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env24907 == env24908) = true)

theorem identity24908 : scanCanonicalize (H12AffineFastState.compose env24908 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound24908 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env24909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,113,48,269,1377,1,343,1392,261,1025,0,32,33,17,2,268,64,113,1393,48,260,1365,112,257,32,1377,593]

theorem envBound24909 : H12AffineFastState.Bounded env24909 := by
  intro p hp
  have h : env24909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24908_24909 : H12AffineEnvironment.transform 10 113 env24908 = env24909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env24908 == env24909) = true)

theorem identity24909 : scanCanonicalize (H12AffineFastState.compose env24909 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24909 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env24910 : List Nat := [2,4,8,16,32,64,9,36,512,1024,113,48,41,1093,1,115,1108,33,1025,0,32,33,17,2,40,64,113,1109,48,32,1137,112,37,32,1093,593]

theorem envBound24910 : H12AffineFastState.Bounded env24910 := by
  intro p hp
  have h : env24910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24909_24910 : H12AffineEnvironment.transform 7 36 env24909 = env24910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24909 == env24910) = true)

theorem identity24910 : scanCanonicalize (H12AffineFastState.compose env24910 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 106) := by decide +kernel

theorem selectedBound24910 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env24911 : List Nat := [2,4,8,16,32,64,9,36,512,106,113,48,41,47,1,115,62,33,107,0,32,33,17,2,40,64,113,63,48,32,27,112,37,32,47,593]

theorem envBound24911 : H12AffineFastState.Bounded env24911 := by
  intro p hp
  have h : env24911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24910_24911 : H12AffineEnvironment.transform 9 106 env24910 = env24911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 106 env24910 == env24911) = true)

theorem identity24911 : scanCanonicalize (H12AffineFastState.compose env24911 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 30) := by decide +kernel

theorem selectedBound24911 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env24912 : List Nat := [2,4,8,16,32,30,9,36,512,52,47,48,41,47,1,45,62,33,53,0,32,33,17,2,40,30,47,63,48,32,27,46,37,32,47,527]

theorem envBound24912 : H12AffineFastState.Bounded env24912 := by
  intro p hp
  have h : env24912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24911_24912 : H12AffineEnvironment.transform 5 30 env24911 = env24912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 30 env24911 == env24912) = true)

theorem identity24912 : scanCanonicalize (H12AffineFastState.compose env24912 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24912 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env24913 : List Nat := [2,4,8,16,1,30,9,5,512,21,14,17,8,14,1,12,31,0,20,0,1,0,17,2,9,30,14,30,17,1,27,15,4,1,14,527]

theorem envBound24913 : H12AffineFastState.Bounded env24913 := by
  intro p hp
  have h : env24913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24912_24913 : H12AffineEnvironment.transform 4 1 env24912 = env24913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24912 == env24913) = true)

theorem identity24913 : scanCanonicalize (H12AffineFastState.compose env24913 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound24913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24914 : List Nat := [2,4,1,16,1,23,0,5,512,21,7,17,1,7,1,5,22,0,20,0,1,0,17,2,0,23,7,23,17,1,18,6,4,1,7,518]

theorem envBound24914 : H12AffineFastState.Bounded env24914 := by
  intro p hp
  have h : env24914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24913_24914 : H12AffineEnvironment.transform 2 1 env24913 = env24914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env24913 == env24914) = true)

theorem identity24914 : scanCanonicalize (H12AffineFastState.compose env24914 (packedSelected [2,6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound24914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24915 : List Nat := [2,3,1,16,1,16,0,2,512,18,0,17,1,0,1,2,17,0,19,0,1,0,17,2,0,16,0,16,17,1,18,1,3,1,0,513]

theorem envBound24915 : H12AffineFastState.Bounded env24915 := by
  intro p hp
  have h : env24915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24914_24915 : H12AffineEnvironment.transform 1 3 env24914 = env24915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env24914 == env24915) = true)

theorem identity24915 : scanCanonicalize (H12AffineFastState.compose env24915 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound24915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24916 : List Nat := [2,3,1,16,1,16,0,2,3,18,0,17,1,0,1,2,17,0,19,0,1,0,17,2,0,16,0,16,17,1,18,1,3,1,0,2]

theorem envBound24916 : H12AffineFastState.Bounded env24916 := by
  intro p hp
  have h : env24916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24915_24916 : H12AffineEnvironment.transform 8 3 env24915 = env24916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env24915 == env24916) = true)

def env24917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,411973,213470,16777216,8328,64,16959642,18973836,2299022,360926,16958926,19344516,257,19039603,19031254,17031705]

theorem envBound24917 : H12AffineFastState.Bounded env24917 := by
  intro p hp
  have h : env24917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24841_24917 : H12AffineEnvironment.transform 21 411973 env24841 = env24917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 411973 env24841 == env24917) = true)

def env24918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213470,16777216,8328,64,16959642,16974300,102878,360926,16958926,17148372,257,16777251,16834950,17031705]

theorem envBound24918 : H12AffineFastState.Bounded env24918 := by
  intro p hp
  have h : env24918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24917_24918 : H12AffineEnvironment.transform 20 165200 env24917 = env24918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env24917 == env24918) = true)

theorem identity24918 : scanCanonicalize (H12AffineFastState.compose env24918 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound24918 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env24919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,411973,213470,188870,8328,64,10588,122906,102878,360926,9224,477202,257,188901,131136,66527]

theorem envBound24919 : H12AffineFastState.Bounded env24919 := by
  intro p hp
  have h : env24919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24918_24919 : H12AffineEnvironment.transform 23 188870 env24918 = env24919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env24918 == env24919) = true)

def env24920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,318549,120014,29910,8328,64,10588,122906,102878,360926,9224,384258,257,29941,38224,66527]

theorem envBound24920 : H12AffineFastState.Bounded env24920 := by
  intro p hp
  have h : env24920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24919_24920 : H12AffineEnvironment.transform 16 38160 env24919 = env24920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24919 == env24920) = true)

theorem identity24920 : scanCanonicalize (H12AffineFastState.compose env24920 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound24920 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25028,262144,1025,29909,4160,272513,73754,29910,8328,64,10588,70862,91402,357642,9224,338390,257,29941,24964,66527]

theorem envBound24921 : H12AffineFastState.Bounded env24921 := by
  intro p hp
  have h : env24921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24920_24921 : H12AffineEnvironment.transform 14 29908 env24920 = env24921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env24920 == env24921) = true)

def env24922 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24980,262144,1025,29829,4112,272513,73754,29830,8328,16,10508,70814,91402,357642,9224,338310,257,29861,24964,66447]

theorem envBound24922 : H12AffineFastState.Bounded env24922 := by
  intro p hp
  have h : env24922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24921_24922 : H12AffineEnvironment.transform 5 16 env24921 = env24922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24921 == env24922) = true)

theorem identity24922 : scanCanonicalize (H12AffineFastState.compose env24922 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound24922 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env24923 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,65536,16400,262144,1025,21761,4112,264453,65950,21762,268,16,2184,70814,83086,349326,1420,329730,257,21793,16384,66447]

theorem envBound24923 : H12AffineFastState.Bounded env24923 := by
  intro p hp
  have h : env24923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24922_24923 : H12AffineEnvironment.transform 12 388 env24922 = env24923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env24922 == env24923) = true)

theorem identity24923 : scanCanonicalize (H12AffineFastState.compose env24923 (packedSelected [16,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound24923 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env24924 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,65536,16400,67755,1025,21761,4112,65966,65950,21762,268,16,2184,70814,83086,23589,1420,169,257,21793,16384,66447]

theorem envBound24924 : H12AffineFastState.Bounded env24924 := by
  intro p hp
  have h : env24924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24923_24924 : H12AffineEnvironment.transform 17 67755 env24923 = env24924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env24923 == env24924) = true)

theorem identity24924 : scanCanonicalize (H12AffineFastState.compose env24924 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound24924 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env24925 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2185,7561,65536,2201,67755,1025,7560,4112,65966,65950,7563,268,16,2184,70814,68615,5292,1420,169,257,7592,2185,66447]

theorem envBound24925 : H12AffineFastState.Bounded env24925 := by
  intro p hp
  have h : env24925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24924_24925 : H12AffineEnvironment.transform 13 2185 env24924 = env24925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env24924 == env24925) = true)

theorem identity24925 : scanCanonicalize (H12AffineFastState.compose env24925 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound24925 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env24926 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2185,7561,1331,2201,3480,1025,7560,4112,1181,1197,7563,268,16,2184,4525,2356,5292,1420,169,257,7592,2185,1724]

theorem envBound24926 : H12AffineFastState.Bounded env24926 := by
  intro p hp
  have h : env24926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24925_24926 : H12AffineEnvironment.transform 15 1331 env24925 = env24926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env24925 == env24926) = true)

theorem identity24926 : scanCanonicalize (H12AffineFastState.compose env24926 (packedSelected [1,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound24926 : packedSelected [1,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env24927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1197,388,2185,2340,1331,2201,3480,1025,2341,1213,1181,1197,2342,268,16,2184,1280,2356,1,1420,169,257,2309,2185,1724]

theorem envBound24927 : H12AffineFastState.Bounded env24927 := by
  intro p hp
  have h : env24927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24926_24927 : H12AffineEnvironment.transform 11 1197 env24926 = env24927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env24926 == env24927) = true)

theorem identity24927 : scanCanonicalize (H12AffineFastState.compose env24927 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24927 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1077,1197,388,1212,1297,1331,1196,429,1025,1296,1213,1181,1197,1299,268,16,1213,1280,1281,1,1420,169,257,1328,1212,1724]

theorem envBound24928 : H12AffineFastState.Bounded env24928 := by
  intro p hp
  have h : env24928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24927_24928 : H12AffineEnvironment.transform 10 1077 env24927 = env24928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env24927 == env24928) = true)

theorem identity24928 : scanCanonicalize (H12AffineFastState.compose env24928 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24928 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24929 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1077,1197,160,1212,1077,1047,1196,137,1025,1076,1213,1181,1197,1079,40,16,1213,1060,1061,1,1192,169,37,1044,1212,1724]

theorem envBound24929 : H12AffineFastState.Bounded env24929 := by
  intro p hp
  have h : env24929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24928_24929 : H12AffineEnvironment.transform 7 36 env24928 = env24929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24928 == env24929) = true)

theorem identity24929 : scanCanonicalize (H12AffineFastState.compose env24929 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound24929 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env24930 : List Nat := [2,4,8,16,32,16,128,36,512,188,137,17,160,0,137,171,16,137,189,136,1,33,17,139,40,16,1,152,153,1,20,169,37,168,0,512]

theorem envBound24930 : H12AffineFastState.Bounded env24930 := by
  intro p hp
  have h : env24930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24929_24930 : H12AffineEnvironment.transform 9 188 env24929 = env24930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env24929 == env24930) = true)

theorem identity24930 : scanCanonicalize (H12AffineFastState.compose env24930 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 63) := by decide +kernel

theorem selectedBound24930 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env24931 : List Nat := [2,4,8,16,32,16,128,36,63,188,137,17,160,0,137,171,16,137,189,136,1,33,17,139,40,16,1,152,153,1,20,169,37,168,0,63]

theorem envBound24931 : H12AffineFastState.Bounded env24931 := by
  intro p hp
  have h : env24931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24930_24931 : H12AffineEnvironment.transform 8 63 env24930 = env24931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 63 env24930 == env24931) = true)

theorem identity24931 : scanCanonicalize (H12AffineFastState.compose env24931 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24931 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24932 : List Nat := [2,4,8,16,32,16,8,36,63,52,1,17,40,0,1,35,16,1,53,0,1,33,17,3,40,16,1,16,17,1,20,33,37,32,0,63]

theorem envBound24932 : H12AffineFastState.Bounded env24932 := by
  intro p hp
  have h : env24932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24931_24932 : H12AffineEnvironment.transform 6 8 env24931 = env24932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24931 == env24932) = true)

theorem identity24932 : scanCanonicalize (H12AffineFastState.compose env24932 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24933 : List Nat := [2,4,8,0,32,0,8,36,47,36,1,1,40,0,1,35,0,1,37,0,1,33,1,3,40,0,1,0,1,1,4,33,37,32,0,47]

theorem envBound24933 : H12AffineFastState.Bounded env24933 := by
  intro p hp
  have h : env24933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24932_24933 : H12AffineEnvironment.transform 3 0 env24932 = env24933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24932 == env24933) = true)

theorem identity24933 : scanCanonicalize (H12AffineFastState.compose env24933 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24933 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24934 : List Nat := [2,4,8,0,0,0,8,4,15,4,1,1,8,0,1,3,0,1,5,0,1,1,1,3,8,0,1,0,1,1,4,1,5,0,0,15]

theorem envBound24934 : H12AffineFastState.Bounded env24934 := by
  intro p hp
  have h : env24934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24933_24934 : H12AffineEnvironment.transform 4 0 env24933 = env24934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24933 == env24934) = true)

theorem identity24934 : scanCanonicalize (H12AffineFastState.compose env24934 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound24934 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24935 : List Nat := [2,4,6,0,0,0,6,4,1,4,1,1,6,0,1,3,0,1,5,0,1,1,1,3,6,0,1,0,1,1,4,1,5,0,0,1]

theorem envBound24935 : H12AffineFastState.Bounded env24935 := by
  intro p hp
  have h : env24935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24934_24935 : H12AffineEnvironment.transform 2 6 env24934 = env24935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env24934 == env24935) = true)

def env24936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,24981,262144,1025,29828,4113,272513,73754,29831,8328,17,10509,70815,91402,357642,9224,338311,257,29860,24964,66446]

theorem envBound24936 : H12AffineFastState.Bounded env24936 := by
  intro p hp
  have h : env24936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24921_24936 : H12AffineEnvironment.transform 5 17 env24921 = env24936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24921 == env24936) = true)

theorem identity24936 : scanCanonicalize (H12AffineFastState.compose env24936 (packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24936 : packedSelected [0,3,5,8,9,11,14,16,17,20,22,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env24937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24981,262144,1025,29828,4113,272513,16,29831,8328,17,10509,13461,17664,283904,9224,264589,257,29860,24964,9092]

theorem envBound24937 : H12AffineFastState.Bounded env24937 := by
  intro p hp
  have h : env24937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24936_24937 : H12AffineEnvironment.transform 15 8202 env24936 = env24937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24936 == env24937) = true)

theorem identity24937 : scanCanonicalize (H12AffineFastState.compose env24937 (packedSelected [1,3,6,9,10,14,16,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound24937 : packedSelected [1,3,6,9,10,14,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24938 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8202,24981,23809,1025,29828,4113,30080,16,29831,8328,17,10509,13461,17664,2049,9224,21644,257,29860,24964,9092]

theorem envBound24938 : H12AffineFastState.Bounded env24938 := by
  intro p hp
  have h : env24938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24937_24938 : H12AffineEnvironment.transform 17 23809 env24937 = env24938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env24937 == env24938) = true)

theorem identity24938 : scanCanonicalize (H12AffineFastState.compose env24938 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24938 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env24939 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,16384,21676,35,16828,23809,1025,21677,4113,21929,16,21678,161,17,2340,5308,17664,2049,1057,21644,257,21645,16813,941]

theorem envBound24939 : H12AffineFastState.Bounded env24939 := by
  intro p hp
  have h : env24939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24938_24939 : H12AffineEnvironment.transform 12 41 env24938 = env24939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24938 == env24939) = true)

theorem identity24939 : scanCanonicalize (H12AffineFastState.compose env24939 (packedSelected [0,2,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound24939 : packedSelected [0,2,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env24940 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5156,136,35,5528,2341,1025,137,4113,397,16,138,161,17,2340,5308,4388,2049,1057,168,257,169,5513,941]

theorem envBound24940 : H12AffineFastState.Bounded env24940 := by
  intro p hp
  have h : env24940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24939_24940 : H12AffineEnvironment.transform 13 5156 env24939 = env24940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env24939 == env24940) = true)

theorem identity24940 : scanCanonicalize (H12AffineFastState.compose env24940 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound24940 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24941 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,136,35,5173,2184,1025,137,4113,32,16,138,161,17,2185,5308,4233,2049,1057,168,172,169,5156,512]

theorem envBound24941 : H12AffineFastState.Bounded env24941 := by
  intro p hp
  have h : env24941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24940_24941 : H12AffineEnvironment.transform 7 173 env24940 = env24941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env24940 == env24941) = true)

theorem identity24941 : scanCanonicalize (H12AffineFastState.compose env24941 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24942 : List Nat := [2,4,8,16,0,17,128,141,512,1024,2048,4096,9,5124,136,3,5141,2184,1025,137,4113,0,16,138,129,17,2185,5276,4233,2049,1025,136,140,137,5124,512]

theorem envBound24942 : H12AffineFastState.Bounded env24942 := by
  intro p hp
  have h : env24942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24941_24942 : H12AffineEnvironment.transform 4 0 env24941 = env24942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24941 == env24942) = true)

theorem identity24942 : scanCanonicalize (H12AffineFastState.compose env24942 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24942 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env24943 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5124,0,3,5141,2048,1025,1,4113,0,16,2,9,17,2049,5140,4097,2049,1025,0,4,1,5124,512]

theorem envBound24943 : H12AffineFastState.Bounded env24943 := by
  intro p hp
  have h : env24943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24942_24943 : H12AffineEnvironment.transform 6 8 env24942 = env24943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24942 == env24943) = true)

def env24944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,318548,120015,29911,8328,64,10588,122906,102878,360926,9224,384259,257,29940,38225,66527]

theorem envBound24944 : H12AffineFastState.Bounded env24944 := by
  intro p hp
  have h : env24944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24919_24944 : H12AffineEnvironment.transform 16 38161 env24919 = env24944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24919 == env24944) = true)

theorem identity24944 : scanCanonicalize (H12AffineFastState.compose env24944 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound24944 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4161,318548,8644,29911,8328,64,10588,5393,25813,292053,9224,272392,257,29940,38225,63188]

theorem envBound24945 : H12AffineFastState.Bounded env24945 := by
  intro p hp
  have h : env24945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24944_24945 : H12AffineEnvironment.transform 15 62731 env24944 = env24945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env24944 == env24945) = true)

def env24946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4161,318548,8524,29791,8192,64,10588,5393,25693,291933,9224,272392,257,29820,38225,63068]

theorem envBound24946 : H12AffineFastState.Bounded env24946 := by
  intro p hp
  have h : env24946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24945_24946 : H12AffineEnvironment.transform 6 8 env24945 = env24946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24945 == env24946) = true)

theorem identity24946 : scanCanonicalize (H12AffineFastState.compose env24946 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24946 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,24908,262144,1025,29788,4161,272393,8524,29791,8192,64,10588,5393,25693,291933,9224,272392,257,29820,24844,513]

theorem envBound24947 : H12AffineFastState.Bounded env24947 := by
  intro p hp
  have h : env24947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24946_24947 : H12AffineEnvironment.transform 14 29789 env24946 = env24947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24946 == env24947) = true)

theorem identity24947 : scanCanonicalize (H12AffineFastState.compose env24947 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 30776) := by decide +kernel

theorem selectedBound24947 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,24908,30776,1025,29788,4161,20529,8524,29791,8192,64,10588,5393,25693,3173,9224,20528,257,29820,24844,513]

theorem envBound24948 : H12AffineFastState.Bounded env24948 := by
  intro p hp
  have h : env24948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24947_24948 : H12AffineEnvironment.transform 17 30776 env24947 = env24948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30776 env24947 == env24948) = true)

theorem identity24948 : scanCanonicalize (H12AffineFastState.compose env24948 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound24948 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,20497,342,17664,23668,1025,20496,4161,20529,1280,20499,1100,64,3344,5393,16401,3173,68,20528,257,20528,17728,513]

theorem envBound24949 : H12AffineFastState.Bounded env24949 := by
  intro p hp
  have h : env24949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24948_24949 : H12AffineEnvironment.transform 12 1100 env24948 = env24949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env24948 == env24949) = true)

theorem identity24949 : scanCanonicalize (H12AffineFastState.compose env24949 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound24949 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env24950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4113,0,342,5393,3173,1025,1,4161,32,1280,2,1100,64,3344,5393,4096,3173,68,33,257,33,5457,513]

theorem envBound24950 : H12AffineFastState.Bounded env24950 := by
  intro p hp
  have h : env24950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24949_24950 : H12AffineEnvironment.transform 13 4113 env24949 = env24950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env24949 == env24950) = true)

theorem identity24950 : scanCanonicalize (H12AffineFastState.compose env24950 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound24950 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1280,1100,1297,0,342,17,3173,1025,1,1345,32,1280,2,1100,64,3344,17,1280,3173,68,33,257,33,81,513]

theorem envBound24951 : H12AffineFastState.Bounded env24951 := by
  intro p hp
  have h : env24951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24950_24951 : H12AffineEnvironment.transform 11 1280 env24950 = env24951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env24950 == env24951) = true)

theorem identity24951 : scanCanonicalize (H12AffineFastState.compose env24951 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24951 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24952 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,1140,1100,1125,0,34,17,3173,1025,1,1077,32,1140,2,1100,64,3172,17,1140,3173,68,33,117,33,81,513]

theorem envBound24952 : H12AffineFastState.Bounded env24952 := by
  intro p hp
  have h : env24952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24951_24952 : H12AffineEnvironment.transform 7 116 env24951 = env24952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24951 == env24952) = true)

theorem identity24952 : scanCanonicalize (H12AffineFastState.compose env24952 (packedSelected [1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound24952 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env24953 : List Nat := [2,4,8,16,32,64,8,116,97,1024,2048,1140,1100,1125,0,34,17,3173,1025,1,1077,32,1140,2,1100,64,3172,17,1140,3173,68,33,117,33,81,96]

theorem envBound24953 : H12AffineFastState.Bounded env24953 := by
  intro p hp
  have h : env24953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24952_24953 : H12AffineEnvironment.transform 8 97 env24952 = env24953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env24952 == env24953) = true)

theorem identity24953 : scanCanonicalize (H12AffineFastState.compose env24953 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound24953 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24954 : List Nat := [2,4,8,16,32,64,8,116,97,1024,65,1140,1100,1125,0,34,17,1060,1025,1,1077,32,1140,2,1100,64,1061,17,1140,1060,68,33,117,33,81,96]

theorem envBound24954 : H12AffineFastState.Bounded env24954 := by
  intro p hp
  have h : env24954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24953_24954 : H12AffineEnvironment.transform 10 65 env24953 = env24954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env24953 == env24954) = true)

theorem identity24954 : scanCanonicalize (H12AffineFastState.compose env24954 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24954 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env24955 : List Nat := [2,4,8,16,32,64,8,116,97,52,65,64,120,81,0,34,17,16,53,1,1,32,64,2,120,64,17,17,64,16,68,33,117,33,81,96]

theorem envBound24955 : H12AffineFastState.Bounded env24955 := by
  intro p hp
  have h : env24955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24954_24955 : H12AffineEnvironment.transform 9 52 env24954 = env24955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24954 == env24955) = true)

theorem identity24955 : scanCanonicalize (H12AffineFastState.compose env24955 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24955 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24956 : List Nat := [2,4,8,16,32,16,8,36,49,52,17,16,40,1,0,34,17,16,53,1,1,32,16,2,40,16,17,17,16,16,20,33,37,33,1,48]

theorem envBound24956 : H12AffineFastState.Bounded env24956 := by
  intro p hp
  have h : env24956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24955_24956 : H12AffineEnvironment.transform 5 16 env24955 = env24956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24955 == env24956) = true)

def env24957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4161,318548,8525,29790,8193,64,10588,5393,25692,291932,9224,272392,257,29821,38225,63069]

theorem envBound24957 : H12AffineFastState.Bounded env24957 := by
  intro p hp
  have h : env24957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24945_24957 : H12AffineEnvironment.transform 6 9 env24945 = env24957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24945 == env24957) = true)

theorem identity24957 : scanCanonicalize (H12AffineFastState.compose env24957 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24957 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env24958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,54358,38161,262144,1025,32769,4161,318548,16,21763,348,64,2049,5393,17665,283905,1365,264533,257,21792,38225,55040]

theorem envBound24958 : H12AffineFastState.Bounded env24958 := by
  intro p hp
  have h : env24958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24957_24958 : H12AffineEnvironment.transform 12 349 env24957 = env24958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24957 == env24958) = true)

theorem identity24958 : scanCanonicalize (H12AffineFastState.compose env24958 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound24958 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16400,262144,1025,21760,4161,264533,16,21763,348,64,2049,5393,17665,283905,1365,264533,257,21792,16464,513]

theorem envBound24959 : H12AffineFastState.Bounded env24959 := by
  intro p hp
  have h : env24959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24958_24959 : H12AffineEnvironment.transform 14 21761 env24958 = env24959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env24958 == env24959) = true)

theorem identity24959 : scanCanonicalize (H12AffineFastState.compose env24959 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound24959 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,343,16400,2420,1025,21760,4161,33,16,21763,348,64,2049,5393,17665,23669,1365,33,257,21792,16464,513]

theorem envBound24960 : H12AffineFastState.Bounded env24960 := by
  intro p hp
  have h : env24960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24959_24960 : H12AffineEnvironment.transform 17 2420 env24959 = env24960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env24959 == env24960) = true)

theorem identity24960 : scanCanonicalize (H12AffineFastState.compose env24960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,343,5392,2420,1025,0,4161,33,16,3,348,64,2049,5393,4097,2421,1365,33,257,32,5456,513]

theorem envBound24961 : H12AffineFastState.Bounded env24961 := by
  intro p hp
  have h : env24961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24960_24961 : H12AffineEnvironment.transform 13 5376 env24960 = env24961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24960 == env24961) = true)

theorem identity24961 : scanCanonicalize (H12AffineFastState.compose env24961 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound24961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24962 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4405,1,343,4389,2420,52,0,4161,33,16,3,348,64,2049,4388,4097,2421,352,33,257,32,4453,513]

theorem envBound24962 : H12AffineFastState.Bounded env24962 := by
  intro p hp
  have h : env24962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24961_24962 : H12AffineEnvironment.transform 9 53 env24961 = env24962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24961 == env24962) = true)

theorem identity24962 : scanCanonicalize (H12AffineFastState.compose env24962 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24962 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24963 : List Nat := [2,4,8,16,32,64,9,117,512,53,2048,4096,40,4160,1,34,4176,2049,52,0,4161,33,16,3,41,64,2049,4177,4097,2048,21,33,116,32,4112,513]

theorem envBound24963 : H12AffineFastState.Bounded env24963 := by
  intro p hp
  have h : env24963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24962_24963 : H12AffineEnvironment.transform 7 117 env24962 = env24963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24962 == env24963) = true)

def env24964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213470,16777216,8328,64,16959642,16974301,102879,360926,16958926,17148373,257,16777250,16834951,17031705]

theorem envBound24964 : H12AffineFastState.Bounded env24964 := by
  intro p hp
  have h : env24964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24917_24964 : H12AffineEnvironment.transform 20 165201 env24917 = env24964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165201 env24917 == env24964) = true)

def env24965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318549,120014,16777216,8328,64,16801162,16880845,102879,360926,16797918,17148373,257,16777250,16834951,16873225]

theorem envBound24965 : H12AffineFastState.Bounded env24965 := by
  intro p hp
  have h : env24965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24964_24965 : H12AffineEnvironment.transform 16 38160 env24964 = env24965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24964 == env24965) = true)

def env24966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318549,120014,338048,8328,64,357642,310349,102879,360926,358494,33109,257,338082,379143,286601]

theorem envBound24966 : H12AffineFastState.Bounded env24966 := by
  intro p hp
  have h : env24966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24965_24966 : H12AffineEnvironment.transform 23 338048 env24965 = env24966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338048 env24965 == env24966) = true)

theorem identity24966 : scanCanonicalize (H12AffineFastState.compose env24966 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound24966 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env24967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21620,65536,16740,262144,1025,21621,4161,264225,65722,338048,8328,64,357642,288825,83371,349610,358494,21793,257,338082,335219,286601]

theorem envBound24967 : H12AffineFastState.Bounded env24967 := by
  intro p hp
  have h : env24967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24966_24967 : H12AffineEnvironment.transform 14 21620 env24966 = env24967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env24966 == env24967) = true)

theorem identity24967 : scanCanonicalize (H12AffineFastState.compose env24967 (packedSelected [0,2,4,6,7,9,16,17,20,23,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound24967 : packedSelected [0,2,4,6,7,9,16,17,20,23,32,35] rootPS < 2^1333 := by decide +kernel

def env24968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21620,30082,16740,262144,1025,21621,4161,264225,30008,285954,8328,64,262280,288825,12329,270376,265692,21793,257,285984,289009,286601]

theorem envBound24968 : H12AffineFastState.Bounded env24968 := by
  intro p hp
  have h : env24968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24967_24968 : H12AffineEnvironment.transform 15 30082 env24967 = env24968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env24967 == env24968) = true)

def env24969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21620,30082,16740,23808,1025,21621,4161,21793,30008,2,8328,64,23944,13625,12329,32040,20700,21793,257,32,13809,649]

theorem envBound24969 : H12AffineFastState.Bounded env24969 := by
  intro p hp
  have h : env24969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24968_24969 : H12AffineEnvironment.transform 17 23808 env24968 = env24969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env24968 == env24969) = true)

theorem identity24969 : scanCanonicalize (H12AffineFastState.compose env24969 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24969 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21620,29962,16740,23808,1025,21621,4161,21793,30008,2,8192,64,23808,13625,12329,32040,20564,21793,257,32,13689,513]

theorem envBound24970 : H12AffineFastState.Bounded env24970 := by
  intro p hp
  have h : env24970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24969_24970 : H12AffineEnvironment.transform 6 8 env24969 = env24970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24969 == env24970) = true)

theorem identity24970 : scanCanonicalize (H12AffineFastState.compose env24970 (packedSelected [0,3,4,5,7,9,10,12,14,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound24970 : packedSelected [0,3,4,5,7,9,10,12,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env24971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12392,9244,1378,12556,11624,1025,9245,4161,9545,1360,2,8192,64,11624,13625,12329,3392,8252,9545,257,32,13689,513]

theorem envBound24971 : H12AffineFastState.Bounded env24971 := by
  intro p hp
  have h : env24971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24970_24971 : H12AffineEnvironment.transform 13 12392 env24970 = env24971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env24970 == env24971) = true)

theorem identity24971 : scanCanonicalize (H12AffineFastState.compose env24971 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24971 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env24972 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,12392,8461,115,12556,10361,272,8460,4161,8280,65,2,8192,64,10361,12328,12329,2129,8252,8280,257,32,12392,513]

theorem envBound24972 : H12AffineFastState.Bounded env24972 := by
  intro p hp
  have h : env24972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24971_24972 : H12AffineEnvironment.transform 9 273 env24971 = env24972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24971 == env24972) = true)

theorem identity24972 : scanCanonicalize (H12AffineFastState.compose env24972 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24972 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env24973 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4404,81,115,4176,2341,272,80,4161,260,65,2,348,64,2341,4468,4469,2129,352,260,257,32,4404,513]

theorem envBound24973 : H12AffineFastState.Bounded env24973 := by
  intro p hp
  have h : env24973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24972_24973 : H12AffineEnvironment.transform 12 348 env24972 = env24973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24972 == env24973) = true)

theorem identity24973 : scanCanonicalize (H12AffineFastState.compose env24973 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24973 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24974 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,268,4404,1,35,4096,2341,272,0,4113,260,17,2,268,16,2341,4388,4389,2049,304,260,257,32,4404,513]

theorem envBound24974 : H12AffineFastState.Bounded env24974 := by
  intro p hp
  have h : env24974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24973_24974 : H12AffineEnvironment.transform 5 16 env24973 = env24974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24973 == env24974) = true)

theorem identity24974 : scanCanonicalize (H12AffineFastState.compose env24974 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 256) := by decide +kernel

theorem selectedBound24974 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24975 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,256,268,52,1,35,256,2341,272,0,273,260,17,2,268,16,2341,36,37,2049,304,260,257,32,52,513]

theorem envBound24975 : H12AffineFastState.Bounded env24975 := by
  intro p hp
  have h : env24975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24974_24975 : H12AffineEnvironment.transform 11 256 env24974 = env24975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 256 env24974 == env24975) = true)

theorem identity24975 : scanCanonicalize (H12AffineFastState.compose env24975 (packedSelected [1,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 313) := by decide +kernel

theorem selectedBound24975 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env24976 : List Nat := [2,4,8,16,32,16,8,256,512,273,313,256,268,52,1,35,256,28,272,0,273,260,17,2,268,16,28,36,37,312,304,260,257,32,52,513]

theorem envBound24976 : H12AffineFastState.Bounded env24976 := by
  intro p hp
  have h : env24976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24975_24976 : H12AffineEnvironment.transform 10 313 env24975 = env24976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 313 env24975 == env24976) = true)

def env24977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21620,30082,16740,23809,1025,21621,4161,21792,30008,3,8328,64,23945,13624,12329,32041,20701,21793,257,33,13808,648]

theorem envBound24977 : H12AffineFastState.Bounded env24977 := by
  intro p hp
  have h : env24977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24968_24977 : H12AffineEnvironment.transform 17 23809 env24968 = env24977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env24968 == env24977) = true)

theorem identity24977 : scanCanonicalize (H12AffineFastState.compose env24977 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13729) := by decide +kernel

theorem selectedBound24977 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13729,8661,35,13509,10400,1025,8660,4161,8321,153,3,8328,64,10280,13624,12329,2184,9596,8320,257,33,13808,648]

theorem envBound24978 : H12AffineFastState.Bounded env24978 := by
  intro p hp
  have h : env24978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24977_24978 : H12AffineEnvironment.transform 13 13729 env24977 = env24978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13729 env24977 == env24978) = true)

theorem identity24978 : scanCanonicalize (H12AffineFastState.compose env24978 (packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24978 : packedSelected [3,4,5,9,10,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24979 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,13444,8432,35,13509,10400,1025,8433,4161,8321,153,3,8328,64,10280,13341,12329,2184,9305,8320,36,33,13525,648]

theorem envBound24979 : H12AffineFastState.Bounded env24979 := by
  intro p hp
  have h : env24979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24978_24979 : H12AffineEnvironment.transform 7 37 env24978 = env24979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24978 == env24979) = true)

theorem identity24979 : scanCanonicalize (H12AffineFastState.compose env24979 (packedSelected [1,6,8,12,14,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound24979 : packedSelected [1,6,8,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env24980 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,241,5237,1,35,5172,2129,1025,0,4161,112,153,3,121,64,2265,5356,4312,2184,1192,113,36,33,5156,648]

theorem envBound24980 : H12AffineFastState.Bounded env24980 := by
  intro p hp
  have h : env24980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24979_24980 : H12AffineEnvironment.transform 12 241 env24979 = env24980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env24979 == env24980) = true)

def env24981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,318549,120014,338049,8328,64,357643,310348,102879,360926,358495,33108,257,338083,379142,286600]

theorem envBound24981 : H12AffineFastState.Bounded env24981 := by
  intro p hp
  have h : env24981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24965_24981 : H12AffineEnvironment.transform 23 338049 env24965 = env24981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338049 env24965 == env24981) = true)

theorem identity24981 : scanCanonicalize (H12AffineFastState.compose env24981 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(14+1) ^^^ 21756) := by decide +kernel

theorem selectedBound24981 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env24982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21756,65536,16876,262144,1025,21757,4161,264361,65586,338049,8328,64,357643,288944,83235,349474,358495,21928,257,338083,335354,286600]

theorem envBound24982 : H12AffineFastState.Bounded env24982 := by
  intro p hp
  have h : env24982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24981_24982 : H12AffineEnvironment.transform 14 21756 env24981 = env24982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21756 env24981 == env24982) = true)

def env24983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21756,65536,16876,10400,1025,21757,4161,8201,65586,65569,8328,64,89515,16400,83235,97666,86271,21928,257,65539,79194,30504]

theorem envBound24983 : H12AffineFastState.Bounded env24983 := by
  intro p hp
  have h : env24983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24982_24983 : H12AffineEnvironment.transform 17 10400 env24982 = env24983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env24982 == env24983) = true)

theorem identity24983 : scanCanonicalize (H12AffineFastState.compose env24983 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound24983 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,8540,65536,13388,10400,1025,8541,4161,8201,65586,65569,8328,64,75787,13744,77955,67618,75103,8200,257,65539,79194,648]

theorem envBound24984 : H12AffineFastState.Bounded env24984 := by
  intro p hp
  have h : env24984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24983_24984 : H12AffineEnvironment.transform 13 13728 env24983 = env24984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env24983 == env24984) = true)

theorem identity24984 : scanCanonicalize (H12AffineFastState.compose env24984 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound24984 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8540,65536,13388,10281,1025,8541,4161,8201,65586,65569,8193,64,75787,13625,77834,67618,75103,8200,257,65539,79194,513]

theorem envBound24985 : H12AffineFastState.Bounded env24985 := by
  intro p hp
  have h : env24985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24984_24985 : H12AffineEnvironment.transform 6 9 env24984 = env24985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24984 == env24985) = true)

theorem identity24985 : scanCanonicalize (H12AffineFastState.compose env24985 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound24985 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8540,8575,13388,10281,1025,8541,4161,8201,8525,8542,8193,64,2420,13625,4469,10589,1056,8200,257,8572,5157,513]

theorem envBound24986 : H12AffineFastState.Bounded env24986 := by
  intro p hp
  have h : env24986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24985_24986 : H12AffineEnvironment.transform 15 8575 env24985 = env24986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env24985 == env24986) = true)

theorem identity24986 : scanCanonicalize (H12AffineFastState.compose env24986 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24986 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,0,35,5392,2421,1025,1,4161,341,17,2,349,64,2420,5221,4469,2049,1056,340,257,32,5157,513]

theorem envBound24987 : H12AffineFastState.Bounded env24987 := by
  intro p hp
  have h : env24987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24986_24987 : H12AffineEnvironment.transform 12 348 env24986 = env24987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24986 == env24987) = true)

theorem identity24987 : scanCanonicalize (H12AffineFastState.compose env24987 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24987 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24988 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,348,5205,0,3,5392,2389,1025,1,4161,341,17,2,349,64,2388,5189,4437,2049,1024,340,257,0,5125,513]

theorem envBound24988 : H12AffineFastState.Bounded env24988 := by
  intro p hp
  have h : env24988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24987_24988 : H12AffineEnvironment.transform 4 0 env24987 = env24988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24987 == env24988) = true)

def env24989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21756,65536,16876,10401,1025,21757,4161,8200,65586,65568,8328,64,89514,16401,83235,97667,86270,21928,257,65538,79195,30505]

theorem envBound24989 : H12AffineFastState.Bounded env24989 := by
  intro p hp
  have h : env24989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24982_24989 : H12AffineEnvironment.transform 17 10401 env24982 = env24989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env24982 == env24989) = true)

theorem identity24989 : scanCanonicalize (H12AffineFastState.compose env24989 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound24989 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env24990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,0,65536,5392,10401,1025,1,4161,8200,65586,65568,8328,64,67926,5357,70111,76159,66562,340,257,65538,79195,9173]

theorem envBound24990 : H12AffineFastState.Bounded env24990 := by
  intro p hp
  have h : env24990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24989_24990 : H12AffineEnvironment.transform 13 5372 env24989 = env24990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env24989 == env24990) = true)

theorem identity24990 : scanCanonicalize (H12AffineFastState.compose env24990 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound24990 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env24991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,0,34,5392,10401,1025,1,4161,8200,16,2,8328,64,2420,5357,4605,10589,1056,340,257,32,13689,9173]

theorem envBound24991 : H12AffineFastState.Bounded env24991 := by
  intro p hp
  have h : env24991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24990_24991 : H12AffineEnvironment.transform 15 34 env24990 = env24991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env24990 == env24991) = true)

theorem identity24991 : scanCanonicalize (H12AffineFastState.compose env24991 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound24991 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env24992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5372,0,34,5392,2048,1025,1,4161,169,16,2,41,64,2420,5357,4605,2556,1056,340,257,32,5592,884]

theorem envBound24992 : H12AffineFastState.Bounded env24992 := by
  intro p hp
  have h : env24992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24991_24992 : H12AffineEnvironment.transform 12 161 env24991 = env24992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env24991 == env24992) = true)

theorem identity24992 : scanCanonicalize (H12AffineFastState.compose env24992 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24992 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24993 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5372,0,34,5221,2048,1025,1,4161,169,16,2,41,64,2049,5357,4232,2185,1056,33,116,32,5293,513]

theorem envBound24993 : H12AffineFastState.Bounded env24993 := by
  intro p hp
  have h : env24993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24992_24993 : H12AffineEnvironment.transform 7 117 env24992 = env24993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24992 == env24993) = true)

theorem identity24993 : scanCanonicalize (H12AffineFastState.compose env24993 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24993 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24994 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,121,5156,0,34,5221,2048,1025,1,4161,113,16,2,41,64,2049,5173,4176,2129,1056,33,116,32,5237,513]

theorem envBound24994 : H12AffineFastState.Bounded env24994 := by
  intro p hp
  have h : env24994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24993_24994 : H12AffineEnvironment.transform 6 88 env24993 = env24994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24993 == env24994) = true)

def env24995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318548,120015,16777216,8328,64,16801163,16880844,102879,360926,16797919,17148373,257,16777250,16834951,16873224]

theorem envBound24995 : H12AffineFastState.Bounded env24995 := by
  intro p hp
  have h : env24995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24964_24995 : H12AffineEnvironment.transform 16 38161 env24964 = env24995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env24964 == env24995) = true)

theorem identity24995 : scanCanonicalize (H12AffineFastState.compose env24995 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound24995 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318548,120015,95497,8328,64,75906,57797,102879,360926,75222,318684,257,95531,103566,513]

theorem envBound24996 : H12AffineFastState.Bounded env24996 := by
  intro p hp
  have h : env24996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24995_24996 : H12AffineEnvironment.transform 23 95497 env24995 = env24996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env24995 == env24996) = true)

def env24997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318548,119879,95497,8192,64,75786,57677,102743,360790,75102,318548,257,95531,103430,513]

theorem envBound24997 : H12AffineFastState.Bounded env24997 := by
  intro p hp
  have h : env24997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24996_24997 : H12AffineEnvironment.transform 6 8 env24996 = env24997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24996 == env24997) = true)

theorem identity24997 : scanCanonicalize (H12AffineFastState.compose env24997 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound24997 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4160,318548,8524,32770,8192,64,56577,57677,25692,291933,53333,318548,257,32800,24845,513]

theorem envBound24998 : H12AffineFastState.Bounded env24998 := by
  intro p hp
  have h : env24998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24997_24998 : H12AffineEnvironment.transform 15 62731 env24997 = env24998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env24997 == env24998) = true)

theorem identity24998 : scanCanonicalize (H12AffineFastState.compose env24998 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound24998 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env24999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,22884,1025,32769,4160,34096,8524,32770,8192,64,56577,57677,25692,11577,53333,34096,257,32800,24845,513]

theorem envBound24999 : H12AffineFastState.Bounded env24999 := by
  intro p hp
  have h : env24999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24998_24999 : H12AffineEnvironment.transform 17 22884 env24998 = env24999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env24998 == env24999) = true)

theorem identity24999 : scanCanonicalize (H12AffineFastState.compose env24999 (packedSelected [0,4,8,9,10,17,20,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24999 : packedSelected [0,4,8,9,10,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env25000 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,22837,1025,32769,4113,34096,8477,32770,8192,17,56577,57628,25613,11577,53252,34096,257,32800,24845,513]

theorem envBound25000 : H12AffineFastState.Bounded env25000 := by
  intro p hp
  have h : env25000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24999_25000 : H12AffineEnvironment.transform 5 17 env24999 = env25000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24999 == env25000) = true)

theorem identity25000 : scanCanonicalize (H12AffineFastState.compose env25000 (packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound25000 : packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env25001 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,16384,32768,53299,38161,22837,1025,32769,4113,34096,1061,32770,1336,17,56577,50212,16693,2049,53252,34096,257,32800,17461,513]

theorem envBound25001 : H12AffineFastState.Bounded env25001 := by
  intro p hp
  have h : env25001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25000_25001 : H12AffineEnvironment.transform 12 1336 env25000 = env25001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env25000 == env25001) = true)

theorem identity25001 : scanCanonicalize (H12AffineFastState.compose env25001 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 20789) := by decide +kernel

theorem selectedBound25001 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env25002 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,16384,20789,262,17444,22837,1025,20788,4113,21509,1061,20791,1336,17,3124,5393,16693,2049,305,21509,257,20757,17461,513]

theorem envBound25002 : H12AffineFastState.Bounded env25002 := by
  intro p hp
  have h : env25002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25001_25002 : H12AffineEnvironment.transform 14 20789 env25001 = env25002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20789 env25001 == env25002) = true)

theorem identity25002 : scanCanonicalize (H12AffineFastState.compose env25002 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound25002 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25003 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,268,16384,20789,262,16400,22837,53,20788,4113,20529,17,20791,268,17,2048,4389,16693,2049,305,20529,257,20757,16385,513]

theorem envBound25003 : H12AffineFastState.Bounded env25003 := by
  intro p hp
  have h : env25003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25002_25003 : H12AffineEnvironment.transform 9 52 env25002 = env25003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env25002 == env25003) = true)

theorem identity25003 : scanCanonicalize (H12AffineFastState.compose env25003 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound25003 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env25004 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,4096,268,16384,20789,262,16400,20757,53,20788,4113,20529,17,20791,268,17,32,4389,16693,33,305,20529,257,20757,16385,513]

theorem envBound25004 : H12AffineFastState.Bounded env25004 := by
  intro p hp
  have h : env25004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25003_25004 : H12AffineEnvironment.transform 10 32 env25003 = env25004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env25003 == env25004) = true)

theorem identity25004 : scanCanonicalize (H12AffineFastState.compose env25004 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound25004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25005 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,4096,268,4112,293,262,4096,261,53,292,4113,33,17,295,268,17,32,4389,4389,33,305,33,257,261,4113,513]

theorem envBound25005 : H12AffineFastState.Bounded env25005 := by
  intro p hp
  have h : env25005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25004_25005 : H12AffineEnvironment.transform 13 4112 env25004 = env25005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env25004 == env25005) = true)

theorem identity25005 : scanCanonicalize (H12AffineFastState.compose env25005 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound25005 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25006 : List Nat := [2,4,8,16,32,17,8,256,512,52,32,33,268,49,293,262,33,261,53,292,48,33,17,295,268,17,32,260,260,33,305,33,257,261,48,513]

theorem envBound25006 : H12AffineFastState.Bounded env25006 := by
  intro p hp
  have h : env25006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25005_25006 : H12AffineEnvironment.transform 11 33 env25005 = env25006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env25005 == env25006) = true)

theorem identity25006 : scanCanonicalize (H12AffineFastState.compose env25006 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound25006 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env25007 : List Nat := [2,4,8,16,32,17,8,256,261,52,32,33,268,49,293,262,33,261,53,292,48,33,17,295,268,17,32,260,260,33,305,33,257,261,48,260]

theorem envBound25007 : H12AffineFastState.Bounded env25007 := by
  intro p hp
  have h : env25007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25006_25007 : H12AffineEnvironment.transform 8 261 env25006 = env25007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env25006 == env25007) = true)

theorem identity25007 : scanCanonicalize (H12AffineFastState.compose env25007 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25008 : List Nat := [2,4,8,16,32,17,8,20,17,52,32,33,24,49,49,18,33,17,53,48,48,33,17,51,24,17,32,16,16,33,37,33,21,17,48,16]

theorem envBound25008 : H12AffineFastState.Bounded env25008 := by
  intro p hp
  have h : env25008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25007_25008 : H12AffineEnvironment.transform 7 20 env25007 = env25008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25007 == env25008) = true)

theorem identity25008 : scanCanonicalize (H12AffineFastState.compose env25008 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25008 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25009 : List Nat := [2,4,8,16,0,17,8,20,17,20,0,1,24,17,17,18,1,17,21,16,16,1,17,19,24,17,0,16,16,1,5,1,21,17,16,16]

theorem envBound25009 : H12AffineFastState.Bounded env25009 := by
  intro p hp
  have h : env25009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25008_25009 : H12AffineEnvironment.transform 4 0 env25008 = env25009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25008 == env25009) = true)

theorem identity25009 : scanCanonicalize (H12AffineFastState.compose env25009 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25009 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25010 : List Nat := [2,4,8,0,0,1,8,4,1,4,0,1,8,1,1,2,1,1,5,0,0,1,1,3,8,1,0,0,0,1,5,1,5,1,0,0]

theorem envBound25010 : H12AffineFastState.Bounded env25010 := by
  intro p hp
  have h : env25010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25009_25010 : H12AffineEnvironment.transform 3 0 env25009 = env25010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25009 == env25010) = true)

def env25011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,318548,119878,95497,8193,64,75787,57676,102742,360791,75103,318549,257,95531,103431,513]

theorem envBound25011 : H12AffineFastState.Bounded env25011 := by
  intro p hp
  have h : env25011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24996_25011 : H12AffineEnvironment.transform 6 9 env24996 = env25011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24996 == env25011) = true)

theorem identity25011 : scanCanonicalize (H12AffineFastState.compose env25011 (packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound25011 : packedSelected [0,3,4,5,7,8,9,11,14,16,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env25012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,35188,1025,32769,4160,21792,119878,95497,8193,64,75787,57676,102742,67619,75103,21793,257,95531,103431,513]

theorem envBound25012 : H12AffineFastState.Bounded env25012 := by
  intro p hp
  have h : env25012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25011_25012 : H12AffineEnvironment.transform 17 35188 env25011 = env25012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env25011 == env25012) = true)

theorem identity25012 : scanCanonicalize (H12AffineFastState.compose env25012 (packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound25012 : packedSelected [1,4,7,8,9,12,15,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env25013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,38161,35188,1025,32769,4160,21792,41245,82,8193,64,23888,57676,58381,32120,20484,21793,257,112,57692,513]

theorem envBound25013 : H12AffineFastState.Bounded env25013 := by
  intro p hp
  have h : env25013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25012_25013 : H12AffineEnvironment.transform 15 30043 env25012 = env25013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env25012 == env25013) = true)

theorem identity25013 : scanCanonicalize (H12AffineFastState.compose env25013 (packedSelected [2,3,5,6,10,12,15,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound25013 : packedSelected [2,3,5,6,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env25014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,8202,38161,35188,1025,32769,4160,113,41245,82,8193,64,2049,46109,45404,10281,1365,112,257,112,46093,513]

theorem envBound25014 : H12AffineFastState.Bounded env25014 := by
  intro p hp
  have h : env25014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25013_25014 : H12AffineEnvironment.transform 13 5457 env25013 = env25014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env25013 == env25014) = true)

theorem identity25014 : scanCanonicalize (H12AffineFastState.compose env25014 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25014 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,1,8202,5392,2421,1025,0,4160,113,8476,82,8193,64,2049,13340,12637,10281,1365,112,257,112,13324,513]

theorem envBound25015 : H12AffineFastState.Bounded env25015 := by
  intro p hp
  have h : env25015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25014_25015 : H12AffineEnvironment.transform 14 1 env25014 = env25015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25014 == env25015) = true)

theorem identity25015 : scanCanonicalize (H12AffineFastState.compose env25015 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25015 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env25016 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,1,8202,5392,2340,1025,0,4113,32,8476,3,8193,17,2049,13340,12556,10281,1284,33,257,33,13324,513]

theorem envBound25016 : H12AffineFastState.Bounded env25016 := by
  intro p hp
  have h : env25016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25015_25016 : H12AffineEnvironment.transform 5 17 env25015 = env25016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25015 == env25016) = true)

theorem identity25016 : scanCanonicalize (H12AffineFastState.compose env25016 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound25016 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env25017 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,5132,5376,1,5126,5392,2340,1025,0,4113,32,5392,3,5133,17,2049,16,1280,7205,1284,33,257,33,0,513]

theorem envBound25017 : H12AffineFastState.Bounded env25017 := by
  intro p hp
  have h : env25017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25016_25017 : H12AffineEnvironment.transform 12 5132 env25016 = env25017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env25016 == env25017) = true)

theorem identity25017 : scanCanonicalize (H12AffineFastState.compose env25017 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound25017 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env25018 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,4096,5132,5376,1,5126,5392,0,1025,0,4113,32,5392,3,5133,17,293,16,1280,5377,1284,33,257,33,0,513]

theorem envBound25018 : H12AffineFastState.Bounded env25018 := by
  intro p hp
  have h : env25018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25017_25018 : H12AffineEnvironment.transform 10 292 env25017 = env25018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env25017 == env25018) = true)

theorem identity25018 : scanCanonicalize (H12AffineFastState.compose env25018 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25018 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env25019 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,4096,4153,4405,1,4147,4389,0,52,0,4113,32,4389,3,4152,17,293,16,309,4404,305,33,257,33,0,513]

theorem envBound25019 : H12AffineFastState.Bounded env25019 := by
  intro p hp
  have h : env25019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25018_25019 : H12AffineEnvironment.transform 9 53 env25018 = env25019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25018 == env25019) = true)

theorem identity25019 : scanCanonicalize (H12AffineFastState.compose env25019 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound25019 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env25020 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,309,268,0,1,262,16,0,52,0,292,32,16,3,269,17,293,16,309,1,305,33,257,33,0,513]

theorem envBound25020 : H12AffineFastState.Bounded env25020 := by
  intro p hp
  have h : env25020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25019_25020 : H12AffineEnvironment.transform 11 309 env25019 = env25020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env25019 == env25020) = true)

theorem identity25020 : scanCanonicalize (H12AffineFastState.compose env25020 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25020 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25021 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,16,41,0,1,35,16,0,52,0,1,32,16,3,40,17,0,16,16,1,20,33,36,33,0,513]

theorem envBound25021 : H12AffineFastState.Bounded env25021 := by
  intro p hp
  have h : env25021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25020_25021 : H12AffineEnvironment.transform 7 37 env25020 = env25021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25020 == env25021) = true)

theorem identity25021 : scanCanonicalize (H12AffineFastState.compose env25021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25022 : List Nat := [2,4,8,16,32,17,9,37,0,53,1,16,41,0,1,35,16,0,52,0,1,32,16,3,40,17,0,16,16,1,20,33,36,33,0,1]

theorem envBound25022 : H12AffineFastState.Bounded env25022 := by
  intro p hp
  have h : env25022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25021_25022 : H12AffineEnvironment.transform 8 0 env25021 = env25022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25021 == env25022) = true)

theorem identity25022 : scanCanonicalize (H12AffineFastState.compose env25022 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound25022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25023 : List Nat := [2,4,8,16,26,17,9,31,0,15,1,16,19,0,1,25,16,0,14,0,1,26,16,3,18,17,0,16,16,1,20,27,30,27,0,1]

theorem envBound25023 : H12AffineFastState.Bounded env25023 := by
  intro p hp
  have h : env25023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25022_25023 : H12AffineEnvironment.transform 4 26 env25022 = env25023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env25022 == env25023) = true)

def env25024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound25024 : H12AffineFastState.Bounded env25024 := by
  intro p hp
  have h : env25024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24725_25024 : H12AffineEnvironment.transform 26 30393345 env24725 = env25024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env24725 == env25024) = true)

def env25025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound25025 : H12AffineFastState.Bounded env25025 := by
  intro p hp
  have h : env25025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25024_25025 : H12AffineEnvironment.transform 18 1024 env25024 = env25025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25024 == env25025) = true)

theorem identity25025 : scanCanonicalize (H12AffineFastState.compose env25025 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound25025 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,16777216,8328,64,29868033,16793618,8491471,8830976,25265168,21012831,256,25165874,25223575,25207750]

theorem envBound25026 : H12AffineFastState.Bounded env25026 := by
  intro p hp
  have h : env25026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25025_25026 : H12AffineEnvironment.transform 20 115871 env25025 = env25026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env25025 == env25026) = true)

def env25027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,4194304,8388608,95496,8328,64,13022473,79130,8491471,8830976,8450328,4314199,256,8484154,8492191,8509134]

theorem envBound25027 : H12AffineFastState.Bounded env25027 := by
  intro p hp
  have h : env25027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25026_25027 : H12AffineEnvironment.transform 23 95496 env25026 = env25027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env25026 == env25027) = true)

def env25028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,8388608,95496,8328,64,8560009,79130,8491471,8830976,8450328,392407,256,8484154,8492191,8509134]

theorem envBound25028 : H12AffineFastState.Bounded env25028 := by
  intro p hp
  have h : env25028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25027_25028 : H12AffineEnvironment.transform 21 272512 env25027 = env25028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env25027 == env25028) = true)

theorem identity25028 : scanCanonicalize (H12AffineFastState.compose env25028 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound25028 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115871,272512,120015,95496,8328,64,215366,79130,17664,464079,75223,392407,256,41461,16464,513]

theorem envBound25029 : H12AffineFastState.Bounded env25029 := by
  intro p hp
  have h : env25029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25028_25029 : H12AffineEnvironment.transform 22 120015 env25028 = env25029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env25028 == env25029) = true)

def env25030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,272392,119879,95496,8192,64,215366,79130,17664,463943,75103,392287,256,41341,16464,513]

theorem envBound25030 : H12AffineFastState.Bounded env25030 := by
  intro p hp
  have h : env25030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25029_25030 : H12AffineEnvironment.transform 6 8 env25029 = env25030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25029 == env25030) = true)

theorem identity25030 : scanCanonicalize (H12AffineFastState.compose env25030 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound25030 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,115735,272392,119879,95496,8192,64,10588,79130,17664,291933,75103,392287,256,41341,16464,513]

theorem envBound25031 : H12AffineFastState.Bounded env25031 := by
  intro p hp
  have h : env25031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25030_25031 : H12AffineEnvironment.transform 16 90138 env25030 = env25031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env25030 == env25031) = true)

def env25032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,115735,32,119879,95496,8192,64,10588,79130,17664,23669,75103,119927,256,41341,16464,513]

theorem envBound25032 : H12AffineFastState.Bounded env25032 := by
  intro p hp
  have h : env25032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25031_25032 : H12AffineEnvironment.transform 17 10280 env25031 = env25032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25031 == env25032) = true)

theorem identity25032 : scanCanonicalize (H12AffineFastState.compose env25032 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25032 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,91466,32,95514,95496,8192,64,10588,79130,17664,23669,75103,95530,256,32,16464,513]

theorem envBound25033 : H12AffineFastState.Bounded env25033 := by
  intro p hp
  have h : env25033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25032_25033 : H12AffineEnvironment.transform 14 8541 env25032 = env25033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25032 == env25033) = true)

theorem identity25033 : scanCanonicalize (H12AffineFastState.compose env25033 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 1378) := by decide +kernel

theorem selectedBound25033 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env25034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,1378,25976,10280,1024,8540,24616,32,28792,28778,8192,64,10588,12408,17664,23669,8253,28744,256,32,16464,513]

theorem envBound25034 : H12AffineFastState.Bounded env25034 := by
  intro p hp
  have h : env25034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25033_25034 : H12AffineEnvironment.transform 15 1378 env25033 = env25034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1378 env25033 == env25034) = true)

theorem identity25034 : scanCanonicalize (H12AffineFastState.compose env25034 (packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound25034 : packedSelected [0,1,4,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env25035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7180,16384,7505,1378,22900,5156,1024,7504,23588,32,19572,19558,7180,64,5456,3188,17664,23669,7217,19524,256,32,16464,513]

theorem envBound25035 : H12AffineFastState.Bounded env25035 := by
  intro p hp
  have h : env25035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25034_25035 : H12AffineEnvironment.transform 12 7180 env25034 = env25035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env25034 == env25035) = true)

theorem identity25035 : scanCanonicalize (H12AffineFastState.compose env25035 (packedSelected [0,1,7,8,10,12,14,23] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25035 : packedSelected [0,1,7,8,10,12,14,23] rootPS < 2^1333 := by decide +kernel

def env25036 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,6201,16384,6500,343,22900,4113,53,6501,22545,32,18497,18515,6201,64,4453,2113,16693,22592,6148,18545,256,32,16464,513]

theorem envBound25036 : H12AffineFastState.Bounded env25036 := by
  intro p hp
  have h : env25036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25035_25036 : H12AffineEnvironment.transform 9 53 env25035 = env25036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25035 == env25036) = true)

theorem identity25036 : scanCanonicalize (H12AffineFastState.compose env25036 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25036 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25037 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,6201,16384,6453,262,22821,4113,53,6452,22545,32,18448,18434,6201,17,4404,2064,16693,22545,6148,18464,256,32,16385,513]

theorem envBound25037 : H12AffineFastState.Bounded env25037 := by
  intro p hp
  have h : env25037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25036_25037 : H12AffineEnvironment.transform 5 17 env25036 = env25037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25036 == env25037) = true)

theorem identity25037 : scanCanonicalize (H12AffineFastState.compose env25037 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound25037 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25038 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,4096,6201,2048,6453,262,4389,4113,53,6452,4113,32,16,2,6201,17,4404,2064,2357,4113,6148,32,256,32,2049,513]

theorem envBound25038 : H12AffineFastState.Bounded env25038 := by
  intro p hp
  have h : env25038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25037_25038 : H12AffineEnvironment.transform 13 2048 env25037 = env25038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env25037 == env25038) = true)

theorem identity25038 : scanCanonicalize (H12AffineFastState.compose env25038 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2561) := by decide +kernel

theorem selectedBound25038 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25039 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2561,568,2048,820,262,2852,2576,53,821,2576,32,16,2,568,17,2869,2064,2357,2576,517,32,256,32,2049,513]

theorem envBound25039 : H12AffineFastState.Bounded env25039 := by
  intro p hp
  have h : env25039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25038_25039 : H12AffineEnvironment.transform 11 2561 env25038 = env25039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2561 env25038 == env25039) = true)

theorem identity25039 : scanCanonicalize (H12AffineFastState.compose env25039 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound25039 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env25040 : List Nat := [2,4,8,16,32,17,8,256,512,53,308,821,568,308,820,262,528,804,53,821,804,32,16,2,568,17,513,292,1,804,517,32,256,32,309,513]

theorem envBound25040 : H12AffineFastState.Bounded env25040 := by
  intro p hp
  have h : env25040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25039_25040 : H12AffineEnvironment.transform 10 308 env25039 = env25040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env25039 == env25040) = true)

theorem identity25040 : scanCanonicalize (H12AffineFastState.compose env25040 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25040 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env25041 : List Nat := [2,4,8,16,32,17,8,37,512,53,17,528,568,17,529,35,528,513,53,528,513,32,16,2,568,17,513,1,1,513,517,32,37,32,16,513]

theorem envBound25041 : H12AffineFastState.Bounded env25041 := by
  intro p hp
  have h : env25041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25040_25041 : H12AffineEnvironment.transform 7 37 env25040 = env25041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25040 == env25041) = true)

theorem identity25041 : scanCanonicalize (H12AffineFastState.compose env25041 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound25041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25042 : List Nat := [2,4,8,16,32,17,8,37,48,53,17,32,8,17,33,35,32,49,53,32,49,32,16,2,8,17,49,1,1,49,53,32,37,32,16,49]

theorem envBound25042 : H12AffineFastState.Bounded env25042 := by
  intro p hp
  have h : env25042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25041_25042 : H12AffineEnvironment.transform 8 48 env25041 = env25042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env25041 == env25042) = true)

theorem identity25042 : scanCanonicalize (H12AffineFastState.compose env25042 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25042 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25043 : List Nat := [2,4,8,1,32,0,8,37,33,36,0,32,8,0,33,35,32,32,36,32,32,32,1,2,8,0,32,1,1,32,36,32,37,32,1,32]

theorem envBound25043 : H12AffineFastState.Bounded env25043 := by
  intro p hp
  have h : env25043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25042_25043 : H12AffineEnvironment.transform 3 1 env25042 = env25043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25042 == env25043) = true)

theorem identity25043 : scanCanonicalize (H12AffineFastState.compose env25043 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25044 : List Nat := [2,4,8,1,0,0,8,5,1,4,0,0,8,0,1,3,0,0,4,0,0,0,1,2,8,0,0,1,1,0,4,0,5,0,1,0]

theorem envBound25044 : H12AffineFastState.Bounded env25044 := by
  intro p hp
  have h : env25044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25043_25044 : H12AffineEnvironment.transform 4 0 env25043 = env25044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25043 == env25044) = true)

def env25045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,115735,33,119879,95496,8192,64,10588,79130,17664,23668,75103,119926,256,41341,16464,513]

theorem envBound25045 : H12AffineFastState.Bounded env25045 := by
  intro p hp
  have h : env25045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25031_25045 : H12AffineEnvironment.transform 17 10281 env25031 = env25045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25031 == env25045) = true)

theorem identity25045 : scanCanonicalize (H12AffineFastState.compose env25045 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound25045 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29962,5392,10281,1024,32769,45341,33,41293,2,8192,64,10588,16400,17664,23668,20565,41340,256,41341,16464,513]

theorem envBound25046 : H12AffineFastState.Bounded env25046 := by
  intro p hp
  have h : env25046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25045_25046 : H12AffineEnvironment.transform 15 29962 env25045 = env25046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env25045 == env25046) = true)

theorem identity25046 : scanCanonicalize (H12AffineFastState.compose env25046 (packedSelected [0,2,3,5,6,7,10,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 17681) := by decide +kernel

theorem selectedBound25046 : packedSelected [0,2,3,5,6,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env25047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,17681,29962,5392,10281,1024,17680,29708,33,25692,2,8192,64,10588,16400,17664,23668,20565,25709,256,25708,16464,513]

theorem envBound25047 : H12AffineFastState.Bounded env25047 := by
  intro p hp
  have h : env25047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25046_25047 : H12AffineEnvironment.transform 14 17681 env25046 = env25047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17681 env25046 == env25047) = true)

theorem identity25047 : scanCanonicalize (H12AffineFastState.compose env25047 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25047 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env25048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,16384,17681,27930,3328,10281,1024,17680,27676,33,25692,2,8192,64,10588,16400,17664,17508,18501,25709,256,25708,16464,513]

theorem envBound25048 : H12AffineFastState.Bounded env25048 := by
  intro p hp
  have h : env25048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25047_25048 : H12AffineEnvironment.transform 11 2064 env25047 = env25048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25047 == env25048) = true)

theorem identity25048 : scanCanonicalize (H12AffineFastState.compose env25048 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 8540) := by decide +kernel

theorem selectedBound25048 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,8192,8540,9293,3142,3328,10281,1024,9292,3392,33,1280,2,8192,64,10588,8524,9308,9528,10521,1329,256,1328,8460,513]

theorem envBound25049 : H12AffineFastState.Bounded env25049 := by
  intro p hp
  have h : env25049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25048_25049 : H12AffineEnvironment.transform 13 8540 env25048 = env25049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8540 env25048 == env25049) = true)

theorem identity25049 : scanCanonicalize (H12AffineFastState.compose env25049 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound25049 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env25050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,1053,1345,80,3142,3328,3124,1024,81,3392,33,1280,2,1053,64,3393,1361,65,293,3332,1329,256,1328,1297,513]

theorem envBound25050 : H12AffineFastState.Bounded env25050 := by
  intro p hp
  have h : env25050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25049_25050 : H12AffineEnvironment.transform 12 1053 env25049 = env25050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env25049 == env25050) = true)

theorem identity25050 : scanCanonicalize (H12AffineFastState.compose env25050 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound25050 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25051 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2064,40,372,80,2163,2357,2049,53,81,2421,33,309,2,40,64,2420,356,65,293,2353,260,256,261,292,513]

theorem envBound25051 : H12AffineFastState.Bounded env25051 := by
  intro p hp
  have h : env25051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25050_25051 : H12AffineEnvironment.transform 9 53 env25050 = env25051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env25050 == env25051) = true)

theorem identity25051 : scanCanonicalize (H12AffineFastState.compose env25051 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound25051 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env25052 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,308,40,372,80,343,17,293,53,81,81,33,309,2,40,64,80,356,65,293,21,260,256,261,292,513]

theorem envBound25052 : H12AffineFastState.Bounded env25052 := by
  intro p hp
  have h : env25052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25051_25052 : H12AffineEnvironment.transform 10 292 env25051 = env25052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env25051 == env25052) = true)

theorem identity25052 : scanCanonicalize (H12AffineFastState.compose env25052 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound25052 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25053 : List Nat := [2,4,8,16,32,64,8,256,260,53,292,308,40,372,80,343,17,293,53,81,81,33,309,2,40,64,80,356,65,293,21,260,256,261,292,261]

theorem envBound25053 : H12AffineFastState.Bounded env25053 := by
  intro p hp
  have h : env25053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25052_25053 : H12AffineEnvironment.transform 8 260 env25052 = env25053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env25052 == env25053) = true)

theorem identity25053 : scanCanonicalize (H12AffineFastState.compose env25053 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25053 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25054 : List Nat := [2,4,8,16,32,16,8,256,260,53,292,308,40,292,0,263,17,293,53,1,1,33,309,2,40,16,0,308,17,293,21,260,256,261,292,261]

theorem envBound25054 : H12AffineFastState.Bounded env25054 := by
  intro p hp
  have h : env25054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25053_25054 : H12AffineEnvironment.transform 5 16 env25053 = env25054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25053 == env25054) = true)

def env25055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115734,272393,119878,95496,8193,64,215366,79130,17664,463942,75102,392286,256,41340,16464,513]

theorem envBound25055 : H12AffineFastState.Bounded env25055 := by
  intro p hp
  have h : env25055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25029_25055 : H12AffineEnvironment.transform 6 9 env25029 = env25055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25029 == env25055) = true)

def env25056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,115734,33,119878,95496,8193,64,215366,79130,17664,212078,75102,119926,256,41340,16464,513]

theorem envBound25056 : H12AffineFastState.Bounded env25056 := by
  intro p hp
  have h : env25056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25055_25056 : H12AffineEnvironment.transform 17 10280 env25055 = env25056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25055 == env25056) = true)

theorem identity25056 : scanCanonicalize (H12AffineFastState.compose env25056 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound25056 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25057 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1024,32769,4160,33,16,41310,8193,64,171280,57676,17664,190520,61704,32,256,41340,16464,513]

theorem envBound25057 : H12AffineFastState.Bounded env25057 := by
  intro p hp
  have h : env25057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25056_25057 : H12AffineEnvironment.transform 15 54358 env25056 = env25057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env25056 == env25057) = true)

theorem identity25057 : scanCanonicalize (H12AffineFastState.compose env25057 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound25057 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25058 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46156,10280,1024,32769,4160,33,16,41310,8193,64,10588,57676,17664,23668,61704,32,256,41340,16464,513]

theorem envBound25058 : H12AffineFastState.Bounded env25058 := by
  intro p hp
  have h : env25058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25057_25058 : H12AffineEnvironment.transform 16 46156 env25057 = env25058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env25057 == env25058) = true)

theorem identity25058 : scanCanonicalize (H12AffineFastState.compose env25058 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound25058 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28698,4096,10280,1024,9293,4160,33,16,1298,8193,64,10588,17664,17664,23668,21828,32,256,1328,16464,513]

theorem envBound25059 : H12AffineFastState.Bounded env25059 := by
  intro p hp
  have h : env25059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25058_25059 : H12AffineEnvironment.transform 14 9292 env25058 = env25059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env25058 == env25059) = true)

theorem identity25059 : scanCanonicalize (H12AffineFastState.compose env25059 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound25059 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env25060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,7425,9292,11547,4096,10280,1024,9293,4160,33,16,1298,8193,64,10588,6145,6145,373,2117,32,256,1328,7505,513]

theorem envBound25060 : H12AffineFastState.Bounded env25060 := by
  intro p hp
  have h : env25060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25059_25060 : H12AffineEnvironment.transform 13 7425 env25059 = env25060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env25059 == env25060) = true)

theorem identity25060 : scanCanonicalize (H12AffineFastState.compose env25060 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound25060 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env25061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2089,7425,3173,1330,4096,1,1024,3172,4160,33,16,1298,2088,64,373,6145,6145,373,2117,32,256,1328,7505,513]

theorem envBound25061 : H12AffineFastState.Bounded env25061 := by
  intro p hp
  have h : env25061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25060_25061 : H12AffineEnvironment.transform 12 2089 env25060 = env25061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env25060 == env25061) = true)

theorem identity25061 : scanCanonicalize (H12AffineFastState.compose env25061 (packedSelected [0,11,14,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound25061 : packedSelected [0,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env25062 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,2089,7284,3173,1095,4096,1,1024,3172,4160,33,16,1127,2088,64,0,6145,6145,0,2117,32,117,1093,7204,513]

theorem envBound25062 : H12AffineFastState.Bounded env25062 := by
  intro p hp
  have h : env25062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25061_25062 : H12AffineEnvironment.transform 7 117 env25061 = env25062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env25061 == env25062) = true)

theorem identity25062 : scanCanonicalize (H12AffineFastState.compose env25062 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound25062 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env25063 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1061,4096,1036,4177,64,1095,4096,1,1024,65,4160,33,16,1127,1037,64,0,5156,5156,0,1120,32,117,1093,4097,513]

theorem envBound25063 : H12AffineFastState.Bounded env25063 := by
  intro p hp
  have h : env25063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25062_25063 : H12AffineEnvironment.transform 10 1061 env25062 = env25063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env25062 == env25063) = true)

theorem identity25063 : scanCanonicalize (H12AffineFastState.compose env25063 (packedSelected [1,2,3,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound25063 : packedSelected [1,2,3,4,6,11] rootPS < 2^1333 := by decide +kernel

def env25064 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1061,1557,1036,1604,64,1095,1557,1,1024,65,1621,33,16,1127,1037,64,0,561,561,0,1120,32,117,1093,1556,513]

theorem envBound25064 : H12AffineFastState.Bounded env25064 := by
  intro p hp
  have h : env25064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25063_25064 : H12AffineEnvironment.transform 11 1557 env25063 = env25064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env25063 == env25064) = true)

theorem identity25064 : scanCanonicalize (H12AffineFastState.compose env25064 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound25064 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env25065 : List Nat := [2,4,8,16,32,64,9,117,512,85,112,576,89,529,64,18,576,1,85,65,512,33,16,50,88,64,0,561,561,0,53,32,117,16,577,513]

theorem envBound25065 : H12AffineFastState.Bounded env25065 := by
  intro p hp
  have h : env25065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25064_25065 : H12AffineEnvironment.transform 9 85 env25064 = env25065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env25064 == env25065) = true)

theorem identity25065 : scanCanonicalize (H12AffineFastState.compose env25065 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25065 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env25066 : List Nat := [2,4,8,16,1,64,9,84,512,85,81,576,89,529,64,18,576,1,85,65,512,0,16,19,88,64,0,528,528,0,20,1,84,16,577,513]

theorem envBound25066 : H12AffineFastState.Bounded env25066 := by
  intro p hp
  have h : env25066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25065_25066 : H12AffineEnvironment.transform 4 1 env25065 = env25066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25065 == env25066) = true)

theorem identity25066 : scanCanonicalize (H12AffineFastState.compose env25066 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound25066 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25067 : List Nat := [2,4,8,16,1,64,9,84,65,85,81,1,89,80,64,18,1,1,85,65,65,0,16,19,88,64,0,81,81,0,20,1,84,16,0,64]

theorem envBound25067 : H12AffineFastState.Bounded env25067 := by
  intro p hp
  have h : env25067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25066_25067 : H12AffineEnvironment.transform 8 65 env25066 = env25067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env25066 == env25067) = true)

theorem identity25067 : scanCanonicalize (H12AffineFastState.compose env25067 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25068 : List Nat := [2,4,8,1,1,64,9,69,65,68,64,1,72,65,64,3,1,1,68,65,65,0,1,2,73,64,0,64,64,0,5,1,69,1,0,64]

theorem envBound25068 : H12AffineFastState.Bounded env25068 := by
  intro p hp
  have h : env25068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25067_25068 : H12AffineEnvironment.transform 3 1 env25067 = env25068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25067 == env25068) = true)

theorem identity25068 : scanCanonicalize (H12AffineFastState.compose env25068 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25069 : List Nat := [2,4,8,1,1,1,9,4,0,5,1,1,9,0,1,3,1,1,5,0,0,0,1,2,8,1,0,1,1,0,5,1,4,1,0,1]

theorem envBound25069 : H12AffineFastState.Bounded env25069 := by
  intro p hp
  have h : env25069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25068_25069 : H12AffineEnvironment.transform 5 1 env25068 = env25069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25068 == env25069) = true)

def env25070 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,115734,32,119878,95496,8193,64,215366,79130,17664,212079,75102,119927,256,41340,16464,513]

theorem envBound25070 : H12AffineFastState.Bounded env25070 := by
  intro p hp
  have h : env25070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25055_25070 : H12AffineEnvironment.transform 17 10281 env25055 = env25070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25055 == env25070) = true)

theorem identity25070 : scanCanonicalize (H12AffineFastState.compose env25070 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound25070 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env25071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57628,10281,1024,32769,115734,32,119878,95496,8193,64,108634,79130,17664,122227,75102,119927,256,41340,16464,513]

theorem envBound25071 : H12AffineFastState.Bounded env25071 := by
  intro p hp
  have h : env25071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25070_25071 : H12AffineEnvironment.transform 16 57628 env25070 = env25071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env25070 == env25071) = true)

theorem identity25071 : scanCanonicalize (H12AffineFastState.compose env25071 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound25071 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env25072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41051,57628,10281,1024,32769,25677,32,29725,54611,8193,64,2049,38209,17664,32040,34053,29740,256,41340,16464,513]

theorem envBound25072 : H12AffineFastState.Bounded env25072 := by
  intro p hp
  have h : env25072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25071_25072 : H12AffineEnvironment.transform 15 41051 env25071 = env25072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env25071 == env25072) = true)

theorem identity25072 : scanCanonicalize (H12AffineFastState.compose env25072 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25072 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env25073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,342,16401,10281,1024,8460,25677,32,29725,29790,8193,64,2049,13388,17664,32040,9224,29740,256,113,16464,513]

theorem envBound25073 : H12AffineFastState.Bounded env25073 := by
  intro p hp
  have h : env25073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25072_25073 : H12AffineEnvironment.transform 14 8461 env25072 = env25073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env25072 == env25073) = true)

theorem identity25073 : scanCanonicalize (H12AffineFastState.compose env25073 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25073 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25074 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,80,342,16401,2420,1024,81,17680,32,21824,21763,348,64,2049,5393,17664,23669,1365,21873,256,113,16464,513]

theorem envBound25074 : H12AffineFastState.Bounded env25074 := by
  intro p hp
  have h : env25074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25073_25074 : H12AffineEnvironment.transform 12 349 env25073 = env25074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25073 == env25074) = true)

theorem identity25074 : scanCanonicalize (H12AffineFastState.compose env25074 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25074 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25075 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,342,5441,2420,1024,81,4160,32,16,83,348,64,2049,5393,4176,2341,1365,33,256,113,5376,513]

theorem envBound25075 : H12AffineFastState.Bounded env25075 := by
  intro p hp
  have h : env25075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25074_25075 : H12AffineEnvironment.transform 13 5456 env25074 = env25075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25074 == env25075) = true)

end H12CloudChart1