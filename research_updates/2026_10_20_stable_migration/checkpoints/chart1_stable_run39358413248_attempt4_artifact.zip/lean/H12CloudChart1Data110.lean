import H12CloudChart1Data109

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound27872 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77898,272512,73755,98781,8328,64,43357,79131,17664,262145,75222,392407,257,21792,46213,513]

theorem envBound27873 : H12AffineFastState.Bounded env27873 := by
  intro p hp
  have h : env27873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27872_27873 : H12AffineEnvironment.transform 20 77898 env27872 = env27873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env27872 == env27873) = true)

theorem identity27873 : scanCanonicalize (H12AffineFastState.compose env27873 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound27873 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env27874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77898,73891,73755,98781,8328,64,43357,79131,17664,67618,75222,62708,257,21792,46213,513]

theorem envBound27874 : H12AffineFastState.Bounded env27874 := by
  intro p hp
  have h : env27874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27873_27874 : H12AffineEnvironment.transform 17 67619 env27873 = env27874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env27873 == env27874) = true)

theorem identity27874 : scanCanonicalize (H12AffineFastState.compose env27874 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27874 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env27875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73891,73755,66012,8328,64,10588,79131,17664,67618,75222,29941,257,21792,13444,513]

theorem envBound27875 : H12AffineFastState.Bounded env27875 := by
  intro p hp
  have h : env27875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27874_27875 : H12AffineEnvironment.transform 14 1 env27874 = env27875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27874 == env27875) = true)

def env27876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73771,73755,65876,8192,64,10588,79131,17664,67618,75102,29821,257,21792,13324,513]

theorem envBound27876 : H12AffineFastState.Bounded env27876 := by
  intro p hp
  have h : env27876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27875_27876 : H12AffineEnvironment.transform 6 8 env27875 = env27876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27875 == env27876) = true)

theorem identity27876 : scanCanonicalize (H12AffineFastState.compose env27876 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound27876 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env27877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21590,13389,23669,1025,0,25628,29821,29773,21762,8192,64,10588,24909,17664,23668,28936,29821,257,21792,13324,513]

theorem envBound27877 : H12AffineFastState.Bounded env27877 := by
  intro p hp
  have h : env27877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27876_27877 : H12AffineEnvironment.transform 15 21590 env27876 = env27877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env27876 == env27877) = true)

theorem identity27877 : scanCanonicalize (H12AffineFastState.compose env27877 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound27877 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21590,5393,23669,1025,0,17728,21793,21777,21762,348,64,2048,16401,17664,23668,20564,21793,257,21792,5456,513]

theorem envBound27878 : H12AffineFastState.Bounded env27878 := by
  intro p hp
  have h : env27878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27877_27878 : H12AffineEnvironment.transform 12 348 env27877 = env27878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env27877 == env27878) = true)

theorem identity27878 : scanCanonicalize (H12AffineFastState.compose env27878 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1025,0,4160,33,17,2,348,64,2048,5393,4096,2420,1364,33,257,32,5456,513]

theorem envBound27879 : H12AffineFastState.Bounded env27879 := by
  intro p hp
  have h : env27879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27878_27879 : H12AffineEnvironment.transform 13 5376 env27878 = env27879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27878 == env27879) = true)

theorem identity27879 : scanCanonicalize (H12AffineFastState.compose env27879 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound27879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,357,348,1125,1,342,1140,2421,1025,0,293,33,17,2,348,64,2048,1140,357,2420,1364,33,257,32,1077,513]

theorem envBound27880 : H12AffineFastState.Bounded env27880 := by
  intro p hp
  have h : env27880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27879_27880 : H12AffineEnvironment.transform 11 357 env27879 = env27880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env27879 == env27880) = true)

theorem identity27880 : scanCanonicalize (H12AffineFastState.compose env27880 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound27880 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,357,348,1125,1,342,1140,1296,1025,0,293,33,17,2,348,64,1125,1140,357,1297,1364,33,257,32,1077,513]

theorem envBound27881 : H12AffineFastState.Bounded env27881 := by
  intro p hp
  have h : env27881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27880_27881 : H12AffineEnvironment.transform 10 1125 env27880 = env27881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env27880 == env27881) = true)

theorem identity27881 : scanCanonicalize (H12AffineFastState.compose env27881 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound27881 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env27882 : List Nat := [2,4,8,16,32,64,8,256,308,1024,1125,357,348,1125,1,342,1140,1296,1025,0,293,33,17,2,348,64,1125,1140,357,1297,1364,33,257,32,1077,309]

theorem envBound27882 : H12AffineFastState.Bounded env27882 := by
  intro p hp
  have h : env27882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27881_27882 : H12AffineEnvironment.transform 8 308 env27881 = env27882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env27881 == env27882) = true)

theorem identity27882 : scanCanonicalize (H12AffineFastState.compose env27882 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound27882 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env27883 : List Nat := [2,4,8,16,32,33,8,256,308,1024,1028,260,317,1028,1,311,1045,1296,1025,0,293,33,17,2,317,33,1028,1045,260,1297,1333,33,257,32,1077,309]

theorem envBound27883 : H12AffineFastState.Bounded env27883 := by
  intro p hp
  have h : env27883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27882_27883 : H12AffineEnvironment.transform 5 33 env27882 = env27883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env27882 == env27883) = true)

theorem identity27883 : scanCanonicalize (H12AffineFastState.compose env27883 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27883 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27884 : List Nat := [2,4,8,16,0,1,8,256,276,1024,1028,260,285,1028,1,279,1045,1296,1025,0,261,1,17,2,285,1,1028,1045,260,1297,1301,1,257,0,1045,277]

theorem envBound27884 : H12AffineFastState.Bounded env27884 := by
  intro p hp
  have h : env27884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27883_27884 : H12AffineEnvironment.transform 4 0 env27883 = env27884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27883 == env27884) = true)

theorem identity27884 : scanCanonicalize (H12AffineFastState.compose env27884 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27884 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env27885 : List Nat := [2,4,8,1,0,1,8,256,261,1024,1028,260,268,1028,1,262,1028,1281,1025,0,261,1,0,2,268,1,1028,1028,260,1280,1284,1,257,0,1028,260]

theorem envBound27885 : H12AffineFastState.Bounded env27885 := by
  intro p hp
  have h : env27885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27884_27885 : H12AffineEnvironment.transform 3 1 env27884 = env27885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27884 == env27885) = true)

theorem identity27885 : scanCanonicalize (H12AffineFastState.compose env27885 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound27885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27886 : List Nat := [2,4,8,1,0,1,8,256,261,256,260,260,268,260,1,262,260,1,257,0,261,1,0,2,268,1,260,260,260,0,4,1,257,0,260,260]

theorem envBound27886 : H12AffineFastState.Bounded env27886 := by
  intro p hp
  have h : env27886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27885_27886 : H12AffineEnvironment.transform 9 256 env27885 = env27886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env27885 == env27886) = true)

theorem identity27886 : scanCanonicalize (H12AffineFastState.compose env27886 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27887 : List Nat := [2,4,8,1,0,1,8,5,0,5,1,1,9,1,1,3,1,1,4,0,0,1,0,2,9,1,1,1,1,0,4,1,4,0,1,1]

theorem envBound27887 : H12AffineFastState.Bounded env27887 := by
  intro p hp
  have h : env27887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27886_27887 : H12AffineEnvironment.transform 7 5 env27886 = env27887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27886 == env27887) = true)

def env27888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,67619,1025,0,77898,73770,73755,65877,8193,64,10588,79131,17664,67618,75103,29820,257,21792,13325,513]

theorem envBound27888 : H12AffineFastState.Bounded env27888 := by
  intro p hp
  have h : env27888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27875_27888 : H12AffineEnvironment.transform 6 9 env27875 = env27888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27875 == env27888) = true)

theorem identity27888 : scanCanonicalize (H12AffineFastState.compose env27888 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27888 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,342,24909,2421,1025,0,12572,8572,8525,3,8193,64,10588,13389,17664,2420,9225,29820,257,21792,13325,513]

theorem envBound27889 : H12AffineFastState.Bounded env27889 := by
  intro p hp
  have h : env27889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27888_27889 : H12AffineEnvironment.transform 15 342 env27888 = env27889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27888 == env27889) = true)

def env27890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2201878,2098513,17664,2437195,2102684,2411676,257,21792,46213,2175563]

theorem envBound27890 : H12AffineFastState.Bounded env27890 := by
  intro p hp
  have h : env27890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27871_27890 : H12AffineEnvironment.transform 21 272513 env27871 = env27890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27871 == env27890) = true)

theorem identity27890 : scanCanonicalize (H12AffineFastState.compose env27890 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27890 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272513,2101329,41431,8328,64,2144540,2098513,17664,2363457,2102684,2411676,257,21792,46213,2101825]

theorem envBound27891 : H12AffineFastState.Bounded env27891 := by
  intro p hp
  have h : env27891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27890_27891 : H12AffineEnvironment.transform 15 8202 env27890 = env27891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27890 == env27891) = true)

theorem identity27891 : scanCanonicalize (H12AffineFastState.compose env27891 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 309472) := by decide +kernel

theorem selectedBound27891 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env27892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,309472,272513,305329,41431,8328,64,262652,310705,17664,43169,306556,29820,257,21792,46213,305825]

theorem envBound27892 : H12AffineFastState.Bounded env27892 := by
  intro p hp
  have h : env27892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27891_27892 : H12AffineEnvironment.transform 20 309472 env27891 = env27892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 309472 env27891 == env27892) = true)

theorem identity27892 : scanCanonicalize (H12AffineFastState.compose env27892 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound27892 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10400,1025,32769,36928,33,32785,41431,8328,64,10588,38161,17664,43169,34268,29820,257,21792,46213,33281]

theorem envBound27893 : H12AffineFastState.Bounded env27893 := by
  intro p hp
  have h : env27893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27892_27893 : H12AffineEnvironment.transform 17 10400 env27892 = env27893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27892 == env27893) = true)

theorem identity27893 : scanCanonicalize (H12AffineFastState.compose env27893 (packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound27893 : packedSelected [0,1,4,5,7,8,16,17,20,22,24] rootPS < 2^1333 := by decide +kernel

def env27894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,13341,10400,1025,29708,25677,33,29724,21978,8328,64,10588,24860,17664,23724,29137,29820,257,21792,16520,30220]

theorem envBound27894 : H12AffineFastState.Bounded env27894 := by
  intro p hp
  have h : env27894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27893_27894 : H12AffineEnvironment.transform 14 29709 env27893 = env27894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env27893 == env27894) = true)

theorem identity27894 : scanCanonicalize (H12AffineFastState.compose env27894 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound27894 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,373,8202,13341,10400,1025,372,4405,33,356,8354,8328,64,10588,5220,12408,10708,1193,260,257,8280,13808,884]

theorem envBound27895 : H12AffineFastState.Bounded env27895 := by
  intro p hp
  have h : env27895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27894_27895 : H12AffineEnvironment.transform 13 13688 env27894 = env27895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env27894 == env27895) = true)

theorem identity27895 : scanCanonicalize (H12AffineFastState.compose env27895 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27895 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27896 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,13525,216,8202,13341,10400,1025,217,4248,33,201,8354,8328,64,10481,5220,12408,10361,1193,169,172,8280,13405,729]

theorem envBound27896 : H12AffineFastState.Bounded env27896 := by
  intro p hp
  have h : env27896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27895_27896 : H12AffineEnvironment.transform 7 173 env27895 = env27896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27895 == env27896) = true)

theorem identity27896 : scanCanonicalize (H12AffineFastState.compose env27896 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27896 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27897 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,13444,137,8202,13341,10400,1025,136,4248,33,152,8354,8328,17,10400,5173,12329,10280,1193,169,172,8201,13324,648]

theorem envBound27897 : H12AffineFastState.Bounded env27897 := by
  intro p hp
  have h : env27897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27896_27897 : H12AffineEnvironment.transform 5 17 env27896 = env27897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27896 == env27897) = true)

theorem identity27897 : scanCanonicalize (H12AffineFastState.compose env27897 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound27897 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env27898 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,161,5157,137,171,5308,2049,1025,136,4248,33,152,3,41,17,2049,5173,4232,2185,1193,169,172,168,5293,648]

theorem envBound27898 : H12AffineFastState.Bounded env27898 := by
  intro p hp
  have h : env27898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27897_27898 : H12AffineEnvironment.transform 12 161 env27897 = env27898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env27897 == env27898) = true)

theorem identity27898 : scanCanonicalize (H12AffineFastState.compose env27898 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound27898 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env27899 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,9,5157,33,3,5140,2049,1025,32,4144,33,48,3,41,17,2049,5173,4128,2081,1025,1,4,0,5125,544]

theorem envBound27899 : H12AffineFastState.Bounded env27899 := by
  intro p hp
  have h : env27899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27898_27899 : H12AffineEnvironment.transform 6 40 env27898 = env27899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env27898 == env27899) = true)

theorem identity27899 : scanCanonicalize (H12AffineFastState.compose env27899 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound27899 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env27900 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,4096,9,4112,33,3,4129,2049,52,32,4144,33,48,3,41,17,2049,4096,4128,2081,52,1,4,0,4144,544]

theorem envBound27900 : H12AffineFastState.Bounded env27900 := by
  intro p hp
  have h : env27900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27899_27900 : H12AffineEnvironment.transform 9 53 env27899 = env27900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env27899 == env27900) = true)

theorem identity27900 : scanCanonicalize (H12AffineFastState.compose env27900 (packedSelected [0,1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2622) := by decide +kernel

theorem selectedBound27900 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env27901 : List Nat := [2,4,8,16,32,17,40,5,512,53,2048,2622,9,2606,33,3,2591,2049,52,32,2574,33,48,3,41,17,2049,2622,2590,2081,52,1,4,0,2574,544]

theorem envBound27901 : H12AffineFastState.Bounded env27901 := by
  intro p hp
  have h : env27901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27900_27901 : H12AffineEnvironment.transform 11 2622 env27900 = env27901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2622 env27900 == env27901) = true)

def env27902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664598,8393985,10507601,8724506,2102685,12645453,257,21793,46212,2175562]

theorem envBound27902 : H12AffineFastState.Bounded env27902 := by
  intro p hp
  have h : env27902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27807_27902 : H12AffineEnvironment.transform 23 10588557 env27807 = env27902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env27807 == env27902) = true)

def env27903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664598,2098513,17665,2437194,2102685,6349853,257,21793,46212,2175562]

theorem envBound27903 : H12AffineFastState.Bounded env27903 := by
  intro p hp
  have h : env27903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27902_27903 : H12AffineEnvironment.transform 22 2101328 env27902 = env27903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env27902 == env27903) = true)

def env27904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2201878,2098513,17665,2437194,2102685,2411677,257,21793,46212,2175562]

theorem envBound27904 : H12AffineFastState.Bounded env27904 := by
  intro p hp
  have h : env27904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27903_27904 : H12AffineEnvironment.transform 21 272512 env27903 = env27904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27903 == env27904) = true)

def env27905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272392,2101328,98645,8192,64,2201878,2098513,17665,2437194,2102549,2411541,257,21793,46092,2175562]

theorem envBound27905 : H12AffineFastState.Bounded env27905 := by
  intro p hp
  have h : env27905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27904_27905 : H12AffineEnvironment.transform 6 8 env27904 = env27905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27904 == env27905) = true)

theorem identity27905 : scanCanonicalize (H12AffineFastState.compose env27905 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound27905 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272392,73755,98645,8192,64,43357,79130,17665,262145,75102,392286,257,21793,46092,513]

theorem envBound27906 : H12AffineFastState.Bounded env27906 := by
  intro p hp
  have h : env27906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27905_27906 : H12AffineEnvironment.transform 20 77899 env27905 = env27906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env27905 == env27906) = true)

theorem identity27906 : scanCanonicalize (H12AffineFastState.compose env27906 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound27906 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,67619,1025,32769,77899,73771,73755,98645,8192,64,43357,79130,17665,67618,75102,62589,257,21793,46092,513]

theorem envBound27907 : H12AffineFastState.Bounded env27907 := by
  intro p hp
  have h : env27907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27906_27907 : H12AffineEnvironment.transform 17 67619 env27906 = env27907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env27906 == env27907) = true)

theorem identity27907 : scanCanonicalize (H12AffineFastState.compose env27907 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound27907 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env27908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,70678,67619,1025,29709,77899,73771,73755,95577,8192,64,23889,79130,17665,67618,75102,113,257,21793,16384,513]

theorem envBound27908 : H12AffineFastState.Bounded env27908 := by
  intro p hp
  have h : env27908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27907_27908 : H12AffineEnvironment.transform 14 29708 env27907 = env27908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env27907 == env27908) = true)

theorem identity27908 : scanCanonicalize (H12AffineFastState.compose env27908 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound27908 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env27909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,65536,70678,67619,1025,0,77899,73771,73755,65876,8192,64,10588,79130,12556,67618,75102,113,257,8492,13325,513]

theorem envBound27909 : H12AffineFastState.Bounded env27909 := by
  intro p hp
  have h : env27909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27908_27909 : H12AffineEnvironment.transform 13 13325 env27908 = env27909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env27908 == env27909) = true)

theorem identity27909 : scanCanonicalize (H12AffineFastState.compose env27909 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound27909 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env27910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,262,5392,2341,1025,0,12621,8493,8477,82,8192,64,10588,13340,12556,2340,9304,113,257,8492,13325,513]

theorem envBound27910 : H12AffineFastState.Bounded env27910 := by
  intro p hp
  have h : env27910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27909_27910 : H12AffineEnvironment.transform 15 262 env27909 = env27910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env27909 == env27910) = true)

theorem identity27910 : scanCanonicalize (H12AffineFastState.compose env27910 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27910 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27911 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,262,5392,2341,1025,0,12573,8493,8477,2,8192,16,10508,13340,12556,2340,9224,33,257,8492,13325,513]

theorem envBound27911 : H12AffineFastState.Bounded env27911 := by
  intro p hp
  have h : env27911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27910_27911 : H12AffineEnvironment.transform 5 16 env27910 = env27911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27910 == env27911) = true)

theorem identity27911 : scanCanonicalize (H12AffineFastState.compose env27911 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound27911 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env27912 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,12573,1,262,4096,2341,273,0,12573,8493,8477,2,8192,16,10508,12556,12556,2340,8472,33,257,8492,12573,513]

theorem envBound27912 : H12AffineFastState.Bounded env27912 := by
  intro p hp
  have h : env27912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27911_27912 : H12AffineEnvironment.transform 9 272 env27911 = env27912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env27911 == env27912) = true)

theorem identity27912 : scanCanonicalize (H12AffineFastState.compose env27912 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27912 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env27913 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4113,1,262,4096,2341,273,0,4113,33,17,2,268,16,2048,4096,4096,2340,20,33,257,32,4113,513]

theorem envBound27913 : H12AffineFastState.Bounded env27913 := by
  intro p hp
  have h : env27913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27912_27913 : H12AffineEnvironment.transform 12 268 env27912 = env27913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27912 == env27913) = true)

theorem identity27913 : scanCanonicalize (H12AffineFastState.compose env27913 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound27913 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27914 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,277,268,260,1,262,277,2341,273,0,260,33,17,2,268,16,2048,277,277,2340,20,33,257,32,260,513]

theorem envBound27914 : H12AffineFastState.Bounded env27914 := by
  intro p hp
  have h : env27914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27913_27914 : H12AffineEnvironment.transform 11 277 env27913 = env27914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env27913 == env27914) = true)

theorem identity27914 : scanCanonicalize (H12AffineFastState.compose env27914 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27914 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27915 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,277,268,260,1,262,277,2308,273,0,260,0,17,2,268,16,2048,277,277,2309,20,0,257,1,260,513]

theorem envBound27915 : H12AffineFastState.Bounded env27915 := by
  intro p hp
  have h : env27915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27914_27915 : H12AffineEnvironment.transform 4 1 env27914 = env27915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27914 == env27915) = true)

theorem identity27915 : scanCanonicalize (H12AffineFastState.compose env27915 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound27915 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27916 : List Nat := [2,4,8,16,1,16,8,256,512,272,512,277,268,260,1,262,277,772,273,0,260,0,17,2,268,16,512,277,277,773,20,0,257,1,260,513]

theorem envBound27916 : H12AffineFastState.Bounded env27916 := by
  intro p hp
  have h : env27916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27915_27916 : H12AffineEnvironment.transform 10 512 env27915 = env27916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env27915 == env27916) = true)

theorem identity27916 : scanCanonicalize (H12AffineFastState.compose env27916 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27917 : List Nat := [2,4,8,1,1,1,8,256,512,257,512,260,268,260,1,262,260,772,256,0,260,0,0,2,268,1,512,260,260,773,5,0,257,1,260,513]

theorem envBound27917 : H12AffineFastState.Bounded env27917 := by
  intro p hp
  have h : env27917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27916_27917 : H12AffineEnvironment.transform 3 1 env27916 = env27917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27916 == env27917) = true)

def env27918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272393,2101328,98644,8193,64,2201878,2098513,17665,2437194,2102548,2411540,257,21793,46093,2175562]

theorem envBound27918 : H12AffineFastState.Bounded env27918 := by
  intro p hp
  have h : env27918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27904_27918 : H12AffineEnvironment.transform 6 9 env27904 = env27918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27904 == env27918) = true)

theorem identity27918 : scanCanonicalize (H12AffineFastState.compose env27918 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound27918 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env27919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,262144,1025,32769,2097152,272393,2101328,8542,8193,64,2111772,2098513,17665,2396224,2102548,2411540,257,21793,46093,2134592]

theorem envBound27919 : H12AffineFastState.Bounded env27919 := by
  intro p hp
  have h : env27919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27918_27919 : H12AffineEnvironment.transform 15 40970 env27918 = env27919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env27918 == env27919) = true)

theorem identity27919 : scanCanonicalize (H12AffineFastState.compose env27919 (packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound27919 : packedSelected [0,4,5,7,8,17,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env27920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,35188,1025,32769,2097152,41341,2101328,8542,8193,64,2111772,2098513,17665,2103604,2102548,2114912,257,21793,46093,2134592]

theorem envBound27920 : H12AffineFastState.Bounded env27920 := by
  intro p hp
  have h : env27920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27919_27920 : H12AffineEnvironment.transform 17 35188 env27919 = env27920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env27919 == env27920) = true)

theorem identity27920 : scanCanonicalize (H12AffineFastState.compose env27920 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound27920 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env27921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16400,35188,1025,32769,4160,41341,16,8542,8193,64,10588,5393,17665,2420,1364,21792,257,21793,46093,33280]

theorem envBound27921 : H12AffineFastState.Bounded env27921 := by
  intro p hp
  have h : env27921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27920_27921 : H12AffineEnvironment.transform 20 4160 env27920 = env27921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env27920 == env27921) = true)

theorem identity27921 : scanCanonicalize (H12AffineFastState.compose env27921 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound27921 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33111,16400,35188,1025,32769,4160,32800,16,3,348,64,2049,5393,17665,2420,1364,21792,257,21793,38224,33280]

theorem envBound27922 : H12AffineFastState.Bounded env27922 := by
  intro p hp
  have h : env27922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27921_27922 : H12AffineEnvironment.transform 12 349 env27921 = env27922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env27921 == env27922) = true)

theorem identity27922 : scanCanonicalize (H12AffineFastState.compose env27922 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound27922 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env27923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21541,21874,16400,23889,1025,21540,4160,21509,16,3,348,64,2049,5393,17665,2420,1364,21792,257,21793,16757,22053]

theorem envBound27923 : H12AffineFastState.Bounded env27923 := by
  intro p hp
  have h : env27923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27922_27923 : H12AffineEnvironment.transform 14 21541 env27922 = env27923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env27922 == env27923) = true)

theorem identity27923 : scanCanonicalize (H12AffineFastState.compose env27923 (packedSelected [1,2,3,4,5,8,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound27923 : packedSelected [1,2,3,4,5,8,9,11,14] rootPS < 2^1333 := by decide +kernel

def env27924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,2340,7425,7254,2356,5237,1025,7424,4160,7457,16,3,348,64,2049,5393,3109,2420,1364,7172,257,7173,2129,7937]

theorem envBound27924 : H12AffineFastState.Bounded env27924 := by
  intro p hp
  have h : env27924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27923_27924 : H12AffineEnvironment.transform 13 2340 env27923 = env27924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env27923 == env27924) = true)

theorem identity27924 : scanCanonicalize (H12AffineFastState.compose env27924 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27924 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27925 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,2340,7425,7175,2356,5156,1025,7424,4113,7457,16,3,269,17,2049,5393,3109,2341,1285,7172,257,7173,2048,7937]

theorem envBound27925 : H12AffineFastState.Bounded env27925 := by
  intro p hp
  have h : env27925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27924_27925 : H12AffineEnvironment.transform 5 17 env27924 = env27925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27924 == env27925) = true)

theorem identity27925 : scanCanonicalize (H12AffineFastState.compose env27925 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound27925 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env27926 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2340,292,34,2356,2049,1025,293,3124,260,16,3,269,17,2049,2356,3109,2341,1285,33,257,32,2048,804]

theorem envBound27926 : H12AffineFastState.Bounded env27926 := by
  intro p hp
  have h : env27926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27925_27926 : H12AffineEnvironment.transform 11 3109 env27925 = env27926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env27925 == env27926) = true)

theorem identity27926 : scanCanonicalize (H12AffineFastState.compose env27926 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27926 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env27927 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,41,2049,1,34,2065,2049,1025,0,3124,33,16,3,40,17,2049,2065,3109,2048,1056,33,36,32,2048,513]

theorem envBound27927 : H12AffineFastState.Bounded env27927 := by
  intro p hp
  have h : env27927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27926_27927 : H12AffineEnvironment.transform 7 37 env27926 = env27927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27926 == env27927) = true)

def env27928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2201879,2098513,17665,2437194,2102685,2411676,257,21793,46212,2175562]

theorem envBound27928 : H12AffineFastState.Bounded env27928 := by
  intro p hp
  have h : env27928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27903_27928 : H12AffineEnvironment.transform 21 272513 env27903 = env27928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27903 == env27928) = true)

theorem identity27928 : scanCanonicalize (H12AffineFastState.compose env27928 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound27928 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,272513,17,98781,8328,64,100694,5392,17665,335883,1500,318685,257,21793,46212,74251]

theorem envBound27929 : H12AffineFastState.Bounded env27929 := by
  intro p hp
  have h : env27929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27928_27929 : H12AffineEnvironment.transform 20 4161 env27928 = env27929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env27928 == env27929) = true)

theorem identity27929 : scanCanonicalize (H12AffineFastState.compose env27929 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound27929 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env27930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272513,17,41431,8328,64,43356,5392,17665,262145,1500,318685,257,21793,46212,513]

theorem envBound27930 : H12AffineFastState.Bounded env27930 := by
  intro p hp
  have h : env27930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27929_27930 : H12AffineEnvironment.transform 15 8202 env27929 = env27930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env27929 == env27930) = true)

theorem identity27930 : scanCanonicalize (H12AffineFastState.compose env27930 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound27930 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env27931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10400,1025,32769,4161,33,17,41431,8328,64,43356,5392,17665,10401,1500,62589,257,21793,46212,513]

theorem envBound27931 : H12AffineFastState.Bounded env27931 := by
  intro p hp
  have h : env27931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27930_27931 : H12AffineEnvironment.transform 17 10400 env27930 = env27931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env27930 == env27931) = true)

theorem identity27931 : scanCanonicalize (H12AffineFastState.compose env27931 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound27931 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env27932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16401,10400,1025,0,4161,33,17,8662,8328,64,10589,5392,17665,10401,1500,29820,257,21793,13445,513]

theorem envBound27932 : H12AffineFastState.Bounded env27932 := by
  intro p hp
  have h : env27932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27931_27932 : H12AffineEnvironment.transform 14 1 env27931 = env27932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env27931 == env27932) = true)

theorem identity27932 : scanCanonicalize (H12AffineFastState.compose env27932 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound27932 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env27933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,1,8202,4097,10400,1025,0,4161,33,17,8662,8328,64,10589,5392,5393,10401,1500,9324,257,1329,13445,513]

theorem envBound27933 : H12AffineFastState.Bounded env27933 := by
  intro p hp
  have h : env27933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27932_27933 : H12AffineEnvironment.transform 13 4112 env27932 = env27933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env27932 == env27933) = true)

theorem identity27933 : scanCanonicalize (H12AffineFastState.compose env27933 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound27933 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env27934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,4112,1,1095,4097,3309,1025,0,4161,33,17,1435,1221,64,3344,5392,5393,3308,1500,33,257,1329,4296,513]

theorem envBound27934 : H12AffineFastState.Bounded env27934 := by
  intro p hp
  have h : env27934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27933_27934 : H12AffineEnvironment.transform 12 1101 env27933 = env27934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env27933 == env27934) = true)

theorem identity27934 : scanCanonicalize (H12AffineFastState.compose env27934 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound27934 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env27935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1076,4096,1101,4112,1,1095,4097,217,1025,0,4161,33,17,1435,1221,64,292,5392,5393,216,1500,33,257,1329,4296,513]

theorem envBound27935 : H12AffineFastState.Bounded env27935 := by
  intro p hp
  have h : env27935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27934_27935 : H12AffineEnvironment.transform 10 1076 env27934 = env27935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env27934 == env27935) = true)

theorem identity27935 : scanCanonicalize (H12AffineFastState.compose env27935 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound27935 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env27936 : List Nat := [2,4,8,16,32,64,128,256,512,273,293,4096,348,4112,1,342,4097,217,272,0,4161,33,17,138,468,64,292,4097,4096,216,205,33,257,32,4296,513]

theorem envBound27936 : H12AffineFastState.Bounded env27936 := by
  intro p hp
  have h : env27936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27935_27936 : H12AffineEnvironment.transform 9 273 env27935 = env27936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env27935 == env27936) = true)

theorem identity27936 : scanCanonicalize (H12AffineFastState.compose env27936 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound27936 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27937 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,4096,241,4112,1,251,4097,217,189,0,4161,33,17,138,121,64,137,4097,4096,216,205,33,172,32,4296,513]

theorem envBound27937 : H12AffineFastState.Bounded env27937 := by
  intro p hp
  have h : env27937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27936_27937 : H12AffineEnvironment.transform 7 173 env27936 = env27937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env27936 == env27937) = true)

theorem identity27937 : scanCanonicalize (H12AffineFastState.compose env27937 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound27937 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27938 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,152,241,136,1,251,153,217,189,0,217,33,17,138,121,64,137,153,152,216,205,33,172,32,80,513]

theorem envBound27938 : H12AffineFastState.Bounded env27938 := by
  intro p hp
  have h : env27938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27937_27938 : H12AffineEnvironment.transform 11 152 env27937 = env27938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env27937 == env27938) = true)

theorem identity27938 : scanCanonicalize (H12AffineFastState.compose env27938 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27938 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27939 : List Nat := [2,4,8,16,32,16,128,173,512,188,136,152,161,136,1,171,153,137,189,0,137,33,17,138,41,16,137,153,152,136,157,33,172,32,0,513]

theorem envBound27939 : H12AffineFastState.Bounded env27939 := by
  intro p hp
  have h : env27939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27938_27939 : H12AffineEnvironment.transform 5 16 env27938 = env27939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27938 == env27939) = true)

theorem identity27939 : scanCanonicalize (H12AffineFastState.compose env27939 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27939 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27940 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,1,1,34,16,0,52,0,0,33,17,3,41,16,0,16,17,1,20,33,37,32,0,513]

theorem envBound27940 : H12AffineFastState.Bounded env27940 := by
  intro p hp
  have h : env27940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27939_27940 : H12AffineEnvironment.transform 6 9 env27939 = env27940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27939 == env27940) = true)

theorem identity27940 : scanCanonicalize (H12AffineFastState.compose env27940 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound27940 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27941 : List Nat := [2,4,8,16,32,16,9,36,17,53,1,17,40,1,1,34,16,0,52,0,0,33,17,3,41,16,0,16,17,1,20,33,37,32,0,16]

theorem envBound27941 : H12AffineFastState.Bounded env27941 := by
  intro p hp
  have h : env27941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27940_27941 : H12AffineEnvironment.transform 8 17 env27940 = env27941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env27940 == env27941) = true)

theorem identity27941 : scanCanonicalize (H12AffineFastState.compose env27941 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound27941 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27942 : List Nat := [2,4,8,16,26,16,9,30,17,15,1,17,18,1,1,24,16,0,14,0,0,27,17,3,19,16,0,16,17,1,20,27,31,26,0,16]

theorem envBound27942 : H12AffineFastState.Bounded env27942 := by
  intro p hp
  have h : env27942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27941_27942 : H12AffineEnvironment.transform 4 26 env27941 = env27942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env27941 == env27942) = true)

def env27943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664598,2098512,17664,2437195,2102685,6349852,257,21793,46212,2175562]

theorem envBound27943 : H12AffineFastState.Bounded env27943 := by
  intro p hp
  have h : env27943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27902_27943 : H12AffineEnvironment.transform 22 2101329 env27902 = env27943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env27902 == env27943) = true)

def env27944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2201878,2098512,17664,2437195,2102685,2411676,257,21793,46212,2175562]

theorem envBound27944 : H12AffineFastState.Bounded env27944 := by
  intro p hp
  have h : env27944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27943_27944 : H12AffineEnvironment.transform 21 272512 env27943 = env27944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env27943 == env27944) = true)

theorem identity27944 : scanCanonicalize (H12AffineFastState.compose env27944 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound27944 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,70862,262144,1025,29909,2097152,272512,2101329,95496,8328,64,2190786,2098512,17664,2437195,2102685,2373704,257,21793,16464,2175562]

theorem envBound27945 : H12AffineFastState.Bounded env27945 := by
  intro p hp
  have h : env27945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27944_27945 : H12AffineEnvironment.transform 14 29908 env27944 = env27945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env27944 == env27945) = true)

def env27946 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,262144,1025,29829,2097152,272512,2101249,95496,8328,16,2190738,2098432,17664,2437147,2102685,2373656,257,21793,16384,2175514]

theorem envBound27946 : H12AffineFastState.Bounded env27946 := by
  intro p hp
  have h : env27946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27945_27946 : H12AffineEnvironment.transform 5 16 env27945 = env27946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27945 == env27946) = true)

theorem identity27946 : scanCanonicalize (H12AffineFastState.compose env27946 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound27946 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27947 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,70814,76198,1025,29829,2097152,65830,2101249,95496,8328,16,2190738,2098432,17664,2103741,2102685,2167230,257,21793,16384,2175514]

theorem envBound27947 : H12AffineFastState.Bounded env27947 := by
  intro p hp
  have h : env27947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27946_27947 : H12AffineEnvironment.transform 17 76198 env27946 = env27947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env27946 == env27947) = true)

theorem identity27947 : scanCanonicalize (H12AffineFastState.compose env27947 (packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound27947 : packedSelected [0,1,3,4,7,10,16,20,22,24,28,31] rootPS < 2^1333 := by decide +kernel

def env27948 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21897,65536,70814,67755,1025,21896,2097152,65830,2101249,87045,389,16,2182303,2098432,17664,2103741,2102685,2167230,257,21793,16384,2167575]

theorem envBound27948 : H12AffineFastState.Bounded env27948 := by
  intro p hp
  have h : env27948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27947_27948 : H12AffineEnvironment.transform 12 269 env27947 = env27948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env27947 == env27948) = true)

theorem identity27948 : scanCanonicalize (H12AffineFastState.compose env27948 (packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound27948 : packedSelected [0,1,4,5,7,8,17,18,22,23,24] rootPS < 2^1333 := by decide +kernel

def env27949 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21897,399,5393,2340,1025,21896,2097152,169,2101249,21898,389,16,2116880,2098432,17664,2103741,2102685,2101297,257,21793,16384,2101912]

theorem envBound27949 : H12AffineFastState.Bounded env27949 := by
  intro p hp
  have h : env27949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27948_27949 : H12AffineEnvironment.transform 15 399 env27948 = env27949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env27948 == env27949) = true)

theorem identity27949 : scanCanonicalize (H12AffineFastState.compose env27949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound27949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27950 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21897,399,5393,2340,1025,21896,17816,169,21913,21898,389,16,2184,16536,17664,23589,20485,21929,257,21793,16384,22272]

theorem envBound27950 : H12AffineFastState.Bounded env27950 := by
  intro p hp
  have h : env27950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27949_27950 : H12AffineEnvironment.transform 20 17816 env27949 = env27950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env27949 == env27950) = true)

theorem identity27950 : scanCanonicalize (H12AffineFastState.compose env27950 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound27950 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27951 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5513,0,399,5393,2340,1025,1,4113,169,16,3,389,16,2184,5393,4233,2476,1420,32,257,168,5513,649]

theorem envBound27951 : H12AffineFastState.Bounded env27951 := by
  intro p hp
  have h : env27951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27950_27951 : H12AffineEnvironment.transform 13 5513 env27950 = env27951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env27950 == env27951) = true)

theorem identity27951 : scanCanonicalize (H12AffineFastState.compose env27951 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound27951 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env27952 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,269,5408,0,294,5393,2340,1025,1,4113,0,16,3,300,16,2081,5393,4128,2309,1317,32,257,1,5408,544]

theorem envBound27952 : H12AffineFastState.Bounded env27952 := by
  intro p hp
  have h : env27952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27951_27952 : H12AffineEnvironment.transform 6 41 env27951 = env27952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env27951 == env27952) = true)

def env27953 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70815,262144,1025,29828,2097152,272512,2101248,95496,8328,17,2190739,2098433,17664,2437146,2102685,2373657,257,21793,16385,2175515]

theorem envBound27953 : H12AffineFastState.Bounded env27953 := by
  intro p hp
  have h : env27953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27945_27953 : H12AffineEnvironment.transform 5 17 env27945 = env27953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27945 == env27953) = true)

theorem identity27953 : scanCanonicalize (H12AffineFastState.compose env27953 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 2477) := by decide +kernel

theorem selectedBound27953 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env27954 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,70815,2477,1025,29828,2097152,8493,2101248,95496,8328,17,2190739,2098433,17664,2177463,2102685,2109876,257,21793,16385,2175515]

theorem envBound27954 : H12AffineFastState.Bounded env27954 := by
  intro p hp
  have h : env27954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27953_27954 : H12AffineEnvironment.transform 17 2477 env27953 = env27954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2477 env27953 == env27954) = true)

theorem identity27954 : scanCanonicalize (H12AffineFastState.compose env27954 (packedSelected [1,10,11,17,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound27954 : packedSelected [1,10,11,17,26,28,32] rootPS < 2^1333 := by decide +kernel

def env27955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,30082,24861,2477,1025,29828,2097152,8493,2101248,138,8328,17,2103313,2098433,17664,2116661,2102685,2109876,257,21793,16385,2115481]

theorem envBound27955 : H12AffineFastState.Bounded env27955 := by
  intro p hp
  have h : env27955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27954_27955 : H12AffineEnvironment.transform 15 30082 env27954 = env27955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env27954 == env27955) = true)

theorem identity27955 : scanCanonicalize (H12AffineFastState.compose env27955 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound27955 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env27956 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8461,8202,13461,2477,1025,8460,2097152,8493,2101248,138,8328,17,2103313,2098433,4232,2103741,2102685,2109876,257,169,5513,2101777]

theorem envBound27956 : H12AffineFastState.Bounded env27956 := by
  intro p hp
  have h : env27956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27955_27956 : H12AffineEnvironment.transform 13 5512 env27955 = env27956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env27955 == env27956) = true)

theorem identity27956 : scanCanonicalize (H12AffineFastState.compose env27956 (packedSelected [1,2,3,4,5,6,7,8,10,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound27956 : packedSelected [1,2,3,4,5,6,7,8,10,15,16,18] rootPS < 2^1333 := by decide +kernel

def env27957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,664,4096,8192,5512,8461,8202,13461,821,1025,8460,2097152,8493,2101248,138,8328,17,2101897,2098433,4232,2102053,2102685,2109876,257,169,5513,2101777]

theorem envBound27957 : H12AffineFastState.Bounded env27957 := by
  intro p hp
  have h : env27957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27956_27957 : H12AffineEnvironment.transform 10 664 env27956 = env27957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env27956 == env27957) = true)

theorem identity27957 : scanCanonicalize (H12AffineFastState.compose env27957 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 4144) := by decide +kernel

theorem selectedBound27957 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env27958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,664,4096,8192,5512,8461,8202,13461,821,1025,8460,4144,8493,48,138,8328,17,697,5425,4232,789,1453,8580,257,169,5513,545]

theorem envBound27958 : H12AffineFastState.Bounded env27958 := by
  intro p hp
  have h : env27958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27957_27958 : H12AffineEnvironment.transform 20 4144 env27957 = env27958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4144 env27957 == env27958) = true)

theorem identity27958 : scanCanonicalize (H12AffineFastState.compose env27958 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound27958 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27959 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,4096,8192,5377,8461,8202,13340,821,1025,8460,4144,8493,48,3,8193,17,560,5425,4097,789,1316,8461,257,32,5376,545]

theorem envBound27959 : H12AffineFastState.Bounded env27959 := by
  intro p hp
  have h : env27959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27958_27959 : H12AffineEnvironment.transform 6 9 env27958 = env27959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env27958 == env27959) = true)

theorem identity27959 : scanCanonicalize (H12AffineFastState.compose env27959 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound27959 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27960 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,804,8192,1573,8461,8202,10040,821,1025,8460,788,8493,48,3,8193,17,560,1557,805,789,1316,8461,257,32,1572,545]

theorem envBound27960 : H12AffineFastState.Bounded env27960 := by
  intro p hp
  have h : env27960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27959_27960 : H12AffineEnvironment.transform 11 804 env27959 = env27960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env27959 == env27960) = true)

theorem identity27960 : scanCanonicalize (H12AffineFastState.compose env27960 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound27960 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env27961 : List Nat := [2,4,8,16,32,17,9,256,512,305,529,804,8192,788,8461,8202,8713,821,304,8460,788,8493,48,3,8193,17,560,804,805,789,21,8461,257,32,789,545]

theorem envBound27961 : H12AffineFastState.Bounded env27961 := by
  intro p hp
  have h : env27961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27960_27961 : H12AffineEnvironment.transform 9 305 env27960 = env27961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env27960 == env27961) = true)

theorem identity27961 : scanCanonicalize (H12AffineFastState.compose env27961 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27961 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env27962 : List Nat := [2,4,8,16,1,17,9,256,512,272,529,773,8192,788,8461,8202,8713,788,273,8460,788,8460,17,3,8193,17,529,773,772,789,21,8461,257,1,789,512]

theorem envBound27962 : H12AffineFastState.Bounded env27962 := by
  intro p hp
  have h : env27962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27961_27962 : H12AffineEnvironment.transform 4 1 env27961 = env27962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27961 == env27962) = true)

theorem identity27962 : scanCanonicalize (H12AffineFastState.compose env27962 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27962 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27963 : List Nat := [2,4,8,16,1,17,9,256,512,272,529,773,268,788,1,262,773,788,273,0,788,0,17,3,269,17,529,773,772,789,21,1,257,1,789,512]

theorem envBound27963 : H12AffineFastState.Bounded env27963 := by
  intro p hp
  have h : env27963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27962_27963 : H12AffineEnvironment.transform 12 268 env27962 = env27963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27962 == env27963) = true)

theorem identity27963 : scanCanonicalize (H12AffineFastState.compose env27963 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 268) := by decide +kernel

theorem selectedBound27963 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27964 : List Nat := [2,4,8,16,1,17,9,256,268,272,285,9,268,24,1,262,9,24,273,0,24,0,17,3,269,17,285,9,8,25,21,1,257,1,25,268]

theorem envBound27964 : H12AffineFastState.Bounded env27964 := by
  intro p hp
  have h : env27964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27963_27964 : H12AffineEnvironment.transform 8 268 env27963 = env27964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 268 env27963 == env27964) = true)

theorem identity27964 : scanCanonicalize (H12AffineFastState.compose env27964 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27965 : List Nat := [2,4,8,1,1,0,9,256,268,257,268,9,268,9,1,262,9,9,256,0,9,0,0,3,269,0,268,9,8,8,4,1,257,1,8,268]

theorem envBound27965 : H12AffineFastState.Bounded env27965 := by
  intro p hp
  have h : env27965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27964_27965 : H12AffineEnvironment.transform 3 1 env27964 = env27965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27964 == env27965) = true)

theorem identity27965 : scanCanonicalize (H12AffineFastState.compose env27965 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound27965 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27966 : List Nat := [2,4,8,1,1,0,9,0,12,1,12,9,12,9,1,6,9,9,0,0,9,0,0,3,13,0,12,9,8,8,4,1,1,1,8,12]

theorem envBound27966 : H12AffineFastState.Bounded env27966 := by
  intro p hp
  have h : env27966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27965_27966 : H12AffineEnvironment.transform 7 0 env27965 = env27966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env27965 == env27966) = true)

theorem identity27966 : scanCanonicalize (H12AffineFastState.compose env27966 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27966 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27967 : List Nat := [2,4,3,1,1,0,2,0,7,1,7,2,7,2,1,6,2,2,0,0,2,0,0,3,6,0,7,2,3,3,4,1,1,1,3,7]

theorem envBound27967 : H12AffineFastState.Bounded env27967 := by
  intro p hp
  have h : env27967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27966_27967 : H12AffineEnvironment.transform 2 3 env27966 = env27967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27966 == env27967) = true)

theorem identity27967 : scanCanonicalize (H12AffineFastState.compose env27967 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27967 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27968 : List Nat := [2,3,3,1,1,0,2,0,0,1,0,2,0,2,1,1,2,2,0,0,2,0,0,3,1,0,0,2,3,3,3,1,1,1,3,0]

theorem envBound27968 : H12AffineFastState.Bounded env27968 := by
  intro p hp
  have h : env27968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27967_27968 : H12AffineEnvironment.transform 1 3 env27967 = env27968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27967 == env27968) = true)

theorem identity27968 : scanCanonicalize (H12AffineFastState.compose env27968 (packedSelected [12] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27968 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env27969 : List Nat := [0,1,1,1,1,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1,1,1,1,1,0]

theorem envBound27969 : H12AffineFastState.Bounded env27969 := by
  intro p hp
  have h : env27969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27968_27969 : H12AffineEnvironment.transform 0 0 env27968 = env27969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27968 == env27969) = true)

def env27970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2201879,2098512,17664,2437195,2102685,2411677,257,21793,46212,2175562]

theorem envBound27970 : H12AffineFastState.Bounded env27970 := by
  intro p hp
  have h : env27970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27943_27970 : H12AffineEnvironment.transform 21 272513 env27943 = env27970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env27943 == env27970) = true)

theorem identity27970 : scanCanonicalize (H12AffineFastState.compose env27970 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound27970 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env27971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,58516,272513,62661,98780,8328,64,97667,57796,17664,382175,61705,272393,257,21793,46212,120542]

theorem envBound27971 : H12AffineFastState.Bounded env27971 := by
  intro p hp
  have h : env27971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27970_27971 : H12AffineEnvironment.transform 20 58516 env27970 = env27971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env27970 == env27971) = true)

def env27972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,58516,169,62661,98780,8328,64,97667,57796,17664,130295,61705,33,257,21793,46212,120542]

theorem envBound27972 : H12AffineFastState.Bounded env27972 := by
  intro p hp
  have h : env27972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27971_27972 : H12AffineEnvironment.transform 17 10280 env27971 = env27972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env27971 == env27972) = true)

theorem identity27972 : scanCanonicalize (H12AffineFastState.compose env27972 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound27972 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env27973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,1095,58461,10280,1025,32769,58516,169,62661,34203,8328,64,31172,57796,17664,63664,61705,33,257,21793,46212,53913]

theorem envBound27973 : H12AffineFastState.Bounded env27973 := by
  intro p hp
  have h : env27973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27972_27973 : H12AffineEnvironment.transform 15 1095 env27972 = env27973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env27972 == env27973) = true)

theorem identity27973 : scanCanonicalize (H12AffineFastState.compose env27973 (packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound27973 : packedSelected [1,3,8,15,16,19,20,24,26,31,38] rootPS < 2^1333 := by decide +kernel

def env27974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12573,32768,1095,38208,10280,1025,32769,38281,169,34264,34203,8328,64,2265,37081,13341,35245,32788,33,257,9276,46212,41860]

theorem envBound27974 : H12AffineFastState.Bounded env27974 := by
  intro p hp
  have h : env27974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27973_27974 : H12AffineEnvironment.transform 13 12573 env27973 = env27974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env27973 == env27974) = true)

theorem identity27974 : scanCanonicalize (H12AffineFastState.compose env27974 (packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound27974 : packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env27975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,4452,32768,1095,38208,2129,1025,32769,38281,169,34264,34203,241,64,2265,37081,5220,35245,32788,33,257,1093,38141,33789]

theorem envBound27975 : H12AffineFastState.Bounded env27975 := by
  intro p hp
  have h : env27975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27974_27975 : H12AffineEnvironment.transform 12 121 env27974 = env27975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env27974 == env27975) = true)

theorem identity27975 : scanCanonicalize (H12AffineFastState.compose env27975 (packedSelected [3,4,5,9,10,11,12,14,15,17,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound27975 : packedSelected [3,4,5,9,10,11,12,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27976 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,121,4452,32768,398,37001,2129,456,32769,36928,169,32785,32850,241,64,2265,37081,4525,35245,32788,33,257,396,37172,33789]

theorem envBound27976 : H12AffineFastState.Bounded env27976 := by
  intro p hp
  have h : env27976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27975_27976 : H12AffineEnvironment.transform 9 457 env27975 = env27976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env27975 == env27976) = true)

theorem identity27976 : scanCanonicalize (H12AffineFastState.compose env27976 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound27976 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env27977 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,121,4452,508,398,4469,2129,456,509,4540,169,493,430,241,64,2265,4389,4525,2129,488,33,257,396,4296,513]

theorem envBound27977 : H12AffineFastState.Bounded env27977 := by
  intro p hp
  have h : env27977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27976_27977 : H12AffineEnvironment.transform 14 508 env27976 = env27977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env27976 == env27977) = true)

theorem identity27977 : scanCanonicalize (H12AffineFastState.compose env27977 (packedSelected [0,6,7,10,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound27977 : packedSelected [0,6,7,10,12,14] rootPS < 2^1333 := by decide +kernel

def env27978 : List Nat := [2,4,8,16,32,64,25,256,512,336,2048,4096,121,4452,357,279,4469,2129,337,356,4389,48,372,311,104,64,2112,4389,4404,2129,369,33,257,277,4177,513]

theorem envBound27978 : H12AffineFastState.Bounded env27978 := by
  intro p hp
  have h : env27978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27977_27978 : H12AffineEnvironment.transform 6 25 env27977 = env27978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env27977 == env27978) = true)

theorem identity27978 : scanCanonicalize (H12AffineFastState.compose env27978 (packedSelected [0,6,7,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound27978 : packedSelected [0,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env27979 : List Nat := [2,4,8,16,32,64,25,37,512,117,2048,4096,121,4161,64,50,4176,2129,116,65,4096,48,81,18,104,64,2112,4096,4113,2129,84,33,36,48,4177,513]

theorem envBound27979 : H12AffineFastState.Bounded env27979 := by
  intro p hp
  have h : env27979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27978_27979 : H12AffineEnvironment.transform 7 37 env27978 = env27979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env27978 == env27979) = true)

theorem identity27979 : scanCanonicalize (H12AffineFastState.compose env27979 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound27979 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27980 : List Nat := [2,4,8,16,32,0,25,37,512,53,2048,4096,57,4097,0,50,4112,2065,52,1,4096,48,17,18,40,0,2048,4096,4113,2065,20,33,36,48,4113,513]

theorem envBound27980 : H12AffineFastState.Bounded env27980 := by
  intro p hp
  have h : env27980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27979_27980 : H12AffineEnvironment.transform 5 0 env27979 = env27980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env27979 == env27980) = true)

theorem identity27980 : scanCanonicalize (H12AffineFastState.compose env27980 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27980 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27981 : List Nat := [2,4,8,16,17,0,25,20,512,4,2048,4096,8,4097,0,3,4112,2065,5,1,4096,1,17,18,25,0,2048,4096,4113,2065,20,16,21,1,4113,513]

theorem envBound27981 : H12AffineFastState.Bounded env27981 := by
  intro p hp
  have h : env27981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27980_27981 : H12AffineEnvironment.transform 4 17 env27980 = env27981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27980 == env27981) = true)

theorem identity27981 : scanCanonicalize (H12AffineFastState.compose env27981 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound27981 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27982 : List Nat := [2,4,8,16,17,0,25,20,512,4,538,4096,8,4097,0,3,4112,523,5,1,4096,1,17,18,25,0,538,4096,4113,523,20,16,21,1,4113,513]

theorem envBound27982 : H12AffineFastState.Bounded env27982 := by
  intro p hp
  have h : env27982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27981_27982 : H12AffineEnvironment.transform 10 538 env27981 = env27982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env27981 == env27982) = true)

theorem identity27982 : scanCanonicalize (H12AffineFastState.compose env27982 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound27982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27983 : List Nat := [2,4,8,16,17,0,25,20,3,4,25,4096,8,4097,0,3,4112,8,5,1,4096,1,17,18,25,0,25,4096,4113,8,20,16,21,1,4113,2]

theorem envBound27983 : H12AffineFastState.Bounded env27983 := by
  intro p hp
  have h : env27983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27982_27983 : H12AffineEnvironment.transform 8 3 env27982 = env27983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env27982 == env27983) = true)

theorem identity27983 : scanCanonicalize (H12AffineFastState.compose env27983 (packedSelected [0,5] rootPS)) = affineNative (2^(11+1) ^^^ 29) := by decide +kernel

theorem selectedBound27983 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env27984 : List Nat := [2,4,8,16,17,0,25,20,3,4,25,29,8,28,0,3,13,8,5,1,29,1,17,18,25,0,25,29,12,8,20,16,21,1,12,2]

theorem envBound27984 : H12AffineFastState.Bounded env27984 := by
  intro p hp
  have h : env27984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27983_27984 : H12AffineEnvironment.transform 11 29 env27983 = env27984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 29 env27983 == env27984) = true)

def env27985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,58516,168,62661,98780,8328,64,97667,57796,17664,130294,61705,32,257,21793,46212,120542]

theorem envBound27985 : H12AffineFastState.Bounded env27985 := by
  intro p hp
  have h : env27985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27971_27985 : H12AffineEnvironment.transform 17 10281 env27971 = env27985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env27971 == env27985) = true)

theorem identity27985 : scanCanonicalize (H12AffineFastState.compose env27985 (packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound27985 : packedSelected [1,3,8,10,11,16,17,18,20,23,24,32] rootPS < 2^1333 := by decide +kernel

def env27986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21897,65536,79251,10281,1025,21896,12573,168,8524,87125,8328,64,97667,13389,17664,76159,9344,32,257,21793,24845,66391]

theorem envBound27986 : H12AffineFastState.Bounded env27986 := by
  intro p hp
  have h : env27986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27985_27986 : H12AffineEnvironment.transform 14 21897 env27985 = env27986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env27985 == env27986) = true)

theorem identity27986 : scanCanonicalize (H12AffineFastState.compose env27986 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27986 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env27987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,79131,10281,1025,21760,12573,32,8524,87125,8192,64,97547,13389,17664,76159,9224,32,257,21793,24845,66391]

theorem envBound27987 : H12AffineFastState.Bounded env27987 := by
  intro p hp
  have h : env27987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27986_27987 : H12AffineEnvironment.transform 6 8 env27986 = env27987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27986 == env27987) = true)

theorem identity27987 : scanCanonicalize (H12AffineFastState.compose env27987 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound27987 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env27988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,342,13389,10281,1025,21760,12573,32,8524,21763,8192,64,31837,13389,17664,10281,9224,32,257,21793,24845,513]

theorem envBound27988 : H12AffineFastState.Bounded env27988 := by
  intro p hp
  have h : env27988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27987_27988 : H12AffineEnvironment.transform 15 342 env27987 = env27988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env27987 == env27988) = true)

theorem identity27988 : scanCanonicalize (H12AffineFastState.compose env27988 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound27988 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env27989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21761,342,5441,2341,1025,21760,4113,32,64,21763,268,64,23889,5441,17664,2341,1284,32,257,21793,16385,513]

theorem envBound27989 : H12AffineFastState.Bounded env27989 := by
  intro p hp
  have h : env27989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27988_27989 : H12AffineEnvironment.transform 12 268 env27988 = env27989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env27988 == env27989) = true)

theorem identity27989 : scanCanonicalize (H12AffineFastState.compose env27989 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound27989 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env27990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,1,342,5441,2341,1025,0,4113,32,64,3,268,64,2129,5441,4096,2341,1284,32,257,33,5377,513]

theorem envBound27990 : H12AffineFastState.Bounded env27990 := by
  intro p hp
  have h : env27990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27989_27990 : H12AffineEnvironment.transform 13 5376 env27989 = env27990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env27989 == env27990) = true)

theorem identity27990 : scanCanonicalize (H12AffineFastState.compose env27990 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27990 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env27991 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1025,0,4113,32,17,3,268,17,2048,5392,4096,2341,1284,32,257,33,5377,513]

theorem envBound27991 : H12AffineFastState.Bounded env27991 := by
  intro p hp
  have h : env27991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27990_27991 : H12AffineEnvironment.transform 5 17 env27990 = env27991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27990 == env27991) = true)

theorem identity27991 : scanCanonicalize (H12AffineFastState.compose env27991 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound27991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27992 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,260,268,1028,1,263,1044,2341,1025,0,277,32,17,3,268,17,2048,1044,260,2341,1284,32,257,33,1029,513]

theorem envBound27992 : H12AffineFastState.Bounded env27992 := by
  intro p hp
  have h : env27992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27991_27992 : H12AffineEnvironment.transform 11 260 env27991 = env27992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env27991 == env27992) = true)

theorem identity27992 : scanCanonicalize (H12AffineFastState.compose env27992 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound27992 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27993 : List Nat := [2,4,8,16,32,17,8,256,293,1024,2048,260,268,1028,1,263,1044,2341,1025,0,277,32,17,3,268,17,2048,1044,260,2341,1284,32,257,33,1029,292]

theorem envBound27993 : H12AffineFastState.Bounded env27993 := by
  intro p hp
  have h : env27993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27992_27993 : H12AffineEnvironment.transform 8 293 env27992 = env27993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env27992 == env27993) = true)

theorem identity27993 : scanCanonicalize (H12AffineFastState.compose env27993 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound27993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27994 : List Nat := [2,4,8,16,32,17,8,256,293,5,2048,260,268,1,1,263,17,2341,4,0,277,32,17,3,268,17,2048,17,260,2341,257,32,257,33,0,292]

theorem envBound27994 : H12AffineFastState.Bounded env27994 := by
  intro p hp
  have h : env27994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27993_27994 : H12AffineEnvironment.transform 9 5 env27993 = env27994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env27993 == env27994) = true)

theorem identity27994 : scanCanonicalize (H12AffineFastState.compose env27994 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound27994 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27995 : List Nat := [2,4,8,16,32,17,8,256,293,5,308,260,268,1,1,263,17,17,4,0,277,32,17,3,268,17,308,17,260,17,257,32,257,33,0,292]

theorem envBound27995 : H12AffineFastState.Bounded env27995 := by
  intro p hp
  have h : env27995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27994_27995 : H12AffineEnvironment.transform 10 308 env27994 = env27995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env27994 == env27995) = true)

theorem identity27995 : scanCanonicalize (H12AffineFastState.compose env27995 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27995 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27996 : List Nat := [2,4,8,16,0,17,8,256,261,5,276,260,268,1,1,263,17,17,4,0,277,0,17,3,268,17,276,17,260,17,257,0,257,1,0,260]

theorem envBound27996 : H12AffineFastState.Bounded env27996 := by
  intro p hp
  have h : env27996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27995_27996 : H12AffineEnvironment.transform 4 0 env27995 = env27996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27995 == env27996) = true)

theorem identity27996 : scanCanonicalize (H12AffineFastState.compose env27996 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27997 : List Nat := [2,4,8,16,0,17,8,20,17,5,0,16,24,1,1,19,17,17,4,0,1,0,17,3,24,17,0,17,16,17,21,0,21,1,0,16]

theorem envBound27997 : H12AffineFastState.Bounded env27997 := by
  intro p hp
  have h : env27997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27996_27997 : H12AffineEnvironment.transform 7 20 env27996 = env27997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27996 == env27997) = true)

theorem identity27997 : scanCanonicalize (H12AffineFastState.compose env27997 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27998 : List Nat := [2,4,3,16,0,17,3,20,17,5,0,16,19,1,1,19,17,17,4,0,1,0,17,3,19,17,0,17,16,17,21,0,21,1,0,16]

theorem envBound27998 : H12AffineFastState.Bounded env27998 := by
  intro p hp
  have h : env27998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27997_27998 : H12AffineEnvironment.transform 2 3 env27997 = env27998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27997 == env27998) = true)

theorem identity27998 : scanCanonicalize (H12AffineFastState.compose env27998 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27998 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env27999 : List Nat := [2,4,3,0,0,1,3,4,1,5,0,0,3,1,1,3,1,1,4,0,1,0,1,3,3,1,0,1,0,1,5,0,5,1,0,0]

theorem envBound27999 : H12AffineFastState.Bounded env27999 := by
  intro p hp
  have h : env27999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27998_27999 : H12AffineEnvironment.transform 3 0 env27998 = env27999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27998 == env27999) = true)

def env28000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound28000 : H12AffineFastState.Bounded env28000 := by
  intro p hp
  have h : env28000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27690_28000 : H12AffineEnvironment.transform 26 30393345 env27690 = env28000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env27690 == env28000) = true)

def env28001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound28001 : H12AffineFastState.Bounded env28001 := by
  intro p hp
  have h : env28001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28000_28001 : H12AffineEnvironment.transform 18 1024 env28000 = env28001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28000 == env28001) = true)

theorem identity28001 : scanCanonicalize (H12AffineFastState.compose env28001 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188635) := by decide +kernel

theorem selectedBound28001 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188635,16777216,8328,64,23504218,18973837,77834,2598235,18932043,23160257,256,16818679,16793682,18990749]

theorem envBound28002 : H12AffineFastState.Bounded env28002 := by
  intro p hp
  have h : env28002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28001_28002 : H12AffineEnvironment.transform 22 2188635 env28001 = env28002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188635 env28001 == env28002) = true)

def env28003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,16777216,8328,64,17227834,18973837,77834,2598235,18932043,16851105,256,16818679,16793682,18990749]

theorem envBound28003 : H12AffineFastState.Bounded env28003 := by
  intro p hp
  have h : env28003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28002_28003 : H12AffineEnvironment.transform 21 2114912 env28002 = env28003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env28002 == env28003) = true)

def env28004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175168,8328,64,2609402,46157,77834,2598235,119179,2101345,256,2199863,2191506,63069]

theorem envBound28004 : H12AffineFastState.Bounded env28004 := by
  intro p hp
  have h : env28004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28003_28004 : H12AffineEnvironment.transform 23 2175168 env28003 = env28004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env28003 == env28004) = true)

def env28005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73856,8328,64,508090,46157,77834,505115,119179,33,256,98679,90322,63069]

theorem envBound28005 : H12AffineFastState.Bounded env28005 := by
  intro p hp
  have h : env28005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28004_28005 : H12AffineEnvironment.transform 20 4160 env28004 = env28005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28004 == env28005) = true)

theorem identity28005 : scanCanonicalize (H12AffineFastState.compose env28005 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28005 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,21792,95515,73856,8328,64,472174,16537,77834,475599,75103,33,256,95651,90322,649]

theorem envBound28006 : H12AffineFastState.Bounded env28006 := by
  intro p hp
  have h : env28006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28005_28006 : H12AffineEnvironment.transform 14 29908 env28005 = env28006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28005 == env28006) = true)

def env28007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,21792,95515,73736,8192,64,472174,16401,77834,475463,75103,33,256,95531,90202,513]

theorem envBound28007 : H12AffineFastState.Bounded env28007 := by
  intro p hp
  have h : env28007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28006_28007 : H12AffineEnvironment.transform 6 8 env28006 = env28007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28006 == env28007) = true)

theorem identity28007 : scanCanonicalize (H12AffineFastState.compose env28007 (packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound28007 : packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env28008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,138293,1024,29789,4160,21792,95515,73736,8192,64,75867,16401,77834,89458,75103,33,256,95531,90202,513]

theorem envBound28008 : H12AffineFastState.Bounded env28008 := by
  intro p hp
  have h : env28008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28007_28008 : H12AffineEnvironment.transform 17 138293 env28007 = env28008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env28007 == env28008) = true)

theorem identity28008 : scanCanonicalize (H12AffineFastState.compose env28008 (packedSelected [0,2,4,6,7,9,14,16,18,20,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound28008 : packedSelected [0,2,4,6,7,9,14,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env28009 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13341,10280,1024,29789,4160,21792,95515,73736,8192,64,75867,16401,77834,89458,75103,33,256,95531,90202,513]

theorem envBound28009 : H12AffineFastState.Bounded env28009 := by
  intro p hp
  have h : env28009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28008_28009 : H12AffineEnvironment.transform 16 13341 env28008 = env28009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env28008 == env28009) = true)

theorem identity28009 : scanCanonicalize (H12AffineFastState.compose env28009 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 17478) := by decide +kernel

theorem selectedBound28009 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env28010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,17478,13341,10280,1024,29789,4160,21792,12637,25678,8192,64,27677,16401,29772,6452,24857,33,256,12653,9244,513]

theorem envBound28010 : H12AffineFastState.Bounded env28010 := by
  intro p hp
  have h : env28010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28009_28010 : H12AffineEnvironment.transform 15 17478 env28009 = env28010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17478 env28009 == env28010) = true)

theorem identity28010 : scanCanonicalize (H12AffineFastState.compose env28010 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound28010 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env28011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,8192,16384,24845,17478,8524,10280,1024,24844,1297,16497,9228,25678,8192,64,27677,16401,24861,3173,24857,33,256,9276,9244,513]

theorem envBound28011 : H12AffineFastState.Bounded env28011 := by
  intro p hp
  have h : env28011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28010_28011 : H12AffineEnvironment.transform 11 1361 env28010 = env28011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env28010 == env28011) = true)

theorem identity28011 : scanCanonicalize (H12AffineFastState.compose env28011 (packedSelected [1,2,6,8,10,11,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28011 : packedSelected [1,2,6,8,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env28012 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1140,8192,16384,24616,17478,8297,10280,1024,24617,1076,16497,9228,25678,8192,64,27677,16401,24632,3173,24636,33,37,9276,9244,513]

theorem envBound28012 : H12AffineFastState.Bounded env28012 := by
  intro p hp
  have h : env28012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28011_28012 : H12AffineEnvironment.transform 7 37 env28011 = env28012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28011 == env28012) = true)

theorem identity28012 : scanCanonicalize (H12AffineFastState.compose env28012 (packedSelected [0,2,4,6,7,9,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound28012 : packedSelected [0,2,4,6,7,9,11,20] rootPS < 2^1333 := by decide +kernel

def env28013 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1140,8192,16384,24616,17478,8297,8312,1024,24617,1076,16497,9228,25678,8192,64,25677,16401,24632,1077,24636,33,37,9276,9244,513]

theorem envBound28013 : H12AffineFastState.Bounded env28013 := by
  intro p hp
  have h : env28013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28012_28013 : H12AffineEnvironment.transform 10 80 env28012 = env28013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env28012 == env28013) = true)

theorem identity28013 : scanCanonicalize (H12AffineFastState.compose env28013 (packedSelected [3,5,11,12,19] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound28013 : packedSelected [3,5,11,12,19] rootPS < 2^1333 := by decide +kernel

def env28014 : List Nat := [2,4,8,16,32,64,8,37,512,1024,80,1140,8192,1125,9293,35,8297,8312,1024,9292,1076,1044,9228,8235,8192,64,8232,1140,9309,1077,9305,33,37,9276,9244,513]

theorem envBound28014 : H12AffineFastState.Bounded env28014 := by
  intro p hp
  have h : env28014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28013_28014 : H12AffineEnvironment.transform 13 1125 env28013 = env28014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env28013 == env28014) = true)

theorem identity28014 : scanCanonicalize (H12AffineFastState.compose env28014 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28014 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28015 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,8192,81,8313,35,8297,8312,52,8312,0,32,8248,8235,8192,64,8232,64,8297,1,8301,33,37,8200,8232,513]

theorem envBound28015 : H12AffineFastState.Bounded env28015 := by
  intro p hp
  have h : env28015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28014_28015 : H12AffineEnvironment.transform 9 52 env28014 = env28015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28014 == env28015) = true)

theorem identity28015 : scanCanonicalize (H12AffineFastState.compose env28015 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28015 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28016 : List Nat := [2,4,8,16,32,64,8,37,512,52,80,64,41,81,80,35,64,81,52,81,0,32,17,2,41,64,1,64,64,1,68,33,37,33,1,513]

theorem envBound28016 : H12AffineFastState.Bounded env28016 := by
  intro p hp
  have h : env28016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28015_28016 : H12AffineEnvironment.transform 12 41 env28015 = env28016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28015 == env28016) = true)

theorem identity28016 : scanCanonicalize (H12AffineFastState.compose env28016 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28017 : List Nat := [2,4,8,16,32,48,8,37,512,52,32,48,41,33,32,35,48,33,52,33,0,32,17,2,41,48,1,48,48,1,52,33,37,33,1,513]

theorem envBound28017 : H12AffineFastState.Bounded env28017 := by
  intro p hp
  have h : env28017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28016_28017 : H12AffineEnvironment.transform 5 48 env28016 = env28017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28016 == env28017) = true)

theorem identity28017 : scanCanonicalize (H12AffineFastState.compose env28017 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28017 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28018 : List Nat := [2,4,8,16,32,48,8,37,1,52,32,48,41,33,32,35,48,33,52,33,0,32,17,2,41,48,1,48,48,1,52,33,37,33,1,0]

theorem envBound28018 : H12AffineFastState.Bounded env28018 := by
  intro p hp
  have h : env28018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28017_28018 : H12AffineEnvironment.transform 8 1 env28017 = env28018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28017 == env28018) = true)

theorem identity28018 : scanCanonicalize (H12AffineFastState.compose env28018 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28019 : List Nat := [2,4,8,16,1,17,8,4,1,21,1,17,8,0,1,2,17,0,21,0,0,1,17,2,8,17,1,17,17,1,21,0,4,0,1,0]

theorem envBound28019 : H12AffineFastState.Bounded env28019 := by
  intro p hp
  have h : env28019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28018_28019 : H12AffineEnvironment.transform 4 1 env28018 = env28019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28018 == env28019) = true)

theorem identity28019 : scanCanonicalize (H12AffineFastState.compose env28019 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28019 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28020 : List Nat := [2,4,8,10,1,11,8,4,1,15,1,11,8,0,1,2,11,0,15,0,0,1,11,2,8,11,1,11,11,1,15,0,4,0,1,0]

theorem envBound28020 : H12AffineFastState.Bounded env28020 := by
  intro p hp
  have h : env28020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28019_28020 : H12AffineEnvironment.transform 3 10 env28019 = env28020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28019 == env28020) = true)

theorem identity28020 : scanCanonicalize (H12AffineFastState.compose env28020 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28020 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28021 : List Nat := [2,4,3,1,1,0,3,4,1,4,1,0,3,0,1,2,0,0,4,0,0,1,0,2,3,0,1,0,0,1,4,0,4,0,1,0]

theorem envBound28021 : H12AffineFastState.Bounded env28021 := by
  intro p hp
  have h : env28021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28020_28021 : H12AffineEnvironment.transform 2 3 env28020 = env28021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28020 == env28021) = true)

def env28022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,21792,95515,73737,8193,64,472174,16400,77834,475462,75103,33,256,95530,90203,512]

theorem envBound28022 : H12AffineFastState.Bounded env28022 := by
  intro p hp
  have h : env28022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28006_28022 : H12AffineEnvironment.transform 6 9 env28006 = env28022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28006 == env28022) = true)

theorem identity28022 : scanCanonicalize (H12AffineFastState.compose env28022 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound28022 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env28023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,4160,21792,17,21763,8193,64,409956,16400,17664,406604,20565,33,256,32,5457,512]

theorem envBound28023 : H12AffineFastState.Bounded env28023 := by
  intro p hp
  have h : env28023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28022_28023 : H12AffineEnvironment.transform 15 29962 env28022 = env28023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env28022 == env28023) = true)

theorem identity28023 : scanCanonicalize (H12AffineFastState.compose env28023 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound28023 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,10588,1024,29788,4160,21792,17,21763,8193,64,157752,16400,17664,138512,20565,33,256,32,5457,512]

theorem envBound28024 : H12AffineFastState.Bounded env28024 := by
  intro p hp
  have h : env28024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28023_28024 : H12AffineEnvironment.transform 17 10588 env28023 = env28024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env28023 == env28024) = true)

theorem identity28024 : scanCanonicalize (H12AffineFastState.compose env28024 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 24648) := by decide +kernel

theorem selectedBound28024 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env28025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,24648,10588,1024,29788,4160,21792,17,21763,8193,64,2160,16400,17664,32088,20565,33,256,32,5457,512]

theorem envBound28025 : H12AffineFastState.Bounded env28025 := by
  intro p hp
  have h : env28025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28024_28025 : H12AffineEnvironment.transform 16 24648 env28024 = env28025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24648 env28024 == env28025) = true)

theorem identity28025 : scanCanonicalize (H12AffineFastState.compose env28025 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound28025 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8232,8575,13373,10588,1024,8233,4160,341,17,374,8193,64,2160,5221,4469,10541,1056,33,256,32,5457,512]

theorem envBound28026 : H12AffineFastState.Bounded env28026 := by
  intro p hp
  have h : env28026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28025_28026 : H12AffineEnvironment.transform 13 5237 env28025 = env28026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env28025 == env28026) = true)

theorem identity28026 : scanCanonicalize (H12AffineFastState.compose env28026 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28026 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env28027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,1,342,5140,2421,1024,0,4160,341,17,374,40,64,2160,5221,4469,2308,1056,33,256,32,5457,512]

theorem envBound28027 : H12AffineFastState.Bounded env28027 := by
  intro p hp
  have h : env28027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28026_28027 : H12AffineEnvironment.transform 12 41 env28026 = env28027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28026 == env28027) = true)

def env28028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73857,8328,64,508091,46157,77834,505114,119179,32,256,98678,90323,63069]

theorem envBound28028 : H12AffineFastState.Bounded env28028 := by
  intro p hp
  have h : env28028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28004_28028 : H12AffineEnvironment.transform 20 4161 env28004 = env28028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28004 == env28028) = true)

theorem identity28028 : scanCanonicalize (H12AffineFastState.compose env28028 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28028 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,4161,21793,95514,73857,8328,64,483814,5392,77834,463943,94422,32,256,73771,90323,22272]

theorem envBound28029 : H12AffineFastState.Bounded env28029 := by
  intro p hp
  have h : env28029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28028_28029 : H12AffineEnvironment.transform 14 8541 env28028 = env28029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28028 == env28029) = true)

theorem identity28029 : scanCanonicalize (H12AffineFastState.compose env28029 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28029 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4161,32,73755,73857,8328,64,472295,5392,77834,463943,75223,32,256,73771,79314,513]

theorem envBound28030 : H12AffineFastState.Bounded env28030 := by
  intro p hp
  have h : env28030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28029_28030 : H12AffineEnvironment.transform 13 5377 env28029 = env28030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28029 == env28030) = true)

theorem identity28030 : scanCanonicalize (H12AffineFastState.compose env28030 (packedSelected [0,2,4,6,11,14,15,16,21,22,27,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 204218) := by decide +kernel

theorem selectedBound28030 : packedSelected [0,2,4,6,11,14,15,16,21,22,27,32,38] rootPS < 2^1333 := by decide +kernel

def env28031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,204218,1024,8540,4161,32,73755,73857,8328,64,10589,5392,77834,2557,75223,32,256,73771,79314,513]

theorem envBound28031 : H12AffineFastState.Bounded env28031 := by
  intro p hp
  have h : env28031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28030_28031 : H12AffineEnvironment.transform 17 204218 env28030 = env28031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204218 env28030 == env28031) = true)

theorem identity28031 : scanCanonicalize (H12AffineFastState.compose env28031 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28031 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env28032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146865,1024,8540,4161,32,16,138,8328,64,10589,5392,4097,2557,1500,32,256,32,5593,513]

theorem envBound28032 : H12AffineFastState.Bounded env28032 := by
  intro p hp
  have h : env28032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28031_28032 : H12AffineEnvironment.transform 15 8203 env28031 = env28032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28031 == env28032) = true)

theorem identity28032 : scanCanonicalize (H12AffineFastState.compose env28032 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28032 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28033 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8461,8203,131072,146865,1024,8460,4113,32,16,138,8328,16,10509,5392,4097,2477,1420,32,256,32,5513,513]

theorem envBound28033 : H12AffineFastState.Bounded env28033 := by
  intro p hp
  have h : env28033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28032_28033 : H12AffineEnvironment.transform 5 16 env28032 = env28033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28032 == env28033) = true)

theorem identity28033 : scanCanonicalize (H12AffineFastState.compose env28033 (packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound28033 : packedSelected [1,4,5,8,9,14,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28034 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5377,137,399,131072,138293,1024,136,4113,32,16,138,268,16,2185,5392,4097,2477,1420,32,256,32,5513,513]

theorem envBound28034 : H12AffineFastState.Bounded env28034 := by
  intro p hp
  have h : env28034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28033_28034 : H12AffineEnvironment.transform 12 388 env28033 = env28034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env28033 == env28034) = true)

theorem identity28034 : scanCanonicalize (H12AffineFastState.compose env28034 (packedSelected [0,2,3,5,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound28034 : packedSelected [0,2,3,5,7,11,14] rootPS < 2^1333 := by decide +kernel

def env28035 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3328,388,2049,137,399,131072,131381,1024,136,3345,32,16,138,268,16,2185,2064,3329,2477,1420,32,256,32,2185,513]

theorem envBound28035 : H12AffineFastState.Bounded env28035 := by
  intro p hp
  have h : env28035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28034_28035 : H12AffineEnvironment.transform 11 3328 env28034 = env28035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env28034 == env28035) = true)

theorem identity28035 : scanCanonicalize (H12AffineFastState.compose env28035 (packedSelected [2,4,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 1281) := by decide +kernel

theorem selectedBound28035 : packedSelected [2,4,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28036 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3328,388,2049,137,399,1281,1076,1024,136,3345,32,16,138,268,16,2185,2064,3329,2477,1420,32,256,32,2185,513]

theorem envBound28036 : H12AffineFastState.Bounded env28036 := by
  intro p hp
  have h : env28036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28035_28036 : H12AffineEnvironment.transform 16 1281 env28035 = env28036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1281 env28035 == env28036) = true)

theorem identity28036 : scanCanonicalize (H12AffineFastState.compose env28036 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound28036 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env28037 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,2493,388,2049,137,399,444,137,189,136,2476,32,16,138,268,16,2185,2064,2492,2477,305,32,256,32,2185,513]

theorem envBound28037 : H12AffineFastState.Bounded env28037 := by
  intro p hp
  have h : env28037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28036_28037 : H12AffineEnvironment.transform 9 189 env28036 = env28037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env28036 == env28037) = true)

theorem identity28037 : scanCanonicalize (H12AffineFastState.compose env28037 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28037 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28038 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,2356,269,2049,0,262,309,0,52,1,2341,32,16,3,268,16,2048,2064,2357,2340,305,32,256,32,2048,513]

theorem envBound28038 : H12AffineFastState.Bounded env28038 := by
  intro p hp
  have h : env28038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28037_28038 : H12AffineEnvironment.transform 6 9 env28037 = env28038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28037 == env28038) = true)

theorem identity28038 : scanCanonicalize (H12AffineFastState.compose env28038 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound28038 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env28039 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,309,269,0,0,262,309,0,52,1,292,32,16,3,268,16,1,17,308,293,305,32,256,32,1,513]

theorem envBound28039 : H12AffineFastState.Bounded env28039 := by
  intro p hp
  have h : env28039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28038_28039 : H12AffineEnvironment.transform 10 1 env28038 = env28039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env28038 == env28039) = true)

theorem identity28039 : scanCanonicalize (H12AffineFastState.compose env28039 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28039 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28040 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,41,0,0,34,17,0,52,1,0,32,16,3,40,16,1,17,16,1,21,32,36,32,1,513]

theorem envBound28040 : H12AffineFastState.Bounded env28040 := by
  intro p hp
  have h : env28040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28039_28040 : H12AffineEnvironment.transform 7 36 env28039 = env28040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28039 == env28040) = true)

theorem identity28040 : scanCanonicalize (H12AffineFastState.compose env28040 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound28040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28041 : List Nat := [2,4,8,16,21,16,9,17,512,1,1,17,28,0,0,23,17,0,1,1,0,21,16,3,29,16,1,17,16,1,21,21,17,21,1,513]

theorem envBound28041 : H12AffineFastState.Bounded env28041 := by
  intro p hp
  have h : env28041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28040_28041 : H12AffineEnvironment.transform 4 21 env28040 = env28041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env28040 == env28041) = true)

theorem identity28041 : scanCanonicalize (H12AffineFastState.compose env28041 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound28041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28042 : List Nat := [2,4,8,16,21,16,9,17,8,1,1,17,28,0,0,23,17,0,1,1,0,21,16,3,29,16,1,17,16,1,21,21,17,21,1,9]

theorem envBound28042 : H12AffineFastState.Bounded env28042 := by
  intro p hp
  have h : env28042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28041_28042 : H12AffineEnvironment.transform 8 8 env28041 = env28042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env28041 == env28042) = true)

theorem identity28042 : scanCanonicalize (H12AffineFastState.compose env28042 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28043 : List Nat := [2,0,8,16,17,16,9,17,8,1,1,17,24,0,0,19,17,0,1,1,0,17,16,3,25,16,1,17,16,1,17,17,17,17,1,9]

theorem envBound28043 : H12AffineFastState.Bounded env28043 := by
  intro p hp
  have h : env28043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28042_28043 : H12AffineEnvironment.transform 1 0 env28042 = env28043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28042 == env28043) = true)

theorem identity28043 : scanCanonicalize (H12AffineFastState.compose env28043 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28043 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28044 : List Nat := [2,0,3,16,17,16,2,17,3,1,1,17,19,0,0,19,17,0,1,1,0,17,16,3,18,16,1,17,16,1,17,17,17,17,1,2]

theorem envBound28044 : H12AffineFastState.Bounded env28044 := by
  intro p hp
  have h : env28044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28043_28044 : H12AffineEnvironment.transform 2 3 env28043 = env28044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28043 == env28044) = true)

theorem identity28044 : scanCanonicalize (H12AffineFastState.compose env28044 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound28044 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28045 : List Nat := [2,0,3,2,3,2,2,3,3,1,1,3,1,0,0,1,3,0,1,1,0,3,2,3,0,2,1,3,2,1,3,3,3,3,1,2]

theorem envBound28045 : H12AffineFastState.Bounded env28045 := by
  intro p hp
  have h : env28045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28044_28045 : H12AffineEnvironment.transform 3 2 env28044 = env28045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env28044 == env28045) = true)

theorem identity28045 : scanCanonicalize (H12AffineFastState.compose env28045 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28045 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env28046 : List Nat := [1,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,0,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,0,0,1,1]

theorem envBound28046 : H12AffineFastState.Bounded env28046 := by
  intro p hp
  have h : env28046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28045_28046 : H12AffineEnvironment.transform 0 1 env28045 = env28046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28045 == env28046) = true)

def env28047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175169,8328,64,2609403,46156,77834,2598235,119178,2101344,256,2199862,2191507,63068]

theorem envBound28047 : H12AffineFastState.Bounded env28047 := by
  intro p hp
  have h : env28047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28003_28047 : H12AffineEnvironment.transform 23 2175169 env28003 = env28047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175169 env28003 == env28047) = true)

def env28048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73857,8328,64,508091,46156,77834,505115,119178,32,256,98678,90323,63068]

theorem envBound28048 : H12AffineFastState.Bounded env28048 := by
  intro p hp
  have h : env28048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28047_28048 : H12AffineEnvironment.transform 20 4160 env28047 = env28048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28047 == env28048) = true)

theorem identity28048 : scanCanonicalize (H12AffineFastState.compose env28048 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28048 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73857,8328,64,497083,46156,77834,505115,99466,32,256,98678,79315,41820]

theorem envBound28049 : H12AffineFastState.Bounded env28049 := by
  intro p hp
  have h : env28049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28048_28049 : H12AffineEnvironment.transform 13 5376 env28048 = env28049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28048 == env28049) = true)

def env28050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73737,8192,64,496947,46156,77834,505115,99330,32,256,98678,79195,41820]

theorem envBound28050 : H12AffineFastState.Bounded env28050 := by
  intro p hp
  have h : env28050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28049_28050 : H12AffineEnvironment.transform 6 8 env28049 = env28050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28049 == env28050) = true)

theorem identity28050 : scanCanonicalize (H12AffineFastState.compose env28050 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28050 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env28051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,32,73755,73737,8192,64,472174,5393,77834,463942,75103,32,256,73771,79195,513]

theorem envBound28051 : H12AffineFastState.Bounded env28051 := by
  intro p hp
  have h : env28051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28050_28051 : H12AffineEnvironment.transform 14 8541 env28050 = env28051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28050 == env28051) = true)

theorem identity28051 : scanCanonicalize (H12AffineFastState.compose env28051 (packedSelected [0,4,7,9,14,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28051 : packedSelected [0,4,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env28052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,32,16,2,8192,64,398437,5393,4097,406605,1364,32,256,32,5456,513]

theorem envBound28052 : H12AffineFastState.Bounded env28052 := by
  intro p hp
  have h : env28052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28051_28052 : H12AffineEnvironment.transform 15 8203 env28051 = env28052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28051 == env28052) = true)

theorem identity28052 : scanCanonicalize (H12AffineFastState.compose env28052 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound28052 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146792,1024,8540,4160,32,16,2,8192,64,10509,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound28053 : H12AffineFastState.Bounded env28053 := by
  intro p hp
  have h : env28053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28052_28053 : H12AffineEnvironment.transform 17 146792 env28052 = env28053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env28052 == env28053) = true)

theorem identity28053 : scanCanonicalize (H12AffineFastState.compose env28053 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28053 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28054 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5392,10360,1024,8540,4160,32,16,2,8192,64,10509,5393,4097,2341,1364,32,256,32,5456,513]

theorem envBound28054 : H12AffineFastState.Bounded env28054 := by
  intro p hp
  have h : env28054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28053_28054 : H12AffineEnvironment.transform 16 5392 env28053 = env28054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28053 == env28054) = true)

theorem identity28054 : scanCanonicalize (H12AffineFastState.compose env28054 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28054 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env28055 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,8232,8203,5221,10360,1024,8233,4160,32,16,2,8192,64,10360,5220,4097,2128,1057,32,117,32,5157,513]

theorem envBound28055 : H12AffineFastState.Bounded env28055 := by
  intro p hp
  have h : env28055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28054_28055 : H12AffineEnvironment.transform 7 117 env28054 = env28055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28054 == env28055) = true)

theorem identity28055 : scanCanonicalize (H12AffineFastState.compose env28055 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28055 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28056 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,5156,8232,8203,5172,10281,1024,8233,4113,32,16,2,8192,17,10281,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound28056 : H12AffineFastState.Bounded env28056 := by
  intro p hp
  have h : env28056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28055_28056 : H12AffineEnvironment.transform 5 17 env28055 = env28056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28055 == env28056) = true)

theorem identity28056 : scanCanonicalize (H12AffineFastState.compose env28056 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound28056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28057 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8,5156,32,3,5172,2081,1024,33,4113,32,16,2,8,17,2081,5173,4097,2049,1057,32,36,32,5157,513]

theorem envBound28057 : H12AffineFastState.Bounded env28057 := by
  intro p hp
  have h : env28057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28056_28057 : H12AffineEnvironment.transform 12 8 env28056 = env28057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env28056 == env28057) = true)

theorem identity28057 : scanCanonicalize (H12AffineFastState.compose env28057 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound28057 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28058 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1045,4096,8,5156,32,3,5172,1076,1024,33,4113,32,16,2,8,17,1076,5173,4097,1044,1057,32,36,32,5157,513]

theorem envBound28058 : H12AffineFastState.Bounded env28058 := by
  intro p hp
  have h : env28058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28057_28058 : H12AffineEnvironment.transform 10 1045 env28057 = env28058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env28057 == env28058) = true)

theorem identity28058 : scanCanonicalize (H12AffineFastState.compose env28058 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28058 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28059 : List Nat := [2,4,8,16,32,17,8,36,0,1024,1045,4096,8,5156,32,3,5172,1076,1024,33,4113,32,16,2,8,17,1076,5173,4097,1044,1057,32,36,32,5157,1]

theorem envBound28059 : H12AffineFastState.Bounded env28059 := by
  intro p hp
  have h : env28059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28058_28059 : H12AffineEnvironment.transform 8 0 env28058 = env28059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28058 == env28059) = true)

def env28060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73755,73736,8193,64,496946,46156,77834,505115,99331,32,256,98678,79194,41820]

theorem envBound28060 : H12AffineFastState.Bounded env28060 := by
  intro p hp
  have h : env28060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28049_28060 : H12AffineEnvironment.transform 6 9 env28049 = env28060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28049 == env28060) = true)

theorem identity28060 : scanCanonicalize (H12AffineFastState.compose env28060 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound28060 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env28061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,262144,1024,32769,4160,32,73755,73736,8193,64,262516,46156,77834,270685,99331,32,256,98678,79194,41820]

theorem envBound28061 : H12AffineFastState.Bounded env28061 := by
  intro p hp
  have h : env28061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28060_28061 : H12AffineEnvironment.transform 16 103494 env28060 = env28061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env28060 == env28061) = true)

theorem identity28061 : scanCanonicalize (H12AffineFastState.compose env28061 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound28061 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env28062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,103494,67618,1024,32769,4160,32,73755,73736,8193,64,67926,46156,77834,76159,99331,32,256,98678,79194,41820]

theorem envBound28062 : H12AffineFastState.Bounded env28062 := by
  intro p hp
  have h : env28062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28061_28062 : H12AffineEnvironment.transform 17 67618 env28061 = env28062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env28061 == env28062) = true)

theorem identity28062 : scanCanonicalize (H12AffineFastState.compose env28062 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound28062 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env28063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,32802,5220,34816,1024,32769,4160,32,41017,41002,8193,64,35188,46156,45096,43357,1057,32,256,340,46456,41820]

theorem envBound28063 : H12AffineFastState.Bounded env28063 := by
  intro p hp
  have h : env28063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28062_28063 : H12AffineEnvironment.transform 15 32802 env28062 = env28063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env28062 == env28063) = true)

theorem identity28063 : scanCanonicalize (H12AffineFastState.compose env28063 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound28063 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env28064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8233,8203,5220,10281,1024,8232,4160,32,16,3,8193,64,10589,5221,4097,2420,1057,32,256,340,5457,885]

theorem envBound28064 : H12AffineFastState.Bounded env28064 := by
  intro p hp
  have h : env28064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28063_28064 : H12AffineEnvironment.transform 14 8233 env28063 = env28064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env28063 == env28064) = true)

theorem identity28064 : scanCanonicalize (H12AffineFastState.compose env28064 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28064 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,292,262,5220,2340,1024,293,4160,32,16,3,268,64,2128,5221,4097,2420,1057,32,256,340,5457,885]

theorem envBound28065 : H12AffineFastState.Bounded env28065 := by
  intro p hp
  have h : env28065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28064_28065 : H12AffineEnvironment.transform 12 269 env28064 = env28065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28064 == env28065) = true)

theorem identity28065 : scanCanonicalize (H12AffineFastState.compose env28065 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28065 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env28066 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,115,5220,2129,1024,80,4160,32,16,3,121,64,2128,5221,4097,2049,1057,32,117,33,5156,512]

theorem envBound28066 : H12AffineFastState.Bounded env28066 := by
  intro p hp
  have h : env28066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28065_28066 : H12AffineEnvironment.transform 7 117 env28065 = env28066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28065 == env28066) = true)

theorem identity28066 : scanCanonicalize (H12AffineFastState.compose env28066 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28066 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env28067 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8,5125,33,3,5140,2081,1024,32,4144,32,16,3,9,48,2080,5141,4097,2049,1057,32,5,33,5156,512]

theorem envBound28067 : H12AffineFastState.Bounded env28067 := by
  intro p hp
  have h : env28067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28066_28067 : H12AffineEnvironment.transform 5 48 env28066 = env28067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28066 == env28067) = true)

theorem identity28067 : scanCanonicalize (H12AffineFastState.compose env28067 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28067 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env28068 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,0,3,5140,2048,1024,1,4113,1,16,3,9,17,2049,5141,4097,2049,1024,1,5,0,5125,512]

theorem envBound28068 : H12AffineFastState.Bounded env28068 := by
  intro p hp
  have h : env28068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28067_28068 : H12AffineEnvironment.transform 4 1 env28067 = env28068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28067 == env28068) = true)

def env28069 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,0,3,1028,2048,1024,1,1,1,16,3,9,17,2049,1029,17,2049,1024,1,5,0,1045,512]

theorem envBound28069 : H12AffineFastState.Bounded env28069 := by
  intro p hp
  have h : env28069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28068_28069 : H12AffineEnvironment.transform 11 16 env28068 = env28069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env28068 == env28069) = true)

theorem identity28069 : scanCanonicalize (H12AffineFastState.compose env28069 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound28069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28070 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,16,8,0,0,3,17,2048,21,1,1,1,16,3,9,17,2049,16,17,2049,21,1,5,0,0,512]

theorem envBound28070 : H12AffineFastState.Bounded env28070 := by
  intro p hp
  have h : env28070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28069_28070 : H12AffineEnvironment.transform 9 21 env28069 = env28070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env28069 == env28070) = true)

theorem identity28070 : scanCanonicalize (H12AffineFastState.compose env28070 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound28070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28071 : List Nat := [2,4,8,16,1,17,9,5,30,21,2048,16,8,0,0,3,17,2048,21,1,1,1,16,3,9,17,2049,16,17,2049,21,1,5,0,0,30]

theorem envBound28071 : H12AffineFastState.Bounded env28071 := by
  intro p hp
  have h : env28071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28070_28071 : H12AffineEnvironment.transform 8 30 env28070 = env28071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env28070 == env28071) = true)

def leafEnv28071 : List Nat := [2,4,8,16,1,17,9,5,30,21,2048,16,8,0,0,3,17,2048,21,1,1,1,16,3,21,9,1,17,2049,16,17,2049,21,1,5,0,4,2,0,30,1,1,0]

def active28071 : List Nat := [0,1,2,3,10]

def tree28071 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28071 : H12WitnessSearch.Good tree28071 := H12GlobalWitnessIndex.good

theorem leafIdentity28071 : H12AffineFastState.composeSystem env28071 rootObs = leafEnv28071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28071 rootObs == leafEnv28071) = true)

theorem terminalChecked28071 : H12PackedTerminal.terminalCheckFast leafEnv28071 active28071 tree28071 = true := by decide +kernel

def env28072 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,8,1044,0,3,1029,2048,1024,1,0,1,16,3,9,17,2049,1028,16,2049,1024,1,5,0,1044,512]

theorem envBound28072 : H12AffineFastState.Bounded env28072 := by
  intro p hp
  have h : env28072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28068_28072 : H12AffineEnvironment.transform 11 17 env28068 = env28072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28068 == env28072) = true)

def env28073 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,0,3,17,2048,20,1,0,1,16,3,9,17,2049,16,16,2049,20,1,5,0,0,512]

theorem envBound28073 : H12AffineFastState.Bounded env28073 := by
  intro p hp
  have h : env28073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28072_28073 : H12AffineEnvironment.transform 9 20 env28072 = env28073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env28072 == env28073) = true)

theorem identity28073 : scanCanonicalize (H12AffineFastState.compose env28073 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound28073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28074 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,4,8,0,0,3,4,2048,1,1,0,1,5,3,9,4,2049,5,5,2049,1,1,5,0,0,512]

theorem envBound28074 : H12AffineFastState.Bounded env28074 := by
  intro p hp
  have h : env28074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28073_28074 : H12AffineEnvironment.transform 3 5 env28073 = env28074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env28073 == env28074) = true)

def leafEnv28074 : List Nat := [2,4,8,5,1,4,9,5,512,1,2048,4,8,0,0,3,4,2048,1,1,0,1,5,3,1,9,1,4,2049,5,5,2049,1,1,5,0,4,2,0,512,1,0,0]

def active28074 : List Nat := [0,1,2,8,10]

def tree28074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28074 : H12WitnessSearch.Good tree28074 := H12GlobalWitnessIndex.good

theorem leafIdentity28074 : H12AffineFastState.composeSystem env28074 rootObs = leafEnv28074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28074 rootObs == leafEnv28074) = true)

theorem terminalChecked28074 : H12PackedTerminal.terminalCheckFast leafEnv28074 active28074 tree28074 = true := by decide +kernel

def env28075 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,17,8,1,0,3,16,2048,21,1,0,1,16,3,9,17,2049,17,16,2049,21,1,5,0,1,512]

theorem envBound28075 : H12AffineFastState.Bounded env28075 := by
  intro p hp
  have h : env28075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28072_28075 : H12AffineEnvironment.transform 9 21 env28072 = env28075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env28072 == env28075) = true)

theorem identity28075 : scanCanonicalize (H12AffineFastState.compose env28075 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound28075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28076 : List Nat := [2,4,8,16,1,17,9,5,31,21,2048,17,8,1,0,3,16,2048,21,1,0,1,16,3,9,17,2049,17,16,2049,21,1,5,0,1,31]

theorem envBound28076 : H12AffineFastState.Bounded env28076 := by
  intro p hp
  have h : env28076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28075_28076 : H12AffineEnvironment.transform 8 31 env28075 = env28076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env28075 == env28076) = true)

def leafEnv28076 : List Nat := [2,4,8,16,1,17,9,5,31,21,2048,17,8,1,0,3,16,2048,21,1,0,1,16,3,21,9,1,17,2049,17,16,2049,21,1,5,0,4,2,1,31,1,0,0]

def active28076 : List Nat := [0,1,2,3,10]

def tree28076 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood28076 : H12WitnessSearch.Good tree28076 := H12GlobalWitnessIndex.good

theorem leafIdentity28076 : H12AffineFastState.composeSystem env28076 rootObs = leafEnv28076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env28076 rootObs == leafEnv28076) = true)

theorem terminalChecked28076 : H12PackedTerminal.terminalCheckFast leafEnv28076 active28076 tree28076 = true := by decide +kernel

def env28077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73856,8328,64,508090,46156,77834,505114,119178,33,256,98679,90322,63068]

theorem envBound28077 : H12AffineFastState.Bounded env28077 := by
  intro p hp
  have h : env28077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28047_28077 : H12AffineEnvironment.transform 20 4161 env28047 = env28077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28047 == env28077) = true)

theorem identity28077 : scanCanonicalize (H12AffineFastState.compose env28077 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28077 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73736,8192,64,507954,46156,77834,505114,119042,33,256,98679,90202,63068]

theorem envBound28078 : H12AffineFastState.Bounded env28078 := by
  intro p hp
  have h : env28078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28077_28078 : H12AffineEnvironment.transform 6 8 env28077 = env28078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28077 == env28078) = true)

theorem identity28078 : scanCanonicalize (H12AffineFastState.compose env28078 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound28078 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env28079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,21793,95514,73736,8192,64,256027,46156,77834,236851,119042,33,256,98679,90202,63068]

theorem envBound28079 : H12AffineFastState.Bounded env28079 := by
  intro p hp
  have h : env28079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28078_28079 : H12AffineEnvironment.transform 17 10281 env28078 = env28079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28078 == env28079) = true)

theorem identity28079 : scanCanonicalize (H12AffineFastState.compose env28079 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound28079 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,10281,1024,29788,4161,21793,95514,73736,8192,64,203846,16401,77834,223598,75103,33,256,95530,90202,513]

theorem envBound28080 : H12AffineFastState.Bounded env28080 := by
  intro p hp
  have h : env28080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28079_28080 : H12AffineEnvironment.transform 14 29789 env28079 = env28080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env28079 == env28080) = true)

theorem identity28080 : scanCanonicalize (H12AffineFastState.compose env28080 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound28080 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env28081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8283,131072,10281,1024,29788,4161,21793,21825,83,8192,64,146461,16401,4177,149813,1284,33,256,21873,16385,513]

theorem envBound28081 : H12AffineFastState.Bounded env28081 := by
  intro p hp
  have h : env28081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28080_28081 : H12AffineEnvironment.transform 15 8283 env28080 = env28081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env28080 == env28081) = true)

theorem identity28081 : scanCanonicalize (H12AffineFastState.compose env28081 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound28081 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8283,24861,10281,1024,29788,4161,21793,21825,83,8192,64,23808,16401,4177,10280,1284,33,256,21873,16385,513]

theorem envBound28082 : H12AffineFastState.Bounded env28082 := by
  intro p hp
  have h : env28082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28081_28082 : H12AffineEnvironment.transform 16 24861 env28081 = env28082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env28081 == env28082) = true)

theorem identity28082 : scanCanonicalize (H12AffineFastState.compose env28082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28083 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8202,24861,10281,1024,29709,4112,21793,21776,2,8192,17,23808,16401,4096,10280,1284,33,256,21792,16385,513]

theorem envBound28083 : H12AffineFastState.Bounded env28083 := by
  intro p hp
  have h : env28083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28082_28083 : H12AffineEnvironment.transform 5 17 env28082 = env28083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28082 == env28083) = true)

theorem identity28083 : scanCanonicalize (H12AffineFastState.compose env28083 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28083 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28084 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10281,1024,8460,4112,32,17,2,8192,17,2049,5392,4096,10280,1284,33,256,33,5376,513]

theorem envBound28084 : H12AffineFastState.Bounded env28084 := by
  intro p hp
  have h : env28084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28083_28084 : H12AffineEnvironment.transform 13 5377 env28083 = env28084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28083 == env28084) = true)

theorem identity28084 : scanCanonicalize (H12AffineFastState.compose env28084 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound28084 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28085 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,5133,5377,5376,5127,17,7204,1024,5377,4112,32,17,2,5133,17,2049,5392,4096,7205,1284,33,256,33,5376,513]

theorem envBound28085 : H12AffineFastState.Bounded env28085 := by
  intro p hp
  have h : env28085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28084_28085 : H12AffineEnvironment.transform 12 5133 env28084 = env28085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env28084 == env28085) = true)

theorem identity28085 : scanCanonicalize (H12AffineFastState.compose env28085 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound28085 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28086 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,5133,5377,5376,5127,17,4113,1024,5377,4112,32,17,2,5133,17,1076,5392,4096,4112,1284,33,256,33,5376,513]

theorem envBound28086 : H12AffineFastState.Bounded env28086 := by
  intro p hp
  have h : env28086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28085_28086 : H12AffineEnvironment.transform 10 1077 env28085 = env28086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env28085 == env28086) = true)

theorem identity28086 : scanCanonicalize (H12AffineFastState.compose env28086 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound28086 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28087 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,1061,40,292,293,34,17,1076,1024,292,1077,32,17,2,40,17,1076,309,1061,1077,1284,33,256,33,293,513]

theorem envBound28087 : H12AffineFastState.Bounded env28087 := by
  intro p hp
  have h : env28087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28086_28087 : H12AffineEnvironment.transform 11 1061 env28086 = env28087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env28086 == env28087) = true)

theorem identity28087 : scanCanonicalize (H12AffineFastState.compose env28087 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28087 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env28088 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,1061,40,1,0,34,17,1076,1024,1,1077,32,17,2,40,17,1076,16,1061,1077,1057,33,37,33,0,513]

theorem envBound28088 : H12AffineFastState.Bounded env28088 := by
  intro p hp
  have h : env28088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28087_28088 : H12AffineEnvironment.transform 7 37 env28087 = env28088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28087 == env28088) = true)

theorem identity28088 : scanCanonicalize (H12AffineFastState.compose env28088 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28089 : List Nat := [2,4,8,0,32,1,8,37,512,1024,1061,1061,40,1,0,34,1,1060,1024,1,1061,32,1,2,40,1,1060,0,1061,1061,1057,33,37,33,0,513]

theorem envBound28089 : H12AffineFastState.Bounded env28089 := by
  intro p hp
  have h : env28089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28088_28089 : H12AffineEnvironment.transform 3 0 env28088 = env28089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28088 == env28089) = true)

theorem identity28089 : scanCanonicalize (H12AffineFastState.compose env28089 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound28089 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28090 : List Nat := [2,4,8,0,32,1,8,37,512,46,11,11,40,1,0,34,1,10,46,1,11,32,1,2,40,1,10,0,11,11,15,33,37,33,0,513]

theorem envBound28090 : H12AffineFastState.Bounded env28090 := by
  intro p hp
  have h : env28090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28089_28090 : H12AffineEnvironment.transform 9 46 env28089 = env28090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env28089 == env28090) = true)

theorem identity28090 : scanCanonicalize (H12AffineFastState.compose env28090 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28090 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28091 : List Nat := [2,4,8,0,11,1,8,14,512,5,11,11,3,1,0,9,1,10,5,1,11,11,1,2,3,1,10,0,11,11,15,10,14,10,0,513]

theorem envBound28091 : H12AffineFastState.Bounded env28091 := by
  intro p hp
  have h : env28091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28090_28091 : H12AffineEnvironment.transform 4 11 env28090 = env28091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28090 == env28091) = true)

theorem identity28091 : scanCanonicalize (H12AffineFastState.compose env28091 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28092 : List Nat := [2,0,8,0,11,1,8,10,512,1,11,11,3,1,0,9,1,10,1,1,11,11,1,2,3,1,10,0,11,11,11,10,10,10,0,513]

theorem envBound28092 : H12AffineFastState.Bounded env28092 := by
  intro p hp
  have h : env28092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28091_28092 : H12AffineEnvironment.transform 1 0 env28091 = env28092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28091 == env28092) = true)

theorem identity28092 : scanCanonicalize (H12AffineFastState.compose env28092 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28092 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28093 : List Nat := [2,0,3,0,0,1,3,1,512,1,0,0,3,1,0,2,1,1,1,1,0,0,1,2,3,1,1,0,0,0,0,1,1,1,0,513]

theorem envBound28093 : H12AffineFastState.Bounded env28093 := by
  intro p hp
  have h : env28093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28092_28093 : H12AffineEnvironment.transform 2 3 env28092 = env28093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28092 == env28093) = true)

theorem identity28093 : scanCanonicalize (H12AffineFastState.compose env28093 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound28093 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28094 : List Nat := [2,0,3,0,0,1,3,1,2,1,0,0,3,1,0,2,1,1,1,1,0,0,1,2,3,1,1,0,0,0,0,1,1,1,0,3]

theorem envBound28094 : H12AffineFastState.Bounded env28094 := by
  intro p hp
  have h : env28094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28093_28094 : H12AffineEnvironment.transform 8 2 env28093 = env28094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env28093 == env28094) = true)

def env28095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,16777216,8328,64,17227835,18973837,77834,2598235,18932043,16851104,256,16818679,16793682,18990749]

theorem envBound28095 : H12AffineFastState.Bounded env28095 := by
  intro p hp
  have h : env28095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28002_28095 : H12AffineEnvironment.transform 21 2114913 env28002 = env28095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env28002 == env28095) = true)

def env28096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114913,2188635,2175168,8328,64,2609403,46157,77834,2598235,119179,2101344,256,2199863,2191506,63069]

theorem envBound28096 : H12AffineFastState.Bounded env28096 := by
  intro p hp
  have h : env28096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28095_28096 : H12AffineEnvironment.transform 23 2175168 env28095 = env28096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env28095 == env28096) = true)

def env28097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21793,95515,73856,8328,64,508091,46157,77834,505115,119179,32,256,98679,90322,63069]

theorem envBound28097 : H12AffineFastState.Bounded env28097 := by
  intro p hp
  have h : env28097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28096_28097 : H12AffineEnvironment.transform 20 4160 env28096 = env28097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28096 == env28097) = true)

theorem identity28097 : scanCanonicalize (H12AffineFastState.compose env28097 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound28097 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,4160,21793,62660,41311,8328,64,409956,46157,45525,406724,20564,32,256,168,57613,63069]

theorem envBound28098 : H12AffineFastState.Bounded env28098 := by
  intro p hp
  have h : env28098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28097_28098 : H12AffineEnvironment.transform 15 33247 env28097 = env28098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env28097 == env28098) = true)

def env28099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,10280,1024,32769,4160,21793,62660,41311,8328,64,158028,46157,45525,138476,20564,32,256,168,57613,63069]

theorem envBound28099 : H12AffineFastState.Bounded env28099 := by
  intro p hp
  have h : env28099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28098_28099 : H12AffineEnvironment.transform 17 10280 env28098 = env28099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env28098 == env28099) = true)

theorem identity28099 : scanCanonicalize (H12AffineFastState.compose env28099 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound28099 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env28100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16400,10280,1024,32769,4160,21793,62660,41311,8328,64,10588,46157,45525,23804,20564,32,256,168,57613,63069]

theorem envBound28100 : H12AffineFastState.Bounded env28100 := by
  intro p hp
  have h : env28100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28099_28100 : H12AffineEnvironment.transform 16 16400 env28099 = env28100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28099 == env28100) = true)

theorem identity28100 : scanCanonicalize (H12AffineFastState.compose env28100 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound28100 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,32768,33247,16400,3173,1024,32769,4160,21793,53385,34066,1221,64,3345,36864,38296,23804,20564,32,256,168,50496,53776]

theorem envBound28101 : H12AffineFastState.Bounded env28101 := by
  intro p hp
  have h : env28101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28100_28101 : H12AffineEnvironment.transform 12 1101 env28100 = env28101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env28100 == env28101) = true)

theorem identity28101 : scanCanonicalize (H12AffineFastState.compose env28101 (packedSelected [0,3,4,5,7,10,21,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound28101 : packedSelected [0,3,4,5,7,10,21,22] rootPS < 2^1333 := by decide +kernel

def env28102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5512,32768,33247,5528,3173,1024,32769,4160,169,34049,34066,1221,64,3345,36864,38296,2420,1500,32,256,168,37064,34712]

theorem envBound28102 : H12AffineFastState.Bounded env28102 := by
  intro p hp
  have h : env28102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28101_28102 : H12AffineEnvironment.transform 13 5512 env28101 = env28102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env28101 == env28102) = true)

theorem identity28102 : scanCanonicalize (H12AffineFastState.compose env28102 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound28102 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,5512,0,479,5528,3173,1024,1,4160,169,1281,1298,1221,64,3345,4096,5528,2420,1500,32,256,168,4296,1944]

theorem envBound28103 : H12AffineFastState.Bounded env28103 := by
  intro p hp
  have h : env28103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28102_28103 : H12AffineEnvironment.transform 14 0 env28102 = env28103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env28102 == env28103) = true)

theorem identity28103 : scanCanonicalize (H12AffineFastState.compose env28103 (packedSelected [0,2,7,11,12,14,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28103 : packedSelected [0,2,7,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28104 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,1101,5260,0,219,5276,3173,1024,1,4160,169,1029,1046,1221,64,3093,4096,5276,2160,1240,32,4,168,4296,1692]

theorem envBound28104 : H12AffineFastState.Bounded env28104 := by
  intro p hp
  have h : env28104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28103_28104 : H12AffineEnvironment.transform 7 4 env28103 = env28104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28103 == env28104) = true)

theorem identity28104 : scanCanonicalize (H12AffineFastState.compose env28104 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28104 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env28105 : List Nat := [2,4,8,16,32,64,128,4,512,52,2048,4096,121,4280,0,219,4264,2129,52,1,4160,169,49,34,241,64,2081,4096,4264,2160,236,32,4,168,4296,680]

theorem envBound28105 : H12AffineFastState.Bounded env28105 := by
  intro p hp
  have h : env28105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28104_28105 : H12AffineEnvironment.transform 9 52 env28104 = env28105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28104 == env28105) = true)

theorem identity28105 : scanCanonicalize (H12AffineFastState.compose env28105 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28105 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env28106 : List Nat := [2,4,8,16,32,64,9,4,512,52,2048,4096,121,4145,0,82,4129,2129,52,1,4160,32,49,34,120,64,2081,4096,4129,2160,101,32,4,33,4161,545]

theorem envBound28106 : H12AffineFastState.Bounded env28106 := by
  intro p hp
  have h : env28106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28105_28106 : H12AffineEnvironment.transform 6 9 env28105 = env28106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28105 == env28106) = true)

theorem identity28106 : scanCanonicalize (H12AffineFastState.compose env28106 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28106 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28107 : List Nat := [2,4,8,16,1,64,9,4,512,21,2048,4096,88,4112,0,82,4096,2129,21,1,4160,1,16,3,89,64,2048,4096,4096,2129,68,1,4,0,4161,512]

theorem envBound28107 : H12AffineFastState.Bounded env28107 := by
  intro p hp
  have h : env28107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28106_28107 : H12AffineEnvironment.transform 4 1 env28106 = env28107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28106 == env28107) = true)

theorem identity28107 : scanCanonicalize (H12AffineFastState.compose env28107 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound28107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28108 : List Nat := [2,4,8,16,1,1,9,4,512,21,2048,4096,25,4112,0,19,4096,2064,21,1,4097,1,16,3,24,1,2048,4096,4096,2064,5,1,4,0,4096,512]

theorem envBound28108 : H12AffineFastState.Bounded env28108 := by
  intro p hp
  have h : env28108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28107_28108 : H12AffineEnvironment.transform 5 1 env28107 = env28108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28107 == env28108) = true)

theorem identity28108 : scanCanonicalize (H12AffineFastState.compose env28108 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28108 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28109 : List Nat := [2,4,8,16,1,1,9,4,0,21,2048,4096,25,4112,0,19,4096,2064,21,1,4097,1,16,3,24,1,2048,4096,4096,2064,5,1,4,0,4096,0]

theorem envBound28109 : H12AffineFastState.Bounded env28109 := by
  intro p hp
  have h : env28109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28108_28109 : H12AffineEnvironment.transform 8 0 env28108 = env28109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28108 == env28109) = true)

theorem identity28109 : scanCanonicalize (H12AffineFastState.compose env28109 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound28109 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env28110 : List Nat := [2,4,8,16,1,1,9,4,0,21,21,4096,25,4112,0,19,4096,5,21,1,4097,1,16,3,24,1,21,4096,4096,5,5,1,4,0,4096,0]

theorem envBound28110 : H12AffineFastState.Bounded env28110 := by
  intro p hp
  have h : env28110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28109_28110 : H12AffineEnvironment.transform 10 21 env28109 = env28110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env28109 == env28110) = true)

theorem identity28110 : scanCanonicalize (H12AffineFastState.compose env28110 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28110 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28111 : List Nat := [2,1,8,16,1,1,9,1,0,16,16,4096,25,4112,0,19,4096,0,16,1,4097,1,16,3,24,1,16,4096,4096,0,0,1,1,0,4096,0]

theorem envBound28111 : H12AffineFastState.Bounded env28111 := by
  intro p hp
  have h : env28111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28110_28111 : H12AffineEnvironment.transform 1 1 env28110 = env28111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28110 == env28111) = true)

theorem identity28111 : scanCanonicalize (H12AffineFastState.compose env28111 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound28111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28112 : List Nat := [2,1,8,16,1,1,9,1,0,16,16,1,25,17,0,19,1,0,16,1,0,1,16,3,24,1,16,1,1,0,0,1,1,0,1,0]

theorem envBound28112 : H12AffineFastState.Bounded env28112 := by
  intro p hp
  have h : env28112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28111_28112 : H12AffineEnvironment.transform 11 1 env28111 = env28112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env28111 == env28112) = true)

theorem identity28112 : scanCanonicalize (H12AffineFastState.compose env28112 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28113 : List Nat := [2,1,8,0,1,1,9,1,0,0,0,1,9,1,0,3,1,0,0,1,0,1,0,3,8,1,0,1,1,0,0,1,1,0,1,0]

theorem envBound28113 : H12AffineFastState.Bounded env28113 := by
  intro p hp
  have h : env28113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28112_28113 : H12AffineEnvironment.transform 3 0 env28112 = env28113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28112 == env28113) = true)

def env28114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,10281,1024,32769,4160,21793,62660,41311,8328,64,158029,46157,45525,138477,20564,32,256,168,57613,63069]

theorem envBound28114 : H12AffineFastState.Bounded env28114 := by
  intro p hp
  have h : env28114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28098_28114 : H12AffineEnvironment.transform 17 10281 env28098 = env28114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env28098 == env28114) = true)

theorem identity28114 : scanCanonicalize (H12AffineFastState.compose env28114 (packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound28114 : packedSelected [3,5,8,10,11,18,21,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env28115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29963,131072,10281,1024,29909,4160,21793,16,21899,8328,64,158029,16537,17665,138477,20564,32,256,168,5593,649]

theorem envBound28115 : H12AffineFastState.Bounded env28115 := by
  intro p hp
  have h : env28115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28114_28115 : H12AffineEnvironment.transform 14 29908 env28114 = env28115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env28114 == env28115) = true)

theorem identity28115 : scanCanonicalize (H12AffineFastState.compose env28115 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 24753) := by decide +kernel

theorem selectedBound28115 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env28116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,29963,24753,10281,1024,29909,4160,21793,16,21899,8328,64,2556,16537,17665,31836,20564,32,256,168,5593,649]

theorem envBound28116 : H12AffineFastState.Bounded env28116 := by
  intro p hp
  have h : env28116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28115_28116 : H12AffineEnvironment.transform 16 24753 env28115 = env28116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24753 env28115 == env28116) = true)

theorem identity28116 : scanCanonicalize (H12AffineFastState.compose env28116 (packedSelected [0,6,7,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound28116 : packedSelected [0,6,7,12,15,18] rootPS < 2^1333 := by decide +kernel

def env28117 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,29908,29943,24753,10281,1024,29909,4160,21725,16,21623,8328,64,2048,16537,17661,31836,20564,32,252,168,5157,649]

theorem envBound28117 : H12AffineFastState.Bounded env28117 := by
  intro p hp
  have h : env28117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28116_28117 : H12AffineEnvironment.transform 7 252 env28116 = env28117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env28116 == env28117) = true)

theorem identity28117 : scanCanonicalize (H12AffineFastState.compose env28117 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound28117 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env28118 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5156,8432,8403,13461,10281,1024,8433,4160,249,16,83,8328,64,2048,5309,4313,10360,1136,32,252,168,5157,649]

theorem envBound28118 : H12AffineFastState.Bounded env28118 := by
  intro p hp
  have h : env28118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28117_28118 : H12AffineEnvironment.transform 13 5156 env28117 = env28118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env28117 == env28118) = true)

theorem identity28118 : scanCanonicalize (H12AffineFastState.compose env28118 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound28118 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28119 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5156,136,171,5357,2129,1024,137,4160,249,16,83,240,64,2048,5309,4313,2048,1136,32,252,168,5157,649]

theorem envBound28119 : H12AffineFastState.Bounded env28119 := by
  intro p hp
  have h : env28119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28118_28119 : H12AffineEnvironment.transform 12 120 env28118 = env28119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env28118 == env28119) = true)

theorem identity28119 : scanCanonicalize (H12AffineFastState.compose env28119 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28119 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28120 : List Nat := [2,4,8,16,32,64,88,36,512,1024,2048,4096,120,5156,80,115,5173,2129,1024,81,4160,33,16,83,40,64,2048,5221,4097,2048,1136,32,36,112,5157,593]

theorem envBound28120 : H12AffineFastState.Bounded env28120 := by
  intro p hp
  have h : env28120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28119_28120 : H12AffineEnvironment.transform 6 88 env28119 = env28120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28119 == env28120) = true)

def env28121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21792,95514,73857,8328,64,508090,46157,77834,505114,119179,33,256,98678,90323,63069]

theorem envBound28121 : H12AffineFastState.Bounded env28121 := by
  intro p hp
  have h : env28121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28096_28121 : H12AffineEnvironment.transform 20 4161 env28096 = env28121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28096 == env28121) = true)

theorem identity28121 : scanCanonicalize (H12AffineFastState.compose env28121 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound28121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,21792,41293,62678,8328,64,398573,46157,58461,418125,1500,33,256,21793,46212,63069]

theorem envBound28122 : H12AffineFastState.Bounded env28122 := by
  intro p hp
  have h : env28122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28121_28122 : H12AffineEnvironment.transform 15 54359 env28121 = env28122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env28121 == env28122) = true)

def env28123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,4161,21792,41293,62678,8328,64,146629,46157,58461,149861,1500,33,256,21793,46212,63069]

theorem envBound28123 : H12AffineFastState.Bounded env28123 := by
  intro p hp
  have h : env28123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28122_28123 : H12AffineEnvironment.transform 17 10280 env28122 = env28123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env28122 == env28123) = true)

theorem identity28123 : scanCanonicalize (H12AffineFastState.compose env28123 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28123 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10280,1024,32769,4161,33,41293,41431,8328,64,146629,46157,45404,138340,1500,33,256,32,46212,41820]

theorem envBound28124 : H12AffineFastState.Bounded env28124 := by
  intro p hp
  have h : env28124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28123_28124 : H12AffineEnvironment.transform 13 5377 env28123 = env28124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28123 == env28124) = true)

theorem identity28124 : scanCanonicalize (H12AffineFastState.compose env28124 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound28124 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,5393,10280,1024,32769,4161,33,41293,41431,8328,64,10708,46157,45404,2421,1500,33,256,32,46212,41820]

end H12CloudChart1