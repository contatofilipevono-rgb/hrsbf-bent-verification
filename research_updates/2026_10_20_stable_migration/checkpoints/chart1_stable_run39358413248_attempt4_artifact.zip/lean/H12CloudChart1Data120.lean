import H12CloudChart1Data119

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity30433 : scanCanonicalize (H12AffineFastState.compose env30433 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30433 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,180409,452649,441658,8328,65,292257,395772,437560,10280,61704,272392,256,41461,16465,63189]

theorem envBound30434 : H12AffineFastState.Bounded env30434 := by
  intro p hp
  have h : env30434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30433_30434 : H12AffineEnvironment.transform 15 8202 env30433 = env30434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30433 == env30434) = true)

def env30435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,32768,250,131072,262144,1024,32769,4161,180409,444633,433610,120,65,283985,395772,429512,2264,53752,264440,256,33029,16465,54821]

theorem envBound30435 : H12AffineFastState.Bounded env30435 := by
  intro p hp
  have h : env30435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30434_30435 : H12AffineEnvironment.transform 12 240 env30434 = env30435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env30434 == env30435) = true)

theorem identity30435 : scanCanonicalize (H12AffineFastState.compose env30435 (packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30435 : packedSelected [7,8,10,11,12,14,15,17,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env30436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,114,131072,262144,1024,32769,4161,180273,444497,433474,120,65,283985,395636,429376,2128,53616,264304,256,33029,16465,54821]

theorem envBound30436 : H12AffineFastState.Bounded env30436 := by
  intro p hp
  have h : env30436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30435_30436 : H12AffineEnvironment.transform 6 8 env30435 = env30436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30435 == env30436) = true)

theorem identity30436 : scanCanonicalize (H12AffineFastState.compose env30436 (packedSelected [0,2,4,6,7,8,9,11,12,17,19,23,26,28,31,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 171329) := by decide +kernel

theorem selectedBound30436 : packedSelected [0,2,4,6,7,8,9,11,12,17,19,23,26,28,31,35,38] rootPS < 2^1333 := by decide +kernel

def env30437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,32768,114,131072,171329,1024,32769,4161,180273,21776,3,120,65,182288,37941,4097,2128,53616,169265,256,33029,16465,54821]

theorem envBound30437 : H12AffineFastState.Bounded env30437 := by
  intro p hp
  have h : env30437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30436_30437 : H12AffineEnvironment.transform 17 171329 env30436 = env30437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171329 env30436 == env30437) = true)

theorem identity30437 : scanCanonicalize (H12AffineFastState.compose env30437 (packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound30437 : packedSelected [2,3,6,9,10,11,14,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env30438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21761,114,131072,149568,1024,21760,4161,136496,21776,3,120,65,138513,16692,4097,2128,1137,147504,256,21508,16465,804]

theorem envBound30438 : H12AffineFastState.Bounded env30438 := by
  intro p hp
  have h : env30438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30437_30438 : H12AffineEnvironment.transform 14 21761 env30437 = env30438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env30437 == env30438) = true)

theorem identity30438 : scanCanonicalize (H12AffineFastState.compose env30438 (packedSelected [0,7,9,14,17,18,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound30438 : packedSelected [0,7,9,14,17,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env30439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21761,114,5173,23669,1024,21760,4161,261,21776,3,120,65,2340,16692,4097,2128,1137,21509,256,21508,16465,804]

theorem envBound30439 : H12AffineFastState.Bounded env30439 := by
  intro p hp
  have h : env30439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30438_30439 : H12AffineEnvironment.transform 16 5173 env30438 = env30439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env30438 == env30439) = true)

theorem identity30439 : scanCanonicalize (H12AffineFastState.compose env30439 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound30439 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5456,81,114,5173,2341,1024,80,4161,261,64,3,120,65,2340,5220,4097,2128,1137,341,256,340,5377,804]

theorem envBound30440 : H12AffineFastState.Bounded env30440 := by
  intro p hp
  have h : env30440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30439_30440 : H12AffineEnvironment.transform 13 5456 env30439 = env30440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env30439 == env30440) = true)

theorem identity30440 : scanCanonicalize (H12AffineFastState.compose env30440 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30440 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30441 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5376,1,34,5173,2341,1024,0,4113,261,16,3,40,17,2340,5172,4097,2048,1057,261,256,260,5377,804]

theorem envBound30441 : H12AffineFastState.Bounded env30441 := by
  intro p hp
  have h : env30441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30440_30441 : H12AffineEnvironment.transform 5 16 env30440 = env30441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30440 == env30441) = true)

theorem identity30441 : scanCanonicalize (H12AffineFastState.compose env30441 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound30441 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30442 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,308,40,1076,1,34,1281,2341,1024,0,293,261,16,3,40,17,2340,1280,309,2048,1057,261,256,260,1077,804]

theorem envBound30442 : H12AffineFastState.Bounded env30442 := by
  intro p hp
  have h : env30442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30441_30442 : H12AffineEnvironment.transform 11 308 env30441 = env30442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env30441 == env30442) = true)

theorem identity30442 : scanCanonicalize (H12AffineFastState.compose env30442 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30442 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env30443 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,308,40,1076,1,34,1281,1296,1024,0,293,261,16,3,40,17,1297,1280,309,1077,1057,261,256,260,1077,804]

theorem envBound30443 : H12AffineFastState.Bounded env30443 := by
  intro p hp
  have h : env30443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30442_30443 : H12AffineEnvironment.transform 10 1077 env30442 = env30443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env30442 == env30443) = true)

theorem identity30443 : scanCanonicalize (H12AffineFastState.compose env30443 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30443 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env30444 : List Nat := [2,4,8,16,32,16,8,256,512,272,293,308,40,292,1,34,17,0,272,0,293,261,16,3,40,17,1,16,309,293,305,261,256,260,293,804]

theorem envBound30444 : H12AffineFastState.Bounded env30444 := by
  intro p hp
  have h : env30444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30443_30444 : H12AffineEnvironment.transform 9 272 env30443 = env30444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30443 == env30444) = true)

theorem identity30444 : scanCanonicalize (H12AffineFastState.compose env30444 (packedSelected [2,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30444 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env30445 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,16,40,0,1,34,17,0,52,0,1,33,16,3,40,17,1,16,17,1,21,33,36,32,1,512]

theorem envBound30445 : H12AffineFastState.Bounded env30445 := by
  intro p hp
  have h : env30445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30444_30445 : H12AffineEnvironment.transform 7 36 env30444 = env30445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30444 == env30445) = true)

theorem identity30445 : scanCanonicalize (H12AffineFastState.compose env30445 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30446 : List Nat := [2,4,8,16,32,16,8,36,1,52,1,16,40,0,1,34,17,0,52,0,1,33,16,3,40,17,1,16,17,1,21,33,36,32,1,1]

theorem envBound30446 : H12AffineFastState.Bounded env30446 := by
  intro p hp
  have h : env30446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30445_30446 : H12AffineEnvironment.transform 8 1 env30445 = env30446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30445 == env30446) = true)

theorem identity30446 : scanCanonicalize (H12AffineFastState.compose env30446 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound30446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30447 : List Nat := [2,4,8,16,30,16,8,26,1,10,1,16,22,0,1,28,17,0,10,0,1,31,16,3,22,17,1,16,17,1,21,31,26,30,1,1]

theorem envBound30447 : H12AffineFastState.Bounded env30447 := by
  intro p hp
  have h : env30447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30446_30447 : H12AffineEnvironment.transform 4 30 env30446 = env30447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env30446 == env30447) = true)

theorem identity30447 : scanCanonicalize (H12AffineFastState.compose env30447 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound30447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30448 : List Nat := [2,4,8,14,0,14,8,4,1,10,1,14,8,0,1,2,15,0,10,0,1,1,14,3,8,15,1,14,15,1,11,1,4,0,1,1]

theorem envBound30448 : H12AffineFastState.Bounded env30448 := by
  intro p hp
  have h : env30448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30447_30448 : H12AffineEnvironment.transform 3 14 env30447 = env30448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env30447 == env30448) = true)

def env30449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,32768,251,131072,262144,1024,32769,4161,180409,444632,433611,121,65,283984,395772,429513,2265,53753,264441,256,33028,16465,54820]

theorem envBound30449 : H12AffineFastState.Bounded env30449 := by
  intro p hp
  have h : env30449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30434_30449 : H12AffineEnvironment.transform 12 241 env30434 = env30449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env30434 == env30449) = true)

def env30450 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,131072,262144,1024,32769,4113,180409,444552,433563,41,17,283904,395692,429465,2185,53673,264361,256,33028,16385,54820]

theorem envBound30450 : H12AffineFastState.Bounded env30450 := by
  intro p hp
  have h : env30450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30449_30450 : H12AffineEnvironment.transform 5 16 env30449 = env30450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30449 == env30450) = true)

theorem identity30450 : scanCanonicalize (H12AffineFastState.compose env30450 (packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound30450 : packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env30451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,5528,262144,1024,32769,4113,54561,318736,296963,41,17,283904,269364,301057,2185,53673,264361,256,33028,16385,54820]

theorem envBound30451 : H12AffineFastState.Bounded env30451 := by
  intro p hp
  have h : env30451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30450_30451 : H12AffineEnvironment.transform 16 5528 env30450 = env30451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env30450 == env30451) = true)

theorem identity30451 : scanCanonicalize (H12AffineFastState.compose env30451 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56492) := by decide +kernel

theorem selectedBound30451 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,16384,32768,171,5528,56492,1024,32769,4113,54561,444,21679,41,17,35244,49304,17581,2185,53673,54277,256,33028,16385,54820]

theorem envBound30452 : H12AffineFastState.Bounded env30452 := by
  intro p hp
  have h : env30452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30451_30452 : H12AffineEnvironment.transform 17 56492 env30451 = env30452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56492 env30451 == env30452) = true)

theorem identity30452 : scanCanonicalize (H12AffineFastState.compose env30452 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound30452 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,161,5292,32768,171,5528,34816,1024,32769,4113,33165,444,3,41,17,35244,37940,4097,2185,34053,32937,256,33028,5293,33416]

theorem envBound30453 : H12AffineFastState.Bounded env30453 := by
  intro p hp
  have h : env30453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30452_30453 : H12AffineEnvironment.transform 13 5292 env30452 = env30453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env30452 == env30453) = true)

theorem identity30453 : scanCanonicalize (H12AffineFastState.compose env30453 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound30453 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env30454 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5292,32768,171,5172,34816,1024,32769,4113,32801,16,3,41,17,34816,37940,4097,2185,33961,32937,172,32936,5293,33416]

theorem envBound30454 : H12AffineFastState.Bounded env30454 := by
  intro p hp
  have h : env30454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30453_30454 : H12AffineEnvironment.transform 7 172 env30453 = env30454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30453 == env30454) = true)

theorem identity30454 : scanCanonicalize (H12AffineFastState.compose env30454 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound30454 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30455 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,161,5292,1,171,5172,2049,1024,0,4113,32,16,3,41,17,2049,5173,4097,2185,1192,168,172,169,5293,649]

theorem envBound30455 : H12AffineFastState.Bounded env30455 := by
  intro p hp
  have h : env30455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30454_30455 : H12AffineEnvironment.transform 14 1 env30454 = env30455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env30454 == env30455) = true)

theorem identity30455 : scanCanonicalize (H12AffineFastState.compose env30455 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound30455 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30456 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,4096,161,4113,1,171,4233,2049,189,0,4113,32,16,3,41,17,2049,4232,4097,2185,21,168,172,169,4112,649]

theorem envBound30456 : H12AffineFastState.Bounded env30456 := by
  intro p hp
  have h : env30456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30455_30456 : H12AffineEnvironment.transform 9 189 env30455 = env30456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env30455 == env30456) = true)

theorem identity30456 : scanCanonicalize (H12AffineFastState.compose env30456 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound30456 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30457 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,17,161,0,1,171,152,2049,189,0,0,32,16,3,41,17,2049,153,16,2185,21,168,172,169,1,649]

theorem envBound30457 : H12AffineFastState.Bounded env30457 := by
  intro p hp
  have h : env30457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30456_30457 : H12AffineEnvironment.transform 11 17 env30456 = env30457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30456 == env30457) = true)

def env30458 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,131072,262144,1024,32769,4112,180409,444553,433562,40,16,283905,395693,429464,2184,53672,264360,256,33028,16384,54820]

theorem envBound30458 : H12AffineFastState.Bounded env30458 := by
  intro p hp
  have h : env30458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30449_30458 : H12AffineEnvironment.transform 5 17 env30449 = env30458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30449 == env30458) = true)

theorem identity30458 : scanCanonicalize (H12AffineFastState.compose env30458 (packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS)) = affineNative (2^(16+1) ^^^ 49597) := by decide +kernel

theorem selectedBound30458 : packedSelected [8,10,12,15,16,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env30459 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,49597,262144,1024,32769,4112,260,264500,285735,40,16,283905,313360,281637,2184,53672,264360,256,33028,16384,54820]

theorem envBound30459 : H12AffineFastState.Bounded env30459 := by
  intro p hp
  have h : env30459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30458_30459 : H12AffineEnvironment.transform 16 49597 env30458 = env30459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49597 env30458 == env30459) = true)

theorem identity30459 : scanCanonicalize (H12AffineFastState.compose env30459 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound30459 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30460 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,49597,2048,1024,32769,4112,260,308,21543,40,16,23809,49168,17445,2184,53672,168,256,33028,16384,54820]

theorem envBound30460 : H12AffineFastState.Bounded env30460 := by
  intro p hp
  have h : env30460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30459_30460 : H12AffineEnvironment.transform 17 2048 env30459 = env30460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env30459 == env30460) = true)

theorem identity30460 : scanCanonicalize (H12AffineFastState.compose env30460 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound30460 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30461 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5292,32768,170,38161,2048,1024,32769,4112,260,308,139,40,16,2477,38076,4233,2184,34052,168,256,33028,5292,33416]

theorem envBound30461 : H12AffineFastState.Bounded env30461 := by
  intro p hp
  have h : env30461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30460_30461 : H12AffineEnvironment.transform 13 5292 env30460 = env30461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env30460 == env30461) = true)

theorem identity30461 : scanCanonicalize (H12AffineFastState.compose env30461 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound30461 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env30462 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5292,429,170,5308,2048,1024,428,4112,260,308,139,40,16,2477,5393,4233,2184,1193,168,256,169,5292,805]

theorem envBound30462 : H12AffineFastState.Bounded env30462 := by
  intro p hp
  have h : env30462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30461_30462 : H12AffineEnvironment.transform 14 429 env30461 = env30462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env30461 == env30462) = true)

theorem identity30462 : scanCanonicalize (H12AffineFastState.compose env30462 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound30462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30463 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,309,160,1433,429,170,1417,2048,1024,428,293,260,308,139,40,16,2477,1060,444,2184,1193,168,256,169,1433,805]

theorem envBound30463 : H12AffineFastState.Bounded env30463 := by
  intro p hp
  have h : env30463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30462_30463 : H12AffineEnvironment.transform 11 309 env30462 = env30463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env30462 == env30463) = true)

theorem identity30463 : scanCanonicalize (H12AffineFastState.compose env30463 (packedSelected [0,1,4,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound30463 : packedSelected [0,1,4,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30464 : List Nat := [2,4,8,16,32,17,128,256,512,1024,293,309,160,1433,429,170,1417,293,1024,428,293,260,308,139,40,16,136,1060,444,429,1193,168,256,169,1433,805]

theorem envBound30464 : H12AffineFastState.Bounded env30464 := by
  intro p hp
  have h : env30464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30463_30464 : H12AffineEnvironment.transform 10 293 env30463 = env30464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env30463 == env30464) = true)

theorem identity30464 : scanCanonicalize (H12AffineFastState.compose env30464 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30464 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env30465 : List Nat := [2,4,8,16,32,17,128,256,512,53,293,309,160,428,429,170,444,293,53,428,293,260,308,139,40,16,136,17,444,429,156,168,256,169,428,805]

theorem envBound30465 : H12AffineFastState.Bounded env30465 := by
  intro p hp
  have h : env30465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30464_30465 : H12AffineEnvironment.transform 9 53 env30464 = env30465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30464 == env30465) = true)

theorem identity30465 : scanCanonicalize (H12AffineFastState.compose env30465 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30465 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30466 : List Nat := [2,4,8,16,32,17,128,36,512,53,1,17,160,136,137,170,152,1,53,136,1,32,16,139,40,16,136,17,152,137,156,168,36,169,136,513]

theorem envBound30466 : H12AffineFastState.Bounded env30466 := by
  intro p hp
  have h : env30466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30465_30466 : H12AffineEnvironment.transform 7 36 env30465 = env30466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30465 == env30466) = true)

def env30467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,509987,498993,8328,65,349610,2496956,2596211,67618,119043,2373704,256,2199999,2191387,63188]

theorem envBound30467 : H12AffineFastState.Bounded env30467 := by
  intro p hp
  have h : env30467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30413_30467 : H12AffineEnvironment.transform 23 498993 env30413 = env30467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env30413 == env30467) = true)

def env30468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,509987,498993,8328,65,349610,395772,494899,67618,119043,272392,256,98815,90203,63188]

theorem envBound30468 : H12AffineFastState.Bounded env30468 := by
  intro p hp
  have h : env30468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30467_30468 : H12AffineEnvironment.transform 20 4160 env30467 = env30468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30467 == env30468) = true)

theorem identity30468 : scanCanonicalize (H12AffineFastState.compose env30468 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound30468 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,180409,400636,412142,8328,65,295285,395772,416236,56573,1500,272392,256,21792,46212,63188]

theorem envBound30469 : H12AffineFastState.Bounded env30469 := by
  intro p hp
  have h : env30469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30468_30469 : H12AffineEnvironment.transform 15 54495 env30468 = env30469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env30468 == env30469) = true)

def env30470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180273,400500,412006,8192,65,295285,395636,416100,56437,1364,272392,256,21792,46092,63068]

theorem envBound30470 : H12AffineFastState.Bounded env30470 := by
  intro p hp
  have h : env30470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30469_30470 : H12AffineEnvironment.transform 6 8 env30469 = env30470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30469 == env30470) = true)

theorem identity30470 : scanCanonicalize (H12AffineFastState.compose env30470 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182628) := by decide +kernel

theorem selectedBound30470 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env30471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,182628,1024,32769,4160,180273,54544,32770,8192,65,149521,49168,36864,56437,1364,188780,256,21792,46092,63068]

theorem envBound30471 : H12AffineFastState.Bounded env30471 := by
  intro p hp
  have h : env30471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30470_30471 : H12AffineEnvironment.transform 17 182628 env30470 = env30471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182628 env30470 == env30471) = true)

theorem identity30471 : scanCanonicalize (H12AffineFastState.compose env30471 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30471 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,146745,1024,29788,4160,144492,8525,29791,8192,65,149521,13389,25693,10280,1364,136497,256,21792,16465,513]

theorem envBound30472 : H12AffineFastState.Bounded env30472 := by
  intro p hp
  have h : env30472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30471_30472 : H12AffineEnvironment.transform 14 29789 env30471 = env30472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30471 == env30472) = true)

theorem identity30472 : scanCanonicalize (H12AffineFastState.compose env30472 (packedSelected [0,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30472 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env30473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,146745,1024,8540,4160,144492,8525,8543,8192,65,138513,13389,12637,10280,1364,136497,256,32,5457,513]

theorem envBound30473 : H12AffineFastState.Bounded env30473 := by
  intro p hp
  have h : env30473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30472_30473 : H12AffineEnvironment.transform 13 5376 env30472 = env30473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30472 == env30473) = true)

theorem identity30473 : scanCanonicalize (H12AffineFastState.compose env30473 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound30473 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env30474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,13388,2421,1024,8540,4160,32,8525,8543,8192,65,10589,13389,12637,10280,1364,8573,256,32,5457,513]

theorem envBound30474 : H12AffineFastState.Bounded env30474 := by
  intro p hp
  have h : env30474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30473_30474 : H12AffineEnvironment.transform 16 13388 env30473 = env30474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env30473 == env30474) = true)

def env30475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180272,400501,412007,8193,65,295285,395637,416101,56436,1365,272392,256,21792,46093,63069]

theorem envBound30475 : H12AffineFastState.Bounded env30475 := by
  intro p hp
  have h : env30475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30469_30475 : H12AffineEnvironment.transform 6 9 env30469 = env30475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30469 == env30475) = true)

theorem identity30475 : scanCanonicalize (H12AffineFastState.compose env30475 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23888) := by decide +kernel

theorem selectedBound30475 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env30476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,23888,1024,32769,4160,180272,147749,136247,8193,65,56357,152613,132149,56436,1365,30040,256,21792,46093,63069]

theorem envBound30476 : H12AffineFastState.Bounded env30476 := by
  intro p hp
  have h : env30476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30475_30476 : H12AffineEnvironment.transform 17 23888 env30475 = env30476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23888 env30475 == env30476) = true)

theorem identity30476 : scanCanonicalize (H12AffineFastState.compose env30476 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound30476 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env30477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,131072,23888,1024,8460,4160,155965,147749,136247,8193,65,32040,152613,132149,32121,1365,30040,256,21792,5376,22352]

theorem envBound30477 : H12AffineFastState.Bounded env30477 := by
  intro p hp
  have h : env30477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30476_30477 : H12AffineEnvironment.transform 14 8461 env30476 = env30477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env30476 == env30477) = true)

theorem identity30477 : scanCanonicalize (H12AffineFastState.compose env30477 (packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound30477 : packedSelected [0,3,7,9,10,14,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,5441,23888,1024,8460,4160,29820,21604,374,8193,65,32040,16740,4468,32121,1365,30040,256,21792,5376,22352]

theorem envBound30478 : H12AffineFastState.Bounded env30478 := by
  intro p hp
  have h : env30478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30477_30478 : H12AffineEnvironment.transform 16 5441 env30477 = env30478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env30477 == env30478) = true)

theorem identity30478 : scanCanonicalize (H12AffineFastState.compose env30478 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30478 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env30479 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,29962,5392,23809,1024,8460,4113,29741,21557,295,8193,16,32040,16693,4389,32040,1284,29961,256,21792,5376,22273]

theorem envBound30479 : H12AffineFastState.Bounded env30479 := by
  intro p hp
  have h : env30479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30478_30479 : H12AffineEnvironment.transform 5 17 env30478 = env30479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30478 == env30479) = true)

theorem identity30479 : scanCanonicalize (H12AffineFastState.compose env30479 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound30479 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30480 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,263,5392,10508,1024,8460,4113,32,8248,295,8193,16,2341,13624,4389,2341,1284,260,256,8493,5376,8972]

theorem envBound30480 : H12AffineFastState.Bounded env30480 := by
  intro p hp
  have h : env30480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30479_30480 : H12AffineEnvironment.transform 13 13325 env30479 = env30480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env30479 == env30480) = true)

theorem identity30480 : scanCanonicalize (H12AffineFastState.compose env30480 (packedSelected [0,1,2,4,6,7,8,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30480 : packedSelected [0,1,2,4,6,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env30481 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5157,293,263,5392,2340,1024,292,4113,32,16,295,41,16,2341,5392,4389,2341,1284,260,256,261,5376,804]

theorem envBound30481 : H12AffineFastState.Bounded env30481 := by
  intro p hp
  have h : env30481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30480_30481 : H12AffineEnvironment.transform 12 40 env30480 = env30481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30480 == env30481) = true)

theorem identity30481 : scanCanonicalize (H12AffineFastState.compose env30481 (packedSelected [0,1,3,4,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30481 : packedSelected [0,1,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env30482 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4113,32,16,3,41,16,2049,5172,4097,2049,1056,32,36,33,5156,512]

theorem envBound30482 : H12AffineFastState.Bounded env30482 := by
  intro p hp
  have h : env30482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30481_30482 : H12AffineEnvironment.transform 7 36 env30481 = env30482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30481 == env30482) = true)

theorem identity30482 : scanCanonicalize (H12AffineFastState.compose env30482 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30483 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,1,2,5141,2048,1024,0,4113,1,16,3,8,16,2049,5141,4097,2049,1025,1,5,0,5125,512]

theorem envBound30483 : H12AffineFastState.Bounded env30483 := by
  intro p hp
  have h : env30483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30482_30483 : H12AffineEnvironment.transform 4 1 env30482 = env30483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30482 == env30483) = true)

theorem identity30483 : scanCanonicalize (H12AffineFastState.compose env30483 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound30483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30484 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,9,5124,1,2,5141,522,1024,0,4113,1,16,3,8,16,523,5141,4097,523,1025,1,5,0,5125,512]

theorem envBound30484 : H12AffineFastState.Bounded env30484 := by
  intro p hp
  have h : env30484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30483_30484 : H12AffineEnvironment.transform 10 522 env30483 = env30484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env30483 == env30484) = true)

def env30485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,509987,498993,8328,65,349610,395773,494898,67618,119043,272393,256,98814,90202,63188]

theorem envBound30485 : H12AffineFastState.Bounded env30485 := by
  intro p hp
  have h : env30485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30467_30485 : H12AffineEnvironment.transform 20 4161 env30467 = env30485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30467 == env30485) = true)

theorem identity30485 : scanCanonicalize (H12AffineFastState.compose env30485 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound30485 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4161,180409,62661,41431,8328,65,158028,79131,45524,67618,119043,201967,256,98814,90202,63188]

theorem envBound30486 : H12AffineFastState.Bounded env30486 := by
  intro p hp
  have h : env30486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30485_30486 : H12AffineEnvironment.transform 17 212198 env30485 = env30486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env30485 == env30486) = true)

theorem identity30486 : scanCanonicalize (H12AffineFastState.compose env30486 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound30486 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212198,1024,29908,4161,144492,16,21762,8328,65,158028,79131,17665,67618,75222,201967,256,95531,90202,513]

theorem envBound30487 : H12AffineFastState.Bounded env30487 := by
  intro p hp
  have h : env30487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30486_30487 : H12AffineEnvironment.transform 14 29909 env30486 = env30487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env30486 == env30487) = true)

theorem identity30487 : scanCanonicalize (H12AffineFastState.compose env30487 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound30487 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env30488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,5528,76158,1024,29908,4161,8692,16,21762,8328,65,31956,79131,17665,67618,75222,65911,256,95531,90202,513]

theorem envBound30488 : H12AffineFastState.Bounded env30488 := by
  intro p hp
  have h : env30488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30487_30488 : H12AffineEnvironment.transform 16 5528 env30487 = env30488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env30487 == env30488) = true)

theorem identity30488 : scanCanonicalize (H12AffineFastState.compose env30488 (packedSelected [4,5,7,8,9,10,15,17,24,26,27,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound30488 : packedSelected [4,5,7,8,9,10,15,17,24,26,27,28,38] rootPS < 2^1333 := by decide +kernel

def env30489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21591,5528,32041,1024,29908,4161,8692,16,21762,8328,65,31956,24908,17665,23669,29057,21792,256,8572,13325,513]

theorem envBound30489 : H12AffineFastState.Bounded env30489 := by
  intro p hp
  have h : env30489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30488_30489 : H12AffineEnvironment.transform 15 21591 env30488 = env30489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env30488 == env30489) = true)

theorem identity30489 : scanCanonicalize (H12AffineFastState.compose env30489 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30489 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env30490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,21591,5528,23668,1024,21897,4161,169,16,21762,469,65,23945,16401,17665,23669,20700,21792,256,33,5456,513]

theorem envBound30490 : H12AffineFastState.Bounded env30490 := by
  intro p hp
  have h : env30490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30489_30490 : H12AffineEnvironment.transform 12 349 env30489 = env30490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30489 == env30490) = true)

theorem identity30490 : scanCanonicalize (H12AffineFastState.compose env30490 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound30490 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30491 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,16384,21756,21591,5356,23668,1024,21757,4161,169,16,21622,161,65,23805,16401,17525,23669,20700,21588,116,33,5156,513]

theorem envBound30491 : H12AffineFastState.Bounded env30491 := by
  intro p hp
  have h : env30491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30490_30491 : H12AffineEnvironment.transform 7 116 env30490 = env30491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env30490 == env30491) = true)

theorem identity30491 : scanCanonicalize (H12AffineFastState.compose env30491 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound30491 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env30492 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5372,0,171,5356,2184,1024,1,4161,169,16,138,161,65,2049,5357,4233,2185,1056,168,116,33,5156,513]

theorem envBound30492 : H12AffineFastState.Bounded env30492 := by
  intro p hp
  have h : env30492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30491_30492 : H12AffineEnvironment.transform 13 5372 env30491 = env30492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env30491 == env30492) = true)

theorem identity30492 : scanCanonicalize (H12AffineFastState.compose env30492 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound30492 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30493 : List Nat := [2,4,8,16,32,64,128,116,512,236,2048,4096,41,4112,0,171,4096,2184,236,1,4161,169,16,138,161,65,2049,4097,4233,2185,204,168,116,33,4296,513]

theorem envBound30493 : H12AffineFastState.Bounded env30493 := by
  intro p hp
  have h : env30493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30492_30493 : H12AffineEnvironment.transform 9 236 env30492 = env30493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env30492 == env30493) = true)

theorem identity30493 : scanCanonicalize (H12AffineFastState.compose env30493 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30493 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30494 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,41,4112,0,35,4096,2048,100,1,4161,33,16,2,41,65,2049,4097,4097,2049,68,32,116,33,4160,513]

theorem envBound30494 : H12AffineFastState.Bounded env30494 := by
  intro p hp
  have h : env30494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30493_30494 : H12AffineEnvironment.transform 6 8 env30493 = env30494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30493 == env30494) = true)

theorem identity30494 : scanCanonicalize (H12AffineFastState.compose env30494 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound30494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30495 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,16,41,0,0,35,16,2048,100,1,81,33,16,2,41,65,2049,17,17,2049,68,32,116,33,80,513]

theorem envBound30495 : H12AffineFastState.Bounded env30495 := by
  intro p hp
  have h : env30495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30494_30495 : H12AffineEnvironment.transform 11 16 env30494 = env30495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30494 == env30495) = true)

theorem identity30495 : scanCanonicalize (H12AffineFastState.compose env30495 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound30495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30496 : List Nat := [2,4,8,16,32,64,8,116,49,100,2048,16,41,0,0,35,16,2048,100,1,81,33,16,2,41,65,2049,17,17,2049,68,32,116,33,80,48]

theorem envBound30496 : H12AffineFastState.Bounded env30496 := by
  intro p hp
  have h : env30496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30495_30496 : H12AffineEnvironment.transform 8 49 env30495 = env30496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env30495 == env30496) = true)

theorem identity30496 : scanCanonicalize (H12AffineFastState.compose env30496 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30496 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30497 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,16,41,0,0,35,16,2048,52,1,1,33,16,2,41,17,2049,17,17,2049,20,32,36,33,0,48]

theorem envBound30497 : H12AffineFastState.Bounded env30497 := by
  intro p hp
  have h : env30497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30496_30497 : H12AffineEnvironment.transform 5 16 env30496 = env30497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30496 == env30497) = true)

theorem identity30497 : scanCanonicalize (H12AffineFastState.compose env30497 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30498 : List Nat := [2,4,8,16,32,16,8,36,49,52,1,16,41,0,0,35,16,1,52,1,1,33,16,2,41,17,0,17,17,0,20,32,36,33,0,48]

theorem envBound30498 : H12AffineFastState.Bounded env30498 := by
  intro p hp
  have h : env30498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30497_30498 : H12AffineEnvironment.transform 10 1 env30497 = env30498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30497 == env30498) = true)

def env30499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound30499 : H12AffineFastState.Bounded env30499 := by
  intro p hp
  have h : env30499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30277_30499 : H12AffineEnvironment.transform 18 1025 env30277 = env30499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env30277 == env30499) = true)

theorem identity30499 : scanCanonicalize (H12AffineFastState.compose env30499 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272546) := by decide +kernel

theorem selectedBound30499 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272546,8328,65,12839074,2468910,10507600,8830976,8760499,6638946,257,10873870,10816939,8686437]

theorem envBound30500 : H12AffineFastState.Bounded env30500 := by
  intro p hp
  have h : env30500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30499_30500 : H12AffineEnvironment.transform 23 272546 env30499 = env30500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272546 env30499 == env30500) = true)

def env30501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272546,8328,65,4302890,2468910,2233816,295048,519227,6638946,257,2600070,2575651,445421]

theorem envBound30501 : H12AffineFastState.Bounded env30501 := by
  intro p hp
  have h : env30501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30500_30501 : H12AffineEnvironment.transform 22 147592 env30500 = env30501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env30500 == env30501) = true)

def env30502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302890,2468910,2119112,295048,371755,6638946,257,2485398,2428211,297981]

theorem envBound30502 : H12AffineFastState.Bounded env30502 := by
  intro p hp
  have h : env30502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30501_30502 : H12AffineEnvironment.transform 16 16400 env30501 = env30502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30501 == env30502) = true)

def env30503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4302890,2468910,2118976,294912,371755,6638946,257,2485278,2428211,297845]

theorem envBound30503 : H12AffineFastState.Bounded env30503 := by
  intro p hp
  have h : env30503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30502_30503 : H12AffineEnvironment.transform 6 8 env30502 = env30503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30502 == env30503) = true)

theorem identity30503 : scanCanonicalize (H12AffineFastState.compose env30503 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30503 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env30504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,2097152,4194304,16,272426,8192,65,4229152,2395172,2118976,294912,298017,6581608,257,2411540,2370873,297845]

theorem envBound30504 : H12AffineFastState.Bounded env30504 := by
  intro p hp
  have h : env30504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30503_30504 : H12AffineEnvironment.transform 15 8202 env30503 = env30504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30503 == env30504) = true)

theorem identity30504 : scanCanonicalize (H12AffineFastState.compose env30504 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound30504 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env30505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,17680,4194304,16,272426,8192,65,4229152,313652,4176,294912,298017,4466808,257,297220,288809,297845]

theorem envBound30505 : H12AffineFastState.Bounded env30505 := by
  intro p hp
  have h : env30505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30504_30505 : H12AffineEnvironment.transform 20 17680 env30504 = env30505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env30504 == env30505) = true)

def env30506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,17680,4194304,16,21762,8192,65,4229152,46108,4176,64808,61705,4216144,257,62508,5377,63069]

theorem envBound30506 : H12AffineFastState.Bounded env30506 := by
  intro p hp
  have h : env30506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30505_30506 : H12AffineEnvironment.transform 17 32040 env30505 = env30506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env30505 == env30506) = true)

theorem identity30506 : scanCanonicalize (H12AffineFastState.compose env30506 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62508) := by decide +kernel

theorem selectedBound30506 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1025,32769,17680,62508,16,21762,8192,65,31756,46108,4176,64808,61705,41340,257,62508,5377,63069]

theorem envBound30507 : H12AffineFastState.Bounded env30507 := by
  intro p hp
  have h : env30507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30506_30507 : H12AffineEnvironment.transform 21 62508 env30506 = env30507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62508 env30506 == env30507) = true)

theorem identity30507 : scanCanonicalize (H12AffineFastState.compose env30507 (packedSelected [3,4,5,9,10,11,12,14,15,16,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound30507 : packedSelected [3,4,5,9,10,11,12,14,15,16,18,23,32] rootPS < 2^1333 := by decide +kernel

def env30508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8202,16400,32040,1025,29992,17680,261,16,21762,8192,65,31756,16693,4176,2049,1056,21589,257,261,5377,884]

theorem envBound30508 : H12AffineFastState.Bounded env30508 := by
  intro p hp
  have h : env30508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30507_30508 : H12AffineEnvironment.transform 14 29993 env30507 = env30508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env30507 == env30508) = true)

theorem identity30508 : scanCanonicalize (H12AffineFastState.compose env30508 (packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound30508 : packedSelected [0,2,4,6,7,9,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env30509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21840,115,16400,23889,1025,21841,17680,261,16,21762,121,65,23669,16693,4176,2049,1056,21589,257,261,5377,884]

theorem envBound30509 : H12AffineFastState.Bounded env30509 := by
  intro p hp
  have h : env30509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30508_30509 : H12AffineEnvironment.transform 12 121 env30508 = env30509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env30508 == env30509) = true)

theorem identity30509 : scanCanonicalize (H12AffineFastState.compose env30509 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30509 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env30510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,80,115,5392,2129,1025,81,4112,261,16,2,121,65,2421,5173,4176,2049,1056,341,257,261,5377,884]

theorem envBound30510 : H12AffineFastState.Bounded env30510 := by
  intro p hp
  have h : env30510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30509_30510 : H12AffineEnvironment.transform 13 5376 env30509 = env30510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30509 == env30510) = true)

theorem identity30510 : scanCanonicalize (H12AffineFastState.compose env30510 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30510 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30511 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5376,1,34,5392,2048,1025,0,4112,261,16,2,40,16,2340,5173,4097,2049,1056,260,257,261,5377,805]

theorem envBound30511 : H12AffineFastState.Bounded env30511 := by
  intro p hp
  have h : env30511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30510_30511 : H12AffineEnvironment.transform 5 17 env30510 = env30511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30510 == env30511) = true)

theorem identity30511 : scanCanonicalize (H12AffineFastState.compose env30511 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30511 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30512 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8,5376,1,2,5392,2048,1025,0,4112,261,16,2,8,16,2308,5141,4097,2049,1024,260,257,261,5377,773]

theorem envBound30512 : H12AffineFastState.Bounded env30512 := by
  intro p hp
  have h : env30512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30511_30512 : H12AffineEnvironment.transform 4 0 env30511 = env30512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30511 == env30512) = true)

def env30513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,17680,4194304,16,21763,8192,65,4229152,46109,4176,64809,61704,4216145,257,62509,5376,63068]

theorem envBound30513 : H12AffineFastState.Bounded env30513 := by
  intro p hp
  have h : env30513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30505_30513 : H12AffineEnvironment.transform 17 32041 env30505 = env30513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env30505 == env30513) = true)

theorem identity30513 : scanCanonicalize (H12AffineFastState.compose env30513 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound30513 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32041,1025,32769,17680,112,16,21763,8192,65,34896,46109,4176,64809,61704,21793,257,62509,5376,63068]

theorem envBound30514 : H12AffineFastState.Bounded env30514 := by
  intro p hp
  have h : env30514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30513_30514 : H12AffineEnvironment.transform 21 112 env30513 = env30514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env30513 == env30514) = true)

theorem identity30514 : scanCanonicalize (H12AffineFastState.compose env30514 (packedSelected [1,4,5,9,10,12,14,15,16,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound30514 : packedSelected [1,4,5,9,10,12,14,15,16,24,28] rootPS < 2^1333 := by decide +kernel

def env30515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,32768,8202,5172,10509,1025,32769,4404,112,16,295,8192,65,34896,46109,4176,43277,42284,261,257,40969,5376,41592]

theorem envBound30515 : H12AffineFastState.Bounded env30515 := by
  intro p hp
  have h : env30515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30514_30515 : H12AffineEnvironment.transform 13 5156 env30514 = env30515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env30514 == env30515) = true)

theorem identity30515 : scanCanonicalize (H12AffineFastState.compose env30515 (packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound30515 : packedSelected [0,2,3,5,6,7,10,11,12,15,20,23] rootPS < 2^1333 := by decide +kernel

def env30516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,1,8202,5172,10509,1025,0,4404,112,16,295,8192,65,2129,13340,4176,10508,9517,261,257,8200,5376,8825]

theorem envBound30516 : H12AffineFastState.Bounded env30516 := by
  intro p hp
  have h : env30516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30515_30516 : H12AffineEnvironment.transform 14 1 env30515 = env30516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env30515 == env30516) = true)

theorem identity30516 : scanCanonicalize (H12AffineFastState.compose env30516 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30516 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env30517 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,1,8202,5172,10280,1025,0,4113,112,16,2,8192,65,2129,13340,4176,10281,9224,32,36,8200,5157,8825]

theorem envBound30517 : H12AffineFastState.Bounded env30517 := by
  intro p hp
  have h : env30517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30516_30517 : H12AffineEnvironment.transform 7 37 env30516 = env30517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30516 == env30517) = true)

theorem identity30517 : scanCanonicalize (H12AffineFastState.compose env30517 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30517 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30518 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5156,1,8202,5172,10280,1025,0,4113,32,16,2,8192,17,2049,13340,4096,10281,9224,32,36,8200,5157,8745]

theorem envBound30518 : H12AffineFastState.Bounded env30518 := by
  intro p hp
  have h : env30518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30517_30518 : H12AffineEnvironment.transform 5 16 env30517 = env30518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30517 == env30518) = true)

theorem identity30518 : scanCanonicalize (H12AffineFastState.compose env30518 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound30518 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env30519 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1025,0,4113,32,16,2,40,17,2049,5172,4096,2049,1056,32,36,32,5157,513]

theorem envBound30519 : H12AffineFastState.Bounded env30519 := by
  intro p hp
  have h : env30519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30518_30519 : H12AffineEnvironment.transform 12 40 env30518 = env30519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env30518 == env30519) = true)

theorem identity30519 : scanCanonicalize (H12AffineFastState.compose env30519 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30520 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1077,40,17,1,34,1,2048,1025,0,1060,32,16,2,40,17,2049,1,1077,2049,1056,32,36,32,16,513]

theorem envBound30520 : H12AffineFastState.Bounded env30520 := by
  intro p hp
  have h : env30520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30519_30520 : H12AffineEnvironment.transform 11 1077 env30519 = env30520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env30519 == env30520) = true)

theorem identity30520 : scanCanonicalize (H12AffineFastState.compose env30520 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30520 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30521 : List Nat := [2,4,8,16,32,16,8,37,0,1024,2048,1077,40,17,1,34,1,2048,1025,0,1060,32,16,2,40,17,2049,1,1077,2049,1056,32,36,32,16,1]

theorem envBound30521 : H12AffineFastState.Bounded env30521 := by
  intro p hp
  have h : env30521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30520_30521 : H12AffineEnvironment.transform 8 0 env30520 = env30521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30520 == env30521) = true)

theorem identity30521 : scanCanonicalize (H12AffineFastState.compose env30521 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound30521 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30522 : List Nat := [2,4,8,16,32,16,8,37,0,1024,17,1077,40,17,1,34,1,17,1025,0,1060,32,16,2,40,17,16,1,1077,16,1056,32,36,32,16,1]

theorem envBound30522 : H12AffineFastState.Bounded env30522 := by
  intro p hp
  have h : env30522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30521_30522 : H12AffineEnvironment.transform 10 17 env30521 = env30522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env30521 == env30522) = true)

theorem identity30522 : scanCanonicalize (H12AffineFastState.compose env30522 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30522 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30523 : List Nat := [2,4,8,16,32,16,8,37,0,53,17,0,40,17,1,34,1,17,52,0,17,32,16,2,40,17,16,1,0,16,21,32,36,32,16,1]

theorem envBound30523 : H12AffineFastState.Bounded env30523 := by
  intro p hp
  have h : env30523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30522_30523 : H12AffineEnvironment.transform 9 53 env30522 = env30523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30522 == env30523) = true)

theorem identity30523 : scanCanonicalize (H12AffineFastState.compose env30523 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30524 : List Nat := [2,4,8,16,16,16,8,21,0,5,17,0,24,17,1,18,1,17,4,0,17,16,16,2,24,17,16,1,0,16,21,16,20,16,16,1]

theorem envBound30524 : H12AffineFastState.Bounded env30524 := by
  intro p hp
  have h : env30524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30523_30524 : H12AffineEnvironment.transform 4 16 env30523 = env30524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30523 == env30524) = true)

def env30525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,272427,8193,65,4302890,2468910,2118977,294913,371755,6638946,257,2485279,2428211,297844]

theorem envBound30525 : H12AffineFastState.Bounded env30525 := by
  intro p hp
  have h : env30525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30502_30525 : H12AffineEnvironment.transform 6 9 env30502 = env30525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30502 == env30525) = true)

theorem identity30525 : scanCanonicalize (H12AffineFastState.compose env30525 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound30525 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41310,8193,65,4302890,2172251,2118977,2420,75102,6407191,257,2188650,2196550,513]

theorem envBound30526 : H12AffineFastState.Bounded env30526 := by
  intro p hp
  have h : env30526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30525_30526 : H12AffineEnvironment.transform 17 35189 env30525 = env30526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env30525 == env30526) = true)

theorem identity30526 : scanCanonicalize (H12AffineFastState.compose env30526 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound30526 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env30527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115734,4194304,17,41310,8193,65,4302890,57677,102743,2420,75102,4194305,257,41340,16464,513]

theorem envBound30527 : H12AffineFastState.Bounded env30527 := by
  intro p hp
  have h : env30527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30526_30527 : H12AffineEnvironment.transform 20 115734 env30526 = env30527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env30526 == env30527) = true)

def env30528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91198,4194304,17,374,8193,65,4261890,16741,78207,2420,75102,4194305,257,340,16464,513]

theorem envBound30528 : H12AffineFastState.Bounded env30528 := by
  intro p hp
  have h : env30528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30527_30528 : H12AffineEnvironment.transform 14 8232 env30527 = env30528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env30527 == env30528) = true)

theorem identity30528 : scanCanonicalize (H12AffineFastState.compose env30528 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30528 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env30529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,373,65536,16400,2048,1025,372,83299,4194304,17,374,348,65,4261890,16741,69666,2420,66563,4194305,257,340,16464,513]

theorem envBound30529 : H12AffineFastState.Bounded env30529 := by
  intro p hp
  have h : env30529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30528_30529 : H12AffineEnvironment.transform 12 349 env30528 = env30529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30528 == env30529) = true)

theorem identity30529 : scanCanonicalize (H12AffineFastState.compose env30529 (packedSelected [2,4,6,7,9,11,18,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30529 : packedSelected [2,4,6,7,9,11,18,27] rootPS < 2^1333 := by decide +kernel

def env30530 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,0,65536,16400,2048,1025,1,82966,4194304,17,3,41,65,4261890,16400,69666,2049,66563,4194305,116,33,16464,513]

theorem envBound30530 : H12AffineFastState.Bounded env30530 := by
  intro p hp
  have h : env30530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30529_30530 : H12AffineEnvironment.transform 7 117 env30529 = env30530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30529 == env30530) = true)

theorem identity30530 : scanCanonicalize (H12AffineFastState.compose env30530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound30530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30531 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,16384,0,34,16400,2048,1025,1,17460,4194304,17,3,41,65,4196384,16400,4096,2049,1057,4194305,116,33,16464,513]

theorem envBound30531 : H12AffineFastState.Bounded env30531 := by
  intro p hp
  have h : env30531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30530_30531 : H12AffineEnvironment.transform 15 34 env30530 = env30531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env30530 == env30531) = true)

theorem identity30531 : scanCanonicalize (H12AffineFastState.compose env30531 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30531 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30532 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,16384,0,34,16400,2048,1025,1,17460,4194304,17,3,41,16,4196384,16400,4096,2049,1057,4194305,37,33,16385,513]

theorem envBound30532 : H12AffineFastState.Bounded env30532 := by
  intro p hp
  have h : env30532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30531_30532 : H12AffineEnvironment.transform 5 17 env30531 = env30532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30531 == env30532) = true)

theorem identity30532 : scanCanonicalize (H12AffineFastState.compose env30532 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound30532 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30533 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,4112,4194304,17,3,41,16,4196384,5172,4096,2049,1057,4194305,37,33,5157,513]

theorem envBound30533 : H12AffineFastState.Bounded env30533 := by
  intro p hp
  have h : env30533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30532_30533 : H12AffineEnvironment.transform 13 5156 env30532 = env30533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env30532 == env30533) = true)

theorem identity30533 : scanCanonicalize (H12AffineFastState.compose env30533 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30533 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30534 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5156,0,34,5172,2048,1025,1,4112,32,17,3,41,16,2048,5172,4096,2049,1057,33,37,33,5157,513]

theorem envBound30534 : H12AffineFastState.Bounded env30534 := by
  intro p hp
  have h : env30534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30533_30534 : H12AffineEnvironment.transform 21 32 env30533 = env30534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30533 == env30534) = true)

theorem identity30534 : scanCanonicalize (H12AffineFastState.compose env30534 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30535 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,8,5124,0,2,5140,2048,1025,1,4112,0,17,3,9,16,2048,5140,4096,2049,1025,1,5,1,5125,513]

theorem envBound30535 : H12AffineFastState.Bounded env30535 := by
  intro p hp
  have h : env30535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30534_30535 : H12AffineEnvironment.transform 4 0 env30534 = env30535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30534 == env30535) = true)

theorem identity30535 : scanCanonicalize (H12AffineFastState.compose env30535 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound30535 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30536 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,1029,8,1,0,2,17,2048,1025,1,1045,0,17,3,9,16,2048,17,1029,2049,1025,1,5,1,0,513]

theorem envBound30536 : H12AffineFastState.Bounded env30536 := by
  intro p hp
  have h : env30536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30535_30536 : H12AffineEnvironment.transform 11 1029 env30535 = env30536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env30535 == env30536) = true)

theorem identity30536 : scanCanonicalize (H12AffineFastState.compose env30536 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30537 : List Nat := [2,4,8,16,0,17,9,4,17,1024,2048,1029,8,1,0,2,17,2048,1025,1,1045,0,17,3,9,16,2048,17,1029,2049,1025,1,5,1,0,16]

theorem envBound30537 : H12AffineFastState.Bounded env30537 := by
  intro p hp
  have h : env30537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30536_30537 : H12AffineEnvironment.transform 8 17 env30536 = env30537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30536 == env30537) = true)

theorem identity30537 : scanCanonicalize (H12AffineFastState.compose env30537 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound30537 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30538 : List Nat := [2,4,8,16,0,17,9,4,17,1024,1028,1029,8,1,0,2,17,1028,1025,1,1045,0,17,3,9,16,1028,17,1029,1029,1025,1,5,1,0,16]

theorem envBound30538 : H12AffineFastState.Bounded env30538 := by
  intro p hp
  have h : env30538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30537_30538 : H12AffineEnvironment.transform 10 1028 env30537 = env30538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env30537 == env30538) = true)

theorem identity30538 : scanCanonicalize (H12AffineFastState.compose env30538 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30538 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30539 : List Nat := [2,4,8,16,0,17,9,4,17,20,16,17,8,1,0,2,17,16,21,1,1,0,17,3,9,16,16,17,17,17,21,1,5,1,0,16]

theorem envBound30539 : H12AffineFastState.Bounded env30539 := by
  intro p hp
  have h : env30539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30538_30539 : H12AffineEnvironment.transform 9 20 env30538 = env30539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30538 == env30539) = true)

theorem identity30539 : scanCanonicalize (H12AffineFastState.compose env30539 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30539 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30540 : List Nat := [2,4,8,1,0,0,9,4,0,5,1,0,8,1,0,2,0,1,4,1,1,0,0,3,9,1,1,0,0,0,4,1,5,1,0,1]

theorem envBound30540 : H12AffineFastState.Bounded env30540 := by
  intro p hp
  have h : env30540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30539_30540 : H12AffineEnvironment.transform 3 1 env30539 = env30540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30539 == env30540) = true)

def env30541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91199,4194304,17,375,8193,65,4261891,16740,78206,2420,75102,4194305,257,341,16464,513]

theorem envBound30541 : H12AffineFastState.Bounded env30541 := by
  intro p hp
  have h : env30541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30527_30541 : H12AffineEnvironment.transform 14 8233 env30527 = env30541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env30527 == env30541) = true)

theorem identity30541 : scanCanonicalize (H12AffineFastState.compose env30541 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30541 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env30542 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,65536,16400,2421,1025,1,82966,4194304,17,375,40,65,4261891,16740,69975,2420,66935,4194305,257,341,16464,513]

theorem envBound30542 : H12AffineFastState.Bounded env30542 := by
  intro p hp
  have h : env30542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30541_30542 : H12AffineEnvironment.transform 12 41 env30541 = env30542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30541 == env30542) = true)

theorem identity30542 : scanCanonicalize (H12AffineFastState.compose env30542 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30542 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30543 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,0,65536,16400,2421,1025,1,82966,32,17,375,40,65,67619,16740,69975,2420,66935,33,257,341,16464,513]

theorem envBound30543 : H12AffineFastState.Bounded env30543 := by
  intro p hp
  have h : env30543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30542_30543 : H12AffineEnvironment.transform 21 32 env30542 = env30543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30542 == env30543) = true)

theorem identity30543 : scanCanonicalize (H12AffineFastState.compose env30543 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30543 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env30544 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,0,65536,16400,2341,1025,1,82966,32,17,295,40,17,67619,16692,69895,2340,66855,33,257,261,16384,513]

theorem envBound30544 : H12AffineFastState.Bounded env30544 := by
  intro p hp
  have h : env30544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30543_30544 : H12AffineEnvironment.transform 5 16 env30543 = env30544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30543 == env30544) = true)

theorem identity30544 : scanCanonicalize (H12AffineFastState.compose env30544 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound30544 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30545 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,0,262,16400,2341,1025,1,17680,32,17,295,40,17,2341,16692,4097,2340,1057,33,257,261,16384,513]

theorem envBound30545 : H12AffineFastState.Bounded env30545 := by
  intro p hp
  have h : env30545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30544_30545 : H12AffineEnvironment.transform 15 262 env30544 = env30545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env30544 == env30545) = true)

theorem identity30545 : scanCanonicalize (H12AffineFastState.compose env30545 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound30545 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30546 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,6160,0,262,6144,2341,1025,1,7424,32,17,295,40,17,2341,6436,4097,2340,1057,33,257,261,6160,513]

theorem envBound30546 : H12AffineFastState.Bounded env30546 := by
  intro p hp
  have h : env30546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30545_30546 : H12AffineEnvironment.transform 13 6160 env30545 = env30546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env30545 == env30546) = true)

theorem identity30546 : scanCanonicalize (H12AffineFastState.compose env30546 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound30546 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30547 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2357,41,293,0,262,309,2341,1025,1,1077,32,17,295,40,17,2341,17,2356,2340,1057,33,257,261,293,513]

theorem envBound30547 : H12AffineFastState.Bounded env30547 := by
  intro p hp
  have h : env30547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30546_30547 : H12AffineEnvironment.transform 11 2357 env30546 = env30547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env30546 == env30547) = true)

theorem identity30547 : scanCanonicalize (H12AffineFastState.compose env30547 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30547 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env30548 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,2357,41,293,0,262,309,2341,52,1,0,32,17,295,40,17,2341,17,2356,2340,20,33,257,261,293,513]

theorem envBound30548 : H12AffineFastState.Bounded env30548 := by
  intro p hp
  have h : env30548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30547_30548 : H12AffineEnvironment.transform 9 53 env30547 = env30548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30547 == env30548) = true)

theorem identity30548 : scanCanonicalize (H12AffineFastState.compose env30548 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound30548 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30549 : List Nat := [2,4,8,16,32,16,9,256,512,53,293,16,41,293,0,262,309,0,52,1,0,32,17,295,40,17,0,17,17,1,20,33,257,261,293,513]

theorem envBound30549 : H12AffineFastState.Bounded env30549 := by
  intro p hp
  have h : env30549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30548_30549 : H12AffineEnvironment.transform 10 293 env30548 = env30549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env30548 == env30549) = true)

def env30550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302890,2468910,2119113,295048,371754,6638946,257,2485399,2428210,297980]

theorem envBound30550 : H12AffineFastState.Bounded env30550 := by
  intro p hp
  have h : env30550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30501_30550 : H12AffineEnvironment.transform 16 16401 env30501 = env30550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30501 == env30550) = true)

theorem identity30550 : scanCanonicalize (H12AffineFastState.compose env30550 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound30550 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,153,138,8328,65,4302890,2196486,2119113,43168,99330,6382922,257,2213055,2172186,41940]

theorem envBound30551 : H12AffineFastState.Bounded env30551 := by
  intro p hp
  have h : env30551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30550_30551 : H12AffineEnvironment.transform 17 10280 env30550 = env30551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30550 == env30551) = true)

def env30552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,17,2,8192,65,4302890,2196486,2118977,43048,99330,6382922,257,2212919,2172186,41820]

theorem envBound30552 : H12AffineFastState.Bounded env30552 := by
  intro p hp
  have h : env30552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30551_30552 : H12AffineEnvironment.transform 6 8 env30551 = env30552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30551 == env30552) = true)

theorem identity30552 : scanCanonicalize (H12AffineFastState.compose env30552 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 58729) := by decide +kernel

theorem selectedBound30552 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env30553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58729,4194304,17,2,8192,65,4302890,90479,45096,43048,99330,4292643,257,74078,114803,41820]

theorem envBound30553 : H12AffineFastState.Bounded env30553 := by
  intro p hp
  have h : env30553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30552_30553 : H12AffineEnvironment.transform 20 58729 env30552 = env30553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58729 env30552 == env30553) = true)

theorem identity30553 : scanCanonicalize (H12AffineFastState.compose env30553 (packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30553 : packedSelected [0,3,4,7,8,12,15,16,17,19,20,22,24,28] rootPS < 2^1333 := by decide +kernel

def env30554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58729,4194304,17,2,8192,65,4229152,16741,45096,43048,41992,4235305,257,340,57465,41820]

theorem envBound30554 : H12AffineFastState.Bounded env30554 := by
  intro p hp
  have h : env30554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30553_30554 : H12AffineEnvironment.transform 15 8202 env30553 = env30554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30553 == env30554) = true)

theorem identity30554 : scanCanonicalize (H12AffineFastState.compose env30554 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41049) := by decide +kernel

theorem selectedBound30554 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env30555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,58729,41049,17,2,8192,65,10361,16741,45096,43048,41992,112,257,340,57465,41820]

theorem envBound30555 : H12AffineFastState.Bounded env30555 := by
  intro p hp
  have h : env30555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30554_30555 : H12AffineEnvironment.transform 21 41049 env30554 = env30555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41049 env30554 == env30555) = true)

theorem identity30555 : scanCanonicalize (H12AffineFastState.compose env30555 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound30555 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8313,8202,16401,10280,1025,8312,17680,32,17,2,8192,65,10361,16741,4177,2129,1137,112,257,340,16384,805]

theorem envBound30556 : H12AffineFastState.Bounded env30556 := by
  intro p hp
  have h : env30556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30555_30556 : H12AffineEnvironment.transform 14 8313 env30555 = env30556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env30555 == env30556) = true)

theorem identity30556 : scanCanonicalize (H12AffineFastState.compose env30556 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30556 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,80,35,16401,2049,1025,81,17680,32,17,2,41,65,2128,16741,4177,2129,1137,112,257,340,16384,805]

theorem envBound30557 : H12AffineFastState.Bounded env30557 := by
  intro p hp
  have h : env30557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30556_30557 : H12AffineEnvironment.transform 12 41 env30556 = env30557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30556 == env30557) = true)

theorem identity30557 : scanCanonicalize (H12AffineFastState.compose env30557 (packedSelected [0,3,5,6,7,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30557 : packedSelected [0,3,5,6,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30558 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,1,35,16401,2049,1025,0,17680,32,17,2,41,16,2049,16692,4096,2048,1056,33,257,261,16384,805]

theorem envBound30558 : H12AffineFastState.Bounded env30558 := by
  intro p hp
  have h : env30558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30557_30558 : H12AffineEnvironment.transform 5 17 env30557 = env30558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30557 == env30558) = true)

theorem identity30558 : scanCanonicalize (H12AffineFastState.compose env30558 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30558 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env30559 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,1,35,16401,2049,1025,0,17461,32,17,2,41,16,2049,16401,4096,2048,1056,33,36,32,16384,512]

theorem envBound30559 : H12AffineFastState.Bounded env30559 := by
  intro p hp
  have h : env30559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30558_30559 : H12AffineEnvironment.transform 7 37 env30558 = env30559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30558 == env30559) = true)

theorem identity30559 : scanCanonicalize (H12AffineFastState.compose env30559 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30559 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30560 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,16384,1,3,16401,2049,1025,0,17429,0,17,2,9,16,2049,16401,4096,2048,1024,1,4,0,16384,512]

theorem envBound30560 : H12AffineFastState.Bounded env30560 := by
  intro p hp
  have h : env30560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30559_30560 : H12AffineEnvironment.transform 4 0 env30559 = env30560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30559 == env30560) = true)

theorem identity30560 : scanCanonicalize (H12AffineFastState.compose env30560 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound30560 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30561 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,1,3,5140,2049,1025,0,4112,0,17,2,9,16,2049,5140,4096,2048,1024,1,4,0,5125,512]

theorem envBound30561 : H12AffineFastState.Bounded env30561 := by
  intro p hp
  have h : env30561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30560_30561 : H12AffineEnvironment.transform 13 5125 env30560 = env30561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env30560 == env30561) = true)

def env30562 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,1,3,1028,2049,1025,0,0,0,17,2,9,16,2049,1028,16,2048,1024,1,4,0,1045,512]

theorem envBound30562 : H12AffineFastState.Bounded env30562 := by
  intro p hp
  have h : env30562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30561_30562 : H12AffineEnvironment.transform 11 16 env30561 = env30562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30561 == env30562) = true)

theorem identity30562 : scanCanonicalize (H12AffineFastState.compose env30562 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound30562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30563 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,16,9,1045,1,3,1028,1045,1025,0,0,0,17,2,9,16,1045,1028,16,1044,1024,1,4,0,1045,512]

theorem envBound30563 : H12AffineFastState.Bounded env30563 := by
  intro p hp
  have h : env30563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30562_30563 : H12AffineEnvironment.transform 10 1044 env30562 = env30563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env30562 == env30563) = true)

def env30564 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,9,1,1,3,16,1,21,0,0,0,17,2,9,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound30564 : H12AffineFastState.Bounded env30564 := by
  intro p hp
  have h : env30564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30563_30564 : H12AffineEnvironment.transform 9 20 env30563 = env30564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30563 == env30564) = true)

theorem identity30564 : scanCanonicalize (H12AffineFastState.compose env30564 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound30564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30565 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,5,9,1,1,3,5,1,0,0,0,0,4,2,9,5,1,5,5,0,1,1,4,0,1,512]

theorem envBound30565 : H12AffineFastState.Bounded env30565 := by
  intro p hp
  have h : env30565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30564_30565 : H12AffineEnvironment.transform 3 5 env30564 = env30565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env30564 == env30565) = true)

def leafEnv30565 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,5,9,1,1,3,5,1,0,0,0,0,4,2,0,9,1,5,1,5,5,0,1,1,4,0,5,3,1,512,1,0,0]

def active30565 : List Nat := [0,1,2,8]

def tree30565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30565 : H12WitnessSearch.Good tree30565 := H12GlobalWitnessIndex.good

theorem leafIdentity30565 : H12AffineFastState.composeSystem env30565 rootObs = leafEnv30565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30565 rootObs == leafEnv30565) = true)

theorem terminalChecked30565 : H12PackedTerminal.terminalCheckFast leafEnv30565 active30565 tree30565 = true := by decide +kernel

def env30566 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,16,9,0,1,3,17,0,20,0,0,0,17,2,9,16,0,17,16,1,21,1,4,0,0,512]

theorem envBound30566 : H12AffineFastState.Bounded env30566 := by
  intro p hp
  have h : env30566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30563_30566 : H12AffineEnvironment.transform 9 21 env30563 = env30566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30563 == env30566) = true)

theorem identity30566 : scanCanonicalize (H12AffineFastState.compose env30566 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound30566 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30567 : List Nat := [2,4,8,16,0,17,8,5,30,21,1,16,9,0,1,3,17,0,20,0,0,0,17,2,9,16,0,17,16,1,21,1,4,0,0,30]

theorem envBound30567 : H12AffineFastState.Bounded env30567 := by
  intro p hp
  have h : env30567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30566_30567 : H12AffineEnvironment.transform 8 30 env30566 = env30567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env30566 == env30567) = true)

def leafEnv30567 : List Nat := [2,4,8,16,0,17,8,5,30,21,1,16,9,0,1,3,17,0,20,0,0,0,17,2,20,9,1,16,0,17,16,1,21,1,4,0,5,3,0,30,1,0,0]

def active30567 : List Nat := [0,1,2,3]

def tree30567 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30567 : H12WitnessSearch.Good tree30567 := H12GlobalWitnessIndex.good

theorem leafIdentity30567 : H12AffineFastState.composeSystem env30567 rootObs = leafEnv30567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30567 rootObs == leafEnv30567) = true)

theorem terminalChecked30567 : H12PackedTerminal.terminalCheckFast leafEnv30567 active30567 tree30567 = true := by decide +kernel

def env30568 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,1,3,1029,2049,1025,0,1,0,17,2,9,16,2049,1029,17,2048,1024,1,4,0,1044,512]

theorem envBound30568 : H12AffineFastState.Bounded env30568 := by
  intro p hp
  have h : env30568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30561_30568 : H12AffineEnvironment.transform 11 17 env30561 = env30568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30561 == env30568) = true)

theorem identity30568 : scanCanonicalize (H12AffineFastState.compose env30568 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30569 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,9,1044,1,3,1029,1,1025,0,1,0,17,2,9,16,1,1029,17,0,1024,1,4,0,1044,512]

theorem envBound30569 : H12AffineFastState.Bounded env30569 := by
  intro p hp
  have h : env30569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30568_30569 : H12AffineEnvironment.transform 10 0 env30568 = env30569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30568 == env30569) = true)

def env30570 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,0,1,3,17,1,21,0,1,0,17,2,9,16,1,17,17,0,20,1,4,0,0,512]

theorem envBound30570 : H12AffineFastState.Bounded env30570 := by
  intro p hp
  have h : env30570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30570 : H12AffineEnvironment.transform 9 20 env30569 = env30570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30569 == env30570) = true)

theorem identity30570 : scanCanonicalize (H12AffineFastState.compose env30570 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound30570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30571 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,1,3,4,1,0,0,1,0,4,2,9,5,1,4,4,0,1,1,4,0,0,512]

theorem envBound30571 : H12AffineFastState.Bounded env30571 := by
  intro p hp
  have h : env30571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30570_30571 : H12AffineEnvironment.transform 3 5 env30570 = env30571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env30570 == env30571) = true)

def leafEnv30571 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,1,3,4,1,0,0,1,0,4,2,0,9,1,5,1,4,4,0,1,1,4,0,5,3,0,512,1,1,0]

def active30571 : List Nat := [0,1,2,8]

def tree30571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30571 : H12WitnessSearch.Good tree30571 := H12GlobalWitnessIndex.good

theorem leafIdentity30571 : H12AffineFastState.composeSystem env30571 rootObs = leafEnv30571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30571 rootObs == leafEnv30571) = true)

theorem terminalChecked30571 : H12PackedTerminal.terminalCheckFast leafEnv30571 active30571 tree30571 = true := by decide +kernel

def env30572 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,1,3,16,1,20,0,1,0,17,2,9,16,1,16,17,0,21,1,4,0,1,512]

theorem envBound30572 : H12AffineFastState.Bounded env30572 := by
  intro p hp
  have h : env30572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30569_30572 : H12AffineEnvironment.transform 9 21 env30569 = env30572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30569 == env30572) = true)

theorem identity30572 : scanCanonicalize (H12AffineFastState.compose env30572 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound30572 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30573 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,9,1,1,3,16,1,20,0,1,0,17,2,9,16,1,16,17,0,21,1,4,0,1,31]

theorem envBound30573 : H12AffineFastState.Bounded env30573 := by
  intro p hp
  have h : env30573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30572_30573 : H12AffineEnvironment.transform 8 31 env30572 = env30573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env30572 == env30573) = true)

def leafEnv30573 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,9,1,1,3,16,1,20,0,1,0,17,2,20,9,1,16,1,16,17,0,21,1,4,0,5,3,1,31,1,1,0]

def active30573 : List Nat := [0,1,2,3]

def tree30573 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood30573 : H12WitnessSearch.Good tree30573 := H12GlobalWitnessIndex.good

theorem leafIdentity30573 : H12AffineFastState.composeSystem env30573 rootObs = leafEnv30573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env30573 rootObs == leafEnv30573) = true)

theorem terminalChecked30573 : H12PackedTerminal.terminalCheckFast leafEnv30573 active30573 tree30573 = true := by decide +kernel

def env30574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,16,3,8193,65,4302890,2196486,2118976,43049,99330,6382922,257,2212918,2172186,41821]

theorem envBound30574 : H12AffineFastState.Bounded env30574 := by
  intro p hp
  have h : env30574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30551_30574 : H12AffineEnvironment.transform 6 9 env30551 = env30574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30551 == env30574) = true)

theorem identity30574 : scanCanonicalize (H12AffineFastState.compose env30574 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30574 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,16,3,8193,65,4262262,2172250,2118976,2421,75102,6382922,257,2188650,2172186,513]

theorem envBound30575 : H12AffineFastState.Bounded env30575 := by
  intro p hp
  have h : env30575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30574_30575 : H12AffineEnvironment.transform 14 8540 env30574 = env30575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30574 == env30575) = true)

theorem identity30575 : scanCanonicalize (H12AffineFastState.compose env30575 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30575 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,4194304,16,3,8193,65,4204925,2098513,2118976,2421,1365,6309185,257,2114913,2098449,513]

theorem envBound30576 : H12AffineFastState.Bounded env30576 := by
  intro p hp
  have h : env30576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30575_30576 : H12AffineEnvironment.transform 15 8203 env30575 = env30576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30575 == env30576) = true)

theorem identity30576 : scanCanonicalize (H12AffineFastState.compose env30576 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound30576 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30577 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,33,16,3,8193,65,10588,2098513,2118976,2421,1365,2114912,257,2114913,2098449,513]

theorem envBound30577 : H12AffineFastState.Bounded env30577 := by
  intro p hp
  have h : env30577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30576_30577 : H12AffineEnvironment.transform 21 33 env30576 = env30577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env30576 == env30577) = true)

theorem identity30577 : scanCanonicalize (H12AffineFastState.compose env30577 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound30577 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30578 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,17681,33,16,3,8193,65,10588,16448,4177,2421,1365,113,257,112,16384,513]

theorem envBound30578 : H12AffineFastState.Bounded env30578 := by
  intro p hp
  have h : env30578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30577_30578 : H12AffineEnvironment.transform 20 17681 env30577 = env30578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env30577 == env30578) = true)

theorem identity30578 : scanCanonicalize (H12AffineFastState.compose env30578 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound30578 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30579 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13357,8540,8203,13372,10280,1025,8541,12604,33,16,3,8193,65,10588,13421,4177,2421,1365,113,257,112,13357,513]

theorem envBound30579 : H12AffineFastState.Bounded env30579 := by
  intro p hp
  have h : env30579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30578_30579 : H12AffineEnvironment.transform 13 13357 env30578 = env30579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env30578 == env30579) = true)

theorem identity30579 : scanCanonicalize (H12AffineFastState.compose env30579 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30579 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30580 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5489,0,343,5472,2420,1025,1,4192,33,16,3,349,65,2048,5425,4177,2421,1365,113,257,112,5489,513]

theorem envBound30580 : H12AffineFastState.Bounded env30580 := by
  intro p hp
  have h : env30580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30579_30580 : H12AffineEnvironment.transform 12 348 env30579 = env30580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30579 == env30580) = true)

theorem identity30580 : scanCanonicalize (H12AffineFastState.compose env30580 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3620) := by decide +kernel

theorem selectedBound30580 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30581 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3620,348,2901,0,343,2884,2420,1025,1,3652,33,16,3,349,65,2048,2837,3701,2421,1365,113,257,112,2901,513]

theorem envBound30581 : H12AffineFastState.Bounded env30581 := by
  intro p hp
  have h : env30581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30580_30581 : H12AffineEnvironment.transform 11 3620 env30580 = env30581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3620 env30580 == env30581) = true)

theorem identity30581 : scanCanonicalize (H12AffineFastState.compose env30581 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound30581 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30582 : List Nat := [2,4,8,16,32,64,9,256,512,1024,277,1841,348,576,0,343,593,97,1025,1,1873,33,16,3,349,65,277,512,1888,96,1365,113,257,112,576,513]

theorem envBound30582 : H12AffineFastState.Bounded env30582 := by
  intro p hp
  have h : env30582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30581_30582 : H12AffineEnvironment.transform 10 277 env30581 = env30582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env30581 == env30582) = true)

theorem identity30582 : scanCanonicalize (H12AffineFastState.compose env30582 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound30582 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30583 : List Nat := [2,4,8,16,32,64,9,256,512,565,277,260,348,576,0,343,593,97,564,1,356,33,16,3,349,65,277,512,341,96,864,113,257,112,576,513]

theorem envBound30583 : H12AffineFastState.Bounded env30583 := by
  intro p hp
  have h : env30583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30582_30583 : H12AffineEnvironment.transform 9 565 env30582 = env30583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env30582 == env30583) = true)

theorem identity30583 : scanCanonicalize (H12AffineFastState.compose env30583 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound30583 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env30584 : List Nat := [2,4,8,16,32,64,9,256,341,352,277,260,348,277,0,343,260,97,353,1,356,33,16,3,349,65,277,341,341,96,53,113,257,112,277,340]

theorem envBound30584 : H12AffineFastState.Bounded env30584 := by
  intro p hp
  have h : env30584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30583_30584 : H12AffineEnvironment.transform 8 341 env30583 = env30584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env30583 == env30584) = true)

theorem identity30584 : scanCanonicalize (H12AffineFastState.compose env30584 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound30584 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env30585 : List Nat := [2,4,8,16,32,64,9,15,90,111,26,11,83,26,0,88,11,97,110,1,107,33,16,3,82,65,26,90,90,96,53,113,14,112,26,91]

theorem envBound30585 : H12AffineFastState.Bounded env30585 := by
  intro p hp
  have h : env30585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30584_30585 : H12AffineEnvironment.transform 7 15 env30584 = env30585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env30584 == env30585) = true)

def env30586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272546,8328,65,4302891,2468910,2233817,295049,519226,6638946,257,2600071,2575650,445420]

theorem envBound30586 : H12AffineFastState.Bounded env30586 := by
  intro p hp
  have h : env30586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30500_30586 : H12AffineEnvironment.transform 22 147593 env30500 = env30586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env30500 == env30586) = true)

def env30587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272546,8328,65,4302891,2468910,2119113,295049,371754,6638946,257,2485399,2428210,297980]

theorem envBound30587 : H12AffineFastState.Bounded env30587 := by
  intro p hp
  have h : env30587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30586_30587 : H12AffineEnvironment.transform 16 16400 env30586 = env30587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env30586 == env30587) = true)

theorem identity30587 : scanCanonicalize (H12AffineFastState.compose env30587 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound30587 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16400,262144,1025,8660,2097152,4194304,153,272546,8328,65,4262398,2428411,2119113,270684,331263,6638946,257,2444610,2428210,272937]

theorem envBound30588 : H12AffineFastState.Bounded env30588 := by
  intro p hp
  have h : env30588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30587_30588 : H12AffineEnvironment.transform 14 8661 env30587 = env30588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env30587 == env30588) = true)

def env30589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16400,10400,1025,8660,2097152,4194304,153,2,8328,65,4262398,2172251,2119113,2556,75103,6383042,257,2188770,2172306,649]

theorem envBound30589 : H12AffineFastState.Bounded env30589 := by
  intro p hp
  have h : env30589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30588_30589 : H12AffineEnvironment.transform 17 10400 env30588 = env30589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30588 == env30589) = true)

theorem identity30589 : scanCanonicalize (H12AffineFastState.compose env30589 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30589 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16400,10400,1025,8660,2097152,4194304,153,2,8328,65,4204924,2098649,2119113,2556,1501,6309184,257,2114912,2098448,649]

theorem envBound30590 : H12AffineFastState.Bounded env30590 := by
  intro p hp
  have h : env30590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30589_30590 : H12AffineEnvironment.transform 15 8322 env30589 = env30590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30589 == env30590) = true)

theorem identity30590 : scanCanonicalize (H12AffineFastState.compose env30590 (packedSelected [1,4,5,7,9,10,12,15,16,17,20,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 8281) := by decide +kernel

theorem selectedBound30590 : packedSelected [1,4,5,7,9,10,12,15,16,17,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16400,10400,1025,8660,2097152,8281,153,2,8328,65,2341,2098649,2119113,2556,1501,2123033,257,2114912,2098448,649]

theorem envBound30591 : H12AffineFastState.Bounded env30591 := by
  intro p hp
  have h : env30591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30590_30591 : H12AffineEnvironment.transform 21 8281 env30590 = env30591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8281 env30590 == env30591) = true)

theorem identity30591 : scanCanonicalize (H12AffineFastState.compose env30591 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound30591 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env30592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,16384,292,115,16400,2129,1025,293,2097152,168,153,2,121,65,2341,2098649,2119113,2556,1501,2115048,257,2114912,2098448,649]

theorem envBound30592 : H12AffineFastState.Bounded env30592 := by
  intro p hp
  have h : env30592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30591_30592 : H12AffineEnvironment.transform 12 241 env30591 = env30592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env30591 == env30592) = true)

theorem identity30592 : scanCanonicalize (H12AffineFastState.compose env30592 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound30592 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env30593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5512,292,115,5528,2129,1025,293,2097152,168,153,2,121,65,2341,2098649,2097217,2556,1501,2101344,257,2101480,2098448,649]

theorem envBound30593 : H12AffineFastState.Bounded env30593 := by
  intro p hp
  have h : env30593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30592_30593 : H12AffineEnvironment.transform 13 5512 env30592 = env30593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env30592 == env30593) = true)

theorem identity30593 : scanCanonicalize (H12AffineFastState.compose env30593 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30593 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env30594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5512,292,115,5528,2129,1025,293,5457,168,153,2,121,65,2341,4232,5392,2556,1501,1329,257,1465,4161,649]

theorem envBound30594 : H12AffineFastState.Bounded env30594 := by
  intro p hp
  have h : env30594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30593_30594 : H12AffineEnvironment.transform 20 5457 env30593 = env30594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env30593 == env30594) = true)

theorem identity30594 : scanCanonicalize (H12AffineFastState.compose env30594 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30594 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30595 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,241,4249,292,115,4233,2129,272,293,4160,168,153,2,121,65,2341,4232,4097,2556,204,32,257,168,4161,649]

theorem envBound30595 : H12AffineFastState.Bounded env30595 := by
  intro p hp
  have h : env30595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30594_30595 : H12AffineEnvironment.transform 9 273 env30594 = env30595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30594 == env30595) = true)

theorem identity30595 : scanCanonicalize (H12AffineFastState.compose env30595 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound30595 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30596 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,4096,241,4249,216,115,4233,2129,236,217,4160,168,153,2,121,65,2265,4232,4097,2048,204,32,253,168,4161,649]

theorem envBound30596 : H12AffineFastState.Bounded env30596 := by
  intro p hp
  have h : env30596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30595_30596 : H12AffineEnvironment.transform 7 252 env30595 = env30596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env30595 == env30596) = true)

theorem identity30596 : scanCanonicalize (H12AffineFastState.compose env30596 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound30596 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30597 : List Nat := [2,4,8,16,32,64,128,252,512,237,2048,2112,241,2265,216,115,2249,2129,236,217,2048,168,153,2,121,65,2265,2248,2113,2048,204,32,253,168,2049,649]

theorem envBound30597 : H12AffineFastState.Bounded env30597 := by
  intro p hp
  have h : env30597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30596_30597 : H12AffineEnvironment.transform 11 2112 env30596 = env30597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env30596 == env30597) = true)

theorem identity30597 : scanCanonicalize (H12AffineFastState.compose env30597 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound30597 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30598 : List Nat := [2,4,8,16,32,64,128,252,512,237,80,16,241,137,216,115,153,1,236,217,80,168,153,2,121,65,137,152,17,80,204,32,253,168,81,649]

theorem envBound30598 : H12AffineFastState.Bounded env30598 := by
  intro p hp
  have h : env30598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30597_30598 : H12AffineEnvironment.transform 10 80 env30597 = env30598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env30597 == env30598) = true)

theorem identity30598 : scanCanonicalize (H12AffineFastState.compose env30598 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30598 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30599 : List Nat := [2,4,8,16,32,64,89,37,512,52,80,16,40,80,1,115,64,1,53,0,80,113,64,2,121,65,80,65,17,80,21,32,36,113,81,592]

theorem envBound30599 : H12AffineFastState.Bounded env30599 := by
  intro p hp
  have h : env30599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30598_30599 : H12AffineEnvironment.transform 6 89 env30598 = env30599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30598 == env30599) = true)

def env30600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16400,10401,1025,8660,2097152,4194304,153,3,8328,65,4262398,2172250,2119113,2557,75102,6383043,257,2188771,2172307,648]

theorem envBound30600 : H12AffineFastState.Bounded env30600 := by
  intro p hp
  have h : env30600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30588_30600 : H12AffineEnvironment.transform 17 10401 env30588 = env30600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30588 == env30600) = true)

theorem identity30600 : scanCanonicalize (H12AffineFastState.compose env30600 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30600 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env30601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4262263,2172250,2118976,2420,75102,6382922,257,2188650,2172186,513]

theorem envBound30601 : H12AffineFastState.Bounded env30601 := by
  intro p hp
  have h : env30601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30600_30601 : H12AffineEnvironment.transform 6 9 env30600 = env30601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30600 == env30601) = true)

theorem identity30601 : scanCanonicalize (H12AffineFastState.compose env30601 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30601 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098448,513]

theorem envBound30602 : H12AffineFastState.Bounded env30602 := by
  intro p hp
  have h : env30602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30601_30602 : H12AffineEnvironment.transform 15 8202 env30601 = env30602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30601 == env30602) = true)

theorem identity30602 : scanCanonicalize (H12AffineFastState.compose env30602 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30602 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,32,16,3,8193,65,10589,2098512,2118976,2420,1364,2114912,257,2114912,2098448,513]

theorem envBound30603 : H12AffineFastState.Bounded env30603 := by
  intro p hp
  have h : env30603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30602_30603 : H12AffineEnvironment.transform 21 32 env30602 = env30603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30602 == env30603) = true)

theorem identity30603 : scanCanonicalize (H12AffineFastState.compose env30603 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 25881) := by decide +kernel

theorem selectedBound30603 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env30604 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,25881,32,16,3,8193,65,10589,24649,12377,2420,1364,8313,257,8313,24585,513]

theorem envBound30604 : H12AffineFastState.Bounded env30604 := by
  intro p hp
  have h : env30604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30603_30604 : H12AffineEnvironment.transform 20 25881 env30603 = env30604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25881 env30603 == env30604) = true)

theorem identity30604 : scanCanonicalize (H12AffineFastState.compose env30604 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30604 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env30605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,342,16400,2420,1025,1,17477,32,16,3,349,65,2049,16661,4357,2420,1364,293,257,293,16725,513]

theorem envBound30605 : H12AffineFastState.Bounded env30605 := by
  intro p hp
  have h : env30605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30604_30605 : H12AffineEnvironment.transform 12 348 env30604 = env30605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30604 == env30605) = true)

theorem identity30605 : scanCanonicalize (H12AffineFastState.compose env30605 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30605 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env30606 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,4096,88,16384,0,82,16400,2160,1025,1,17477,32,16,3,89,65,2049,16401,4097,2160,1104,33,5,33,16465,513]

theorem envBound30606 : H12AffineFastState.Bounded env30606 := by
  intro p hp
  have h : env30606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30605_30606 : H12AffineEnvironment.transform 7 4 env30605 = env30606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30605 == env30606) = true)

theorem identity30606 : scanCanonicalize (H12AffineFastState.compose env30606 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound30606 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30607 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,577,88,16384,0,82,16400,2160,1025,1,17477,32,16,3,89,65,2049,16401,576,2160,1104,33,5,33,16465,513]

theorem envBound30607 : H12AffineFastState.Bounded env30607 := by
  intro p hp
  have h : env30607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30606_30607 : H12AffineEnvironment.transform 11 577 env30606 = env30607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env30606 == env30607) = true)

theorem identity30607 : scanCanonicalize (H12AffineFastState.compose env30607 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 2112) := by decide +kernel

theorem selectedBound30607 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30608 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,577,88,2112,0,82,2128,2160,1025,1,3077,32,16,3,89,65,2049,2129,576,2160,1104,33,5,33,2065,513]

theorem envBound30608 : H12AffineFastState.Bounded env30608 := by
  intro p hp
  have h : env30608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30607_30608 : H12AffineEnvironment.transform 13 2112 env30607 = env30608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2112 env30607 == env30608) = true)

def env30609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272546,8328,65,4302891,2468910,2119112,295049,371755,6638946,257,2485398,2428211,297981]

theorem envBound30609 : H12AffineFastState.Bounded env30609 := by
  intro p hp
  have h : env30609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30586_30609 : H12AffineEnvironment.transform 16 16401 env30586 = env30609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env30586 == env30609) = true)

theorem identity30609 : scanCanonicalize (H12AffineFastState.compose env30609 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound30609 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35324,1025,32769,2097152,4194304,152,41310,8328,65,4302891,2172370,2119112,2421,75223,6407326,257,2188650,2196687,513]

theorem envBound30610 : H12AffineFastState.Bounded env30610 := by
  intro p hp
  have h : env30610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30609_30610 : H12AffineEnvironment.transform 17 35324 env30609 = env30610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env30609 == env30610) = true)

def env30611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302891,2172250,2118976,2421,75103,6407190,257,2188650,2196551,513]

theorem envBound30611 : H12AffineFastState.Bounded env30611 := by
  intro p hp
  have h : env30611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30611 : H12AffineEnvironment.transform 6 8 env30610 = env30611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30610 == env30611) = true)

theorem identity30611 : scanCanonicalize (H12AffineFastState.compose env30611 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30611 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env30612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229152,2098513,2118976,2421,1364,6349853,257,2114913,2139212,513]

theorem envBound30612 : H12AffineFastState.Bounded env30612 := by
  intro p hp
  have h : env30612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30611_30612 : H12AffineEnvironment.transform 15 8203 env30611 = env30612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30611 == env30612) = true)

theorem identity30612 : scanCanonicalize (H12AffineFastState.compose env30612 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound30612 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,41341,16,41310,8192,65,10589,2098513,2118976,2421,1364,2114912,257,2114913,2139212,513]

theorem envBound30613 : H12AffineFastState.Bounded env30613 := by
  intro p hp
  have h : env30613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30612_30613 : H12AffineEnvironment.transform 21 41341 env30612 = env30613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env30612 == env30613) = true)

theorem identity30613 : scanCanonicalize (H12AffineFastState.compose env30613 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound30613 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,38144,41341,16,41310,8192,65,10589,36945,49216,2421,1364,53344,257,53345,12620,513]

theorem envBound30614 : H12AffineFastState.Bounded env30614 := by
  intro p hp
  have h : env30614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30613_30614 : H12AffineEnvironment.transform 20 38144 env30613 = env30614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env30613 == env30614) = true)

theorem identity30614 : scanCanonicalize (H12AffineFastState.compose env30614 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound30614 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16401,30777,1025,29004,25677,20528,16,20499,8192,65,10589,24860,12557,2421,1364,8493,257,8492,12620,513]

theorem envBound30615 : H12AffineFastState.Bounded env30615 := by
  intro p hp
  have h : env30615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30614_30615 : H12AffineEnvironment.transform 14 29005 env30614 = env30615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env30614 == env30615) = true)

theorem identity30615 : scanCanonicalize (H12AffineFastState.compose env30615 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound30615 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env30616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,8192,16384,27677,8203,16401,25961,1025,27676,25677,19808,16,19779,8192,65,10589,24860,11357,2421,1364,8493,257,8492,11292,513]

theorem envBound30616 : H12AffineFastState.Bounded env30616 := by
  intro p hp
  have h : env30616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30615_30616 : H12AffineEnvironment.transform 11 3408 env30615 = env30616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env30615 == env30616) = true)

theorem identity30616 : scanCanonicalize (H12AffineFastState.compose env30616 (packedSelected [3,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 11625) := by decide +kernel

theorem selectedBound30616 : packedSelected [3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,8192,11625,372,8203,11640,2048,1025,373,2340,8201,16,8234,8192,65,10589,3189,11357,2421,1364,8493,257,8492,11292,513]

theorem envBound30617 : H12AffineFastState.Bounded env30617 := by
  intro p hp
  have h : env30617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30616_30617 : H12AffineEnvironment.transform 13 11625 env30616 = env30617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11625 env30616 == env30617) = true)

theorem identity30617 : scanCanonicalize (H12AffineFastState.compose env30617 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30617 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1140,8192,9293,372,8203,9308,292,1025,373,0,8201,16,8234,8192,65,8313,1361,9593,81,1364,8493,257,8492,9528,513]

theorem envBound30618 : H12AffineFastState.Bounded env30618 := by
  intro p hp
  have h : env30618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30617_30618 : H12AffineEnvironment.transform 10 292 env30617 = env30618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30617 == env30618) = true)

theorem identity30618 : scanCanonicalize (H12AffineFastState.compose env30618 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30618 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30619 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,308,8192,8461,372,8203,8476,292,321,373,0,8201,16,8234,8192,65,8313,17,8249,81,20,8493,257,8492,8312,513]

theorem envBound30619 : H12AffineFastState.Bounded env30619 := by
  intro p hp
  have h : env30619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30618_30619 : H12AffineEnvironment.transform 9 320 env30618 = env30619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30618 == env30619) = true)

theorem identity30619 : scanCanonicalize (H12AffineFastState.compose env30619 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30619 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30620 : List Nat := [2,4,8,16,32,64,8,256,512,320,292,308,348,81,372,343,64,292,321,373,0,341,16,374,348,65,293,17,357,81,20,113,257,112,292,513]

theorem envBound30620 : H12AffineFastState.Bounded env30620 := by
  intro p hp
  have h : env30620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30619_30620 : H12AffineEnvironment.transform 12 348 env30619 = env30620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30619 == env30620) = true)

def env30621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41310,8193,65,4302891,2172251,2118977,2421,75102,6407191,257,2188650,2196550,513]

theorem envBound30621 : H12AffineFastState.Bounded env30621 := by
  intro p hp
  have h : env30621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30610_30621 : H12AffineEnvironment.transform 6 9 env30610 = env30621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30610 == env30621) = true)

theorem identity30621 : scanCanonicalize (H12AffineFastState.compose env30621 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound30621 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env30622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115734,4194304,17,41310,8193,65,4302891,57677,102743,2421,75102,4194305,257,41340,16464,513]

theorem envBound30622 : H12AffineFastState.Bounded env30622 := by
  intro p hp
  have h : env30622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30621_30622 : H12AffineEnvironment.transform 20 115734 env30621 = env30622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env30621 == env30622) = true)

theorem identity30622 : scanCanonicalize (H12AffineFastState.compose env30622 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30622 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env30623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91467,4194304,17,3,8193,65,4262262,16400,77834,2421,75102,4194305,257,33,16464,513]

theorem envBound30623 : H12AffineFastState.Bounded env30623 := by
  intro p hp
  have h : env30623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30622_30623 : H12AffineEnvironment.transform 14 8541 env30622 = env30623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30622 == env30623) = true)

theorem identity30623 : scanCanonicalize (H12AffineFastState.compose env30623 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound30623 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env30624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91467,32,17,3,8193,65,67926,16400,77834,2421,75102,33,257,33,16464,513]

theorem envBound30624 : H12AffineFastState.Bounded env30624 := by
  intro p hp
  have h : env30624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30623_30624 : H12AffineEnvironment.transform 21 32 env30623 = env30624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env30623 == env30624) = true)

def env30625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254785,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound30625 : H12AffineFastState.Bounded env30625 := by
  intro p hp
  have h : env30625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29140_30625 : H12AffineEnvironment.transform 29 155254785 env29140 = env30625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env29140 == env30625) = true)

def env30626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254785,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound30626 : H12AffineFastState.Bounded env30626 := by
  intro p hp
  have h : env30626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30625_30626 : H12AffineEnvironment.transform 25 64 env30625 = env30626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env30625 == env30626) = true)

def env30627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound30627 : H12AffineFastState.Bounded env30627 := by
  intro p hp
  have h : env30627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30626_30627 : H12AffineEnvironment.transform 26 30393344 env30626 = env30627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env30626 == env30627) = true)

def env30628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound30628 : H12AffineFastState.Bounded env30628 := by
  intro p hp
  have h : env30628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30627_30628 : H12AffineEnvironment.transform 18 1024 env30627 = env30628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env30627 == env30628) = true)

theorem identity30628 : scanCanonicalize (H12AffineFastState.compose env30628 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188755) := by decide +kernel

theorem selectedBound30628 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188755,16777216,8328,64,23504339,18973837,77954,2598354,18932163,23160257,256,16818559,16793818,18990613]

theorem envBound30629 : H12AffineFastState.Bounded env30629 := by
  intro p hp
  have h : env30629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30628_30629 : H12AffineEnvironment.transform 22 2188755 env30628 = env30629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188755 env30628 == env30629) = true)

def env30630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,16777216,8328,64,17227835,18973837,77954,2598354,18932163,16850985,256,16818559,16793818,18990613]

theorem envBound30630 : H12AffineFastState.Bounded env30630 := by
  intro p hp
  have h : env30630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30629_30630 : H12AffineEnvironment.transform 21 2115048 env30629 = env30630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env30629 == env30630) = true)

def env30631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175048,8328,64,2609267,46277,77954,2598354,119179,2101345,256,2199863,2191506,63069]

theorem envBound30631 : H12AffineFastState.Bounded env30631 := by
  intro p hp
  have h : env30631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30630_30631 : H12AffineEnvironment.transform 23 2175048 env30630 = env30631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env30630 == env30631) = true)

def env30632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175048,8328,64,2590067,46277,77954,2598354,99467,2101345,256,2199863,2172306,41821]

theorem envBound30632 : H12AffineFastState.Bounded env30632 := by
  intro p hp
  have h : env30632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30631_30632 : H12AffineEnvironment.transform 13 5376 env30631 = env30632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30631 == env30632) = true)

theorem identity30632 : scanCanonicalize (H12AffineFastState.compose env30632 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound30632 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,2097152,2101480,2101328,2101451,8328,64,2532848,46277,4097,2524497,41992,2101345,256,2142644,2098449,41821]

theorem envBound30633 : H12AffineFastState.Bounded env30633 := by
  intro p hp
  have h : env30633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30632_30633 : H12AffineEnvironment.transform 15 8323 env30632 = env30633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env30632 == env30633) = true)

def env30634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2532728,46157,4097,2524497,41992,2101345,256,2142524,2098449,41821]

theorem envBound30634 : H12AffineFastState.Bounded env30634 := by
  intro p hp
  have h : env30634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30633_30634 : H12AffineEnvironment.transform 6 8 env30633 = env30634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30633 == env30634) = true)

theorem identity30634 : scanCanonicalize (H12AffineFastState.compose env30634 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound30634 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,46156,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2363700,46157,4097,2371869,41992,2101345,256,2142524,2098449,41821]

theorem envBound30635 : H12AffineFastState.Bounded env30635 := by
  intro p hp
  have h : env30635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30634_30635 : H12AffineEnvironment.transform 16 46156 env30634 = env30635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env30634 == env30635) = true)

theorem identity30635 : scanCanonicalize (H12AffineFastState.compose env30635 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30635 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5392,262144,1024,8541,2097152,2101344,2101328,2101315,8192,64,2363700,5393,4097,2371869,1364,2101345,256,2101344,2098449,513]

theorem envBound30636 : H12AffineFastState.Bounded env30636 := by
  intro p hp
  have h : env30636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30635_30636 : H12AffineEnvironment.transform 14 8540 env30635 = env30636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30635 == env30636) = true)

theorem identity30636 : scanCanonicalize (H12AffineFastState.compose env30636 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30636 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30637 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8203,4097,262144,273,8541,2097152,2101344,2101328,2101315,8192,64,2363700,4096,4097,2371869,69,2101345,256,2101344,2097152,513]

theorem envBound30637 : H12AffineFastState.Bounded env30637 := by
  intro p hp
  have h : env30637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30636_30637 : H12AffineEnvironment.transform 9 273 env30636 = env30637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30636 == env30637) = true)

theorem identity30637 : scanCanonicalize (H12AffineFastState.compose env30637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound30637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30638 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8203,4097,262144,273,8541,276584,272392,272440,272427,8192,64,10588,4096,4097,2421,69,272393,256,272392,276584,513]

theorem envBound30638 : H12AffineFastState.Bounded env30638 := by
  intro p hp
  have h : env30638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30637_30638 : H12AffineEnvironment.transform 20 276584 env30637 = env30638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env30637 == env30638) = true)

theorem identity30638 : scanCanonicalize (H12AffineFastState.compose env30638 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30638 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env30639 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,41,4113,373,34,4097,262144,273,372,268353,264225,264209,264194,41,64,2421,4096,4097,2421,69,264224,256,264225,268353,513]

theorem envBound30639 : H12AffineFastState.Bounded env30639 := by
  intro p hp
  have h : env30639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30638_30639 : H12AffineEnvironment.transform 12 41 env30638 = env30639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30638 == env30639) = true)

theorem identity30639 : scanCanonicalize (H12AffineFastState.compose env30639 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound30639 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30640 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,41,4113,373,34,4097,2421,273,372,4404,340,356,375,41,64,2421,4096,4097,2421,69,341,256,340,4404,513]

theorem envBound30640 : H12AffineFastState.Bounded env30640 := by
  intro p hp
  have h : env30640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30639_30640 : H12AffineEnvironment.transform 17 2421 env30639 = env30640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env30639 == env30640) = true)

theorem identity30640 : scanCanonicalize (H12AffineFastState.compose env30640 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30640 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env30641 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4113,292,34,4097,2340,273,293,4404,261,309,294,41,17,2340,4096,4097,2340,20,260,256,261,4404,513]

theorem envBound30641 : H12AffineFastState.Bounded env30641 := by
  intro p hp
  have h : env30641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30640_30641 : H12AffineEnvironment.transform 5 17 env30640 = env30641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30640 == env30641) = true)

theorem identity30641 : scanCanonicalize (H12AffineFastState.compose env30641 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30641 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30642 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,0,34,4097,2048,53,1,4112,33,17,2,41,17,2048,4096,4097,2048,20,32,36,33,4112,513]

theorem envBound30642 : H12AffineFastState.Bounded env30642 := by
  intro p hp
  have h : env30642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30641_30642 : H12AffineEnvironment.transform 7 36 env30641 = env30642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30641 == env30642) = true)

theorem identity30642 : scanCanonicalize (H12AffineFastState.compose env30642 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound30642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30643 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,4096,41,4113,0,34,4097,49,53,1,4112,33,17,2,41,17,49,4096,4097,49,20,32,36,33,4112,513]

theorem envBound30643 : H12AffineFastState.Bounded env30643 := by
  intro p hp
  have h : env30643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30642_30643 : H12AffineEnvironment.transform 10 49 env30642 = env30643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env30642 == env30643) = true)

theorem identity30643 : scanCanonicalize (H12AffineFastState.compose env30643 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound30643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30644 : List Nat := [2,4,8,16,32,17,8,36,32,53,49,4096,41,4113,0,34,4097,49,53,1,4112,33,17,2,41,17,49,4096,4097,49,20,32,36,33,4112,33]

theorem envBound30644 : H12AffineFastState.Bounded env30644 := by
  intro p hp
  have h : env30644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30643_30644 : H12AffineEnvironment.transform 8 32 env30643 = env30644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env30643 == env30644) = true)

theorem identity30644 : scanCanonicalize (H12AffineFastState.compose env30644 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound30644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30645 : List Nat := [2,4,8,16,32,17,8,36,32,53,49,16,41,1,0,34,17,49,53,1,0,33,17,2,41,17,49,16,17,49,20,32,36,33,0,33]

theorem envBound30645 : H12AffineFastState.Bounded env30645 := by
  intro p hp
  have h : env30645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30644_30645 : H12AffineEnvironment.transform 11 16 env30644 = env30645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30644 == env30645) = true)

def env30646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2532729,46156,4097,2524497,41992,2101345,256,2142525,2098449,41821]

theorem envBound30646 : H12AffineFastState.Bounded env30646 := by
  intro p hp
  have h : env30646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30633_30646 : H12AffineEnvironment.transform 6 9 env30633 = env30646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30633 == env30646) = true)

theorem identity30646 : scanCanonicalize (H12AffineFastState.compose env30646 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30646 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,5393,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2404456,46156,4097,2396224,41992,2101345,256,2142525,2098449,41821]

theorem envBound30647 : H12AffineFastState.Bounded env30647 := by
  intro p hp
  have h : env30647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30646_30647 : H12AffineEnvironment.transform 16 5393 env30646 = env30647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30646 == env30647) = true)

theorem identity30647 : scanCanonicalize (H12AffineFastState.compose env30647 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30647 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env30648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5393,262144,1024,8541,2097152,2101345,2101328,2101314,8193,64,2363700,5392,4097,2371868,1364,2101345,256,2101345,2098449,513]

theorem envBound30648 : H12AffineFastState.Bounded env30648 := by
  intro p hp
  have h : env30648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30647_30648 : H12AffineEnvironment.transform 14 8540 env30647 = env30648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30647 == env30648) = true)

def env30649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175048,8328,64,2590066,46277,77954,2598354,99466,2101345,256,2199863,2172307,41820]

theorem envBound30649 : H12AffineFastState.Bounded env30649 := by
  intro p hp
  have h : env30649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30631_30649 : H12AffineEnvironment.transform 13 5377 env30631 = env30649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30631 == env30649) = true)

theorem identity30649 : scanCanonicalize (H12AffineFastState.compose env30649 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound30649 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,73771,16,138,8328,64,439728,46277,77954,431376,99466,73891,256,41461,5457,41820]

theorem envBound30650 : H12AffineFastState.Bounded env30650 := by
  intro p hp
  have h : env30650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30649_30650 : H12AffineEnvironment.transform 20 78018 env30649 = env30650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env30649 == env30650) = true)

def env30651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,73771,16,2,8192,64,439608,46157,77834,431376,99330,73771,256,41341,5457,41820]

theorem envBound30651 : H12AffineFastState.Bounded env30651 := by
  intro p hp
  have h : env30651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30650_30651 : H12AffineEnvironment.transform 6 8 env30650 = env30651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30650 == env30651) = true)

theorem identity30651 : scanCanonicalize (H12AffineFastState.compose env30651 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound30651 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env30652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,77898,73771,16,2,8192,64,360482,46157,77834,368650,99330,73771,256,41341,5457,41820]

theorem envBound30652 : H12AffineFastState.Bounded env30652 := by
  intro p hp
  have h : env30652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30651_30652 : H12AffineEnvironment.transform 16 79130 env30651 = env30652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env30651 == env30652) = true)

theorem identity30652 : scanCanonicalize (H12AffineFastState.compose env30652 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound30652 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env30653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,46157,262144,1024,32769,45341,41340,16,2,8192,64,262517,46157,45405,270685,1365,41340,256,41341,5457,41820]

theorem envBound30653 : H12AffineFastState.Bounded env30653 := by
  intro p hp
  have h : env30653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30652_30653 : H12AffineEnvironment.transform 15 33111 env30652 = env30653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env30652 == env30653) = true)

theorem identity30653 : scanCanonicalize (H12AffineFastState.compose env30653 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound30653 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env30654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,33111,37940,262144,1024,32769,37220,33029,16,2,121,64,262517,37940,37156,262436,1365,33029,256,33028,5457,33573]

theorem envBound30654 : H12AffineFastState.Bounded env30654 := by
  intro p hp
  have h : env30654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30653_30654 : H12AffineEnvironment.transform 12 121 env30653 = env30654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env30653 == env30654) = true)

theorem identity30654 : scanCanonicalize (H12AffineFastState.compose env30654 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound30654 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env30655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,32768,33111,37940,35189,1024,32769,37220,33029,16,2,121,64,34816,37940,37156,34897,1365,33029,256,33028,5457,33573]

theorem envBound30655 : H12AffineFastState.Bounded env30655 := by
  intro p hp
  have h : env30655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30654_30655 : H12AffineEnvironment.transform 17 35189 env30654 = env30655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env30654 == env30655) = true)

theorem identity30655 : scanCanonicalize (H12AffineFastState.compose env30655 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound30655 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,373,34,5441,2048,1024,372,4113,112,16,2,121,64,2421,5441,4177,2340,1365,112,256,113,5457,592]

theorem envBound30656 : H12AffineFastState.Bounded env30656 := by
  intro p hp
  have h : env30656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30655_30656 : H12AffineEnvironment.transform 14 373 env30655 = env30656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env30655 == env30656) = true)

theorem identity30656 : scanCanonicalize (H12AffineFastState.compose env30656 (packedSelected [0,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound30656 : packedSelected [0,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,121,2128,373,34,2064,2048,1024,372,3392,112,16,2,121,64,2421,2064,3328,2340,1365,112,256,113,2048,592]

theorem envBound30657 : H12AffineFastState.Bounded env30657 := by
  intro p hp
  have h : env30657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30656_30657 : H12AffineEnvironment.transform 11 3409 env30656 = env30657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env30656 == env30657) = true)

theorem identity30657 : scanCanonicalize (H12AffineFastState.compose env30657 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30657 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env30658 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3189,121,2128,81,34,2064,2048,1024,80,3172,112,16,2,121,64,2129,2064,3108,2048,1137,112,36,113,2048,592]

theorem envBound30658 : H12AffineFastState.Bounded env30658 := by
  intro p hp
  have h : env30658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30657_30658 : H12AffineEnvironment.transform 7 36 env30657 = env30658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30657 == env30658) = true)

theorem identity30658 : scanCanonicalize (H12AffineFastState.compose env30658 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30658 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30659 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,3109,41,2048,1,34,2064,2048,1024,0,3124,32,16,2,41,16,2049,2064,3108,2048,1057,32,36,33,2048,512]

theorem envBound30659 : H12AffineFastState.Bounded env30659 := by
  intro p hp
  have h : env30659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30658_30659 : H12AffineEnvironment.transform 5 16 env30658 = env30659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30658 == env30659) = true)

theorem identity30659 : scanCanonicalize (H12AffineFastState.compose env30659 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30660 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,1061,41,0,1,34,16,0,1024,0,1076,32,16,2,41,16,1,16,1060,0,1057,32,36,33,0,512]

theorem envBound30660 : H12AffineFastState.Bounded env30660 := by
  intro p hp
  have h : env30660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30659_30660 : H12AffineEnvironment.transform 10 0 env30659 = env30660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30659 == env30660) = true)

theorem identity30660 : scanCanonicalize (H12AffineFastState.compose env30660 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound30660 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30661 : List Nat := [2,4,8,16,32,16,8,36,512,542,0,571,41,0,1,34,16,0,542,0,554,32,16,2,41,16,1,16,570,0,575,32,36,33,0,512]

theorem envBound30661 : H12AffineFastState.Bounded env30661 := by
  intro p hp
  have h : env30661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30660_30661 : H12AffineEnvironment.transform 9 542 env30660 = env30661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env30660 == env30661) = true)

theorem identity30661 : scanCanonicalize (H12AffineFastState.compose env30661 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound30661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30662 : List Nat := [2,4,8,16,13,16,8,9,512,542,0,534,4,0,1,15,16,0,542,0,519,13,16,2,4,16,1,16,535,0,530,13,9,12,0,512]

theorem envBound30662 : H12AffineFastState.Bounded env30662 := by
  intro p hp
  have h : env30662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30661_30662 : H12AffineEnvironment.transform 4 13 env30661 = env30662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env30661 == env30662) = true)

theorem identity30662 : scanCanonicalize (H12AffineFastState.compose env30662 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30662 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30663 : List Nat := [2,3,8,16,10,16,8,9,512,537,0,529,3,0,1,8,16,0,537,0,512,10,16,2,3,16,1,16,528,0,530,10,9,11,0,512]

theorem envBound30663 : H12AffineFastState.Bounded env30663 := by
  intro p hp
  have h : env30663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30662_30663 : H12AffineEnvironment.transform 1 3 env30662 = env30663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30662 == env30663) = true)

theorem identity30663 : scanCanonicalize (H12AffineFastState.compose env30663 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound30663 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30664 : List Nat := [2,3,8,16,10,16,8,9,27,2,0,10,3,0,1,8,16,0,2,0,27,10,16,2,3,16,1,16,11,0,9,10,9,11,0,27]

theorem envBound30664 : H12AffineFastState.Bounded env30664 := by
  intro p hp
  have h : env30664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30663_30664 : H12AffineEnvironment.transform 8 27 env30663 = env30664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env30663 == env30664) = true)

theorem identity30664 : scanCanonicalize (H12AffineFastState.compose env30664 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30664 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30665 : List Nat := [2,3,3,16,1,16,3,2,16,2,0,1,3,0,1,3,16,0,2,0,16,1,16,2,3,16,1,16,0,0,2,1,2,0,0,16]

theorem envBound30665 : H12AffineFastState.Bounded env30665 := by
  intro p hp
  have h : env30665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30664_30665 : H12AffineEnvironment.transform 2 3 env30664 = env30665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30664 == env30665) = true)

theorem identity30665 : scanCanonicalize (H12AffineFastState.compose env30665 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound30665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30666 : List Nat := [2,3,3,3,1,3,3,2,3,2,0,1,3,0,1,3,3,0,2,0,3,1,3,2,3,3,1,3,0,0,2,1,2,0,0,3]

theorem envBound30666 : H12AffineFastState.Bounded env30666 := by
  intro p hp
  have h : env30666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30665_30666 : H12AffineEnvironment.transform 3 3 env30665 = env30666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env30665 == env30666) = true)

def env30667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,73771,16,3,8193,64,439609,46156,77835,431376,99331,73770,256,41340,5457,41820]

theorem envBound30667 : H12AffineFastState.Bounded env30667 := by
  intro p hp
  have h : env30667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30650_30667 : H12AffineEnvironment.transform 6 9 env30650 = env30667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30650 == env30667) = true)

theorem identity30667 : scanCanonicalize (H12AffineFastState.compose env30667 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30667 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,73771,16,3,8193,64,398436,5393,77835,406605,75102,73770,256,33,5457,513]

theorem envBound30668 : H12AffineFastState.Bounded env30668 := by
  intro p hp
  have h : env30668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30667_30668 : H12AffineEnvironment.transform 14 8541 env30667 = env30668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30667 == env30668) = true)

theorem identity30668 : scanCanonicalize (H12AffineFastState.compose env30668 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound30668 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env30669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77899,73771,16,3,8193,64,146509,5393,77835,138340,75102,73770,256,33,5457,513]

theorem envBound30669 : H12AffineFastState.Bounded env30669 := by
  intro p hp
  have h : env30669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30668_30669 : H12AffineEnvironment.transform 17 10281 env30668 = env30669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30668 == env30669) = true)

theorem identity30669 : scanCanonicalize (H12AffineFastState.compose env30669 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound30669 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env30670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,70678,10281,1024,8540,77899,73771,16,3,8193,64,75867,5393,77835,67698,75102,73770,256,33,5457,513]

theorem envBound30670 : H12AffineFastState.Bounded env30670 := by
  intro p hp
  have h : env30670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30669_30670 : H12AffineEnvironment.transform 16 70678 env30669 = env30670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env30669 == env30670) = true)

theorem identity30670 : scanCanonicalize (H12AffineFastState.compose env30670 (packedSelected [4,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound30670 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30671 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8282,13388,10281,1024,8540,4113,113,16,3,8193,64,2049,5393,4177,10280,1284,112,256,33,5457,513]

theorem envBound30671 : H12AffineFastState.Bounded env30671 := by
  intro p hp
  have h : env30671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30670_30671 : H12AffineEnvironment.transform 15 8282 env30670 = env30671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env30670 == env30671) = true)

theorem identity30671 : scanCanonicalize (H12AffineFastState.compose env30671 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30671 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env30672 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,13341,10281,1024,8461,4113,32,16,3,8193,17,2049,5393,4096,10280,1284,33,256,33,5376,513]

theorem envBound30672 : H12AffineFastState.Bounded env30672 := by
  intro p hp
  have h : env30672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30671_30672 : H12AffineEnvironment.transform 5 17 env30671 = env30672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30671 == env30672) = true)

theorem identity30672 : scanCanonicalize (H12AffineFastState.compose env30672 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound30672 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30673 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4380,5377,4112,4375,1281,6453,1024,4113,4113,32,16,3,4381,17,2049,5393,4096,6452,1284,33,256,33,5376,513]

theorem envBound30673 : H12AffineFastState.Bounded env30673 := by
  intro p hp
  have h : env30673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30672_30673 : H12AffineEnvironment.transform 12 4380 env30672 = env30673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env30672 == env30673) = true)

theorem identity30673 : scanCanonicalize (H12AffineFastState.compose env30673 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound30673 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30674 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,3384,2341,3124,3379,1281,1297,1024,3125,3125,32,16,3,3385,17,2049,2357,3108,1296,1284,33,256,33,2340,513]

theorem envBound30674 : H12AffineFastState.Bounded env30674 := by
  intro p hp
  have h : env30674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30673_30674 : H12AffineEnvironment.transform 11 3108 env30673 = env30674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env30673 == env30674) = true)

theorem identity30674 : scanCanonicalize (H12AffineFastState.compose env30674 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30674 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env30675 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3108,3100,2049,3124,3095,1061,1077,1024,3125,3125,32,16,3,3101,17,2049,2065,3108,1076,1056,33,36,33,2048,513]

theorem envBound30675 : H12AffineFastState.Bounded env30675 := by
  intro p hp
  have h : env30675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30674_30675 : H12AffineEnvironment.transform 7 36 env30674 = env30675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30674 == env30675) = true)

def env30676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175049,8328,64,2609266,46276,77954,2598354,119178,2101344,256,2199862,2191507,63068]

theorem envBound30676 : H12AffineFastState.Bounded env30676 := by
  intro p hp
  have h : env30676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30630_30676 : H12AffineEnvironment.transform 23 2175049 env30630 = env30676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env30630 == env30676) = true)

def env30677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175049,8328,64,2590066,46276,77954,2598354,99466,2101344,256,2199862,2172307,41820]

theorem envBound30677 : H12AffineFastState.Bounded env30677 := by
  intro p hp
  have h : env30677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30676_30677 : H12AffineEnvironment.transform 13 5376 env30676 = env30677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30676 == env30677) = true)

theorem identity30677 : scanCanonicalize (H12AffineFastState.compose env30677 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102814) := by decide +kernel

theorem selectedBound30677 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102814,98678,41293,41431,8328,64,398572,46276,77954,406604,99466,98814,256,168,46093,41820]

theorem envBound30678 : H12AffineFastState.Bounded env30678 := by
  intro p hp
  have h : env30678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30677_30678 : H12AffineEnvironment.transform 20 102814 env30677 = env30678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102814 env30677 == env30678) = true)

def env30679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102814,98678,41293,41431,8328,64,146628,46276,77954,138340,99466,98814,256,168,46093,41820]

theorem envBound30679 : H12AffineFastState.Bounded env30679 := by
  intro p hp
  have h : env30679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30678_30679 : H12AffineEnvironment.transform 17 10280 env30678 = env30679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30678 == env30679) = true)

theorem identity30679 : scanCanonicalize (H12AffineFastState.compose env30679 (packedSelected [5,8,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound30679 : packedSelected [5,8,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env30680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,103494,10280,1024,32769,102814,98678,41293,41431,8328,64,108674,46276,77954,100386,99466,98814,256,168,46093,41820]

theorem envBound30680 : H12AffineFastState.Bounded env30680 := by
  intro p hp
  have h : env30680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30679_30680 : H12AffineEnvironment.transform 16 103494 env30679 = env30680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env30679 == env30680) = true)

theorem identity30680 : scanCanonicalize (H12AffineFastState.compose env30680 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 33862) := by decide +kernel

theorem selectedBound30680 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env30681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33862,4096,10280,1024,32769,5592,1328,41293,41431,8328,64,11460,46276,46276,3172,204,1464,256,168,46093,41820]

theorem envBound30681 : H12AffineFastState.Bounded env30681 := by
  intro p hp
  have h : env30681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30680_30681 : H12AffineEnvironment.transform 15 33862 env30680 = env30681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33862 env30680 == env30681) = true)

theorem identity30681 : scanCanonicalize (H12AffineFastState.compose env30681 (packedSelected [0,1,2,3,4,5,6,9,11,15,16,18,26,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound30681 : packedSelected [0,1,2,3,4,5,6,9,11,15,16,18,26,27,28,38] rootPS < 2^1333 := by decide +kernel

def env30682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,428,1514,4096,10280,1024,429,5592,1328,8417,8315,8328,64,11460,13672,13672,3172,204,1464,256,168,13729,8944]

theorem envBound30682 : H12AffineFastState.Bounded env30682 := by
  intro p hp
  have h : env30682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30681_30682 : H12AffineEnvironment.transform 14 428 env30681 = env30682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env30681 == env30682) = true)

theorem identity30682 : scanCanonicalize (H12AffineFastState.compose env30682 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound30682 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5376,428,1514,4096,2264,1024,429,5592,1328,17,139,120,64,3124,5528,5528,3172,204,1464,256,168,5457,512]

theorem envBound30683 : H12AffineFastState.Bounded env30683 := by
  intro p hp
  have h : env30683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30682_30683 : H12AffineEnvironment.transform 12 240 env30682 = env30683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env30682 == env30683) = true)

theorem identity30683 : scanCanonicalize (H12AffineFastState.compose env30683 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30683 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30684 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,240,4113,428,251,4096,2264,273,429,4297,33,17,139,120,64,2341,4233,4233,2421,204,169,256,168,4160,512]

theorem envBound30684 : H12AffineFastState.Bounded env30684 := by
  intro p hp
  have h : env30684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30683_30684 : H12AffineEnvironment.transform 9 273 env30683 = env30684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30683 == env30684) = true)

theorem identity30684 : scanCanonicalize (H12AffineFastState.compose env30684 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound30684 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30685 : List Nat := [2,4,8,16,32,64,128,84,512,69,2048,4096,240,4113,248,251,4096,2264,69,249,4297,33,17,139,120,64,2161,4233,4233,2081,204,169,84,168,4160,512]

theorem envBound30685 : H12AffineFastState.Bounded env30685 := by
  intro p hp
  have h : env30685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30684_30685 : H12AffineEnvironment.transform 7 84 env30684 = env30685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env30684 == env30685) = true)

theorem identity30685 : scanCanonicalize (H12AffineFastState.compose env30685 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound30685 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30686 : List Nat := [2,4,8,16,32,64,128,84,512,69,2048,185,240,168,248,251,185,2264,69,249,112,33,17,139,120,64,2161,48,48,2081,204,169,84,168,249,512]

theorem envBound30686 : H12AffineFastState.Bounded env30686 := by
  intro p hp
  have h : env30686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30685_30686 : H12AffineEnvironment.transform 11 185 env30685 = env30686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env30685 == env30686) = true)

theorem identity30686 : scanCanonicalize (H12AffineFastState.compose env30686 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound30686 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30687 : List Nat := [2,4,8,16,32,64,128,84,512,69,248,185,240,168,248,251,185,32,69,249,112,33,17,139,120,64,137,48,48,217,204,169,84,168,249,512]

theorem envBound30687 : H12AffineFastState.Bounded env30687 := by
  intro p hp
  have h : env30687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30686_30687 : H12AffineEnvironment.transform 10 248 env30686 = env30687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env30686 == env30687) = true)

theorem identity30687 : scanCanonicalize (H12AffineFastState.compose env30687 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30687 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30688 : List Nat := [2,4,8,16,32,64,9,84,512,69,113,48,121,33,113,114,48,32,69,112,112,33,17,2,120,64,0,48,48,80,69,32,84,33,112,512]

theorem envBound30688 : H12AffineFastState.Bounded env30688 := by
  intro p hp
  have h : env30688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1