import H12CloudChart1Data121

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans30945_30946 : H12AffineEnvironment.transform 5 16 env30945 = env30946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30945 == env30946) = true)

theorem identity30946 : scanCanonicalize (H12AffineFastState.compose env30946 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound30946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30947 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,48,268,1328,0,262,1313,2341,1025,1,33,33,17,3,268,16,2048,1312,49,2341,1284,32,257,32,1328,513]

theorem envBound30947 : H12AffineFastState.Bounded env30947 := by
  intro p hp
  have h : env30947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30946_30947 : H12AffineEnvironment.transform 11 48 env30946 = env30947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env30946 == env30947) = true)

theorem identity30947 : scanCanonicalize (H12AffineFastState.compose env30947 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30947 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30948 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,48,268,32,0,262,49,2341,273,1,33,33,17,3,268,16,2048,48,49,2341,20,32,257,32,32,513]

theorem envBound30948 : H12AffineFastState.Bounded env30948 := by
  intro p hp
  have h : env30948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30947_30948 : H12AffineEnvironment.transform 9 272 env30947 = env30948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30947 == env30948) = true)

theorem identity30948 : scanCanonicalize (H12AffineFastState.compose env30948 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound30948 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30949 : List Nat := [2,4,8,16,32,16,8,256,293,272,2048,48,268,32,0,262,49,2341,273,1,33,33,17,3,268,16,2048,48,49,2341,20,32,257,32,32,292]

theorem envBound30949 : H12AffineFastState.Bounded env30949 := by
  intro p hp
  have h : env30949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30948_30949 : H12AffineEnvironment.transform 8 293 env30948 = env30949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env30948 == env30949) = true)

theorem identity30949 : scanCanonicalize (H12AffineFastState.compose env30949 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound30949 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30950 : List Nat := [2,4,8,16,32,16,8,256,293,272,277,48,268,32,0,262,49,48,273,1,33,33,17,3,268,16,277,48,49,48,20,32,257,32,32,292]

theorem envBound30950 : H12AffineFastState.Bounded env30950 := by
  intro p hp
  have h : env30950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30949_30950 : H12AffineEnvironment.transform 10 277 env30949 = env30950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env30949 == env30950) = true)

theorem identity30950 : scanCanonicalize (H12AffineFastState.compose env30950 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30950 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30951 : List Nat := [2,4,8,16,32,16,8,36,1,52,49,48,40,32,0,34,49,48,53,1,33,33,17,3,40,16,49,48,49,48,20,32,37,32,32,0]

theorem envBound30951 : H12AffineFastState.Bounded env30951 := by
  intro p hp
  have h : env30951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30950_30951 : H12AffineEnvironment.transform 7 36 env30950 = env30951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30950 == env30951) = true)

theorem identity30951 : scanCanonicalize (H12AffineFastState.compose env30951 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30952 : List Nat := [2,4,8,16,0,16,8,4,1,20,17,16,8,0,0,2,17,16,21,1,1,1,17,3,8,16,17,16,17,16,20,0,5,0,0,0]

theorem envBound30952 : H12AffineFastState.Bounded env30952 := by
  intro p hp
  have h : env30952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30951_30952 : H12AffineEnvironment.transform 4 0 env30951 = env30952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30951 == env30952) = true)

theorem identity30952 : scanCanonicalize (H12AffineFastState.compose env30952 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30953 : List Nat := [2,4,2,16,0,16,2,4,1,20,17,16,2,0,0,2,17,16,21,1,1,1,17,3,2,16,17,16,17,16,20,0,5,0,0,0]

theorem envBound30953 : H12AffineFastState.Bounded env30953 := by
  intro p hp
  have h : env30953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30952_30953 : H12AffineEnvironment.transform 2 2 env30952 = env30953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30952 == env30953) = true)

theorem identity30953 : scanCanonicalize (H12AffineFastState.compose env30953 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30953 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env30954 : List Nat := [2,4,2,0,0,0,2,4,1,4,1,0,2,0,0,2,1,0,5,1,1,1,1,3,2,0,1,0,1,0,4,0,5,0,0,0]

theorem envBound30954 : H12AffineFastState.Bounded env30954 := by
  intro p hp
  have h : env30954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30953_30954 : H12AffineEnvironment.transform 3 0 env30953 = env30954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30953 == env30954) = true)

def env30955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13509,10401,1025,8660,2097152,33,2101328,2101315,8328,64,75907,79130,4096,2111712,75222,73890,257,2175082,2172186,513]

theorem envBound30955 : H12AffineFastState.Bounded env30955 := by
  intro p hp
  have h : env30955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30940_30955 : H12AffineEnvironment.transform 13 5377 env30940 = env30955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30940 == env30955) = true)

theorem identity30955 : scanCanonicalize (H12AffineFastState.compose env30955 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound30955 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13509,10401,1025,8660,2097152,33,2101328,2101315,8328,64,2049,5528,4096,2111712,1364,32,257,2101480,2098584,513]

theorem envBound30956 : H12AffineFastState.Bounded env30956 := by
  intro p hp
  have h : env30956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30955_30956 : H12AffineEnvironment.transform 15 8322 env30955 = env30956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env30955 == env30956) = true)

theorem identity30956 : scanCanonicalize (H12AffineFastState.compose env30956 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound30956 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5528,2556,1025,137,2097152,33,2101328,2101315,469,64,2049,5528,4096,2103741,1364,32,257,2101480,2098584,513]

theorem envBound30957 : H12AffineFastState.Bounded env30957 := by
  intro p hp
  have h : env30957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30956_30957 : H12AffineEnvironment.transform 12 349 env30956 = env30957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env30956 == env30957) = true)

theorem identity30957 : scanCanonicalize (H12AffineFastState.compose env30957 (packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS)) = affineNative (2^(20+1) ^^^ 4297) := by decide +kernel

theorem selectedBound30957 : packedSelected [1,2,3,4,5,6,8,9,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env30958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,136,479,5528,2556,1025,137,4297,33,153,138,469,64,2049,5528,4096,2420,1364,32,257,33,5457,513]

theorem envBound30958 : H12AffineFastState.Bounded env30958 := by
  intro p hp
  have h : env30958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30957_30958 : H12AffineEnvironment.transform 20 4297 env30957 = env30958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4297 env30957 == env30958) = true)

theorem identity30958 : scanCanonicalize (H12AffineFastState.compose env30958 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30958 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5393,2421,1025,0,4160,33,16,3,348,64,2049,5393,4096,2420,1364,32,257,33,5457,513]

theorem envBound30959 : H12AffineFastState.Bounded env30959 := by
  intro p hp
  have h : env30959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30958_30959 : H12AffineEnvironment.transform 6 9 env30958 = env30959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30958 == env30959) = true)

theorem identity30959 : scanCanonicalize (H12AffineFastState.compose env30959 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30959 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30960 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1025,0,4113,33,16,3,269,17,2049,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound30960 : H12AffineFastState.Bounded env30960 := by
  intro p hp
  have h : env30960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30959_30960 : H12AffineEnvironment.transform 5 17 env30959 = env30960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30959 == env30960) = true)

theorem identity30960 : scanCanonicalize (H12AffineFastState.compose env30960 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound30960 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30961 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3329,268,2048,1,263,2064,2340,1025,0,3344,33,16,3,269,17,2049,2064,3329,2341,1285,32,257,33,2049,513]

theorem envBound30961 : H12AffineFastState.Bounded env30961 := by
  intro p hp
  have h : env30961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30960_30961 : H12AffineEnvironment.transform 11 3329 env30960 = env30961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env30960 == env30961) = true)

theorem identity30961 : scanCanonicalize (H12AffineFastState.compose env30961 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30961 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30962 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,40,2048,1,35,2064,2048,1025,0,3124,33,16,3,41,17,2049,2064,3109,2049,1057,32,37,33,2049,513]

theorem envBound30962 : H12AffineFastState.Bounded env30962 := by
  intro p hp
  have h : env30962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30961_30962 : H12AffineEnvironment.transform 7 36 env30961 = env30962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30961 == env30962) = true)

theorem identity30962 : scanCanonicalize (H12AffineFastState.compose env30962 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30962 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30963 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,40,2048,1,35,2064,2048,52,0,2049,33,16,3,41,17,2049,2064,2064,2049,20,32,37,33,2049,513]

theorem envBound30963 : H12AffineFastState.Bounded env30963 := by
  intro p hp
  have h : env30963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30962_30963 : H12AffineEnvironment.transform 9 53 env30962 = env30963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30962 == env30963) = true)

def env30964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97667,115150,17665,2363457,119042,329730,257,2199999,2191387,63189]

theorem envBound30964 : H12AffineFastState.Bounded env30964 := by
  intro p hp
  have h : env30964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30924_30964 : H12AffineEnvironment.transform 21 272513 env30924 = env30964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30924 == env30964) = true)

theorem identity30964 : scanCanonicalize (H12AffineFastState.compose env30964 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound30964 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272513,62661,41431,8328,64,97667,115150,17665,324820,119042,329730,257,95530,103566,63189]

theorem envBound30965 : H12AffineFastState.Bounded env30965 := by
  intro p hp
  have h : env30965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30964_30965 : H12AffineEnvironment.transform 20 58517 env30964 = env30965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env30964 == env30965) = true)

def env30966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272513,62613,41351,8328,16,97667,115102,17665,324740,119042,329730,257,95530,103566,63109]

theorem envBound30966 : H12AffineFastState.Bounded env30966 := by
  intro p hp
  have h : env30966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30965_30966 : H12AffineEnvironment.transform 5 16 env30965 = env30966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30965 == env30966) = true)

theorem identity30966 : scanCanonicalize (H12AffineFastState.compose env30966 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound30966 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,64809,1025,32769,58517,54696,62613,41351,8328,16,97667,115102,17665,2477,119042,128299,257,95530,103566,63109]

theorem envBound30967 : H12AffineFastState.Bounded env30967 := by
  intro p hp
  have h : env30967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30966_30967 : H12AffineEnvironment.transform 17 64809 env30966 = env30967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env30966 == env30967) = true)

theorem identity30967 : scanCanonicalize (H12AffineFastState.compose env30967 (packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30967 : packedSelected [0,5,8,9,10,16,18,19,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30968 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,64809,1025,32769,58396,54561,62492,41230,8193,16,97546,114967,17665,2340,119042,128299,257,95530,103431,62988]

theorem envBound30968 : H12AffineFastState.Bounded env30968 := by
  intro p hp
  have h : env30968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30967_30968 : H12AffineEnvironment.transform 6 9 env30967 = env30968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30967 == env30968) = true)

theorem identity30968 : scanCanonicalize (H12AffineFastState.compose env30968 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound30968 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env30969 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,65536,5393,10281,1025,21761,12572,33,8476,29710,8193,16,97546,70679,17665,2340,66562,73771,257,95530,82183,8972]

theorem envBound30969 : H12AffineFastState.Bounded env30969 := by
  intro p hp
  have h : env30969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30968_30969 : H12AffineEnvironment.transform 14 21760 env30968 = env30969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env30968 == env30969) = true)

theorem identity30969 : scanCanonicalize (H12AffineFastState.compose env30969 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound30969 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30970 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8461,65536,5393,10281,1025,8460,12572,33,8476,3,8193,16,67847,70679,12556,2340,66562,73771,257,65831,79114,8972]

theorem envBound30970 : H12AffineFastState.Bounded env30970 := by
  intro p hp
  have h : env30970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30969_30970 : H12AffineEnvironment.transform 13 13325 env30969 = env30970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env30969 == env30970) = true)

theorem identity30970 : scanCanonicalize (H12AffineFastState.compose env30970 (packedSelected [1,4,8,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 14655) := by decide +kernel

theorem selectedBound30970 : packedSelected [1,4,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30971 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8461,14655,5393,10281,1025,8460,12572,33,8476,3,8193,16,12344,11560,12556,2340,15677,6420,257,14360,3125,8972]

theorem envBound30971 : H12AffineFastState.Bounded env30971 := by
  intro p hp
  have h : env30971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30970_30971 : H12AffineEnvironment.transform 15 14655 env30970 = env30971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14655 env30970 == env30971) = true)

theorem identity30971 : scanCanonicalize (H12AffineFastState.compose env30971 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound30971 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env30972 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,1297,4113,2083,5393,6453,1025,4112,0,33,4096,3,4381,16,292,7220,16,2340,3105,6420,257,2308,3125,4624]

theorem envBound30972 : H12AffineFastState.Bounded env30972 := by
  intro p hp
  have h : env30972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30971_30972 : H12AffineEnvironment.transform 12 4380 env30971 = env30972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env30971 == env30972) = true)

theorem identity30972 : scanCanonicalize (H12AffineFastState.compose env30972 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound30972 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env30973 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,2088,1297,2341,2083,3109,1,1025,2340,0,33,2356,3,2089,16,292,1280,16,2340,3105,32,257,2308,3125,2852]

theorem envBound30973 : H12AffineFastState.Bounded env30973 := by
  intro p hp
  have h : env30973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30972_30973 : H12AffineEnvironment.transform 11 2356 env30972 = env30973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env30972 == env30973) = true)

theorem identity30973 : scanCanonicalize (H12AffineFastState.compose env30973 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound30973 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env30974 : List Nat := [2,4,8,16,32,16,9,256,512,549,2048,2356,2088,820,2341,2083,2560,1,548,2340,0,33,2356,3,2089,16,292,805,16,2340,2564,32,257,2308,2576,2852]

theorem envBound30974 : H12AffineFastState.Bounded env30974 := by
  intro p hp
  have h : env30974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30973_30974 : H12AffineEnvironment.transform 9 549 env30973 = env30974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env30973 == env30974) = true)

theorem identity30974 : scanCanonicalize (H12AffineFastState.compose env30974 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound30974 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30975 : List Nat := [2,4,8,16,32,16,9,47,512,549,2048,2075,2088,539,2058,2083,2560,1,548,2059,0,33,2075,3,2089,16,11,522,16,2059,2564,32,46,2091,2576,2571]

theorem envBound30975 : H12AffineFastState.Bounded env30975 := by
  intro p hp
  have h : env30975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30974_30975 : H12AffineEnvironment.transform 7 47 env30974 = env30975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env30974 == env30975) = true)

theorem identity30975 : scanCanonicalize (H12AffineFastState.compose env30975 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30975 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30976 : List Nat := [2,4,8,16,11,16,9,4,512,526,2048,2075,2051,539,2058,2056,2560,1,527,2059,0,10,2075,3,2050,16,11,522,16,2059,2564,11,5,2048,2576,2571]

theorem envBound30976 : H12AffineFastState.Bounded env30976 := by
  intro p hp
  have h : env30976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30975_30976 : H12AffineEnvironment.transform 4 11 env30975 = env30976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30975 == env30976) = true)

theorem identity30976 : scanCanonicalize (H12AffineFastState.compose env30976 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30976 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30977 : List Nat := [2,4,8,16,11,16,9,4,512,526,0,27,3,539,10,8,512,1,527,11,0,10,27,3,2,16,11,522,16,11,516,11,5,0,528,523]

theorem envBound30977 : H12AffineFastState.Bounded env30977 := by
  intro p hp
  have h : env30977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30976_30977 : H12AffineEnvironment.transform 10 0 env30976 = env30977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30976 == env30977) = true)

theorem identity30977 : scanCanonicalize (H12AffineFastState.compose env30977 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound30977 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30978 : List Nat := [2,4,8,16,11,16,9,4,5,11,0,27,3,30,10,8,5,1,10,11,0,10,27,3,2,16,11,15,16,11,1,11,5,0,21,14]

theorem envBound30978 : H12AffineFastState.Bounded env30978 := by
  intro p hp
  have h : env30978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30977_30978 : H12AffineEnvironment.transform 8 5 env30977 = env30978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env30977 == env30978) = true)

theorem identity30978 : scanCanonicalize (H12AffineFastState.compose env30978 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30978 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env30979 : List Nat := [2,4,3,16,0,16,2,4,5,0,0,16,3,21,1,3,5,1,1,0,0,1,16,3,2,16,0,4,16,0,1,0,5,0,21,5]

theorem envBound30979 : H12AffineFastState.Bounded env30979 := by
  intro p hp
  have h : env30979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30978_30979 : H12AffineEnvironment.transform 2 3 env30978 = env30979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30978 == env30979) = true)

theorem identity30979 : scanCanonicalize (H12AffineFastState.compose env30979 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30979 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30980 : List Nat := [2,4,3,1,0,1,2,4,5,0,0,1,3,4,1,3,5,1,1,0,0,1,1,3,2,1,0,4,1,0,1,0,5,0,4,5]

theorem envBound30980 : H12AffineFastState.Bounded env30980 := by
  intro p hp
  have h : env30980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30979_30980 : H12AffineEnvironment.transform 3 1 env30979 = env30980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30979 == env30980) = true)

theorem identity30980 : scanCanonicalize (H12AffineFastState.compose env30980 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30980 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30981 : List Nat := [0,4,1,1,0,1,0,4,5,0,0,1,1,4,1,1,5,1,1,0,0,1,1,1,0,1,0,4,1,0,1,0,5,0,4,5]

theorem envBound30981 : H12AffineFastState.Bounded env30981 := by
  intro p hp
  have h : env30981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30980_30981 : H12AffineEnvironment.transform 0 0 env30980 = env30981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30980 == env30981) = true)

def env30982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,58517,272513,62612,41350,8328,17,97667,115103,17665,324741,119042,329730,257,95530,103566,63108]

theorem envBound30982 : H12AffineFastState.Bounded env30982 := by
  intro p hp
  have h : env30982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30965_30982 : H12AffineEnvironment.transform 5 17 env30965 = env30982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30965 == env30982) = true)

theorem identity30982 : scanCanonicalize (H12AffineFastState.compose env30982 (packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound30982 : packedSelected [1,3,4,7,9,10,19,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,122147,1025,32769,58517,128418,62612,41350,8328,17,97667,115103,17665,76198,119042,54561,257,95530,103566,63108]

theorem envBound30983 : H12AffineFastState.Bounded env30983 := by
  intro p hp
  have h : env30983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30982_30983 : H12AffineEnvironment.transform 17 122147 env30982 = env30983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env30982 == env30983) = true)

theorem identity30983 : scanCanonicalize (H12AffineFastState.compose env30983 (packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 62850) := by decide +kernel

theorem selectedBound30983 : packedSelected [0,3,5,8,9,16,18,19,20,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,62850,49169,10401,1025,32769,58517,32,62612,41350,8328,17,34817,13341,17665,56356,9344,54561,257,32936,24844,63108]

theorem envBound30984 : H12AffineFastState.Bounded env30984 := by
  intro p hp
  have h : env30984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30983_30984 : H12AffineEnvironment.transform 15 62850 env30983 = env30984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62850 env30983 == env30984) = true)

theorem identity30984 : scanCanonicalize (H12AffineFastState.compose env30984 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound30984 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30985 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,21647,24860,10401,1025,8460,17816,32,21913,139,8328,17,10508,13341,17665,32041,9344,29740,257,8613,24844,22409]

theorem envBound30985 : H12AffineFastState.Bounded env30985 := by
  intro p hp
  have h : env30985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30984_30985 : H12AffineEnvironment.transform 14 8461 env30984 = env30985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env30984 == env30985) = true)

theorem identity30985 : scanCanonicalize (H12AffineFastState.compose env30985 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound30985 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30986 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8461,263,13460,10401,1025,8460,4112,32,17,139,8328,17,10508,13341,4233,10401,9344,8612,257,8613,13444,513]

theorem envBound30986 : H12AffineFastState.Bounded env30986 := by
  intro p hp
  have h : env30986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30985_30986 : H12AffineEnvironment.transform 13 5512 env30985 = env30986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env30985 == env30986) = true)

theorem identity30986 : scanCanonicalize (H12AffineFastState.compose env30986 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound30986 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30987 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,137,263,5392,2341,1025,136,4112,32,17,139,268,17,2184,5529,4233,2341,1284,32,257,33,5376,513]

theorem envBound30987 : H12AffineFastState.Bounded env30987 := by
  intro p hp
  have h : env30987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30986_30987 : H12AffineEnvironment.transform 12 388 env30986 = env30987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env30986 == env30987) = true)

theorem identity30987 : scanCanonicalize (H12AffineFastState.compose env30987 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30987 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30988 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1025,0,4112,32,17,3,268,17,2048,5393,4097,2341,1284,32,257,33,5376,513]

theorem envBound30988 : H12AffineFastState.Bounded env30988 := by
  intro p hp
  have h : env30988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30987_30988 : H12AffineEnvironment.transform 6 8 env30987 = env30988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30987 == env30988) = true)

theorem identity30988 : scanCanonicalize (H12AffineFastState.compose env30988 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound30988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30989 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1045,268,277,1,263,261,2341,1025,0,1029,32,17,3,268,17,2048,260,1044,2341,1284,32,257,33,277,513]

theorem envBound30989 : H12AffineFastState.Bounded env30989 := by
  intro p hp
  have h : env30989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30988_30989 : H12AffineEnvironment.transform 11 1045 env30988 = env30989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env30988 == env30989) = true)

theorem identity30989 : scanCanonicalize (H12AffineFastState.compose env30989 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30989 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30990 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1045,268,277,1,263,261,2341,1025,0,1029,32,17,3,268,17,2048,260,1044,2341,1284,32,257,33,277,1]

theorem envBound30990 : H12AffineFastState.Bounded env30990 := by
  intro p hp
  have h : env30990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30989_30990 : H12AffineEnvironment.transform 8 0 env30989 = env30990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30989 == env30990) = true)

theorem identity30990 : scanCanonicalize (H12AffineFastState.compose env30990 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30990 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30991 : List Nat := [2,4,8,16,32,17,8,37,0,1024,2048,1045,41,48,1,34,32,2048,1025,0,1029,32,17,3,41,17,2048,33,1044,2048,1057,32,36,33,48,1]

theorem envBound30991 : H12AffineFastState.Bounded env30991 := by
  intro p hp
  have h : env30991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30990_30991 : H12AffineEnvironment.transform 7 37 env30990 = env30991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30990 == env30991) = true)

theorem identity30991 : scanCanonicalize (H12AffineFastState.compose env30991 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30991 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30992 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1045,9,16,1,2,0,2048,1025,0,1029,0,17,3,9,17,2048,1,1044,2048,1025,0,4,1,16,1]

theorem envBound30992 : H12AffineFastState.Bounded env30992 := by
  intro p hp
  have h : env30992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30991_30992 : H12AffineEnvironment.transform 4 0 env30991 = env30992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30991 == env30992) = true)

theorem identity30992 : scanCanonicalize (H12AffineFastState.compose env30992 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound30992 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30993 : List Nat := [2,4,8,16,0,17,8,5,0,20,2048,1,9,16,1,2,0,2048,21,0,17,0,17,3,9,17,2048,1,0,2048,21,0,4,1,16,1]

theorem envBound30993 : H12AffineFastState.Bounded env30993 := by
  intro p hp
  have h : env30993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30992_30993 : H12AffineEnvironment.transform 9 20 env30992 = env30993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env30992 == env30993) = true)

theorem identity30993 : scanCanonicalize (H12AffineFastState.compose env30993 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound30993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30994 : List Nat := [2,4,8,16,0,17,8,5,0,20,0,1,9,16,1,2,0,0,21,0,17,0,17,3,9,17,0,1,0,0,21,0,4,1,16,1]

theorem envBound30994 : H12AffineFastState.Bounded env30994 := by
  intro p hp
  have h : env30994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30993_30994 : H12AffineEnvironment.transform 10 0 env30993 = env30994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env30993 == env30994) = true)

theorem identity30994 : scanCanonicalize (H12AffineFastState.compose env30994 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30995 : List Nat := [2,4,3,16,0,17,3,5,0,20,0,1,2,16,1,2,0,0,21,0,17,0,17,3,2,17,0,1,0,0,21,0,4,1,16,1]

theorem envBound30995 : H12AffineFastState.Bounded env30995 := by
  intro p hp
  have h : env30995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30994_30995 : H12AffineEnvironment.transform 2 3 env30994 = env30995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30994 == env30995) = true)

def env30996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543747,115150,17664,2363456,119043,4268163,257,2199998,2191386,63188]

theorem envBound30996 : H12AffineFastState.Bounded env30996 := by
  intro p hp
  have h : env30996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30923_30996 : H12AffineEnvironment.transform 22 2101329 env30923 = env30996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env30923 == env30996) = true)

def env30997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97667,115150,17664,2363456,119043,329731,257,2199998,2191386,63188]

theorem envBound30997 : H12AffineFastState.Bounded env30997 := by
  intro p hp
  have h : env30997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30996_30997 : H12AffineEnvironment.transform 21 272512 env30996 = env30997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30996 == env30997) = true)

def env30998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101329,2114882,8192,64,97547,115014,17664,2363456,119043,329731,257,2199862,2191386,63068]

theorem envBound30998 : H12AffineFastState.Bounded env30998 := by
  intro p hp
  have h : env30998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30997_30998 : H12AffineEnvironment.transform 6 8 env30997 = env30998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30997 == env30998) = true)

def env30999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21762,8192,64,97547,115014,17664,262144,119043,329731,257,98678,90202,63068]

theorem envBound30999 : H12AffineFastState.Bounded env30999 := by
  intro p hp
  have h : env30999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30998_30999 : H12AffineEnvironment.transform 20 4160 env30998 = env30999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30998 == env30999) = true)

theorem identity30999 : scanCanonicalize (H12AffineFastState.compose env30999 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound30999 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56436,1025,32769,4160,62588,17,21762,8192,64,97547,115014,17664,56436,119043,119927,257,98678,90202,63068]

theorem envBound31000 : H12AffineFastState.Bounded env31000 := by
  intro p hp
  have h : env31000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30999_31000 : H12AffineEnvironment.transform 17 56436 env30999 = env31000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env30999 == env31000) = true)

theorem identity31000 : scanCanonicalize (H12AffineFastState.compose env31000 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound31000 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,49169,56436,1025,32769,4160,62588,17,21762,8192,64,64604,16401,17664,56436,20564,21792,257,33,57613,63068]

theorem envBound31001 : H12AffineFastState.Bounded env31001 := by
  intro p hp
  have h : env31001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31000_31001 : H12AffineEnvironment.transform 15 33111 env31000 = env31001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env31000 == env31001) = true)

theorem identity31001 : scanCanonicalize (H12AffineFastState.compose env31001 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound31001 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,30042,13340,10361,1025,29708,4160,113,17,21762,8192,64,2129,16401,17664,10361,20564,21792,257,33,5376,593]

theorem envBound31002 : H12AffineFastState.Bounded env31002 := by
  intro p hp
  have h : env31002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31001_31002 : H12AffineEnvironment.transform 14 29709 env31001 = env31002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env31001 == env31002) = true)

theorem identity31002 : scanCanonicalize (H12AffineFastState.compose env31002 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31002 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,8203,13340,10361,1025,8541,4160,113,17,83,8192,64,2129,5440,4177,10361,1285,113,257,33,5376,593]

theorem envBound31003 : H12AffineFastState.Bounded env31003 := by
  intro p hp
  have h : env31003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31002_31003 : H12AffineEnvironment.transform 13 5457 env31002 = env31003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31002 == env31003) = true)

theorem identity31003 : scanCanonicalize (H12AffineFastState.compose env31003 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31003 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5457,292,115,5220,2049,1025,293,4160,113,17,83,120,64,2129,5440,4177,2049,1285,113,257,33,5376,593]

theorem envBound31004 : H12AffineFastState.Bounded env31004 := by
  intro p hp
  have h : env31004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31003_31004 : H12AffineEnvironment.transform 12 120 env31003 = env31004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31003 == env31004) = true)

theorem identity31004 : scanCanonicalize (H12AffineFastState.compose env31004 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound31004 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env31005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,120,2048,292,115,2357,2049,1025,293,3345,113,17,83,120,64,2129,2065,3328,2049,1285,113,257,33,2129,593]

theorem envBound31005 : H12AffineFastState.Bounded env31005 := by
  intro p hp
  have h : env31005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31004_31005 : H12AffineEnvironment.transform 11 3409 env31004 = env31005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env31004 == env31005) = true)

theorem identity31005 : scanCanonicalize (H12AffineFastState.compose env31005 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31005 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31006 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,3188,120,2048,1,115,2064,2049,1025,0,3124,113,17,83,120,64,2129,2065,3109,2049,1056,113,36,33,2129,593]

theorem envBound31006 : H12AffineFastState.Bounded env31006 := by
  intro p hp
  have h : env31006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31005_31006 : H12AffineEnvironment.transform 7 37 env31005 = env31006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31005 == env31006) = true)

theorem identity31006 : scanCanonicalize (H12AffineFastState.compose env31006 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31006 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env31007 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,40,2048,1,35,2064,2049,1025,0,3124,33,17,3,40,16,2049,2065,3109,2049,1056,33,36,33,2049,513]

theorem envBound31007 : H12AffineFastState.Bounded env31007 := by
  intro p hp
  have h : env31007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31006_31007 : H12AffineEnvironment.transform 5 16 env31006 = env31007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31006 == env31007) = true)

theorem identity31007 : scanCanonicalize (H12AffineFastState.compose env31007 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1060) := by decide +kernel

theorem selectedBound31007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31008 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1060,0,40,1060,1,35,1076,1061,1025,0,16,33,17,3,40,16,1061,1077,1,1061,1056,33,36,33,1061,513]

theorem envBound31008 : H12AffineFastState.Bounded env31008 := by
  intro p hp
  have h : env31008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31007_31008 : H12AffineEnvironment.transform 10 1060 env31007 = env31008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env31007 == env31008) = true)

theorem identity31008 : scanCanonicalize (H12AffineFastState.compose env31008 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound31008 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31009 : List Nat := [2,4,8,16,32,16,8,37,17,1024,1060,0,40,1060,1,35,1076,1061,1025,0,16,33,17,3,40,16,1061,1077,1,1061,1056,33,36,33,1061,16]

theorem envBound31009 : H12AffineFastState.Bounded env31009 := by
  intro p hp
  have h : env31009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31008_31009 : H12AffineEnvironment.transform 8 17 env31008 = env31009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env31008 == env31009) = true)

theorem identity31009 : scanCanonicalize (H12AffineFastState.compose env31009 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound31009 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31010 : List Nat := [2,4,8,16,32,16,8,37,17,36,0,0,40,0,1,35,16,1,37,0,16,33,17,3,40,16,1,17,1,1,4,33,36,33,1,16]

theorem envBound31010 : H12AffineFastState.Bounded env31010 := by
  intro p hp
  have h : env31010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31009_31010 : H12AffineEnvironment.transform 9 36 env31009 = env31010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env31009 == env31010) = true)

def env31011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,16,21763,8192,64,97547,115014,17664,262145,119043,329731,257,98679,90203,63068]

theorem envBound31011 : H12AffineFastState.Bounded env31011 := by
  intro p hp
  have h : env31011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30998_31011 : H12AffineEnvironment.transform 20 4161 env30998 = env31011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env30998 == env31011) = true)

theorem identity31011 : scanCanonicalize (H12AffineFastState.compose env31011 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,262144,1025,29788,4161,272392,16,21763,8192,64,97547,79131,17664,262145,75102,329731,257,95530,90203,513]

theorem envBound31012 : H12AffineFastState.Bounded env31012 := by
  intro p hp
  have h : env31012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31011_31012 : H12AffineEnvironment.transform 14 29789 env31011 = env31012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31011 == env31012) = true)

theorem identity31012 : scanCanonicalize (H12AffineFastState.compose env31012 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound31012 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21591,13388,262144,1025,29788,4161,272392,16,21763,8192,64,10588,24908,17664,262145,28937,285780,257,8573,13324,513]

theorem envBound31013 : H12AffineFastState.Bounded env31013 := by
  intro p hp
  have h : env31013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31012_31013 : H12AffineEnvironment.transform 15 21591 env31012 = env31013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env31012 == env31013) = true)

theorem identity31013 : scanCanonicalize (H12AffineFastState.compose env31013 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31013 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21591,5392,262144,1025,21760,4161,264532,16,21763,348,64,2048,16400,17664,262145,20565,285780,257,33,5456,513]

theorem envBound31014 : H12AffineFastState.Bounded env31014 := by
  intro p hp
  have h : env31014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31013_31014 : H12AffineEnvironment.transform 12 348 env31013 = env31014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31013 == env31014) = true)

theorem identity31014 : scanCanonicalize (H12AffineFastState.compose env31014 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound31014 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21591,5392,2420,1025,21760,4161,32,16,21763,348,64,2048,16400,17664,2421,20565,21792,257,33,5456,513]

theorem envBound31015 : H12AffineFastState.Bounded env31015 := by
  intro p hp
  have h : env31015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31014_31015 : H12AffineEnvironment.transform 17 2420 env31014 = env31015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env31014 == env31015) = true)

theorem identity31015 : scanCanonicalize (H12AffineFastState.compose env31015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4112,1297,1095,5392,2420,1025,1296,4161,32,16,1299,348,64,2048,4096,5392,2421,69,1328,257,33,5456,513]

theorem envBound31016 : H12AffineFastState.Bounded env31016 := by
  intro p hp
  have h : env31016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31015_31016 : H12AffineEnvironment.transform 13 4112 env31015 = env31016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env31015 == env31016) = true)

theorem identity31016 : scanCanonicalize (H12AffineFastState.compose env31016 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound31016 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,348,4112,1297,1095,5392,1076,1025,1296,4161,32,16,1299,348,64,1344,4096,5392,1077,69,1328,257,33,5456,513]

theorem envBound31017 : H12AffineFastState.Bounded env31017 := by
  intro p hp
  have h : env31017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31016_31017 : H12AffineEnvironment.transform 10 1344 env31016 = env31017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env31016 == env31017) = true)

theorem identity31017 : scanCanonicalize (H12AffineFastState.compose env31017 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31017 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31018 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,4096,41,4112,1124,1095,5221,1076,1025,1125,4161,32,16,1126,41,64,1077,4096,5221,1077,69,1093,116,33,5157,513]

theorem envBound31018 : H12AffineFastState.Bounded env31018 := by
  intro p hp
  have h : env31018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31017_31018 : H12AffineEnvironment.transform 7 117 env31017 = env31018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31017 == env31018) = true)

theorem identity31018 : scanCanonicalize (H12AffineFastState.compose env31018 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound31018 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env31019 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1077,1141,41,1125,1124,1095,16,1076,1025,1125,1076,32,16,1126,41,64,1077,1141,16,1077,69,1093,116,33,80,513]

theorem envBound31019 : H12AffineFastState.Bounded env31019 := by
  intro p hp
  have h : env31019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31018_31019 : H12AffineEnvironment.transform 11 1141 env31018 = env31019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env31018 == env31019) = true)

theorem identity31019 : scanCanonicalize (H12AffineFastState.compose env31019 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound31019 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31020 : List Nat := [2,4,8,16,32,64,8,117,512,100,81,17,41,1,0,35,16,80,101,1,80,32,16,2,41,64,81,17,16,81,69,33,116,33,80,513]

theorem envBound31020 : H12AffineFastState.Bounded env31020 := by
  intro p hp
  have h : env31020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31019_31020 : H12AffineEnvironment.transform 9 100 env31019 = env31020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env31019 == env31020) = true)

theorem identity31020 : scanCanonicalize (H12AffineFastState.compose env31020 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound31020 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31021 : List Nat := [2,4,8,16,32,64,8,117,49,100,81,17,41,1,0,35,16,80,101,1,80,32,16,2,41,64,81,17,16,81,69,33,116,33,80,48]

theorem envBound31021 : H12AffineFastState.Bounded env31021 := by
  intro p hp
  have h : env31021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31020_31021 : H12AffineEnvironment.transform 8 49 env31020 = env31021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env31020 == env31021) = true)

theorem identity31021 : scanCanonicalize (H12AffineFastState.compose env31021 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31022 : List Nat := [2,4,8,0,32,64,8,101,33,100,65,1,41,1,0,35,0,64,101,1,64,32,0,2,41,64,65,1,0,65,69,33,100,33,64,32]

theorem envBound31022 : H12AffineFastState.Bounded env31022 := by
  intro p hp
  have h : env31022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31021_31022 : H12AffineEnvironment.transform 3 0 env31021 = env31022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31021 == env31022) = true)

theorem identity31022 : scanCanonicalize (H12AffineFastState.compose env31022 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound31022 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31023 : List Nat := [2,4,8,0,32,32,8,5,33,4,33,1,41,1,0,35,0,32,5,1,32,32,0,2,41,32,33,1,0,33,37,33,4,33,32,32]

theorem envBound31023 : H12AffineFastState.Bounded env31023 := by
  intro p hp
  have h : env31023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31022_31023 : H12AffineEnvironment.transform 5 32 env31022 = env31023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env31022 == env31023) = true)

theorem identity31023 : scanCanonicalize (H12AffineFastState.compose env31023 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31023 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31024 : List Nat := [2,4,8,0,1,1,8,5,0,4,0,1,8,1,0,2,0,1,5,1,1,1,0,2,8,1,0,1,0,0,4,0,4,0,1,1]

theorem envBound31024 : H12AffineFastState.Bounded env31024 := by
  intro p hp
  have h : env31024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31023_31024 : H12AffineEnvironment.transform 4 1 env31023 = env31024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31023 == env31024) = true)

def env31025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272393,2101329,2114882,8193,64,97546,115015,17664,2363456,119043,329731,257,2199863,2191386,63069]

theorem envBound31025 : H12AffineFastState.Bounded env31025 := by
  intro p hp
  have h : env31025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30997_31025 : H12AffineEnvironment.transform 6 9 env30997 = env31025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30997 == env31025) = true)

def env31026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21762,8193,64,97546,115015,17664,262144,119043,329731,257,98679,90202,63069]

theorem envBound31026 : H12AffineFastState.Bounded env31026 := by
  intro p hp
  have h : env31026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31025_31026 : H12AffineEnvironment.transform 20 4160 env31025 = env31026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31025 == env31026) = true)

theorem identity31026 : scanCanonicalize (H12AffineFastState.compose env31026 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound31026 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,4160,21793,17,21762,8193,64,97546,115015,17664,32040,119043,95531,257,98679,90202,63069]

theorem envBound31027 : H12AffineFastState.Bounded env31027 := by
  intro p hp
  have h : env31027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31026_31027 : H12AffineEnvironment.transform 17 32040 env31026 = env31027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env31026 == env31027) = true)

theorem identity31027 : scanCanonicalize (H12AffineFastState.compose env31027 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound31027 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31028 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8494,49169,32040,1025,32769,4160,21793,17,21762,8193,64,23588,57449,17664,32040,61485,21509,257,41049,16756,63069]

theorem envBound31028 : H12AffineFastState.Bounded env31028 := by
  intro p hp
  have h : env31028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31027_31028 : H12AffineEnvironment.transform 15 8494 env31027 = env31028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env31027 == env31028) = true)

theorem identity31028 : scanCanonicalize (H12AffineFastState.compose env31028 (packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound31028 : packedSelected [0,3,4,5,7,10,12,15,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env31029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,8494,24860,32040,1025,8460,4160,21793,17,21762,8193,64,23588,16740,17664,32040,20768,21509,257,340,16756,22352]

theorem envBound31029 : H12AffineFastState.Bounded env31029 := by
  intro p hp
  have h : env31029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31028_31029 : H12AffineEnvironment.transform 14 8461 env31028 = env31029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env31028 == env31029) = true)

theorem identity31029 : scanCanonicalize (H12AffineFastState.compose env31029 (packedSelected [0,3,4,5,7,10,12,15,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31029 : packedSelected [0,3,4,5,7,10,12,15,22] rootPS < 2^1333 := by decide +kernel

def env31030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,35,16401,23589,1025,1,4160,21793,17,21762,268,64,23588,16740,17664,23589,20768,21509,257,340,16756,22352]

theorem envBound31030 : H12AffineFastState.Bounded env31030 := by
  intro p hp
  have h : env31030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31029_31030 : H12AffineEnvironment.transform 12 269 env31029 = env31030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31029 == env31030) = true)

theorem identity31030 : scanCanonicalize (H12AffineFastState.compose env31030 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound31030 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,0,35,5440,2420,1025,1,4160,112,17,83,268,64,2421,5173,4177,2420,1137,340,257,340,5157,513]

theorem envBound31031 : H12AffineFastState.Bounded env31031 := by
  intro p hp
  have h : env31031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31030_31031 : H12AffineEnvironment.transform 13 5457 env31030 = env31031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env31030 == env31031) = true)

theorem identity31031 : scanCanonicalize (H12AffineFastState.compose env31031 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31032 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5156,0,35,5173,2049,1025,1,4160,112,17,83,121,64,2048,5173,4177,2049,1137,33,116,33,5157,513]

theorem envBound31032 : H12AffineFastState.Bounded env31032 := by
  intro p hp
  have h : env31032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31031_31032 : H12AffineEnvironment.transform 7 117 env31031 = env31032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31031 == env31032) = true)

theorem identity31032 : scanCanonicalize (H12AffineFastState.compose env31032 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31032 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env31033 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4112,0,35,4097,2049,53,1,4160,112,17,83,121,64,2048,4097,4177,2049,69,33,116,33,4113,513]

theorem envBound31033 : H12AffineFastState.Bounded env31033 := by
  intro p hp
  have h : env31033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31032_31033 : H12AffineEnvironment.transform 9 52 env31032 = env31033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31032 == env31033) = true)

def env31034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272393,16,21763,8193,64,97546,115015,17664,262145,119043,329731,257,98678,90203,63069]

theorem envBound31034 : H12AffineFastState.Bounded env31034 := by
  intro p hp
  have h : env31034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31025_31034 : H12AffineEnvironment.transform 20 4161 env31025 = env31034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31025 == env31034) = true)

theorem identity31034 : scanCanonicalize (H12AffineFastState.compose env31034 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31034 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,262144,1025,32769,4161,272393,16,3,8193,64,75786,103495,4096,262145,99331,329731,257,98678,79195,41821]

theorem envBound31035 : H12AffineFastState.Bounded env31035 := by
  intro p hp
  have h : env31035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31034_31035 : H12AffineEnvironment.transform 13 5376 env31034 = env31035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31034 == env31035) = true)

theorem identity31035 : scanCanonicalize (H12AffineFastState.compose env31035 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound31035 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env31036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38161,10361,1025,32769,4161,112,16,3,8193,64,75786,103495,4096,10360,99331,73850,257,98678,79195,41821]

theorem envBound31036 : H12AffineFastState.Bounded env31036 := by
  intro p hp
  have h : env31036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31035_31036 : H12AffineEnvironment.transform 17 10361 env31035 = env31036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env31035 == env31036) = true)

theorem identity31036 : scanCanonicalize (H12AffineFastState.compose env31036 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31036 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env31037 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,32768,65536,37940,10361,1025,32769,4161,112,16,3,8193,64,75786,103495,4096,10360,99331,73850,36,98387,78974,41592]

theorem envBound31037 : H12AffineFastState.Bounded env31037 := by
  intro p hp
  have h : env31037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31036_31037 : H12AffineEnvironment.transform 7 37 env31036 = env31037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31036 == env31037) = true)

theorem identity31037 : scanCanonicalize (H12AffineFastState.compose env31037 (packedSelected [0,7,9,14,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound31037 : packedSelected [0,7,9,14,16,22] rootPS < 2^1333 := by decide +kernel

def env31038 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,32768,32803,37940,10361,1025,32769,4161,112,16,3,8193,64,43049,5220,4096,10360,1056,41049,36,112,46173,41592]

theorem envBound31038 : H12AffineFastState.Bounded env31038 := by
  intro p hp
  have h : env31038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31037_31038 : H12AffineEnvironment.transform 15 32803 env31037 = env31038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env31037 == env31038) = true)

theorem identity31038 : scanCanonicalize (H12AffineFastState.compose env31038 (packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound31038 : packedSelected [0,1,2,4,6,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env31039 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5157,8232,8203,13340,10361,1025,8233,4161,112,16,3,8193,64,2049,5220,4096,10360,1056,113,36,112,5237,592]

theorem envBound31039 : H12AffineFastState.Bounded env31039 := by
  intro p hp
  have h : env31039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31038_31039 : H12AffineEnvironment.transform 14 8232 env31038 = env31039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env31038 == env31039) = true)

theorem identity31039 : scanCanonicalize (H12AffineFastState.compose env31039 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31039 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31040 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5157,80,115,5220,2049,1025,81,4161,112,16,3,121,64,2049,5220,4096,2048,1056,113,36,112,5237,592]

theorem envBound31040 : H12AffineFastState.Bounded env31040 := by
  intro p hp
  have h : env31040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31039_31040 : H12AffineEnvironment.transform 12 120 env31039 = env31040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31039 == env31040) = true)

def env31041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97666,115150,17664,2363456,119043,329730,257,2199998,2191386,63188]

theorem envBound31041 : H12AffineFastState.Bounded env31041 := by
  intro p hp
  have h : env31041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30996_31041 : H12AffineEnvironment.transform 21 272513 env30996 = env31041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30996 == env31041) = true)

theorem identity31041 : scanCanonicalize (H12AffineFastState.compose env31041 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound31041 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272513,17,21762,8328,64,97666,115150,17664,262144,119043,329730,257,98814,90202,63188]

theorem envBound31042 : H12AffineFastState.Bounded env31042 := by
  intro p hp
  have h : env31042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31041_31042 : H12AffineEnvironment.transform 20 4160 env31041 = env31042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31041 == env31042) = true)

def env31043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21762,8192,64,97546,115014,17664,262144,119043,329730,257,98678,90202,63068]

theorem envBound31043 : H12AffineFastState.Bounded env31043 := by
  intro p hp
  have h : env31043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31042_31043 : H12AffineEnvironment.transform 6 8 env31042 = env31043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31042 == env31043) = true)

theorem identity31043 : scanCanonicalize (H12AffineFastState.compose env31043 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound31043 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31044 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56436,1025,32769,4160,62589,17,21762,8192,64,97546,115014,17664,56436,119043,119926,257,98678,90202,63068]

theorem envBound31044 : H12AffineFastState.Bounded env31044 := by
  intro p hp
  have h : env31044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31043_31044 : H12AffineEnvironment.transform 17 56436 env31043 = env31044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env31043 == env31044) = true)

theorem identity31044 : scanCanonicalize (H12AffineFastState.compose env31044 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound31044 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31045 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,5393,2420,1025,21761,4160,8573,17,21762,8192,64,97546,70726,17664,2420,66563,65910,257,87158,90202,9052]

theorem envBound31045 : H12AffineFastState.Bounded env31045 := by
  intro p hp
  have h : env31045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31044_31045 : H12AffineEnvironment.transform 14 21760 env31044 = env31045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env31044 == env31045) = true)

theorem identity31045 : scanCanonicalize (H12AffineFastState.compose env31045 (packedSelected [2,3,5,6,14,15,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31045 : packedSelected [2,3,5,6,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env31046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,5393,2420,1025,21761,4160,8573,17,21762,8192,64,23809,13389,17664,2420,9224,8573,257,29821,16465,9052]

theorem envBound31046 : H12AffineFastState.Bounded env31046 := by
  intro p hp
  have h : env31046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31045_31046 : H12AffineEnvironment.transform 15 8203 env31045 = env31046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31045 == env31046) = true)

def env31047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21762,8193,64,97547,115015,17664,262144,119043,329730,257,98679,90202,63069]

theorem envBound31047 : H12AffineFastState.Bounded env31047 := by
  intro p hp
  have h : env31047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31042_31047 : H12AffineEnvironment.transform 6 9 env31042 = env31047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31042 == env31047) = true)

theorem identity31047 : scanCanonicalize (H12AffineFastState.compose env31047 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound31047 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32040,1025,32769,4160,21792,17,21762,8193,64,97547,115015,17664,32040,119043,95530,257,98679,90202,63069]

theorem envBound31048 : H12AffineFastState.Bounded env31048 := by
  intro p hp
  have h : env31048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31047_31048 : H12AffineEnvironment.transform 17 32040 env31047 = env31048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env31047 == env31048) = true)

theorem identity31048 : scanCanonicalize (H12AffineFastState.compose env31048 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound31048 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32803,49169,32040,1025,32769,4160,21792,17,21762,8193,64,64808,16740,17664,32040,20768,62729,257,340,57465,63069]

theorem envBound31049 : H12AffineFastState.Bounded env31049 := by
  intro p hp
  have h : env31049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31048_31049 : H12AffineEnvironment.transform 15 32803 env31048 = env31049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env31048 == env31049) = true)

theorem identity31049 : scanCanonicalize (H12AffineFastState.compose env31049 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,18,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31049 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,16,18,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,32803,49169,23668,1025,32769,4160,21792,17,21762,349,64,56436,16740,17664,23668,20768,54357,257,340,49445,55041]

theorem envBound31050 : H12AffineFastState.Bounded env31050 := by
  intro p hp
  have h : env31050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31049_31050 : H12AffineEnvironment.transform 12 348 env31049 = env31050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31049 == env31050) = true)

theorem identity31050 : scanCanonicalize (H12AffineFastState.compose env31050 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31050 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31051 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,32803,49169,23668,1025,32769,4160,21589,17,21623,40,64,56436,16401,17525,23668,20565,54357,116,33,49232,54900]

theorem envBound31051 : H12AffineFastState.Bounded env31051 := by
  intro p hp
  have h : env31051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31050_31051 : H12AffineEnvironment.transform 7 117 env31050 = env31051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31050 == env31051) = true)

theorem identity31051 : scanCanonicalize (H12AffineFastState.compose env31051 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound31051 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env31052 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21621,21590,5220,23668,1025,21620,4160,21589,17,21623,40,64,2049,16401,17525,23668,20565,32,116,33,5157,513]

theorem envBound31052 : H12AffineFastState.Bounded env31052 := by
  intro p hp
  have h : env31052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31051_31052 : H12AffineEnvironment.transform 14 21621 env31051 = env31052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env31051 == env31052) = true)

theorem identity31052 : scanCanonicalize (H12AffineFastState.compose env31052 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound31052 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31053 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,4113,1124,1095,5220,3173,1025,1125,4160,1092,17,1126,40,64,2049,4096,5220,3173,68,32,116,33,5157,513]

theorem envBound31053 : H12AffineFastState.Bounded env31053 := by
  intro p hp
  have h : env31053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31052_31053 : H12AffineEnvironment.transform 13 4113 env31052 = env31053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31052 == env31053) = true)

theorem identity31053 : scanCanonicalize (H12AffineFastState.compose env31053 (packedSelected [0,1,2,3,5,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2656) := by decide +kernel

theorem selectedBound31053 : packedSelected [0,1,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31054 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2656,41,2673,1124,1095,3588,3173,1025,1125,2592,1092,17,1126,40,64,2049,2656,3588,3173,68,32,116,33,3653,513]

theorem envBound31054 : H12AffineFastState.Bounded env31054 := by
  intro p hp
  have h : env31054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31053_31054 : H12AffineEnvironment.transform 11 2656 env31053 = env31054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2656 env31053 == env31054) = true)

theorem identity31054 : scanCanonicalize (H12AffineFastState.compose env31054 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound31054 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env31055 : List Nat := [2,4,8,16,32,64,9,117,512,1024,545,65,41,80,1124,1095,1061,1604,1025,1125,1,1092,17,1126,40,64,544,65,1061,1604,68,32,116,33,1124,513]

theorem envBound31055 : H12AffineFastState.Bounded env31055 := by
  intro p hp
  have h : env31055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31054_31055 : H12AffineEnvironment.transform 10 545 env31054 = env31055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env31054 == env31055) = true)

def env31056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound31056 : H12AffineFastState.Bounded env31056 := by
  intro p hp
  have h : env31056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30626_31056 : H12AffineEnvironment.transform 26 30393345 env30626 = env31056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env30626 == env31056) = true)

def env31057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound31057 : H12AffineFastState.Bounded env31057 := by
  intro p hp
  have h : env31057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31056_31057 : H12AffineEnvironment.transform 18 1024 env31056 = env31057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31056 == env31057) = true)

theorem identity31057 : scanCanonicalize (H12AffineFastState.compose env31057 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound31057 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388626,8328,64,4702227,10585247,10507601,8830976,99330,14771666,256,2213055,2172187,41940]

theorem envBound31058 : H12AffineFastState.Bounded env31058 := by
  intro p hp
  have h : env31058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31057_31058 : H12AffineEnvironment.transform 23 8388626 env31057 = env31058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env31057 == env31058) = true)

def env31059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147610,8328,64,4702227,2343959,2233817,295048,99330,6497626,256,2213055,2172187,41940]

theorem envBound31059 : H12AffineFastState.Bounded env31059 := by
  intro p hp
  have h : env31059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31058_31059 : H12AffineEnvironment.transform 22 147592 env31058 = env31059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env31058 == env31059) = true)

def env31060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147610,8328,64,4450483,2343959,2233817,43048,99330,6497626,256,2213055,2172187,41940]

theorem envBound31060 : H12AffineFastState.Bounded env31060 := by
  intro p hp
  have h : env31060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31059_31060 : H12AffineEnvironment.transform 17 10400 env31059 = env31060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31059 == env31060) = true)

theorem identity31060 : scanCanonicalize (H12AffineFastState.compose env31060 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31060 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4303011,2196487,2119113,43048,99330,6382922,256,2213055,2172187,41940]

theorem envBound31061 : H12AffineFastState.Bounded env31061 := by
  intro p hp
  have h : env31061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31060_31061 : H12AffineEnvironment.transform 16 16400 env31060 = env31061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31060 == env31061) = true)

theorem identity31061 : scanCanonicalize (H12AffineFastState.compose env31061 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31061 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env31062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4229288,2139148,2119113,43048,41993,6309185,256,2155700,2098448,41940]

theorem envBound31062 : H12AffineFastState.Bounded env31062 := by
  intro p hp
  have h : env31062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31061_31062 : H12AffineEnvironment.transform 15 8203 env31061 = env31062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31061 == env31062) = true)

theorem identity31062 : scanCanonicalize (H12AffineFastState.compose env31062 (packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS)) = affineNative (2^(20+1) ^^^ 17816) := by decide +kernel

theorem selectedBound31062 : packedSelected [1,3,4,5,7,8,9,10,11,16,17,18,19,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env31063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,17816,4194304,152,138,8328,64,4229288,57748,4177,43048,41993,4194521,256,41260,16520,41940]

theorem envBound31063 : H12AffineFastState.Bounded env31063 := by
  intro p hp
  have h : env31063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31062_31063 : H12AffineEnvironment.transform 20 17816 env31062 = env31063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17816 env31062 == env31063) = true)

theorem identity31063 : scanCanonicalize (H12AffineFastState.compose env31063 (packedSelected [4,5,7,8,9,10,16,17,19,20,24,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31063 : packedSelected [4,5,7,8,9,10,16,17,19,20,24,27,28] rootPS < 2^1333 := by decide +kernel

def env31064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,17816,32,152,138,8328,64,34952,57748,4177,43048,41993,249,256,41260,16520,41940]

theorem envBound31064 : H12AffineFastState.Bounded env31064 := by
  intro p hp
  have h : env31064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31063_31064 : H12AffineEnvironment.transform 21 32 env31063 = env31064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31063 == env31064) = true)

theorem identity31064 : scanCanonicalize (H12AffineFastState.compose env31064 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound31064 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env31065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,32768,8203,5221,10400,1024,32769,4589,32,152,138,8328,64,34952,46561,4177,43048,41993,249,256,41260,5373,41940]

theorem envBound31065 : H12AffineFastState.Bounded env31065 := by
  intro p hp
  have h : env31065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31064_31065 : H12AffineEnvironment.transform 13 5237 env31064 = env31065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env31064 == env31065) = true)

theorem identity31065 : scanCanonicalize (H12AffineFastState.compose env31065 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound31065 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,8433,8203,5221,10400,1024,8432,4589,32,152,138,8328,64,10361,5392,4177,2265,1272,249,256,477,5373,805]

theorem envBound31066 : H12AffineFastState.Bounded env31066 := by
  intro p hp
  have h : env31066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31065_31066 : H12AffineEnvironment.transform 14 8433 env31065 = env31066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env31065 == env31066) = true)

theorem identity31066 : scanCanonicalize (H12AffineFastState.compose env31066 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31066 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env31067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5237,293,479,5221,2420,1024,292,4589,32,152,138,348,64,2477,5392,4177,2265,1272,249,256,477,5373,805]

theorem envBound31067 : H12AffineFastState.Bounded env31067 := by
  intro p hp
  have h : env31067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31066_31067 : H12AffineEnvironment.transform 12 468 env31066 = env31067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31066 == env31067) = true)

theorem identity31067 : scanCanonicalize (H12AffineFastState.compose env31067 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31067 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31068 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5237,80,170,5221,2049,1024,81,4248,32,152,138,41,64,2264,5221,4177,2265,1272,249,117,168,5373,592]

theorem envBound31068 : H12AffineFastState.Bounded env31068 := by
  intro p hp
  have h : env31068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31067_31068 : H12AffineEnvironment.transform 7 117 env31067 = env31068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31067 == env31068) = true)

theorem identity31068 : scanCanonicalize (H12AffineFastState.compose env31068 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31068 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31069 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,161,5157,0,170,5173,2049,1024,1,4248,32,152,138,41,16,2184,5173,4097,2185,1192,169,37,168,5293,512]

theorem envBound31069 : H12AffineFastState.Bounded env31069 := by
  intro p hp
  have h : env31069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31068_31069 : H12AffineEnvironment.transform 5 16 env31068 = env31069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31068 == env31069) = true)

theorem identity31069 : scanCanonicalize (H12AffineFastState.compose env31069 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31070 : List Nat := [2,4,8,16,0,16,128,5,512,1024,2048,4096,129,5125,0,138,5141,2049,1024,1,4248,0,152,138,9,16,2184,5141,4097,2185,1160,137,5,136,5261,512]

theorem envBound31070 : H12AffineFastState.Bounded env31070 := by
  intro p hp
  have h : env31070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31069_31070 : H12AffineEnvironment.transform 4 0 env31069 = env31070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31069 == env31070) = true)

def env31071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147610,8328,64,4450482,2343959,2233817,43049,99330,6497626,256,2213055,2172187,41940]

theorem envBound31071 : H12AffineFastState.Bounded env31071 := by
  intro p hp
  have h : env31071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31059_31071 : H12AffineEnvironment.transform 17 10401 env31059 = env31071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31059 == env31071) = true)

theorem identity31071 : scanCanonicalize (H12AffineFastState.compose env31071 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31071 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147456,147474,8192,64,4450362,2343959,2233681,43049,99330,6497626,256,2212919,2172187,41820]

theorem envBound31072 : H12AffineFastState.Bounded env31072 := by
  intro p hp
  have h : env31072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31071_31072 : H12AffineEnvironment.transform 6 8 env31071 = env31072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31071 == env31072) = true)

theorem identity31072 : scanCanonicalize (H12AffineFastState.compose env31072 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31072 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147474,8192,64,4409703,2319690,2233681,2420,75103,6497626,256,2188650,2172187,513]

theorem envBound31073 : H12AffineFastState.Bounded env31073 := by
  intro p hp
  have h : env31073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31072_31073 : H12AffineEnvironment.transform 14 8541 env31072 = env31073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31072 == env31073) = true)

def env31074 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147456,147474,8192,16,4409655,2319642,2233601,2340,75023,6497546,256,2188602,2172187,513]

theorem envBound31074 : H12AffineFastState.Bounded env31074 := by
  intro p hp
  have h : env31074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31073_31074 : H12AffineEnvironment.transform 5 16 env31073 = env31074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31073 == env31074) = true)

theorem identity31074 : scanCanonicalize (H12AffineFastState.compose env31074 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 213302) := by decide +kernel

theorem selectedBound31074 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31075 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,213302,147456,147474,8192,16,2049,2319642,2233601,2340,75023,2122812,256,2188602,2172187,513]

theorem envBound31075 : H12AffineFastState.Bounded env31075 := by
  intro p hp
  have h : env31075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31074_31075 : H12AffineEnvironment.transform 21 213302 env31074 = env31075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213302 env31074 == env31075) = true)

theorem identity31075 : scanCanonicalize (H12AffineFastState.compose env31075 (packedSelected [1,2,6,8,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31075 : packedSelected [1,2,6,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31076 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,2097152,213302,147456,147474,269,16,2049,2311191,2233601,2340,66562,2114865,256,2180151,2163734,513]

theorem envBound31076 : H12AffineFastState.Bounded env31076 := by
  intro p hp
  have h : env31076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31075_31076 : H12AffineEnvironment.transform 12 269 env31075 = env31076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31075 == env31076) = true)

theorem identity31076 : scanCanonicalize (H12AffineFastState.compose env31076 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 132353) := by decide +kernel

theorem selectedBound31076 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31077 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,132353,213302,147456,147474,269,16,2049,82198,4096,2340,66562,147504,256,213302,196887,513]

theorem envBound31077 : H12AffineFastState.Bounded env31077 := by
  intro p hp
  have h : env31077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31076_31077 : H12AffineEnvironment.transform 20 132353 env31076 = env31077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132353 env31076 == env31077) = true)

theorem identity31077 : scanCanonicalize (H12AffineFastState.compose env31077 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31077 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31078 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,65536,16400,2340,1024,1,17681,65830,16,2,269,16,2049,82198,4096,2340,66562,32,256,65830,82183,513]

theorem envBound31078 : H12AffineFastState.Bounded env31078 := by
  intro p hp
  have h : env31078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31077_31078 : H12AffineEnvironment.transform 16 16400 env31077 = env31078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31077 == env31078) = true)

theorem identity31078 : scanCanonicalize (H12AffineFastState.compose env31078 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 24371) := by decide +kernel

theorem selectedBound31078 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env31079 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,24371,16400,2340,1024,1,17681,24085,16,2,269,16,2049,7717,4096,2340,23345,32,256,24085,7732,513]

theorem envBound31079 : H12AffineFastState.Bounded env31079 := by
  intro p hp
  have h : env31079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31078_31079 : H12AffineEnvironment.transform 15 24371 env31078 = env31079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24371 env31078 == env31079) = true)

theorem identity31079 : scanCanonicalize (H12AffineFastState.compose env31079 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 7732) := by decide +kernel

theorem selectedBound31079 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env31080 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7732,0,263,7716,2340,1024,1,6949,33,16,2,269,16,2049,7717,4096,2340,1285,32,256,33,7732,513]

theorem envBound31080 : H12AffineFastState.Bounded env31080 := by
  intro p hp
  have h : env31080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31079_31080 : H12AffineEnvironment.transform 13 7732 env31079 = env31080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7732 env31079 == env31080) = true)

theorem identity31080 : scanCanonicalize (H12AffineFastState.compose env31080 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound31080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31081 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,276,269,3872,0,263,3888,2340,1024,1,2609,33,16,2,269,16,2049,3889,276,2340,1285,32,256,33,3872,513]

theorem envBound31081 : H12AffineFastState.Bounded env31081 := by
  intro p hp
  have h : env31081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31080_31081 : H12AffineEnvironment.transform 11 276 env31080 = env31081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env31080 == env31081) = true)

theorem identity31081 : scanCanonicalize (H12AffineFastState.compose env31081 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound31081 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31082 : List Nat := [2,4,8,16,32,16,8,256,512,298,2048,276,269,2570,0,263,2586,2340,298,1,2609,33,16,2,269,16,2049,2587,276,2340,47,32,256,33,2570,513]

theorem envBound31082 : H12AffineFastState.Bounded env31082 := by
  intro p hp
  have h : env31082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31081_31082 : H12AffineEnvironment.transform 9 298 env31081 = env31082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env31081 == env31082) = true)

theorem identity31082 : scanCanonicalize (H12AffineFastState.compose env31082 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound31082 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31083 : List Nat := [2,4,8,16,32,16,8,256,59,298,2048,276,269,2097,0,263,2081,2340,298,1,2058,33,16,2,269,16,2049,2080,276,2340,47,32,256,33,2097,58]

theorem envBound31083 : H12AffineFastState.Bounded env31083 := by
  intro p hp
  have h : env31083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31082_31083 : H12AffineEnvironment.transform 8 59 env31082 = env31083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env31082 == env31083) = true)

theorem identity31083 : scanCanonicalize (H12AffineFastState.compose env31083 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31083 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31084 : List Nat := [2,4,2,16,32,16,2,256,49,288,2048,276,263,2097,0,263,2081,2340,288,1,2048,33,16,2,263,16,2049,2080,276,2340,37,32,256,33,2097,48]

theorem envBound31084 : H12AffineFastState.Bounded env31084 := by
  intro p hp
  have h : env31084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31083_31084 : H12AffineEnvironment.transform 2 2 env31083 = env31084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31083 == env31084) = true)

theorem identity31084 : scanCanonicalize (H12AffineFastState.compose env31084 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound31084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31085 : List Nat := [2,4,2,16,32,16,2,256,49,288,48,276,263,1,0,263,17,276,288,1,48,33,16,2,263,16,49,16,276,276,37,32,256,33,1,48]

theorem envBound31085 : H12AffineFastState.Bounded env31085 := by
  intro p hp
  have h : env31085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31084_31085 : H12AffineEnvironment.transform 10 48 env31084 = env31085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env31084 == env31085) = true)

theorem identity31085 : scanCanonicalize (H12AffineFastState.compose env31085 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31085 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env31086 : List Nat := [2,4,2,16,32,16,2,21,49,53,48,1,18,1,0,18,17,1,53,1,48,33,16,2,18,16,49,16,1,1,37,32,21,33,1,48]

theorem envBound31086 : H12AffineFastState.Bounded env31086 := by
  intro p hp
  have h : env31086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31085_31086 : H12AffineEnvironment.transform 7 21 env31085 = env31086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31085 == env31086) = true)

theorem identity31086 : scanCanonicalize (H12AffineFastState.compose env31086 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31086 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31087 : List Nat := [2,4,2,7,32,7,2,2,38,34,39,1,5,1,0,5,6,1,34,1,39,33,7,2,5,7,38,7,1,1,37,32,2,33,1,39]

theorem envBound31087 : H12AffineFastState.Bounded env31087 := by
  intro p hp
  have h : env31087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31086_31087 : H12AffineEnvironment.transform 3 7 env31086 = env31087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31086 == env31087) = true)

def env31088 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147456,147474,8192,17,4409654,2319643,2233600,2341,75022,6497547,256,2188603,2172187,513]

theorem envBound31088 : H12AffineFastState.Bounded env31088 := by
  intro p hp
  have h : env31088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31073_31088 : H12AffineEnvironment.transform 5 17 env31073 = env31088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31073 == env31088) = true)

theorem identity31088 : scanCanonicalize (H12AffineFastState.compose env31088 (packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound31088 : packedSelected [0,3,4,5,7,9,10,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31089 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,8493,147456,147474,8192,17,223259,2319643,2233600,2341,75022,2294822,256,2188603,2172187,513]

theorem envBound31089 : H12AffineFastState.Bounded env31089 := by
  intro p hp
  have h : env31089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31088_31089 : H12AffineEnvironment.transform 21 8493 env31088 = env31089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env31088 == env31089) = true)

theorem identity31089 : scanCanonicalize (H12AffineFastState.compose env31089 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(20+1) ^^^ 197639) := by decide +kernel

theorem selectedBound31089 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env31090 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,197639,8493,147456,147474,8192,17,223259,24860,69895,2341,75022,33,256,155964,139548,513]

theorem envBound31090 : H12AffineFastState.Bounded env31090 := by
  intro p hp
  have h : env31090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31089_31090 : H12AffineEnvironment.transform 20 197639 env31089 = env31090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197639 env31089 == env31090) = true)

theorem identity31090 : scanCanonicalize (H12AffineFastState.compose env31090 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound31090 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env31091 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,65536,24861,10281,1024,8461,91418,8493,8477,8463,8192,17,67846,24860,69895,2341,75022,33,256,33,16385,513]

theorem envBound31091 : H12AffineFastState.Bounded env31091 := by
  intro p hp
  have h : env31091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31090_31091 : H12AffineEnvironment.transform 16 24861 env31090 = env31091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env31090 == env31091) = true)

theorem identity31091 : scanCanonicalize (H12AffineFastState.compose env31091 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31091 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31092 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,65536,16401,2341,1024,1,82966,33,17,3,268,17,67846,16400,69895,2341,66562,33,256,33,16385,513]

theorem envBound31092 : H12AffineFastState.Bounded env31092 := by
  intro p hp
  have h : env31092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31091_31092 : H12AffineEnvironment.transform 12 268 env31091 = env31092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31091 == env31092) = true)

theorem identity31092 : scanCanonicalize (H12AffineFastState.compose env31092 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound31092 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31093 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1024,1,17681,33,17,3,268,17,2049,16400,4096,2341,1285,33,256,33,16385,513]

theorem envBound31093 : H12AffineFastState.Bounded env31093 := by
  intro p hp
  have h : env31093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31092_31093 : H12AffineEnvironment.transform 15 263 env31092 = env31093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env31092 == env31093) = true)

theorem identity31093 : scanCanonicalize (H12AffineFastState.compose env31093 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31094 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1024,1,4113,33,17,3,268,17,2049,5392,4096,2341,1285,33,256,33,5377,513]

theorem envBound31094 : H12AffineFastState.Bounded env31094 := by
  intro p hp
  have h : env31094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31093_31094 : H12AffineEnvironment.transform 13 5376 env31093 = env31094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31093 == env31094) = true)

theorem identity31094 : scanCanonicalize (H12AffineFastState.compose env31094 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2878) := by decide +kernel

theorem selectedBound31094 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31095 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2878,268,3646,0,263,3631,2341,1024,1,2863,33,17,3,268,17,2049,3630,2878,2341,1285,33,256,33,3647,513]

theorem envBound31095 : H12AffineFastState.Bounded env31095 := by
  intro p hp
  have h : env31095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31094_31095 : H12AffineEnvironment.transform 11 2878 env31094 = env31095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2878 env31094 == env31095) = true)

theorem identity31095 : scanCanonicalize (H12AffineFastState.compose env31095 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31095 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31096 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2618,8,3646,0,3,3631,2081,1024,1,2603,33,17,3,8,17,2049,3630,2618,2081,1025,33,4,33,3647,513]

theorem envBound31096 : H12AffineFastState.Bounded env31096 := by
  intro p hp
  have h : env31096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31095_31096 : H12AffineEnvironment.transform 7 4 env31095 = env31096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31095 == env31096) = true)

theorem identity31096 : scanCanonicalize (H12AffineFastState.compose env31096 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound31096 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31097 : List Nat := [2,4,8,16,32,17,8,4,512,1024,1566,1060,8,32,0,3,49,1599,1024,1,1077,33,17,3,8,17,1567,48,1060,1599,1025,33,4,33,33,513]

theorem envBound31097 : H12AffineFastState.Bounded env31097 := by
  intro p hp
  have h : env31097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31096_31097 : H12AffineEnvironment.transform 10 1566 env31096 = env31097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env31096 == env31097) = true)

theorem identity31097 : scanCanonicalize (H12AffineFastState.compose env31097 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound31097 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31098 : List Nat := [2,4,8,16,32,17,8,4,512,542,0,570,8,32,0,3,49,33,542,1,555,33,17,3,8,17,1,48,570,33,543,33,4,33,33,513]

theorem envBound31098 : H12AffineFastState.Bounded env31098 := by
  intro p hp
  have h : env31098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31097_31098 : H12AffineEnvironment.transform 9 542 env31097 = env31098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env31097 == env31098) = true)

theorem identity31098 : scanCanonicalize (H12AffineFastState.compose env31098 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31098 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env31099 : List Nat := [2,4,8,16,1,17,8,4,512,542,0,539,8,1,0,3,16,0,542,1,522,0,17,3,8,17,1,17,539,0,543,0,4,0,0,513]

theorem envBound31099 : H12AffineFastState.Bounded env31099 := by
  intro p hp
  have h : env31099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31098_31099 : H12AffineEnvironment.transform 4 1 env31098 = env31099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31098 == env31099) = true)

theorem identity31099 : scanCanonicalize (H12AffineFastState.compose env31099 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound31099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31100 : List Nat := [2,4,7,16,1,17,7,4,512,529,0,532,7,1,0,3,16,0,529,1,517,0,17,3,7,17,1,17,532,0,528,0,4,0,0,513]

theorem envBound31100 : H12AffineFastState.Bounded env31100 := by
  intro p hp
  have h : env31100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31099_31100 : H12AffineEnvironment.transform 2 7 env31099 = env31100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env31099 == env31100) = true)

theorem identity31100 : scanCanonicalize (H12AffineFastState.compose env31100 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31101 : List Nat := [2,2,1,16,1,17,1,2,512,529,0,530,1,1,0,3,16,0,529,1,515,0,17,3,1,17,1,17,530,0,528,0,2,0,0,513]

theorem envBound31101 : H12AffineFastState.Bounded env31101 := by
  intro p hp
  have h : env31101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31100_31101 : H12AffineEnvironment.transform 1 2 env31100 = env31101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31100 == env31101) = true)

def env31102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147611,8328,64,4702227,2343958,2233816,295049,99330,6497627,256,2213055,2172187,41940]

theorem envBound31102 : H12AffineFastState.Bounded env31102 := by
  intro p hp
  have h : env31102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31058_31102 : H12AffineEnvironment.transform 22 147593 env31058 = env31102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env31058 == env31102) = true)

def env31103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147611,8328,64,4450483,2343958,2233816,43049,99330,6497627,256,2213055,2172187,41940]

theorem envBound31103 : H12AffineFastState.Bounded env31103 := by
  intro p hp
  have h : env31103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31102_31103 : H12AffineEnvironment.transform 17 10400 env31102 = env31103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31102 == env31103) = true)

theorem identity31103 : scanCanonicalize (H12AffineFastState.compose env31103 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound31103 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10400,1024,32769,2097152,4194304,41293,41311,8328,64,4262263,2172370,2159644,43049,99330,6407327,256,2213055,2172187,41940]

theorem envBound31104 : H12AffineFastState.Bounded env31104 := by
  intro p hp
  have h : env31104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31103_31104 : H12AffineEnvironment.transform 16 57796 env31103 = env31104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env31103 == env31104) = true)

theorem identity31104 : scanCanonicalize (H12AffineFastState.compose env31104 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31104 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env31105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,57796,10400,1024,32769,2097152,4194304,41293,41311,8328,64,4204925,2098648,2159644,43049,41992,6349973,256,2155701,2098449,41940]

theorem envBound31105 : H12AffineFastState.Bounded env31105 := by
  intro p hp
  have h : env31105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31104_31105 : H12AffineEnvironment.transform 15 8202 env31104 = env31105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31104 == env31105) = true)

theorem identity31105 : scanCanonicalize (H12AffineFastState.compose env31105 (packedSelected [0,1,3,5,8,9,10,11,17,18,19,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound31105 : packedSelected [0,1,3,5,8,9,10,11,17,18,19,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env31106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16401,10400,1024,8660,2097152,4194304,152,138,8328,64,4204925,2098648,2119113,2556,1501,6309184,256,2114912,2098449,513]

theorem envBound31106 : H12AffineFastState.Bounded env31106 := by
  intro p hp
  have h : env31106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31105_31106 : H12AffineEnvironment.transform 14 8661 env31105 = env31106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env31105 == env31106) = true)

theorem identity31106 : scanCanonicalize (H12AffineFastState.compose env31106 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound31106 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env31107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16401,10400,1024,8660,2097152,20528,152,138,8328,64,31053,2098648,2119113,2556,1501,2102640,256,2114912,2098449,513]

theorem envBound31107 : H12AffineFastState.Bounded env31107 := by
  intro p hp
  have h : env31107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31106_31107 : H12AffineEnvironment.transform 21 20528 env31106 = env31107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env31106 == env31107) = true)

theorem identity31107 : scanCanonicalize (H12AffineFastState.compose env31107 (packedSelected [0,1,3,4,7,9,11,12,14,15,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound31107 : packedSelected [0,1,3,4,7,9,11,12,14,15,18,24,28] rootPS < 2^1333 := by decide +kernel

def env31108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8661,8202,5173,10400,1024,8660,2097152,1044,152,138,8328,64,11625,2098648,2097645,2556,1501,2102640,256,2101572,2098449,513]

theorem envBound31108 : H12AffineFastState.Bounded env31108 := by
  intro p hp
  have h : env31108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31107_31108 : H12AffineEnvironment.transform 13 5156 env31107 = env31108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env31107 == env31108) = true)

theorem identity31108 : scanCanonicalize (H12AffineFastState.compose env31108 (packedSelected [0,4,7,9,11,14,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 13689) := by decide +kernel

theorem selectedBound31108 : packedSelected [0,4,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env31109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,8661,8202,5173,10400,1024,8660,13689,1044,152,138,8328,64,11625,12449,13460,2556,1501,8201,256,9277,12392,513]

theorem envBound31109 : H12AffineFastState.Bounded env31109 := by
  intro p hp
  have h : env31109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31108_31109 : H12AffineEnvironment.transform 20 13689 env31108 = env31109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13689 env31108 == env31109) = true)

theorem identity31109 : scanCanonicalize (H12AffineFastState.compose env31109 (packedSelected [11,12,23,38] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31109 : packedSelected [11,12,23,38] rootPS < 2^1333 := by decide +kernel

def env31110 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,8433,8202,5173,10400,1024,8432,13405,1044,152,138,8328,64,11341,12449,13460,2264,1273,8201,36,9277,12392,513]

theorem envBound31110 : H12AffineFastState.Bounded env31110 := by
  intro p hp
  have h : env31110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31109_31110 : H12AffineEnvironment.transform 7 36 env31109 = env31110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31109 == env31110) = true)

theorem identity31110 : scanCanonicalize (H12AffineFastState.compose env31110 (packedSelected [11,17,23] rootPS)) = affineNative (2^(12+1) ^^^ 1220) := by decide +kernel

theorem selectedBound31110 : packedSelected [11,17,23] rootPS < 2^1333 := by decide +kernel

def env31111 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,1220,5156,1077,1230,5173,3172,1024,1076,4249,1044,152,138,1100,64,2185,5221,4176,2264,1273,1229,36,249,5292,513]

theorem envBound31111 : H12AffineFastState.Bounded env31111 := by
  intro p hp
  have h : env31111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31110_31111 : H12AffineEnvironment.transform 12 1220 env31110 = env31111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env31110 == env31111) = true)

theorem identity31111 : scanCanonicalize (H12AffineFastState.compose env31111 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound31111 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env31112 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,3244,1220,2184,1077,1230,2201,3172,1024,1076,3125,1044,152,138,1100,64,2185,2249,3324,2264,1273,1229,36,249,2048,513]

theorem envBound31112 : H12AffineFastState.Bounded env31112 := by
  intro p hp
  have h : env31112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31111_31112 : H12AffineEnvironment.transform 11 3244 env31111 = env31112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env31111 == env31112) = true)

theorem identity31112 : scanCanonicalize (H12AffineFastState.compose env31112 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31112 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31113 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,1101,2049,1077,1095,2064,3172,1024,1076,3125,1044,17,3,1100,64,2048,2112,3189,2129,1136,1092,36,112,2048,513]

theorem envBound31113 : H12AffineFastState.Bounded env31113 := by
  intro p hp
  have h : env31113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31112_31113 : H12AffineEnvironment.transform 6 9 env31112 = env31113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31112 == env31113) = true)

theorem identity31113 : scanCanonicalize (H12AffineFastState.compose env31113 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31113 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env31114 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2065,121,2049,1,115,2064,2128,52,0,2049,32,17,3,120,64,2048,2112,2113,2129,68,112,36,112,2048,513]

theorem envBound31114 : H12AffineFastState.Bounded env31114 := by
  intro p hp
  have h : env31114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31113_31114 : H12AffineEnvironment.transform 9 52 env31113 = env31114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31113 == env31114) = true)

theorem identity31114 : scanCanonicalize (H12AffineFastState.compose env31114 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound31114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31115 : List Nat := [2,4,8,16,32,64,9,36,512,52,32,49,121,33,1,115,48,112,52,0,33,32,17,3,120,64,32,96,97,113,68,112,36,112,32,513]

theorem envBound31115 : H12AffineFastState.Bounded env31115 := by
  intro p hp
  have h : env31115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31114_31115 : H12AffineEnvironment.transform 10 32 env31114 = env31115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env31114 == env31115) = true)

theorem identity31115 : scanCanonicalize (H12AffineFastState.compose env31115 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31115 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31116 : List Nat := [2,4,8,16,32,49,9,36,512,52,32,49,8,33,1,2,48,1,52,0,33,32,17,3,9,49,32,17,16,0,53,1,36,1,32,513]

theorem envBound31116 : H12AffineFastState.Bounded env31116 := by
  intro p hp
  have h : env31116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31115_31116 : H12AffineEnvironment.transform 5 49 env31115 = env31116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31115 == env31116) = true)

theorem identity31116 : scanCanonicalize (H12AffineFastState.compose env31116 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound31116 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31117 : List Nat := [2,4,8,16,32,49,9,36,33,52,32,49,8,33,1,2,48,1,52,0,33,32,17,3,9,49,32,17,16,0,53,1,36,1,32,32]

theorem envBound31117 : H12AffineFastState.Bounded env31117 := by
  intro p hp
  have h : env31117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31116_31117 : H12AffineEnvironment.transform 8 33 env31116 = env31117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env31116 == env31117) = true)

theorem identity31117 : scanCanonicalize (H12AffineFastState.compose env31117 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31118 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,17,8,1,1,2,16,1,20,0,1,0,17,3,9,17,0,17,16,0,21,1,4,1,0,0]

theorem envBound31118 : H12AffineFastState.Bounded env31118 := by
  intro p hp
  have h : env31118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31117_31118 : H12AffineEnvironment.transform 4 0 env31117 = env31118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31117 == env31118) = true)

theorem identity31118 : scanCanonicalize (H12AffineFastState.compose env31118 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31119 : List Nat := [2,4,8,0,0,1,9,4,1,4,0,1,8,1,1,2,0,1,4,0,1,0,1,3,9,1,0,1,0,0,5,1,4,1,0,0]

theorem envBound31119 : H12AffineFastState.Bounded env31119 := by
  intro p hp
  have h : env31119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31118_31119 : H12AffineEnvironment.transform 3 0 env31118 = env31119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31118 == env31119) = true)

def env31120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147611,8328,64,4450482,2343958,2233816,43048,99330,6497627,256,2213055,2172187,41940]

theorem envBound31120 : H12AffineFastState.Bounded env31120 := by
  intro p hp
  have h : env31120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31102_31120 : H12AffineEnvironment.transform 17 10401 env31102 = env31120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31102 == env31120) = true)

theorem identity31120 : scanCanonicalize (H12AffineFastState.compose env31120 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31120 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147593,147611,8328,64,4409839,2319691,2233816,2421,75103,6497627,256,2188770,2172187,649]

theorem envBound31121 : H12AffineFastState.Bounded env31121 := by
  intro p hp
  have h : env31121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31120_31121 : H12AffineEnvironment.transform 14 8541 env31120 = env31121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31120 == env31121) = true)

theorem identity31121 : scanCanonicalize (H12AffineFastState.compose env31121 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31121 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,147475,8192,64,4409703,2319691,2233680,2421,75103,6497627,256,2188650,2172187,513]

theorem envBound31122 : H12AffineFastState.Bounded env31122 := by
  intro p hp
  have h : env31122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31121_31122 : H12AffineEnvironment.transform 6 8 env31121 = env31122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31121 == env31122) = true)

theorem identity31122 : scanCanonicalize (H12AffineFastState.compose env31122 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound31122 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env31123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,25629,4194304,147457,147475,8192,64,4409703,196950,160077,2421,75103,4407622,256,65911,82182,513]

theorem envBound31123 : H12AffineFastState.Bounded env31123 := by
  intro p hp
  have h : env31123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31122_31123 : H12AffineEnvironment.transform 20 25629 env31122 = env31123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env31122 == env31123) = true)

theorem identity31123 : scanCanonicalize (H12AffineFastState.compose env31123 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31123 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env31124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,25629,4194304,16,2,8192,64,4262262,82247,12636,2421,75103,4260183,256,65911,82182,513]

theorem envBound31124 : H12AffineFastState.Bounded env31124 := by
  intro p hp
  have h : env31124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31123_31124 : H12AffineEnvironment.transform 16 16401 env31123 = env31124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31123 == env31124) = true)

theorem identity31124 : scanCanonicalize (H12AffineFastState.compose env31124 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound31124 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env31125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,25629,8572,16,2,8192,64,75786,82247,12636,2421,75103,73771,256,65911,82182,513]

theorem envBound31125 : H12AffineFastState.Bounded env31125 := by
  intro p hp
  have h : env31125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31124_31125 : H12AffineEnvironment.transform 21 8572 env31124 = env31125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env31124 == env31125) = true)

theorem identity31125 : scanCanonicalize (H12AffineFastState.compose env31125 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31125 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env31126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,342,16401,10281,1024,8540,25629,8572,16,2,8192,64,10588,16401,12636,2421,9225,8573,256,33,16464,513]

theorem envBound31126 : H12AffineFastState.Bounded env31126 := by
  intro p hp
  have h : env31126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31125_31126 : H12AffineEnvironment.transform 15 342 env31125 = env31126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31125 == env31126) = true)

theorem identity31126 : scanCanonicalize (H12AffineFastState.compose env31126 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 17) := by decide +kernel

theorem selectedBound31126 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,17,8541,342,0,10281,1024,8540,9228,8572,16,2,8192,64,10588,0,12636,2421,9225,8573,256,33,65,513]

theorem envBound31127 : H12AffineFastState.Bounded env31127 := by
  intro p hp
  have h : env31127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31126_31127 : H12AffineEnvironment.transform 13 17 env31126 = env31127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 17 env31126 == env31127) = true)

theorem identity31127 : scanCanonicalize (H12AffineFastState.compose env31127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,17,0,342,0,2420,1024,1,1361,33,16,2,349,64,2049,0,4097,2421,1364,32,256,33,65,513]

theorem envBound31128 : H12AffineFastState.Bounded env31128 := by
  intro p hp
  have h : env31128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31127_31128 : H12AffineEnvironment.transform 12 349 env31127 = env31128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31127 == env31128) = true)

theorem identity31128 : scanCanonicalize (H12AffineFastState.compose env31128 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound31128 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2350,349,17,0,342,0,2420,1024,1,1361,33,16,2,349,64,2049,0,2351,2421,1364,32,256,33,65,513]

theorem envBound31129 : H12AffineFastState.Bounded env31129 := by
  intro p hp
  have h : env31129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31128_31129 : H12AffineEnvironment.transform 11 2350 env31128 = env31129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env31128 == env31129) = true)

theorem identity31129 : scanCanonicalize (H12AffineFastState.compose env31129 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31129 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31130 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2350,268,17,0,263,0,2341,1024,1,1280,33,16,2,268,17,2049,0,2351,2340,1285,32,256,33,16,513]

theorem envBound31130 : H12AffineFastState.Bounded env31130 := by
  intro p hp
  have h : env31130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31129_31130 : H12AffineEnvironment.transform 5 17 env31129 = env31130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31129 == env31130) = true)

theorem identity31130 : scanCanonicalize (H12AffineFastState.compose env31130 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31131 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2350,268,17,0,263,0,2341,53,1,309,33,16,2,268,17,2049,0,2351,2340,304,32,256,33,16,513]

theorem envBound31131 : H12AffineFastState.Bounded env31131 := by
  intro p hp
  have h : env31131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31130_31131 : H12AffineEnvironment.transform 9 53 env31130 = env31131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31130 == env31131) = true)

theorem identity31131 : scanCanonicalize (H12AffineFastState.compose env31131 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound31131 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31132 : List Nat := [2,4,8,16,32,17,8,256,512,53,525,803,268,17,0,263,0,808,53,1,309,33,16,2,268,17,524,0,802,809,304,32,256,33,16,513]

theorem envBound31132 : H12AffineFastState.Bounded env31132 := by
  intro p hp
  have h : env31132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31131_31132 : H12AffineEnvironment.transform 10 525 env31131 = env31132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env31131 == env31132) = true)

theorem identity31132 : scanCanonicalize (H12AffineFastState.compose env31132 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound31132 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31133 : List Nat := [2,4,8,16,32,17,8,14,512,53,525,557,2,17,0,9,0,550,53,1,59,33,16,2,2,17,524,0,556,551,62,32,14,33,16,513]

theorem envBound31133 : H12AffineFastState.Bounded env31133 := by
  intro p hp
  have h : env31133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31132_31133 : H12AffineEnvironment.transform 7 14 env31132 = env31133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env31132 == env31133) = true)

theorem identity31133 : scanCanonicalize (H12AffineFastState.compose env31133 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31133 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env31134 : List Nat := [2,4,8,16,17,17,8,14,512,4,525,540,2,17,0,9,0,535,4,1,10,16,16,2,2,17,524,0,541,534,15,17,14,16,16,513]

theorem envBound31134 : H12AffineFastState.Bounded env31134 := by
  intro p hp
  have h : env31134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31133_31134 : H12AffineEnvironment.transform 4 17 env31133 = env31134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31133 == env31134) = true)

def env31135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound31135 : H12AffineFastState.Bounded env31135 := by
  intro p hp
  have h : env31135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31056_31135 : H12AffineEnvironment.transform 18 1025 env31056 = env31135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31056 == env31135) = true)

theorem identity31135 : scanCanonicalize (H12AffineFastState.compose env31135 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound31135 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630611,18973836,10507601,8724626,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound31136 : H12AffineFastState.Bounded env31136 := by
  intro p hp
  have h : env31136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31135_31136 : H12AffineEnvironment.transform 16 123027 env31135 = env31136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env31135 == env31136) = true)

def env31137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664479,8393984,10507601,8724626,2102684,12645452,257,21792,46213,2175563]

theorem envBound31137 : H12AffineFastState.Bounded env31137 := by
  intro p hp
  have h : env31137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31136_31137 : H12AffineEnvironment.transform 23 10588556 env31136 = env31137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env31136 == env31137) = true)

def env31138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664479,2098512,17665,2437314,2102684,6349852,257,21792,46213,2175563]

theorem envBound31138 : H12AffineFastState.Bounded env31138 := by
  intro p hp
  have h : env31138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31137_31138 : H12AffineEnvironment.transform 22 2101328 env31137 = env31138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env31137 == env31138) = true)

def env31139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2202015,2098512,17665,2437314,2102684,2411676,257,21792,46213,2175563]

theorem envBound31139 : H12AffineFastState.Bounded env31139 := by
  intro p hp
  have h : env31139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31138_31139 : H12AffineEnvironment.transform 21 272512 env31138 = env31139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31138 == env31139) = true)

theorem identity31139 : scanCanonicalize (H12AffineFastState.compose env31139 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31139 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,2097152,272512,2101328,41431,8328,64,2144660,2098512,17665,2363593,2102684,2411676,257,21792,46213,2101824]

theorem envBound31140 : H12AffineFastState.Bounded env31140 := by
  intro p hp
  have h : env31140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31139_31140 : H12AffineEnvironment.transform 15 8203 env31139 = env31140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31139 == env31140) = true)

def env31141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2202014,2098512,17665,2437314,2102684,2411677,257,21792,46213,2175563]

theorem envBound31141 : H12AffineFastState.Bounded env31141 := by
  intro p hp
  have h : env31141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31138_31141 : H12AffineEnvironment.transform 21 272513 env31138 = env31141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31138 == env31141) = true)

theorem identity31141 : scanCanonicalize (H12AffineFastState.compose env31141 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound31141 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77898,272513,73754,98780,8328,64,43476,79130,17665,262280,75222,392407,257,21792,46213,513]

theorem envBound31142 : H12AffineFastState.Bounded env31142 := by
  intro p hp
  have h : env31142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31141_31142 : H12AffineEnvironment.transform 20 77898 env31141 = env31142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env31141 == env31142) = true)

def env31143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90259,262144,1025,1,77898,272513,73754,66012,8328,64,10708,79130,17665,262280,75222,359639,257,21792,13445,513]

theorem envBound31143 : H12AffineFastState.Bounded env31143 := by
  intro p hp
  have h : env31143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31142_31143 : H12AffineEnvironment.transform 14 0 env31142 = env31143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31142 == env31143) = true)

theorem identity31143 : scanCanonicalize (H12AffineFastState.compose env31143 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound31143 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env31144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16401,262144,1025,1,4296,272513,152,8542,8328,64,10708,5528,17665,262280,1364,285781,257,21792,13445,513]

theorem envBound31144 : H12AffineFastState.Bounded env31144 := by
  intro p hp
  have h : env31144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31143_31144 : H12AffineEnvironment.transform 15 8322 env31143 = env31144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env31143 == env31144) = true)

theorem identity31144 : scanCanonicalize (H12AffineFastState.compose env31144 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound31144 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16401,10281,1025,1,4296,168,152,8542,8328,64,10708,5528,17665,10401,1364,29820,257,21792,13445,513]

theorem envBound31145 : H12AffineFastState.Bounded env31145 := by
  intro p hp
  have h : env31145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31144_31145 : H12AffineEnvironment.transform 17 10281 env31144 = env31145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31144 == env31145) = true)

theorem identity31145 : scanCanonicalize (H12AffineFastState.compose env31145 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31145 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env31146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,0,342,16401,2557,1025,1,4296,168,152,138,348,64,2048,5528,17665,2421,1364,21928,257,21792,5457,513]

theorem envBound31146 : H12AffineFastState.Bounded env31146 := by
  intro p hp
  have h : env31146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31145_31146 : H12AffineEnvironment.transform 12 468 env31145 = env31146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31145 == env31146) = true)

theorem identity31146 : scanCanonicalize (H12AffineFastState.compose env31146 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31146 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env31147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,0,342,5392,2557,1025,1,4296,168,152,138,348,64,2048,5528,4096,2421,1364,169,257,33,5457,513]

theorem envBound31147 : H12AffineFastState.Bounded env31147 := by
  intro p hp
  have h : env31147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31146_31147 : H12AffineEnvironment.transform 13 5377 env31146 = env31147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31146 == env31147) = true)

theorem identity31147 : scanCanonicalize (H12AffineFastState.compose env31147 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31147 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31148 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2421,1025,1,4160,32,16,2,348,64,2048,5392,4096,2421,1364,33,257,33,5457,513]

theorem envBound31148 : H12AffineFastState.Bounded env31148 := by
  intro p hp
  have h : env31148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31147_31148 : H12AffineEnvironment.transform 6 8 env31147 = env31148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31147 == env31148) = true)

theorem identity31148 : scanCanonicalize (H12AffineFastState.compose env31148 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31148 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31149 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,348,4112,0,342,4097,2421,272,1,4160,32,16,2,348,64,2048,4097,4096,2421,69,33,257,33,4160,513]

theorem envBound31149 : H12AffineFastState.Bounded env31149 := by
  intro p hp
  have h : env31149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31148_31149 : H12AffineEnvironment.transform 9 273 env31148 = env31149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31148 == env31149) = true)

theorem identity31149 : scanCanonicalize (H12AffineFastState.compose env31149 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31150 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,4112,0,263,4097,2340,272,1,4113,32,16,2,269,17,2048,4097,4096,2340,20,33,257,33,4113,513]

theorem envBound31150 : H12AffineFastState.Bounded env31150 := by
  intro p hp
  have h : env31150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31149_31150 : H12AffineEnvironment.transform 5 17 env31149 = env31150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31149 == env31150) = true)

theorem identity31150 : scanCanonicalize (H12AffineFastState.compose env31150 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound31150 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31151 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,309,269,293,0,263,308,2340,272,1,292,32,16,2,269,17,2048,308,309,2340,20,33,257,33,292,513]

theorem envBound31151 : H12AffineFastState.Bounded env31151 := by
  intro p hp
  have h : env31151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31150_31151 : H12AffineEnvironment.transform 11 309 env31150 = env31151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env31150 == env31151) = true)

theorem identity31151 : scanCanonicalize (H12AffineFastState.compose env31151 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound31151 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31152 : List Nat := [2,4,8,16,32,17,8,256,512,273,293,309,269,293,0,263,308,1,272,1,292,32,16,2,269,17,293,308,309,1,20,33,257,33,292,513]

theorem envBound31152 : H12AffineFastState.Bounded env31152 := by
  intro p hp
  have h : env31152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31151_31152 : H12AffineEnvironment.transform 10 293 env31151 = env31152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env31151 == env31152) = true)

theorem identity31152 : scanCanonicalize (H12AffineFastState.compose env31152 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31152 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31153 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,1,0,35,16,1,52,1,0,32,16,2,41,17,1,16,17,1,20,33,37,33,0,513]

theorem envBound31153 : H12AffineFastState.Bounded env31153 := by
  intro p hp
  have h : env31153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31152_31153 : H12AffineEnvironment.transform 7 36 env31152 = env31153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31152 == env31153) = true)

theorem identity31153 : scanCanonicalize (H12AffineFastState.compose env31153 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31154 : List Nat := [2,4,8,16,17,17,8,21,512,4,1,17,24,1,0,18,16,1,5,1,0,17,16,2,24,17,1,16,17,1,20,16,20,16,0,513]

theorem envBound31154 : H12AffineFastState.Bounded env31154 := by
  intro p hp
  have h : env31154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31153_31154 : H12AffineEnvironment.transform 4 17 env31153 = env31154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31153 == env31154) = true)

theorem identity31154 : scanCanonicalize (H12AffineFastState.compose env31154 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31155 : List Nat := [2,4,8,16,17,17,8,21,0,4,1,17,24,1,0,18,16,1,5,1,0,17,16,2,24,17,1,16,17,1,20,16,20,16,0,1]

theorem envBound31155 : H12AffineFastState.Bounded env31155 := by
  intro p hp
  have h : env31155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31154_31155 : H12AffineEnvironment.transform 8 0 env31154 = env31155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31154 == env31155) = true)

def env31156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90258,262144,1025,0,77898,272513,73754,66013,8328,64,10709,79130,17665,262280,75222,359638,257,21792,13444,513]

theorem envBound31156 : H12AffineFastState.Bounded env31156 := by
  intro p hp
  have h : env31156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31142_31156 : H12AffineEnvironment.transform 14 1 env31142 = env31156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31142 == env31156) = true)

theorem identity31156 : scanCanonicalize (H12AffineFastState.compose env31156 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31156 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,262144,1025,0,77898,272392,73754,65876,8193,64,10588,79130,17665,262145,75103,359519,257,21792,13325,513]

theorem envBound31157 : H12AffineFastState.Bounded env31157 := by
  intro p hp
  have h : env31157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31156_31157 : H12AffineEnvironment.transform 6 9 env31156 = env31157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31156 == env31157) = true)

theorem identity31157 : scanCanonicalize (H12AffineFastState.compose env31157 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound31157 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env31158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,67618,1025,0,77898,73770,73754,65876,8193,64,10588,79130,17665,67619,75103,29821,257,21792,13325,513]

theorem envBound31158 : H12AffineFastState.Bounded env31158 := by
  intro p hp
  have h : env31158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31157_31158 : H12AffineEnvironment.transform 17 67618 env31157 = env31158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env31157 == env31158) = true)

theorem identity31158 : scanCanonicalize (H12AffineFastState.compose env31158 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31158 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,65536,70726,67618,1025,0,77898,73770,73754,65876,8193,64,10588,79130,12636,67619,75103,32,257,8573,13325,513]

theorem envBound31159 : H12AffineFastState.Bounded env31159 := by
  intro p hp
  have h : env31159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31158_31159 : H12AffineEnvironment.transform 13 13405 env31158 = env31159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31158 == env31159) = true)

theorem identity31159 : scanCanonicalize (H12AffineFastState.compose env31159 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31159 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,65536,70726,67618,1025,0,69910,65910,65862,65876,349,64,2048,70726,4096,67619,66563,32,257,33,5457,513]

theorem envBound31160 : H12AffineFastState.Bounded env31160 := by
  intro p hp
  have h : env31160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31159_31160 : H12AffineEnvironment.transform 12 348 env31159 = env31160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31159 == env31160) = true)

theorem identity31160 : scanCanonicalize (H12AffineFastState.compose env31160 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound31160 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5393,2421,1025,0,4161,33,17,3,349,64,2048,5393,4096,2420,1364,32,257,33,5457,513]

theorem envBound31161 : H12AffineFastState.Bounded env31161 := by
  intro p hp
  have h : env31161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31160_31161 : H12AffineEnvironment.transform 15 343 env31160 = env31161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env31160 == env31161) = true)

theorem identity31161 : scanCanonicalize (H12AffineFastState.compose env31161 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound31161 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,1,343,1140,2421,1025,0,292,33,17,3,349,64,2048,1140,357,2420,1364,32,257,33,1076,513]

theorem envBound31162 : H12AffineFastState.Bounded env31162 := by
  intro p hp
  have h : env31162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31161_31162 : H12AffineEnvironment.transform 11 357 env31161 = env31162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env31161 == env31162) = true)

theorem identity31162 : scanCanonicalize (H12AffineFastState.compose env31162 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound31162 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,357,348,1124,1,343,1140,1297,1025,0,292,33,17,3,349,64,1124,1140,357,1296,1364,32,257,33,1076,513]

theorem envBound31163 : H12AffineFastState.Bounded env31163 := by
  intro p hp
  have h : env31163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31162_31163 : H12AffineEnvironment.transform 10 1124 env31162 = env31163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env31162 == env31163) = true)

theorem identity31163 : scanCanonicalize (H12AffineFastState.compose env31163 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound31163 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env31164 : List Nat := [2,4,8,16,32,64,9,256,309,1024,1124,357,348,1124,1,343,1140,1297,1025,0,292,33,17,3,349,64,1124,1140,357,1296,1364,32,257,33,1076,308]

theorem envBound31164 : H12AffineFastState.Bounded env31164 := by
  intro p hp
  have h : env31164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31163_31164 : H12AffineEnvironment.transform 8 309 env31163 = env31164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env31163 == env31164) = true)

theorem identity31164 : scanCanonicalize (H12AffineFastState.compose env31164 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31164 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env31165 : List Nat := [2,4,8,16,16,64,9,256,261,1024,1108,341,348,1108,1,343,1092,1297,1025,0,276,17,17,3,349,64,1108,1092,341,1296,1364,16,257,17,1028,260]

theorem envBound31165 : H12AffineFastState.Bounded env31165 := by
  intro p hp
  have h : env31165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31164_31165 : H12AffineEnvironment.transform 4 16 env31164 = env31165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31164 == env31165) = true)

theorem identity31165 : scanCanonicalize (H12AffineFastState.compose env31165 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31165 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31166 : List Nat := [2,4,8,1,1,64,9,256,261,1024,1093,324,333,1093,1,326,1092,1280,1025,0,261,0,0,3,332,64,1093,1092,324,1281,1349,1,257,0,1028,260]

theorem envBound31166 : H12AffineFastState.Bounded env31166 := by
  intro p hp
  have h : env31166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31165_31166 : H12AffineEnvironment.transform 3 1 env31165 = env31166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31165 == env31166) = true)

theorem identity31166 : scanCanonicalize (H12AffineFastState.compose env31166 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound31166 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env31167 : List Nat := [2,4,8,1,1,1,9,256,261,1024,1028,261,268,1028,1,263,1029,1280,1025,0,261,0,0,3,269,1,1028,1029,261,1281,1284,1,257,0,1028,260]

theorem envBound31167 : H12AffineFastState.Bounded env31167 := by
  intro p hp
  have h : env31167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31166_31167 : H12AffineEnvironment.transform 5 1 env31166 = env31167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31166 == env31167) = true)

theorem identity31167 : scanCanonicalize (H12AffineFastState.compose env31167 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound31167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31168 : List Nat := [2,4,8,1,1,1,9,256,261,256,260,261,268,260,1,263,261,0,257,0,261,0,0,3,269,1,260,261,261,1,4,1,257,0,260,260]

theorem envBound31168 : H12AffineFastState.Bounded env31168 := by
  intro p hp
  have h : env31168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31167_31168 : H12AffineEnvironment.transform 9 256 env31167 = env31168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env31167 == env31168) = true)

theorem identity31168 : scanCanonicalize (H12AffineFastState.compose env31168 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31169 : List Nat := [2,4,8,1,1,1,9,5,0,5,1,0,9,1,1,2,0,0,4,0,0,0,0,3,8,1,1,0,0,1,4,1,4,0,1,1]

theorem envBound31169 : H12AffineFastState.Bounded env31169 := by
  intro p hp
  have h : env31169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31168_31169 : H12AffineEnvironment.transform 7 5 env31168 = env31169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31168 == env31169) = true)

def env31170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664479,2098513,17664,2437315,2102684,6349853,257,21792,46213,2175563]

theorem envBound31170 : H12AffineFastState.Bounded env31170 := by
  intro p hp
  have h : env31170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31137_31170 : H12AffineEnvironment.transform 22 2101329 env31137 = env31170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env31137 == env31170) = true)

def env31171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2202015,2098513,17664,2437315,2102684,2411677,257,21792,46213,2175563]

theorem envBound31171 : H12AffineFastState.Bounded env31171 := by
  intro p hp
  have h : env31171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31170_31171 : H12AffineEnvironment.transform 21 272512 env31170 = env31171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env31170 == env31171) = true)

theorem identity31171 : scanCanonicalize (H12AffineFastState.compose env31171 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound31171 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13388,262144,1025,32769,2097152,272512,2101329,21762,8328,64,2116928,2098513,17664,2417692,2102684,2411677,257,21792,46213,2156180]

theorem envBound31172 : H12AffineFastState.Bounded env31172 := by
  intro p hp
  have h : env31172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31171_31172 : H12AffineEnvironment.transform 15 54495 env31171 = env31172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env31171 == env31172) = true)

def env31173 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,262144,1025,32769,2097152,272512,2101249,21762,8328,16,2116880,2098433,17664,2417692,2102684,2411677,257,21792,46213,2156180]

theorem envBound31173 : H12AffineFastState.Bounded env31173 := by
  intro p hp
  have h : env31173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31172_31173 : H12AffineEnvironment.transform 5 16 env31172 = env31173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31172 == env31173) = true)

theorem identity31173 : scanCanonicalize (H12AffineFastState.compose env31173 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 290105) := by decide +kernel

theorem selectedBound31173 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env31174 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,262144,1025,32769,290105,272512,294200,21762,8328,16,270377,288824,17664,35109,293029,41380,257,21792,46213,297901]

theorem envBound31174 : H12AffineFastState.Bounded env31174 := by
  intro p hp
  have h : env31174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31173_31174 : H12AffineEnvironment.transform 20 290105 env31173 = env31174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 290105 env31173 == env31174) = true)

theorem identity31174 : scanCanonicalize (H12AffineFastState.compose env31174 (packedSelected [0,3,5,8,9,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound31174 : packedSelected [0,3,5,8,9,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31175 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,13340,32160,1025,32769,4249,21792,152,21762,8328,16,23945,5528,17664,35109,1285,41380,257,21792,46213,62989]

theorem envBound31175 : H12AffineFastState.Bounded env31175 := by
  intro p hp
  have h : env31175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31174_31175 : H12AffineEnvironment.transform 17 32160 env31174 = env31175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env31174 == env31175) = true)

theorem identity31175 : scanCanonicalize (H12AffineFastState.compose env31175 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound31175 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env31176 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,33030,13340,10281,1025,32769,4249,169,152,139,8328,16,2048,5528,4233,35109,1285,41380,257,169,46213,41860]

theorem envBound31176 : H12AffineFastState.Bounded env31176 := by
  intro p hp
  have h : env31176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31175_31176 : H12AffineEnvironment.transform 13 5513 env31175 = env31176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env31175 == env31176) = true)

theorem identity31176 : scanCanonicalize (H12AffineFastState.compose env31176 (packedSelected [1,8,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound31176 : packedSelected [1,8,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env31177 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8581,8323,13340,10281,1025,8580,4249,169,152,139,8328,16,2048,5528,4233,10400,1285,33,257,169,5376,513]

theorem envBound31177 : H12AffineFastState.Bounded env31177 := by
  intro p hp
  have h : env31177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31176_31177 : H12AffineEnvironment.transform 14 8581 env31176 = env31177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env31176 == env31177) = true)

theorem identity31177 : scanCanonicalize (H12AffineFastState.compose env31177 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound31177 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env31178 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,0,262,5529,2476,1025,1,4249,169,152,139,269,16,2048,5528,4233,2341,1285,33,257,169,5376,513]

theorem envBound31178 : H12AffineFastState.Bounded env31178 := by
  intro p hp
  have h : env31178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31177_31178 : H12AffineEnvironment.transform 12 389 env31177 = env31178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env31177 == env31178) = true)

def env31179 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,262144,1025,32769,2097152,272512,2101248,21762,8328,17,2116881,2098432,17664,2417692,2102684,2411677,257,21792,46213,2156180]

theorem envBound31179 : H12AffineFastState.Bounded env31179 := by
  intro p hp
  have h : env31179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31172_31179 : H12AffineEnvironment.transform 5 17 env31172 = env31179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31172 == env31179) = true)

theorem identity31179 : scanCanonicalize (H12AffineFastState.compose env31179 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound31179 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env31180 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,262144,1025,32769,45460,272512,41364,21762,8328,17,64645,46228,17664,284040,41992,294153,257,21792,46213,22272]

theorem envBound31180 : H12AffineFastState.Bounded env31180 := by
  intro p hp
  have h : env31180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31179_31180 : H12AffineEnvironment.transform 20 45460 env31179 = env31180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env31179 == env31180) = true)

theorem identity31180 : scanCanonicalize (H12AffineFastState.compose env31180 (packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound31180 : packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env31181 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13341,35245,1025,32769,45460,41261,41364,21762,8328,17,64645,46228,17664,56357,41992,62628,257,21792,46213,22272]

theorem envBound31181 : H12AffineFastState.Bounded env31181 := by
  intro p hp
  have h : env31181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31180_31181 : H12AffineEnvironment.transform 17 35245 env31180 = env31181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env31180 == env31181) = true)

theorem identity31181 : scanCanonicalize (H12AffineFastState.compose env31181 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound31181 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31182 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,13341,32161,1025,29709,17816,21793,21912,21762,8328,17,2185,16536,17664,10281,20484,168,257,21792,16521,22272]

theorem envBound31182 : H12AffineFastState.Bounded env31182 := by
  intro p hp
  have h : env31182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31181_31182 : H12AffineEnvironment.transform 14 29708 env31181 = env31182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env31181 == env31182) = true)

theorem identity31182 : scanCanonicalize (H12AffineFastState.compose env31182 (packedSelected [0,1,2,6,7,8,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31182 : packedSelected [0,1,2,6,7,8,16,19] rootPS < 2^1333 := by decide +kernel

def env31183 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8460,8322,13341,10401,1025,8461,4248,33,152,2,8328,17,2185,5528,4096,10281,1284,168,257,32,5513,512]

theorem envBound31183 : H12AffineFastState.Bounded env31183 := by
  intro p hp
  have h : env31183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31182_31183 : H12AffineEnvironment.transform 13 5376 env31182 = env31183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31182 == env31183) = true)

theorem identity31183 : scanCanonicalize (H12AffineFastState.compose env31183 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31183 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31184 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,5376,8460,8322,13341,10368,1025,8461,4248,0,152,2,8328,17,2185,5528,4096,10248,1284,137,257,1,5513,512]

theorem envBound31184 : H12AffineFastState.Bounded env31184 := by
  intro p hp
  have h : env31184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31183_31184 : H12AffineEnvironment.transform 4 1 env31183 = env31184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31183 == env31184) = true)

theorem identity31184 : scanCanonicalize (H12AffineFastState.compose env31184 (packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound31184 : packedSelected [0,1,2,3,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env31185 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,2064,8192,3344,8460,8322,11277,10368,1025,8461,2184,0,152,2,8328,17,2185,3464,2064,10248,1284,137,257,1,3481,512]

theorem envBound31185 : H12AffineFastState.Bounded env31185 := by
  intro p hp
  have h : env31185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31184_31185 : H12AffineEnvironment.transform 11 2064 env31184 = env31185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env31184 == env31185) = true)

def env31186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2202014,2098513,17664,2437315,2102684,2411676,257,21792,46213,2175563]

theorem envBound31186 : H12AffineFastState.Bounded env31186 := by
  intro p hp
  have h : env31186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31170_31186 : H12AffineEnvironment.transform 21 272513 env31170 = env31186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env31170 == env31186) = true)

theorem identity31186 : scanCanonicalize (H12AffineFastState.compose env31186 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound31186 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,115871,272513,120014,98781,8328,64,23809,115150,17664,324700,119043,329731,257,21792,46213,63188]

theorem envBound31187 : H12AffineFastState.Bounded env31187 := by
  intro p hp
  have h : env31187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31186_31187 : H12AffineEnvironment.transform 20 115871 env31186 = env31187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env31186 == env31187) = true)

def env31188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10400,1025,32769,115871,33,120014,98781,8328,64,23809,115150,17664,56572,119043,73891,257,21792,46213,63188]

theorem envBound31188 : H12AffineFastState.Bounded env31188 := by
  intro p hp
  have h : env31188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31187_31188 : H12AffineEnvironment.transform 17 10400 env31187 = env31188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31187 == env31188) = true)

theorem identity31188 : scanCanonicalize (H12AffineFastState.compose env31188 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound31188 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env31189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,90139,10400,1025,137,82967,33,87110,65877,8328,64,23809,82246,17664,23668,86411,73891,257,21792,13325,30300]

theorem envBound31189 : H12AffineFastState.Bounded env31189 := by
  intro p hp
  have h : env31189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31188_31189 : H12AffineEnvironment.transform 14 136 env31188 = env31189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env31188 == env31189) = true)

theorem identity31189 : scanCanonicalize (H12AffineFastState.compose env31189 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31189 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,136,65536,70726,10400,1025,137,77898,33,73755,65877,8328,64,10588,79131,12637,10281,75222,73891,257,8573,13325,513]

theorem envBound31190 : H12AffineFastState.Bounded env31190 := by
  intro p hp
  have h : env31190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31189_31190 : H12AffineEnvironment.transform 13 13405 env31189 = env31190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31189 == env31190) = true)

theorem identity31190 : scanCanonicalize (H12AffineFastState.compose env31190 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31190 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31191 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,136,65536,70678,10400,1025,137,77850,33,73755,65797,8328,16,10508,79131,12557,10281,75142,73891,257,8493,13325,513]

theorem envBound31191 : H12AffineFastState.Bounded env31191 := by
  intro p hp
  have h : env31191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31190_31191 : H12AffineEnvironment.transform 5 16 env31190 = env31191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31190 == env31191) = true)

theorem identity31191 : scanCanonicalize (H12AffineFastState.compose env31191 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound31191 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31192 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13325,136,398,5528,10400,1025,137,12692,33,8597,139,8328,16,10508,13461,12557,10281,9224,8493,257,8493,13325,513]

theorem envBound31192 : H12AffineFastState.Bounded env31192 := by
  intro p hp
  have h : env31192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31191_31192 : H12AffineEnvironment.transform 15 398 env31191 = env31192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env31191 == env31192) = true)

theorem identity31192 : scanCanonicalize (H12AffineFastState.compose env31192 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31192 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env31193 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,263,5393,10281,1025,0,12573,33,8476,2,8193,16,10508,13340,12557,10281,9224,8493,257,8493,13325,513]

theorem envBound31193 : H12AffineFastState.Bounded env31193 := by
  intro p hp
  have h : env31193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31192_31193 : H12AffineEnvironment.transform 6 9 env31192 = env31193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31192 == env31193) = true)

def env31194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,10401,1025,32769,115871,32,120014,98781,8328,64,23809,115150,17664,56573,119043,73890,257,21792,46213,63188]

theorem envBound31194 : H12AffineFastState.Bounded env31194 := by
  intro p hp
  have h : env31194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31187_31194 : H12AffineEnvironment.transform 17 10401 env31187 = env31194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31187 == env31194) = true)

theorem identity31194 : scanCanonicalize (H12AffineFastState.compose env31194 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound31194 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env31195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,79250,10401,1025,21760,70046,32,65999,87260,8328,64,23809,70863,17664,2556,66562,73890,257,21792,24964,9173]

theorem envBound31195 : H12AffineFastState.Bounded env31195 := by
  intro p hp
  have h : env31195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31194_31195 : H12AffineEnvironment.transform 14 21761 env31194 = env31195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env31194 == env31195) = true)

theorem identity31195 : scanCanonicalize (H12AffineFastState.compose env31195 (packedSelected [0,1,2,6,8,10,11,12,14,15,16,18,19,20,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound31195 : packedSelected [0,1,2,6,8,10,11,12,14,15,16,18,19,20,27,31] rootPS < 2^1333 := by decide +kernel

def env31196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8615,5173,10401,1025,21760,12345,32,8296,30075,8328,64,23809,13672,17664,2556,9637,261,257,21792,24964,9173]

theorem envBound31196 : H12AffineFastState.Bounded env31196 := by
  intro p hp
  have h : env31196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31195_31196 : H12AffineEnvironment.transform 15 8615 env31195 = env31196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env31195 == env31196) = true)

theorem identity31196 : scanCanonicalize (H12AffineFastState.compose env31196 (packedSelected [2,6,9,11,14,16,17,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound31196 : packedSelected [2,6,9,11,14,16,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env31197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5237,372,8615,5173,10401,1025,373,12345,32,8296,8462,8328,64,2420,13672,4469,2556,9637,261,257,341,13809,9173]

theorem envBound31197 : H12AffineFastState.Bounded env31197 := by
  intro p hp
  have h : env31197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31196_31197 : H12AffineEnvironment.transform 13 5237 env31196 = env31197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env31196 == env31197) = true)

theorem identity31197 : scanCanonicalize (H12AffineFastState.compose env31197 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31197 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env31198 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,5237,81,8322,5173,10401,1025,80,12345,32,8296,8235,8328,64,2129,13389,4176,2265,9344,32,36,112,13524,8944]

theorem envBound31198 : H12AffineFastState.Bounded env31198 := by
  intro p hp
  have h : env31198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31197_31198 : H12AffineEnvironment.transform 7 37 env31197 = env31198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31197 == env31198) = true)

theorem identity31198 : scanCanonicalize (H12AffineFastState.compose env31198 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound31198 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env31199 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,8192,5237,81,8283,5173,10360,1025,80,12345,32,8296,8235,8273,64,2129,13389,4176,2048,9305,32,36,112,13325,8745]

theorem envBound31199 : H12AffineFastState.Bounded env31199 := by
  intro p hp
  have h : env31199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31198_31199 : H12AffineEnvironment.transform 6 89 env31198 = env31199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env31198 == env31199) = true)

theorem identity31199 : scanCanonicalize (H12AffineFastState.compose env31199 (packedSelected [0,1,2,3,5,6,7,8,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound31199 : packedSelected [0,1,2,3,5,6,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env31200 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,4096,5149,5237,81,5190,5173,7269,1025,80,1060,32,5237,5174,5196,64,2129,80,4176,2048,4164,32,36,112,16,5684]

theorem envBound31200 : H12AffineFastState.Bounded env31200 := by
  intro p hp
  have h : env31200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31199_31200 : H12AffineEnvironment.transform 12 5149 env31199 = env31200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env31199 == env31200) = true)

theorem identity31200 : scanCanonicalize (H12AffineFastState.compose env31200 (packedSelected [3,4,5,9,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound31200 : packedSelected [3,4,5,9,12,14] rootPS < 2^1333 := by decide +kernel

def env31201 : List Nat := [2,4,8,16,32,64,89,37,512,1024,2048,3109,2104,2128,81,2147,2064,64,1025,80,1060,32,2128,2067,2153,64,2129,80,3189,2048,3169,32,36,112,16,2577]

theorem envBound31201 : H12AffineFastState.Bounded env31201 := by
  intro p hp
  have h : env31201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31200_31201 : H12AffineEnvironment.transform 11 3109 env31200 = env31201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env31200 == env31201) = true)

theorem identity31201 : scanCanonicalize (H12AffineFastState.compose env31201 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound31201 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1