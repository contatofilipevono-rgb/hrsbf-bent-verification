import H12CloudChart1Data181

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env46120 : List Nat := [2,4,8,16,0,17,9,256,277,256,0,261,269,0,261,262,17,0,257,260,276,261,16,263,268,16,0,277,1,260,5,260,257,260,1,277]

theorem envBound46120 : H12AffineFastState.Bounded env46120 := by
  intro p hp
  have h : env46120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46119_46120 : H12AffineEnvironment.transform 8 277 env46119 = env46120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env46119 == env46120) = true)

theorem identity46120 : scanCanonicalize (H12AffineFastState.compose env46120 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46120 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env46121 : List Nat := [2,4,8,0,0,1,9,256,261,256,0,261,269,0,261,262,1,0,257,260,260,261,0,263,268,0,0,261,1,260,5,260,257,260,1,261]

theorem envBound46121 : H12AffineFastState.Bounded env46121 := by
  intro p hp
  have h : env46121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46120_46121 : H12AffineEnvironment.transform 3 0 env46120 = env46121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46120 == env46121) = true)

def env46122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98780,8328,65,4340965,79131,91403,179513,1500,4314198,257,95531,103567,74250]

theorem envBound46122 : H12AffineFastState.Bounded env46122 := by
  intro p hp
  have h : env46122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46091_46122 : H12AffineEnvironment.transform 22 17 env46091 = env46122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46091 == env46122) = true)

theorem identity46122 : scanCanonicalize (H12AffineFastState.compose env46122 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46122 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41431,8328,65,4340965,5392,17664,179513,1500,4256861,257,21792,46212,513]

theorem envBound46123 : H12AffineFastState.Bounded env46123 := by
  intro p hp
  have h : env46123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46122_46123 : H12AffineEnvironment.transform 15 8203 env46122 = env46123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46122 == env46123) = true)

theorem identity46123 : scanCanonicalize (H12AffineFastState.compose env46123 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41381) := by decide +kernel

theorem selectedBound46123 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41381,17,41431,8328,65,171328,5392,17664,179513,1500,22008,257,21792,46212,513]

theorem envBound46124 : H12AffineFastState.Bounded env46124 := by
  intro p hp
  have h : env46124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46123_46124 : H12AffineEnvironment.transform 21 41381 env46123 = env46124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41381 env46123 == env46124) = true)

def env46125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41261,17,41311,8192,65,171328,5392,17664,179513,1364,21872,257,21792,46092,513]

theorem envBound46125 : H12AffineFastState.Bounded env46125 := by
  intro p hp
  have h : env46125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46124_46125 : H12AffineEnvironment.transform 6 8 env46124 = env46125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46124 == env46125) = true)

theorem identity46125 : scanCanonicalize (H12AffineFastState.compose env46125 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound46125 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env46126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21872,17,21762,8192,65,157981,5392,17664,149860,1364,21872,257,21792,16465,513]

theorem envBound46126 : H12AffineFastState.Bounded env46126 := by
  intro p hp
  have h : env46126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46125_46126 : H12AffineEnvironment.transform 14 29789 env46125 = env46126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env46125 == env46126) = true)

theorem identity46126 : scanCanonicalize (H12AffineFastState.compose env46126 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46126 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env46127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8203,131072,10361,1025,8461,4160,33,17,83,8192,65,146508,5392,4177,138293,1364,33,257,113,5376,513]

theorem envBound46127 : H12AffineFastState.Bounded env46127 := by
  intro p hp
  have h : env46127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46126_46127 : H12AffineEnvironment.transform 13 5457 env46126 = env46127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46126 == env46127) = true)

theorem identity46127 : scanCanonicalize (H12AffineFastState.compose env46127 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound46127 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env46128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8203,13388,10361,1025,8461,4160,33,17,83,8192,65,2048,5392,4177,10361,1364,33,257,113,5376,513]

theorem envBound46128 : H12AffineFastState.Bounded env46128 := by
  intro p hp
  have h : env46128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46127_46128 : H12AffineEnvironment.transform 16 13388 env46127 = env46128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env46127 == env46128) = true)

theorem identity46128 : scanCanonicalize (H12AffineFastState.compose env46128 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46128 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env46129 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,13341,10280,1025,8461,4113,33,17,2,8192,16,2048,5392,4096,10280,1285,33,257,32,5376,513]

theorem envBound46129 : H12AffineFastState.Bounded env46129 := by
  intro p hp
  have h : env46129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46128_46129 : H12AffineEnvironment.transform 5 17 env46128 = env46129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46128 == env46129) = true)

theorem identity46129 : scanCanonicalize (H12AffineFastState.compose env46129 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46129 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46130 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5392,2341,1025,0,4113,33,17,2,269,16,2048,5392,4096,2341,1285,33,257,32,5376,513]

theorem envBound46130 : H12AffineFastState.Bounded env46130 := by
  intro p hp
  have h : env46130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46129_46130 : H12AffineEnvironment.transform 12 269 env46129 = env46130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46129 == env46130) = true)

theorem identity46130 : scanCanonicalize (H12AffineFastState.compose env46130 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46131 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5173,2048,1025,0,4113,33,17,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound46131 : H12AffineFastState.Bounded env46131 := by
  intro p hp
  have h : env46131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46130_46131 : H12AffineEnvironment.transform 7 37 env46130 = env46131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46130 == env46131) = true)

def env46132 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,1,35,1029,2048,1025,0,33,33,17,2,40,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound46132 : H12AffineFastState.Bounded env46132 := by
  intro p hp
  have h : env46132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46131_46132 : H12AffineEnvironment.transform 11 48 env46131 = env46132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46131 == env46132) = true)

theorem identity46132 : scanCanonicalize (H12AffineFastState.compose env46132 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound46132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46133 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,40,1045,1,35,1029,32,1025,0,33,33,17,2,40,16,32,1029,48,32,1056,33,36,32,1045,513]

theorem envBound46133 : H12AffineFastState.Bounded env46133 := by
  intro p hp
  have h : env46133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46132_46133 : H12AffineEnvironment.transform 10 32 env46132 = env46133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env46132 == env46133) = true)

def env46134 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,40,33,1,35,49,32,53,0,33,33,17,2,40,16,32,49,48,32,20,33,36,32,33,513]

theorem envBound46134 : H12AffineFastState.Bounded env46134 := by
  intro p hp
  have h : env46134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46133_46134 : H12AffineEnvironment.transform 9 52 env46133 = env46134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46133 == env46134) = true)

theorem identity46134 : scanCanonicalize (H12AffineFastState.compose env46134 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound46134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46135 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,40,33,1,35,49,32,53,0,33,33,17,2,40,16,32,49,48,32,20,33,36,32,33,10]

theorem envBound46135 : H12AffineFastState.Bounded env46135 := by
  intro p hp
  have h : env46135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46134_46135 : H12AffineEnvironment.transform 8 11 env46134 = env46135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env46134 == env46135) = true)

def leafEnv46135 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,40,33,1,35,49,32,53,0,33,33,17,2,21,40,1,16,32,49,48,32,20,33,36,32,5,35,33,10,1,33,0]

def active46135 : List Nat := [0,1,2,3,4]

def tree46135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46135 : H12WitnessSearch.Good tree46135 := H12GlobalWitnessIndex.good

theorem leafIdentity46135 : H12AffineFastState.composeSystem env46135 rootObs = leafEnv46135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46135 rootObs == leafEnv46135) = true)

theorem terminalChecked46135 : H12PackedTerminal.terminalCheckFast leafEnv46135 active46135 tree46135 = true := by decide +kernel

def env46136 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,40,32,1,35,48,32,52,0,33,33,17,2,40,16,32,48,48,32,21,33,36,32,32,513]

theorem envBound46136 : H12AffineFastState.Bounded env46136 := by
  intro p hp
  have h : env46136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46133_46136 : H12AffineEnvironment.transform 9 53 env46133 = env46136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46133 == env46136) = true)

theorem identity46136 : scanCanonicalize (H12AffineFastState.compose env46136 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46137 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,9,1,1,2,17,1,21,0,0,0,17,2,9,16,1,17,17,1,21,0,5,1,1,513]

theorem envBound46137 : H12AffineFastState.Bounded env46137 := by
  intro p hp
  have h : env46137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46136_46137 : H12AffineEnvironment.transform 4 1 env46136 = env46137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46136 == env46137) = true)

def leafEnv46137 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,9,1,1,2,17,1,21,0,0,0,17,2,20,9,1,16,1,17,17,1,21,0,5,1,5,2,1,513,1,0,0]

def active46137 : List Nat := [0,1,2,3,8]

def tree46137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46137 : H12WitnessSearch.Good tree46137 := H12GlobalWitnessIndex.good

theorem leafIdentity46137 : H12AffineFastState.composeSystem env46137 rootObs = leafEnv46137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46137 rootObs == leafEnv46137) = true)

theorem terminalChecked46137 : H12PackedTerminal.terminalCheckFast leafEnv46137 active46137 tree46137 = true := by decide +kernel

def env46138 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,1,35,1028,2048,1025,0,32,33,17,2,40,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound46138 : H12AffineFastState.Bounded env46138 := by
  intro p hp
  have h : env46138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46131_46138 : H12AffineEnvironment.transform 11 49 env46131 = env46138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46131 == env46138) = true)

theorem identity46138 : scanCanonicalize (H12AffineFastState.compose env46138 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound46138 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46139 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,40,1044,1,35,1028,1045,1025,0,32,33,17,2,40,16,1045,1028,49,1045,1056,33,36,32,1044,513]

theorem envBound46139 : H12AffineFastState.Bounded env46139 := by
  intro p hp
  have h : env46139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46138_46139 : H12AffineEnvironment.transform 10 1045 env46138 = env46139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env46138 == env46139) = true)

def env46140 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,40,32,1,35,48,33,53,0,32,33,17,2,40,16,33,48,49,33,20,33,36,32,32,513]

theorem envBound46140 : H12AffineFastState.Bounded env46140 := by
  intro p hp
  have h : env46140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46139_46140 : H12AffineEnvironment.transform 9 52 env46139 = env46140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46139 == env46140) = true)

theorem identity46140 : scanCanonicalize (H12AffineFastState.compose env46140 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46141 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,40,32,1,35,48,33,53,0,32,33,17,2,40,16,33,48,49,33,20,33,36,32,32,11]

theorem envBound46141 : H12AffineFastState.Bounded env46141 := by
  intro p hp
  have h : env46141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46140_46141 : H12AffineEnvironment.transform 8 10 env46140 = env46141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46140 == env46141) = true)

def leafEnv46141 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,40,32,1,35,48,33,53,0,32,33,17,2,21,40,1,16,33,48,49,33,20,33,36,32,5,35,32,11,1,32,0]

def active46141 : List Nat := [0,1,2,3,4]

def tree46141 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46141 : H12WitnessSearch.Good tree46141 := H12GlobalWitnessIndex.good

theorem leafIdentity46141 : H12AffineFastState.composeSystem env46141 rootObs = leafEnv46141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46141 rootObs == leafEnv46141) = true)

theorem terminalChecked46141 : H12PackedTerminal.terminalCheckFast leafEnv46141 active46141 tree46141 = true := by decide +kernel

def env46142 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,40,33,1,35,49,32,52,0,32,33,17,2,40,16,32,49,49,32,21,33,36,32,33,513]

theorem envBound46142 : H12AffineFastState.Bounded env46142 := by
  intro p hp
  have h : env46142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46139_46142 : H12AffineEnvironment.transform 9 53 env46139 = env46142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46139 == env46142) = true)

theorem identity46142 : scanCanonicalize (H12AffineFastState.compose env46142 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46142 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46143 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,9,0,1,2,16,1,21,0,1,0,17,2,9,16,1,16,16,1,21,0,5,1,0,513]

theorem envBound46143 : H12AffineFastState.Bounded env46143 := by
  intro p hp
  have h : env46143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46142_46143 : H12AffineEnvironment.transform 4 1 env46142 = env46143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46142 == env46143) = true)

def leafEnv46143 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,9,0,1,2,16,1,21,0,1,0,17,2,20,9,1,16,1,16,16,1,21,0,5,1,5,2,0,513,1,1,0]

def active46143 : List Nat := [0,1,2,3,8]

def tree46143 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46143 : H12WitnessSearch.Good tree46143 := H12GlobalWitnessIndex.good

theorem leafIdentity46143 : H12AffineFastState.composeSystem env46143 rootObs = leafEnv46143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46143 rootObs == leafEnv46143) = true)

theorem terminalChecked46143 : H12PackedTerminal.terminalCheckFast leafEnv46143 active46143 tree46143 = true := by decide +kernel

def env46144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41260,17,41310,8193,65,171328,5392,17664,179513,1365,21873,257,21792,46093,513]

theorem envBound46144 : H12AffineFastState.Bounded env46144 := by
  intro p hp
  have h : env46144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46124_46144 : H12AffineEnvironment.transform 6 9 env46124 = env46144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46124 == env46144) = true)

theorem identity46144 : scanCanonicalize (H12AffineFastState.compose env46144 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46144 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32040,1025,8540,4160,113,17,3,8193,65,146461,5392,17664,138340,1365,21873,257,21792,5456,513]

theorem envBound46145 : H12AffineFastState.Bounded env46145 := by
  intro p hp
  have h : env46145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46144_46145 : H12AffineEnvironment.transform 14 8541 env46144 = env46145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46144 == env46145) = true)

theorem identity46145 : scanCanonicalize (H12AffineFastState.compose env46145 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46145 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,32040,1025,8540,4160,113,17,3,8193,65,31757,5392,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound46146 : H12AffineFastState.Bounded env46146 := by
  intro p hp
  have h : env46146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46145_46146 : H12AffineEnvironment.transform 16 16400 env46145 = env46146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46145 == env46146) = true)

theorem identity46146 : scanCanonicalize (H12AffineFastState.compose env46146 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound46146 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8541,8203,13672,2128,1025,8540,4160,113,17,3,8193,65,2421,5392,12408,10508,1365,8201,257,8280,5456,513]

theorem envBound46147 : H12AffineFastState.Bounded env46147 := by
  intro p hp
  have h : env46147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46146_46147 : H12AffineEnvironment.transform 13 13688 env46146 = env46147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env46146 == env46147) = true)

theorem identity46147 : scanCanonicalize (H12AffineFastState.compose env46147 (packedSelected [5,8,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46147 : packedSelected [5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env46148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5236,81,263,5220,2128,1025,80,4160,113,17,3,269,65,2421,5392,4468,2048,1365,261,257,340,5456,513]

theorem envBound46148 : H12AffineFastState.Bounded env46148 := by
  intro p hp
  have h : env46148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46147_46148 : H12AffineEnvironment.transform 12 268 env46147 = env46148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46147 == env46148) = true)

theorem identity46148 : scanCanonicalize (H12AffineFastState.compose env46148 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46148 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46149 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,268,4161,81,263,4177,2128,52,80,4160,113,17,3,269,65,2421,4389,4468,2048,352,261,257,340,4453,513]

theorem envBound46149 : H12AffineFastState.Bounded env46149 := by
  intro p hp
  have h : env46149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46148_46149 : H12AffineEnvironment.transform 9 53 env46148 = env46149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46148 == env46149) = true)

theorem identity46149 : scanCanonicalize (H12AffineFastState.compose env46149 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46149 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46150 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,4096,40,4161,81,35,4177,2128,52,80,4160,113,17,3,41,65,2129,4097,4176,2048,68,33,37,112,4161,513]

theorem envBound46150 : H12AffineFastState.Bounded env46150 := by
  intro p hp
  have h : env46150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46149_46150 : H12AffineEnvironment.transform 7 36 env46149 = env46150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46149 == env46150) = true)

theorem identity46150 : scanCanonicalize (H12AffineFastState.compose env46150 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46151 : List Nat := [2,4,8,16,32,49,9,36,512,53,2048,4096,40,4144,32,35,4128,2081,52,33,4145,0,17,3,41,48,2080,4097,4129,2048,53,33,37,1,4144,513]

theorem envBound46151 : H12AffineFastState.Bounded env46151 := by
  intro p hp
  have h : env46151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46150_46151 : H12AffineEnvironment.transform 5 49 env46150 = env46151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46150 == env46151) = true)

theorem identity46151 : scanCanonicalize (H12AffineFastState.compose env46151 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound46151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46152 : List Nat := [2,4,8,16,32,49,9,36,512,53,2048,49,40,1,32,35,17,2081,52,33,0,0,17,3,41,48,2080,48,16,2048,53,33,37,1,1,513]

theorem envBound46152 : H12AffineFastState.Bounded env46152 := by
  intro p hp
  have h : env46152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46151_46152 : H12AffineEnvironment.transform 11 49 env46151 = env46152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46151 == env46152) = true)

theorem identity46152 : scanCanonicalize (H12AffineFastState.compose env46152 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46152 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46153 : List Nat := [2,4,8,16,16,1,9,20,512,5,2048,1,24,1,16,19,17,2065,4,17,0,0,17,3,25,0,2064,0,16,2048,5,17,21,1,1,513]

theorem envBound46153 : H12AffineFastState.Bounded env46153 := by
  intro p hp
  have h : env46153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46152_46153 : H12AffineEnvironment.transform 4 16 env46152 = env46153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46152 == env46153) = true)

theorem identity46153 : scanCanonicalize (H12AffineFastState.compose env46153 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46154 : List Nat := [2,4,8,16,16,1,9,20,512,5,1,1,24,1,16,19,17,16,4,17,0,0,17,3,25,0,17,0,16,1,5,17,21,1,1,513]

theorem envBound46154 : H12AffineFastState.Bounded env46154 := by
  intro p hp
  have h : env46154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46153_46154 : H12AffineEnvironment.transform 10 1 env46153 = env46154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46153 == env46154) = true)

theorem identity46154 : scanCanonicalize (H12AffineFastState.compose env46154 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46154 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46155 : List Nat := [2,4,8,16,16,1,9,20,16,5,1,1,24,1,16,19,17,16,4,17,0,0,17,3,25,0,17,0,16,1,5,17,21,1,1,17]

theorem envBound46155 : H12AffineFastState.Bounded env46155 := by
  intro p hp
  have h : env46155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46154_46155 : H12AffineEnvironment.transform 8 16 env46154 = env46155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46154 == env46155) = true)

theorem identity46155 : scanCanonicalize (H12AffineFastState.compose env46155 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46155 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46156 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,1,8,1,0,3,1,0,4,1,0,0,1,3,9,0,1,0,0,1,5,1,5,1,1,1]

theorem envBound46156 : H12AffineFastState.Bounded env46156 := by
  intro p hp
  have h : env46156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46155_46156 : H12AffineEnvironment.transform 3 0 env46155 = env46156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46155 == env46156) = true)

def env46157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98781,8328,65,12729588,79131,8480027,8568105,8390092,4314198,257,8484154,8492190,8462874]

theorem envBound46157 : H12AffineFastState.Bounded env46157 := by
  intro p hp
  have h : env46157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46090_46157 : H12AffineEnvironment.transform 17 32041 env46090 = env46157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env46090 == env46157) = true)

def env46158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98781,8328,65,4340964,79131,91403,179513,1500,4314198,257,95530,103566,74250]

theorem envBound46158 : H12AffineFastState.Bounded env46158 := by
  intro p hp
  have h : env46158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46157_46158 : H12AffineEnvironment.transform 22 16 env46157 = env46158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46157 == env46158) = true)

theorem identity46158 : scanCanonicalize (H12AffineFastState.compose env46158 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound46158 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98678,16,98781,8328,65,245138,79131,91403,179513,1500,21792,257,95530,103566,74250]

theorem envBound46159 : H12AffineFastState.Bounded env46159 := by
  intro p hp
  have h : env46159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46158_46159 : H12AffineEnvironment.transform 21 98678 env46158 = env46159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env46158 == env46159) = true)

def env46160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98678,16,98645,8192,65,245018,79131,91403,179513,1364,21792,257,95530,103430,74250]

theorem envBound46160 : H12AffineFastState.Bounded env46160 := by
  intro p hp
  have h : env46160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46159_46160 : H12AffineEnvironment.transform 6 8 env46159 = env46160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46159 == env46160) = true)

theorem identity46160 : scanCanonicalize (H12AffineFastState.compose env46160 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46160 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,77898,98678,16,98645,8192,65,245018,79131,77834,179513,1364,33,257,73771,103430,74250]

theorem envBound46161 : H12AffineFastState.Bounded env46161 := by
  intro p hp
  have h : env46161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46160_46161 : H12AffineEnvironment.transform 13 5377 env46160 = env46161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46160 == env46161) = true)

theorem identity46161 : scanCanonicalize (H12AffineFastState.compose env46161 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79178) := by decide +kernel

theorem selectedBound46161 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46162 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79178,10280,1025,32769,77898,98678,16,98645,8192,65,34896,79131,77834,100467,1364,33,257,73771,103430,74250]

theorem envBound46162 : H12AffineFastState.Bounded env46162 := by
  intro p hp
  have h : env46162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46161_46162 : H12AffineEnvironment.transform 16 79178 env46161 = env46162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79178 env46161 == env46162) = true)

theorem identity46162 : scanCanonicalize (H12AffineFastState.compose env46162 (packedSelected [0,7,9,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound46162 : packedSelected [0,7,9,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env46163 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33031,46157,10280,1025,32769,45389,113,16,82,8192,65,34896,46108,45325,2420,1364,33,257,41260,5377,41741]

theorem envBound46163 : H12AffineFastState.Bounded env46163 := by
  intro p hp
  have h : env46163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46162_46163 : H12AffineEnvironment.transform 15 33031 env46162 = env46163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env46162 == env46163) = true)

theorem identity46163 : scanCanonicalize (H12AffineFastState.compose env46163 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46163 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46164 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33031,46109,10280,1025,32769,45341,33,16,2,8192,17,34816,46108,45325,2340,1284,33,257,41260,5377,41741]

theorem envBound46164 : H12AffineFastState.Bounded env46164 := by
  intro p hp
  have h : env46164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46163_46164 : H12AffineEnvironment.transform 5 16 env46163 = env46164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46163 == env46164) = true)

theorem identity46164 : scanCanonicalize (H12AffineFastState.compose env46164 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound46164 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env46165 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5432,5377,32768,33031,33061,7440,1025,32769,33829,33,16,2,5432,17,34816,33060,33845,2340,1284,33,257,37908,5377,38453]

theorem envBound46165 : H12AffineFastState.Bounded env46165 := by
  intro p hp
  have h : env46165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46164_46165 : H12AffineEnvironment.transform 12 5432 env46164 = env46165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env46164 == env46165) = true)

theorem identity46165 : scanCanonicalize (H12AffineFastState.compose env46165 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 5172) := by decide +kernel

theorem selectedBound46165 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46166 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5432,5377,5172,5427,5393,7440,1025,5173,4113,33,16,2,5432,17,7220,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound46166 : H12AffineFastState.Bounded env46166 := by
  intro p hp
  have h : env46166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46165_46166 : H12AffineEnvironment.transform 14 5172 env46165 = env46166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5172 env46165 == env46166) = true)

theorem identity46166 : scanCanonicalize (H12AffineFastState.compose env46166 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound46166 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46167 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1077,269,308,1,262,292,2341,1025,0,1060,33,16,2,269,17,2049,293,1076,2340,1284,33,257,32,308,513]

theorem envBound46167 : H12AffineFastState.Bounded env46167 := by
  intro p hp
  have h : env46167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46166_46167 : H12AffineEnvironment.transform 11 1077 env46166 = env46167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env46166 == env46167) = true)

theorem identity46167 : scanCanonicalize (H12AffineFastState.compose env46167 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound46167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46168 : List Nat := [2,4,8,16,32,16,8,256,512,784,2048,805,269,308,1,262,292,2341,785,0,820,33,16,2,269,17,2049,293,804,2340,532,33,257,32,308,513]

theorem envBound46168 : H12AffineFastState.Bounded env46168 := by
  intro p hp
  have h : env46168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46167_46168 : H12AffineEnvironment.transform 9 784 env46167 = env46168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env46167 == env46168) = true)

theorem identity46168 : scanCanonicalize (H12AffineFastState.compose env46168 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound46168 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46169 : List Nat := [2,4,8,16,32,16,8,256,512,784,292,805,269,308,1,262,292,1,785,0,820,33,16,2,269,17,293,293,804,0,532,33,257,32,308,513]

theorem envBound46169 : H12AffineFastState.Bounded env46169 := by
  intro p hp
  have h : env46169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46168_46169 : H12AffineEnvironment.transform 10 292 env46168 = env46169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env46168 == env46169) = true)

theorem identity46169 : scanCanonicalize (H12AffineFastState.compose env46169 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound46169 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46170 : List Nat := [2,4,8,16,32,16,8,53,512,549,17,528,56,1,1,51,17,1,548,0,513,33,16,2,56,17,16,16,529,0,532,33,52,32,1,513]

theorem envBound46170 : H12AffineFastState.Bounded env46170 := by
  intro p hp
  have h : env46170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46169_46170 : H12AffineEnvironment.transform 7 53 env46169 = env46170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env46169 == env46170) = true)

def env46171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,98678,16,98644,8193,65,245019,79131,91403,179513,1365,21792,257,95530,103431,74250]

theorem envBound46171 : H12AffineFastState.Bounded env46171 := by
  intro p hp
  have h : env46171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46159_46171 : H12AffineEnvironment.transform 6 9 env46159 = env46171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46159 == env46171) = true)

theorem identity46171 : scanCanonicalize (H12AffineFastState.compose env46171 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound46171 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1025,29788,77898,95531,16,95497,8193,65,215366,79131,91403,149860,1365,21792,257,95530,90202,74250]

theorem envBound46172 : H12AffineFastState.Bounded env46172 := by
  intro p hp
  have h : env46172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46171_46172 : H12AffineEnvironment.transform 14 29789 env46171 = env46172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env46171 == env46172) = true)

theorem identity46172 : scanCanonicalize (H12AffineFastState.compose env46172 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46172 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env46173 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32008,1025,29788,77898,95498,16,95497,8193,65,215366,79131,91403,149829,1365,21761,257,95499,90202,74250]

theorem envBound46173 : H12AffineFastState.Bounded env46173 := by
  intro p hp
  have h : env46173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46172_46173 : H12AffineEnvironment.transform 4 1 env46172 = env46173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46172 == env46173) = true)

theorem identity46173 : scanCanonicalize (H12AffineFastState.compose env46173 (packedSelected [1,3,4,5,6,7,8,9,10,11,14,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound46173 : packedSelected [1,3,4,5,6,7,8,9,10,11,14,18,19,27] rootPS < 2^1333 := by decide +kernel

def env46174 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,16384,29789,30043,131072,32008,1025,29788,17681,81,16,82,8193,65,146461,16448,4176,149829,1365,21761,257,80,5377,22353]

theorem envBound46174 : H12AffineFastState.Bounded env46174 := by
  intro p hp
  have h : env46174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46173_46174 : H12AffineEnvironment.transform 15 30043 env46173 = env46174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env46173 == env46174) = true)

theorem identity46174 : scanCanonicalize (H12AffineFastState.compose env46174 (packedSelected [1,3,5,6,8,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46174 : packedSelected [1,3,5,6,8,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env46175 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5457,8460,8202,131072,10329,1025,8461,4160,81,16,82,8193,65,146461,5393,4176,138260,1365,80,257,80,5377,512]

theorem envBound46175 : H12AffineFastState.Bounded env46175 := by
  intro p hp
  have h : env46175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46174_46175 : H12AffineEnvironment.transform 13 5457 env46174 = env46175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46174 == env46175) = true)

theorem identity46175 : scanCanonicalize (H12AffineFastState.compose env46175 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound46175 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46176 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,5457,8460,8202,5141,10329,1025,8461,4160,81,16,82,8193,65,10248,5393,4176,2049,1365,80,257,80,5377,512]

theorem envBound46176 : H12AffineFastState.Bounded env46176 := by
  intro p hp
  have h : env46176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46175_46176 : H12AffineEnvironment.transform 16 5141 env46175 = env46176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env46175 == env46176) = true)

theorem identity46176 : scanCanonicalize (H12AffineFastState.compose env46176 (packedSelected [2,6,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound46176 : packedSelected [2,6,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46177 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,325,8192,1044,8460,8202,1360,10329,1025,8461,261,81,16,82,8193,65,10248,1108,277,2049,1365,80,257,80,1092,512]

theorem envBound46177 : H12AffineFastState.Bounded env46177 := by
  intro p hp
  have h : env46177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46176_46177 : H12AffineEnvironment.transform 11 325 env46176 = env46177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env46176 == env46177) = true)

theorem identity46177 : scanCanonicalize (H12AffineFastState.compose env46177 (packedSelected [1,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46177 : packedSelected [1,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46178 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,325,349,1044,81,343,1360,2308,1025,80,261,81,16,82,348,65,2389,1108,277,2049,1365,80,257,80,1092,512]

theorem envBound46178 : H12AffineFastState.Bounded env46178 := by
  intro p hp
  have h : env46178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46177_46178 : H12AffineEnvironment.transform 12 349 env46177 = env46178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46177 == env46178) = true)

theorem identity46178 : scanCanonicalize (H12AffineFastState.compose env46178 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46178 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46179 : List Nat := [2,4,8,16,1,64,9,5,512,1024,2048,64,88,1044,81,82,1109,2049,1025,80,0,81,16,82,89,65,2128,1108,16,2049,1104,80,4,80,1092,512]

theorem envBound46179 : H12AffineFastState.Bounded env46179 := by
  intro p hp
  have h : env46179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46178_46179 : H12AffineEnvironment.transform 7 5 env46178 = env46179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46178 == env46179) = true)

theorem identity46179 : scanCanonicalize (H12AffineFastState.compose env46179 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46179 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46180 : List Nat := [2,4,8,16,1,64,9,5,512,4,2048,64,88,16,81,82,81,2049,5,80,0,81,16,82,89,65,2128,80,16,2049,84,80,4,80,64,512]

theorem envBound46180 : H12AffineFastState.Bounded env46180 := by
  intro p hp
  have h : env46180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46179_46180 : H12AffineEnvironment.transform 9 4 env46179 = env46180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46179 == env46180) = true)

theorem identity46180 : scanCanonicalize (H12AffineFastState.compose env46180 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound46180 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env46181 : List Nat := [2,4,8,16,1,64,9,5,512,4,529,64,88,16,81,82,81,528,5,80,0,81,16,82,89,65,577,80,16,528,84,80,4,80,64,512]

theorem envBound46181 : H12AffineFastState.Bounded env46181 := by
  intro p hp
  have h : env46181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46180_46181 : H12AffineEnvironment.transform 10 529 env46180 = env46181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env46180 == env46181) = true)

theorem identity46181 : scanCanonicalize (H12AffineFastState.compose env46181 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46181 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env46182 : List Nat := [2,4,8,16,1,64,9,5,0,4,17,64,88,16,81,82,81,16,5,80,0,81,16,82,89,65,65,80,16,16,84,80,4,80,64,0]

theorem envBound46182 : H12AffineFastState.Bounded env46182 := by
  intro p hp
  have h : env46182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46181_46182 : H12AffineEnvironment.transform 8 0 env46181 = env46182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46181 == env46182) = true)

theorem identity46182 : scanCanonicalize (H12AffineFastState.compose env46182 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46182 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46183 : List Nat := [2,4,8,16,1,16,9,5,0,4,17,16,8,16,1,2,1,16,5,0,0,1,16,2,9,17,17,0,16,16,4,0,4,0,16,0]

theorem envBound46183 : H12AffineFastState.Bounded env46183 := by
  intro p hp
  have h : env46183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46182_46183 : H12AffineEnvironment.transform 5 16 env46182 = env46183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46182 == env46183) = true)

theorem identity46183 : scanCanonicalize (H12AffineFastState.compose env46183 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound46183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46184 : List Nat := [2,4,8,4,1,4,9,5,0,4,5,4,8,4,1,2,1,4,5,0,0,1,4,2,9,5,5,0,4,4,4,0,4,0,4,0]

theorem envBound46184 : H12AffineFastState.Bounded env46184 := by
  intro p hp
  have h : env46184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46183_46184 : H12AffineEnvironment.transform 3 4 env46183 = env46184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env46183 == env46184) = true)

theorem identity46184 : scanCanonicalize (H12AffineFastState.compose env46184 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46184 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46185 : List Nat := [2,0,8,0,1,0,9,1,0,0,1,0,8,0,1,2,1,0,1,0,0,1,0,2,9,1,1,0,0,0,0,0,0,0,0,0]

theorem envBound46185 : H12AffineFastState.Bounded env46185 := by
  intro p hp
  have h : env46185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46184_46185 : H12AffineEnvironment.transform 1 0 env46184 = env46185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46184 == env46185) = true)

theorem identity46185 : scanCanonicalize (H12AffineFastState.compose env46185 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46186 : List Nat := [2,0,0,0,1,0,1,1,0,0,1,0,0,0,1,2,1,0,1,0,0,1,0,2,1,1,1,0,0,0,0,0,0,0,0,0]

theorem envBound46186 : H12AffineFastState.Bounded env46186 := by
  intro p hp
  have h : env46186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46185_46186 : H12AffineEnvironment.transform 2 0 env46185 = env46186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46185 == env46186) = true)

theorem identity46186 : scanCanonicalize (H12AffineFastState.compose env46186 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46186 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46187 : List Nat := [0,0,0,0,1,0,1,1,0,0,1,0,0,0,1,0,1,0,1,0,0,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0]

theorem envBound46187 : H12AffineFastState.Bounded env46187 := by
  intro p hp
  have h : env46187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46186_46187 : H12AffineEnvironment.transform 0 0 env46186 = env46187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46186 == env46187) = true)

def env46188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98781,8328,65,4340965,79131,91402,179512,1501,4314198,257,95531,103567,74251]

theorem envBound46188 : H12AffineFastState.Bounded env46188 := by
  intro p hp
  have h : env46188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46157_46188 : H12AffineEnvironment.transform 22 17 env46157 = env46188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46157 == env46188) = true)

theorem identity46188 : scanCanonicalize (H12AffineFastState.compose env46188 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound46188 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32041,1025,32769,58516,4194304,17,21763,8328,65,4340965,57797,45524,179512,1501,4194440,257,41461,16465,63189]

theorem envBound46189 : H12AffineFastState.Bounded env46189 := by
  intro p hp
  have h : env46189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46188_46189 : H12AffineEnvironment.transform 15 54494 env46188 = env46189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env46188 == env46189) = true)

def env46190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,58396,4194304,17,21763,8192,65,4340845,57677,45404,179512,1365,4194304,257,41341,16465,63069]

theorem envBound46190 : H12AffineFastState.Bounded env46190 := by
  intro p hp
  have h : env46190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46189_46190 : H12AffineEnvironment.transform 6 8 env46189 = env46190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46189 == env46190) = true)

theorem identity46190 : scanCanonicalize (H12AffineFastState.compose env46190 (packedSelected [0,1,9,14,19,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46190 : packedSelected [0,1,9,14,19,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env46191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4160,4194304,17,21763,8192,65,4340845,5393,17664,149860,1365,4194304,257,21793,16465,513]

theorem envBound46191 : H12AffineFastState.Bounded env46191 := by
  intro p hp
  have h : env46191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46190_46191 : H12AffineEnvironment.transform 14 29788 env46190 = env46191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46190 == env46191) = true)

theorem identity46191 : scanCanonicalize (H12AffineFastState.compose env46191 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound46191 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env46192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4160,147505,17,21763,8192,65,31836,5393,17664,149860,1365,147505,257,21793,16465,513]

theorem envBound46192 : H12AffineFastState.Bounded env46192 := by
  intro p hp
  have h : env46192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46191_46192 : H12AffineEnvironment.transform 21 147505 env46191 = env46192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env46191 == env46192) = true)

theorem identity46192 : scanCanonicalize (H12AffineFastState.compose env46192 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46192 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,10281,1025,8541,4160,136497,17,3,8192,65,10588,5393,4096,138340,1365,136497,257,33,5457,513]

theorem envBound46193 : H12AffineFastState.Bounded env46193 := by
  intro p hp
  have h : env46193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46192_46193 : H12AffineEnvironment.transform 13 5376 env46192 = env46193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46192 == env46193) = true)

theorem identity46193 : scanCanonicalize (H12AffineFastState.compose env46193 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound46193 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,13388,10281,1025,8541,4160,8573,17,3,8192,65,10588,5393,4096,10280,1365,8573,257,33,5457,513]

theorem envBound46194 : H12AffineFastState.Bounded env46194 := by
  intro p hp
  have h : env46194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46193_46194 : H12AffineEnvironment.transform 16 13388 env46193 = env46194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env46193 == env46194) = true)

theorem identity46194 : scanCanonicalize (H12AffineFastState.compose env46194 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46194 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46195 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,8540,8202,12637,10281,272,8541,4160,8573,17,3,8192,65,10588,4096,4096,10280,68,8573,257,33,4160,513]

theorem envBound46195 : H12AffineFastState.Bounded env46195 := by
  intro p hp
  have h : env46195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46194_46195 : H12AffineEnvironment.transform 9 273 env46194 = env46195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46194 == env46195) = true)

theorem identity46195 : scanCanonicalize (H12AffineFastState.compose env46195 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound46195 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46196 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,8192,4113,8540,8202,12637,8313,272,8541,4160,8573,17,3,8192,65,8460,4096,4096,8312,68,8573,257,33,4160,513]

theorem envBound46196 : H12AffineFastState.Bounded env46196 := by
  intro p hp
  have h : env46196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46195_46196 : H12AffineEnvironment.transform 10 80 env46195 = env46196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env46195 == env46196) = true)

theorem identity46196 : scanCanonicalize (H12AffineFastState.compose env46196 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46196 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46197 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,348,4113,0,342,4097,293,272,1,4160,33,17,3,348,65,80,4096,4096,292,68,33,257,33,4160,513]

theorem envBound46197 : H12AffineFastState.Bounded env46197 := by
  intro p hp
  have h : env46197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46196_46197 : H12AffineEnvironment.transform 12 348 env46196 = env46197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46196 == env46197) = true)

theorem identity46197 : scanCanonicalize (H12AffineFastState.compose env46197 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound46197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46198 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,308,348,293,0,342,309,293,272,1,372,33,17,3,348,65,80,308,308,292,68,33,257,33,372,513]

theorem envBound46198 : H12AffineFastState.Bounded env46198 := by
  intro p hp
  have h : env46198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46197_46198 : H12AffineEnvironment.transform 11 308 env46197 = env46198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env46197 == env46198) = true)

theorem identity46198 : scanCanonicalize (H12AffineFastState.compose env46198 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 382) := by decide +kernel

theorem selectedBound46198 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46199 : List Nat := [2,4,8,16,32,64,8,256,382,273,80,308,348,293,0,342,309,293,272,1,372,33,17,3,348,65,80,308,308,292,68,33,257,33,372,383]

theorem envBound46199 : H12AffineFastState.Bounded env46199 := by
  intro p hp
  have h : env46199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46198_46199 : H12AffineEnvironment.transform 8 382 env46198 = env46199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 382 env46198 == env46199) = true)

theorem identity46199 : scanCanonicalize (H12AffineFastState.compose env46199 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46199 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46200 : List Nat := [2,4,8,16,32,48,8,256,270,273,32,308,300,293,0,294,309,293,272,1,260,33,17,3,300,49,32,308,308,292,52,33,257,33,260,271]

theorem envBound46200 : H12AffineFastState.Bounded env46200 := by
  intro p hp
  have h : env46200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46199_46200 : H12AffineEnvironment.transform 5 48 env46199 = env46200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46199 == env46200) = true)

theorem identity46200 : scanCanonicalize (H12AffineFastState.compose env46200 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46200 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46201 : List Nat := [2,4,8,16,32,48,8,37,43,52,32,17,9,0,0,3,16,0,53,1,33,33,17,3,9,49,32,17,17,1,52,33,36,33,33,42]

theorem envBound46201 : H12AffineFastState.Bounded env46201 := by
  intro p hp
  have h : env46201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46200_46201 : H12AffineEnvironment.transform 7 37 env46200 = env46201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46200 == env46201) = true)

theorem identity46201 : scanCanonicalize (H12AffineFastState.compose env46201 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46201 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46202 : List Nat := [2,4,8,16,0,16,8,5,11,20,0,17,9,0,0,3,16,0,21,1,1,1,17,3,9,17,0,17,17,1,20,1,4,1,1,10]

theorem envBound46202 : H12AffineFastState.Bounded env46202 := by
  intro p hp
  have h : env46202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46201_46202 : H12AffineEnvironment.transform 4 0 env46201 = env46202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46201 == env46202) = true)

theorem identity46202 : scanCanonicalize (H12AffineFastState.compose env46202 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46203 : List Nat := [2,0,8,16,0,16,8,1,11,16,0,17,9,0,0,3,16,0,17,1,1,1,17,3,9,17,0,17,17,1,16,1,0,1,1,10]

theorem envBound46203 : H12AffineFastState.Bounded env46203 := by
  intro p hp
  have h : env46203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46202_46203 : H12AffineEnvironment.transform 1 0 env46202 = env46203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46202 == env46203) = true)

theorem identity46203 : scanCanonicalize (H12AffineFastState.compose env46203 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46203 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46204 : List Nat := [1,0,8,16,0,16,8,1,8,16,0,17,9,0,0,0,16,0,17,1,1,1,17,0,9,17,0,17,17,1,16,1,0,1,1,9]

theorem envBound46204 : H12AffineFastState.Bounded env46204 := by
  intro p hp
  have h : env46204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46203_46204 : H12AffineEnvironment.transform 0 1 env46203 = env46204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46203 == env46204) = true)

def env46205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,58397,4194304,17,21763,8193,65,4340844,57676,45405,179512,1364,4194305,257,41340,16465,63068]

theorem envBound46205 : H12AffineFastState.Bounded env46205 := by
  intro p hp
  have h : env46205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46189_46205 : H12AffineEnvironment.transform 6 9 env46189 = env46205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46189 == env46205) = true)

theorem identity46205 : scanCanonicalize (H12AffineFastState.compose env46205 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46205 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,131072,32041,1025,8540,17728,4194304,17,21763,8193,65,4340844,16401,4096,138341,1364,4194305,257,33,16465,22273]

theorem envBound46206 : H12AffineFastState.Bounded env46206 := by
  intro p hp
  have h : env46206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46205_46206 : H12AffineEnvironment.transform 14 8541 env46205 = env46206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46205 == env46206) = true)

theorem identity46206 : scanCanonicalize (H12AffineFastState.compose env46206 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound46206 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,16401,32041,1025,8540,17728,4194304,17,21763,8193,65,4226173,16401,4096,23668,1364,4194305,257,33,16465,22273]

theorem envBound46207 : H12AffineFastState.Bounded env46207 := by
  intro p hp
  have h : env46207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46206_46207 : H12AffineEnvironment.transform 16 16401 env46206 = env46207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46206 == env46207) = true)

theorem identity46207 : scanCanonicalize (H12AffineFastState.compose env46207 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 29960) := by decide +kernel

theorem selectedBound46207 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env46208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,16401,32041,1025,8540,17728,29960,17,21763,8193,65,2421,16401,4096,23668,1364,29961,257,33,16465,22273]

theorem envBound46208 : H12AffineFastState.Bounded env46208 := by
  intro p hp
  have h : env46208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46207_46208 : H12AffineEnvironment.transform 21 29960 env46207 = env46208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29960 env46207 == env46208) = true)

theorem identity46208 : scanCanonicalize (H12AffineFastState.compose env46208 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46208 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env46209 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,16401,23669,1025,0,17728,21588,17,21763,349,65,2421,16401,4096,23668,1364,21589,257,33,16465,22273]

theorem envBound46209 : H12AffineFastState.Bounded env46209 := by
  intro p hp
  have h : env46209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46208_46209 : H12AffineEnvironment.transform 12 348 env46208 = env46209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46208 == env46209) = true)

theorem identity46209 : scanCanonicalize (H12AffineFastState.compose env46209 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46209 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env46210 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,16384,1,21590,16401,23669,1025,0,17460,21588,17,21623,41,65,2049,16401,4096,23668,1056,21589,117,33,16465,22133]

theorem envBound46210 : H12AffineFastState.Bounded env46210 := by
  intro p hp
  have h : env46210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46209_46210 : H12AffineEnvironment.transform 7 116 env46209 = env46210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46209 == env46210) = true)

theorem identity46210 : scanCanonicalize (H12AffineFastState.compose env46210 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound46210 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46211 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,40,5237,1,35,5220,2048,1025,0,4161,33,17,2,41,65,2049,5220,4096,2049,1056,32,117,33,5156,512]

theorem envBound46211 : H12AffineFastState.Bounded env46211 := by
  intro p hp
  have h : env46211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46210_46211 : H12AffineEnvironment.transform 13 5237 env46210 = env46211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env46210 == env46211) = true)

theorem identity46211 : scanCanonicalize (H12AffineFastState.compose env46211 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46211 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46212 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,4096,8,5205,1,3,5188,2048,1025,0,4161,1,17,2,9,65,2049,5188,4096,2049,1024,0,85,1,5124,512]

theorem envBound46212 : H12AffineFastState.Bounded env46212 := by
  intro p hp
  have h : env46212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46211_46212 : H12AffineEnvironment.transform 4 0 env46211 = env46212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46211 == env46212) = true)

theorem identity46212 : scanCanonicalize (H12AffineFastState.compose env46212 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46212 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46213 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5124,1,3,5141,2048,1025,0,4112,1,17,2,9,16,2049,5141,4096,2049,1024,0,4,1,5124,512]

theorem envBound46213 : H12AffineFastState.Bounded env46213 := by
  intro p hp
  have h : env46213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46212_46213 : H12AffineEnvironment.transform 5 17 env46212 = env46213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46212 == env46213) = true)

theorem identity46213 : scanCanonicalize (H12AffineFastState.compose env46213 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46213 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46214 : List Nat := [2,4,8,16,0,17,9,5,1,1024,2048,4096,8,5124,1,3,5141,2048,1025,0,4112,1,17,2,9,16,2049,5141,4096,2049,1024,0,4,1,5124,1]

theorem envBound46214 : H12AffineFastState.Bounded env46214 := by
  intro p hp
  have h : env46214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46213_46214 : H12AffineEnvironment.transform 8 1 env46213 = env46214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46213 == env46214) = true)

theorem identity46214 : scanCanonicalize (H12AffineFastState.compose env46214 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound46214 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46215 : List Nat := [2,4,8,16,0,17,9,5,1,1024,2048,1044,8,16,1,3,1,2048,1025,0,1028,1,17,2,9,16,2049,1,1044,2049,1024,0,4,1,16,1]

theorem envBound46215 : H12AffineFastState.Bounded env46215 := by
  intro p hp
  have h : env46215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46214_46215 : H12AffineEnvironment.transform 11 1044 env46214 = env46215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env46214 == env46215) = true)

theorem identity46215 : scanCanonicalize (H12AffineFastState.compose env46215 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound46215 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env46216 : List Nat := [2,4,8,16,0,17,9,5,1,21,2048,1,8,16,1,3,1,2048,20,0,17,1,17,2,9,16,2049,1,1,2049,21,0,4,1,16,1]

theorem envBound46216 : H12AffineFastState.Bounded env46216 := by
  intro p hp
  have h : env46216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46215_46216 : H12AffineEnvironment.transform 9 21 env46215 = env46216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env46215 == env46216) = true)

theorem identity46216 : scanCanonicalize (H12AffineFastState.compose env46216 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound46216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46217 : List Nat := [2,4,8,16,0,17,9,5,1,21,5,1,8,16,1,3,1,5,20,0,17,1,17,2,9,16,4,1,1,4,21,0,4,1,16,1]

theorem envBound46217 : H12AffineFastState.Bounded env46217 := by
  intro p hp
  have h : env46217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46216_46217 : H12AffineEnvironment.transform 10 5 env46216 = env46217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env46216 == env46217) = true)

def env46218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,347491,4194304,8388608,392437,8328,65,12729589,79130,8722482,8830976,8681700,4314199,257,8484155,8492191,8740658]

theorem envBound46218 : H12AffineFastState.Bounded env46218 := by
  intro p hp
  have h : env46218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46089_46218 : H12AffineEnvironment.transform 23 392437 env46089 = env46218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 392437 env46089 == env46218) = true)

def env46219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,8388608,98781,8328,65,12729589,79130,8480026,8568104,8390092,4314199,257,8484155,8492191,8462874]

theorem envBound46219 : H12AffineFastState.Bounded env46219 := by
  intro p hp
  have h : env46219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46218_46219 : H12AffineEnvironment.transform 17 32040 env46218 = env46219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env46218 == env46219) = true)

def env46220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,16,98781,8328,65,4340965,79130,91402,179512,1500,4314199,257,95531,103567,74250]

theorem envBound46220 : H12AffineFastState.Bounded env46220 := by
  intro p hp
  have h : env46220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46219_46220 : H12AffineEnvironment.transform 22 16 env46219 = env46220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46219 == env46220) = true)

theorem identity46220 : scanCanonicalize (H12AffineFastState.compose env46220 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound46220 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,41341,16,98781,8328,65,171416,79130,91402,179512,1500,95530,257,95531,103567,74250]

theorem envBound46221 : H12AffineFastState.Bounded env46221 := by
  intro p hp
  have h : env46221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46220_46221 : H12AffineEnvironment.transform 21 41341 env46220 = env46221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env46220 == env46221) = true)

theorem identity46221 : scanCanonicalize (H12AffineFastState.compose env46221 (packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound46221 : packedSelected [0,5,8,9,11,14,15,22,24,26,27,28,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env46222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21647,131072,32040,1025,32769,25796,41341,16,54610,8328,65,171416,24981,12677,179512,1500,8613,257,8612,49152,30341]

theorem envBound46222 : H12AffineFastState.Bounded env46222 := by
  intro p hp
  have h : env46222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46221_46222 : H12AffineEnvironment.transform 15 21647 env46221 = env46222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env46221 == env46222) = true)

theorem identity46222 : scanCanonicalize (H12AffineFastState.compose env46222 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46222 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21647,131072,23588,1025,32769,17864,32881,16,54610,388,65,171416,16537,4233,171060,1500,169,257,168,49152,22409]

theorem envBound46223 : H12AffineFastState.Bounded env46223 := by
  intro p hp
  have h : env46223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46222_46223 : H12AffineEnvironment.transform 12 268 env46222 = env46223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46222 == env46223) = true)

theorem identity46223 : scanCanonicalize (H12AffineFastState.compose env46223 (packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 38345) := by decide +kernel

theorem selectedBound46223 : packedSelected [0,3,4,7,10,11,12,15,17,18,19,22,24] rootPS < 2^1333 := by decide +kernel

def env46224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,32768,21647,38345,23588,1025,32769,17864,32881,16,54610,388,65,2129,16537,4233,2557,1500,169,257,168,49152,22409]

theorem envBound46224 : H12AffineFastState.Bounded env46224 := by
  intro p hp
  have h : env46224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46223_46224 : H12AffineEnvironment.transform 16 38345 env46223 = env46224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38345 env46223 == env46224) = true)

theorem identity46224 : scanCanonicalize (H12AffineFastState.compose env46224 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound46224 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env46225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,80,21647,5529,23588,1025,81,17864,33,16,21762,388,65,2129,16537,4233,2557,1500,169,257,168,16464,22409]

theorem envBound46225 : H12AffineFastState.Bounded env46225 := by
  intro p hp
  have h : env46225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46224_46225 : H12AffineEnvironment.transform 14 80 env46224 = env46225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env46224 == env46225) = true)

theorem identity46225 : scanCanonicalize (H12AffineFastState.compose env46225 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46225 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env46226 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,16384,80,21647,5221,23588,1025,81,17460,33,16,21758,120,65,2129,16537,4233,2049,1056,169,253,168,16464,22133]

theorem envBound46226 : H12AffineFastState.Bounded env46226 := by
  intro p hp
  have h : env46226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46225_46226 : H12AffineEnvironment.transform 7 252 env46225 = env46226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46225 == env46226) = true)

theorem identity46226 : scanCanonicalize (H12AffineFastState.compose env46226 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound46226 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env46227 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,240,5372,80,115,5221,2264,1025,81,4296,33,16,2,120,65,2129,5221,4233,2049,1056,169,253,168,5292,649]

theorem envBound46227 : H12AffineFastState.Bounded env46227 := by
  intro p hp
  have h : env46227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46226_46227 : H12AffineEnvironment.transform 13 5372 env46226 = env46227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env46226 == env46227) = true)

theorem identity46227 : scanCanonicalize (H12AffineFastState.compose env46227 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46227 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46228 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,80,115,5221,2129,1025,81,4161,33,16,2,120,65,2129,5221,4096,2049,1056,32,116,33,5157,512]

theorem envBound46228 : H12AffineFastState.Bounded env46228 := by
  intro p hp
  have h : env46228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46227_46228 : H12AffineEnvironment.transform 6 9 env46227 = env46228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46227 == env46228) = true)

theorem identity46228 : scanCanonicalize (H12AffineFastState.compose env46228 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46228 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46229 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,80,82,5188,2129,1025,81,4161,0,16,2,89,65,2129,5188,4096,2049,1025,1,85,0,5124,512]

theorem envBound46229 : H12AffineFastState.Bounded env46229 := by
  intro p hp
  have h : env46229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46228_46229 : H12AffineEnvironment.transform 4 1 env46228 = env46229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46228 == env46229) = true)

theorem identity46229 : scanCanonicalize (H12AffineFastState.compose env46229 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46229 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46230 : List Nat := [2,4,8,16,1,64,9,84,512,1024,0,4096,88,5204,80,82,5188,81,1025,81,4161,0,16,2,89,65,81,5188,4096,1,1025,1,85,0,5124,512]

theorem envBound46230 : H12AffineFastState.Bounded env46230 := by
  intro p hp
  have h : env46230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46229_46230 : H12AffineEnvironment.transform 10 0 env46229 = env46230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46229 == env46230) = true)

def env46231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,77899,4194304,17,98781,8328,65,4340964,79130,91403,179513,1501,4314199,257,95530,103566,74251]

theorem envBound46231 : H12AffineFastState.Bounded env46231 := by
  intro p hp
  have h : env46231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46219_46231 : H12AffineEnvironment.transform 22 17 env46219 = env46231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46219 == env46231) = true)

theorem identity46231 : scanCanonicalize (H12AffineFastState.compose env46231 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound46231 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32040,1025,29908,77899,4194304,17,95496,8328,65,4340964,79130,91403,149996,1501,4268162,257,95530,90203,74251]

theorem envBound46232 : H12AffineFastState.Bounded env46232 := by
  intro p hp
  have h : env46232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46231_46232 : H12AffineEnvironment.transform 14 29909 env46231 = env46232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env46231 == env46232) = true)

def env46233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10280,1025,8660,77899,4194304,17,73736,8328,65,4340964,79130,77835,138476,1501,4268162,257,73770,79195,74251]

theorem envBound46233 : H12AffineFastState.Bounded env46233 := by
  intro p hp
  have h : env46233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46232_46233 : H12AffineEnvironment.transform 13 5376 env46232 = env46233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46232 == env46233) = true)

theorem identity46233 : scanCanonicalize (H12AffineFastState.compose env46233 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46233 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1025,8540,77899,4194304,17,73736,8192,65,4340844,79130,77835,138340,1365,4268042,257,73770,79195,74251]

theorem envBound46234 : H12AffineFastState.Bounded env46234 := by
  intro p hp
  have h : env46234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46233_46234 : H12AffineEnvironment.transform 6 8 env46233 = env46234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46233 == env46234) = true)

theorem identity46234 : scanCanonicalize (H12AffineFastState.compose env46234 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46234 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10280,1025,8540,4161,4194304,17,2,8192,65,4340844,5392,4097,138340,1365,4194304,257,32,5457,513]

theorem envBound46235 : H12AffineFastState.Bounded env46235 := by
  intro p hp
  have h : env46235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46234_46235 : H12AffineEnvironment.transform 15 8202 env46234 = env46235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46234 == env46235) = true)

theorem identity46235 : scanCanonicalize (H12AffineFastState.compose env46235 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 136496) := by decide +kernel

theorem selectedBound46235 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10280,1025,8540,4161,136496,17,2,8192,65,10588,5392,4097,138340,1365,136496,257,32,5457,513]

theorem envBound46236 : H12AffineFastState.Bounded env46236 := by
  intro p hp
  have h : env46236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46235_46236 : H12AffineEnvironment.transform 21 136496 env46235 = env46236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136496 env46235 == env46236) = true)

theorem identity46236 : scanCanonicalize (H12AffineFastState.compose env46236 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound46236 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10280,1025,8540,4161,33,17,2,8192,65,10588,5392,4097,2421,1365,33,257,32,5457,513]

theorem envBound46237 : H12AffineFastState.Bounded env46237 := by
  intro p hp
  have h : env46237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46236_46237 : H12AffineEnvironment.transform 16 5393 env46236 = env46237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env46236 == env46237) = true)

theorem identity46237 : scanCanonicalize (H12AffineFastState.compose env46237 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound46237 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5376,33,374,5393,2388,1025,32,4161,33,17,2,380,65,2080,5392,4097,2421,1365,33,257,32,5457,513]

theorem envBound46238 : H12AffineFastState.Bounded env46238 := by
  intro p hp
  have h : env46238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46237_46238 : H12AffineEnvironment.transform 12 380 env46237 = env46238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env46237 == env46238) = true)

theorem identity46238 : scanCanonicalize (H12AffineFastState.compose env46238 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46238 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46239 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,5376,33,295,5393,2309,1025,32,4112,33,17,2,301,16,2080,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound46239 : H12AffineFastState.Bounded env46239 := by
  intro p hp
  have h : env46239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46238_46239 : H12AffineEnvironment.transform 5 17 env46238 = env46239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46238 == env46239) = true)

theorem identity46239 : scanCanonicalize (H12AffineFastState.compose env46239 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound46239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46240 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,301,4388,33,295,4405,2309,37,32,4112,33,17,2,301,16,2080,4404,4097,2340,288,33,257,32,4388,513]

theorem envBound46240 : H12AffineFastState.Bounded env46240 := by
  intro p hp
  have h : env46240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46239_46240 : H12AffineEnvironment.transform 9 36 env46239 = env46240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env46239 == env46240) = true)

theorem identity46240 : scanCanonicalize (H12AffineFastState.compose env46240 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound46240 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46241 : List Nat := [2,4,8,16,32,17,8,256,512,36,560,4096,301,4388,33,295,4405,821,37,32,4112,33,17,2,301,16,528,4404,4097,788,288,33,257,32,4388,513]

theorem envBound46241 : H12AffineFastState.Bounded env46241 := by
  intro p hp
  have h : env46241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46240_46241 : H12AffineEnvironment.transform 10 560 env46240 = env46241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env46240 == env46241) = true)

def env46242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1025,8661,77899,4194304,17,73737,8328,65,4340964,79130,77834,138477,1501,4268162,257,73771,79194,74251]

theorem envBound46242 : H12AffineFastState.Bounded env46242 := by
  intro p hp
  have h : env46242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46232_46242 : H12AffineEnvironment.transform 13 5377 env46232 = env46242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46232 == env46242) = true)

theorem identity46242 : scanCanonicalize (H12AffineFastState.compose env46242 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound46242 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,5392,10281,1025,8661,77899,4194304,17,73737,8328,65,4205044,79130,77834,2557,1501,4268162,257,73771,79194,74251]

theorem envBound46243 : H12AffineFastState.Bounded env46243 := by
  intro p hp
  have h : env46243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46242_46243 : H12AffineEnvironment.transform 16 5392 env46242 = env46243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env46242 == env46243) = true)

theorem identity46243 : scanCanonicalize (H12AffineFastState.compose env46243 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound46243 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,9498,5392,10281,1025,8661,5457,4194304,17,1299,8328,65,4205044,4096,5392,2557,1501,4195736,257,1329,4160,1809]

theorem envBound46244 : H12AffineFastState.Bounded env46244 := by
  intro p hp
  have h : env46244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46243_46244 : H12AffineEnvironment.transform 15 9498 env46243 = env46244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env46243 == env46244) = true)

theorem identity46244 : scanCanonicalize (H12AffineFastState.compose env46244 (packedSelected [0,4,7,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound46244 : packedSelected [0,4,7,22,23,32] rootPS < 2^1333 := by decide +kernel

def env46245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,5377,1260,34,5392,3345,1025,1261,5457,4194304,17,1299,1456,65,4197580,4096,5392,2557,1501,4195736,257,1329,4160,1809]

theorem envBound46245 : H12AffineFastState.Bounded env46245 := by
  intro p hp
  have h : env46245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46244_46245 : H12AffineEnvironment.transform 12 1336 env46244 = env46245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env46244 == env46245) = true)

theorem identity46245 : scanCanonicalize (H12AffineFastState.compose env46245 (packedSelected [0,2,6,12,14,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46245 : packedSelected [0,2,6,12,14,27,38] rootPS < 2^1333 := by decide +kernel

def env46246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5377,1125,34,5392,3345,1025,1124,5457,4194304,17,1299,1337,65,4197445,4096,5392,2420,1364,4195601,257,1329,4160,1809]

theorem envBound46246 : H12AffineFastState.Bounded env46246 := by
  intro p hp
  have h : env46246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46245_46246 : H12AffineEnvironment.transform 6 9 env46245 = env46246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46245 == env46246) = true)

theorem identity46246 : scanCanonicalize (H12AffineFastState.compose env46246 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 1329) := by decide +kernel

theorem selectedBound46246 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env46247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5377,1125,34,5392,3345,1025,1124,5457,1329,17,1299,1337,65,2420,4096,5392,2420,1364,32,257,1329,4160,1809]

theorem envBound46247 : H12AffineFastState.Bounded env46247 := by
  intro p hp
  have h : env46247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46246_46247 : H12AffineEnvironment.transform 21 1329 env46246 = env46247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1329 env46246 == env46247) = true)

theorem identity46247 : scanCanonicalize (H12AffineFastState.compose env46247 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46247 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env46248 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4112,372,34,4097,2048,272,373,4160,32,17,2,40,65,2420,4096,4097,2420,69,32,257,32,4160,512]

theorem envBound46248 : H12AffineFastState.Bounded env46248 := by
  intro p hp
  have h : env46248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46247_46248 : H12AffineEnvironment.transform 9 273 env46247 = env46248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46247 == env46248) = true)

theorem identity46248 : scanCanonicalize (H12AffineFastState.compose env46248 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46249 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,41,4112,292,34,4097,2048,272,293,4112,32,17,2,40,17,2340,4096,4097,2340,21,32,257,32,4112,512]

theorem envBound46249 : H12AffineFastState.Bounded env46249 := by
  intro p hp
  have h : env46249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46248_46249 : H12AffineEnvironment.transform 5 16 env46248 = env46249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46248 == env46249) = true)

theorem identity46249 : scanCanonicalize (H12AffineFastState.compose env46249 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46249 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46250 : List Nat := [2,4,8,16,1,16,9,256,512,273,2048,4096,8,4112,261,3,4097,2048,272,260,4112,1,17,2,9,17,2309,4096,4097,2309,21,1,257,1,4112,512]

theorem envBound46250 : H12AffineFastState.Bounded env46250 := by
  intro p hp
  have h : env46250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46249_46250 : H12AffineEnvironment.transform 4 1 env46249 = env46250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46249 == env46250) = true)

theorem identity46250 : scanCanonicalize (H12AffineFastState.compose env46250 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46250 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46251 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,4096,8,4112,1,3,4097,2048,20,0,4112,1,17,2,9,17,2049,4096,4097,2049,21,1,5,1,4112,512]

theorem envBound46251 : H12AffineFastState.Bounded env46251 := by
  intro p hp
  have h : env46251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46250_46251 : H12AffineEnvironment.transform 7 4 env46250 = env46251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46250 == env46251) = true)

theorem identity46251 : scanCanonicalize (H12AffineFastState.compose env46251 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound46251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46252 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,1,3,16,2048,20,0,1,1,17,2,9,17,2049,17,16,2049,21,1,5,1,1,512]

theorem envBound46252 : H12AffineFastState.Bounded env46252 := by
  intro p hp
  have h : env46252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46251_46252 : H12AffineEnvironment.transform 11 17 env46251 = env46252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env46251 == env46252) = true)

theorem identity46252 : scanCanonicalize (H12AffineFastState.compose env46252 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound46252 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46253 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,17,8,1,1,3,16,543,20,0,1,1,17,2,9,17,542,17,16,542,21,1,5,1,1,512]

theorem envBound46253 : H12AffineFastState.Bounded env46253 := by
  intro p hp
  have h : env46253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46252_46253 : H12AffineEnvironment.transform 10 543 env46252 = env46253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env46252 == env46253) = true)

theorem identity46253 : scanCanonicalize (H12AffineFastState.compose env46253 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46253 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46254 : List Nat := [2,4,8,16,1,16,9,4,1,21,30,17,8,1,1,3,16,30,20,0,1,1,17,2,9,17,31,17,16,31,21,1,5,1,1,1]

theorem envBound46254 : H12AffineFastState.Bounded env46254 := by
  intro p hp
  have h : env46254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46253_46254 : H12AffineEnvironment.transform 8 1 env46253 = env46254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46253 == env46254) = true)

theorem identity46254 : scanCanonicalize (H12AffineFastState.compose env46254 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46254 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46255 : List Nat := [2,4,8,1,1,1,9,4,1,4,15,0,8,1,1,3,1,15,5,0,1,1,0,2,9,0,14,0,1,14,4,1,5,1,1,1]

theorem envBound46255 : H12AffineFastState.Bounded env46255 := by
  intro p hp
  have h : env46255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46254_46255 : H12AffineEnvironment.transform 3 1 env46254 = env46255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46254 == env46255) = true)

def env46256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,8388608,98780,8328,65,12729589,79130,8480027,8568105,8390093,4314199,257,8484155,8492191,8462875]

theorem envBound46256 : H12AffineFastState.Bounded env46256 := by
  intro p hp
  have h : env46256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46218_46256 : H12AffineEnvironment.transform 17 32041 env46218 = env46256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env46218 == env46256) = true)

def env46257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,16,98780,8328,65,4340965,79130,91403,179513,1501,4314199,257,95531,103567,74251]

theorem envBound46257 : H12AffineFastState.Bounded env46257 := by
  intro p hp
  have h : env46257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46256_46257 : H12AffineEnvironment.transform 22 16 env46256 = env46257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46256 == env46257) = true)

theorem identity46257 : scanCanonicalize (H12AffineFastState.compose env46257 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21929) := by decide +kernel

theorem selectedBound46257 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,21929,16,98780,8328,65,158028,79130,91403,179513,1501,98814,257,95531,103567,74251]

theorem envBound46258 : H12AffineFastState.Bounded env46258 := by
  intro p hp
  have h : env46258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46257_46258 : H12AffineEnvironment.transform 21 21929 env46257 = env46258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21929 env46257 == env46258) = true)

theorem identity46258 : scanCanonicalize (H12AffineFastState.compose env46258 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46258 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4160,21929,16,41430,8328,65,158028,5392,17665,179513,1501,41460,257,21793,46213,513]

theorem envBound46259 : H12AffineFastState.Bounded env46259 := by
  intro p hp
  have h : env46259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46258_46259 : H12AffineEnvironment.transform 15 8202 env46258 = env46259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46258 == env46259) = true)

theorem identity46259 : scanCanonicalize (H12AffineFastState.compose env46259 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound46259 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env46260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,32041,1025,32769,4160,21929,16,41430,8328,65,10589,5392,17665,64808,1501,41460,257,21793,46213,513]

theorem envBound46260 : H12AffineFastState.Bounded env46260 := by
  intro p hp
  have h : env46260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46259_46260 : H12AffineEnvironment.transform 16 16401 env46259 = env46260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46259 == env46260) = true)

def env46261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98780,8328,65,4340964,79130,91402,179512,1500,4314199,257,95530,103566,74250]

theorem envBound46261 : H12AffineFastState.Bounded env46261 := by
  intro p hp
  have h : env46261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46256_46261 : H12AffineEnvironment.transform 22 17 env46256 = env46261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46256 == env46261) = true)

def env46262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98644,8192,65,4340844,79130,91402,179512,1364,4314199,257,95530,103430,74250]

theorem envBound46262 : H12AffineFastState.Bounded env46262 := by
  intro p hp
  have h : env46262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46261_46262 : H12AffineEnvironment.transform 6 8 env46261 = env46262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46261 == env46262) = true)

theorem identity46262 : scanCanonicalize (H12AffineFastState.compose env46262 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46262 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32041,1025,32769,4161,4194304,17,41311,8192,65,4340844,5393,17665,179512,1364,4256860,257,21793,46093,513]

theorem envBound46263 : H12AffineFastState.Bounded env46263 := by
  intro p hp
  have h : env46263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46262_46263 : H12AffineEnvironment.transform 15 8203 env46262 = env46263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46262 == env46263) = true)

theorem identity46263 : scanCanonicalize (H12AffineFastState.compose env46263 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound46263 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env46264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,4194304,17,21763,8192,65,4340844,5393,17665,149860,1364,4194304,257,21793,16465,513]

theorem envBound46264 : H12AffineFastState.Bounded env46264 := by
  intro p hp
  have h : env46264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46263_46264 : H12AffineEnvironment.transform 14 29788 env46263 = env46264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env46263 == env46264) = true)

theorem identity46264 : scanCanonicalize (H12AffineFastState.compose env46264 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound46264 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env46265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4161,21873,17,21763,8192,65,157981,5393,17665,149860,1364,21873,257,21793,16465,513]

theorem envBound46265 : H12AffineFastState.Bounded env46265 := by
  intro p hp
  have h : env46265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46264_46265 : H12AffineEnvironment.transform 21 21873 env46264 = env46265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env46264 == env46265) = true)

theorem identity46265 : scanCanonicalize (H12AffineFastState.compose env46265 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46265 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env46266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8203,131072,10361,1025,8461,4161,33,17,83,8192,65,146509,5393,4177,138292,1364,33,257,113,5377,513]

theorem envBound46266 : H12AffineFastState.Bounded env46266 := by
  intro p hp
  have h : env46266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46265_46266 : H12AffineEnvironment.transform 13 5456 env46265 = env46266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46265 == env46266) = true)

theorem identity46266 : scanCanonicalize (H12AffineFastState.compose env46266 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound46266 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env46267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,8203,13389,10361,1025,8461,4161,33,17,83,8192,65,2048,5393,4177,10361,1364,33,257,113,5377,513]

theorem envBound46267 : H12AffineFastState.Bounded env46267 := by
  intro p hp
  have h : env46267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46266_46267 : H12AffineEnvironment.transform 16 13389 env46266 = env46267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env46266 == env46267) = true)

theorem identity46267 : scanCanonicalize (H12AffineFastState.compose env46267 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46267 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46268 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10280,1025,8461,4112,33,17,2,8192,16,2048,5393,4096,10280,1285,33,257,32,5377,513]

theorem envBound46268 : H12AffineFastState.Bounded env46268 := by
  intro p hp
  have h : env46268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46267_46268 : H12AffineEnvironment.transform 5 17 env46267 = env46268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46267 == env46268) = true)

theorem identity46268 : scanCanonicalize (H12AffineFastState.compose env46268 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46268 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46269 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5393,2341,1025,0,4112,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5377,513]

theorem envBound46269 : H12AffineFastState.Bounded env46269 := by
  intro p hp
  have h : env46269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46268_46269 : H12AffineEnvironment.transform 12 269 env46268 = env46269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46268 == env46269) = true)

theorem identity46269 : scanCanonicalize (H12AffineFastState.compose env46269 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46270 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4112,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound46270 : H12AffineFastState.Bounded env46270 := by
  intro p hp
  have h : env46270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46269_46270 : H12AffineEnvironment.transform 7 37 env46269 = env46270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46269 == env46270) = true)

def env46271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,77898,4194304,17,98645,8193,65,4340845,79130,91402,179512,1365,4314199,257,95530,103431,74250]

theorem envBound46271 : H12AffineFastState.Bounded env46271 := by
  intro p hp
  have h : env46271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46261_46271 : H12AffineEnvironment.transform 6 9 env46261 = env46271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46261 == env46271) = true)

theorem identity46271 : scanCanonicalize (H12AffineFastState.compose env46271 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46271 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32041,1025,8540,77898,4194304,17,73736,8193,65,4340845,79130,91402,138341,1365,4289802,257,95530,79194,74250]

theorem envBound46272 : H12AffineFastState.Bounded env46272 := by
  intro p hp
  have h : env46272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46271_46272 : H12AffineEnvironment.transform 14 8541 env46271 = env46272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46271 == env46272) = true)

theorem identity46272 : scanCanonicalize (H12AffineFastState.compose env46272 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound46272 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32041,1025,8540,77898,136497,17,73736,8193,65,10588,79130,91402,138341,1365,221243,257,95530,79194,74250]

theorem envBound46273 : H12AffineFastState.Bounded env46273 := by
  intro p hp
  have h : env46273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46272_46273 : H12AffineEnvironment.transform 21 136497 env46272 = env46273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env46272 == env46273) = true)

def env46274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,32041,1025,8540,77898,21793,17,73736,8193,65,10588,79130,91402,23669,1365,73771,257,95530,79194,74250]

theorem envBound46274 : H12AffineFastState.Bounded env46274 := by
  intro p hp
  have h : env46274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46273_46274 : H12AffineEnvironment.transform 16 16400 env46273 = env46274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46273 == env46274) = true)

theorem identity46274 : scanCanonicalize (H12AffineFastState.compose env46274 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound46274 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,34,16400,32041,1025,8540,12392,21793,17,8234,8193,65,10588,13624,25896,23669,1365,8201,257,29960,13688,8744]

theorem envBound46275 : H12AffineFastState.Bounded env46275 := by
  intro p hp
  have h : env46275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46274_46275 : H12AffineEnvironment.transform 15 34 env46274 = env46275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env46274 == env46275) = true)

theorem identity46275 : scanCanonicalize (H12AffineFastState.compose env46275 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound46275 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,34,5220,10589,1025,8540,12392,341,17,8234,8193,65,10588,13624,12636,2049,1365,8201,257,8572,13688,8744]

theorem envBound46276 : H12AffineFastState.Bounded env46276 := by
  intro p hp
  have h : env46276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46275_46276 : H12AffineEnvironment.transform 13 5236 env46275 = env46276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env46275 == env46276) = true)

theorem identity46276 : scanCanonicalize (H12AffineFastState.compose env46276 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46276 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env46277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5236,372,34,5220,2420,1025,373,4161,341,17,3,40,65,2421,5393,4469,2049,1365,32,257,341,5457,513]

theorem envBound46277 : H12AffineFastState.Bounded env46277 := by
  intro p hp
  have h : env46277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46276_46277 : H12AffineEnvironment.transform 12 41 env46276 = env46277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46276 == env46277) = true)

theorem identity46277 : scanCanonicalize (H12AffineFastState.compose env46277 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46277 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46278 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,5236,80,34,5220,2128,1025,81,4161,113,17,3,40,65,2129,5173,4177,2049,1137,32,37,113,5237,513]

theorem envBound46278 : H12AffineFastState.Bounded env46278 := by
  intro p hp
  have h : env46278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46277_46278 : H12AffineEnvironment.transform 7 36 env46277 = env46278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46277 == env46278) = true)

theorem identity46278 : scanCanonicalize (H12AffineFastState.compose env46278 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46279 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,41,4112,80,34,4096,2128,101,81,4161,113,17,3,40,65,2129,4177,4177,2049,21,32,37,113,4113,513]

theorem envBound46279 : H12AffineFastState.Bounded env46279 := by
  intro p hp
  have h : env46279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46278_46279 : H12AffineEnvironment.transform 9 100 env46278 = env46279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46278 == env46279) = true)

def env46280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,32041,1025,8540,77898,21792,17,73736,8193,65,10588,79130,91402,23668,1365,73770,257,95530,79194,74250]

theorem envBound46280 : H12AffineFastState.Bounded env46280 := by
  intro p hp
  have h : env46280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46273_46280 : H12AffineEnvironment.transform 16 16401 env46273 = env46280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46273 == env46280) = true)

theorem identity46280 : scanCanonicalize (H12AffineFastState.compose env46280 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 374) := by decide +kernel

theorem selectedBound46280 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,374,16401,32041,1025,8540,12604,21792,17,8574,8193,65,10588,13420,25724,23668,1365,8540,257,29788,13356,9084]

theorem envBound46281 : H12AffineFastState.Bounded env46281 := by
  intro p hp
  have h : env46281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46280_46281 : H12AffineEnvironment.transform 15 374 env46280 = env46281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 374 env46280 == env46281) = true)

def env46282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound46282 : H12AffineFastState.Bounded env46282 := by
  intro p hp
  have h : env46282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44620_46282 : H12AffineEnvironment.transform 29 155254785 env44620 = env46282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env44620 == env46282) = true)

def env46283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound46283 : H12AffineFastState.Bounded env46283 := by
  intro p hp
  have h : env46283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46282_46283 : H12AffineEnvironment.transform 25 64 env46282 = env46283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env46282 == env46283) = true)

def env46284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound46284 : H12AffineFastState.Bounded env46284 := by
  intro p hp
  have h : env46284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46283_46284 : H12AffineEnvironment.transform 26 30393344 env46283 = env46284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env46283 == env46284) = true)

def env46285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound46285 : H12AffineFastState.Bounded env46285 := by
  intro p hp
  have h : env46285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46284_46285 : H12AffineEnvironment.transform 18 1024 env46284 = env46285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46284 == env46285) = true)

theorem identity46285 : scanCanonicalize (H12AffineFastState.compose env46285 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388626) := by decide +kernel

theorem selectedBound46285 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388626,8328,64,4702226,10585247,10507600,8830977,99330,14771666,256,2213055,2172187,41940]

theorem envBound46286 : H12AffineFastState.Bounded env46286 := by
  intro p hp
  have h : env46286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46285_46286 : H12AffineEnvironment.transform 23 8388626 env46285 = env46286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388626 env46285 == env46286) = true)

def env46287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147610,8328,64,4702226,2343959,2233816,295049,99330,6497626,256,2213055,2172187,41940]

theorem envBound46287 : H12AffineFastState.Bounded env46287 := by
  intro p hp
  have h : env46287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46286_46287 : H12AffineEnvironment.transform 22 147592 env46286 = env46287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env46286 == env46287) = true)

def env46288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147610,8328,64,4450482,2343959,2233816,43049,99330,6497626,256,2213055,2172187,41940]

theorem envBound46288 : H12AffineFastState.Bounded env46288 := by
  intro p hp
  have h : env46288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46287_46288 : H12AffineEnvironment.transform 17 10400 env46287 = env46288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46287 == env46288) = true)

theorem identity46288 : scanCanonicalize (H12AffineFastState.compose env46288 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound46288 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4303010,2196487,2119112,43049,99330,6382922,256,2213055,2172187,41940]

theorem envBound46289 : H12AffineFastState.Bounded env46289 := by
  intro p hp
  have h : env46289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46288_46289 : H12AffineEnvironment.transform 16 16400 env46288 = env46289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env46288 == env46289) = true)

theorem identity46289 : scanCanonicalize (H12AffineFastState.compose env46289 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound46289 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env46290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16400,10400,1024,32769,2097152,4194304,152,138,8328,64,4204925,2098648,2119112,43049,1501,6349973,256,2114912,2139332,41940]

theorem envBound46290 : H12AffineFastState.Bounded env46290 := by
  intro p hp
  have h : env46290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46289_46290 : H12AffineEnvironment.transform 15 33247 env46289 = env46290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env46289 == env46290) = true)

theorem identity46290 : scanCanonicalize (H12AffineFastState.compose env46290 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound46290 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16400,10400,1024,32769,2097152,32,152,138,8328,64,10589,2098648,2119112,43049,1501,2155701,256,2114912,2139332,41940]

theorem envBound46291 : H12AffineFastState.Bounded env46291 := by
  intro p hp
  have h : env46291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46290_46291 : H12AffineEnvironment.transform 21 32 env46290 = env46291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env46290 == env46291) = true)

theorem identity46291 : scanCanonicalize (H12AffineFastState.compose env46291 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50584) := by decide +kernel

theorem selectedBound46291 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env46292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16400,10400,1024,32769,50584,32,152,138,8328,64,10589,49216,36944,43049,1501,8493,256,33016,24924,41940]

theorem envBound46292 : H12AffineFastState.Bounded env46292 := by
  intro p hp
  have h : env46292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46291_46292 : H12AffineEnvironment.transform 20 50584 env46291 = env46292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50584 env46291 == env46292) = true)

theorem identity46292 : scanCanonicalize (H12AffineFastState.compose env46292 (packedSelected [0,1,2,3,5,7,8,11,17,18,21] rootPS)) = affineNative (2^(14+1) ^^^ 20664) := by decide +kernel

theorem selectedBound46292 : packedSelected [0,1,2,3,5,7,8,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env46293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20664,20839,16400,10400,1024,20665,5408,32,152,138,8328,64,10589,4344,16616,30865,1501,8493,256,20544,24924,29548]

theorem envBound46293 : H12AffineFastState.Bounded env46293 := by
  intro p hp
  have h : env46293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46292_46293 : H12AffineEnvironment.transform 14 20664 env46292 = env46293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20664 env46292 == env46293) = true)

theorem identity46293 : scanCanonicalize (H12AffineFastState.compose env46293 (packedSelected [0,1,3,4,5,7,8,9,11,12,15,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46293 : packedSelected [0,1,3,4,5,7,8,9,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env46294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,20664,20839,16400,2477,1024,20665,5408,32,152,138,389,64,2128,4344,16616,22940,1501,32,256,20544,16465,21089]

theorem envBound46294 : H12AffineFastState.Bounded env46294 := by
  intro p hp
  have h : env46294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46293_46294 : H12AffineEnvironment.transform 12 269 env46293 = env46294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46293 == env46294) = true)

theorem identity46294 : scanCanonicalize (H12AffineFastState.compose env46294 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound46294 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,4249,33,510,4233,2477,1024,32,5408,32,152,138,389,64,2128,4344,4209,2309,1501,32,256,217,4296,760]

theorem envBound46295 : H12AffineFastState.Bounded env46295 := by
  intro p hp
  have h : env46295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46294_46295 : H12AffineEnvironment.transform 13 4249 env46294 = env46295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env46294 == env46295) = true)

theorem identity46295 : scanCanonicalize (H12AffineFastState.compose env46295 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound46295 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env46296 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,269,4249,33,398,4233,2477,1024,32,5408,32,152,138,389,48,2080,4232,4097,2309,1453,32,256,169,4280,648]

theorem envBound46296 : H12AffineFastState.Bounded env46296 := by
  intro p hp
  have h : env46296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46295_46296 : H12AffineEnvironment.transform 5 48 env46295 = env46296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env46295 == env46296) = true)

theorem identity46296 : scanCanonicalize (H12AffineFastState.compose env46296 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46296 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46297 : List Nat := [2,4,8,16,32,48,128,256,512,273,2048,4096,269,4249,33,398,4233,2477,273,32,4145,32,152,138,389,48,2080,4232,4097,2309,188,32,256,169,4280,648]

theorem envBound46297 : H12AffineFastState.Bounded env46297 := by
  intro p hp
  have h : env46297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46296_46297 : H12AffineEnvironment.transform 9 273 env46296 = env46297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46296 == env46297) = true)

theorem identity46297 : scanCanonicalize (H12AffineFastState.compose env46297 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46297 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46298 : List Nat := [2,4,8,16,32,48,128,4,512,21,2048,4096,9,4249,33,138,4233,2217,21,32,4145,32,152,138,129,48,2080,4232,4097,2049,188,32,4,169,4280,648]

theorem envBound46298 : H12AffineFastState.Bounded env46298 := by
  intro p hp
  have h : env46298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46297_46298 : H12AffineEnvironment.transform 7 4 env46297 = env46298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46297 == env46298) = true)

theorem identity46298 : scanCanonicalize (H12AffineFastState.compose env46298 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46298 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env46299 : List Nat := [2,4,8,16,32,48,8,4,512,21,2048,4096,9,4113,33,2,4097,2081,21,32,4145,32,16,2,9,48,2080,4096,4097,2049,52,32,4,33,4144,512]

theorem envBound46299 : H12AffineFastState.Bounded env46299 := by
  intro p hp
  have h : env46299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46298_46299 : H12AffineEnvironment.transform 6 8 env46298 = env46299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46298 == env46299) = true)

theorem identity46299 : scanCanonicalize (H12AffineFastState.compose env46299 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46300 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,9,4113,1,2,4097,2049,21,0,4113,0,16,2,9,16,2048,4096,4097,2049,20,0,4,1,4112,512]

theorem envBound46300 : H12AffineFastState.Bounded env46300 := by
  intro p hp
  have h : env46300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46299_46300 : H12AffineEnvironment.transform 4 0 env46299 = env46300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46299 == env46300) = true)

theorem identity46300 : scanCanonicalize (H12AffineFastState.compose env46300 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46301 : List Nat := [2,4,8,16,0,16,8,4,1,21,2048,4096,9,4113,1,2,4097,2049,21,0,4113,0,16,2,9,16,2048,4096,4097,2049,20,0,4,1,4112,1]

theorem envBound46301 : H12AffineFastState.Bounded env46301 := by
  intro p hp
  have h : env46301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46300_46301 : H12AffineEnvironment.transform 8 1 env46300 = env46301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46300 == env46301) = true)

theorem identity46301 : scanCanonicalize (H12AffineFastState.compose env46301 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound46301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46302 : List Nat := [2,4,8,16,0,16,8,4,1,21,31,4096,9,4113,1,2,4097,30,21,0,4113,0,16,2,9,16,31,4096,4097,30,20,0,4,1,4112,1]

theorem envBound46302 : H12AffineFastState.Bounded env46302 := by
  intro p hp
  have h : env46302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46301_46302 : H12AffineEnvironment.transform 10 31 env46301 = env46302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env46301 == env46302) = true)

theorem identity46302 : scanCanonicalize (H12AffineFastState.compose env46302 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound46302 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46303 : List Nat := [2,4,8,16,0,16,8,4,1,21,31,15,9,30,1,2,14,30,21,0,30,0,16,2,9,16,31,15,14,30,20,0,4,1,31,1]

theorem envBound46303 : H12AffineFastState.Bounded env46303 := by
  intro p hp
  have h : env46303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46302_46303 : H12AffineEnvironment.transform 11 15 env46302 = env46303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env46302 == env46303) = true)

def leafEnv46303 : List Nat := [2,4,8,16,0,16,8,4,1,21,31,15,9,30,1,2,14,30,21,0,30,0,16,2,20,9,1,16,31,15,14,30,20,0,4,1,4,2,31,1,1,31,0]

def active46303 : List Nat := [0,1,2,3]

def tree46303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46303 : H12WitnessSearch.Good tree46303 := H12GlobalWitnessIndex.good

theorem leafIdentity46303 : H12AffineFastState.composeSystem env46303 rootObs = leafEnv46303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46303 rootObs == leafEnv46303) = true)

theorem terminalChecked46303 : H12PackedTerminal.terminalCheckFast leafEnv46303 active46303 tree46303 = true := by decide +kernel

def env46304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147610,8328,64,4450483,2343959,2233816,43048,99330,6497626,256,2213055,2172187,41940]

theorem envBound46304 : H12AffineFastState.Bounded env46304 := by
  intro p hp
  have h : env46304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46287_46304 : H12AffineEnvironment.transform 17 10401 env46287 = env46304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46287 == env46304) = true)

theorem identity46304 : scanCanonicalize (H12AffineFastState.compose env46304 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46304 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147456,147474,8192,64,4450363,2343959,2233680,43048,99330,6497626,256,2212919,2172187,41820]

theorem envBound46305 : H12AffineFastState.Bounded env46305 := by
  intro p hp
  have h : env46305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46304_46305 : H12AffineEnvironment.transform 6 8 env46304 = env46305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46304 == env46305) = true)

theorem identity46305 : scanCanonicalize (H12AffineFastState.compose env46305 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46305 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env46306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147474,8192,64,4409702,2319690,2233680,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound46306 : H12AffineFastState.Bounded env46306 := by
  intro p hp
  have h : env46306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46305_46306 : H12AffineEnvironment.transform 14 8541 env46305 = env46306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46305 == env46306) = true)

theorem identity46306 : scanCanonicalize (H12AffineFastState.compose env46306 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound46306 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env46307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,131072,10281,1024,8540,2097152,4194304,147456,147474,8192,64,4343857,2253853,2233680,2421,9224,6431757,256,2122813,2106444,513]

theorem envBound46307 : H12AffineFastState.Bounded env46307 := by
  intro p hp
  have h : env46307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46306_46307 : H12AffineEnvironment.transform 15 343 env46306 = env46307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env46306 == env46307) = true)

theorem identity46307 : scanCanonicalize (H12AffineFastState.compose env46307 (packedSelected [1,4,8,9,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound46307 : packedSelected [1,4,8,9,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env46308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,131072,10281,1024,8540,25629,4194304,147456,147474,8192,64,4343857,131072,160077,2421,9224,4341776,256,32,16465,513]

theorem envBound46308 : H12AffineFastState.Bounded env46308 := by
  intro p hp
  have h : env46308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46307_46308 : H12AffineEnvironment.transform 20 25629 env46307 = env46308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env46307 == env46308) = true)

theorem identity46308 : scanCanonicalize (H12AffineFastState.compose env46308 (packedSelected [1,3,5,8,11,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound46308 : packedSelected [1,3,5,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env46309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,131072,10281,1024,8540,25629,8493,147456,147474,8192,64,157980,131072,160077,2421,9224,155965,256,32,16465,513]

theorem envBound46309 : H12AffineFastState.Bounded env46309 := by
  intro p hp
  have h : env46309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46308_46309 : H12AffineEnvironment.transform 21 8493 env46308 = env46309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env46308 == env46309) = true)

theorem identity46309 : scanCanonicalize (H12AffineFastState.compose env46309 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46309 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env46310 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,131072,10281,1024,8460,25629,8493,147456,147474,8192,16,157980,131072,160029,2341,9224,155965,256,32,16385,513]

theorem envBound46310 : H12AffineFastState.Bounded env46310 := by
  intro p hp
  have h : env46310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46309_46310 : H12AffineEnvironment.transform 5 16 env46309 = env46310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46309 == env46310) = true)

theorem identity46310 : scanCanonicalize (H12AffineFastState.compose env46310 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46310 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46311 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,263,131072,2340,1024,1,17680,32,147456,147474,269,16,149521,131072,151568,2341,1285,147504,256,32,16385,513]

theorem envBound46311 : H12AffineFastState.Bounded env46311 := by
  intro p hp
  have h : env46311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46310_46311 : H12AffineEnvironment.transform 12 269 env46310 = env46311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46310 == env46311) = true)

theorem identity46311 : scanCanonicalize (H12AffineFastState.compose env46311 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(16+1) ^^^ 3109) := by decide +kernel

theorem selectedBound46311 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env46312 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,263,3109,2340,1024,1,17680,32,19493,19511,269,16,17460,3109,23605,2341,1285,19477,256,32,16385,513]

theorem envBound46312 : H12AffineFastState.Bounded env46312 := by
  intro p hp
  have h : env46312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46311_46312 : H12AffineEnvironment.transform 16 3109 env46311 = env46312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3109 env46311 == env46312) = true)

theorem identity46312 : scanCanonicalize (H12AffineFastState.compose env46312 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46312 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46313 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,16384,0,263,2065,2340,52,1,16676,32,18449,18435,269,16,16384,2065,22529,2341,305,18465,256,32,16385,513]

theorem envBound46313 : H12AffineFastState.Bounded env46313 := by
  intro p hp
  have h : env46313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46312_46313 : H12AffineEnvironment.transform 9 52 env46312 = env46313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46312 == env46313) = true)

theorem identity46313 : scanCanonicalize (H12AffineFastState.compose env46313 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound46313 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env46314 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,2048,0,263,2065,2340,52,1,2340,32,17,3,269,16,2048,2065,4097,2341,305,33,256,32,2049,513]

theorem envBound46314 : H12AffineFastState.Bounded env46314 := by
  intro p hp
  have h : env46314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46313_46314 : H12AffineEnvironment.transform 13 2048 env46313 = env46314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env46313 == env46314) = true)

theorem identity46314 : scanCanonicalize (H12AffineFastState.compose env46314 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound46314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46315 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,4096,57,2048,0,51,2065,2064,52,1,2064,32,17,3,57,16,2048,2065,4097,2065,5,33,52,32,2049,513]

theorem envBound46315 : H12AffineFastState.Bounded env46315 := by
  intro p hp
  have h : env46315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46314_46315 : H12AffineEnvironment.transform 7 52 env46314 = env46315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env46314 == env46315) = true)

theorem identity46315 : scanCanonicalize (H12AffineFastState.compose env46315 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46315 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46316 : List Nat := [2,4,8,10,32,10,8,46,512,46,2048,4096,35,2048,0,41,2059,2058,46,1,2058,32,11,3,35,10,2048,2059,4097,2059,5,33,46,32,2049,513]

theorem envBound46316 : H12AffineFastState.Bounded env46316 := by
  intro p hp
  have h : env46316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46315_46316 : H12AffineEnvironment.transform 3 10 env46315 = env46316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46315 == env46316) = true)

theorem identity46316 : scanCanonicalize (H12AffineFastState.compose env46316 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound46316 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46317 : List Nat := [2,4,8,10,32,10,8,46,512,46,43,4096,35,43,0,41,32,33,46,1,33,32,11,3,35,10,43,32,4097,32,5,33,46,32,42,513]

theorem envBound46317 : H12AffineFastState.Bounded env46317 := by
  intro p hp
  have h : env46317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46316_46317 : H12AffineEnvironment.transform 10 43 env46316 = env46317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env46316 == env46317) = true)

theorem identity46317 : scanCanonicalize (H12AffineFastState.compose env46317 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound46317 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46318 : List Nat := [2,4,8,10,32,10,8,46,512,46,43,42,35,43,0,41,32,33,46,1,33,32,11,3,35,10,43,32,43,32,5,33,46,32,42,513]

theorem envBound46318 : H12AffineFastState.Bounded env46318 := by
  intro p hp
  have h : env46318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46317_46318 : H12AffineEnvironment.transform 11 42 env46317 = env46318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env46317 == env46318) = true)

theorem identity46318 : scanCanonicalize (H12AffineFastState.compose env46318 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46318 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46319 : List Nat := [2,4,4,6,32,6,4,34,512,34,39,38,35,39,0,37,32,33,34,1,33,32,7,3,35,6,39,32,39,32,5,33,34,32,38,513]

theorem envBound46319 : H12AffineFastState.Bounded env46319 := by
  intro p hp
  have h : env46319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46318_46319 : H12AffineEnvironment.transform 2 4 env46318 = env46319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46318 == env46319) = true)

def env46320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147611,8328,64,4702226,2343958,2233817,295048,99330,6497627,256,2213055,2172187,41940]

theorem envBound46320 : H12AffineFastState.Bounded env46320 := by
  intro p hp
  have h : env46320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46286_46320 : H12AffineEnvironment.transform 22 147593 env46286 = env46320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env46286 == env46320) = true)

def env46321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147611,8328,64,4450482,2343958,2233817,43048,99330,6497627,256,2213055,2172187,41940]

theorem envBound46321 : H12AffineFastState.Bounded env46321 := by
  intro p hp
  have h : env46321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46320_46321 : H12AffineEnvironment.transform 17 10400 env46320 = env46321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46320 == env46321) = true)

theorem identity46321 : scanCanonicalize (H12AffineFastState.compose env46321 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound46321 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10400,1024,32769,2097152,4194304,41293,41311,8328,64,4262262,2172370,2159645,43048,99330,6407327,256,2213055,2172187,41940]

theorem envBound46322 : H12AffineFastState.Bounded env46322 := by
  intro p hp
  have h : env46322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46321_46322 : H12AffineEnvironment.transform 16 57796 env46321 = env46322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env46321 == env46322) = true)

theorem identity46322 : scanCanonicalize (H12AffineFastState.compose env46322 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound46322 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env46323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,57796,10400,1024,32769,2097152,4194304,41293,41311,8328,64,4229288,2139148,2159645,43048,1500,6309185,256,2114913,2139333,41940]

theorem envBound46323 : H12AffineFastState.Bounded env46323 := by
  intro p hp
  have h : env46323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46322_46323 : H12AffineEnvironment.transform 15 33246 env46322 = env46323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env46322 == env46323) = true)

theorem identity46323 : scanCanonicalize (H12AffineFastState.compose env46323 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41461) := by decide +kernel

theorem selectedBound46323 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,57796,10400,1024,32769,2097152,41461,41293,41311,8328,64,10589,2139148,2159645,43048,1500,2155700,256,2114913,2139333,41940]

theorem envBound46324 : H12AffineFastState.Bounded env46324 := by
  intro p hp
  have h : env46324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46323_46324 : H12AffineEnvironment.transform 21 41461 env46323 = env46324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41461 env46323 == env46324) = true)

theorem identity46324 : scanCanonicalize (H12AffineFastState.compose env46324 (packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound46324 : packedSelected [1,2,3,5,8,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env46325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,8694,16876,10400,1024,8233,2097152,477,357,375,8328,64,10589,2098212,2118709,2048,1500,2114716,256,2114913,2098413,1020]

theorem envBound46325 : H12AffineFastState.Bounded env46325 := by
  intro p hp
  have h : env46325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46324_46325 : H12AffineEnvironment.transform 14 8232 env46324 = env46325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env46324 == env46325) = true)

theorem identity46325 : scanCanonicalize (H12AffineFastState.compose env46325 (packedSelected [1,3,4,7,9,17,21,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound46325 : packedSelected [1,3,4,7,9,17,21,24,27,28] rootPS < 2^1333 := by decide +kernel

def env46326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,8694,16876,10400,1024,8233,25676,477,357,375,8328,64,10589,24680,12409,2048,1500,8400,256,8493,24737,1020]

theorem envBound46326 : H12AffineFastState.Bounded env46326 := by
  intro p hp
  have h : env46326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46325_46326 : H12AffineEnvironment.transform 20 25676 env46325 = env46326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env46325 == env46326) = true)

theorem identity46326 : scanCanonicalize (H12AffineFastState.compose env46326 (packedSelected [1,2,8,10,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound46326 : packedSelected [1,2,8,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env46327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8232,8694,13625,10400,1024,8233,4249,477,357,375,8328,64,10589,5309,12409,2048,1500,8400,256,8493,5236,1020]

theorem envBound46327 : H12AffineFastState.Bounded env46327 := by
  intro p hp
  have h : env46327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46326_46327 : H12AffineEnvironment.transform 13 13525 env46326 = env46327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env46326 == env46327) = true)

theorem identity46327 : scanCanonicalize (H12AffineFastState.compose env46327 (packedSelected [1,3,5,8,12,14,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46327 : packedSelected [1,3,5,8,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env46328 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13525,8232,8323,13388,10400,1024,8233,4249,168,16,2,8328,64,10280,5309,12409,2048,1193,8400,117,8280,5236,649]

theorem envBound46328 : H12AffineFastState.Bounded env46328 := by
  intro p hp
  have h : env46328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46327_46328 : H12AffineEnvironment.transform 7 117 env46327 = env46328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46327 == env46328) = true)

theorem identity46328 : scanCanonicalize (H12AffineFastState.compose env46328 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound46328 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46329 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,241,5156,217,114,5309,2129,1024,216,4249,168,16,2,121,64,2265,5309,4232,2048,1193,33,117,169,5236,649]

theorem envBound46329 : H12AffineFastState.Bounded env46329 := by
  intro p hp
  have h : env46329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46328_46329 : H12AffineEnvironment.transform 12 241 env46328 = env46329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env46328 == env46329) = true)

theorem identity46329 : scanCanonicalize (H12AffineFastState.compose env46329 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound46329 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env46330 : List Nat := [2,4,8,16,32,64,128,117,512,1024,81,4096,241,5156,217,114,5309,0,1024,216,4249,168,16,2,121,64,136,5309,4232,81,1193,33,117,169,5236,649]

theorem envBound46330 : H12AffineFastState.Bounded env46330 := by
  intro p hp
  have h : env46330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46329_46330 : H12AffineEnvironment.transform 10 81 env46329 = env46330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env46329 == env46330) = true)

theorem identity46330 : scanCanonicalize (H12AffineFastState.compose env46330 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46330 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46331 : List Nat := [2,4,8,16,32,64,88,117,512,1024,81,4096,41,5156,1,114,5221,0,1024,0,4161,112,16,2,121,64,80,5221,4176,81,1137,33,117,113,5236,593]

theorem envBound46331 : H12AffineFastState.Bounded env46331 := by
  intro p hp
  have h : env46331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46330_46331 : H12AffineEnvironment.transform 6 88 env46330 = env46331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46330 == env46331) = true)

theorem identity46331 : scanCanonicalize (H12AffineFastState.compose env46331 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound46331 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46332 : List Nat := [2,4,8,16,32,64,88,117,512,1024,81,17,41,1077,1,114,1140,0,1024,0,80,112,16,2,121,64,80,1140,65,81,1137,33,117,113,1125,593]

theorem envBound46332 : H12AffineFastState.Bounded env46332 := by
  intro p hp
  have h : env46332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46331_46332 : H12AffineEnvironment.transform 11 17 env46331 = env46332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env46331 == env46332) = true)

theorem identity46332 : scanCanonicalize (H12AffineFastState.compose env46332 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46332 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46333 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1,17,41,1077,1,34,1060,0,1024,0,0,32,16,2,41,16,0,1060,17,1,1057,33,37,33,1077,513]

theorem envBound46333 : H12AffineFastState.Bounded env46333 := by
  intro p hp
  have h : env46333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46332_46333 : H12AffineEnvironment.transform 5 16 env46332 = env46333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46332 == env46333) = true)

def env46334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147611,8328,64,4450483,2343958,2233817,43049,99330,6497627,256,2213055,2172187,41940]

theorem envBound46334 : H12AffineFastState.Bounded env46334 := by
  intro p hp
  have h : env46334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46320_46334 : H12AffineEnvironment.transform 17 10401 env46320 = env46334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46320 == env46334) = true)

theorem identity46334 : scanCanonicalize (H12AffineFastState.compose env46334 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46334 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147593,147611,8328,64,4409838,2319691,2233817,2420,75103,6497627,256,2188770,2172187,649]

theorem envBound46335 : H12AffineFastState.Bounded env46335 := by
  intro p hp
  have h : env46335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46334_46335 : H12AffineEnvironment.transform 14 8541 env46334 = env46335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46334 == env46335) = true)

theorem identity46335 : scanCanonicalize (H12AffineFastState.compose env46335 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46335 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env46336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,147475,8192,64,4409702,2319691,2233681,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound46336 : H12AffineFastState.Bounded env46336 := by
  intro p hp
  have h : env46336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46335_46336 : H12AffineEnvironment.transform 6 8 env46335 = env46336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46335 == env46336) = true)

theorem identity46336 : scanCanonicalize (H12AffineFastState.compose env46336 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound46336 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env46337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,91466,4194304,147457,147475,8192,64,4409702,131073,225307,2420,75103,4341777,256,32,16465,513]

theorem envBound46337 : H12AffineFastState.Bounded env46337 := by
  intro p hp
  have h : env46337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46336_46337 : H12AffineEnvironment.transform 20 91466 env46336 = env46337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env46336 == env46337) = true)

theorem identity46337 : scanCanonicalize (H12AffineFastState.compose env46337 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound46337 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,91466,4194304,16,2,8192,64,4262263,16400,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound46338 : H12AffineFastState.Bounded env46338 := by
  intro p hp
  have h : env46338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46337_46338 : H12AffineEnvironment.transform 16 16401 env46337 = env46338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env46337 == env46338) = true)

theorem identity46338 : scanCanonicalize (H12AffineFastState.compose env46338 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound46338 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,91466,73770,16,2,8192,64,10589,16400,77834,2420,75103,73770,256,32,16465,513]

theorem envBound46339 : H12AffineFastState.Bounded env46339 := by
  intro p hp
  have h : env46339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46338_46339 : H12AffineEnvironment.transform 21 73770 env46338 = env46339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env46338 == env46339) = true)

theorem identity46339 : scanCanonicalize (H12AffineFastState.compose env46339 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound46339 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8282,16401,10281,1024,8540,17680,112,16,2,8192,64,10589,16400,4176,2420,1285,112,256,32,16465,513]

theorem envBound46340 : H12AffineFastState.Bounded env46340 := by
  intro p hp
  have h : env46340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46339_46340 : H12AffineEnvironment.transform 15 8282 env46339 = env46340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env46339 == env46340) = true)

theorem identity46340 : scanCanonicalize (H12AffineFastState.compose env46340 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46340 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,263,16401,2420,1024,1,17680,112,16,2,349,64,2048,16400,4176,2420,1285,112,256,32,16465,513]

theorem envBound46341 : H12AffineFastState.Bounded env46341 := by
  intro p hp
  have h : env46341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46340_46341 : H12AffineEnvironment.transform 12 349 env46340 = env46341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46340 == env46341) = true)

theorem identity46341 : scanCanonicalize (H12AffineFastState.compose env46341 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound46341 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5156,0,263,5173,2420,1024,1,4404,112,16,2,349,64,2048,5172,4176,2420,1285,112,256,32,5237,513]

theorem envBound46342 : H12AffineFastState.Bounded env46342 := by
  intro p hp
  have h : env46342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46341_46342 : H12AffineEnvironment.transform 13 5156 env46341 = env46342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env46341 == env46342) = true)

theorem identity46342 : scanCanonicalize (H12AffineFastState.compose env46342 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46342 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46343 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5156,0,263,5173,2341,1024,1,4404,33,16,2,268,17,2048,5172,4097,2341,1285,33,256,32,5156,513]

theorem envBound46343 : H12AffineFastState.Bounded env46343 := by
  intro p hp
  have h : env46343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46342_46343 : H12AffineEnvironment.transform 5 17 env46342 = env46343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46342 == env46343) = true)

def env46344 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2836,0,263,2821,2341,1024,1,3588,33,16,2,268,17,2048,2820,3889,2341,1285,33,256,32,2836,513]

theorem envBound46344 : H12AffineFastState.Bounded env46344 := by
  intro p hp
  have h : env46344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46343_46344 : H12AffineEnvironment.transform 11 3888 env46343 = env46344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env46343 == env46344) = true)

def env46345 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1044,0,263,1029,1573,1024,1,260,33,16,2,268,17,1792,1028,49,1573,1285,33,256,32,1044,513]

theorem envBound46345 : H12AffineFastState.Bounded env46345 := by
  intro p hp
  have h : env46345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46344_46345 : H12AffineEnvironment.transform 10 1792 env46344 = env46345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env46344 == env46345) = true)

theorem identity46345 : scanCanonicalize (H12AffineFastState.compose env46345 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound46345 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46346 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,48,268,788,0,263,773,293,768,1,260,33,16,2,268,17,0,772,49,293,517,33,256,32,788,513]

theorem envBound46346 : H12AffineFastState.Bounded env46346 := by
  intro p hp
  have h : env46346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46345_46346 : H12AffineEnvironment.transform 9 768 env46345 = env46346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env46345 == env46346) = true)

def env46347 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,48,268,32,0,263,49,293,52,1,260,33,16,2,268,17,0,48,49,293,305,33,256,32,32,309]

theorem envBound46347 : H12AffineFastState.Bounded env46347 := by
  intro p hp
  have h : env46347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46346_46347 : H12AffineEnvironment.transform 8 308 env46346 = env46347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env46346 == env46347) = true)

theorem identity46347 : scanCanonicalize (H12AffineFastState.compose env46347 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46347 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46348 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,268,32,0,263,42,293,47,1,260,33,11,2,268,10,0,43,42,293,298,33,256,32,32,302]

theorem envBound46348 : H12AffineFastState.Bounded env46348 := by
  intro p hp
  have h : env46348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46347_46348 : H12AffineEnvironment.transform 3 11 env46347 = env46348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46347 == env46348) = true)

def leafEnv46348 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,43,268,32,0,263,42,293,47,1,260,33,11,2,298,268,1,10,0,43,42,293,298,33,256,32,4,263,32,302,1,260,0]

def active46348 : List Nat := [0,1,2,4,7]

def tree46348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46348 : H12WitnessSearch.Good tree46348 := H12GlobalWitnessIndex.good

theorem leafIdentity46348 : H12AffineFastState.composeSystem env46348 rootObs = leafEnv46348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46348 rootObs == leafEnv46348) = true)

theorem terminalChecked46348 : H12PackedTerminal.terminalCheckFast leafEnv46348 active46348 tree46348 = true := by decide +kernel

def env46349 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,268,33,0,263,48,293,53,1,260,33,16,2,268,17,0,49,49,293,304,33,256,32,33,308]

theorem envBound46349 : H12AffineFastState.Bounded env46349 := by
  intro p hp
  have h : env46349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46346_46349 : H12AffineEnvironment.transform 8 309 env46346 = env46349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env46346 == env46349) = true)

theorem identity46349 : scanCanonicalize (H12AffineFastState.compose env46349 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46350 : List Nat := [2,4,8,16,0,17,8,256,277,21,0,16,268,1,0,263,16,261,21,1,260,1,16,2,268,17,0,17,17,261,272,1,256,0,1,276]

theorem envBound46350 : H12AffineFastState.Bounded env46350 := by
  intro p hp
  have h : env46350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46349_46350 : H12AffineEnvironment.transform 4 0 env46349 = env46350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46349 == env46350) = true)

def leafEnv46350 : List Nat := [2,4,8,16,0,17,8,256,277,21,0,16,268,1,0,263,16,261,21,1,260,1,16,2,272,268,1,17,0,17,17,261,272,1,256,0,4,263,1,276,1,260,0]

def active46350 : List Nat := [0,1,2,3,7]

def tree46350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46350 : H12WitnessSearch.Good tree46350 := H12GlobalWitnessIndex.good

theorem leafIdentity46350 : H12AffineFastState.composeSystem env46350 rootObs = leafEnv46350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46350 rootObs == leafEnv46350) = true)

theorem terminalChecked46350 : H12PackedTerminal.terminalCheckFast leafEnv46350 active46350 tree46350 = true := by decide +kernel

def env46351 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1045,0,263,1028,1572,1024,1,261,33,16,2,268,17,1793,1029,48,1572,1285,33,256,32,1045,513]

theorem envBound46351 : H12AffineFastState.Bounded env46351 := by
  intro p hp
  have h : env46351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46344_46351 : H12AffineEnvironment.transform 10 1793 env46344 = env46351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env46344 == env46351) = true)

theorem identity46351 : scanCanonicalize (H12AffineFastState.compose env46351 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound46351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46352 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1297,49,268,1045,0,263,1028,1076,1024,1,261,33,16,2,268,17,1297,1029,48,1076,1285,33,256,32,1045,17]

theorem envBound46352 : H12AffineFastState.Bounded env46352 := by
  intro p hp
  have h : env46352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46351_46352 : H12AffineEnvironment.transform 8 16 env46351 = env46352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46351 == env46352) = true)

def env46353 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,268,33,0,263,48,0,52,1,261,33,16,2,268,17,293,49,48,0,305,33,256,32,33,17]

theorem envBound46353 : H12AffineFastState.Bounded env46353 := by
  intro p hp
  have h : env46353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46353 : H12AffineEnvironment.transform 9 52 env46352 = env46353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46352 == env46353) = true)

theorem identity46353 : scanCanonicalize (H12AffineFastState.compose env46353 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46354 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,268,33,0,263,42,0,46,1,261,33,10,2,268,11,293,43,42,0,299,33,256,32,33,11]

theorem envBound46354 : H12AffineFastState.Bounded env46354 := by
  intro p hp
  have h : env46354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46353_46354 : H12AffineEnvironment.transform 3 10 env46353 = env46354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46353 == env46354) = true)

def leafEnv46354 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,43,268,33,0,263,42,0,46,1,261,33,10,2,299,268,1,11,293,43,42,0,299,33,256,32,4,263,33,11,1,261,0]

def active46354 : List Nat := [0,1,2,4,7]

def tree46354 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46354 : H12WitnessSearch.Good tree46354 := H12GlobalWitnessIndex.good

theorem leafIdentity46354 : H12AffineFastState.composeSystem env46354 rootObs = leafEnv46354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46354 rootObs == leafEnv46354) = true)

theorem terminalChecked46354 : H12PackedTerminal.terminalCheckFast leafEnv46354 active46354 tree46354 = true := by decide +kernel

def env46355 : List Nat := [2,4,8,16,32,17,8,256,16,53,292,49,268,32,0,263,49,1,53,1,261,33,16,2,268,17,292,48,48,1,304,33,256,32,32,17]

theorem envBound46355 : H12AffineFastState.Bounded env46355 := by
  intro p hp
  have h : env46355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46352_46355 : H12AffineEnvironment.transform 9 53 env46352 = env46355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46352 == env46355) = true)

theorem identity46355 : scanCanonicalize (H12AffineFastState.compose env46355 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46356 : List Nat := [2,4,8,16,32,17,8,5,16,53,33,49,9,32,0,2,49,1,53,1,0,33,16,2,9,17,33,48,48,1,53,33,5,32,32,17]

theorem envBound46356 : H12AffineFastState.Bounded env46356 := by
  intro p hp
  have h : env46356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46355_46356 : H12AffineEnvironment.transform 7 5 env46355 = env46356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46355 == env46356) = true)

def leafEnv46356 : List Nat := [2,4,8,16,32,17,8,5,16,53,33,49,9,32,0,2,49,1,53,1,0,33,16,2,53,9,1,17,33,48,48,1,53,33,5,32,4,2,32,17,1,0,0]

def active46356 : List Nat := [0,1,2,3,4]

def tree46356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46356 : H12WitnessSearch.Good tree46356 := H12GlobalWitnessIndex.good

theorem leafIdentity46356 : H12AffineFastState.composeSystem env46356 rootObs = leafEnv46356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46356 rootObs == leafEnv46356) = true)

theorem terminalChecked46356 : H12PackedTerminal.terminalCheckFast leafEnv46356 active46356 tree46356 = true := by decide +kernel

def env46357 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2837,0,263,2820,2341,1024,1,3589,33,16,2,268,17,2048,2821,3888,2341,1285,33,256,32,2837,513]

theorem envBound46357 : H12AffineFastState.Bounded env46357 := by
  intro p hp
  have h : env46357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46343_46357 : H12AffineEnvironment.transform 11 3889 env46343 = env46357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env46343 == env46357) = true)

def env46358 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1045,0,263,1028,1573,1024,1,261,33,16,2,268,17,1792,1029,48,1573,1285,33,256,32,1045,513]

theorem envBound46358 : H12AffineFastState.Bounded env46358 := by
  intro p hp
  have h : env46358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46357_46358 : H12AffineEnvironment.transform 10 1792 env46357 = env46358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env46357 == env46358) = true)

theorem identity46358 : scanCanonicalize (H12AffineFastState.compose env46358 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound46358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46359 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1076,49,268,1045,0,263,1028,1297,1024,1,261,33,16,2,268,17,1076,1029,48,1297,1285,33,256,32,1045,309]

theorem envBound46359 : H12AffineFastState.Bounded env46359 := by
  intro p hp
  have h : env46359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46358_46359 : H12AffineEnvironment.transform 8 308 env46358 = env46359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env46358 == env46359) = true)

def env46360 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,268,33,0,263,48,293,52,1,261,33,16,2,268,17,0,49,48,293,305,33,256,32,33,309]

theorem envBound46360 : H12AffineFastState.Bounded env46360 := by
  intro p hp
  have h : env46360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46359_46360 : H12AffineEnvironment.transform 9 52 env46359 = env46360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46359 == env46360) = true)

theorem identity46360 : scanCanonicalize (H12AffineFastState.compose env46360 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46361 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,268,33,0,263,43,293,47,1,261,33,11,2,268,10,0,42,43,293,298,33,256,32,33,302]

theorem envBound46361 : H12AffineFastState.Bounded env46361 := by
  intro p hp
  have h : env46361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46360_46361 : H12AffineEnvironment.transform 3 11 env46360 = env46361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46360 == env46361) = true)

def leafEnv46361 : List Nat := [2,4,8,11,32,10,8,256,303,47,0,42,268,33,0,263,43,293,47,1,261,33,11,2,298,268,1,10,0,42,43,293,298,33,256,32,4,263,33,302,1,261,0]

def active46361 : List Nat := [0,1,2,4,7]

def tree46361 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46361 : H12WitnessSearch.Good tree46361 := H12GlobalWitnessIndex.good

theorem leafIdentity46361 : H12AffineFastState.composeSystem env46361 rootObs = leafEnv46361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46361 rootObs == leafEnv46361) = true)

theorem terminalChecked46361 : H12PackedTerminal.terminalCheckFast leafEnv46361 active46361 tree46361 = true := by decide +kernel

def env46362 : List Nat := [2,4,8,16,32,17,8,256,308,53,1,49,268,32,0,263,49,292,53,1,261,33,16,2,268,17,1,48,48,292,304,33,256,32,32,309]

theorem envBound46362 : H12AffineFastState.Bounded env46362 := by
  intro p hp
  have h : env46362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46359_46362 : H12AffineEnvironment.transform 9 53 env46359 = env46362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46359 == env46362) = true)

theorem identity46362 : scanCanonicalize (H12AffineFastState.compose env46362 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46363 : List Nat := [2,4,8,16,0,17,8,256,276,21,1,17,268,0,0,263,17,260,21,1,261,1,16,2,268,17,1,16,16,260,272,1,256,0,0,277]

theorem envBound46363 : H12AffineFastState.Bounded env46363 := by
  intro p hp
  have h : env46363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46362_46363 : H12AffineEnvironment.transform 4 0 env46362 = env46363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46362 == env46363) = true)

def leafEnv46363 : List Nat := [2,4,8,16,0,17,8,256,276,21,1,17,268,0,0,263,17,260,21,1,261,1,16,2,272,268,1,17,1,16,16,260,272,1,256,0,4,263,0,277,1,261,0]

def active46363 : List Nat := [0,1,2,3,7]

def tree46363 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46363 : H12WitnessSearch.Good tree46363 := H12GlobalWitnessIndex.good

theorem leafIdentity46363 : H12AffineFastState.composeSystem env46363 rootObs = leafEnv46363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46363 rootObs == leafEnv46363) = true)

theorem terminalChecked46363 : H12PackedTerminal.terminalCheckFast leafEnv46363 active46363 tree46363 = true := by decide +kernel

def env46364 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1044,0,263,1029,1572,1024,1,260,33,16,2,268,17,1793,1028,49,1572,1285,33,256,32,1044,513]

theorem envBound46364 : H12AffineFastState.Bounded env46364 := by
  intro p hp
  have h : env46364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46357_46364 : H12AffineEnvironment.transform 10 1793 env46357 = env46364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env46357 == env46364) = true)

theorem identity46364 : scanCanonicalize (H12AffineFastState.compose env46364 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound46364 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46365 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,48,268,560,0,263,545,0,548,1,260,33,16,2,268,17,293,544,49,0,801,33,256,32,560,513]

theorem envBound46365 : H12AffineFastState.Bounded env46365 := by
  intro p hp
  have h : env46365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46364_46365 : H12AffineEnvironment.transform 9 548 env46364 = env46365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env46364 == env46365) = true)

def env46366 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,48,268,32,0,263,49,0,52,1,260,33,16,2,268,17,293,48,49,0,305,33,256,32,32,17]

theorem envBound46366 : H12AffineFastState.Bounded env46366 := by
  intro p hp
  have h : env46366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46365_46366 : H12AffineEnvironment.transform 8 16 env46365 = env46366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46365 == env46366) = true)

theorem identity46366 : scanCanonicalize (H12AffineFastState.compose env46366 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46367 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,268,32,0,263,43,0,46,1,260,33,10,2,268,11,293,42,43,0,299,33,256,32,32,11]

theorem envBound46367 : H12AffineFastState.Bounded env46367 := by
  intro p hp
  have h : env46367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46366_46367 : H12AffineEnvironment.transform 3 10 env46366 = env46367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46366 == env46367) = true)

end H12CloudChart1