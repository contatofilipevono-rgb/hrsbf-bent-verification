import H12CloudChart1Data227

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env57788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144712,169102,26056,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57788 : H12AffineFastState.Bounded env57788 := by
  intro p hp
  have h : env57788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57787_57788 : H12AffineEnvironment.transform 17 87424 env57787 = env57788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57787 == env57788) = true)

theorem identity57788 : scanCanonicalize (H12AffineFastState.compose env57788 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 91263) := by decide +kernel

theorem selectedBound57788 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,91263,87424,1024,32768,94527,46480,86327,127217,26056,65846,103453,16384,91182,93514,29936,1528,257,69730,91263,18241]

theorem envBound57789 : H12AffineFastState.Bounded env57789 := by
  intro p hp
  have h : env57789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57788_57789 : H12AffineEnvironment.transform 16 91263 env57788 = env57789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91263 env57788 == env57789) = true)

def env57790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74047,69824,1024,32768,78975,46480,70775,112049,8328,65846,103453,1344,74094,75786,12720,1528,257,69730,74047,513]

theorem envBound57790 : H12AffineFastState.Bounded env57790 := by
  intro p hp
  have h : env57790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57789_57790 : H12AffineEnvironment.transform 13 1344 env57789 = env57790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57789 == env57790) = true)

theorem identity57790 : scanCanonicalize (H12AffineFastState.compose env57790 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57790 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,46497,33886,1024,32768,41185,46480,33001,8495,8328,38312,131,1344,46576,48276,12720,1528,257,34044,46497,513]

theorem envBound57791 : H12AffineFastState.Bounded env57791 := by
  intro p hp
  have h : env57791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57790_57791 : H12AffineEnvironment.transform 15 38046 env57790 = env57791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57790 == env57791) = true)

theorem identity57791 : scanCanonicalize (H12AffineFastState.compose env57791 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5560) := by decide +kernel

theorem selectedBound57791 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,8217,4582,1024,5560,13657,8232,5457,8495,8328,16,131,1344,8264,10540,12720,1528,257,4420,8217,513]

theorem envBound57792 : H12AffineFastState.Bounded env57792 := by
  intro p hp
  have h : env57792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57791_57792 : H12AffineEnvironment.transform 14 5560 env57791 = env57792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5560 env57791 == env57792) = true)

theorem identity57792 : scanCanonicalize (H12AffineFastState.compose env57792 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57792 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1109,294,8217,11,1024,1109,9396,8232,1212,8495,8328,16,131,1344,8264,10540,8285,1528,257,169,8217,513]

theorem envBound57793 : H12AffineFastState.Bounded env57793 := by
  intro p hp
  have h : env57793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57792_57793 : H12AffineEnvironment.transform 11 493 env57792 = env57793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57792 == env57793) = true)

theorem identity57793 : scanCanonicalize (H12AffineFastState.compose env57793 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 3922) := by decide +kernel

theorem selectedBound57793 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,3922,1344,1109,294,3915,11,1024,1109,3046,3962,1212,3709,4058,16,131,1344,3866,1662,3855,1528,257,169,3915,513]

theorem envBound57794 : H12AffineFastState.Bounded env57794 := by
  intro p hp
  have h : env57794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57793_57794 : H12AffineEnvironment.transform 12 3922 env57793 = env57794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3922 env57793 == env57794) = true)

theorem identity57794 : scanCanonicalize (H12AffineFastState.compose env57794 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound57794 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,420,1344,1109,294,445,11,1024,1109,1296,396,1212,139,300,16,131,1344,492,1662,505,1528,257,169,445,513]

theorem envBound57795 : H12AffineFastState.Bounded env57795 := by
  intro p hp
  have h : env57795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57794_57795 : H12AffineEnvironment.transform 10 1782 env57794 = env57795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env57794 == env57795) = true)

theorem identity57795 : scanCanonicalize (H12AffineFastState.compose env57795 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57795 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57796 : List Nat := [2,4,8,16,32,64,128,256,512,549,211,493,420,869,624,294,445,11,549,624,821,396,665,139,300,16,131,869,492,91,505,989,257,169,445,513]

theorem envBound57796 : H12AffineFastState.Bounded env57796 := by
  intro p hp
  have h : env57796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57795_57796 : H12AffineEnvironment.transform 9 549 env57795 = env57796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57795 == env57796) = true)

theorem identity57796 : scanCanonicalize (H12AffineFastState.compose env57796 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57796 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57797 : List Nat := [2,4,8,16,32,64,128,256,373,336,211,493,420,16,261,294,445,11,336,261,64,396,492,139,300,16,131,16,492,91,505,168,257,169,445,372]

theorem envBound57797 : H12AffineFastState.Bounded env57797 := by
  intro p hp
  have h : env57797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57796_57797 : H12AffineEnvironment.transform 8 373 env57796 = env57797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57796 == env57797) = true)

theorem identity57797 : scanCanonicalize (H12AffineFastState.compose env57797 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57797 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57798 : List Nat := [2,4,8,16,32,64,128,15,122,95,211,226,171,16,10,41,178,11,95,10,64,131,227,139,35,16,131,16,227,91,246,168,14,169,178,123]

theorem envBound57798 : H12AffineFastState.Bounded env57798 := by
  intro p hp
  have h : env57798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57797_57798 : H12AffineEnvironment.transform 7 15 env57797 = env57798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57797 == env57798) = true)

theorem identity57798 : scanCanonicalize (H12AffineFastState.compose env57798 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 107) := by decide +kernel

theorem selectedBound57798 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env57799 : List Nat := [2,4,8,16,32,64,107,15,122,95,56,9,64,16,10,41,89,11,95,10,64,104,8,96,35,16,104,16,8,91,29,67,14,66,89,123]

theorem envBound57799 : H12AffineFastState.Bounded env57799 := by
  intro p hp
  have h : env57799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57798_57799 : H12AffineEnvironment.transform 6 107 env57798 = env57799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 107 env57798 == env57799) = true)

theorem identity57799 : scanCanonicalize (H12AffineFastState.compose env57799 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound57799 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env57800 : List Nat := [2,4,8,16,32,8,35,15,50,23,56,9,8,16,10,41,17,11,23,10,8,32,8,40,35,16,32,16,8,19,29,11,14,10,17,51]

theorem envBound57800 : H12AffineFastState.Bounded env57800 := by
  intro p hp
  have h : env57800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57799_57800 : H12AffineEnvironment.transform 5 8 env57799 = env57800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env57799 == env57800) = true)

theorem identity57800 : scanCanonicalize (H12AffineFastState.compose env57800 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound57800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57801 : List Nat := [2,4,8,16,18,8,17,15,0,23,10,9,8,16,10,27,17,11,23,10,8,18,8,26,17,16,18,16,8,19,29,11,14,10,17,1]

theorem envBound57801 : H12AffineFastState.Bounded env57801 := by
  intro p hp
  have h : env57801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57800_57801 : H12AffineEnvironment.transform 4 18 env57800 = env57801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env57800 == env57801) = true)

theorem identity57801 : scanCanonicalize (H12AffineFastState.compose env57801 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57802 : List Nat := [1,4,8,16,17,8,17,12,0,20,9,9,8,16,9,24,17,8,20,9,8,17,8,25,17,16,17,16,8,16,29,8,13,9,17,1]

theorem envBound57802 : H12AffineFastState.Bounded env57802 := by
  intro p hp
  have h : env57802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57801_57802 : H12AffineEnvironment.transform 0 1 env57801 = env57802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57801 == env57802) = true)

theorem identity57802 : scanCanonicalize (H12AffineFastState.compose env57802 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound57802 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57803 : List Nat := [1,4,8,8,9,8,9,12,0,12,9,9,8,8,9,0,9,8,12,9,8,9,8,1,9,8,9,8,8,8,5,8,13,9,9,1]

theorem envBound57803 : H12AffineFastState.Bounded env57803 := by
  intro p hp
  have h : env57803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57802_57803 : H12AffineEnvironment.transform 3 8 env57802 = env57803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env57802 == env57803) = true)

def env57804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74046,69825,1024,32768,78974,46480,70774,112048,8329,65846,103453,1345,74095,75787,12721,1528,257,69730,74046,512]

theorem envBound57804 : H12AffineFastState.Bounded env57804 := by
  intro p hp
  have h : env57804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57789_57804 : H12AffineEnvironment.transform 13 1345 env57789 = env57804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57789 == env57804) = true)

theorem identity57804 : scanCanonicalize (H12AffineFastState.compose env57804 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57804 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74046,67024,1024,32768,74095,41089,65895,106657,8329,65846,98572,1345,74095,75787,9376,1528,257,66931,74046,512]

theorem envBound57805 : H12AffineFastState.Bounded env57805 := by
  intro p hp
  have h : env57805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57804_57805 : H12AffineEnvironment.transform 11 1297 env57804 = env57805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57804 == env57805) = true)

def env57806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144712,169102,26056,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound57806 : H12AffineFastState.Bounded env57806 := by
  intro p hp
  have h : env57806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57787_57806 : H12AffineEnvironment.transform 17 87425 env57787 = env57806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57787 == env57806) = true)

theorem identity57806 : scanCanonicalize (H12AffineFastState.compose env57806 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 74047) := by decide +kernel

theorem selectedBound57806 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74047,87425,1024,32768,78975,46480,70775,112049,26056,83062,103452,16384,74094,93514,12720,16568,257,69730,74047,18241]

theorem envBound57807 : H12AffineFastState.Bounded env57807 := by
  intro p hp
  have h : env57807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57806_57807 : H12AffineEnvironment.transform 16 74047 env57806 = env57807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74047 env57806 == env57807) = true)

def env57808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,74047,69825,1024,32768,78975,46480,70775,112049,8328,65846,103452,1344,74094,75786,12720,1528,257,69730,74047,513]

theorem envBound57808 : H12AffineFastState.Bounded env57808 := by
  intro p hp
  have h : env57808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57807_57808 : H12AffineEnvironment.transform 13 1344 env57807 = env57808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57807 == env57808) = true)

theorem identity57808 : scanCanonicalize (H12AffineFastState.compose env57808 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57808 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,46497,33887,1024,32768,41185,46480,33001,8495,8328,38312,130,1344,46576,48276,12720,1528,257,34044,46497,513]

theorem envBound57809 : H12AffineFastState.Bounded env57809 := by
  intro p hp
  have h : env57809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57808_57809 : H12AffineEnvironment.transform 15 38046 env57808 = env57809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57808 == env57809) = true)

theorem identity57809 : scanCanonicalize (H12AffineFastState.compose env57809 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 5560) := by decide +kernel

theorem selectedBound57809 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5560,294,8217,4583,1024,5560,13657,8232,5457,8495,8328,16,130,1344,8264,10540,12720,1528,257,4420,8217,513]

theorem envBound57810 : H12AffineFastState.Bounded env57810 := by
  intro p hp
  have h : env57810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57809_57810 : H12AffineEnvironment.transform 14 5560 env57809 = env57810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5560 env57809 == env57810) = true)

theorem identity57810 : scanCanonicalize (H12AffineFastState.compose env57810 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound57810 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1109,294,8217,10,1024,1109,9396,8232,1212,8495,8328,16,130,1344,8264,10540,8285,1528,257,169,8217,513]

theorem envBound57811 : H12AffineFastState.Bounded env57811 := by
  intro p hp
  have h : env57811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57810_57811 : H12AffineEnvironment.transform 11 493 env57810 = env57811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env57810 == env57811) = true)

theorem identity57811 : scanCanonicalize (H12AffineFastState.compose env57811 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 3922) := by decide +kernel

theorem selectedBound57811 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,3922,1344,1109,294,3915,10,1024,1109,3046,3962,1212,3709,4058,16,130,1344,3866,1662,3855,1528,257,169,3915,513]

theorem envBound57812 : H12AffineFastState.Bounded env57812 := by
  intro p hp
  have h : env57812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57811_57812 : H12AffineEnvironment.transform 12 3922 env57811 = env57812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3922 env57811 == env57812) = true)

theorem identity57812 : scanCanonicalize (H12AffineFastState.compose env57812 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound57812 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,420,1344,1109,294,445,10,1024,1109,1296,396,1212,139,300,16,130,1344,492,1662,505,1528,257,169,445,513]

theorem envBound57813 : H12AffineFastState.Bounded env57813 := by
  intro p hp
  have h : env57813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57812_57813 : H12AffineEnvironment.transform 10 1782 env57812 = env57813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env57812 == env57813) = true)

theorem identity57813 : scanCanonicalize (H12AffineFastState.compose env57813 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57813 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57814 : List Nat := [2,4,8,16,32,64,128,256,512,549,211,493,420,869,624,294,445,10,549,624,821,396,665,139,300,16,130,869,492,91,505,989,257,169,445,513]

theorem envBound57814 : H12AffineFastState.Bounded env57814 := by
  intro p hp
  have h : env57814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57813_57814 : H12AffineEnvironment.transform 9 549 env57813 = env57814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57813 == env57814) = true)

theorem identity57814 : scanCanonicalize (H12AffineFastState.compose env57814 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound57814 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57815 : List Nat := [2,4,8,16,32,64,128,256,373,336,211,493,420,16,261,294,445,10,336,261,64,396,492,139,300,16,130,16,492,91,505,168,257,169,445,372]

theorem envBound57815 : H12AffineFastState.Bounded env57815 := by
  intro p hp
  have h : env57815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57814_57815 : H12AffineEnvironment.transform 8 373 env57814 = env57815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env57814 == env57815) = true)

theorem identity57815 : scanCanonicalize (H12AffineFastState.compose env57815 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound57815 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57816 : List Nat := [2,4,8,16,32,64,115,256,373,336,32,286,343,16,261,294,334,10,336,261,64,383,287,120,300,16,113,16,287,91,266,91,257,90,334,372]

theorem envBound57816 : H12AffineFastState.Bounded env57816 := by
  intro p hp
  have h : env57816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57815_57816 : H12AffineEnvironment.transform 6 115 env57815 = env57816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env57815 == env57816) = true)

theorem identity57816 : scanCanonicalize (H12AffineFastState.compose env57816 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 109) := by decide +kernel

theorem selectedBound57816 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env57817 : List Nat := [2,4,8,16,32,64,115,109,24,61,32,115,58,16,104,75,35,10,61,104,64,18,114,120,65,16,113,16,114,91,103,91,108,90,35,25]

theorem envBound57817 : H12AffineFastState.Bounded env57817 := by
  intro p hp
  have h : env57817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57816_57817 : H12AffineEnvironment.transform 7 109 env57816 = env57817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 109 env57816 == env57817) = true)

theorem identity57817 : scanCanonicalize (H12AffineFastState.compose env57817 (packedSelected [0,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57817 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env57818 : List Nat := [2,4,8,16,32,16,35,61,24,61,32,35,58,16,56,27,35,10,61,56,16,18,34,40,17,16,33,16,34,11,55,11,60,10,35,25]

theorem envBound57818 : H12AffineFastState.Bounded env57818 := by
  intro p hp
  have h : env57818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57817_57818 : H12AffineEnvironment.transform 5 16 env57817 = env57818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57817 == env57818) = true)

theorem identity57818 : scanCanonicalize (H12AffineFastState.compose env57818 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57818 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57819 : List Nat := [2,4,8,16,0,16,3,29,24,29,0,3,26,16,24,27,3,10,29,24,16,18,2,8,17,16,1,16,2,11,23,11,28,10,3,25]

theorem envBound57819 : H12AffineFastState.Bounded env57819 := by
  intro p hp
  have h : env57819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57818_57819 : H12AffineEnvironment.transform 4 0 env57818 = env57819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57818 == env57819) = true)

theorem identity57819 : scanCanonicalize (H12AffineFastState.compose env57819 (packedSelected [0,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57819 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env57820 : List Nat := [1,4,8,16,0,16,0,29,24,29,0,0,25,16,24,24,0,9,29,24,16,17,1,8,17,16,1,16,1,8,20,8,28,9,0,25]

theorem envBound57820 : H12AffineFastState.Bounded env57820 := by
  intro p hp
  have h : env57820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57819_57820 : H12AffineEnvironment.transform 0 1 env57819 = env57820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57819 == env57820) = true)

theorem identity57820 : scanCanonicalize (H12AffineFastState.compose env57820 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound57820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57821 : List Nat := [1,4,1,16,0,16,0,20,17,20,0,0,16,16,17,17,0,0,20,17,16,17,1,1,17,16,1,16,1,1,20,1,21,0,0,16]

theorem envBound57821 : H12AffineFastState.Bounded env57821 := by
  intro p hp
  have h : env57821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57820_57821 : H12AffineEnvironment.transform 2 1 env57820 = env57821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env57820 == env57821) = true)

theorem identity57821 : scanCanonicalize (H12AffineFastState.compose env57821 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57821 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57822 : List Nat := [1,4,1,0,0,0,0,4,1,4,0,0,0,0,1,1,0,0,4,1,0,1,1,1,1,0,1,0,1,1,4,1,5,0,0,0]

theorem envBound57822 : H12AffineFastState.Bounded env57822 := by
  intro p hp
  have h : env57822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57821_57822 : H12AffineEnvironment.transform 3 0 env57821 = env57822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57821 == env57822) = true)

def env57823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,74047,69824,1024,32768,78975,46480,70775,112049,8329,65847,103452,1345,74094,75787,12720,1529,257,69730,74047,512]

theorem envBound57823 : H12AffineFastState.Bounded env57823 := by
  intro p hp
  have h : env57823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57807_57823 : H12AffineEnvironment.transform 13 1345 env57807 = env57823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57807 == env57823) = true)

theorem identity57823 : scanCanonicalize (H12AffineFastState.compose env57823 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57823 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,74047,67025,1024,32768,74094,41089,65894,106656,8329,65847,98573,1345,74094,75787,9377,1529,257,66931,74047,512]

theorem envBound57824 : H12AffineFastState.Bounded env57824 := by
  intro p hp
  have h : env57824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57823_57824 : H12AffineEnvironment.transform 11 1297 env57823 = env57824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57823 == env57824) = true)

def env57825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144712,169102,26057,157001,311708,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57825 : H12AffineFastState.Bounded env57825 := by
  intro p hp
  have h : env57825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57786_57825 : H12AffineEnvironment.transform 20 136513 env57786 = env57825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57786 == env57825) = true)

def env57826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144712,169102,26057,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57826 : H12AffineFastState.Bounded env57826 := by
  intro p hp
  have h : env57826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57825_57826 : H12AffineEnvironment.transform 17 87424 env57825 = env57826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57825 == env57826) = true)

theorem identity57826 : scanCanonicalize (H12AffineFastState.compose env57826 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 78894) := by decide +kernel

theorem selectedBound57826 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,78894,87424,1024,32768,74095,46481,65894,106656,26057,86375,103452,16384,78975,93515,9377,21929,257,69731,78894,18240]

theorem envBound57827 : H12AffineFastState.Bounded env57827 := by
  intro p hp
  have h : env57827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57826_57827 : H12AffineEnvironment.transform 16 78894 env57826 = env57827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78894 env57826 == env57827) = true)

def env57828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78894,69824,1024,32768,74095,46481,65894,106656,8329,70695,103452,1344,78975,75787,9377,4329,257,69731,78894,512]

theorem envBound57828 : H12AffineFastState.Bounded env57828 := by
  intro p hp
  have h : env57828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57827_57828 : H12AffineEnvironment.transform 13 1344 env57827 = env57828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57827 == env57828) = true)

theorem identity57828 : scanCanonicalize (H12AffineFastState.compose env57828 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57828 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74046,67024,1024,32768,74095,41089,65894,106656,8329,65847,98572,1344,74095,75787,9377,1529,257,66931,74046,512]

theorem envBound57829 : H12AffineFastState.Bounded env57829 := by
  intro p hp
  have h : env57829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57828_57829 : H12AffineEnvironment.transform 11 1296 env57828 = env57829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57828 == env57829) = true)

def env57830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78894,69825,1024,32768,74095,46481,65894,106656,8328,70694,103452,1345,78975,75786,9377,4328,257,69731,78894,513]

theorem envBound57830 : H12AffineFastState.Bounded env57830 := by
  intro p hp
  have h : env57830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57827_57830 : H12AffineEnvironment.transform 13 1345 env57827 = env57830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57827 == env57830) = true)

theorem identity57830 : scanCanonicalize (H12AffineFastState.compose env57830 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57830 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,41137,33886,1024,32768,46576,46481,38393,13375,8328,32953,131,1345,41184,48277,9377,4328,257,34044,41137,513]

theorem envBound57831 : H12AffineFastState.Bounded env57831 := by
  intro p hp
  have h : env57831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57830_57831 : H12AffineEnvironment.transform 15 38047 env57830 = env57831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57830 == env57831) = true)

theorem identity57831 : scanCanonicalize (H12AffineFastState.compose env57831 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound57831 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,8216,1271,1024,169,13657,13624,5456,13375,8328,16,131,1345,8265,15420,9377,4328,257,1109,8216,513]

theorem envBound57832 : H12AffineFastState.Bounded env57832 := by
  intro p hp
  have h : env57832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57831_57832 : H12AffineEnvironment.transform 14 169 env57831 = env57832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env57831 == env57832) = true)

theorem identity57832 : scanCanonicalize (H12AffineFastState.compose env57832 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound57832 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57833 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,169,4298,8216,11,252,169,12709,12740,4524,12483,8328,16,131,445,8265,14528,8285,4328,257,169,8216,513]

theorem envBound57833 : H12AffineFastState.Bounded env57833 := by
  intro p hp
  have h : env57833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57832_57833 : H12AffineEnvironment.transform 9 252 env57832 = env57833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57832 == env57833) = true)

theorem identity57833 : scanCanonicalize (H12AffineFastState.compose env57833 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6722) := by decide +kernel

theorem selectedBound57833 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57834 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,6722,445,169,4298,6746,11,252,169,3047,2950,4524,2689,6858,16,131,445,6667,642,6687,4328,257,169,6746,513]

theorem envBound57834 : H12AffineFastState.Bounded env57834 := by
  intro p hp
  have h : env57834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57833_57834 : H12AffineEnvironment.transform 12 6722 env57833 = env57834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6722 env57833 == env57834) = true)

theorem identity57834 : scanCanonicalize (H12AffineFastState.compose env57834 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57834 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57835 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,4168,445,169,4298,4176,11,252,169,493,396,4524,139,4288,16,131,445,4097,642,4117,4328,257,169,4176,513]

theorem envBound57835 : H12AffineFastState.Bounded env57835 := by
  intro p hp
  have h : env57835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57834_57835 : H12AffineEnvironment.transform 10 522 env57834 = env57835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57834 == env57835) = true)

theorem identity57835 : scanCanonicalize (H12AffineFastState.compose env57835 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound57835 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57836 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,820,892,445,169,1022,868,11,252,169,493,396,664,139,1012,16,131,445,821,642,801,988,257,169,868,513]

theorem envBound57836 : H12AffineFastState.Bounded env57836 := by
  intro p hp
  have h : env57836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57835_57836 : H12AffineEnvironment.transform 11 820 env57835 = env57836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env57835 == env57836) = true)

theorem identity57836 : scanCanonicalize (H12AffineFastState.compose env57836 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57836 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57837 : List Nat := [2,4,8,16,32,64,128,172,512,252,522,664,720,17,169,594,712,11,252,169,65,32,664,139,600,16,131,17,665,642,653,624,173,169,712,513]

theorem envBound57837 : H12AffineFastState.Bounded env57837 := by
  intro p hp
  have h : env57837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57836_57837 : H12AffineEnvironment.transform 7 172 env57836 = env57837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57836 == env57837) = true)

theorem identity57837 : scanCanonicalize (H12AffineFastState.compose env57837 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound57837 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57838 : List Nat := [2,4,8,16,32,64,128,172,123,252,113,227,171,17,169,41,179,11,252,169,65,32,227,139,35,16,131,17,226,249,246,11,173,169,179,122]

theorem envBound57838 : H12AffineFastState.Bounded env57838 := by
  intro p hp
  have h : env57838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57837_57838 : H12AffineEnvironment.transform 8 123 env57837 = env57838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env57837 == env57838) = true)

theorem identity57838 : scanCanonicalize (H12AffineFastState.compose env57838 (packedSelected [2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound57838 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env57839 : List Nat := [2,4,8,16,19,64,128,159,72,207,66,208,152,17,154,26,128,11,207,154,65,19,208,139,16,16,131,17,209,202,197,11,158,154,128,73]

theorem envBound57839 : H12AffineFastState.Bounded env57839 := by
  intro p hp
  have h : env57839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57838_57839 : H12AffineEnvironment.transform 4 19 env57838 = env57839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env57838 == env57839) = true)

theorem identity57839 : scanCanonicalize (H12AffineFastState.compose env57839 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57839 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env57840 : List Nat := [2,4,8,16,19,17,128,159,25,158,19,129,152,17,154,26,128,11,158,154,16,19,129,139,16,16,131,17,128,155,148,11,158,154,128,24]

theorem envBound57840 : H12AffineFastState.Bounded env57840 := by
  intro p hp
  have h : env57840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57839_57840 : H12AffineEnvironment.transform 5 17 env57839 = env57840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57839 == env57840) = true)

theorem identity57840 : scanCanonicalize (H12AffineFastState.compose env57840 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound57840 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57841 : List Nat := [2,4,8,16,19,17,18,13,25,12,19,19,10,17,8,26,18,11,12,8,16,19,19,25,16,16,17,17,18,9,6,11,12,8,18,24]

theorem envBound57841 : H12AffineFastState.Bounded env57841 := by
  intro p hp
  have h : env57841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57840_57841 : H12AffineEnvironment.transform 6 18 env57840 = env57841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env57840 == env57841) = true)

theorem identity57841 : scanCanonicalize (H12AffineFastState.compose env57841 (packedSelected [0,2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57841 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env57842 : List Nat := [1,4,8,16,16,17,17,13,25,12,16,16,9,17,8,25,17,8,12,8,16,16,16,25,16,16,17,17,17,9,5,8,12,8,17,24]

theorem envBound57842 : H12AffineFastState.Bounded env57842 := by
  intro p hp
  have h : env57842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57841_57842 : H12AffineEnvironment.transform 0 1 env57841 = env57842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57841 == env57842) = true)

theorem identity57842 : scanCanonicalize (H12AffineFastState.compose env57842 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57843 : List Nat := [1,4,8,0,0,1,1,13,9,12,0,0,9,1,8,9,1,8,12,8,0,0,0,9,0,0,1,1,1,9,5,8,12,8,1,8]

theorem envBound57843 : H12AffineFastState.Bounded env57843 := by
  intro p hp
  have h : env57843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57842_57843 : H12AffineEnvironment.transform 3 0 env57842 = env57843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57842 == env57843) = true)

def env57844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144712,169102,26057,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound57844 : H12AffineFastState.Bounded env57844 := by
  intro p hp
  have h : env57844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57825_57844 : H12AffineEnvironment.transform 17 87425 env57825 = env57844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57825 == env57844) = true)

theorem identity57844 : scanCanonicalize (H12AffineFastState.compose env57844 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 94575) := by decide +kernel

theorem selectedBound57844 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94575,87425,1024,32768,91182,46481,82983,124385,26057,70694,103453,16384,94526,93515,25056,4328,257,69731,94575,18240]

theorem envBound57845 : H12AffineFastState.Bounded env57845 := by
  intro p hp
  have h : env57845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57844_57845 : H12AffineEnvironment.transform 16 94575 env57844 = env57845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94575 env57844 == env57845) = true)

def env57846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,78895,69825,1024,32768,74094,46481,65895,106657,8329,70694,103453,1344,78974,75787,9376,4328,257,69731,78895,512]

theorem envBound57846 : H12AffineFastState.Bounded env57846 := by
  intro p hp
  have h : env57846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57845_57846 : H12AffineEnvironment.transform 13 1344 env57845 = env57846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57845 == env57846) = true)

theorem identity57846 : scanCanonicalize (H12AffineFastState.compose env57846 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57846 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,74047,67025,1024,32768,74094,41089,65895,106657,8329,65846,98573,1344,74094,75787,9376,1528,257,66931,74047,512]

theorem envBound57847 : H12AffineFastState.Bounded env57847 := by
  intro p hp
  have h : env57847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57846_57847 : H12AffineEnvironment.transform 11 1296 env57846 = env57847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57846 == env57847) = true)

def env57848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,78894,69824,1024,32768,74095,46481,65894,106656,8328,70694,103453,1345,78975,75786,9377,4328,257,69731,78894,513]

theorem envBound57848 : H12AffineFastState.Bounded env57848 := by
  intro p hp
  have h : env57848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57845_57848 : H12AffineEnvironment.transform 13 1345 env57845 = env57848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57845 == env57848) = true)

theorem identity57848 : scanCanonicalize (H12AffineFastState.compose env57848 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57848 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,41137,33887,1024,32768,46576,46481,38393,13375,8328,32953,130,1345,41184,48277,9377,4328,257,34044,41137,513]

theorem envBound57849 : H12AffineFastState.Bounded env57849 := by
  intro p hp
  have h : env57849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57848_57849 : H12AffineEnvironment.transform 15 38047 env57848 = env57849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57848 == env57849) = true)

theorem identity57849 : scanCanonicalize (H12AffineFastState.compose env57849 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound57849 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,169,5174,8216,1270,1024,169,13657,13624,5456,13375,8328,16,130,1345,8265,15420,9377,4328,257,1109,8216,513]

theorem envBound57850 : H12AffineFastState.Bounded env57850 := by
  intro p hp
  have h : env57850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57849_57850 : H12AffineEnvironment.transform 14 169 env57849 = env57850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env57849 == env57850) = true)

theorem identity57850 : scanCanonicalize (H12AffineFastState.compose env57850 (packedSelected [25] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound57850 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57851 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,169,4298,8216,10,252,169,12709,12740,4524,12483,8328,16,130,445,8265,14528,8285,4328,257,169,8216,513]

theorem envBound57851 : H12AffineFastState.Bounded env57851 := by
  intro p hp
  have h : env57851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57850_57851 : H12AffineEnvironment.transform 9 252 env57850 = env57851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env57850 == env57851) = true)

theorem identity57851 : scanCanonicalize (H12AffineFastState.compose env57851 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6722) := by decide +kernel

theorem selectedBound57851 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57852 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,6722,445,169,4298,6746,10,252,169,3047,2950,4524,2689,6858,16,130,445,6667,642,6687,4328,257,169,6746,513]

theorem envBound57852 : H12AffineFastState.Bounded env57852 := by
  intro p hp
  have h : env57852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57851_57852 : H12AffineEnvironment.transform 12 6722 env57851 = env57852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6722 env57851 == env57852) = true)

theorem identity57852 : scanCanonicalize (H12AffineFastState.compose env57852 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound57852 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57853 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,4168,445,169,4298,4176,10,252,169,493,396,4524,139,4288,16,130,445,4097,642,4117,4328,257,169,4176,513]

theorem envBound57853 : H12AffineFastState.Bounded env57853 := by
  intro p hp
  have h : env57853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57852_57853 : H12AffineEnvironment.transform 10 522 env57852 = env57853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env57852 == env57853) = true)

theorem identity57853 : scanCanonicalize (H12AffineFastState.compose env57853 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound57853 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57854 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,820,892,445,169,1022,868,10,252,169,493,396,664,139,1012,16,130,445,821,642,801,988,257,169,868,513]

theorem envBound57854 : H12AffineFastState.Bounded env57854 := by
  intro p hp
  have h : env57854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57853_57854 : H12AffineEnvironment.transform 11 820 env57853 = env57854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env57853 == env57854) = true)

theorem identity57854 : scanCanonicalize (H12AffineFastState.compose env57854 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57854 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env57855 : List Nat := [2,4,8,16,32,64,128,172,512,252,522,664,720,17,169,594,712,10,252,169,65,32,664,139,600,16,130,17,665,642,653,624,173,169,712,513]

theorem envBound57855 : H12AffineFastState.Bounded env57855 := by
  intro p hp
  have h : env57855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57854_57855 : H12AffineEnvironment.transform 7 172 env57854 = env57855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57854 == env57855) = true)

theorem identity57855 : scanCanonicalize (H12AffineFastState.compose env57855 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound57855 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env57856 : List Nat := [2,4,8,16,32,64,114,94,512,14,522,618,546,17,91,594,570,10,14,91,65,32,618,121,600,16,112,17,619,624,639,624,95,91,570,513]

theorem envBound57856 : H12AffineFastState.Bounded env57856 := by
  intro p hp
  have h : env57856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57855_57856 : H12AffineEnvironment.transform 6 114 env57855 = env57856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env57855 == env57856) = true)

theorem identity57856 : scanCanonicalize (H12AffineFastState.compose env57856 (packedSelected [0,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound57856 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env57857 : List Nat := [2,4,8,16,32,35,17,61,512,14,522,521,546,17,56,561,570,10,14,56,34,32,521,26,571,16,19,17,520,531,540,531,60,56,570,513]

theorem envBound57857 : H12AffineFastState.Bounded env57857 := by
  intro p hp
  have h : env57857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57856_57857 : H12AffineEnvironment.transform 5 35 env57856 = env57857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env57856 == env57857) = true)

theorem identity57857 : scanCanonicalize (H12AffineFastState.compose env57857 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound57857 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env57858 : List Nat := [2,4,8,16,32,35,17,61,42,14,32,35,8,17,56,27,16,10,14,56,34,32,35,26,17,16,19,17,34,57,54,57,60,56,16,43]

theorem envBound57858 : H12AffineFastState.Bounded env57858 := by
  intro p hp
  have h : env57858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57857_57858 : H12AffineEnvironment.transform 8 42 env57857 = env57858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env57857 == env57858) = true)

theorem identity57858 : scanCanonicalize (H12AffineFastState.compose env57858 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound57858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57859 : List Nat := [2,4,8,16,9,10,17,20,3,14,9,10,8,17,17,27,16,10,14,17,11,9,10,26,17,16,19,17,11,16,31,16,21,17,16,2]

theorem envBound57859 : H12AffineFastState.Bounded env57859 := by
  intro p hp
  have h : env57859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57858_57859 : H12AffineEnvironment.transform 4 9 env57858 = env57859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env57858 == env57859) = true)

theorem identity57859 : scanCanonicalize (H12AffineFastState.compose env57859 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57859 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57860 : List Nat := [0,4,8,16,9,8,17,20,1,12,9,8,8,17,17,25,16,8,12,17,9,9,8,24,17,16,17,17,9,16,29,16,21,17,16,0]

theorem envBound57860 : H12AffineFastState.Bounded env57860 := by
  intro p hp
  have h : env57860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57859_57860 : H12AffineEnvironment.transform 0 0 env57859 = env57860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57859 == env57860) = true)

theorem identity57860 : scanCanonicalize (H12AffineFastState.compose env57860 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound57860 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env57861 : List Nat := [0,4,8,8,9,8,9,12,1,12,9,8,8,9,9,1,8,8,12,9,9,9,8,0,9,8,9,9,9,8,5,8,13,9,8,0]

theorem envBound57861 : H12AffineFastState.Bounded env57861 := by
  intro p hp
  have h : env57861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57860_57861 : H12AffineEnvironment.transform 3 8 env57860 = env57861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env57860 == env57861) = true)

def env57862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144713,169103,2257033,157000,2544861,16384,131153,2324491,200846,221575,257,2295074,131072,2249216]

theorem envBound57862 : H12AffineFastState.Bounded env57862 := by
  intro p hp
  have h : env57862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57785_57862 : H12AffineEnvironment.transform 21 2269393 env57785 = env57862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env57785 == env57862) = true)

def env57863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144713,169103,26057,157000,311709,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57863 : H12AffineFastState.Bounded env57863 := by
  intro p hp
  have h : env57863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57862_57863 : H12AffineEnvironment.transform 20 136512 env57862 = env57863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57862 == env57863) = true)

def env57864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144713,169103,26057,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57864 : H12AffineFastState.Bounded env57864 := by
  intro p hp
  have h : env57864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57863_57864 : H12AffineEnvironment.transform 17 87424 env57863 = env57864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57863 == env57864) = true)

theorem identity57864 : scanCanonicalize (H12AffineFastState.compose env57864 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 87095) := by decide +kernel

theorem selectedBound57864 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,87095,87424,1024,32768,82295,46481,90494,114872,26057,78207,103453,16384,87142,93515,17593,13744,257,69730,87095,18240]

theorem envBound57865 : H12AffineFastState.Bounded env57865 := by
  intro p hp
  have h : env57865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57864_57865 : H12AffineEnvironment.transform 16 87095 env57864 = env57865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 87095 env57864 == env57865) = true)

def env57866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70007,69824,1024,32768,66615,46481,74814,99832,8329,78207,103453,1344,69926,75787,505,13744,257,69730,70007,512]

theorem envBound57866 : H12AffineFastState.Bounded env57866 := by
  intro p hp
  have h : env57866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57865_57866 : H12AffineEnvironment.transform 13 1344 env57865 = env57866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57865 == env57866) = true)

theorem identity57866 : scanCanonicalize (H12AffineFastState.compose env57866 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57866 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66663,67024,1024,32768,66615,41089,74814,99832,8329,74863,98573,1344,66614,75787,505,8352,257,66930,66663,512]

theorem envBound57867 : H12AffineFastState.Bounded env57867 := by
  intro p hp
  have h : env57867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57866_57867 : H12AffineEnvironment.transform 11 1296 env57866 = env57867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57866 == env57867) = true)

def env57868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70006,69825,1024,32768,66614,46481,74815,99833,8328,78207,103453,1345,69927,75786,504,13744,257,69730,70006,513]

theorem envBound57868 : H12AffineFastState.Bounded env57868 := by
  intro p hp
  have h : env57868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57865_57868 : H12AffineEnvironment.transform 13 1345 env57865 = env57868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57865 == env57868) = true)

theorem identity57868 : scanCanonicalize (H12AffineFastState.compose env57868 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57868 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,34280,33887,1024,32768,37032,46481,45217,4455,8328,42465,131,1345,34233,48276,504,13744,257,34044,34280,513]

theorem envBound57869 : H12AffineFastState.Bounded env57869 := by
  intro p hp
  have h : env57869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57868_57869 : H12AffineEnvironment.transform 15 38046 env57868 = env57869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57868 == env57869) = true)

theorem identity57869 : scanCanonicalize (H12AffineFastState.compose env57869 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound57869 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,8216,8623,1024,9712,13656,4193,5457,4455,8328,17,131,1345,8265,6500,504,13744,257,8460,8216,513]

theorem envBound57870 : H12AffineFastState.Bounded env57870 := by
  intro p hp
  have h : env57870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57869_57870 : H12AffineEnvironment.transform 14 9712 env57869 = env57870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env57869 == env57870) = true)

theorem identity57870 : scanCanonicalize (H12AffineFastState.compose env57870 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57870 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1108,4298,444,11,1024,1108,5372,4193,5457,4455,300,17,131,1345,493,6500,504,5140,257,168,444,513]

theorem envBound57871 : H12AffineFastState.Bounded env57871 := by
  intro p hp
  have h : env57871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57870_57871 : H12AffineEnvironment.transform 12 420 env57870 = env57871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57870 == env57871) = true)

theorem identity57871 : scanCanonicalize (H12AffineFastState.compose env57871 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3767) := by decide +kernel

theorem selectedBound57871 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3767,420,1345,1108,3709,444,11,1024,1108,2635,3798,3046,4048,300,17,131,1345,493,2003,504,2723,257,168,444,513]

theorem envBound57872 : H12AffineFastState.Bounded env57872 := by
  intro p hp
  have h : env57872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57871_57872 : H12AffineEnvironment.transform 11 3767 env57871 = env57872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3767 env57871 == env57872) = true)

theorem identity57872 : scanCanonicalize (H12AffineFastState.compose env57872 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57872 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57873 : List Nat := [2,4,8,16,32,64,128,256,512,549,2048,2194,420,868,625,2136,444,11,549,625,2635,2291,3046,2549,300,17,131,868,493,502,504,2723,257,168,444,513]

theorem envBound57873 : H12AffineFastState.Bounded env57873 := by
  intro p hp
  have h : env57873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57872_57873 : H12AffineEnvironment.transform 9 549 env57872 = env57873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57872 == env57873) = true)

theorem identity57873 : scanCanonicalize (H12AffineFastState.compose env57873 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound57873 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env57874 : List Nat := [2,4,8,16,32,64,128,256,293,256,2048,2194,420,65,340,2136,444,11,256,340,2414,2291,2243,2549,300,17,131,65,493,502,504,2438,257,168,444,292]

theorem envBound57874 : H12AffineFastState.Bounded env57874 := by
  intro p hp
  have h : env57874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57873_57874 : H12AffineEnvironment.transform 8 293 env57873 = env57874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env57873 == env57874) = true)

theorem identity57874 : scanCanonicalize (H12AffineFastState.compose env57874 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57874 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57875 : List Nat := [2,4,8,16,32,17,128,256,293,256,2048,2194,420,16,261,2057,444,11,256,261,2367,2210,2194,2468,300,17,131,16,444,423,425,2438,257,168,444,292]

theorem envBound57875 : H12AffineFastState.Bounded env57875 := by
  intro p hp
  have h : env57875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57874_57875 : H12AffineEnvironment.transform 5 17 env57874 = env57875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57874 == env57875) = true)

theorem identity57875 : scanCanonicalize (H12AffineFastState.compose env57875 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound57875 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57876 : List Nat := [2,4,8,16,32,17,128,256,293,256,131,17,420,16,261,138,444,11,256,261,444,33,17,295,300,17,131,16,444,423,425,261,257,168,444,292]

theorem envBound57876 : H12AffineFastState.Bounded env57876 := by
  intro p hp
  have h : env57876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57875_57876 : H12AffineEnvironment.transform 10 131 env57875 = env57876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env57875 == env57876) = true)

theorem identity57876 : scanCanonicalize (H12AffineFastState.compose env57876 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57876 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57877 : List Nat := [2,4,8,1,32,0,128,256,293,256,131,0,420,1,261,138,429,11,256,261,429,33,0,295,300,0,131,1,429,423,425,261,257,168,429,292]

theorem envBound57877 : H12AffineFastState.Bounded env57877 := by
  intro p hp
  have h : env57877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57876_57877 : H12AffineEnvironment.transform 3 1 env57876 = env57877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57876 == env57877) = true)

theorem identity57877 : scanCanonicalize (H12AffineFastState.compose env57877 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57877 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57878 : List Nat := [2,4,8,1,32,0,9,256,293,256,10,0,301,1,261,3,292,11,256,261,292,33,0,295,300,0,10,1,292,302,288,261,257,33,292,292]

theorem envBound57878 : H12AffineFastState.Bounded env57878 := by
  intro p hp
  have h : env57878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57877_57878 : H12AffineEnvironment.transform 6 9 env57877 = env57878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57877 == env57878) = true)

theorem identity57878 : scanCanonicalize (H12AffineFastState.compose env57878 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound57878 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57879 : List Nat := [2,4,8,1,2,0,9,256,263,256,10,0,271,1,261,3,262,11,256,261,262,3,0,261,270,0,10,1,262,268,258,261,257,3,262,262]

theorem envBound57879 : H12AffineFastState.Bounded env57879 := by
  intro p hp
  have h : env57879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57878_57879 : H12AffineEnvironment.transform 4 2 env57878 = env57879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env57878 == env57879) = true)

theorem identity57879 : scanCanonicalize (H12AffineFastState.compose env57879 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound57879 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env57880 : List Nat := [2,4,8,1,2,0,9,15,8,15,10,0,0,1,10,3,9,11,15,10,9,3,0,10,1,0,10,1,9,3,13,10,14,3,9,9]

theorem envBound57880 : H12AffineFastState.Bounded env57880 := by
  intro p hp
  have h : env57880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57879_57880 : H12AffineEnvironment.transform 7 15 env57879 = env57880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env57879 == env57880) = true)

theorem identity57880 : scanCanonicalize (H12AffineFastState.compose env57880 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57881 : List Nat := [2,4,0,1,2,0,1,7,0,7,2,0,0,1,2,3,1,3,7,2,1,3,0,2,1,0,2,1,1,3,5,2,6,3,1,1]

theorem envBound57881 : H12AffineFastState.Bounded env57881 := by
  intro p hp
  have h : env57881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57880_57881 : H12AffineEnvironment.transform 2 0 env57880 = env57881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57880 == env57881) = true)

theorem identity57881 : scanCanonicalize (H12AffineFastState.compose env57881 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57882 : List Nat := [0,4,0,1,0,0,1,5,0,5,0,0,0,1,0,1,1,1,5,0,1,1,0,0,1,0,0,1,1,1,5,0,4,1,1,1]

theorem envBound57882 : H12AffineFastState.Bounded env57882 := by
  intro p hp
  have h : env57882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57881_57882 : H12AffineEnvironment.transform 0 0 env57881 = env57882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57881 == env57882) = true)

def env57883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144713,169103,26057,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound57883 : H12AffineFastState.Bounded env57883 := by
  intro p hp
  have h : env57883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57863_57883 : H12AffineEnvironment.transform 17 87425 env57863 = env57883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57863 == env57883) = true)

theorem identity57883 : scanCanonicalize (H12AffineFastState.compose env57883 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 70006) := by decide +kernel

theorem selectedBound57883 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70006,87425,1024,32768,66614,46481,74815,99833,26057,95294,103452,16384,69927,93515,504,28913,257,69730,70006,18240]

theorem envBound57884 : H12AffineFastState.Bounded env57884 := by
  intro p hp
  have h : env57884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57883_57884 : H12AffineEnvironment.transform 16 70006 env57883 = env57884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70006 env57883 == env57884) = true)

def env57885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,70006,69825,1024,32768,66614,46481,74815,99833,8329,78206,103452,1344,69927,75787,504,13745,257,69730,70006,512]

theorem envBound57885 : H12AffineFastState.Bounded env57885 := by
  intro p hp
  have h : env57885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57884_57885 : H12AffineEnvironment.transform 13 1344 env57884 = env57885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57884 == env57885) = true)

theorem identity57885 : scanCanonicalize (H12AffineFastState.compose env57885 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57885 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,66662,67025,1024,32768,66614,41089,74815,99833,8329,74862,98572,1344,66615,75787,504,8353,257,66930,66662,512]

theorem envBound57886 : H12AffineFastState.Bounded env57886 := by
  intro p hp
  have h : env57886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57885_57886 : H12AffineEnvironment.transform 11 1296 env57885 = env57886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57885 == env57886) = true)

def env57887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,70006,69824,1024,32768,66614,46481,74815,99833,8328,78207,103452,1345,69927,75786,504,13744,257,69730,70006,513]

theorem envBound57887 : H12AffineFastState.Bounded env57887 := by
  intro p hp
  have h : env57887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57884_57887 : H12AffineEnvironment.transform 13 1345 env57884 = env57887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57884 == env57887) = true)

theorem identity57887 : scanCanonicalize (H12AffineFastState.compose env57887 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57887 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,34280,33886,1024,32768,37032,46481,45217,4455,8328,42465,130,1345,34233,48276,504,13744,257,34044,34280,513]

theorem envBound57888 : H12AffineFastState.Bounded env57888 := by
  intro p hp
  have h : env57888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57887_57888 : H12AffineEnvironment.transform 15 38046 env57887 = env57888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57887 == env57888) = true)

theorem identity57888 : scanCanonicalize (H12AffineFastState.compose env57888 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9712) := by decide +kernel

theorem selectedBound57888 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9712,12654,8216,8622,1024,9712,13656,4193,5457,4455,8328,17,130,1345,8265,6500,504,13744,257,8460,8216,513]

theorem envBound57889 : H12AffineFastState.Bounded env57889 := by
  intro p hp
  have h : env57889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57888_57889 : H12AffineEnvironment.transform 14 9712 env57888 = env57889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9712 env57888 == env57889) = true)

theorem identity57889 : scanCanonicalize (H12AffineFastState.compose env57889 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound57889 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1108,4298,444,10,1024,1108,5372,4193,5457,4455,300,17,130,1345,493,6500,504,5140,257,168,444,513]

theorem envBound57890 : H12AffineFastState.Bounded env57890 := by
  intro p hp
  have h : env57890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57889_57890 : H12AffineEnvironment.transform 12 420 env57889 = env57890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env57889 == env57890) = true)

theorem identity57890 : scanCanonicalize (H12AffineFastState.compose env57890 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3767) := by decide +kernel

theorem selectedBound57890 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3767,420,1345,1108,3709,444,10,1024,1108,2635,3798,3046,4048,300,17,130,1345,493,2003,504,2723,257,168,444,513]

theorem envBound57891 : H12AffineFastState.Bounded env57891 := by
  intro p hp
  have h : env57891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57890_57891 : H12AffineEnvironment.transform 11 3767 env57890 = env57891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3767 env57890 == env57891) = true)

theorem identity57891 : scanCanonicalize (H12AffineFastState.compose env57891 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1411) := by decide +kernel

theorem selectedBound57891 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1411,820,420,1345,1108,1022,444,10,1024,1108,1992,853,1637,595,300,17,130,1345,493,2003,504,1824,257,168,444,513]

theorem envBound57892 : H12AffineFastState.Bounded env57892 := by
  intro p hp
  have h : env57892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57891_57892 : H12AffineEnvironment.transform 10 1411 env57891 = env57892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1411 env57891 == env57892) = true)

theorem identity57892 : scanCanonicalize (H12AffineFastState.compose env57892 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound57892 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env57893 : List Nat := [2,4,8,16,32,64,128,256,292,1024,1411,16,420,1345,1108,218,444,10,1024,1108,1260,113,1345,375,300,17,130,1345,493,1271,504,1028,257,168,444,293]

theorem envBound57893 : H12AffineFastState.Bounded env57893 := by
  intro p hp
  have h : env57893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57892_57893 : H12AffineEnvironment.transform 8 292 env57892 = env57893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env57892 == env57893) = true)

theorem identity57893 : scanCanonicalize (H12AffineFastState.compose env57893 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 337) := by decide +kernel

theorem selectedBound57893 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57894 : List Nat := [2,4,8,16,32,64,128,256,292,337,210,16,420,16,261,218,444,10,337,261,445,113,16,375,300,17,130,16,493,422,504,341,257,168,444,293]

theorem envBound57894 : H12AffineFastState.Bounded env57894 := by
  intro p hp
  have h : env57894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57893_57894 : H12AffineEnvironment.transform 9 337 env57893 = env57894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env57893 == env57894) = true)

theorem identity57894 : scanCanonicalize (H12AffineFastState.compose env57894 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound57894 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env57895 : List Nat := [2,4,8,16,32,64,83,256,292,337,1,16,375,16,261,9,367,10,337,261,366,113,16,375,300,17,81,16,318,373,299,341,257,123,367,293]

theorem envBound57895 : H12AffineFastState.Bounded env57895 := by
  intro p hp
  have h : env57895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57894_57895 : H12AffineEnvironment.transform 6 83 env57894 = env57895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env57894 == env57895) = true)

theorem identity57895 : scanCanonicalize (H12AffineFastState.compose env57895 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound57895 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57896 : List Nat := [2,4,8,16,32,16,3,256,292,257,1,16,295,16,261,9,319,10,257,261,318,33,16,295,300,17,1,16,318,293,299,261,257,43,319,293]

theorem envBound57896 : H12AffineFastState.Bounded env57896 := by
  intro p hp
  have h : env57896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57895_57896 : H12AffineEnvironment.transform 5 16 env57895 = env57896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57895 == env57896) = true)

theorem identity57896 : scanCanonicalize (H12AffineFastState.compose env57896 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound57896 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57897 : List Nat := [2,4,8,16,32,16,3,62,26,63,1,16,25,16,59,9,1,10,63,59,0,33,16,25,18,17,1,16,0,27,21,59,63,43,1,27]

theorem envBound57897 : H12AffineFastState.Bounded env57897 := by
  intro p hp
  have h : env57897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57896_57897 : H12AffineEnvironment.transform 7 62 env57896 = env57897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env57896 == env57897) = true)

theorem identity57897 : scanCanonicalize (H12AffineFastState.compose env57897 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound57897 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env57898 : List Nat := [2,4,8,11,32,11,3,37,1,36,1,11,2,11,32,9,1,10,36,32,0,33,11,2,9,10,1,11,0,0,14,32,36,43,1,0]

theorem envBound57898 : H12AffineFastState.Bounded env57898 := by
  intro p hp
  have h : env57898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57897_57898 : H12AffineEnvironment.transform 3 11 env57897 = env57898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env57897 == env57898) = true)

theorem identity57898 : scanCanonicalize (H12AffineFastState.compose env57898 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound57898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57899 : List Nat := [2,4,8,11,3,11,3,6,1,7,1,11,2,11,3,9,1,10,7,3,0,2,11,2,9,10,1,11,0,0,14,3,7,8,1,0]

theorem envBound57899 : H12AffineFastState.Bounded env57899 := by
  intro p hp
  have h : env57899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57898_57899 : H12AffineEnvironment.transform 4 3 env57898 = env57899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env57898 == env57899) = true)

theorem identity57899 : scanCanonicalize (H12AffineFastState.compose env57899 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57899 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57900 : List Nat := [0,4,8,9,1,9,1,4,1,5,1,9,0,9,1,9,1,8,5,1,0,0,9,0,9,8,1,9,0,0,12,1,5,8,1,0]

theorem envBound57900 : H12AffineFastState.Bounded env57900 := by
  intro p hp
  have h : env57900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57899_57900 : H12AffineEnvironment.transform 0 0 env57899 = env57900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57899 == env57900) = true)

theorem identity57900 : scanCanonicalize (H12AffineFastState.compose env57900 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57900 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57901 : List Nat := [0,4,0,1,1,1,1,4,1,5,1,1,0,1,1,1,1,0,5,1,0,0,1,0,1,0,1,1,0,0,4,1,5,0,1,0]

theorem envBound57901 : H12AffineFastState.Bounded env57901 := by
  intro p hp
  have h : env57901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57900_57901 : H12AffineEnvironment.transform 2 0 env57900 = env57901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57900 == env57901) = true)

def env57902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144713,169103,26056,157000,311708,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57902 : H12AffineFastState.Bounded env57902 := by
  intro p hp
  have h : env57902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57862_57902 : H12AffineEnvironment.transform 20 136513 env57862 = env57902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57862 == env57902) = true)

def env57903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144713,169103,26056,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57903 : H12AffineFastState.Bounded env57903 := by
  intro p hp
  have h : env57903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57902_57903 : H12AffineEnvironment.transform 17 87424 env57902 = env57903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57902 == env57903) = true)

theorem identity57903 : scanCanonicalize (H12AffineFastState.compose env57903 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 66663) := by decide +kernel

theorem selectedBound57903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,66663,87424,1024,32768,69926,46480,78126,102632,26056,90415,103452,16384,66614,93514,5353,26080,257,69731,66663,18241]

theorem envBound57904 : H12AffineFastState.Bounded env57904 := by
  intro p hp
  have h : env57904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57903_57904 : H12AffineEnvironment.transform 16 66663 env57903 = env57904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 66663 env57903 == env57904) = true)

def env57905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66663,69824,1024,32768,69926,46480,78126,102632,8328,74863,103452,1344,66614,75786,5353,8352,257,69731,66663,513]

theorem envBound57905 : H12AffineFastState.Bounded env57905 := by
  intro p hp
  have h : env57905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57904_57905 : H12AffineEnvironment.transform 13 1344 env57904 = env57905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57904 == env57905) = true)

theorem identity57905 : scanCanonicalize (H12AffineFastState.compose env57905 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57905 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,37112,33887,1024,32768,34233,46480,42417,1143,8328,45296,131,1344,37033,48277,5353,8352,257,34044,37112,513]

theorem envBound57906 : H12AffineFastState.Bounded env57906 := by
  intro p hp
  have h : env57906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57905_57906 : H12AffineEnvironment.transform 15 38047 env57905 = env57906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57905 == env57906) = true)

theorem identity57906 : scanCanonicalize (H12AffineFastState.compose env57906 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57906 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,8217,13502,1024,12513,13656,1393,5456,1143,8328,17,131,1344,8264,3188,5353,8352,257,13341,8217,513]

theorem envBound57907 : H12AffineFastState.Bounded env57907 := by
  intro p hp
  have h : env57907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57906_57907 : H12AffineEnvironment.transform 14 12513 env57906 = env57907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57906 == env57907) = true)

theorem identity57907 : scanCanonicalize (H12AffineFastState.compose env57907 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound57907 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1108,4299,5292,11,1024,1108,493,1393,5456,1143,5181,17,131,1344,5373,3188,5353,5141,257,168,5292,513]

theorem envBound57908 : H12AffineFastState.Bounded env57908 := by
  intro p hp
  have h : env57908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57907_57908 : H12AffineEnvironment.transform 12 5301 env57907 = env57908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env57907 == env57908) = true)

theorem identity57908 : scanCanonicalize (H12AffineFastState.compose env57908 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound57908 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,5301,1344,1108,4299,5292,11,1024,1108,493,1393,5456,1143,5181,17,131,1344,5373,2003,5353,5141,257,168,5292,513]

theorem envBound57909 : H12AffineFastState.Bounded env57909 := by
  intro p hp
  have h : env57909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57908_57909 : H12AffineEnvironment.transform 10 935 env57908 = env57909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env57908 == env57909) = true)

theorem identity57909 : scanCanonicalize (H12AffineFastState.compose env57909 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1992) := by decide +kernel

theorem selectedBound57909 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,1992,893,1344,1108,1795,868,11,1024,1108,493,1393,664,1143,1013,17,131,1344,821,2003,801,989,257,168,868,513]

theorem envBound57910 : H12AffineFastState.Bounded env57910 := by
  intro p hp
  have h : env57910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57909_57910 : H12AffineEnvironment.transform 11 1992 env57909 = env57910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1992 env57909 == env57910) = true)

theorem identity57910 : scanCanonicalize (H12AffineFastState.compose env57910 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound57910 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57911 : List Nat := [2,4,8,16,32,64,128,256,292,1024,131,1260,89,1344,1108,1063,64,11,1024,1108,493,1393,444,1143,209,17,131,1344,17,1271,5,249,257,168,64,293]

theorem envBound57911 : H12AffineFastState.Bounded env57911 := by
  intro p hp
  have h : env57911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57910_57911 : H12AffineEnvironment.transform 8 292 env57910 = env57911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env57910 == env57911) = true)

theorem identity57911 : scanCanonicalize (H12AffineFastState.compose env57911 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound57911 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57912 : List Nat := [2,4,8,16,32,64,128,256,292,172,131,64,89,492,248,139,64,11,172,248,493,477,444,219,209,17,131,492,17,91,5,249,257,168,64,293]

theorem envBound57912 : H12AffineFastState.Bounded env57912 := by
  intro p hp
  have h : env57912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57911_57912 : H12AffineEnvironment.transform 9 172 env57911 = env57912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env57911 == env57912) = true)

theorem identity57912 : scanCanonicalize (H12AffineFastState.compose env57912 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound57912 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57913 : List Nat := [2,4,8,16,32,64,128,252,216,172,131,64,89,16,248,139,64,11,172,248,17,33,64,219,209,17,131,16,17,91,5,249,253,168,64,217]

theorem envBound57913 : H12AffineFastState.Bounded env57913 := by
  intro p hp
  have h : env57913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57912_57913 : H12AffineEnvironment.transform 7 252 env57912 = env57913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env57912 == env57913) = true)

theorem identity57913 : scanCanonicalize (H12AffineFastState.compose env57913 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound57913 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57914 : List Nat := [2,4,8,16,32,64,25,101,65,53,26,64,89,16,97,18,64,11,53,97,17,33,64,66,72,17,26,16,17,91,5,96,100,49,64,64]

theorem envBound57914 : H12AffineFastState.Bounded env57914 := by
  intro p hp
  have h : env57914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57913_57914 : H12AffineEnvironment.transform 6 25 env57913 = env57914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env57913 == env57914) = true)

theorem identity57914 : scanCanonicalize (H12AffineFastState.compose env57914 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound57914 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57915 : List Nat := [2,4,8,16,32,43,25,14,42,53,26,43,50,16,10,18,43,11,53,10,17,33,43,41,35,17,26,16,17,48,5,11,15,49,43,43]

theorem envBound57915 : H12AffineFastState.Bounded env57915 := by
  intro p hp
  have h : env57915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57914_57915 : H12AffineEnvironment.transform 5 43 env57914 = env57915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env57914 == env57915) = true)

theorem identity57915 : scanCanonicalize (H12AffineFastState.compose env57915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound57915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57916 : List Nat := [2,4,8,16,19,24,25,14,25,6,26,24,1,16,10,18,24,11,6,10,17,18,24,26,16,17,26,16,17,3,5,11,15,2,24,24]

theorem envBound57916 : H12AffineFastState.Bounded env57916 := by
  intro p hp
  have h : env57916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57915_57916 : H12AffineEnvironment.transform 4 19 env57915 = env57916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env57915 == env57916) = true)

theorem identity57916 : scanCanonicalize (H12AffineFastState.compose env57916 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57916 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57917 : List Nat := [2,4,8,0,3,8,9,14,9,6,10,8,1,0,10,2,8,11,6,10,1,2,8,10,0,1,10,0,1,3,5,11,15,2,8,8]

theorem envBound57917 : H12AffineFastState.Bounded env57917 := by
  intro p hp
  have h : env57917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57916_57917 : H12AffineEnvironment.transform 3 0 env57916 = env57917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57916 == env57917) = true)

def env57918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66663,69825,1024,32768,69926,46480,78126,102632,8329,74862,103452,1345,66614,75787,5353,8353,257,69731,66663,512]

theorem envBound57918 : H12AffineFastState.Bounded env57918 := by
  intro p hp
  have h : env57918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57904_57918 : H12AffineEnvironment.transform 13 1345 env57904 = env57918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57904 == env57918) = true)

theorem identity57918 : scanCanonicalize (H12AffineFastState.compose env57918 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57918 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66663,67024,1024,32768,66615,41089,74815,99833,8329,74862,98573,1345,66614,75787,504,8353,257,66930,66663,512]

theorem envBound57919 : H12AffineFastState.Bounded env57919 := by
  intro p hp
  have h : env57919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57918_57919 : H12AffineEnvironment.transform 11 1297 env57918 = env57919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57918 == env57919) = true)

def env57920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144713,169103,26056,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound57920 : H12AffineFastState.Bounded env57920 := by
  intro p hp
  have h : env57920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57902_57920 : H12AffineEnvironment.transform 17 87425 env57902 = env57920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57902 == env57920) = true)

theorem identity57920 : scanCanonicalize (H12AffineFastState.compose env57920 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 82215) := by decide +kernel

theorem selectedBound57920 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82215,87425,1024,32768,87142,46480,95342,120232,26056,74863,103453,16384,82294,93514,20905,8352,257,69731,82215,18241]

theorem envBound57921 : H12AffineFastState.Bounded env57921 := by
  intro p hp
  have h : env57921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57920_57921 : H12AffineEnvironment.transform 16 82215 env57920 = env57921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82215 env57920 == env57921) = true)

def env57922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,66663,69825,1024,32768,69926,46480,78126,102632,8328,74863,103453,1344,66614,75786,5353,8352,257,69731,66663,513]

theorem envBound57922 : H12AffineFastState.Bounded env57922 := by
  intro p hp
  have h : env57922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57921_57922 : H12AffineEnvironment.transform 13 1344 env57921 = env57922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57921 == env57922) = true)

theorem identity57922 : scanCanonicalize (H12AffineFastState.compose env57922 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57922 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,37112,33886,1024,32768,34233,46480,42417,1143,8328,45296,130,1344,37033,48277,5353,8352,257,34044,37112,513]

theorem envBound57923 : H12AffineFastState.Bounded env57923 := by
  intro p hp
  have h : env57923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57922_57923 : H12AffineEnvironment.transform 15 38047 env57922 = env57923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57922 == env57923) = true)

theorem identity57923 : scanCanonicalize (H12AffineFastState.compose env57923 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 12513) := by decide +kernel

theorem selectedBound57923 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12513,9342,8217,13503,1024,12513,13656,1393,5456,1143,8328,17,130,1344,8264,3188,5353,8352,257,13341,8217,513]

theorem envBound57924 : H12AffineFastState.Bounded env57924 := by
  intro p hp
  have h : env57924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57923_57924 : H12AffineEnvironment.transform 14 12513 env57923 = env57924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12513 env57923 == env57924) = true)

theorem identity57924 : scanCanonicalize (H12AffineFastState.compose env57924 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound57924 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1108,4299,5292,10,1024,1108,493,1393,5456,1143,5181,17,130,1344,5373,3188,5353,5141,257,168,5292,513]

theorem envBound57925 : H12AffineFastState.Bounded env57925 := by
  intro p hp
  have h : env57925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57924_57925 : H12AffineEnvironment.transform 12 5301 env57924 = env57925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env57924 == env57925) = true)

theorem identity57925 : scanCanonicalize (H12AffineFastState.compose env57925 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 935) := by decide +kernel

theorem selectedBound57925 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,935,4096,5301,1344,1108,4299,5292,10,1024,1108,493,1393,5456,1143,5181,17,130,1344,5373,2003,5353,5141,257,168,5292,513]

theorem envBound57926 : H12AffineFastState.Bounded env57926 := by
  intro p hp
  have h : env57926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57925_57926 : H12AffineEnvironment.transform 10 935 env57925 = env57926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 935 env57925 == env57926) = true)

theorem identity57926 : scanCanonicalize (H12AffineFastState.compose env57926 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound57926 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env57927 : List Nat := [2,4,8,16,32,64,128,256,216,1024,383,4096,5301,1344,1108,4299,5292,10,1024,1108,493,1393,5456,1143,5181,17,130,1344,5373,1291,5353,5141,257,168,5292,217]

theorem envBound57927 : H12AffineFastState.Bounded env57927 := by
  intro p hp
  have h : env57927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57926_57927 : H12AffineEnvironment.transform 8 216 env57926 = env57927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env57926 == env57927) = true)

theorem identity57927 : scanCanonicalize (H12AffineFastState.compose env57927 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound57927 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env57928 : List Nat := [2,4,8,16,32,64,128,253,216,1024,130,4096,5301,1213,1108,4299,5292,10,1024,1108,16,1164,5293,1143,5181,17,130,1213,5373,1270,5353,5141,252,168,5292,217]

theorem envBound57928 : H12AffineFastState.Bounded env57928 := by
  intro p hp
  have h : env57928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57927_57928 : H12AffineEnvironment.transform 7 253 env57927 = env57928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env57927 == env57928) = true)

theorem identity57928 : scanCanonicalize (H12AffineFastState.compose env57928 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound57928 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env57929 : List Nat := [2,4,8,16,32,64,128,253,216,1024,130,64,1269,1213,1108,139,1260,10,1024,1108,16,1164,1261,1143,1149,17,130,1213,1213,1270,1193,1109,252,168,1260,217]

theorem envBound57929 : H12AffineFastState.Bounded env57929 := by
  intro p hp
  have h : env57929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57928_57929 : H12AffineEnvironment.transform 11 64 env57928 = env57929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env57928 == env57929) = true)

theorem identity57929 : scanCanonicalize (H12AffineFastState.compose env57929 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound57929 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57930 : List Nat := [2,4,8,16,32,64,128,253,216,173,130,64,88,16,249,139,65,10,173,249,16,33,64,218,208,17,130,16,16,91,4,248,252,168,65,217]

theorem envBound57930 : H12AffineFastState.Bounded env57930 := by
  intro p hp
  have h : env57930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57929_57930 : H12AffineEnvironment.transform 9 173 env57929 = env57930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env57929 == env57930) = true)

theorem identity57930 : scanCanonicalize (H12AffineFastState.compose env57930 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound57930 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env57931 : List Nat := [2,4,8,16,32,64,25,100,65,52,27,64,88,16,96,18,65,10,52,96,16,33,64,67,73,17,27,16,16,91,4,97,101,49,65,64]

theorem envBound57931 : H12AffineFastState.Bounded env57931 := by
  intro p hp
  have h : env57931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57930_57931 : H12AffineEnvironment.transform 6 25 env57930 = env57931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env57930 == env57931) = true)

theorem identity57931 : scanCanonicalize (H12AffineFastState.compose env57931 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound57931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57932 : List Nat := [2,4,8,16,26,64,25,94,65,14,27,64,88,16,90,18,65,10,14,90,16,27,64,67,73,17,27,16,16,91,4,91,95,11,65,64]

theorem envBound57932 : H12AffineFastState.Bounded env57932 := by
  intro p hp
  have h : env57932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57931_57932 : H12AffineEnvironment.transform 4 26 env57931 = env57932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env57931 == env57932) = true)

theorem identity57932 : scanCanonicalize (H12AffineFastState.compose env57932 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57932 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57933 : List Nat := [2,4,0,16,18,64,17,86,65,6,19,64,80,16,82,18,65,2,6,82,16,19,64,67,65,17,19,16,16,83,4,83,87,3,65,64]

theorem envBound57933 : H12AffineFastState.Bounded env57933 := by
  intro p hp
  have h : env57933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57932_57933 : H12AffineEnvironment.transform 2 0 env57932 = env57933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57932 == env57933) = true)

theorem identity57933 : scanCanonicalize (H12AffineFastState.compose env57933 (packedSelected [0,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57933 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env57934 : List Nat := [2,4,0,16,18,0,17,22,1,6,19,0,16,16,18,18,1,2,6,18,16,19,0,3,1,17,19,16,16,19,4,19,23,3,1,0]

theorem envBound57934 : H12AffineFastState.Bounded env57934 := by
  intro p hp
  have h : env57934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57933_57934 : H12AffineEnvironment.transform 5 0 env57933 = env57934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57933 == env57934) = true)

theorem identity57934 : scanCanonicalize (H12AffineFastState.compose env57934 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57935 : List Nat := [2,4,0,0,2,0,1,6,1,6,3,0,0,0,2,2,1,2,6,2,0,3,0,3,1,1,3,0,0,3,4,3,7,3,1,0]

theorem envBound57935 : H12AffineFastState.Bounded env57935 := by
  intro p hp
  have h : env57935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57934_57935 : H12AffineEnvironment.transform 3 0 env57934 = env57935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57934 == env57935) = true)

theorem identity57935 : scanCanonicalize (H12AffineFastState.compose env57935 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57935 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57936 : List Nat := [0,4,0,0,0,0,1,4,1,4,1,0,0,0,0,0,1,0,4,0,0,1,0,1,1,1,1,0,0,1,4,1,5,1,1,0]

theorem envBound57936 : H12AffineFastState.Bounded env57936 := by
  intro p hp
  have h : env57936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57935_57936 : H12AffineEnvironment.transform 0 0 env57935 = env57936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57935 == env57936) = true)

def env57937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,66662,69824,1024,32768,69927,46480,78127,102633,8329,74863,103453,1345,66615,75787,5352,8352,257,69731,66662,512]

theorem envBound57937 : H12AffineFastState.Bounded env57937 := by
  intro p hp
  have h : env57937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57921_57937 : H12AffineEnvironment.transform 13 1345 env57921 = env57937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57921 == env57937) = true)

theorem identity57937 : scanCanonicalize (H12AffineFastState.compose env57937 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57937 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,66662,67025,1024,32768,66614,41089,74814,99832,8329,74863,98572,1345,66615,75787,505,8352,257,66930,66662,512]

theorem envBound57938 : H12AffineFastState.Bounded env57938 := by
  intro p hp
  have h : env57938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57937_57938 : H12AffineEnvironment.transform 11 1297 env57937 = env57938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57937 == env57938) = true)

def env57939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329752,6304862,4247641,6342041,2544861,16384,131153,4315354,6402143,221575,257,2295074,131072,4256464]

theorem envBound57939 : H12AffineFastState.Bounded env57939 := by
  intro p hp
  have h : env57939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57784_57939 : H12AffineEnvironment.transform 24 4247641 env57784 = env57939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env57784 == env57939) = true)

def env57940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144712,169102,2257033,157001,2544861,16384,131153,2324490,200847,221575,257,2295074,131072,2249216]

theorem envBound57940 : H12AffineFastState.Bounded env57940 := by
  intro p hp
  have h : env57940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57939_57940 : H12AffineEnvironment.transform 21 2269392 env57939 = env57940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env57939 == env57940) = true)

def env57941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144712,169102,26057,157001,311709,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57941 : H12AffineFastState.Bounded env57941 := by
  intro p hp
  have h : env57941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57940_57941 : H12AffineEnvironment.transform 20 136512 env57940 = env57941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env57940 == env57941) = true)

def env57942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144712,169102,26057,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57942 : H12AffineFastState.Bounded env57942 := by
  intro p hp
  have h : env57942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57941_57942 : H12AffineEnvironment.transform 17 87424 env57941 = env57942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57941 == env57942) = true)

theorem identity57942 : scanCanonicalize (H12AffineFastState.compose env57942 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 103714) := by decide +kernel

theorem selectedBound57942 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103714,87424,1024,32768,98402,46480,106602,65964,26057,127083,103453,16384,103795,93514,34221,62629,257,69730,103714,18240]

theorem envBound57943 : H12AffineFastState.Bounded env57943 := by
  intro p hp
  have h : env57943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57942_57943 : H12AffineEnvironment.transform 16 103714 env57942 = env57943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103714 env57942 == env57943) = true)

def env57944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103714,69824,1024,32768,98402,46480,106602,65964,8329,111915,103453,1344,103795,75786,34221,45541,257,69730,103714,512]

theorem envBound57944 : H12AffineFastState.Bounded env57944 := by
  intro p hp
  have h : env57944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57943_57944 : H12AffineEnvironment.transform 13 1344 env57943 = env57944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57943 == env57944) = true)

theorem identity57944 : scanCanonicalize (H12AffineFastState.compose env57944 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57944 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98354,67024,1024,32768,98402,41088,106602,65964,8329,106555,98573,1344,98403,75786,34221,42229,257,66930,98354,512]

theorem envBound57945 : H12AffineFastState.Bounded env57945 := by
  intro p hp
  have h : env57945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57944_57945 : H12AffineEnvironment.transform 11 1296 env57944 = env57945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57944 == env57945) = true)

def env57946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103714,69825,1024,32768,98402,46480,106602,65964,8328,111914,103453,1345,103795,75787,34221,45540,257,69730,103714,513]

theorem envBound57946 : H12AffineFastState.Bounded env57946 := by
  intro p hp
  have h : env57946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57943_57946 : H12AffineEnvironment.transform 13 1345 env57943 = env57946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57943 == env57946) = true)

theorem identity57946 : scanCanonicalize (H12AffineFastState.compose env57946 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57946 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,445,33886,1024,32768,5373,46480,13557,38195,8328,8629,130,1345,492,48276,34221,45540,257,34045,445,513]

theorem envBound57947 : H12AffineFastState.Bounded env57947 := by
  intro p hp
  have h : env57947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57946_57947 : H12AffineEnvironment.transform 15 38047 env57946 = env57947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57946 == env57947) = true)

theorem identity57947 : scanCanonicalize (H12AffineFastState.compose env57947 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound57947 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,32768,38047,445,33886,1024,32768,5373,37941,5456,38195,301,16,130,1345,492,40241,34221,36929,257,34045,445,513]

theorem envBound57948 : H12AffineFastState.Bounded env57948 := by
  intro p hp
  have h : env57948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57947_57948 : H12AffineEnvironment.transform 12 421 env57947 = env57948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env57947 == env57948) = true)

theorem identity57948 : scanCanonicalize (H12AffineFastState.compose env57948 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57948 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1109,4298,445,11,1024,1109,5373,4192,5456,4454,301,16,130,1345,492,6500,504,5140,257,168,445,513]

theorem envBound57949 : H12AffineFastState.Bounded env57949 := by
  intro p hp
  have h : env57949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57948_57949 : H12AffineEnvironment.transform 14 1109 env57948 = env57949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57948 == env57949) = true)

theorem identity57949 : scanCanonicalize (H12AffineFastState.compose env57949 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound57949 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,421,1345,1109,4298,445,11,1024,1109,5373,4192,5456,4454,301,16,130,1345,492,5695,504,5140,257,168,445,513]

theorem envBound57950 : H12AffineFastState.Bounded env57950 := by
  intro p hp
  have h : env57950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57949_57950 : H12AffineEnvironment.transform 10 1883 env57949 = env57950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env57949 == env57950) = true)

theorem identity57950 : scanCanonicalize (H12AffineFastState.compose env57950 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound57950 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,444,421,1345,1109,374,445,11,1024,1109,1345,476,1260,218,301,16,130,1345,492,1923,504,1448,257,168,445,513]

theorem envBound57951 : H12AffineFastState.Bounded env57951 := by
  intro p hp
  have h : env57951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57950_57951 : H12AffineEnvironment.transform 11 444 env57950 = env57951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env57950 == env57951) = true)

theorem identity57951 : scanCanonicalize (H12AffineFastState.compose env57951 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound57951 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env57952 : List Nat := [2,4,8,16,32,64,128,256,512,257,602,444,421,64,340,374,445,11,257,340,64,476,493,218,301,16,130,64,492,642,504,169,257,168,445,513]

theorem envBound57952 : H12AffineFastState.Bounded env57952 := by
  intro p hp
  have h : env57952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57951_57952 : H12AffineEnvironment.transform 9 257 env57951 = env57952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env57951 == env57952) = true)

theorem identity57952 : scanCanonicalize (H12AffineFastState.compose env57952 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57952 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57953 : List Nat := [2,4,8,16,32,64,128,256,217,257,131,444,421,64,340,374,445,11,257,340,64,476,493,218,301,16,130,64,492,91,504,169,257,168,445,216]

theorem envBound57953 : H12AffineFastState.Bounded env57953 := by
  intro p hp
  have h : env57953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57952_57953 : H12AffineEnvironment.transform 8 217 env57952 = env57953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57952 == env57953) = true)

def env57954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144712,169102,26057,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18240]

theorem envBound57954 : H12AffineFastState.Bounded env57954 := by
  intro p hp
  have h : env57954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57941_57954 : H12AffineEnvironment.transform 17 87425 env57941 = env57954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57941 == env57954) = true)

theorem identity57954 : scanCanonicalize (H12AffineFastState.compose env57954 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 118883) := by decide +kernel

theorem selectedBound57954 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,118883,87425,1024,32768,116003,46480,124203,83181,26057,111914,103452,16384,118834,93514,49388,45540,257,69730,118883,18240]

theorem envBound57955 : H12AffineFastState.Bounded env57955 := by
  intro p hp
  have h : env57955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57954_57955 : H12AffineEnvironment.transform 16 118883 env57954 = env57955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 118883 env57954 == env57955) = true)

def env57956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,103715,69825,1024,32768,98403,46480,106603,65965,8329,111914,103452,1344,103794,75786,34220,45540,257,69730,103715,512]

theorem envBound57956 : H12AffineFastState.Bounded env57956 := by
  intro p hp
  have h : env57956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57955_57956 : H12AffineEnvironment.transform 13 1344 env57955 = env57956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57955 == env57956) = true)

theorem identity57956 : scanCanonicalize (H12AffineFastState.compose env57956 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound57956 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,98355,67025,1024,32768,98403,41088,106603,65965,8329,106554,98572,1344,98402,75786,34220,42228,257,66930,98355,512]

theorem envBound57957 : H12AffineFastState.Bounded env57957 := by
  intro p hp
  have h : env57957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57956_57957 : H12AffineEnvironment.transform 11 1296 env57956 = env57957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env57956 == env57957) = true)

def env57958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,103714,69824,1024,32768,98402,46480,106602,65964,8328,111914,103452,1345,103795,75787,34221,45540,257,69730,103714,513]

theorem envBound57958 : H12AffineFastState.Bounded env57958 := by
  intro p hp
  have h : env57958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57955_57958 : H12AffineEnvironment.transform 13 1345 env57955 = env57958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57955 == env57958) = true)

theorem identity57958 : scanCanonicalize (H12AffineFastState.compose env57958 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound57958 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38047,445,33887,1024,32768,5373,46480,13557,38195,8328,8629,131,1345,492,48276,34221,45540,257,34045,445,513]

theorem envBound57959 : H12AffineFastState.Bounded env57959 := by
  intro p hp
  have h : env57959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57958_57959 : H12AffineEnvironment.transform 15 38047 env57958 = env57959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env57958 == env57959) = true)

theorem identity57959 : scanCanonicalize (H12AffineFastState.compose env57959 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound57959 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,32768,38047,445,33887,1024,32768,5373,37941,5456,38195,301,16,131,1345,492,40241,34221,36929,257,34045,445,513]

theorem envBound57960 : H12AffineFastState.Bounded env57960 := by
  intro p hp
  have h : env57960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57959_57960 : H12AffineEnvironment.transform 12 421 env57959 = env57960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env57959 == env57960) = true)

theorem identity57960 : scanCanonicalize (H12AffineFastState.compose env57960 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57960 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1109,4298,445,10,1024,1109,5373,4192,5456,4454,301,16,131,1345,492,6500,504,5140,257,168,445,513]

theorem envBound57961 : H12AffineFastState.Bounded env57961 := by
  intro p hp
  have h : env57961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57960_57961 : H12AffineEnvironment.transform 14 1109 env57960 = env57961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57960 == env57961) = true)

theorem identity57961 : scanCanonicalize (H12AffineFastState.compose env57961 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound57961 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,421,1345,1109,4298,445,10,1024,1109,5373,4192,5456,4454,301,16,131,1345,492,5695,504,5140,257,168,445,513]

theorem envBound57962 : H12AffineFastState.Bounded env57962 := by
  intro p hp
  have h : env57962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57961_57962 : H12AffineEnvironment.transform 10 1883 env57961 = env57962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env57961 == env57962) = true)

theorem identity57962 : scanCanonicalize (H12AffineFastState.compose env57962 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound57962 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57963 : List Nat := [2,4,8,16,32,64,128,256,512,172,1015,4096,421,493,249,4298,445,10,172,249,4177,4192,4604,4454,301,16,131,493,492,4755,504,4280,257,168,445,513]

theorem envBound57963 : H12AffineFastState.Bounded env57963 := by
  intro p hp
  have h : env57963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57962_57963 : H12AffineEnvironment.transform 9 172 env57962 = env57963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env57962 == env57963) = true)

theorem identity57963 : scanCanonicalize (H12AffineFastState.compose env57963 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound57963 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env57964 : List Nat := [2,4,8,16,32,64,128,256,512,172,1015,17,421,493,249,219,445,10,172,249,64,113,493,375,301,16,131,493,492,642,504,169,257,168,445,513]

theorem envBound57964 : H12AffineFastState.Bounded env57964 := by
  intro p hp
  have h : env57964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57963_57964 : H12AffineEnvironment.transform 11 17 env57963 = env57964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env57963 == env57964) = true)

theorem identity57964 : scanCanonicalize (H12AffineFastState.compose env57964 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound57964 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57965 : List Nat := [2,4,8,16,32,64,128,256,217,172,302,17,421,493,249,219,445,10,172,249,64,113,493,375,301,16,131,493,492,91,504,169,257,168,445,216]

theorem envBound57965 : H12AffineFastState.Bounded env57965 := by
  intro p hp
  have h : env57965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57964_57965 : H12AffineEnvironment.transform 8 217 env57964 = env57965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env57964 == env57965) = true)

theorem identity57965 : scanCanonicalize (H12AffineFastState.compose env57965 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57965 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57966 : List Nat := [2,4,8,16,32,64,128,172,217,172,130,17,9,65,249,219,17,10,172,249,64,113,65,219,129,16,131,65,64,91,84,169,173,168,17,216]

theorem envBound57966 : H12AffineFastState.Bounded env57966 := by
  intro p hp
  have h : env57966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57965_57966 : H12AffineEnvironment.transform 7 172 env57965 = env57966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57965 == env57966) = true)

theorem identity57966 : scanCanonicalize (H12AffineFastState.compose env57966 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound57966 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57967 : List Nat := [2,4,8,16,26,64,128,150,217,150,130,17,9,65,195,219,17,10,150,195,64,75,65,219,129,16,131,65,64,91,84,147,151,146,17,216]

theorem envBound57967 : H12AffineFastState.Bounded env57967 := by
  intro p hp
  have h : env57967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57966_57967 : H12AffineEnvironment.transform 4 26 env57966 = env57967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env57966 == env57967) = true)

theorem identity57967 : scanCanonicalize (H12AffineFastState.compose env57967 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound57967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57968 : List Nat := [2,4,8,16,26,64,73,95,16,95,75,17,9,65,10,18,17,10,95,10,64,75,65,18,72,16,74,65,64,91,84,90,94,91,17,17]

theorem envBound57968 : H12AffineFastState.Bounded env57968 := by
  intro p hp
  have h : env57968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57967_57968 : H12AffineEnvironment.transform 6 73 env57967 = env57968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env57967 == env57968) = true)

theorem identity57968 : scanCanonicalize (H12AffineFastState.compose env57968 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound57968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57969 : List Nat := [2,4,8,2,8,64,73,77,2,77,75,3,9,65,10,0,3,10,77,10,64,75,65,0,72,2,74,65,64,73,70,72,76,73,3,3]

theorem envBound57969 : H12AffineFastState.Bounded env57969 := by
  intro p hp
  have h : env57969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57968_57969 : H12AffineEnvironment.transform 3 2 env57968 = env57969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env57968 == env57969) = true)

def env57970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144712,169102,26056,157001,311708,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57970 : H12AffineFastState.Bounded env57970 := by
  intro p hp
  have h : env57970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57940_57970 : H12AffineEnvironment.transform 20 136513 env57940 = env57970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env57940 == env57970) = true)

def env57971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144712,169102,26056,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57971 : H12AffineFastState.Bounded env57971 := by
  intro p hp
  have h : env57971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57970_57971 : H12AffineEnvironment.transform 17 87424 env57970 = env57971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env57970 == env57971) = true)

theorem identity57971 : scanCanonicalize (H12AffineFastState.compose env57971 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 116083) := by decide +kernel

theorem selectedBound57971 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,116083,87424,1024,32768,118834,46481,127035,86525,26056,106554,103452,16384,116002,93515,54780,42228,257,69731,116083,18241]

theorem envBound57972 : H12AffineFastState.Bounded env57972 := by
  intro p hp
  have h : env57972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57971_57972 : H12AffineEnvironment.transform 16 116083 env57971 = env57972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 116083 env57971 == env57972) = true)

def env57973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98355,69824,1024,32768,103794,46481,111995,70845,8328,106554,103452,1344,98402,75787,37052,42228,257,69731,98355,513]

theorem envBound57973 : H12AffineFastState.Bounded env57973 := by
  intro p hp
  have h : env57973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57972_57973 : H12AffineEnvironment.transform 13 1344 env57972 = env57973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57972 == env57973) = true)

theorem identity57973 : scanCanonicalize (H12AffineFastState.compose env57973 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57973 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,5293,33886,1024,32768,492,46481,8677,32803,8328,13476,130,1344,5372,48277,37052,42228,257,34045,5293,513]

theorem envBound57974 : H12AffineFastState.Bounded env57974 := by
  intro p hp
  have h : env57974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57973_57974 : H12AffineEnvironment.transform 15 38046 env57973 = env57974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57973 == env57974) = true)

theorem identity57974 : scanCanonicalize (H12AffineFastState.compose env57974 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound57974 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,32768,38046,5293,33886,1024,32768,492,33061,5457,32803,5180,16,130,1344,5372,34849,37052,36928,257,34045,5293,513]

theorem envBound57975 : H12AffineFastState.Bounded env57975 := by
  intro p hp
  have h : env57975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57974_57975 : H12AffineEnvironment.transform 12 5300 env57974 = env57975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env57974 == env57975) = true)

theorem identity57975 : scanCanonicalize (H12AffineFastState.compose env57975 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57975 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1109,4299,5293,11,1024,1109,492,1392,5457,1142,5180,16,130,1344,5372,3188,5353,5141,257,168,5293,513]

theorem envBound57976 : H12AffineFastState.Bounded env57976 := by
  intro p hp
  have h : env57976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57975_57976 : H12AffineEnvironment.transform 14 1109 env57975 = env57976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57975 == env57976) = true)

theorem identity57976 : scanCanonicalize (H12AffineFastState.compose env57976 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound57976 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,5300,1344,1109,4299,5293,11,1024,1109,492,1392,5457,1142,5180,16,130,1344,5372,815,5353,5141,257,168,5293,513]

theorem envBound57977 : H12AffineFastState.Bounded env57977 := by
  intro p hp
  have h : env57977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57976_57977 : H12AffineEnvironment.transform 10 1883 env57976 = env57977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env57976 == env57977) = true)

theorem identity57977 : scanCanonicalize (H12AffineFastState.compose env57977 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound57977 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1344,500,1344,1109,1419,493,11,1024,1109,492,1392,17,1142,380,16,130,1344,444,815,425,341,257,168,493,513]

theorem envBound57978 : H12AffineFastState.Bounded env57978 := by
  intro p hp
  have h : env57978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57977_57978 : H12AffineEnvironment.transform 11 1344 env57977 = env57978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env57977 == env57978) = true)

theorem identity57978 : scanCanonicalize (H12AffineFastState.compose env57978 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound57978 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57979 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1702,1213,9,1213,1109,1142,16,11,1024,1109,17,1165,17,1142,129,16,130,1213,65,722,84,168,252,168,16,513]

theorem envBound57979 : H12AffineFastState.Bounded env57979 := by
  intro p hp
  have h : env57979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57978_57979 : H12AffineEnvironment.transform 7 253 env57978 = env57979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env57978 == env57979) = true)

theorem identity57979 : scanCanonicalize (H12AffineFastState.compose env57979 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57979 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57980 : List Nat := [2,4,8,16,32,64,128,253,512,549,131,664,9,664,624,595,16,11,549,624,17,680,17,595,129,16,130,664,65,722,84,168,252,168,16,513]

theorem envBound57980 : H12AffineFastState.Bounded env57980 := by
  intro p hp
  have h : env57980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57979_57980 : H12AffineEnvironment.transform 9 549 env57979 = env57980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57979 == env57980) = true)

theorem identity57980 : scanCanonicalize (H12AffineFastState.compose env57980 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound57980 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env57981 : List Nat := [2,4,8,16,32,32,128,157,512,549,131,664,9,664,528,563,16,11,549,528,17,680,17,563,129,16,130,664,33,690,52,168,156,168,16,513]

theorem envBound57981 : H12AffineFastState.Bounded env57981 := by
  intro p hp
  have h : env57981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57980_57981 : H12AffineEnvironment.transform 5 32 env57980 = env57981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env57980 == env57981) = true)

theorem identity57981 : scanCanonicalize (H12AffineFastState.compose env57981 (packedSelected [3,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound57981 : packedSelected [3,8,11] rootPS < 2^1333 := by decide +kernel

def env57982 : List Nat := [2,4,8,16,32,32,57,36,512,549,58,545,9,545,528,563,16,11,549,528,17,529,17,563,56,16,59,545,33,523,52,17,37,17,16,513]

theorem envBound57982 : H12AffineFastState.Bounded env57982 := by
  intro p hp
  have h : env57982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57981_57982 : H12AffineEnvironment.transform 6 57 env57981 = env57982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env57981 == env57982) = true)

theorem identity57982 : scanCanonicalize (H12AffineFastState.compose env57982 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 50) := by decide +kernel

theorem selectedBound57982 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57983 : List Nat := [2,4,8,16,32,32,57,36,50,23,58,19,9,19,34,1,16,11,23,34,17,35,17,1,56,16,59,19,33,57,52,17,37,17,16,51]

theorem envBound57983 : H12AffineFastState.Bounded env57983 := by
  intro p hp
  have h : env57983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57982_57983 : H12AffineEnvironment.transform 8 50 env57982 = env57983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 50 env57982 == env57983) = true)

theorem identity57983 : scanCanonicalize (H12AffineFastState.compose env57983 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57983 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env57984 : List Nat := [2,4,8,16,10,10,19,14,24,23,16,19,9,19,8,1,16,11,23,8,17,9,17,1,18,16,17,19,11,19,30,17,15,17,16,25]

theorem envBound57984 : H12AffineFastState.Bounded env57984 := by
  intro p hp
  have h : env57984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57983_57984 : H12AffineEnvironment.transform 4 10 env57983 = env57984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57983 == env57984) = true)

theorem identity57984 : scanCanonicalize (H12AffineFastState.compose env57984 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound57984 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57985 : List Nat := [2,4,8,9,10,10,10,14,1,14,9,10,9,10,8,1,9,11,14,8,8,9,8,1,11,9,8,10,11,10,7,8,15,8,9,0]

theorem envBound57985 : H12AffineFastState.Bounded env57985 := by
  intro p hp
  have h : env57985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57984_57985 : H12AffineEnvironment.transform 3 9 env57984 = env57985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env57984 == env57985) = true)

def env57986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98354,69825,1024,32768,103795,46481,111994,70844,8329,106554,103452,1345,98403,75786,37053,42228,257,69731,98354,512]

theorem envBound57986 : H12AffineFastState.Bounded env57986 := by
  intro p hp
  have h : env57986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57972_57986 : H12AffineEnvironment.transform 13 1345 env57972 = env57986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57972 == env57986) = true)

theorem identity57986 : scanCanonicalize (H12AffineFastState.compose env57986 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound57986 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98354,67024,1024,32768,98402,41088,106603,65965,8329,106554,98573,1345,98403,75786,34220,42228,257,66930,98354,512]

theorem envBound57987 : H12AffineFastState.Bounded env57987 := by
  intro p hp
  have h : env57987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57986_57987 : H12AffineEnvironment.transform 11 1297 env57986 = env57987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env57986 == env57987) = true)

def env57988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144712,169102,26056,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound57988 : H12AffineFastState.Bounded env57988 := by
  intro p hp
  have h : env57988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57970_57988 : H12AffineEnvironment.transform 17 87425 env57970 = env57988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env57970 == env57988) = true)

theorem identity57988 : scanCanonicalize (H12AffineFastState.compose env57988 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 98355) := by decide +kernel

theorem selectedBound57988 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,98355,87425,1024,32768,103794,46481,111995,70845,26056,124282,103453,16384,98402,93515,37052,57780,257,69731,98355,18241]

theorem envBound57989 : H12AffineFastState.Bounded env57989 := by
  intro p hp
  have h : env57989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57988_57989 : H12AffineEnvironment.transform 16 98355 env57988 = env57989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 98355 env57988 == env57989) = true)

def env57990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,98355,69825,1024,32768,103794,46481,111995,70845,8328,106554,103453,1344,98402,75787,37052,42228,257,69731,98355,513]

theorem envBound57990 : H12AffineFastState.Bounded env57990 := by
  intro p hp
  have h : env57990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57989_57990 : H12AffineEnvironment.transform 13 1344 env57989 = env57990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env57989 == env57990) = true)

theorem identity57990 : scanCanonicalize (H12AffineFastState.compose env57990 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound57990 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env57991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38046,5293,33887,1024,32768,492,46481,8677,32803,8328,13476,131,1344,5372,48277,37052,42228,257,34045,5293,513]

theorem envBound57991 : H12AffineFastState.Bounded env57991 := by
  intro p hp
  have h : env57991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57990_57991 : H12AffineEnvironment.transform 15 38046 env57990 = env57991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env57990 == env57991) = true)

theorem identity57991 : scanCanonicalize (H12AffineFastState.compose env57991 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound57991 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env57992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,32768,38046,5293,33887,1024,32768,492,33061,5457,32803,5180,16,131,1344,5372,34849,37052,36928,257,34045,5293,513]

theorem envBound57992 : H12AffineFastState.Bounded env57992 := by
  intro p hp
  have h : env57992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57991_57992 : H12AffineEnvironment.transform 12 5300 env57991 = env57992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env57991 == env57992) = true)

theorem identity57992 : scanCanonicalize (H12AffineFastState.compose env57992 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound57992 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env57993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1109,4299,5293,10,1024,1109,492,1392,5457,1142,5180,16,131,1344,5372,3188,5353,5141,257,168,5293,513]

theorem envBound57993 : H12AffineFastState.Bounded env57993 := by
  intro p hp
  have h : env57993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57992_57993 : H12AffineEnvironment.transform 14 1109 env57992 = env57993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env57992 == env57993) = true)

theorem identity57993 : scanCanonicalize (H12AffineFastState.compose env57993 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound57993 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,4096,5300,1344,1109,4299,5293,10,1024,1109,492,1392,5457,1142,5180,16,131,1344,5372,815,5353,5141,257,168,5293,513]

theorem envBound57994 : H12AffineFastState.Bounded env57994 := by
  intro p hp
  have h : env57994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57993_57994 : H12AffineEnvironment.transform 10 1883 env57993 = env57994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env57993 == env57994) = true)

theorem identity57994 : scanCanonicalize (H12AffineFastState.compose env57994 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound57994 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env57995 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1802,4096,5300,1297,1028,4250,5293,10,1024,1028,445,1313,5376,1063,5180,16,131,1297,5293,815,5304,5141,257,168,5293,513]

theorem envBound57995 : H12AffineFastState.Bounded env57995 := by
  intro p hp
  have h : env57995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57994_57995 : H12AffineEnvironment.transform 5 17 env57994 = env57995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env57994 == env57995) = true)

theorem identity57995 : scanCanonicalize (H12AffineFastState.compose env57995 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57995 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env57996 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1802,1213,9,1297,1028,1063,16,10,1024,1028,445,1313,445,1063,129,16,131,1297,16,815,5,168,257,168,16,513]

theorem envBound57996 : H12AffineFastState.Bounded env57996 := by
  intro p hp
  have h : env57996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57995_57996 : H12AffineEnvironment.transform 11 1213 env57995 = env57996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env57995 == env57996) = true)

theorem identity57996 : scanCanonicalize (H12AffineFastState.compose env57996 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound57996 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env57997 : List Nat := [2,4,8,16,32,17,128,256,512,549,303,664,9,820,545,514,16,10,549,545,445,772,445,514,129,16,131,820,16,815,5,168,257,168,16,513]

theorem envBound57997 : H12AffineFastState.Bounded env57997 := by
  intro p hp
  have h : env57997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57996_57997 : H12AffineEnvironment.transform 9 549 env57996 = env57997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env57996 == env57997) = true)

theorem identity57997 : scanCanonicalize (H12AffineFastState.compose env57997 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound57997 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env57998 : List Nat := [2,4,8,16,32,17,128,172,512,549,131,664,9,664,545,514,16,10,549,545,17,680,17,514,129,16,131,664,16,643,5,168,173,168,16,513]

theorem envBound57998 : H12AffineFastState.Bounded env57998 := by
  intro p hp
  have h : env57998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57997_57998 : H12AffineEnvironment.transform 7 172 env57997 = env57998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57997 == env57998) = true)

theorem identity57998 : scanCanonicalize (H12AffineFastState.compose env57998 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound57998 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env57999 : List Nat := [2,4,8,16,32,17,128,172,162,135,131,58,9,58,131,160,16,10,135,131,17,10,17,160,129,16,131,58,16,33,5,168,173,168,16,163]

theorem envBound57999 : H12AffineFastState.Bounded env57999 := by
  intro p hp
  have h : env57999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57998_57999 : H12AffineEnvironment.transform 8 162 env57998 = env57999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env57998 == env57999) = true)

theorem identity57999 : scanCanonicalize (H12AffineFastState.compose env57999 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound57999 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58000 : List Nat := [2,4,8,16,32,17,26,54,56,29,25,58,9,58,25,58,16,10,29,25,17,10,17,58,27,16,25,58,16,33,5,50,55,50,16,57]

theorem envBound58000 : H12AffineFastState.Bounded env58000 := by
  intro p hp
  have h : env58000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57999_58000 : H12AffineEnvironment.transform 6 26 env57999 = env58000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env57999 == env58000) = true)

theorem identity58000 : scanCanonicalize (H12AffineFastState.compose env58000 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound58000 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58001 : List Nat := [2,4,8,9,32,8,3,47,33,4,0,35,9,35,0,35,9,10,4,0,8,10,8,35,2,9,0,35,9,33,5,43,46,43,9,32]

theorem envBound58001 : H12AffineFastState.Bounded env58001 := by
  intro p hp
  have h : env58001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58000_58001 : H12AffineEnvironment.transform 3 9 env58000 = env58001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env58000 == env58001) = true)

theorem identity58001 : scanCanonicalize (H12AffineFastState.compose env58001 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58002 : List Nat := [2,4,8,9,10,8,3,5,11,4,0,9,9,9,0,9,9,10,4,0,8,10,8,9,2,9,0,9,9,11,5,1,4,1,9,10]

theorem envBound58002 : H12AffineFastState.Bounded env58002 := by
  intro p hp
  have h : env58002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58001_58002 : H12AffineEnvironment.transform 4 10 env58001 = env58002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58001 == env58002) = true)

theorem identity58002 : scanCanonicalize (H12AffineFastState.compose env58002 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58003 : List Nat := [2,4,3,2,1,3,3,5,0,4,0,2,2,2,0,2,2,1,4,0,3,1,3,2,2,2,0,2,2,0,5,1,4,1,2,1]

theorem envBound58003 : H12AffineFastState.Bounded env58003 := by
  intro p hp
  have h : env58003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58002_58003 : H12AffineEnvironment.transform 2 3 env58002 = env58003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58002 == env58003) = true)

theorem identity58003 : scanCanonicalize (H12AffineFastState.compose env58003 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58003 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58004 : List Nat := [0,4,1,0,1,1,1,5,0,4,0,0,0,0,0,0,0,1,4,0,1,1,1,0,0,0,0,0,0,0,5,1,4,1,0,1]

theorem envBound58004 : H12AffineFastState.Bounded env58004 := by
  intro p hp
  have h : env58004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58003_58004 : H12AffineEnvironment.transform 0 0 env58003 = env58004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58003 == env58004) = true)

def env58005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,98355,69824,1024,32768,103794,46481,111995,70845,8329,106555,103453,1345,98402,75786,37052,42229,257,69731,98355,512]

theorem envBound58005 : H12AffineFastState.Bounded env58005 := by
  intro p hp
  have h : env58005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57989_58005 : H12AffineEnvironment.transform 13 1345 env57989 = env58005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env57989 == env58005) = true)

theorem identity58005 : scanCanonicalize (H12AffineFastState.compose env58005 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58005 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,98355,67025,1024,32768,98403,41088,106602,65964,8329,106555,98572,1345,98402,75786,34221,42229,257,66930,98355,512]

theorem envBound58006 : H12AffineFastState.Bounded env58006 := by
  intro p hp
  have h : env58006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58005_58006 : H12AffineEnvironment.transform 11 1297 env58005 = env58006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58005 == env58006) = true)

def env58007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144713,169103,2257032,157000,2544861,16384,131153,2324491,200846,221575,257,2295074,131072,2249217]

theorem envBound58007 : H12AffineFastState.Bounded env58007 := by
  intro p hp
  have h : env58007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57939_58007 : H12AffineEnvironment.transform 21 2269393 env57939 = env58007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env57939 == env58007) = true)

def env58008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144713,169103,26056,157000,311709,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58008 : H12AffineFastState.Bounded env58008 := by
  intro p hp
  have h : env58008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58007_58008 : H12AffineEnvironment.transform 20 136512 env58007 = env58008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58007 == env58008) = true)

def env58009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144713,169103,26056,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58009 : H12AffineFastState.Bounded env58009 := by
  intro p hp
  have h : env58009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58008_58009 : H12AffineEnvironment.transform 17 87424 env58008 = env58009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58008 == env58009) = true)

theorem identity58009 : scanCanonicalize (H12AffineFastState.compose env58009 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 107883) := by decide +kernel

theorem selectedBound58009 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,107883,87424,1024,32768,110635,46481,102434,78308,26056,114723,103453,16384,107834,93515,46565,50412,257,69730,107883,18241]

theorem envBound58010 : H12AffineFastState.Bounded env58010 := by
  intro p hp
  have h : env58010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58009_58010 : H12AffineEnvironment.transform 16 107883 env58009 = env58010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 107883 env58009 == env58010) = true)

def env58011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107883,69824,1024,32768,110635,46481,102434,78308,8328,99683,103453,1344,107834,75787,46565,33196,257,69730,107883,513]

theorem envBound58011 : H12AffineFastState.Bounded env58011 := by
  intro p hp
  have h : env58011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58010_58011 : H12AffineEnvironment.transform 13 1344 env58010 = env58011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58010 == env58011) = true)

theorem identity58011 : scanCanonicalize (H12AffineFastState.compose env58011 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58011 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,12788,33887,1024,32768,9396,46481,1213,42363,8328,4604,130,1344,12709,48276,46565,33196,257,34045,12788,513]

theorem envBound58012 : H12AffineFastState.Bounded env58012 := by
  intro p hp
  have h : env58012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58011_58012 : H12AffineEnvironment.transform 15 38047 env58011 = env58012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58011 == env58012) = true)

theorem identity58012 : scanCanonicalize (H12AffineFastState.compose env58012 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound58012 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,32768,34162,8217,33887,1024,32768,9396,42108,1213,42363,8328,17,130,1344,8264,44409,41992,33196,257,34045,8217,513]

theorem envBound58013 : H12AffineFastState.Bounded env58013 := by
  intro p hp
  have h : env58013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58012_58013 : H12AffineEnvironment.transform 11 493 env58012 = env58013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58012 == env58013) = true)

theorem identity58013 : scanCanonicalize (H12AffineFastState.compose env58013 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58013 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1108,294,8217,11,1024,1108,9396,8232,1213,8495,8328,17,130,1344,8264,10541,8284,1528,257,169,8217,513]

theorem envBound58014 : H12AffineFastState.Bounded env58014 := by
  intro p hp
  have h : env58014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58013_58014 : H12AffineEnvironment.transform 14 1108 env58013 = env58014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58013 == env58014) = true)

theorem identity58014 : scanCanonicalize (H12AffineFastState.compose env58014 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound58014 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,8192,1344,1108,294,8217,11,1024,1108,9396,8232,1213,8495,8328,17,130,1344,8264,10203,8284,1528,257,169,8217,513]

theorem envBound58015 : H12AffineFastState.Bounded env58015 := by
  intro p hp
  have h : env58015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58014_58015 : H12AffineEnvironment.transform 10 1782 env58014 = env58015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env58014 == env58015) = true)

theorem identity58015 : scanCanonicalize (H12AffineFastState.compose env58015 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58015 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,420,1344,1108,294,445,11,1024,1108,1296,396,1213,139,300,17,130,1344,492,1663,504,1528,257,169,445,513]

theorem envBound58016 : H12AffineFastState.Bounded env58016 := by
  intro p hp
  have h : env58016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58015_58016 : H12AffineEnvironment.transform 12 420 env58015 = env58016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58015 == env58016) = true)

theorem identity58016 : scanCanonicalize (H12AffineFastState.compose env58016 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58016 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58017 : List Nat := [2,4,8,16,32,64,128,256,372,1024,1410,493,420,1344,1108,294,445,11,1024,1108,1296,396,1213,139,300,17,130,1344,492,1291,504,1528,257,169,445,373]

theorem envBound58017 : H12AffineFastState.Bounded env58017 := by
  intro p hp
  have h : env58017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58016_58017 : H12AffineEnvironment.transform 8 372 env58016 = env58017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58016 == env58017) = true)

theorem identity58017 : scanCanonicalize (H12AffineFastState.compose env58017 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58017 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58018 : List Nat := [2,4,8,16,32,64,128,15,123,1024,1165,226,171,1103,1108,41,178,11,1024,1108,1055,131,1213,139,35,17,130,1103,227,1028,247,1271,14,169,178,122]

theorem envBound58018 : H12AffineFastState.Bounded env58018 := by
  intro p hp
  have h : env58018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58017_58018 : H12AffineEnvironment.transform 7 15 env58017 = env58018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58017 == env58018) = true)

def env58019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107883,69825,1024,32768,110635,46481,102434,78308,8329,99682,103453,1345,107834,75786,46565,33197,257,69730,107883,512]

theorem envBound58019 : H12AffineFastState.Bounded env58019 := by
  intro p hp
  have h : env58019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58010_58019 : H12AffineEnvironment.transform 13 1345 env58010 = env58019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58010 == env58019) = true)

theorem identity58019 : scanCanonicalize (H12AffineFastState.compose env58019 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58019 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107883,67024,1024,32768,107834,41088,99635,74997,8329,99682,98572,1345,107834,75786,41204,33197,257,66931,107883,512]

theorem envBound58020 : H12AffineFastState.Bounded env58020 := by
  intro p hp
  have h : env58020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58019_58020 : H12AffineEnvironment.transform 11 1297 env58019 = env58020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58019 == env58020) = true)

def env58021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144713,169103,26056,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58021 : H12AffineFastState.Bounded env58021 := by
  intro p hp
  have h : env58021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58008_58021 : H12AffineEnvironment.transform 17 87425 env58008 = env58021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58008 == env58021) = true)

theorem identity58021 : scanCanonicalize (H12AffineFastState.compose env58021 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 122923) := by decide +kernel

theorem selectedBound58021 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122923,87425,1024,32768,128363,46481,120162,95396,26056,99683,103452,16384,123002,93515,61605,33196,257,69730,122923,18241]

theorem envBound58022 : H12AffineFastState.Bounded env58022 := by
  intro p hp
  have h : env58022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58021_58022 : H12AffineEnvironment.transform 16 122923 env58021 = env58022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122923 env58021 == env58022) = true)

def env58023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,107883,69825,1024,32768,110635,46481,102434,78308,8328,99683,103452,1344,107834,75787,46565,33196,257,69730,107883,513]

theorem envBound58023 : H12AffineFastState.Bounded env58023 := by
  intro p hp
  have h : env58023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58022_58023 : H12AffineEnvironment.transform 13 1344 env58022 = env58023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58022 == env58023) = true)

theorem identity58023 : scanCanonicalize (H12AffineFastState.compose env58023 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58023 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,38047,12788,33886,1024,32768,9396,46481,1213,42363,8328,4604,131,1344,12709,48276,46565,33196,257,34045,12788,513]

theorem envBound58024 : H12AffineFastState.Bounded env58024 := by
  intro p hp
  have h : env58024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58023_58024 : H12AffineEnvironment.transform 15 38047 env58023 = env58024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58023 == env58024) = true)

theorem identity58024 : scanCanonicalize (H12AffineFastState.compose env58024 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound58024 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,32768,34162,8217,33886,1024,32768,9396,42108,1213,42363,8328,17,131,1344,8264,44409,41992,33196,257,34045,8217,513]

theorem envBound58025 : H12AffineFastState.Bounded env58025 := by
  intro p hp
  have h : env58025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58024_58025 : H12AffineEnvironment.transform 11 493 env58024 = env58025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58024 == env58025) = true)

theorem identity58025 : scanCanonicalize (H12AffineFastState.compose env58025 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58025 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1344,1108,294,8217,10,1024,1108,9396,8232,1213,8495,8328,17,131,1344,8264,10541,8284,1528,257,169,8217,513]

theorem envBound58026 : H12AffineFastState.Bounded env58026 := by
  intro p hp
  have h : env58026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58025_58026 : H12AffineEnvironment.transform 14 1108 env58025 = env58026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58025 == env58026) = true)

theorem identity58026 : scanCanonicalize (H12AffineFastState.compose env58026 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound58026 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,8192,1344,1108,294,8217,10,1024,1108,9396,8232,1213,8495,8328,17,131,1344,8264,10203,8284,1528,257,169,8217,513]

theorem envBound58027 : H12AffineFastState.Bounded env58027 := by
  intro p hp
  have h : env58027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58026_58027 : H12AffineEnvironment.transform 10 1782 env58026 = env58027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env58026 == env58027) = true)

theorem identity58027 : scanCanonicalize (H12AffineFastState.compose env58027 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58027 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,493,420,1344,1108,294,445,10,1024,1108,1296,396,1213,139,300,17,131,1344,492,1663,504,1528,257,169,445,513]

theorem envBound58028 : H12AffineFastState.Bounded env58028 := by
  intro p hp
  have h : env58028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58027_58028 : H12AffineEnvironment.transform 12 420 env58027 = env58028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58027 == env58028) = true)

theorem identity58028 : scanCanonicalize (H12AffineFastState.compose env58028 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58028 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58029 : List Nat := [2,4,8,16,32,64,128,256,372,1024,1410,493,420,1344,1108,294,445,10,1024,1108,1296,396,1213,139,300,17,131,1344,492,1291,504,1528,257,169,445,373]

theorem envBound58029 : H12AffineFastState.Bounded env58029 := by
  intro p hp
  have h : env58029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58028_58029 : H12AffineEnvironment.transform 8 372 env58028 = env58029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58028 == env58029) = true)

theorem identity58029 : scanCanonicalize (H12AffineFastState.compose env58029 (packedSelected [3,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 419) := by decide +kernel

theorem selectedBound58029 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58030 : List Nat := [2,4,8,16,32,64,128,256,372,419,33,493,420,227,503,294,445,10,419,503,179,396,286,139,300,17,131,227,492,168,504,91,257,169,445,373]

theorem envBound58030 : H12AffineFastState.Bounded env58030 := by
  intro p hp
  have h : env58030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58029_58030 : H12AffineEnvironment.transform 9 419 env58029 = env58030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 419 env58029 == env58030) = true)

def env58031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,107882,69824,1024,32768,110634,46481,102435,78309,8329,99683,103452,1345,107835,75786,46564,33196,257,69730,107882,512]

theorem envBound58031 : H12AffineFastState.Bounded env58031 := by
  intro p hp
  have h : env58031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58022_58031 : H12AffineEnvironment.transform 13 1345 env58022 = env58031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58022 == env58031) = true)

theorem identity58031 : scanCanonicalize (H12AffineFastState.compose env58031 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58031 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,107882,67025,1024,32768,107835,41088,99634,74996,8329,99683,98573,1345,107835,75786,41205,33196,257,66931,107882,512]

theorem envBound58032 : H12AffineFastState.Bounded env58032 := by
  intro p hp
  have h : env58032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58031_58032 : H12AffineEnvironment.transform 11 1297 env58031 = env58032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58031 == env58032) = true)

def env58033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144713,169103,26057,157000,311708,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58033 : H12AffineFastState.Bounded env58033 := by
  intro p hp
  have h : env58033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58007_58033 : H12AffineEnvironment.transform 20 136513 env58007 = env58033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58007 == env58033) = true)

def env58034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144713,169103,26057,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58034 : H12AffineFastState.Bounded env58034 := by
  intro p hp
  have h : env58034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58033_58034 : H12AffineEnvironment.transform 17 87424 env58033 = env58034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58033 == env58034) = true)

theorem identity58034 : scanCanonicalize (H12AffineFastState.compose env58034 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 128315) := by decide +kernel

theorem selectedBound58034 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,128315,87424,1024,32768,123002,46480,114802,90548,26057,102515,103452,16384,128362,93514,58805,38076,257,69731,128315,18240]

theorem envBound58035 : H12AffineFastState.Bounded env58035 := by
  intro p hp
  have h : env58035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58034_58035 : H12AffineEnvironment.transform 16 128315 env58034 = env58035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 128315 env58034 == env58035) = true)

def env58036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110715,69824,1024,32768,107834,46480,99634,74996,8329,102515,103452,1344,110634,75786,41205,38076,257,69731,110715,512]

theorem envBound58036 : H12AffineFastState.Bounded env58036 := by
  intro p hp
  have h : env58036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58035_58036 : H12AffineEnvironment.transform 13 1344 env58035 = env58036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58035 == env58036) = true)

theorem identity58036 : scanCanonicalize (H12AffineFastState.compose env58036 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58036 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107883,67024,1024,32768,107834,41088,99634,74996,8329,99683,98572,1344,107834,75786,41205,33196,257,66931,107883,512]

theorem envBound58037 : H12AffineFastState.Bounded env58037 := by
  intro p hp
  have h : env58037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58036_58037 : H12AffineEnvironment.transform 11 1296 env58036 = env58037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58036 == env58037) = true)

def env58038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110714,69825,1024,32768,107835,46480,99635,74997,8328,102515,103452,1345,110635,75787,41204,38076,257,69731,110714,513]

theorem envBound58038 : H12AffineFastState.Bounded env58038 := by
  intro p hp
  have h : env58038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58035_58038 : H12AffineEnvironment.transform 13 1345 env58035 = env58038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58035 == env58038) = true)

theorem identity58038 : scanCanonicalize (H12AffineFastState.compose env58038 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58038 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,9444,33887,1024,32768,12709,46480,4525,45163,8328,1261,130,1345,9397,48277,41204,38076,257,34045,9444,513]

theorem envBound58039 : H12AffineFastState.Bounded env58039 := by
  intro p hp
  have h : env58039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58038_58039 : H12AffineEnvironment.transform 15 38046 env58038 = env58039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58038 == env58039) = true)

theorem identity58039 : scanCanonicalize (H12AffineFastState.compose env58039 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58039 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58040 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,32768,36962,8216,32931,252,32768,12709,45420,4525,45163,8328,17,130,445,8265,47209,41204,36928,257,32769,8216,513]

theorem envBound58040 : H12AffineFastState.Bounded env58040 := by
  intro p hp
  have h : env58040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58039_58040 : H12AffineEnvironment.transform 9 252 env58039 = env58040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58039 == env58040) = true)

theorem identity58040 : scanCanonicalize (H12AffineFastState.compose env58040 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound58040 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58041 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,168,4298,8216,11,252,168,12709,12740,4525,12483,8328,17,130,445,8265,14529,8284,4328,257,169,8216,513]

theorem envBound58041 : H12AffineFastState.Bounded env58041 := by
  intro p hp
  have h : env58041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58040_58041 : H12AffineEnvironment.transform 14 168 env58040 = env58041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env58040 == env58041) = true)

theorem identity58041 : scanCanonicalize (H12AffineFastState.compose env58041 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound58041 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58042 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,8192,445,168,4298,8216,11,252,168,12709,12740,4525,12483,8328,17,130,445,8265,13003,8284,4328,257,169,8216,513]

theorem envBound58042 : H12AffineFastState.Bounded env58042 := by
  intro p hp
  have h : env58042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58041_58042 : H12AffineEnvironment.transform 10 522 env58041 = env58042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env58041 == env58042) = true)

theorem identity58042 : scanCanonicalize (H12AffineFastState.compose env58042 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound58042 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58043 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,4168,445,168,4298,4176,11,252,168,493,396,4525,139,4288,17,130,445,4097,643,4116,4328,257,169,4176,513]

theorem envBound58043 : H12AffineFastState.Bounded env58043 := by
  intro p hp
  have h : env58043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58042_58043 : H12AffineEnvironment.transform 12 4168 env58042 = env58043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env58042 == env58043) = true)

theorem identity58043 : scanCanonicalize (H12AffineFastState.compose env58043 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58043 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58044 : List Nat := [2,4,8,16,32,64,128,256,373,252,383,4096,4168,445,168,4298,4176,11,252,168,493,396,4525,139,4288,17,130,445,4097,502,4116,4328,257,169,4176,372]

theorem envBound58044 : H12AffineFastState.Bounded env58044 := by
  intro p hp
  have h : env58044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58043_58044 : H12AffineEnvironment.transform 8 373 env58043 = env58044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58043 == env58044) = true)

theorem identity58044 : scanCanonicalize (H12AffineFastState.compose env58044 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound58044 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env58045 : List Nat := [2,4,8,16,32,64,35,256,373,95,383,4096,4168,286,11,4201,4176,11,95,11,334,303,4366,40,4195,17,33,286,4097,341,4116,4171,257,10,4176,372]

theorem envBound58045 : H12AffineFastState.Bounded env58045 := by
  intro p hp
  have h : env58045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58044_58045 : H12AffineEnvironment.transform 6 35 env58044 = env58045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env58044 == env58045) = true)

theorem identity58045 : scanCanonicalize (H12AffineFastState.compose env58045 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58045 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58046 : List Nat := [2,4,8,16,32,16,35,256,293,15,303,4096,4120,286,11,4153,4096,11,15,11,286,303,4366,40,4147,17,33,286,4097,261,4116,4123,257,10,4096,292]

theorem envBound58046 : H12AffineFastState.Bounded env58046 := by
  intro p hp
  have h : env58046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58045_58046 : H12AffineEnvironment.transform 5 16 env58045 = env58046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58045 == env58046) = true)

theorem identity58046 : scanCanonicalize (H12AffineFastState.compose env58046 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58046 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58047 : List Nat := [2,4,8,1,32,1,35,256,293,15,303,4096,4105,271,11,4136,4096,11,15,11,271,303,4366,40,4130,0,33,271,4097,261,4101,4106,257,10,4096,292]

theorem envBound58047 : H12AffineFastState.Bounded env58047 := by
  intro p hp
  have h : env58047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58046_58047 : H12AffineEnvironment.transform 3 1 env58046 = env58047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58046 == env58047) = true)

theorem identity58047 : scanCanonicalize (H12AffineFastState.compose env58047 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound58047 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env58048 : List Nat := [2,4,8,1,32,1,35,46,11,15,1,4096,4105,33,11,4136,4096,11,15,11,33,1,4128,40,4130,0,33,33,4097,43,4101,4106,47,10,4096,10]

theorem envBound58048 : H12AffineFastState.Bounded env58048 := by
  intro p hp
  have h : env58048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58047_58048 : H12AffineEnvironment.transform 7 46 env58047 = env58048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env58047 == env58048) = true)

theorem identity58048 : scanCanonicalize (H12AffineFastState.compose env58048 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58048 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58049 : List Nat := [2,4,8,1,10,1,9,4,11,15,1,4096,4105,11,11,4098,4096,11,15,11,11,1,4106,2,4104,0,11,11,4097,1,4101,4106,5,10,4096,10]

theorem envBound58049 : H12AffineFastState.Bounded env58049 := by
  intro p hp
  have h : env58049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58048_58049 : H12AffineEnvironment.transform 4 10 env58048 = env58049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58048 == env58049) = true)

theorem identity58049 : scanCanonicalize (H12AffineFastState.compose env58049 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2) := by decide +kernel

theorem selectedBound58049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1