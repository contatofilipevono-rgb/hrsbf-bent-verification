import H12CloudChart1Data072

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env18420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5441,2420,1024,1,4160,33,16,2,349,64,2128,5392,4097,2341,1364,33,256,32,5456,513]

theorem envBound18420 : H12AffineFastState.Bounded env18420 := by
  intro p hp
  have h : env18420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18419_18420 : H12AffineEnvironment.transform 16 5441 env18419 = env18420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env18419 == env18420) = true)

theorem identity18420 : scanCanonicalize (H12AffineFastState.compose env18420 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

theorem selectedBound18420 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18421 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3157,349,2389,0,342,2324,2420,1024,1,3093,33,16,2,349,64,2128,2373,3156,2341,1364,33,256,32,2309,513]

theorem envBound18421 : H12AffineFastState.Bounded env18421 := by
  intro p hp
  have h : env18421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18420_18421 : H12AffineEnvironment.transform 11 3157 env18420 = env18421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env18420 == env18421) = true)

theorem identity18421 : scanCanonicalize (H12AffineFastState.compose env18421 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18421 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18422 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,3157,8,2048,0,3,2113,2081,1024,1,3093,33,16,2,8,64,2128,2064,3156,2160,1025,33,85,32,2128,513]

theorem envBound18422 : H12AffineFastState.Bounded env18422 := by
  intro p hp
  have h : env18422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18421_18422 : H12AffineEnvironment.transform 7 85 env18421 = env18422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18421 == env18422) = true)

theorem identity18422 : scanCanonicalize (H12AffineFastState.compose env18422 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound18422 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18423 : List Nat := [2,4,8,16,32,64,8,85,64,1024,2048,3157,8,2048,0,3,2113,2081,1024,1,3093,33,16,2,8,64,2128,2064,3156,2160,1025,33,85,32,2128,65]

theorem envBound18423 : H12AffineFastState.Bounded env18423 := by
  intro p hp
  have h : env18423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18422_18423 : H12AffineEnvironment.transform 8 64 env18422 = env18423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env18422 == env18423) = true)

theorem identity18423 : scanCanonicalize (H12AffineFastState.compose env18423 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18423 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env18424 : List Nat := [2,4,8,16,32,64,8,85,64,20,2048,2113,8,2048,0,3,2113,2081,20,1,2049,33,16,2,8,64,2128,2064,2112,2160,21,33,85,32,2128,65]

theorem envBound18424 : H12AffineFastState.Bounded env18424 := by
  intro p hp
  have h : env18424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18423_18424 : H12AffineEnvironment.transform 9 20 env18423 = env18424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18423 == env18424) = true)

theorem identity18424 : scanCanonicalize (H12AffineFastState.compose env18424 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18424 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env18425 : List Nat := [2,4,8,16,32,64,8,85,64,20,0,65,8,0,0,3,65,33,20,1,1,33,16,2,8,64,80,16,64,112,21,33,85,32,80,65]

theorem envBound18425 : H12AffineFastState.Bounded env18425 := by
  intro p hp
  have h : env18425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18424_18425 : H12AffineEnvironment.transform 10 0 env18424 = env18425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18424 == env18425) = true)

theorem identity18425 : scanCanonicalize (H12AffineFastState.compose env18425 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18425 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18426 : List Nat := [2,4,8,16,16,64,8,85,64,20,0,65,8,0,0,3,65,17,20,1,1,17,16,2,8,64,80,16,64,64,21,17,85,16,80,65]

theorem envBound18426 : H12AffineFastState.Bounded env18426 := by
  intro p hp
  have h : env18426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18425_18426 : H12AffineEnvironment.transform 4 16 env18425 = env18426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18425 == env18426) = true)

theorem identity18426 : scanCanonicalize (H12AffineFastState.compose env18426 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound18426 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18427 : List Nat := [2,4,8,16,16,1,8,20,1,20,0,0,8,0,0,3,0,17,20,1,1,17,16,2,8,1,17,16,1,1,21,17,20,16,17,0]

theorem envBound18427 : H12AffineFastState.Bounded env18427 := by
  intro p hp
  have h : env18427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18426_18427 : H12AffineEnvironment.transform 5 1 env18426 = env18427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env18426 == env18427) = true)

def env18428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,17,98644,8193,64,398436,5393,4096,431377,1365,41341,256,32,46092,74250]

theorem envBound18428 : H12AffineFastState.Bounded env18428 := by
  intro p hp
  have h : env18428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18414_18428 : H12AffineEnvironment.transform 6 9 env18414 = env18428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18414 == env18428) = true)

theorem identity18428 : scanCanonicalize (H12AffineFastState.compose env18428 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound18428 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,4160,33,17,98644,8193,64,245019,5393,4096,212078,1365,41341,256,32,46092,74250]

theorem envBound18429 : H12AffineFastState.Bounded env18429 := by
  intro p hp
  have h : env18429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18428_18429 : H12AffineEnvironment.transform 17 108927 env18428 = env18429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env18428 == env18429) = true)

theorem identity18429 : scanCanonicalize (H12AffineFastState.compose env18429 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18429 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5393,108927,1024,32769,4160,33,17,98644,8193,64,108554,5393,4096,76159,1365,41341,256,32,46092,74250]

theorem envBound18430 : H12AffineFastState.Bounded env18430 := by
  intro p hp
  have h : env18430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18429_18430 : H12AffineEnvironment.transform 16 5393 env18429 = env18430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18429 == env18430) = true)

theorem identity18430 : scanCanonicalize (H12AffineFastState.compose env18430 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18430 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,5393,35188,1024,32769,4160,33,17,41311,8193,64,34817,5393,4096,2420,1365,41341,256,32,46092,513]

theorem envBound18431 : H12AffineFastState.Bounded env18431 := by
  intro p hp
  have h : env18431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18430_18431 : H12AffineEnvironment.transform 15 8203 env18430 = env18431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18430 == env18431) = true)

theorem identity18431 : scanCanonicalize (H12AffineFastState.compose env18431 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound18431 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9293,8203,5393,11577,1024,9292,4160,33,17,1298,8193,64,11340,5393,4096,2420,1365,1328,256,32,4161,513]

theorem envBound18432 : H12AffineFastState.Bounded env18432 := by
  intro p hp
  have h : env18432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18431_18432 : H12AffineEnvironment.transform 14 9293 env18431 = env18432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env18431 == env18432) = true)

theorem identity18432 : scanCanonicalize (H12AffineFastState.compose env18432 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound18432 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,292,8192,1060,9293,8203,1077,11577,1024,9292,356,33,17,1298,8193,64,11340,1077,292,2420,1365,1328,256,32,357,513]

theorem envBound18433 : H12AffineFastState.Bounded env18433 := by
  intro p hp
  have h : env18433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18432_18433 : H12AffineEnvironment.transform 11 292 env18432 = env18433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env18432 == env18433) = true)

def env18434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685836,2098649,4232,2524633,2102684,6336916,256,32,46213,2175562]

theorem envBound18434 : H12AffineFastState.Bounded env18434 := by
  intro p hp
  have h : env18434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18398_18434 : H12AffineEnvironment.transform 22 2101465 env18398 = env18434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env18398 == env18434) = true)

def env18435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491564,2098649,4232,2524633,2102684,2142644,256,32,46213,2175562]

theorem envBound18435 : H12AffineFastState.Bounded env18435 := by
  intro p hp
  have h : env18435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18434_18435 : H12AffineEnvironment.transform 21 32 env18434 = env18435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env18434 == env18435) = true)

theorem identity18435 : scanCanonicalize (H12AffineFastState.compose env18435 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18435 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,2097152,32,2101465,73736,8328,64,2491564,2098649,4232,2499716,2102684,2101481,256,32,5592,2175562]

theorem envBound18436 : H12AffineFastState.Bounded env18436 := by
  intro p hp
  have h : env18436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18435_18436 : H12AffineEnvironment.transform 14 8541 env18435 = env18436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18435 == env18436) = true)

def env18437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,2097152,32,2101465,73736,8328,64,2239500,2098649,4232,2231332,2102684,2101481,256,32,5592,2175562]

theorem envBound18437 : H12AffineFastState.Bounded env18437 := by
  intro p hp
  have h : env18437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18436_18437 : H12AffineEnvironment.transform 17 10400 env18436 = env18437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18436 == env18437) = true)

theorem identity18437 : scanCanonicalize (H12AffineFastState.compose env18437 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound18437 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,77899,32,73874,73736,8328,64,203847,79250,4232,212079,75223,73890,256,32,5592,513]

theorem envBound18438 : H12AffineFastState.Bounded env18438 := by
  intro p hp
  have h : env18438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18437_18438 : H12AffineEnvironment.transform 20 77899 env18437 = env18438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env18437 == env18438) = true)

theorem identity18438 : scanCanonicalize (H12AffineFastState.compose env18438 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound18438 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env18439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79251,10400,1024,8540,77899,32,73874,73736,8328,64,10708,79250,4232,2556,75223,73890,256,32,5592,513]

theorem envBound18439 : H12AffineFastState.Bounded env18439 := by
  intro p hp
  have h : env18439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18438_18439 : H12AffineEnvironment.transform 16 79251 env18438 = env18439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env18438 == env18439) = true)

theorem identity18439 : scanCanonicalize (H12AffineFastState.compose env18439 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18439 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env18440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5528,10400,1024,8540,4160,32,153,3,8328,64,10708,5529,4232,2556,1500,169,256,32,5592,513]

theorem envBound18440 : H12AffineFastState.Bounded env18440 := by
  intro p hp
  have h : env18440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18439_18440 : H12AffineEnvironment.transform 15 8203 env18439 = env18440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18439 == env18440) = true)

theorem identity18440 : scanCanonicalize (H12AffineFastState.compose env18440 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18440 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18441 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10281,1024,8540,4160,32,16,3,8193,64,10589,5392,4097,2421,1365,32,256,32,5457,513]

theorem envBound18441 : H12AffineFastState.Bounded env18441 := by
  intro p hp
  have h : env18441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18440_18441 : H12AffineEnvironment.transform 6 9 env18440 = env18441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18440 == env18441) = true)

theorem identity18441 : scanCanonicalize (H12AffineFastState.compose env18441 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18442 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8203,5393,10281,1024,8461,4113,32,16,3,8193,17,10508,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound18442 : H12AffineFastState.Bounded env18442 := by
  intro p hp
  have h : env18442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18441_18442 : H12AffineEnvironment.transform 5 17 env18441 = env18442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18441 == env18442) = true)

theorem identity18442 : scanCanonicalize (H12AffineFastState.compose env18442 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound18442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18443 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1305,5376,1045,1298,5393,3376,1024,1044,4113,32,16,3,1304,17,3093,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound18443 : H12AffineFastState.Bounded env18443 := by
  intro p hp
  have h : env18443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18442_18443 : H12AffineEnvironment.transform 12 1305 env18442 = env18443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env18442 == env18443) = true)

theorem identity18443 : scanCanonicalize (H12AffineFastState.compose env18443 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18443 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18444 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,301,4404,33,294,4389,2308,52,32,4113,32,16,3,300,17,2081,4388,4097,2340,304,32,256,32,4404,513]

theorem envBound18444 : H12AffineFastState.Bounded env18444 := by
  intro p hp
  have h : env18444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18443_18444 : H12AffineEnvironment.transform 9 52 env18443 = env18444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18443 == env18444) = true)

theorem identity18444 : scanCanonicalize (H12AffineFastState.compose env18444 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound18444 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18445 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2324,301,2080,33,294,2097,2308,52,32,2309,32,16,3,300,17,2081,2096,2325,2340,304,32,256,32,2080,513]

theorem envBound18445 : H12AffineFastState.Bounded env18445 := by
  intro p hp
  have h : env18445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18444_18445 : H12AffineEnvironment.transform 11 2324 env18444 = env18445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env18444 == env18445) = true)

theorem identity18445 : scanCanonicalize (H12AffineFastState.compose env18445 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound18445 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18446 : List Nat := [2,4,8,16,32,17,9,256,308,52,2048,2324,301,2080,33,294,2097,2308,52,32,2309,32,16,3,300,17,2081,2096,2325,2340,304,32,256,32,2080,309]

theorem envBound18446 : H12AffineFastState.Bounded env18446 := by
  intro p hp
  have h : env18446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18445_18446 : H12AffineEnvironment.transform 8 308 env18445 = env18446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env18445 == env18446) = true)

theorem identity18446 : scanCanonicalize (H12AffineFastState.compose env18446 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18446 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env18447 : List Nat := [2,4,8,16,32,17,9,37,17,52,2048,2097,8,2080,33,3,2097,2081,52,32,2080,32,16,3,9,17,2081,2096,2096,2049,21,32,37,32,2080,16]

theorem envBound18447 : H12AffineFastState.Bounded env18447 := by
  intro p hp
  have h : env18447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18446_18447 : H12AffineEnvironment.transform 7 37 env18446 = env18447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18446 == env18447) = true)

theorem identity18447 : scanCanonicalize (H12AffineFastState.compose env18447 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18448 : List Nat := [2,4,8,0,32,1,9,37,1,36,2048,2081,8,2080,33,3,2081,2081,36,32,2080,32,0,3,9,1,2081,2080,2080,2049,5,32,37,32,2080,0]

theorem envBound18448 : H12AffineFastState.Bounded env18448 := by
  intro p hp
  have h : env18448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18447_18448 : H12AffineEnvironment.transform 3 0 env18447 = env18448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18447 == env18448) = true)

theorem identity18448 : scanCanonicalize (H12AffineFastState.compose env18448 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound18448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18449 : List Nat := [2,4,8,0,32,1,9,37,1,36,33,0,8,1,33,3,0,0,36,32,1,32,0,3,9,1,0,1,1,32,5,32,37,32,1,0]

theorem envBound18449 : H12AffineFastState.Bounded env18449 := by
  intro p hp
  have h : env18449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18448_18449 : H12AffineEnvironment.transform 10 33 env18448 = env18449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env18448 == env18449) = true)

def env18450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,2097152,32,2101465,73736,8328,64,2239501,2098649,4232,2231333,2102684,2101481,256,32,5592,2175562]

theorem envBound18450 : H12AffineFastState.Bounded env18450 := by
  intro p hp
  have h : env18450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18436_18450 : H12AffineEnvironment.transform 17 10401 env18436 = env18450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18436 == env18450) = true)

theorem identity18450 : scanCanonicalize (H12AffineFastState.compose env18450 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18450 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,10401,1024,8540,2097152,32,2101465,138,8328,64,2239501,2098649,4232,2231333,2102684,2101481,256,32,5592,2101960]

theorem envBound18451 : H12AffineFastState.Bounded env18451 := by
  intro p hp
  have h : env18451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18450_18451 : H12AffineEnvironment.transform 15 8322 env18450 = env18451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18450 == env18451) = true)

theorem identity18451 : scanCanonicalize (H12AffineFastState.compose env18451 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound18451 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5528,10401,1024,8540,2097152,32,2101465,138,8328,64,2111893,2098649,4232,2103741,2102684,2101481,256,32,5592,2101960]

theorem envBound18452 : H12AffineFastState.Bounded env18452 := by
  intro p hp
  have h : env18452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18451_18452 : H12AffineEnvironment.transform 16 5528 env18451 = env18452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env18451 == env18452) = true)

theorem identity18452 : scanCanonicalize (H12AffineFastState.compose env18452 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound18452 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env18453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,216,263,5528,2340,1024,217,2097152,32,2101465,138,269,64,2103312,2098649,4232,2103741,2102684,2101481,256,32,5592,2101960]

theorem envBound18453 : H12AffineFastState.Bounded env18453 := by
  intro p hp
  have h : env18453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18452_18453 : H12AffineEnvironment.transform 12 389 env18452 = env18453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env18452 == env18453) = true)

theorem identity18453 : scanCanonicalize (H12AffineFastState.compose env18453 (packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18453 : packedSelected [1,3,5,8,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env18454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,263,5393,2340,1024,80,2097152,32,2101328,3,269,64,2103312,2098512,4097,2103604,2102549,2101344,256,32,5457,2101825]

theorem envBound18454 : H12AffineFastState.Bounded env18454 := by
  intro p hp
  have h : env18454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18453_18454 : H12AffineEnvironment.transform 6 9 env18453 = env18454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18453 == env18454) = true)

theorem identity18454 : scanCanonicalize (H12AffineFastState.compose env18454 (packedSelected [6,7,9,10,11,12] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound18454 : packedSelected [6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env18455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,263,5393,2340,1024,80,4160,32,16,3,269,64,2128,5392,4097,2420,1365,32,256,32,5457,513]

theorem envBound18455 : H12AffineFastState.Bounded env18455 := by
  intro p hp
  have h : env18455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18454_18455 : H12AffineEnvironment.transform 20 4160 env18454 = env18455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18454 == env18455) = true)

theorem identity18455 : scanCanonicalize (H12AffineFastState.compose env18455 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18455 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18456 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,268,4405,81,263,4388,2340,53,80,4160,32,16,3,269,64,2128,4389,4097,2420,352,32,256,32,4452,513]

theorem envBound18456 : H12AffineFastState.Bounded env18456 := by
  intro p hp
  have h : env18456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18455_18456 : H12AffineEnvironment.transform 9 53 env18455 = env18456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18455 == env18456) = true)

theorem identity18456 : scanCanonicalize (H12AffineFastState.compose env18456 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound18456 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18457 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2357,268,2048,81,263,2065,2340,53,80,2421,32,16,3,269,64,2128,2064,2356,2420,352,32,256,32,2129,513]

theorem envBound18457 : H12AffineFastState.Bounded env18457 := by
  intro p hp
  have h : env18457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18456_18457 : H12AffineEnvironment.transform 11 2357 env18456 = env18457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env18456 == env18457) = true)

theorem identity18457 : scanCanonicalize (H12AffineFastState.compose env18457 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound18457 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18458 : List Nat := [2,4,8,16,32,64,9,256,512,53,373,64,268,373,81,263,356,81,53,80,0,32,16,3,269,64,293,357,65,1,352,32,256,32,292,513]

theorem envBound18458 : H12AffineFastState.Bounded env18458 := by
  intro p hp
  have h : env18458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18457_18458 : H12AffineEnvironment.transform 10 373 env18457 = env18458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env18457 == env18458) = true)

theorem identity18458 : scanCanonicalize (H12AffineFastState.compose env18458 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18458 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18459 : List Nat := [2,4,8,16,32,16,9,256,512,53,293,16,268,293,1,263,308,1,53,0,0,32,16,3,269,16,293,309,17,1,304,32,256,32,292,513]

theorem envBound18459 : H12AffineFastState.Bounded env18459 := by
  intro p hp
  have h : env18459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18458_18459 : H12AffineEnvironment.transform 5 16 env18458 = env18459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18458 == env18459) = true)

def env18460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491565,2098649,4232,2524633,2102684,2142645,256,32,46213,2175562]

theorem envBound18460 : H12AffineFastState.Bounded env18460 := by
  intro p hp
  have h : env18460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18434_18460 : H12AffineEnvironment.transform 21 33 env18434 = env18460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18434 == env18460) = true)

theorem identity18460 : scanCanonicalize (H12AffineFastState.compose env18460 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound18460 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,45460,33,41293,98645,8328,64,439609,46157,4232,406605,41992,33,256,32,46213,99294]

theorem envBound18461 : H12AffineFastState.Bounded env18461 := by
  intro p hp
  have h : env18461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18460_18461 : H12AffineEnvironment.transform 20 45460 env18460 = env18461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env18460 == env18461) = true)

theorem identity18461 : scanCanonicalize (H12AffineFastState.compose env18461 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound18461 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env18462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,45460,33,41293,98645,8328,64,203846,46157,4232,236850,41992,33,256,32,46213,99294]

theorem envBound18462 : H12AffineFastState.Bounded env18462 := by
  intro p hp
  have h : env18462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18461_18462 : H12AffineEnvironment.transform 17 108927 env18461 = env18462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env18461 == env18462) = true)

theorem identity18462 : scanCanonicalize (H12AffineFastState.compose env18462 (packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound18462 : packedSelected [0,1,3,5,8,9,11,12,15,16,18,20,21,22,26,27,31] rootPS < 2^1333 := by decide +kernel

def env18463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,131072,10400,1024,32769,45460,33,41293,138,8328,64,171417,46157,4232,138477,41992,33,256,32,46213,513]

theorem envBound18463 : H12AffineFastState.Bounded env18463 := by
  intro p hp
  have h : env18463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18462_18463 : H12AffineEnvironment.transform 15 33247 env18462 = env18463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env18462 == env18463) = true)

theorem identity18463 : scanCanonicalize (H12AffineFastState.compose env18463 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound18463 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env18464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,13340,10400,1024,32769,45460,33,41293,138,8328,64,43397,46157,4232,10481,41992,33,256,32,46213,513]

theorem envBound18464 : H12AffineFastState.Bounded env18464 := by
  intro p hp
  have h : env18464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18463_18464 : H12AffineEnvironment.transform 16 13340 env18463 = env18464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env18463 == env18464) = true)

theorem identity18464 : scanCanonicalize (H12AffineFastState.compose env18464 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound18464 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env18465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,216,263,13340,10400,1024,217,12620,33,8597,138,8328,64,10589,13461,4232,10481,9424,33,256,32,13405,513]

theorem envBound18465 : H12AffineFastState.Bounded env18465 := by
  intro p hp
  have h : env18465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18464_18465 : H12AffineEnvironment.transform 14 216 env18464 = env18465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env18464 == env18465) = true)

theorem identity18465 : scanCanonicalize (H12AffineFastState.compose env18465 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound18465 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,216,263,5529,2341,1024,217,4297,33,16,138,269,64,2264,5392,4232,2420,1365,33,256,32,5592,513]

theorem envBound18466 : H12AffineFastState.Bounded env18466 := by
  intro p hp
  have h : env18466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18465_18466 : H12AffineEnvironment.transform 12 389 env18465 = env18466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env18465 == env18466) = true)

theorem identity18466 : scanCanonicalize (H12AffineFastState.compose env18466 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 347) := by decide +kernel

theorem selectedBound18466 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env18467 : List Nat := [2,4,8,16,32,64,128,256,512,347,2048,4096,389,4187,216,263,4290,2341,347,217,4297,33,16,138,269,64,2264,4171,4232,2420,14,33,256,32,4227,513]

theorem envBound18467 : H12AffineFastState.Bounded env18467 := by
  intro p hp
  have h : env18467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18466_18467 : H12AffineEnvironment.transform 9 347 env18466 = env18467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 347 env18466 == env18467) = true)

theorem identity18467 : scanCanonicalize (H12AffineFastState.compose env18467 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound18467 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env18468 : List Nat := [2,4,8,16,32,64,89,256,512,347,2048,4096,348,4187,1,263,4123,2341,347,0,4112,33,16,83,269,64,2049,4171,4177,2420,14,33,256,32,4186,513]

theorem envBound18468 : H12AffineFastState.Bounded env18468 := by
  intro p hp
  have h : env18468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18467_18468 : H12AffineEnvironment.transform 6 89 env18467 = env18468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env18467 == env18468) = true)

theorem identity18468 : scanCanonicalize (H12AffineFastState.compose env18468 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18468 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18469 : List Nat := [2,4,8,16,32,16,9,256,512,267,2048,4096,268,4107,1,263,4123,2341,267,0,4112,33,16,3,269,16,2049,4123,4097,2340,14,33,256,32,4106,513]

theorem envBound18469 : H12AffineFastState.Bounded env18469 := by
  intro p hp
  have h : env18469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18468_18469 : H12AffineEnvironment.transform 5 16 env18468 = env18469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18468 == env18469) = true)

theorem identity18469 : scanCanonicalize (H12AffineFastState.compose env18469 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound18469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18470 : List Nat := [2,4,8,16,32,16,9,256,512,267,2048,0,268,11,1,263,27,2341,267,0,16,33,16,3,269,16,2049,27,1,2340,14,33,256,32,10,513]

theorem envBound18470 : H12AffineFastState.Bounded env18470 := by
  intro p hp
  have h : env18470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18469_18470 : H12AffineEnvironment.transform 11 0 env18469 = env18470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env18469 == env18470) = true)

theorem identity18470 : scanCanonicalize (H12AffineFastState.compose env18470 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound18470 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18471 : List Nat := [2,4,8,16,32,16,9,256,512,267,303,0,268,11,1,263,27,10,267,0,16,33,16,3,269,16,302,27,1,11,14,33,256,32,10,513]

theorem envBound18471 : H12AffineFastState.Bounded env18471 := by
  intro p hp
  have h : env18471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18470_18471 : H12AffineEnvironment.transform 10 303 env18470 = env18471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env18470 == env18471) = true)

theorem identity18471 : scanCanonicalize (H12AffineFastState.compose env18471 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18471 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18472 : List Nat := [2,4,8,16,11,16,9,256,512,267,260,0,268,11,1,263,27,10,267,0,16,10,16,3,269,16,261,27,1,11,14,10,256,11,10,513]

theorem envBound18472 : H12AffineFastState.Bounded env18472 := by
  intro p hp
  have h : env18472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18471_18472 : H12AffineEnvironment.transform 4 11 env18471 = env18472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18471 == env18472) = true)

theorem identity18472 : scanCanonicalize (H12AffineFastState.compose env18472 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound18472 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18473 : List Nat := [2,4,8,16,11,16,9,14,512,5,10,0,2,11,1,9,27,10,5,0,16,10,16,3,3,16,11,27,1,11,14,10,14,11,10,513]

theorem envBound18473 : H12AffineFastState.Bounded env18473 := by
  intro p hp
  have h : env18473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18472_18473 : H12AffineEnvironment.transform 7 14 env18472 = env18473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env18472 == env18473) = true)

theorem identity18473 : scanCanonicalize (H12AffineFastState.compose env18473 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound18473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18474 : List Nat := [2,4,8,5,11,5,9,14,512,5,10,0,2,11,1,9,14,10,5,0,5,10,5,3,3,5,11,14,1,11,14,10,14,11,10,513]

theorem envBound18474 : H12AffineFastState.Bounded env18474 := by
  intro p hp
  have h : env18474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18473_18474 : H12AffineEnvironment.transform 3 5 env18473 = env18474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env18473 == env18474) = true)

theorem identity18474 : scanCanonicalize (H12AffineFastState.compose env18474 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound18474 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env18475 : List Nat := [2,4,6,5,5,5,7,0,512,5,4,0,2,5,1,7,0,4,5,0,5,4,5,3,3,5,5,0,1,5,0,4,0,5,4,513]

theorem envBound18475 : H12AffineFastState.Bounded env18475 := by
  intro p hp
  have h : env18475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18474_18475 : H12AffineEnvironment.transform 2 6 env18474 = env18475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env18474 == env18475) = true)

theorem identity18475 : scanCanonicalize (H12AffineFastState.compose env18475 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound18475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18476 : List Nat := [2,4,6,5,5,5,7,0,6,5,4,0,2,5,1,7,0,4,5,0,5,4,5,3,3,5,5,0,1,5,0,4,0,5,4,7]

theorem envBound18476 : H12AffineFastState.Bounded env18476 := by
  intro p hp
  have h : env18476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18475_18476 : H12AffineEnvironment.transform 8 6 env18475 = env18476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env18475 == env18476) = true)

def env18477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685836,8393985,10485840,8819969,2102685,12624205,256,32,46212,2175563]

theorem envBound18477 : H12AffineFastState.Bounded env18477 := by
  intro p hp
  have h : env18477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18397_18477 : H12AffineEnvironment.transform 13 5377 env18397 = env18477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18397 == env18477) = true)

def env18478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685836,2098649,4232,2524633,2102685,6336917,256,32,46212,2175563]

theorem envBound18478 : H12AffineFastState.Bounded env18478 := by
  intro p hp
  have h : env18478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18477_18478 : H12AffineEnvironment.transform 22 2101464 env18477 = env18478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env18477 == env18478) = true)

def env18479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491564,2098649,4232,2524633,2102685,2142645,256,32,46212,2175563]

theorem envBound18479 : H12AffineFastState.Bounded env18479 := by
  intro p hp
  have h : env18479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18478_18479 : H12AffineEnvironment.transform 21 32 env18478 = env18479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env18478 == env18479) = true)

theorem identity18479 : scanCanonicalize (H12AffineFastState.compose env18479 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102679) := by decide +kernel

theorem selectedBound18479 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102679,32,98767,98645,8328,64,497083,103630,4232,464078,99466,73890,256,32,46212,41820]

theorem envBound18480 : H12AffineFastState.Bounded env18480 := by
  intro p hp
  have h : env18480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18479_18480 : H12AffineEnvironment.transform 20 102679 env18479 = env18480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102679 env18479 == env18480) = true)

theorem identity18480 : scanCanonicalize (H12AffineFastState.compose env18480 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18480 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,32,73874,73736,8328,64,472294,79251,4232,464078,75223,73890,256,32,5593,513]

theorem envBound18481 : H12AffineFastState.Bounded env18481 := by
  intro p hp
  have h : env18481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18480_18481 : H12AffineEnvironment.transform 14 8541 env18480 = env18481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18480 == env18481) = true)

def env18482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10400,1024,8540,77898,32,73874,73736,8328,64,203846,79251,4232,212078,75223,73890,256,32,5593,513]

theorem envBound18482 : H12AffineFastState.Bounded env18482 := by
  intro p hp
  have h : env18482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18481_18482 : H12AffineEnvironment.transform 17 10400 env18481 = env18482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18481 == env18482) = true)

theorem identity18482 : scanCanonicalize (H12AffineFastState.compose env18482 (packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound18482 : packedSelected [2,4,6,7,9,11,12,15,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env18483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,79250,10400,1024,8540,77898,32,73874,73736,8328,64,10708,79251,4232,2556,75223,73890,256,32,5593,513]

theorem envBound18483 : H12AffineFastState.Bounded env18483 := by
  intro p hp
  have h : env18483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18482_18483 : H12AffineEnvironment.transform 16 79250 env18482 = env18483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env18482 == env18483) = true)

theorem identity18483 : scanCanonicalize (H12AffineFastState.compose env18483 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18483 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env18484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,5529,10400,1024,8540,4161,32,153,3,8328,64,10708,5528,4232,2556,1500,169,256,32,5593,513]

theorem envBound18484 : H12AffineFastState.Bounded env18484 := by
  intro p hp
  have h : env18484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18483_18484 : H12AffineEnvironment.transform 15 8203 env18483 = env18484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18483 == env18484) = true)

theorem identity18484 : scanCanonicalize (H12AffineFastState.compose env18484 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18484 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10281,1024,8540,4161,32,16,3,8193,64,10589,5393,4097,2421,1365,32,256,32,5456,513]

theorem envBound18485 : H12AffineFastState.Bounded env18485 := by
  intro p hp
  have h : env18485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18484_18485 : H12AffineEnvironment.transform 6 9 env18484 = env18485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18484 == env18485) = true)

theorem identity18485 : scanCanonicalize (H12AffineFastState.compose env18485 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18485 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18486 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8203,5392,10281,1024,8461,4112,32,16,3,8193,17,10508,5393,4097,2340,1284,32,256,32,5377,513]

theorem envBound18486 : H12AffineFastState.Bounded env18486 := by
  intro p hp
  have h : env18486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18485_18486 : H12AffineEnvironment.transform 5 17 env18485 = env18486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18485 == env18486) = true)

theorem identity18486 : scanCanonicalize (H12AffineFastState.compose env18486 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound18486 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18487 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1304,5377,1044,1299,5392,3377,1024,1045,4112,32,16,3,1305,17,3092,5393,4097,2340,1284,32,256,32,5377,513]

theorem envBound18487 : H12AffineFastState.Bounded env18487 := by
  intro p hp
  have h : env18487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18486_18487 : H12AffineEnvironment.transform 12 1304 env18486 = env18487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env18486 == env18487) = true)

theorem identity18487 : scanCanonicalize (H12AffineFastState.compose env18487 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18487 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18488 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,300,4405,32,295,4388,2309,52,33,4112,32,16,3,301,17,2080,4389,4097,2340,304,32,256,32,4405,513]

theorem envBound18488 : H12AffineFastState.Bounded env18488 := by
  intro p hp
  have h : env18488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18487_18488 : H12AffineEnvironment.transform 9 52 env18487 = env18488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18487 == env18488) = true)

theorem identity18488 : scanCanonicalize (H12AffineFastState.compose env18488 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound18488 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18489 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2324,300,2081,32,295,2096,2309,52,33,2308,32,16,3,301,17,2080,2097,2325,2340,304,32,256,32,2081,513]

theorem envBound18489 : H12AffineFastState.Bounded env18489 := by
  intro p hp
  have h : env18489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18488_18489 : H12AffineEnvironment.transform 11 2324 env18488 = env18489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env18488 == env18489) = true)

theorem identity18489 : scanCanonicalize (H12AffineFastState.compose env18489 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound18489 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env18490 : List Nat := [2,4,8,16,32,17,9,256,277,52,2048,2324,300,2081,32,295,2096,2309,52,33,2308,32,16,3,301,17,2080,2097,2325,2340,304,32,256,32,2081,276]

theorem envBound18490 : H12AffineFastState.Bounded env18490 := by
  intro p hp
  have h : env18490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18489_18490 : H12AffineEnvironment.transform 8 277 env18489 = env18490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env18489 == env18490) = true)

theorem identity18490 : scanCanonicalize (H12AffineFastState.compose env18490 (packedSelected [0,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18490 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env18491 : List Nat := [2,4,8,16,32,17,9,36,49,52,2048,2096,8,2081,32,3,2096,2081,52,33,2080,32,16,3,9,17,2080,2097,2097,2048,20,32,36,32,2081,48]

theorem envBound18491 : H12AffineFastState.Bounded env18491 := by
  intro p hp
  have h : env18491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18490_18491 : H12AffineEnvironment.transform 7 36 env18490 = env18491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18490 == env18491) = true)

theorem identity18491 : scanCanonicalize (H12AffineFastState.compose env18491 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound18491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18492 : List Nat := [2,4,8,16,32,17,9,36,49,52,49,1,8,16,32,3,1,16,52,33,17,32,16,3,9,17,17,0,0,49,20,32,36,32,16,48]

theorem envBound18492 : H12AffineFastState.Bounded env18492 := by
  intro p hp
  have h : env18492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18491_18492 : H12AffineEnvironment.transform 10 49 env18491 = env18492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env18491 == env18492) = true)

theorem identity18492 : scanCanonicalize (H12AffineFastState.compose env18492 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18492 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18493 : List Nat := [2,4,8,16,17,17,9,21,0,5,0,1,8,16,17,3,1,16,5,16,17,17,16,3,9,17,17,0,0,0,20,17,21,17,16,1]

theorem envBound18493 : H12AffineFastState.Bounded env18493 := by
  intro p hp
  have h : env18493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18492_18493 : H12AffineEnvironment.transform 4 17 env18492 = env18493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18492 == env18493) = true)

theorem identity18493 : scanCanonicalize (H12AffineFastState.compose env18493 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18493 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18494 : List Nat := [2,4,8,0,1,1,9,5,0,5,0,1,8,0,1,3,1,0,5,0,1,1,0,3,9,1,1,0,0,0,4,1,5,1,0,1]

theorem envBound18494 : H12AffineFastState.Bounded env18494 := by
  intro p hp
  have h : env18494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18493_18494 : H12AffineEnvironment.transform 3 0 env18493 = env18494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18493 == env18494) = true)

def env18495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10401,1024,8540,77898,32,73874,73736,8328,64,203847,79251,4232,212079,75223,73890,256,32,5593,513]

theorem envBound18495 : H12AffineFastState.Bounded env18495 := by
  intro p hp
  have h : env18495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18481_18495 : H12AffineEnvironment.transform 17 10401 env18481 = env18495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18481 == env18495) = true)

theorem identity18495 : scanCanonicalize (H12AffineFastState.compose env18495 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound18495 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env18496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,79131,10401,1024,8540,77898,32,73874,73736,8328,64,10588,79251,4232,2420,75223,73890,256,32,5593,513]

theorem envBound18496 : H12AffineFastState.Bounded env18496 := by
  intro p hp
  have h : env18496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18495_18496 : H12AffineEnvironment.transform 16 79131 env18495 = env18496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env18495 == env18496) = true)

theorem identity18496 : scanCanonicalize (H12AffineFastState.compose env18496 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound18496 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env18497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2184,8541,65536,75922,10401,1024,8540,77251,32,73874,73736,8328,64,10588,75802,3329,2420,75223,73890,256,32,2128,513]

theorem envBound18497 : H12AffineFastState.Bounded env18497 := by
  intro p hp
  have h : env18497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18496_18497 : H12AffineEnvironment.transform 11 3465 env18496 = env18497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env18496 == env18497) = true)

theorem identity18497 : scanCanonicalize (H12AffineFastState.compose env18497 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18497 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3465,8192,2184,8541,8322,2064,10401,1024,8540,3393,32,16,138,8328,64,10588,2200,3329,2420,1365,32,256,32,2128,513]

theorem envBound18498 : H12AffineFastState.Bounded env18498 := by
  intro p hp
  have h : env18498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18497_18498 : H12AffineEnvironment.transform 15 8322 env18497 = env18498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18497 == env18498) = true)

theorem identity18498 : scanCanonicalize (H12AffineFastState.compose env18498 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18498 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1416,8192,137,8541,8322,17,8352,1024,8540,1344,32,16,138,8328,64,8541,153,1280,373,1365,32,256,32,81,513]

theorem envBound18499 : H12AffineFastState.Bounded env18499 := by
  intro p hp
  have h : env18499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18498_18499 : H12AffineEnvironment.transform 10 1 env18498 = env18499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18498 == env18499) = true)

theorem identity18499 : scanCanonicalize (H12AffineFastState.compose env18499 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound18499 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env18500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1416,1337,137,1124,1467,17,1433,1024,1125,1344,32,16,138,1457,64,1124,153,1280,373,1365,32,256,32,81,513]

theorem envBound18500 : H12AffineFastState.Bounded env18500 := by
  intro p hp
  have h : env18500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18499_18500 : H12AffineEnvironment.transform 12 1337 env18499 = env18500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env18499 == env18500) = true)

theorem identity18500 : scanCanonicalize (H12AffineFastState.compose env18500 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18500 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18501 : List Nat := [2,4,8,16,32,64,128,256,512,53,1,445,268,137,81,398,17,428,53,80,373,32,16,138,388,64,81,153,309,373,352,32,256,32,81,513]

theorem envBound18501 : H12AffineFastState.Bounded env18501 := by
  intro p hp
  have h : env18501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18500_18501 : H12AffineEnvironment.transform 9 53 env18500 = env18501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18500 == env18501) = true)

def env18502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491565,2098649,4232,2524633,2102685,2142644,256,32,46212,2175563]

theorem envBound18502 : H12AffineFastState.Bounded env18502 := by
  intro p hp
  have h : env18502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18478_18502 : H12AffineEnvironment.transform 21 33 env18478 = env18502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18478 == env18502) = true)

theorem identity18502 : scanCanonicalize (H12AffineFastState.compose env18502 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound18502 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491565,2098649,4232,2524633,2102685,2142644,256,32,46212,2143124]

theorem envBound18503 : H12AffineFastState.Bounded env18503 := by
  intro p hp
  have h : env18503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18502_18503 : H12AffineEnvironment.transform 15 33247 env18502 = env18503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env18502 == env18503) = true)

theorem identity18503 : scanCanonicalize (H12AffineFastState.compose env18503 (packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound18503 : packedSelected [0,1,9,11,12,14,15,18,19,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env18504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10400,1024,32769,2097152,33,2101464,138,8328,64,2239501,2098649,4232,2272633,2102685,2142644,256,32,46212,2143124]

theorem envBound18504 : H12AffineFastState.Bounded env18504 := by
  intro p hp
  have h : env18504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18503_18504 : H12AffineEnvironment.transform 17 10400 env18503 = env18504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18503 == env18504) = true)

def env18505 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1024,32769,2097152,33,2101328,2,8192,64,2239501,2098513,4096,2272633,2102549,2142524,256,32,46092,2143004]

theorem envBound18505 : H12AffineFastState.Bounded env18505 := by
  intro p hp
  have h : env18505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18504_18505 : H12AffineEnvironment.transform 6 8 env18504 = env18505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18504 == env18505) = true)

theorem identity18505 : scanCanonicalize (H12AffineFastState.compose env18505 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 45341) := by decide +kernel

theorem selectedBound18505 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18506 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,10280,1024,32769,45341,33,41293,2,8192,64,171280,46156,4096,138340,41992,33,256,32,46092,513]

theorem envBound18506 : H12AffineFastState.Bounded env18506 := by
  intro p hp
  have h : env18506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18505_18506 : H12AffineEnvironment.transform 20 45341 env18505 = env18506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45341 env18505 == env18506) = true)

theorem identity18506 : scanCanonicalize (H12AffineFastState.compose env18506 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18506 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18507 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,131072,10280,1024,8541,4161,33,17,2,8192,64,146508,5392,4096,138340,1364,33,256,32,5456,513]

theorem envBound18507 : H12AffineFastState.Bounded env18507 := by
  intro p hp
  have h : env18507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18506_18507 : H12AffineEnvironment.transform 14 8540 env18506 = env18507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18506 == env18507) = true)

theorem identity18507 : scanCanonicalize (H12AffineFastState.compose env18507 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound18507 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13340,10280,1024,8541,4161,33,17,2,8192,64,2128,5392,4096,10360,1364,33,256,32,5456,513]

theorem envBound18508 : H12AffineFastState.Bounded env18508 := by
  intro p hp
  have h : env18508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18507_18508 : H12AffineEnvironment.transform 16 13340 env18507 = env18508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env18507 == env18508) = true)

theorem identity18508 : scanCanonicalize (H12AffineFastState.compose env18508 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18508 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env18509 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5156,8313,8203,13340,10280,1024,8312,4161,33,17,2,8192,64,2128,5173,4096,10360,1137,33,37,32,5237,513]

theorem envBound18509 : H12AffineFastState.Bounded env18509 := by
  intro p hp
  have h : env18509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18508_18509 : H12AffineEnvironment.transform 7 37 env18508 = env18509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18508 == env18509) = true)

theorem identity18509 : scanCanonicalize (H12AffineFastState.compose env18509 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18509 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env18510 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5156,8232,8203,13340,10280,1024,8233,4112,33,17,2,8192,17,2049,5173,4096,10281,1056,33,37,32,5156,513]

theorem envBound18510 : H12AffineFastState.Bounded env18510 := by
  intro p hp
  have h : env18510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18509_18510 : H12AffineEnvironment.transform 5 17 env18509 = env18510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18509 == env18510) = true)

theorem identity18510 : scanCanonicalize (H12AffineFastState.compose env18510 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18510 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env18511 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,8192,4112,8232,8203,12328,10280,52,8233,4112,33,17,2,8192,17,2049,4097,4096,10281,20,33,37,32,4112,513]

theorem envBound18511 : H12AffineFastState.Bounded env18511 := by
  intro p hp
  have h : env18511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18510_18511 : H12AffineEnvironment.transform 9 52 env18510 = env18511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18510 == env18511) = true)

def env18512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10281,1024,32769,2097152,33,2101329,3,8193,64,2239501,2098512,4097,2272633,2102548,2142525,256,32,46093,2143005]

theorem envBound18512 : H12AffineFastState.Bounded env18512 := by
  intro p hp
  have h : env18512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18504_18512 : H12AffineEnvironment.transform 6 9 env18504 = env18512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18504 == env18512) = true)

theorem identity18512 : scanCanonicalize (H12AffineFastState.compose env18512 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound18512 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18513 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,10281,1024,32769,4161,33,16,3,8193,64,146508,5393,4097,179512,1365,41340,256,32,46093,41820]

theorem envBound18513 : H12AffineFastState.Bounded env18513 := by
  intro p hp
  have h : env18513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18512_18513 : H12AffineEnvironment.transform 20 4161 env18512 = env18513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18512 == env18513) = true)

theorem identity18513 : scanCanonicalize (H12AffineFastState.compose env18513 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound18513 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env18514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,13624,10281,1024,32769,4161,33,16,3,8193,64,2420,5393,4097,34816,1365,41340,256,32,46093,41820]

theorem envBound18514 : H12AffineFastState.Bounded env18514 := by
  intro p hp
  have h : env18514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18513_18514 : H12AffineEnvironment.transform 16 13624 env18513 = env18514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env18513 == env18514) = true)

theorem identity18514 : scanCanonicalize (H12AffineFastState.compose env18514 (packedSelected [6,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound18514 : packedSelected [6,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9293,9499,13624,10281,1024,9292,4161,33,16,3,8193,64,2420,5393,4097,11341,1365,1329,256,32,4160,1809]

theorem envBound18515 : H12AffineFastState.Bounded env18515 := by
  intro p hp
  have h : env18515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18514_18515 : H12AffineEnvironment.transform 14 9293 env18514 = env18515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env18514 == env18515) = true)

def env18516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685836,2098648,4233,2524632,2102685,6336916,256,32,46212,2175563]

theorem envBound18516 : H12AffineFastState.Bounded env18516 := by
  intro p hp
  have h : env18516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18477_18516 : H12AffineEnvironment.transform 22 2101465 env18477 = env18516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env18477 == env18516) = true)

def env18517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491564,2098648,4233,2524632,2102685,2142644,256,32,46212,2175563]

theorem envBound18517 : H12AffineFastState.Bounded env18517 := by
  intro p hp
  have h : env18517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18516_18517 : H12AffineEnvironment.transform 21 32 env18516 = env18517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env18516 == env18517) = true)

theorem identity18517 : scanCanonicalize (H12AffineFastState.compose env18517 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound18517 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,73755,98644,8328,64,472174,79130,4233,505114,75103,98678,256,32,46212,649]

theorem envBound18518 : H12AffineFastState.Bounded env18518 := by
  intro p hp
  have h : env18518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18517_18518 : H12AffineEnvironment.transform 20 78018 env18517 = env18518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env18517 == env18518) = true)

def env18519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472174,79130,4097,505114,75103,98678,256,32,46092,513]

theorem envBound18519 : H12AffineFastState.Bounded env18519 := by
  intro p hp
  have h : env18519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18518_18519 : H12AffineEnvironment.transform 6 8 env18518 = env18519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18518 == env18519) = true)

theorem identity18519 : scanCanonicalize (H12AffineFastState.compose env18519 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound18519 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env18520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,45340,32,41293,2,8192,64,439608,46156,4097,406604,41993,32,256,32,46092,513]

theorem envBound18520 : H12AffineFastState.Bounded env18520 := by
  intro p hp
  have h : env18520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18519_18520 : H12AffineEnvironment.transform 15 33110 env18519 = env18520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env18519 == env18520) = true)

theorem identity18520 : scanCanonicalize (H12AffineFastState.compose env18520 (packedSelected [2,6,21] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound18520 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env18521 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,171060,1024,32769,45340,32,41293,2,8192,64,10508,46156,4097,43128,41993,32,256,32,46092,513]

theorem envBound18521 : H12AffineFastState.Bounded env18521 := by
  intro p hp
  have h : env18521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18520_18521 : H12AffineEnvironment.transform 17 171060 env18520 = env18521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env18520 == env18521) = true)

theorem identity18521 : scanCanonicalize (H12AffineFastState.compose env18521 (packedSelected [0,3,4,7,9,10,14,19,24] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound18521 : packedSelected [0,3,4,7,9,10,14,19,24] rootPS < 2^1333 := by decide +kernel

def env18522 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,38160,2340,1024,32769,45340,32,41293,2,8192,64,10508,46156,4097,43128,41993,32,256,32,46092,513]

theorem envBound18522 : H12AffineFastState.Bounded env18522 := by
  intro p hp
  have h : env18522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18521_18522 : H12AffineEnvironment.transform 16 38160 env18521 = env18522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env18521 == env18522) = true)

theorem identity18522 : scanCanonicalize (H12AffineFastState.compose env18522 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18522 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env18523 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,33030,38160,2340,1024,32769,45340,32,41245,2,8192,16,10508,46108,4097,43048,41993,32,256,32,46092,513]

theorem envBound18523 : H12AffineFastState.Bounded env18523 := by
  intro p hp
  have h : env18523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18522_18523 : H12AffineEnvironment.transform 5 16 env18522 = env18523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18522 == env18523) = true)

theorem identity18523 : scanCanonicalize (H12AffineFastState.compose env18523 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18523 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env18524 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,13341,2340,1024,8460,4113,32,16,2,8192,16,10508,5393,4097,2341,1284,32,256,32,5377,513]

theorem envBound18524 : H12AffineFastState.Bounded env18524 := by
  intro p hp
  have h : env18524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18523_18524 : H12AffineEnvironment.transform 14 8461 env18523 = env18524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env18523 == env18524) = true)

theorem identity18524 : scanCanonicalize (H12AffineFastState.compose env18524 (packedSelected [1,2,3,4,5,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound18524 : packedSelected [1,2,3,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18525 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,8192,2049,8461,8203,10525,2340,1024,8460,3345,32,16,2,8192,16,10508,2065,3329,2341,1284,32,256,32,2049,513]

theorem envBound18525 : H12AffineFastState.Bounded env18525 := by
  intro p hp
  have h : env18525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18524_18525 : H12AffineEnvironment.transform 11 3328 env18524 = env18525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env18524 == env18525) = true)

theorem identity18525 : scanCanonicalize (H12AffineFastState.compose env18525 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18525 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env18526 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1280,8192,1,8461,8203,8477,292,1024,8460,1297,32,16,2,8192,16,8460,17,1281,293,1284,32,256,32,1,513]

theorem envBound18526 : H12AffineFastState.Bounded env18526 := by
  intro p hp
  have h : env18526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18525_18526 : H12AffineEnvironment.transform 10 0 env18525 = env18526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18525 == env18526) = true)

theorem identity18526 : scanCanonicalize (H12AffineFastState.compose env18526 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18526 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env18527 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1280,269,1,0,262,16,292,1024,1,1297,32,16,2,269,16,1,17,1281,293,1284,32,256,32,1,513]

theorem envBound18527 : H12AffineFastState.Bounded env18527 := by
  intro p hp
  have h : env18527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18526_18527 : H12AffineEnvironment.transform 12 269 env18526 = env18527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18526 == env18527) = true)

theorem identity18527 : scanCanonicalize (H12AffineFastState.compose env18527 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18528 : List Nat := [2,4,8,16,32,16,8,256,512,52,0,308,269,1,0,262,16,292,52,1,293,32,16,2,269,16,1,17,309,293,304,32,256,32,1,513]

theorem envBound18528 : H12AffineFastState.Bounded env18528 := by
  intro p hp
  have h : env18528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18527_18528 : H12AffineEnvironment.transform 9 52 env18527 = env18528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18527 == env18528) = true)

theorem identity18528 : scanCanonicalize (H12AffineFastState.compose env18528 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18529 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,17,40,1,0,35,16,1,52,1,0,32,16,2,40,16,1,17,16,0,21,32,37,32,1,513]

theorem envBound18529 : H12AffineFastState.Bounded env18529 := by
  intro p hp
  have h : env18529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18528_18529 : H12AffineEnvironment.transform 7 37 env18528 = env18529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18528 == env18529) = true)

theorem identity18529 : scanCanonicalize (H12AffineFastState.compose env18529 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18530 : List Nat := [2,4,8,0,32,0,8,37,512,36,0,1,40,1,0,35,0,1,36,1,0,32,0,2,40,0,1,1,0,0,5,32,37,32,1,513]

theorem envBound18530 : H12AffineFastState.Bounded env18530 := by
  intro p hp
  have h : env18530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18529_18530 : H12AffineEnvironment.transform 3 0 env18529 = env18530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18529 == env18530) = true)

theorem identity18530 : scanCanonicalize (H12AffineFastState.compose env18530 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound18530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18531 : List Nat := [2,4,8,0,32,0,8,37,10,36,0,1,40,1,0,35,0,1,36,1,0,32,0,2,40,0,1,1,0,0,5,32,37,32,1,11]

theorem envBound18531 : H12AffineFastState.Bounded env18531 := by
  intro p hp
  have h : env18531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18530_18531 : H12AffineEnvironment.transform 8 10 env18530 = env18531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env18530 == env18531) = true)

def env18532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,73755,98644,8193,64,472174,79130,4096,505114,75103,98678,256,32,46093,512]

theorem envBound18532 : H12AffineFastState.Bounded env18532 := by
  intro p hp
  have h : env18532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18518_18532 : H12AffineEnvironment.transform 6 9 env18518 = env18532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18518 == env18532) = true)

theorem identity18532 : scanCanonicalize (H12AffineFastState.compose env18532 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound18532 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,45340,32,41292,3,8193,64,439609,46157,4096,406605,41992,33,256,32,46093,512]

theorem envBound18533 : H12AffineFastState.Bounded env18533 := by
  intro p hp
  have h : env18533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18532_18533 : H12AffineEnvironment.transform 15 33111 env18532 = env18533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env18532 == env18533) = true)

theorem identity18533 : scanCanonicalize (H12AffineFastState.compose env18533 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound18533 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18534 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5425,262144,1024,32769,45340,32,41292,3,8193,64,303112,46157,4096,270716,41992,33,256,32,46093,512]

theorem envBound18534 : H12AffineFastState.Bounded env18534 := by
  intro p hp
  have h : env18534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18533_18534 : H12AffineEnvironment.transform 16 5425 env18533 = env18534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env18533 == env18534) = true)

theorem identity18534 : scanCanonicalize (H12AffineFastState.compose env18534 (packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 8573) := by decide +kernel

theorem selectedBound18534 : packedSelected [1,2,3,4,5,8,9,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env18535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8573,8234,5425,262144,1024,8572,4193,32,49,3,8193,64,262517,5424,4096,270716,1397,33,256,32,5488,512]

theorem envBound18535 : H12AffineFastState.Bounded env18535 := by
  intro p hp
  have h : env18535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18534_18535 : H12AffineEnvironment.transform 14 8573 env18534 = env18535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8573 env18534 == env18535) = true)

theorem identity18535 : scanCanonicalize (H12AffineFastState.compose env18535 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound18535 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8573,8234,5425,10589,1024,8572,4193,32,49,3,8193,64,10280,5424,4096,2081,1397,33,256,32,5488,512]

theorem envBound18536 : H12AffineFastState.Bounded env18536 := by
  intro p hp
  have h : env18536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18535_18536 : H12AffineEnvironment.transform 17 10589 env18535 = env18536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env18535 == env18536) = true)

theorem identity18536 : scanCanonicalize (H12AffineFastState.compose env18536 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18536 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18537 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,5204,8232,8234,5220,10248,1024,8233,4193,32,49,3,8193,64,10280,5221,4096,2081,1056,33,85,32,5157,512]

theorem envBound18537 : H12AffineFastState.Bounded env18537 := by
  intro p hp
  have h : env18537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18536_18537 : H12AffineEnvironment.transform 7 85 env18536 = env18537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18536 == env18537) = true)

theorem identity18537 : scanCanonicalize (H12AffineFastState.compose env18537 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18537 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18538 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,8192,5157,8232,8234,5141,10248,1024,8233,4112,32,49,3,8193,49,10280,5140,4096,2081,1056,33,36,32,5157,512]

theorem envBound18538 : H12AffineFastState.Bounded env18538 := by
  intro p hp
  have h : env18538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18537_18538 : H12AffineEnvironment.transform 5 49 env18537 = env18538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18537 == env18538) = true)

theorem identity18538 : scanCanonicalize (H12AffineFastState.compose env18538 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound18538 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18539 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,8,5157,32,34,5141,2048,1024,33,4112,32,49,3,9,49,2080,5140,4096,2081,1056,33,36,32,5157,512]

theorem envBound18539 : H12AffineFastState.Bounded env18539 := by
  intro p hp
  have h : env18539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18538_18539 : H12AffineEnvironment.transform 12 8 env18538 = env18539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env18538 == env18539) = true)

theorem identity18539 : scanCanonicalize (H12AffineFastState.compose env18539 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3086) := by decide +kernel

theorem selectedBound18539 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18540 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,3086,8,2091,32,34,2075,2048,1024,33,3102,32,49,3,9,49,2080,2074,3086,2081,1056,33,36,32,2091,512]

theorem envBound18540 : H12AffineFastState.Bounded env18540 := by
  intro p hp
  have h : env18540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18539_18540 : H12AffineEnvironment.transform 11 3086 env18539 = env18540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3086 env18539 == env18540) = true)

theorem identity18540 : scanCanonicalize (H12AffineFastState.compose env18540 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound18540 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18541 : List Nat := [2,4,8,16,32,49,9,36,512,1024,523,1541,8,544,32,34,528,523,1024,33,1557,32,49,3,9,49,555,529,1541,554,1056,33,36,32,544,512]

theorem envBound18541 : H12AffineFastState.Bounded env18541 := by
  intro p hp
  have h : env18541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18540_18541 : H12AffineEnvironment.transform 10 523 env18540 = env18541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env18540 == env18541) = true)

theorem identity18541 : scanCanonicalize (H12AffineFastState.compose env18541 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound18541 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18542 : List Nat := [2,4,8,16,32,49,9,36,512,14,523,523,8,544,32,34,528,523,14,33,539,32,49,3,9,49,555,529,523,554,46,33,36,32,544,512]

theorem envBound18542 : H12AffineFastState.Bounded env18542 := by
  intro p hp
  have h : env18542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18541_18542 : H12AffineEnvironment.transform 9 14 env18541 = env18542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env18541 == env18542) = true)

theorem identity18542 : scanCanonicalize (H12AffineFastState.compose env18542 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18542 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env18543 : List Nat := [2,4,8,16,11,26,9,15,512,14,523,523,8,523,11,9,528,523,14,10,539,11,26,3,9,26,512,529,523,513,5,10,15,11,523,512]

theorem envBound18543 : H12AffineFastState.Bounded env18543 := by
  intro p hp
  have h : env18543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18542_18543 : H12AffineEnvironment.transform 4 11 env18542 = env18543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18542 == env18543) = true)

theorem identity18543 : scanCanonicalize (H12AffineFastState.compose env18543 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound18543 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18544 : List Nat := [2,4,3,16,0,17,2,4,512,5,512,512,3,512,0,2,528,512,5,1,528,0,17,3,2,17,512,529,512,513,5,1,4,0,512,512]

theorem envBound18544 : H12AffineFastState.Bounded env18544 := by
  intro p hp
  have h : env18544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18543_18544 : H12AffineEnvironment.transform 2 3 env18543 = env18544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env18543 == env18544) = true)

theorem identity18544 : scanCanonicalize (H12AffineFastState.compose env18544 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound18544 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18545 : List Nat := [2,4,3,16,0,17,2,4,18,5,18,18,3,18,0,2,2,18,5,1,2,0,17,3,2,17,18,3,18,19,5,1,4,0,18,18]

theorem envBound18545 : H12AffineFastState.Bounded env18545 := by
  intro p hp
  have h : env18545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18544_18545 : H12AffineEnvironment.transform 8 18 env18544 = env18545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env18544 == env18545) = true)

theorem identity18545 : scanCanonicalize (H12AffineFastState.compose env18545 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18545 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18546 : List Nat := [2,4,3,1,0,0,2,4,3,5,3,3,3,3,0,2,2,3,5,1,2,0,0,3,2,0,3,3,3,2,5,1,4,0,3,3]

theorem envBound18546 : H12AffineFastState.Bounded env18546 := by
  intro p hp
  have h : env18546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18545_18546 : H12AffineEnvironment.transform 3 1 env18545 = env18546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18545 == env18546) = true)

theorem identity18546 : scanCanonicalize (H12AffineFastState.compose env18546 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound18546 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18547 : List Nat := [2,2,3,1,0,0,2,2,3,3,3,3,3,3,0,2,2,3,3,1,2,0,0,3,2,0,3,3,3,2,3,1,2,0,3,3]

theorem envBound18547 : H12AffineFastState.Bounded env18547 := by
  intro p hp
  have h : env18547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18546_18547 : H12AffineEnvironment.transform 1 2 env18546 = env18547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env18546 == env18547) = true)

def env18548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491565,2098648,4233,2524632,2102685,2142645,256,32,46212,2175563]

theorem envBound18548 : H12AffineFastState.Bounded env18548 := by
  intro p hp
  have h : env18548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18516_18548 : H12AffineEnvironment.transform 21 33 env18516 = env18548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env18516 == env18548) = true)

theorem identity18548 : scanCanonicalize (H12AffineFastState.compose env18548 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18548 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101465,41311,8328,64,2491565,2098648,4233,2524632,2102685,2142645,256,32,46212,2101824]

theorem envBound18549 : H12AffineFastState.Bounded env18549 := by
  intro p hp
  have h : env18549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18548_18549 : H12AffineEnvironment.transform 15 8203 env18548 = env18549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18548 == env18549) = true)

def env18550 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101385,41231,8328,16,2491565,2098568,4233,2524552,2102685,2142645,256,32,46212,2101776]

theorem envBound18550 : H12AffineFastState.Bounded env18550 := by
  intro p hp
  have h : env18550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18549_18550 : H12AffineEnvironment.transform 5 16 env18549 = env18550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18549 == env18550) = true)

theorem identity18550 : scanCanonicalize (H12AffineFastState.compose env18550 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound18550 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env18551 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35245,1024,32769,2097152,33,2101385,41231,8328,16,2264320,2098568,4233,2231333,2102685,2142645,256,32,46212,2101776]

theorem envBound18551 : H12AffineFastState.Bounded env18551 := by
  intro p hp
  have h : env18551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18550_18551 : H12AffineEnvironment.transform 17 35245 env18550 = env18551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env18550 == env18551) = true)

theorem identity18551 : scanCanonicalize (H12AffineFastState.compose env18551 (packedSelected [0,4,5,7,8,16,20,21,22,24,26,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18551 : packedSelected [0,4,5,7,8,16,20,21,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env18552 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,35245,1024,32769,4113,33,152,41231,8328,16,171281,5529,4233,138292,1420,41380,256,32,46212,513]

theorem envBound18552 : H12AffineFastState.Bounded env18552 := by
  intro p hp
  have h : env18552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18551_18552 : H12AffineEnvironment.transform 20 4113 env18551 = env18552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4113 env18551 == env18552) = true)

theorem identity18552 : scanCanonicalize (H12AffineFastState.compose env18552 (packedSelected [2,3,6,10,16,18,20,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound18552 : packedSelected [2,3,6,10,16,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env18553 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35245,1024,32769,4113,33,152,41231,8328,16,34816,5529,4233,2341,1420,41380,256,32,46212,513]

theorem envBound18553 : H12AffineFastState.Bounded env18553 := by
  intro p hp
  have h : env18553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18552_18553 : H12AffineEnvironment.transform 16 5393 env18552 = env18553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env18552 == env18553) = true)

theorem identity18553 : scanCanonicalize (H12AffineFastState.compose env18553 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18553 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18554 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35109,1024,32769,4113,33,16,41231,8192,16,34816,5393,4097,2341,1284,41260,256,32,46092,513]

theorem envBound18554 : H12AffineFastState.Bounded env18554 := by
  intro p hp
  have h : env18554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18553_18554 : H12AffineEnvironment.transform 6 8 env18553 = env18554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18553 == env18554) = true)

theorem identity18554 : scanCanonicalize (H12AffineFastState.compose env18554 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5172) := by decide +kernel

theorem selectedBound18554 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18555 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,5172,8203,5393,7441,1024,5173,4113,33,16,13627,8192,16,7220,5393,4097,2341,1284,13592,256,32,8248,513]

theorem envBound18555 : H12AffineFastState.Bounded env18555 := by
  intro p hp
  have h : env18555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18554_18555 : H12AffineEnvironment.transform 14 5172 env18554 = env18555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5172 env18554 == env18555) = true)

theorem identity18555 : scanCanonicalize (H12AffineFastState.compose env18555 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound18555 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env18556 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,5172,262,5393,7441,1024,5173,4113,33,16,5174,269,16,7220,5393,4097,2341,1284,5141,256,32,309,513]

theorem envBound18556 : H12AffineFastState.Bounded env18556 := by
  intro p hp
  have h : env18556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18555_18556 : H12AffineEnvironment.transform 12 269 env18555 = env18556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env18555 == env18556) = true)

theorem identity18556 : scanCanonicalize (H12AffineFastState.compose env18556 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound18556 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env18557 : List Nat := [2,4,8,16,32,16,8,256,512,1024,302,4096,269,5377,5172,262,5393,5183,1024,5173,4113,33,16,5174,269,16,5402,5393,4097,11,1284,5141,256,32,309,513]

theorem envBound18557 : H12AffineFastState.Bounded env18557 := by
  intro p hp
  have h : env18557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18556_18557 : H12AffineEnvironment.transform 10 302 env18556 = env18557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env18556 == env18557) = true)

theorem identity18557 : scanCanonicalize (H12AffineFastState.compose env18557 (packedSelected [1,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18557 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env18558 : List Nat := [2,4,8,16,32,16,8,256,512,1024,302,1076,269,309,0,262,293,11,1024,1,1061,33,16,2,269,16,302,293,1077,11,1284,33,256,32,309,513]

theorem envBound18558 : H12AffineFastState.Bounded env18558 := by
  intro p hp
  have h : env18558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18557_18558 : H12AffineEnvironment.transform 11 1076 env18557 = env18558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env18557 == env18558) = true)

def env18559 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101384,41230,8328,17,2491565,2098569,4233,2524553,2102685,2142645,256,32,46212,2101777]

theorem envBound18559 : H12AffineFastState.Bounded env18559 := by
  intro p hp
  have h : env18559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18549_18559 : H12AffineEnvironment.transform 5 17 env18549 = env18559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18549 == env18559) = true)

theorem identity18559 : scanCanonicalize (H12AffineFastState.compose env18559 (packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18559 : packedSelected [0,1,9,10,11,14,18,21,22,23,26,27,28,32,35] rootPS < 2^1333 := by decide +kernel

def env18560 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,2097152,33,2101248,41230,8192,17,2491429,2098433,4097,2524417,2102549,2142525,256,32,46092,2101777]

theorem envBound18560 : H12AffineFastState.Bounded env18560 := by
  intro p hp
  have h : env18560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18559_18560 : H12AffineEnvironment.transform 6 8 env18559 = env18560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18559 == env18560) = true)

def env18561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound18561 : H12AffineFastState.Bounded env18561 := by
  intro p hp
  have h : env18561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18395_18561 : H12AffineEnvironment.transform 18 1025 env18395 = env18561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18395 == env18561) = true)

theorem identity18561 : scanCanonicalize (H12AffineFastState.compose env18561 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140300) := by decide +kernel

theorem selectedBound18561 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env18562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,16777216,8328,64,29868033,17014913,8548701,8830977,25265168,21184973,257,25419937,25362693,25207751]

theorem envBound18562 : H12AffineFastState.Bounded env18562 := by
  intro p hp
  have h : env18562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18561_18562 : H12AffineEnvironment.transform 20 140300 env18561 = env18562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 140300 env18561 == env18562) = true)

def env18563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,8388608,8631680,8328,64,4486529,8393985,8548701,8830977,143760,12645453,257,21793,46213,202311]

theorem envBound18563 : H12AffineFastState.Bounded env18563 := by
  intro p hp
  have h : env18563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18562_18563 : H12AffineEnvironment.transform 23 8631680 env18562 = env18563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8631680 env18562 == env18563) = true)

def env18564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180360,95496,8328,64,4486529,185737,45525,262281,143760,4338885,257,21793,46213,202311]

theorem envBound18564 : H12AffineFastState.Bounded env18564 := by
  intro p hp
  have h : env18564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18564 : H12AffineEnvironment.transform 22 180360 env18563 = env18564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env18563 == env18564) = true)

def env18565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180360,95496,8328,64,23809,185737,45525,262281,143760,400453,257,21793,46213,202311]

theorem envBound18565 : H12AffineFastState.Bounded env18565 := by
  intro p hp
  have h : env18565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18564_18565 : H12AffineEnvironment.transform 21 272512 env18564 = env18565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18564 == env18565) = true)

theorem identity18565 : scanCanonicalize (H12AffineFastState.compose env18565 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound18565 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,115870,272512,73754,95496,8328,64,23809,79131,45525,262281,119042,392407,257,21793,46213,63189]

theorem envBound18566 : H12AffineFastState.Bounded env18566 := by
  intro p hp
  have h : env18566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18565_18566 : H12AffineEnvironment.transform 16 123026 env18565 = env18566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env18565 == env18566) = true)

def env18567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,115870,32,73754,95496,8328,64,23809,79131,45525,10281,119042,119927,257,21793,46213,63189]

theorem envBound18567 : H12AffineFastState.Bounded env18567 := by
  intro p hp
  have h : env18567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18566_18567 : H12AffineEnvironment.transform 17 10400 env18566 = env18567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18566 == env18567) = true)

theorem identity18567 : scanCanonicalize (H12AffineFastState.compose env18567 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound18567 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,16401,10400,1025,32769,25629,32,32921,54667,8328,64,23809,38296,45525,10281,29057,29940,257,21793,46213,63189]

theorem envBound18568 : H12AffineFastState.Bounded env18568 := by
  intro p hp
  have h : env18568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18567_18568 : H12AffineEnvironment.transform 15 41091 env18567 = env18568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env18567 == env18568) = true)

theorem identity18568 : scanCanonicalize (H12AffineFastState.compose env18568 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18568 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env18569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,41091,13389,10400,1025,32769,4161,32,32921,41431,8328,64,10589,38296,45525,10281,1501,168,257,8573,46213,33417]

theorem envBound18569 : H12AffineFastState.Bounded env18569 := by
  intro p hp
  have h : env18569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18568_18569 : H12AffineEnvironment.transform 13 13404 env18568 = env18569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18568 == env18569) = true)

theorem identity18569 : scanCanonicalize (H12AffineFastState.compose env18569 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18569 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env18570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33247,5393,2556,1025,32769,4161,32,32921,32907,468,64,2049,38296,37001,2421,1501,168,257,33,38361,33417]

theorem envBound18570 : H12AffineFastState.Bounded env18570 := by
  intro p hp
  have h : env18570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18569_18570 : H12AffineEnvironment.transform 12 348 env18569 = env18570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18569 == env18570) = true)

theorem identity18570 : scanCanonicalize (H12AffineFastState.compose env18570 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound18570 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env18571 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5341,32768,32770,5324,2081,1025,32769,4161,32,32921,32907,9,64,2049,37957,37001,2216,1024,168,220,33,37892,33417]

theorem envBound18571 : H12AffineFastState.Bounded env18571 := by
  intro p hp
  have h : env18571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18570_18571 : H12AffineEnvironment.transform 7 221 env18570 = env18571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env18570 == env18571) = true)

theorem identity18571 : scanCanonicalize (H12AffineFastState.compose env18571 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound18571 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env18572 : List Nat := [2,4,8,16,32,64,128,221,512,1024,2048,4096,129,5341,137,139,5324,2081,1025,136,4161,32,16,2,9,64,2049,5324,4096,2216,1024,168,220,33,5261,512]

theorem envBound18572 : H12AffineFastState.Bounded env18572 := by
  intro p hp
  have h : env18572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18571_18572 : H12AffineEnvironment.transform 14 137 env18571 = env18572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18571 == env18572) = true)

theorem identity18572 : scanCanonicalize (H12AffineFastState.compose env18572 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18572 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18573 : List Nat := [2,4,8,16,1,64,128,221,512,1024,2048,4096,129,5341,137,139,5324,2048,1025,136,4161,1,16,2,9,64,2049,5324,4096,2185,1024,137,220,0,5261,512]

theorem envBound18573 : H12AffineFastState.Bounded env18573 := by
  intro p hp
  have h : env18573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18572_18573 : H12AffineEnvironment.transform 4 1 env18572 = env18573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18572 == env18573) = true)

theorem identity18573 : scanCanonicalize (H12AffineFastState.compose env18573 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound18573 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18574 : List Nat := [2,4,8,16,1,64,88,5,512,1024,2048,4096,89,5125,81,83,5140,2048,1025,80,4161,1,16,2,9,64,2049,5140,4096,2129,1024,81,4,0,5205,512]

theorem envBound18574 : H12AffineFastState.Bounded env18574 := by
  intro p hp
  have h : env18574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18573_18574 : H12AffineEnvironment.transform 6 88 env18573 = env18574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env18573 == env18574) = true)

theorem identity18574 : scanCanonicalize (H12AffineFastState.compose env18574 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18574 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env18575 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,8,5125,0,2,5140,2048,1025,1,4112,1,16,2,9,17,2049,5140,4096,2048,1024,0,4,0,5124,512]

theorem envBound18575 : H12AffineFastState.Bounded env18575 := by
  intro p hp
  have h : env18575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18574_18575 : H12AffineEnvironment.transform 5 17 env18574 = env18575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18574 == env18575) = true)

theorem identity18575 : scanCanonicalize (H12AffineFastState.compose env18575 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound18575 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18576 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,8,1045,0,2,1028,2048,1025,1,0,1,16,2,9,17,2049,1028,16,2048,1024,0,4,0,1044,512]

theorem envBound18576 : H12AffineFastState.Bounded env18576 := by
  intro p hp
  have h : env18576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18575_18576 : H12AffineEnvironment.transform 11 16 env18575 = env18576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18575 == env18576) = true)

theorem identity18576 : scanCanonicalize (H12AffineFastState.compose env18576 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound18576 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18577 : List Nat := [2,4,8,16,1,17,9,5,512,1024,1044,16,8,1045,0,2,1028,1044,1025,1,0,1,16,2,9,17,1045,1028,16,1044,1024,0,4,0,1044,512]

theorem envBound18577 : H12AffineFastState.Bounded env18577 := by
  intro p hp
  have h : env18577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18576_18577 : H12AffineEnvironment.transform 10 1044 env18576 = env18577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env18576 == env18577) = true)

theorem identity18577 : scanCanonicalize (H12AffineFastState.compose env18577 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound18577 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18578 : List Nat := [2,4,8,16,1,17,9,5,512,21,1,16,8,0,0,2,17,1,20,1,0,1,16,2,9,17,0,17,16,1,21,0,4,0,1,512]

theorem envBound18578 : H12AffineFastState.Bounded env18578 := by
  intro p hp
  have h : env18578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18577_18578 : H12AffineEnvironment.transform 9 21 env18577 = env18578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env18577 == env18578) = true)

theorem identity18578 : scanCanonicalize (H12AffineFastState.compose env18578 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound18578 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18579 : List Nat := [2,4,8,4,1,5,9,5,512,1,1,4,8,0,0,2,5,1,0,1,0,1,4,2,9,5,0,5,4,1,1,0,4,0,1,512]

theorem envBound18579 : H12AffineFastState.Bounded env18579 := by
  intro p hp
  have h : env18579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18578_18579 : H12AffineEnvironment.transform 3 4 env18578 = env18579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env18578 == env18579) = true)

def env18580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,115870,33,73754,95496,8328,64,23809,79131,45525,10280,119042,119926,257,21793,46213,63189]

theorem envBound18580 : H12AffineFastState.Bounded env18580 := by
  intro p hp
  have h : env18580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18566_18580 : H12AffineEnvironment.transform 17 10401 env18566 = env18580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env18566 == env18580) = true)

theorem identity18580 : scanCanonicalize (H12AffineFastState.compose env18580 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound18580 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env18581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,478,57676,10401,1025,32769,50496,33,8644,29910,8328,64,23809,13509,45525,10280,53468,54696,257,21793,46213,63189]

theorem envBound18581 : H12AffineFastState.Bounded env18581 := by
  intro p hp
  have h : env18581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18580_18581 : H12AffineEnvironment.transform 15 478 env18580 = env18581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env18580 == env18581) = true)

theorem identity18581 : scanCanonicalize (H12AffineFastState.compose env18581 (packedSelected [1,3,4,7,9,10,16,17,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18581 : packedSelected [1,3,4,7,9,10,16,17,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49304,2421,1025,32769,50496,33,16,21762,348,64,23809,5393,36865,2556,53468,54696,257,21793,38225,55041]

theorem envBound18582 : H12AffineFastState.Bounded env18582 := by
  intro p hp
  have h : env18582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18581_18582 : H12AffineEnvironment.transform 12 468 env18581 = env18582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18581 == env18582) = true)

theorem identity18582 : scanCanonicalize (H12AffineFastState.compose env18582 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound18582 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env18583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,478,16400,2421,1025,137,17864,33,16,21762,348,64,23809,5393,4233,2556,20564,21792,257,21793,5593,22409]

theorem envBound18583 : H12AffineFastState.Bounded env18583 := by
  intro p hp
  have h : env18583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18582_18583 : H12AffineEnvironment.transform 14 136 env18582 = env18583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env18582 == env18583) = true)

theorem identity18583 : scanCanonicalize (H12AffineFastState.compose env18583 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound18583 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5528,2421,1025,137,4160,33,16,138,348,64,2185,5393,4233,2556,1500,168,257,169,5593,513]

theorem envBound18584 : H12AffineFastState.Bounded env18584 := by
  intro p hp
  have h : env18584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18583_18584 : H12AffineEnvironment.transform 13 5512 env18583 = env18584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env18583 == env18584) = true)

def env18585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180360,95496,8328,64,23808,185737,45525,262281,143760,400452,257,21793,46213,202311]

theorem envBound18585 : H12AffineFastState.Bounded env18585 := by
  intro p hp
  have h : env18585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18564_18585 : H12AffineEnvironment.transform 21 272513 env18564 = env18585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18564 == env18585) = true)

theorem identity18585 : scanCanonicalize (H12AffineFastState.compose env18585 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18585 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272513,180360,21763,8328,64,23808,185737,45525,262281,143760,400452,257,21793,46213,144972]

theorem envBound18586 : H12AffineFastState.Bounded env18586 := by
  intro p hp
  have h : env18586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18585_18586 : H12AffineEnvironment.transform 15 8203 env18585 = env18586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18585 == env18586) = true)

def env18587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272393,180224,21763,8192,64,23808,185601,45405,262145,143640,400452,257,21793,46093,144972]

theorem envBound18587 : H12AffineFastState.Bounded env18587 := by
  intro p hp
  have h : env18587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18586_18587 : H12AffineEnvironment.transform 6 8 env18586 = env18587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18586 == env18587) = true)

def env18588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58396,272393,16,21763,8192,64,23808,5393,45405,262145,61704,318548,257,21793,46093,63068]

theorem envBound18588 : H12AffineFastState.Bounded env18588 := by
  intro p hp
  have h : env18588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18587_18588 : H12AffineEnvironment.transform 16 49168 env18587 = env18588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18587 == env18588) = true)

theorem identity18588 : scanCanonicalize (H12AffineFastState.compose env18588 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound18588 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38161,262144,1025,32769,45341,272393,16,2,8192,64,2049,5393,45405,262145,41993,297301,257,32,46093,41821]

theorem envBound18589 : H12AffineFastState.Bounded env18589 := by
  intro p hp
  have h : env18589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18588_18589 : H12AffineEnvironment.transform 13 5377 env18588 = env18589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env18588 == env18589) = true)

theorem identity18589 : scanCanonicalize (H12AffineFastState.compose env18589 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18589 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env18590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38161,10280,1025,32769,45341,33,16,2,8192,64,2049,5393,45405,10281,41993,41341,257,32,46093,41821]

theorem envBound18590 : H12AffineFastState.Bounded env18590 := by
  intro p hp
  have h : env18590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18589_18590 : H12AffineEnvironment.transform 17 10280 env18589 = env18590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18589 == env18590) = true)

def env18591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58397,272393,17,21763,8192,64,23808,5392,45405,262145,61705,318549,257,21793,46093,63069]

theorem envBound18591 : H12AffineFastState.Bounded env18591 := by
  intro p hp
  have h : env18591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18587_18591 : H12AffineEnvironment.transform 16 49169 env18587 = env18591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18587 == env18591) = true)

theorem identity18591 : scanCanonicalize (H12AffineFastState.compose env18591 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound18591 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,32041,1025,32769,58397,21792,17,21763,8192,64,23808,5392,45405,32040,61705,41340,257,21793,46093,63069]

theorem envBound18592 : H12AffineFastState.Bounded env18592 := by
  intro p hp
  have h : env18592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18591_18592 : H12AffineEnvironment.transform 17 32041 env18591 = env18592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env18591 == env18592) = true)

theorem identity18592 : scanCanonicalize (H12AffineFastState.compose env18592 (packedSelected [2,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18592 : packedSelected [2,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env18593 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,13389,32041,1025,29789,4161,21792,17,21763,8192,64,23808,5392,17665,32040,1365,21792,257,21793,16465,513]

theorem envBound18593 : H12AffineFastState.Bounded env18593 := by
  intro p hp
  have h : env18593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18592_18593 : H12AffineEnvironment.transform 14 29788 env18592 = env18593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18592 == env18593) = true)

theorem identity18593 : scanCanonicalize (H12AffineFastState.compose env18593 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18593 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,9292,8203,13389,11577,1025,9293,4161,1328,17,1299,8192,64,3344,5392,5393,11576,1365,1328,257,1329,4161,513]

theorem envBound18594 : H12AffineFastState.Bounded env18594 := by
  intro p hp
  have h : env18594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18593_18594 : H12AffineEnvironment.transform 13 4112 env18593 = env18594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env18593 == env18594) = true)

def env18595 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,140300,272392,180225,21763,8193,64,23808,185600,45404,262144,143641,400452,257,21793,46092,144972]

theorem envBound18595 : H12AffineFastState.Bounded env18595 := by
  intro p hp
  have h : env18595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18586_18595 : H12AffineEnvironment.transform 6 9 env18586 = env18595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18586 == env18595) = true)

def env18596 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,58396,272392,17,21763,8193,64,23808,5392,45404,262144,61705,318548,257,21793,46092,63068]

theorem envBound18596 : H12AffineFastState.Bounded env18596 := by
  intro p hp
  have h : env18596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18595_18596 : H12AffineEnvironment.transform 16 49168 env18595 = env18596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env18595 == env18596) = true)

theorem identity18596 : scanCanonicalize (H12AffineFastState.compose env18596 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound18596 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,56437,1025,32769,58396,62589,17,21763,8193,64,23808,5392,45404,56437,61705,33,257,21793,46092,63068]

theorem envBound18597 : H12AffineFastState.Bounded env18597 := by
  intro p hp
  have h : env18597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18596_18597 : H12AffineEnvironment.transform 17 56437 env18596 = env18597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env18596 == env18597) = true)

theorem identity18597 : scanCanonicalize (H12AffineFastState.compose env18597 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound18597 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,24908,32041,1025,8541,17728,21793,17,21763,8193,64,23808,5392,4096,32041,20565,33,257,21793,5456,22272]

theorem envBound18598 : H12AffineFastState.Bounded env18598 := by
  intro p hp
  have h : env18598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18597_18598 : H12AffineEnvironment.transform 14 8540 env18597 = env18598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env18597 == env18598) = true)

theorem identity18598 : scanCanonicalize (H12AffineFastState.compose env18598 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18598 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8203,5440,2341,1025,8541,12620,8493,17,8463,8193,64,10508,5392,4096,2341,9305,33,257,8493,5456,8972]

theorem envBound18599 : H12AffineFastState.Bounded env18599 := by
  intro p hp
  have h : env18599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18598_18599 : H12AffineEnvironment.transform 13 13324 env18598 = env18599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18598 == env18599) = true)

theorem identity18599 : scanCanonicalize (H12AffineFastState.compose env18599 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18599 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18600 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,8203,5392,2341,1025,8461,12572,8493,17,8463,8193,16,10508,5392,4096,2341,9225,33,257,8493,5376,8972]

theorem envBound18600 : H12AffineFastState.Bounded env18600 := by
  intro p hp
  have h : env18600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18599_18600 : H12AffineEnvironment.transform 5 16 env18599 = env18600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18599 == env18600) = true)

theorem identity18600 : scanCanonicalize (H12AffineFastState.compose env18600 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound18600 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env18601 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5417,293,5157,5410,5392,2341,1025,5156,1077,5124,17,5158,5416,16,7205,5392,4096,2341,4384,33,257,5124,5376,5669]

theorem envBound18601 : H12AffineFastState.Bounded env18601 := by
  intro p hp
  have h : env18601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18600_18601 : H12AffineEnvironment.transform 12 5417 env18600 = env18601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env18600 == env18601) = true)

theorem identity18601 : scanCanonicalize (H12AffineFastState.compose env18601 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18601 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env18602 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,5417,293,5157,5410,5392,1297,1025,5156,1077,5124,17,5158,5416,16,4113,5392,4096,1297,4384,33,257,5124,5376,5669]

theorem envBound18602 : H12AffineFastState.Bounded env18602 := by
  intro p hp
  have h : env18602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18601_18602 : H12AffineEnvironment.transform 10 1076 env18601 = env18602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env18601 == env18602) = true)

theorem identity18602 : scanCanonicalize (H12AffineFastState.compose env18602 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18602 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18603 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,4096,4381,293,4113,4374,4388,293,53,4112,1,4144,17,4114,4380,16,4113,4388,4096,293,4384,33,257,4144,4404,4625]

theorem envBound18603 : H12AffineFastState.Bounded env18603 := by
  intro p hp
  have h : env18603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18602_18603 : H12AffineEnvironment.transform 9 52 env18602 = env18603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18602 == env18603) = true)

theorem identity18603 : scanCanonicalize (H12AffineFastState.compose env18603 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound18603 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18604 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,16,269,293,1,262,308,293,53,0,1,32,17,2,268,16,1,308,16,293,304,33,257,32,292,513]

theorem envBound18604 : H12AffineFastState.Bounded env18604 := by
  intro p hp
  have h : env18604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18603_18604 : H12AffineEnvironment.transform 11 16 env18603 = env18604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18603 == env18604) = true)

def env18605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,58397,272392,16,21763,8193,64,23808,5393,45404,262144,61704,318549,257,21793,46092,63069]

theorem envBound18605 : H12AffineFastState.Bounded env18605 := by
  intro p hp
  have h : env18605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18595_18605 : H12AffineEnvironment.transform 16 49169 env18595 = env18605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18595 == env18605) = true)

theorem identity18605 : scanCanonicalize (H12AffineFastState.compose env18605 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound18605 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13389,262144,1025,29789,4161,272392,16,21763,8193,64,23808,5393,17664,262144,1364,272393,257,21793,16464,513]

theorem envBound18606 : H12AffineFastState.Bounded env18606 := by
  intro p hp
  have h : env18606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18605_18606 : H12AffineEnvironment.transform 14 29788 env18605 = env18606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env18605 == env18606) = true)

theorem identity18606 : scanCanonicalize (H12AffineFastState.compose env18606 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound18606 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,13389,10360,1025,29789,4161,112,16,21763,8193,64,23808,5393,17664,10360,1364,113,257,21793,16464,513]

theorem envBound18607 : H12AffineFastState.Bounded env18607 := by
  intro p hp
  have h : env18607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18606_18607 : H12AffineEnvironment.transform 17 10360 env18606 = env18607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env18606 == env18607) = true)

theorem identity18607 : scanCanonicalize (H12AffineFastState.compose env18607 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18607 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env18608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,13389,10360,1025,1,4161,112,16,8543,8193,64,10588,5393,12636,10360,1364,113,257,8573,13324,513]

theorem envBound18608 : H12AffineFastState.Bounded env18608 := by
  intro p hp
  have h : env18608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18607_18608 : H12AffineEnvironment.transform 13 13404 env18607 = env18608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18607 == env18608) = true)

theorem identity18608 : scanCanonicalize (H12AffineFastState.compose env18608 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18608 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5456,0,263,5441,2420,1025,1,4161,112,16,83,269,64,2128,5393,4176,2420,1364,113,257,113,5376,513]

theorem envBound18609 : H12AffineFastState.Bounded env18609 := by
  intro p hp
  have h : env18609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18608_18609 : H12AffineEnvironment.transform 12 268 env18608 = env18609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18608 == env18609) = true)

theorem identity18609 : scanCanonicalize (H12AffineFastState.compose env18609 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound18609 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env18610 : List Nat := [2,4,8,16,32,64,9,256,512,548,2048,4096,268,4980,0,263,4965,2420,549,1,4161,112,16,83,269,64,2128,4917,4176,2420,880,113,257,113,4900,513]

theorem envBound18610 : H12AffineFastState.Bounded env18610 := by
  intro p hp
  have h : env18610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18609_18610 : H12AffineEnvironment.transform 9 548 env18609 = env18610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env18609 == env18610) = true)

theorem identity18610 : scanCanonicalize (H12AffineFastState.compose env18610 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18610 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env18611 : List Nat := [2,4,8,16,32,64,9,256,512,548,2048,17,268,869,0,263,884,2420,549,1,80,112,16,83,269,64,2128,804,65,2420,880,113,257,113,821,513]

theorem envBound18611 : H12AffineFastState.Bounded env18611 := by
  intro p hp
  have h : env18611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18610_18611 : H12AffineEnvironment.transform 11 17 env18610 = env18611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18610 == env18611) = true)

theorem identity18611 : scanCanonicalize (H12AffineFastState.compose env18611 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18611 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env18612 : List Nat := [2,4,8,16,32,64,9,37,512,548,2048,17,41,576,0,34,593,2129,549,1,80,112,16,83,40,64,2128,513,65,2129,597,113,36,113,528,513]

theorem envBound18612 : H12AffineFastState.Bounded env18612 := by
  intro p hp
  have h : env18612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18611_18612 : H12AffineEnvironment.transform 7 37 env18611 = env18612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18611 == env18612) = true)

theorem identity18612 : scanCanonicalize (H12AffineFastState.compose env18612 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound18612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18613 : List Nat := [2,4,8,16,32,1,9,37,512,548,2048,17,41,513,0,34,528,2064,549,1,17,49,16,18,40,1,2065,513,0,2064,532,48,36,48,528,513]

theorem envBound18613 : H12AffineFastState.Bounded env18613 := by
  intro p hp
  have h : env18613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18612_18613 : H12AffineEnvironment.transform 5 1 env18612 = env18613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env18612 == env18613) = true)

theorem identity18613 : scanCanonicalize (H12AffineFastState.compose env18613 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound18613 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env18614 : List Nat := [2,4,8,16,32,1,9,37,512,548,1,17,41,513,0,34,528,17,549,1,17,49,16,18,40,1,16,513,0,17,532,48,36,48,528,513]

theorem envBound18614 : H12AffineFastState.Bounded env18614 := by
  intro p hp
  have h : env18614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18613_18614 : H12AffineEnvironment.transform 10 1 env18613 = env18614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18613 == env18614) = true)

theorem identity18614 : scanCanonicalize (H12AffineFastState.compose env18614 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound18614 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18615 : List Nat := [2,4,8,16,32,1,9,37,0,36,1,17,41,1,0,34,16,17,37,1,17,49,16,18,40,1,16,1,0,17,20,48,36,48,16,1]

theorem envBound18615 : H12AffineFastState.Bounded env18615 := by
  intro p hp
  have h : env18615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18614_18615 : H12AffineEnvironment.transform 8 0 env18614 = env18615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18614 == env18615) = true)

theorem identity18615 : scanCanonicalize (H12AffineFastState.compose env18615 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18616 : List Nat := [2,4,8,16,16,1,9,21,0,20,1,17,25,1,0,18,16,17,21,1,17,1,16,18,24,1,16,1,0,17,20,0,20,0,16,1]

theorem envBound18616 : H12AffineFastState.Bounded env18616 := by
  intro p hp
  have h : env18616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18615_18616 : H12AffineEnvironment.transform 4 16 env18615 = env18616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18615 == env18616) = true)

theorem identity18616 : scanCanonicalize (H12AffineFastState.compose env18616 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18617 : List Nat := [2,4,8,0,0,1,9,5,0,4,1,1,9,1,0,2,0,1,5,1,1,1,0,2,8,1,0,1,0,1,4,0,4,0,0,1]

theorem envBound18617 : H12AffineFastState.Bounded env18617 := by
  intro p hp
  have h : env18617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18616_18617 : H12AffineEnvironment.transform 3 0 env18616 = env18617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18616 == env18617) = true)

def env18618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,4194304,180361,95497,8328,64,4486529,185736,45524,262280,143760,4338884,257,21793,46213,202311]

theorem envBound18618 : H12AffineFastState.Bounded env18618 := by
  intro p hp
  have h : env18618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18618 : H12AffineEnvironment.transform 22 180361 env18563 = env18618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env18563 == env18618) = true)

def env18619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272512,180361,95497,8328,64,23809,185736,45524,262280,143760,400452,257,21793,46213,202311]

theorem envBound18619 : H12AffineFastState.Bounded env18619 := by
  intro p hp
  have h : env18619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18618_18619 : H12AffineEnvironment.transform 21 272512 env18618 = env18619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env18618 == env18619) = true)

theorem identity18619 : scanCanonicalize (H12AffineFastState.compose env18619 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound18619 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272512,120015,95497,8328,64,23809,115150,45524,262280,75222,329730,257,21793,46213,513]

theorem envBound18620 : H12AffineFastState.Bounded env18620 := by
  intro p hp
  have h : env18620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18619_18620 : H12AffineEnvironment.transform 16 70726 env18619 = env18620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env18619 == env18620) = true)

def env18621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272392,119879,95497,8192,64,23809,115014,45404,262144,75102,329730,257,21793,46093,513]

theorem envBound18621 : H12AffineFastState.Bounded env18621 := by
  intro p hp
  have h : env18621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18620_18621 : H12AffineEnvironment.transform 6 8 env18620 = env18621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18620 == env18621) = true)

theorem identity18621 : scanCanonicalize (H12AffineFastState.compose env18621 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18621 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,262144,1025,32769,77898,272392,106523,65877,8192,64,10589,111898,45404,262144,75102,329730,257,8573,46093,513]

theorem envBound18622 : H12AffineFastState.Bounded env18622 := by
  intro p hp
  have h : env18622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18621_18622 : H12AffineEnvironment.transform 13 13404 env18621 = env18622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18621 == env18622) = true)

theorem identity18622 : scanCanonicalize (H12AffineFastState.compose env18622 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 100466) := by decide +kernel

theorem selectedBound18622 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env18623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,70726,100466,1025,32769,77898,106618,106523,65877,8192,64,10589,111898,45404,100466,75102,32880,257,8573,46093,513]

theorem envBound18623 : H12AffineFastState.Bounded env18623 := by
  intro p hp
  have h : env18623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18622_18623 : H12AffineEnvironment.transform 17 100466 env18622 = env18623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100466 env18622 == env18623) = true)

theorem identity18623 : scanCanonicalize (H12AffineFastState.compose env18623 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound18623 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env18624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,5393,35109,1025,32769,12573,41261,41292,2,8192,64,10589,46157,45404,35109,9225,32880,257,8573,46093,513]

theorem envBound18624 : H12AffineFastState.Bounded env18624 := by
  intro p hp
  have h : env18624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18623_18624 : H12AffineEnvironment.transform 15 343 env18623 = env18624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env18623 == env18624) = true)

theorem identity18624 : scanCanonicalize (H12AffineFastState.compose env18624 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound18624 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4161,32768,343,5393,35109,1025,32769,5376,34096,34129,2,1053,64,3392,36944,38209,35109,20,32880,257,1376,36880,513]

theorem envBound18625 : H12AffineFastState.Bounded env18625 := by
  intro p hp
  have h : env18625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18624_18625 : H12AffineEnvironment.transform 12 1053 env18624 = env18625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env18624 == env18625) = true)

theorem identity18625 : scanCanonicalize (H12AffineFastState.compose env18625 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18625 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env18626 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,4161,32768,34,5220,34896,1025,32769,5237,33861,33828,2,1053,64,3125,36944,37940,34896,20,32880,116,1045,36880,513]

theorem envBound18626 : H12AffineFastState.Bounded env18626 := by
  intro p hp
  have h : env18626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18625_18626 : H12AffineEnvironment.transform 7 117 env18625 = env18626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18625 == env18626) = true)

theorem identity18626 : scanCanonicalize (H12AffineFastState.compose env18626 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18626 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env18627 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1053,4161,1,34,5220,2129,1025,0,5237,1092,1061,2,1053,64,3125,4177,5173,2129,20,113,116,1045,4113,513]

theorem envBound18627 : H12AffineFastState.Bounded env18627 := by
  intro p hp
  have h : env18627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18626_18627 : H12AffineEnvironment.transform 14 1 env18626 = env18627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18626 == env18627) = true)

theorem identity18627 : scanCanonicalize (H12AffineFastState.compose env18627 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18627 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env18628 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,41,4161,1,34,4176,2129,53,0,4161,112,17,2,41,64,2049,4177,4097,2129,20,113,116,33,4113,513]

theorem envBound18628 : H12AffineFastState.Bounded env18628 := by
  intro p hp
  have h : env18628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18627_18628 : H12AffineEnvironment.transform 9 52 env18627 = env18628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18627 == env18628) = true)

theorem identity18628 : scanCanonicalize (H12AffineFastState.compose env18628 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound18628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18629 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,96,41,33,1,34,48,2129,53,0,33,112,17,2,41,64,2049,49,97,2129,20,113,116,33,113,513]

theorem envBound18629 : H12AffineFastState.Bounded env18629 := by
  intro p hp
  have h : env18629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18628_18629 : H12AffineEnvironment.transform 11 96 env18628 = env18629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env18628 == env18629) = true)

theorem identity18629 : scanCanonicalize (H12AffineFastState.compose env18629 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18630 : List Nat := [2,4,8,16,32,49,8,4,512,52,2048,17,41,33,1,34,48,2080,53,0,33,1,17,2,41,49,2049,49,16,2080,20,0,5,33,0,513]

theorem envBound18630 : H12AffineFastState.Bounded env18630 := by
  intro p hp
  have h : env18630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18629_18630 : H12AffineEnvironment.transform 5 49 env18629 = env18630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18629 == env18630) = true)

theorem identity18630 : scanCanonicalize (H12AffineFastState.compose env18630 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound18630 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18631 : List Nat := [2,4,8,16,32,49,8,4,32,52,2048,17,41,33,1,34,48,2080,53,0,33,1,17,2,41,49,2049,49,16,2080,20,0,5,33,0,33]

theorem envBound18631 : H12AffineFastState.Bounded env18631 := by
  intro p hp
  have h : env18631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18630_18631 : H12AffineEnvironment.transform 8 32 env18630 = env18631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env18630 == env18631) = true)

theorem identity18631 : scanCanonicalize (H12AffineFastState.compose env18631 (packedSelected [0,1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound18631 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env18632 : List Nat := [2,4,8,16,32,49,8,4,32,52,17,17,41,33,1,34,48,49,53,0,33,1,17,2,41,49,16,49,16,49,20,0,5,33,0,33]

theorem envBound18632 : H12AffineFastState.Bounded env18632 := by
  intro p hp
  have h : env18632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18631_18632 : H12AffineEnvironment.transform 10 17 env18631 = env18632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env18631 == env18632) = true)

def env18633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,77898,272393,119878,95497,8193,64,23809,115015,45405,262145,75103,329730,257,21793,46092,513]

theorem envBound18633 : H12AffineFastState.Bounded env18633 := by
  intro p hp
  have h : env18633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18620_18633 : H12AffineEnvironment.transform 6 9 env18620 = env18633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18620 == env18633) = true)

def env18634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1025,32769,77898,33,119878,95497,8193,64,23809,115015,45405,10281,75103,73770,257,21793,46092,513]

theorem envBound18634 : H12AffineFastState.Bounded env18634 := by
  intro p hp
  have h : env18634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18633_18634 : H12AffineEnvironment.transform 17 10280 env18633 = env18634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18633 == env18634) = true)

theorem identity18634 : scanCanonicalize (H12AffineFastState.compose env18634 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound18634 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env18635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,70726,10280,1025,8540,77898,33,95515,95497,8193,64,23809,90138,4096,10281,75103,73770,257,21793,5457,513]

theorem envBound18635 : H12AffineFastState.Bounded env18635 := by
  intro p hp
  have h : env18635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18634_18635 : H12AffineEnvironment.transform 14 8541 env18634 = env18635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env18634 == env18635) = true)

theorem identity18635 : scanCanonicalize (H12AffineFastState.compose env18635 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound18635 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21590,16400,10280,1025,8540,25628,33,8525,8543,8193,64,23809,13388,4096,10281,28937,29820,257,21793,5457,513]

theorem envBound18636 : H12AffineFastState.Bounded env18636 := by
  intro p hp
  have h : env18636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18635_18636 : H12AffineEnvironment.transform 15 21590 env18635 = env18636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env18635 == env18636) = true)

theorem identity18636 : scanCanonicalize (H12AffineFastState.compose env18636 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18636 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21590,16400,2420,1025,0,17728,33,17,3,349,64,23809,5392,4096,2421,20565,21792,257,21793,5457,513]

theorem envBound18637 : H12AffineFastState.Bounded env18637 := by
  intro p hp
  have h : env18637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18636_18637 : H12AffineEnvironment.transform 12 348 env18636 = env18637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18636 == env18637) = true)

theorem identity18637 : scanCanonicalize (H12AffineFastState.compose env18637 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18637 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env18638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5392,2420,1025,0,4160,33,17,3,349,64,2049,5392,4096,2421,1365,32,257,33,5457,513]

theorem envBound18638 : H12AffineFastState.Bounded env18638 := by
  intro p hp
  have h : env18638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18637_18638 : H12AffineEnvironment.transform 13 5376 env18637 = env18638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18637 == env18638) = true)

theorem identity18638 : scanCanonicalize (H12AffineFastState.compose env18638 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound18638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18639 : List Nat := [2,4,8,16,32,64,9,256,512,565,2048,4096,348,4917,1,342,4901,2420,564,0,4160,33,17,3,349,64,2049,4901,4096,2421,864,32,257,33,4964,513]

theorem envBound18639 : H12AffineFastState.Bounded env18639 := by
  intro p hp
  have h : env18639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18638_18639 : H12AffineEnvironment.transform 9 565 env18638 = env18639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env18638 == env18639) = true)

theorem identity18639 : scanCanonicalize (H12AffineFastState.compose env18639 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18639 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18640 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,4096,268,4917,1,262,4901,2340,564,0,4112,33,17,3,269,16,2049,4901,4096,2341,816,32,257,33,4916,513]

theorem envBound18640 : H12AffineFastState.Bounded env18640 := by
  intro p hp
  have h : env18640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18639_18640 : H12AffineEnvironment.transform 5 16 env18639 = env18640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18639 == env18640) = true)

theorem identity18640 : scanCanonicalize (H12AffineFastState.compose env18640 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound18640 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18641 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,512,268,309,1,262,293,2340,564,0,528,33,17,3,269,16,2049,293,512,2341,816,32,257,33,308,513]

theorem envBound18641 : H12AffineFastState.Bounded env18641 := by
  intro p hp
  have h : env18641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18640_18641 : H12AffineEnvironment.transform 11 512 env18640 = env18641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env18640 == env18641) = true)

theorem identity18641 : scanCanonicalize (H12AffineFastState.compose env18641 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound18641 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18642 : List Nat := [2,4,8,16,32,16,9,256,512,565,821,512,268,309,1,262,293,529,564,0,528,33,17,3,269,16,820,293,512,528,816,32,257,33,308,513]

theorem envBound18642 : H12AffineFastState.Bounded env18642 := by
  intro p hp
  have h : env18642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18641_18642 : H12AffineEnvironment.transform 10 821 env18641 = env18642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env18641 == env18642) = true)

theorem identity18642 : scanCanonicalize (H12AffineFastState.compose env18642 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound18642 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18643 : List Nat := [2,4,8,16,32,16,9,256,293,272,16,293,268,309,1,262,293,308,273,0,309,33,17,3,269,16,17,293,293,309,21,32,257,33,308,292]

theorem envBound18643 : H12AffineFastState.Bounded env18643 := by
  intro p hp
  have h : env18643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18642_18643 : H12AffineEnvironment.transform 8 293 env18642 = env18643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env18642 == env18643) = true)

theorem identity18643 : scanCanonicalize (H12AffineFastState.compose env18643 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18643 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env18644 : List Nat := [2,4,8,16,17,16,9,256,276,272,16,276,268,260,1,262,276,261,273,0,260,16,17,3,269,16,17,276,276,260,21,17,257,16,261,277]

theorem envBound18644 : H12AffineFastState.Bounded env18644 := by
  intro p hp
  have h : env18644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18643_18644 : H12AffineEnvironment.transform 4 17 env18643 = env18644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18643 == env18644) = true)

theorem identity18644 : scanCanonicalize (H12AffineFastState.compose env18644 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18644 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18645 : List Nat := [2,4,8,16,17,16,9,21,1,5,16,1,25,17,1,19,1,16,4,0,17,16,17,3,24,16,17,1,1,17,21,17,20,16,16,0]

theorem envBound18645 : H12AffineFastState.Bounded env18645 := by
  intro p hp
  have h : env18645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18644_18645 : H12AffineEnvironment.transform 7 21 env18644 = env18645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18644 == env18645) = true)

def env18646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10281,1025,32769,77898,32,119878,95497,8193,64,23809,115015,45405,10280,75103,73771,257,21793,46092,513]

theorem envBound18646 : H12AffineFastState.Bounded env18646 := by
  intro p hp
  have h : env18646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18633_18646 : H12AffineEnvironment.transform 17 10281 env18633 = env18646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env18633 == env18646) = true)

theorem identity18646 : scanCanonicalize (H12AffineFastState.compose env18646 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound18646 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10281,1025,32769,58396,32,16,41311,8193,64,23809,5393,45405,10280,61705,62589,257,21793,46092,513]

theorem envBound18647 : H12AffineFastState.Bounded env18647 := by
  intro p hp
  have h : env18647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18646_18647 : H12AffineEnvironment.transform 15 54358 env18646 = env18647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env18646 == env18647) = true)

theorem identity18647 : scanCanonicalize (H12AffineFastState.compose env18647 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15372) := by decide +kernel

theorem selectedBound18647 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env18648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,15372,32768,43098,48156,10281,1025,32769,38928,32,16,41311,8193,64,8461,5393,45405,10280,36101,34929,257,10541,46092,513]

theorem envBound18648 : H12AffineFastState.Bounded env18648 := by
  intro p hp
  have h : env18648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18647_18648 : H12AffineEnvironment.transform 13 15372 env18647 = env18648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15372 env18647 == env18648) = true)

theorem identity18648 : scanCanonicalize (H12AffineFastState.compose env18648 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound18648 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,8192,13404,32768,40970,46156,8313,1025,32769,36928,32,16,41311,8193,64,8461,5393,45405,8312,34133,32801,257,8573,46092,513]

theorem envBound18649 : H12AffineFastState.Bounded env18649 := by
  intro p hp
  have h : env18649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18648_18649 : H12AffineEnvironment.transform 10 80 env18648 = env18649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env18648 == env18649) = true)

theorem identity18649 : scanCanonicalize (H12AffineFastState.compose env18649 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 12620) := by decide +kernel

theorem selectedBound18649 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env18650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,8192,13404,12620,4422,1280,8313,1025,12621,8460,32,16,4115,8193,64,8461,5393,17,8312,13337,12653,257,8573,1344,513]

theorem envBound18650 : H12AffineFastState.Bounded env18650 := by
  intro p hp
  have h : env18650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18649_18650 : H12AffineEnvironment.transform 14 12620 env18649 = env18650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12620 env18649 == env18650) = true)

theorem identity18650 : scanCanonicalize (H12AffineFastState.compose env18650 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18650 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18651 : List Nat := [2,4,8,16,32,64,9,256,512,273,80,4096,8192,12621,12620,4422,17,8313,272,12621,8460,32,16,4115,8193,64,8461,4096,17,8312,12552,12653,257,8573,81,513]

theorem envBound18651 : H12AffineFastState.Bounded env18651 := by
  intro p hp
  have h : env18651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18650_18651 : H12AffineEnvironment.transform 9 273 env18650 = env18651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18650 == env18651) = true)

theorem identity18651 : scanCanonicalize (H12AffineFastState.compose env18651 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound18651 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env18652 : List Nat := [2,4,8,16,32,64,9,117,512,100,80,4096,8192,12344,12345,4147,17,8313,101,12344,8313,32,16,4115,8193,64,8312,4096,17,8312,12413,12312,116,8200,81,513]

theorem envBound18652 : H12AffineFastState.Bounded env18652 := by
  intro p hp
  have h : env18652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18651_18652 : H12AffineEnvironment.transform 7 117 env18651 = env18652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env18651 == env18652) = true)

def env18653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140300,272513,180361,95497,8328,64,23808,185736,45524,262280,143760,400453,257,21793,46213,202311]

theorem envBound18653 : H12AffineFastState.Bounded env18653 := by
  intro p hp
  have h : env18653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18618_18653 : H12AffineEnvironment.transform 21 272513 env18618 = env18653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env18618 == env18653) = true)

theorem identity18653 : scanCanonicalize (H12AffineFastState.compose env18653 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound18653 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,140300,272513,180361,41431,8328,64,23808,185736,45524,262280,143760,400453,257,21793,46213,180889]

theorem envBound18654 : H12AffineFastState.Bounded env18654 := by
  intro p hp
  have h : env18654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18653_18654 : H12AffineEnvironment.transform 15 54494 env18653 = env18654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env18653 == env18654) = true)

def env18655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,140300,272393,180225,41311,8192,64,23808,185600,45404,262144,143640,400453,257,21793,46093,180753]

theorem envBound18655 : H12AffineFastState.Bounded env18655 := by
  intro p hp
  have h : env18655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18654_18655 : H12AffineEnvironment.transform 6 8 env18654 = env18655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18654 == env18655) = true)

theorem identity18655 : scanCanonicalize (H12AffineFastState.compose env18655 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound18655 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env18656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13673,262144,1025,32769,4453,272393,62824,41311,8192,64,23808,57449,45404,262144,1137,272684,257,21793,46093,63352]

theorem envBound18656 : H12AffineFastState.Bounded env18656 := by
  intro p hp
  have h : env18656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18655_18656 : H12AffineEnvironment.transform 16 13673 env18655 = env18656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env18655 == env18656) = true)

theorem identity18656 : scanCanonicalize (H12AffineFastState.compose env18656 (packedSelected [0,1,3,4,10,14,18,19,20,22,23,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43357) := by decide +kernel

theorem selectedBound18656 : packedSelected [0,1,3,4,10,14,18,19,20,22,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env18657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13673,43357,1025,32769,4453,33108,62824,41311,8192,64,23808,57449,45404,43357,1137,32881,257,21793,46093,63352]

theorem envBound18657 : H12AffineFastState.Bounded env18657 := by
  intro p hp
  have h : env18657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18656_18657 : H12AffineEnvironment.transform 17 43357 env18656 = env18657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43357 env18656 == env18657) = true)

theorem identity18657 : scanCanonicalize (H12AffineFastState.compose env18657 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18,19,26] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound18657 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18,19,26] rootPS < 2^1333 := by decide +kernel

def env18658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,13673,43357,1025,32769,4453,33108,33077,41311,8192,64,10589,37940,45404,43357,1137,32881,257,8572,46093,33573]

theorem envBound18658 : H12AffineFastState.Bounded env18658 := by
  intro p hp
  have h : env18658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18657_18658 : H12AffineEnvironment.transform 13 13405 env18657 = env18658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env18657 == env18658) = true)

theorem identity18658 : scanCanonicalize (H12AffineFastState.compose env18658 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound18658 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env18659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8313,114,13673,2340,1025,8312,4453,8493,8524,294,8192,64,10589,13389,4389,2340,1137,8200,257,8572,5236,9052]

theorem envBound18659 : H12AffineFastState.Bounded env18659 := by
  intro p hp
  have h : env18659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18658_18659 : H12AffineEnvironment.transform 14 8313 env18658 = env18659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env18658 == env18659) = true)

theorem identity18659 : scanCanonicalize (H12AffineFastState.compose env18659 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18659 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env18660 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8313,114,13341,2128,1025,8312,4113,8281,8248,82,8192,64,10281,13389,4177,2128,1137,8200,117,8200,5236,8744]

theorem envBound18660 : H12AffineFastState.Bounded env18660 := by
  intro p hp
  have h : env18660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18659_18660 : H12AffineEnvironment.transform 7 116 env18659 = env18660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18659 == env18660) = true)

theorem identity18660 : scanCanonicalize (H12AffineFastState.compose env18660 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18660 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env18661 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,8192,13405,8313,114,13341,1124,1025,8312,4113,8281,8248,82,8192,64,9245,13389,4177,1124,1137,8200,117,8200,5236,8744]

theorem envBound18661 : H12AffineFastState.Bounded env18661 := by
  intro p hp
  have h : env18661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18660_18661 : H12AffineEnvironment.transform 10 1076 env18660 = env18661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env18660 == env18661) = true)

theorem identity18661 : scanCanonicalize (H12AffineFastState.compose env18661 (packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound18661 : packedSelected [0,3,4,5,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env18662 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1076,4096,5133,80,5236,114,16,1124,1025,5237,4113,5204,5173,82,5133,64,4112,64,4177,1124,1137,5125,117,5125,5236,5669]

theorem envBound18662 : H12AffineFastState.Bounded env18662 := by
  intro p hp
  have h : env18662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18661_18662 : H12AffineEnvironment.transform 12 5133 env18661 = env18662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env18661 == env18662) = true)

theorem identity18662 : scanCanonicalize (H12AffineFastState.compose env18662 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18662 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18663 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,4096,5133,1,5157,35,16,1077,1025,5156,4113,5125,5173,3,5133,17,4112,17,4096,1077,1056,5125,36,5125,5157,5669]

theorem envBound18663 : H12AffineFastState.Bounded env18663 := by
  intro p hp
  have h : env18663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18662_18663 : H12AffineEnvironment.transform 5 17 env18662 = env18663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18662 == env18663) = true)

theorem identity18663 : scanCanonicalize (H12AffineFastState.compose env18663 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound18663 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env18664 : List Nat := [2,4,8,16,32,17,8,37,10,1024,1076,4096,5133,1,5157,35,16,1077,1025,5156,4113,5125,5173,3,5133,17,4112,17,4096,1077,1056,5125,36,5125,5157,5167]

theorem envBound18664 : H12AffineFastState.Bounded env18664 := by
  intro p hp
  have h : env18664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18663_18664 : H12AffineEnvironment.transform 8 10 env18663 = env18664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env18663 == env18664) = true)

def env18665 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,140300,272392,180224,41310,8193,64,23808,185601,45405,262145,143641,400453,257,21793,46092,180752]

theorem envBound18665 : H12AffineFastState.Bounded env18665 := by
  intro p hp
  have h : env18665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18654_18665 : H12AffineEnvironment.transform 6 9 env18654 = env18665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18654 == env18665) = true)

theorem identity18665 : scanCanonicalize (H12AffineFastState.compose env18665 (packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound18665 : packedSelected [1,3,7,8,10,12,14,18,20,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env18666 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,171061,1025,32769,140300,177213,180224,41310,8193,64,23808,185601,45405,171060,143641,32880,257,21793,46092,180752]

theorem envBound18666 : H12AffineFastState.Bounded env18666 := by
  intro p hp
  have h : env18666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18665_18666 : H12AffineEnvironment.transform 17 171061 env18665 = env18666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env18665 == env18666) = true)

theorem identity18666 : scanCanonicalize (H12AffineFastState.compose env18666 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound18666 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env18667 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,23588,1025,32769,58397,29740,17,41310,8193,64,23808,5392,45405,23589,61704,32880,257,21793,46092,513]

theorem envBound18667 : H12AffineFastState.Bounded env18667 := by
  intro p hp
  have h : env18667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18666_18667 : H12AffineEnvironment.transform 16 49169 env18666 = env18667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env18666 == env18667) = true)

theorem identity18667 : scanCanonicalize (H12AffineFastState.compose env18667 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18667 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18668 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,41051,46109,10280,1025,32769,36881,32,17,41310,8193,64,10508,5392,45405,10281,34052,32880,257,8493,46092,513]

theorem envBound18668 : H12AffineFastState.Bounded env18668 := by
  intro p hp
  have h : env18668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18667_18668 : H12AffineEnvironment.transform 13 13324 env18667 = env18668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18667 == env18668) = true)

theorem identity18668 : scanCanonicalize (H12AffineFastState.compose env18668 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18668 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env18669 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,342,5392,10280,1025,8460,12572,32,17,83,8193,64,10508,5392,4176,10281,9225,8573,257,8493,5377,513]

theorem envBound18669 : H12AffineFastState.Bounded env18669 := by
  intro p hp
  have h : env18669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18668_18669 : H12AffineEnvironment.transform 14 8461 env18668 = env18669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env18668 == env18669) = true)

theorem identity18669 : scanCanonicalize (H12AffineFastState.compose env18669 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18669 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18670 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,342,5392,2340,1025,0,4112,32,17,83,269,64,2048,5392,4176,2341,1285,113,257,33,5377,513]

theorem envBound18670 : H12AffineFastState.Bounded env18670 := by
  intro p hp
  have h : env18670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18669_18670 : H12AffineEnvironment.transform 12 268 env18669 = env18670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18669 == env18670) = true)

theorem identity18670 : scanCanonicalize (H12AffineFastState.compose env18670 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18670 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env18671 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5392,2340,1025,0,4112,32,17,3,269,16,2048,5392,4096,2341,1285,33,257,33,5377,513]

theorem envBound18671 : H12AffineFastState.Bounded env18671 := by
  intro p hp
  have h : env18671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18670_18671 : H12AffineEnvironment.transform 5 16 env18670 = env18671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18670 == env18671) = true)

theorem identity18671 : scanCanonicalize (H12AffineFastState.compose env18671 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound18671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18672 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1328,268,48,1,262,32,2340,1025,0,1312,32,17,3,269,16,2048,32,1328,2341,1285,33,257,33,49,513]

theorem envBound18672 : H12AffineFastState.Bounded env18672 := by
  intro p hp
  have h : env18672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18671_18672 : H12AffineEnvironment.transform 11 1328 env18671 = env18672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env18671 == env18672) = true)

theorem identity18672 : scanCanonicalize (H12AffineFastState.compose env18672 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound18672 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18673 : List Nat := [2,4,8,16,32,16,9,256,277,1024,2048,1328,268,48,1,262,32,2340,1025,0,1312,32,17,3,269,16,2048,32,1328,2341,1285,33,257,33,49,276]

theorem envBound18673 : H12AffineFastState.Bounded env18673 := by
  intro p hp
  have h : env18673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18672_18673 : H12AffineEnvironment.transform 8 277 env18672 = env18673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env18672 == env18673) = true)

theorem identity18673 : scanCanonicalize (H12AffineFastState.compose env18673 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18673 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18674 : List Nat := [2,4,8,16,32,16,9,256,277,1024,1076,1328,268,48,1,262,32,1296,1025,0,1312,32,17,3,269,16,1076,32,1328,1297,1285,33,257,33,49,276]

theorem envBound18674 : H12AffineFastState.Bounded env18674 := by
  intro p hp
  have h : env18674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18673_18674 : H12AffineEnvironment.transform 10 1076 env18673 = env18674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env18673 == env18674) = true)

theorem identity18674 : scanCanonicalize (H12AffineFastState.compose env18674 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound18674 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18675 : List Nat := [2,4,8,16,32,16,9,256,277,304,260,0,268,48,1,262,32,32,305,0,16,32,17,3,269,16,260,32,0,33,53,33,257,33,49,276]

theorem envBound18675 : H12AffineFastState.Bounded env18675 := by
  intro p hp
  have h : env18675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18674_18675 : H12AffineEnvironment.transform 9 304 env18674 = env18675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env18674 == env18675) = true)

theorem identity18675 : scanCanonicalize (H12AffineFastState.compose env18675 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound18675 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env18676 : List Nat := [2,4,8,16,32,16,9,21,0,37,17,0,25,48,1,19,32,32,36,0,16,32,17,3,24,16,17,32,0,33,53,33,20,33,49,1]

theorem envBound18676 : H12AffineFastState.Bounded env18676 := by
  intro p hp
  have h : env18676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18675_18676 : H12AffineEnvironment.transform 7 21 env18675 = env18676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env18675 == env18676) = true)

theorem identity18676 : scanCanonicalize (H12AffineFastState.compose env18676 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18676 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env18677 : List Nat := [2,4,8,0,32,0,9,5,0,37,1,0,9,32,1,3,32,32,36,0,0,32,1,3,8,0,1,32,0,33,37,33,4,33,33,1]

end H12CloudChart1