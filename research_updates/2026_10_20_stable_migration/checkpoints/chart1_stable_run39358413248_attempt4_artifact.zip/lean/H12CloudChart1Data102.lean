import H12CloudChart1Data101

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound25837 : H12AffineFastState.Bounded env25837 := by
  intro p hp
  have h : env25837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25836_25837 : H12AffineEnvironment.transform 3 0 env25836 = env25837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25836 == env25837) = true)

theorem identity25837 : scanCanonicalize (H12AffineFastState.compose env25837 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound25837 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25838 : List Nat := [2,4,8,0,32,0,9,256,293,37,0,32,268,260,0,262,261,293,37,1,33,32,0,2,269,1,1,260,33,292,288,33,256,32,260,292]

theorem envBound25838 : H12AffineFastState.Bounded env25838 := by
  intro p hp
  have h : env25838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25837_25838 : H12AffineEnvironment.transform 8 293 env25837 = env25838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env25837 == env25838) = true)

theorem identity25838 : scanCanonicalize (H12AffineFastState.compose env25838 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25838 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25839 : List Nat := [2,4,8,0,1,0,9,256,260,4,0,1,268,260,0,262,261,260,4,1,0,1,0,2,269,1,1,260,0,261,257,0,256,1,260,261]

theorem envBound25839 : H12AffineFastState.Bounded env25839 := by
  intro p hp
  have h : env25839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25838_25839 : H12AffineEnvironment.transform 4 1 env25838 = env25839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25838 == env25839) = true)

def env25840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262521,412157,2114882,8328,65,215367,115151,2497708,35325,2590894,2336123,256,509970,469431,2535289]

theorem envBound25840 : H12AffineFastState.Bounded env25840 := by
  intro p hp
  have h : env25840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25785_25840 : H12AffineEnvironment.transform 21 2262521 env25785 = env25840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262521 env25785 == env25840) = true)

def env25841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,21762,8328,65,215367,115151,396524,35325,497902,243003,256,509970,469431,442169]

theorem envBound25841 : H12AffineFastState.Bounded env25841 := by
  intro p hp
  have h : env25841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25840_25841 : H12AffineEnvironment.transform 20 4160 env25840 = env25841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env25840 == env25841) = true)

theorem identity25841 : scanCanonicalize (H12AffineFastState.compose env25841 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound25841 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169401,62661,21762,8328,65,215367,115151,45524,35325,75222,243003,256,95530,103567,513]

theorem envBound25842 : H12AffineFastState.Bounded env25842 := by
  intro p hp
  have h : env25842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25841_25842 : H12AffineEnvironment.transform 17 179512 env25841 = env25842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env25841 == env25842) = true)

def env25843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169265,62541,21762,8192,65,215367,115015,45404,35189,75102,243003,256,95530,103431,513]

theorem envBound25843 : H12AffineFastState.Bounded env25843 := by
  intro p hp
  have h : env25843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25842_25843 : H12AffineEnvironment.transform 6 8 env25842 = env25843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25842 == env25843) = true)

theorem identity25843 : scanCanonicalize (H12AffineFastState.compose env25843 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound25843 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,122147,1024,32769,4160,128298,62541,21762,8192,65,10588,115015,45404,35189,75102,54560,256,95530,103431,513]

theorem envBound25844 : H12AffineFastState.Bounded env25844 := by
  intro p hp
  have h : env25844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25843_25844 : H12AffineEnvironment.transform 16 90139 env25843 = env25844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env25843 == env25844) = true)

theorem identity25844 : scanCanonicalize (H12AffineFastState.compose env25844 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 20789) := by decide +kernel

theorem selectedBound25844 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env25845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20789,65536,90139,68630,1024,20788,4160,74783,9592,21762,8192,65,10588,69746,24681,22592,75102,1045,256,95530,83250,513]

theorem envBound25845 : H12AffineFastState.Bounded env25845 := by
  intro p hp
  have h : env25845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25844_25845 : H12AffineEnvironment.transform 14 20789 env25844 = env25845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20789 env25844 == env25845) = true)

theorem identity25845 : scanCanonicalize (H12AffineFastState.compose env25845 (packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound25845 : packedSelected [7,8,10,14,17,20,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env25846 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,16384,20789,65536,90139,67847,273,20788,4160,73998,8297,20499,8192,65,10588,69746,24681,22592,73807,260,256,94267,81955,513]

theorem envBound25846 : H12AffineFastState.Bounded env25846 := by
  intro p hp
  have h : env25846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25845_25846 : H12AffineEnvironment.transform 9 273 env25845 = env25846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env25845 == env25846) = true)

theorem identity25846 : scanCanonicalize (H12AffineFastState.compose env25846 (packedSelected [1,2,3,4,6,9,11,12,14,20,23,24,28,41] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound25846 : packedSelected [1,2,3,4,6,9,11,12,14,20,23,24,28,41] rootPS < 2^1333 := by decide +kernel

def env25847 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,16384,20789,65536,81971,67847,273,20788,4160,65830,65,20499,40,65,2420,69746,16449,22592,65639,260,256,86035,81955,513]

theorem envBound25847 : H12AffineFastState.Bounded env25847 := by
  intro p hp
  have h : env25847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25846_25847 : H12AffineEnvironment.transform 12 40 env25846 = env25847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env25846 == env25847) = true)

theorem identity25847 : scanCanonicalize (H12AffineFastState.compose env25847 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound25847 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env25848 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,16384,20789,114,16449,2421,273,20788,4160,340,65,20499,40,65,2420,4096,16449,22592,21,260,256,20577,16465,513]

theorem envBound25848 : H12AffineFastState.Bounded env25848 := by
  intro p hp
  have h : env25848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25847_25848 : H12AffineEnvironment.transform 15 114 env25847 = env25848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env25847 == env25848) = true)

theorem identity25848 : scanCanonicalize (H12AffineFastState.compose env25848 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25848 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25849 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,40,16384,20496,114,16449,2128,52,20497,4160,113,65,20499,40,65,2129,4096,16449,22592,21,33,37,20577,16465,513]

theorem envBound25849 : H12AffineFastState.Bounded env25849 := by
  intro p hp
  have h : env25849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25848_25849 : H12AffineEnvironment.transform 7 37 env25848 = env25849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25848 == env25849) = true)

theorem identity25849 : scanCanonicalize (H12AffineFastState.compose env25849 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25849 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25850 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,16384,20496,34,16401,2048,52,20497,4112,33,17,20499,40,17,2049,4096,16401,22544,21,33,37,20529,16385,513]

theorem envBound25850 : H12AffineFastState.Bounded env25850 := by
  intro p hp
  have h : env25850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25849_25850 : H12AffineEnvironment.transform 5 16 env25849 = env25850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25849 == env25850) = true)

theorem identity25850 : scanCanonicalize (H12AffineFastState.compose env25850 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25851 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,4096,40,4113,1,34,4096,2048,52,0,4112,33,17,2,40,17,2049,4096,4096,2049,21,33,37,32,4112,513]

theorem envBound25851 : H12AffineFastState.Bounded env25851 := by
  intro p hp
  have h : env25851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25850_25851 : H12AffineEnvironment.transform 13 4113 env25850 = env25851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25850 == env25851) = true)

theorem identity25851 : scanCanonicalize (H12AffineFastState.compose env25851 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound25851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25852 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,512,40,529,1,34,512,2048,52,0,528,33,17,2,40,17,2049,512,512,2049,21,33,37,32,528,513]

theorem envBound25852 : H12AffineFastState.Bounded env25852 := by
  intro p hp
  have h : env25852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25851_25852 : H12AffineEnvironment.transform 11 512 env25851 = env25852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env25851 == env25852) = true)

theorem identity25852 : scanCanonicalize (H12AffineFastState.compose env25852 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound25852 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25853 : List Nat := [2,4,8,16,32,16,8,37,512,52,10,512,40,529,1,34,512,10,52,0,528,33,17,2,40,17,11,512,512,11,21,33,37,32,528,513]

theorem envBound25853 : H12AffineFastState.Bounded env25853 := by
  intro p hp
  have h : env25853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25852_25853 : H12AffineEnvironment.transform 10 10 env25852 = env25853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env25852 == env25853) = true)

theorem identity25853 : scanCanonicalize (H12AffineFastState.compose env25853 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound25853 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25854 : List Nat := [2,4,8,16,32,16,8,37,26,52,10,26,40,11,1,34,26,10,52,0,10,33,17,2,40,17,11,26,26,11,21,33,37,32,10,27]

theorem envBound25854 : H12AffineFastState.Bounded env25854 := by
  intro p hp
  have h : env25854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25853_25854 : H12AffineEnvironment.transform 8 26 env25853 = env25854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env25853 == env25854) = true)

def env25855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169264,62540,21762,8193,65,215367,115014,45405,35188,75103,243003,256,95530,103430,513]

theorem envBound25855 : H12AffineFastState.Bounded env25855 := by
  intro p hp
  have h : env25855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25842_25855 : H12AffineEnvironment.transform 6 9 env25842 = env25855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25842 == env25855) = true)

theorem identity25855 : scanCanonicalize (H12AffineFastState.compose env25855 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound25855 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env25856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,33,62540,21762,8193,65,121942,115014,45405,35188,75103,73770,256,95530,103430,513]

theorem envBound25856 : H12AffineFastState.Bounded env25856 := by
  intro p hp
  have h : env25856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25855_25856 : H12AffineEnvironment.transform 16 38161 env25855 = env25856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env25855 == env25856) = true)

theorem identity25856 : scanCanonicalize (H12AffineFastState.compose env25856 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound25856 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env25857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,5440,10281,1024,80,4160,33,29725,21762,8193,65,89095,82199,12556,2341,75103,73770,256,95530,70743,513]

theorem envBound25857 : H12AffineFastState.Bounded env25857 := by
  intro p hp
  have h : env25857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25856_25857 : H12AffineEnvironment.transform 14 81 env25856 = env25857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env25856 == env25857) = true)

theorem identity25857 : scanCanonicalize (H12AffineFastState.compose env25857 (packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound25857 : packedSelected [1,2,3,4,5,6,8,9,12,14,16] rootPS < 2^1333 := by decide +kernel

def env25858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21510,5440,10281,1024,80,4160,33,29725,21762,8193,65,2049,5393,12556,2341,29017,29740,256,8492,16465,513]

theorem envBound25858 : H12AffineFastState.Bounded env25858 := by
  intro p hp
  have h : env25858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25857_25858 : H12AffineEnvironment.transform 15 21510 env25857 = env25858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env25857 == env25858) = true)

theorem identity25858 : scanCanonicalize (H12AffineFastState.compose env25858 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25858 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env25859 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,21510,5392,10281,1024,0,4112,33,29725,21762,8193,17,2049,5393,12556,2341,28937,29740,256,8492,16385,513]

theorem envBound25859 : H12AffineFastState.Bounded env25859 := by
  intro p hp
  have h : env25859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25858_25859 : H12AffineEnvironment.transform 5 16 env25858 = env25859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25858 == env25859) = true)

theorem identity25859 : scanCanonicalize (H12AffineFastState.compose env25859 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound25859 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25860 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,8203,5392,10281,1024,0,4112,33,16,8463,8193,17,2049,5393,12556,2341,1284,33,256,8492,13324,513]

theorem envBound25860 : H12AffineFastState.Bounded env25860 := by
  intro p hp
  have h : env25860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25859_25860 : H12AffineEnvironment.transform 13 13325 env25859 = env25860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env25859 == env25860) = true)

theorem identity25860 : scanCanonicalize (H12AffineFastState.compose env25860 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound25860 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env25861 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1588,8192,8761,1,8203,804,10281,1024,0,1572,33,16,8463,8193,17,2049,805,10040,2341,1284,33,256,8492,8760,513]

theorem envBound25861 : H12AffineFastState.Bounded env25861 := by
  intro p hp
  have h : env25861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25860_25861 : H12AffineEnvironment.transform 11 1588 env25860 = env25861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env25860 == env25861) = true)

theorem identity25861 : scanCanonicalize (H12AffineFastState.compose env25861 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25861 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env25862 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1588,268,821,1,263,804,2341,1024,0,1572,33,16,3,269,17,2049,805,1588,2341,1284,33,256,32,820,513]

theorem envBound25862 : H12AffineFastState.Bounded env25862 := by
  intro p hp
  have h : env25862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25861_25862 : H12AffineEnvironment.transform 12 268 env25861 = env25862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25861 == env25862) = true)

theorem identity25862 : scanCanonicalize (H12AffineFastState.compose env25862 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25862 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25863 : List Nat := [2,4,8,16,32,16,9,20,512,1024,2048,1588,24,545,1,19,560,2097,1024,0,1572,33,16,3,25,17,2049,561,1588,2097,1040,33,20,32,544,513]

theorem envBound25863 : H12AffineFastState.Bounded env25863 := by
  intro p hp
  have h : env25863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25862_25863 : H12AffineEnvironment.transform 7 20 env25862 = env25863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25862 == env25863) = true)

theorem identity25863 : scanCanonicalize (H12AffineFastState.compose env25863 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound25863 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25864 : List Nat := [2,4,8,16,32,16,9,20,512,1024,539,1588,24,545,1,19,560,554,1024,0,1572,33,16,3,25,17,538,561,1588,554,1040,33,20,32,544,513]

theorem envBound25864 : H12AffineFastState.Bounded env25864 := by
  intro p hp
  have h : env25864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25863_25864 : H12AffineEnvironment.transform 10 539 env25863 = env25864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env25863 == env25864) = true)

theorem identity25864 : scanCanonicalize (H12AffineFastState.compose env25864 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25864 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25865 : List Nat := [2,4,8,16,32,16,9,20,17,1024,10,1061,24,48,1,19,33,59,1024,0,1077,33,16,3,25,17,11,32,1061,59,1040,33,20,32,49,16]

theorem envBound25865 : H12AffineFastState.Bounded env25865 := by
  intro p hp
  have h : env25865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25864_25865 : H12AffineEnvironment.transform 8 17 env25864 = env25865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25864 == env25865) = true)

theorem identity25865 : scanCanonicalize (H12AffineFastState.compose env25865 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound25865 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25866 : List Nat := [2,4,8,16,32,16,9,20,17,14,10,43,24,48,1,19,33,59,14,0,59,33,16,3,25,17,11,32,43,59,30,33,20,32,49,16]

theorem envBound25866 : H12AffineFastState.Bounded env25866 := by
  intro p hp
  have h : env25866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25865_25866 : H12AffineEnvironment.transform 9 14 env25865 = env25866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env25865 == env25866) = true)

theorem identity25866 : scanCanonicalize (H12AffineFastState.compose env25866 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound25866 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25867 : List Nat := [2,4,8,16,10,16,9,20,17,14,10,1,24,26,1,19,11,17,14,0,17,11,16,3,25,17,11,10,1,17,30,11,20,10,27,16]

theorem envBound25867 : H12AffineFastState.Bounded env25867 := by
  intro p hp
  have h : env25867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25866_25867 : H12AffineEnvironment.transform 4 10 env25866 = env25867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env25866 == env25867) = true)

theorem identity25867 : scanCanonicalize (H12AffineFastState.compose env25867 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25867 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25868 : List Nat := [2,4,7,16,5,16,6,20,17,1,5,1,23,21,1,19,4,17,1,0,17,4,16,3,22,17,4,5,1,17,17,4,20,5,20,16]

theorem envBound25868 : H12AffineFastState.Bounded env25868 := by
  intro p hp
  have h : env25868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25867_25868 : H12AffineEnvironment.transform 2 7 env25867 = env25868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25867 == env25868) = true)

theorem identity25868 : scanCanonicalize (H12AffineFastState.compose env25868 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound25868 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25869 : List Nat := [2,4,7,6,5,6,6,2,7,1,5,1,1,3,1,5,4,7,1,0,7,4,6,3,0,7,4,5,1,7,7,4,2,5,2,6]

theorem envBound25869 : H12AffineFastState.Bounded env25869 := by
  intro p hp
  have h : env25869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25868_25869 : H12AffineEnvironment.transform 3 6 env25868 = env25869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env25868 == env25869) = true)

theorem identity25869 : scanCanonicalize (H12AffineFastState.compose env25869 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25869 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25870 : List Nat := [2,1,2,3,0,3,3,2,2,1,0,1,1,3,1,0,1,2,1,0,2,1,3,3,0,2,1,0,1,2,2,1,2,0,2,3]

theorem envBound25870 : H12AffineFastState.Bounded env25870 := by
  intro p hp
  have h : env25870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25869_25870 : H12AffineEnvironment.transform 1 1 env25869 = env25870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25869 == env25870) = true)

def env25871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,21763,8328,65,215367,115151,396525,35325,497903,243002,256,509970,469431,442168]

theorem envBound25871 : H12AffineFastState.Bounded env25871 := by
  intro p hp
  have h : env25871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25840_25871 : H12AffineEnvironment.transform 20 4161 env25840 = env25871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env25840 == env25871) = true)

def env25872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169400,156117,21763,8328,65,215367,115151,140485,35325,241863,243002,256,254010,197023,169744]

theorem envBound25872 : H12AffineFastState.Bounded env25872 := by
  intro p hp
  have h : env25872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25871_25872 : H12AffineEnvironment.transform 17 10280 env25871 = env25872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env25871 == env25872) = true)

def env25873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21928,41413,21763,8328,65,100695,115151,58581,35325,94423,95530,256,73770,115087,22272]

theorem envBound25873 : H12AffineFastState.Bounded env25873 := by
  intro p hp
  have h : env25873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25872_25873 : H12AffineEnvironment.transform 16 49168 env25872 = env25873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25872 == env25873) = true)

theorem identity25873 : scanCanonicalize (H12AffineFastState.compose env25873 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound25873 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,10280,1024,29908,4161,21928,21776,21763,8328,65,97666,79130,4096,32040,94423,95530,256,73770,79194,22272]

theorem envBound25874 : H12AffineFastState.Bounded env25874 := by
  intro p hp
  have h : env25874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25873_25874 : H12AffineEnvironment.transform 14 29909 env25873 = env25874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env25873 == env25874) = true)

theorem identity25874 : scanCanonicalize (H12AffineFastState.compose env25874 (packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound25874 : packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env25875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,21676,65536,5308,2129,1024,21677,4161,21928,21776,21763,241,65,89595,71011,4096,23889,86190,87379,256,65619,70947,22272]

theorem envBound25875 : H12AffineFastState.Bounded env25875 := by
  intro p hp
  have h : env25875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25874_25875 : H12AffineEnvironment.transform 12 121 env25874 = env25875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env25874 == env25875) = true)

theorem identity25875 : scanCanonicalize (H12AffineFastState.compose env25875 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25875 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env25876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5377,429,65536,5308,2129,1024,428,4161,169,17,2,241,65,67834,71011,4096,2128,66991,65618,256,65619,70947,513]

theorem envBound25876 : H12AffineFastState.Bounded env25876 := by
  intro p hp
  have h : env25876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25875_25876 : H12AffineEnvironment.transform 13 5377 env25875 = env25876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25875 == env25876) = true)

theorem identity25876 : scanCanonicalize (H12AffineFastState.compose env25876 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound25876 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5377,429,479,5308,2129,1024,428,4161,169,17,2,241,65,2341,5308,4096,2128,1136,397,256,396,5372,513]

theorem envBound25877 : H12AffineFastState.Bounded env25877 := by
  intro p hp
  have h : env25877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25876_25877 : H12AffineEnvironment.transform 15 479 env25876 = env25877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env25876 == env25877) = true)

theorem identity25877 : scanCanonicalize (H12AffineFastState.compose env25877 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25877 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env25878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5377,293,343,5172,2129,1024,292,4161,33,17,2,121,65,2341,5172,4096,2128,1136,261,256,260,5236,513]

theorem envBound25878 : H12AffineFastState.Bounded env25878 := by
  intro p hp
  have h : env25878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25877_25878 : H12AffineEnvironment.transform 6 8 env25877 = env25878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25877 == env25878) = true)

theorem identity25878 : scanCanonicalize (H12AffineFastState.compose env25878 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound25878 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25879 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,121,4113,293,343,4388,2129,272,292,4161,33,17,2,121,65,2341,4388,4096,2128,352,261,256,260,4452,513]

theorem envBound25879 : H12AffineFastState.Bounded env25879 := by
  intro p hp
  have h : env25879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25878_25879 : H12AffineEnvironment.transform 9 272 env25878 = env25879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env25878 == env25879) = true)

theorem identity25879 : scanCanonicalize (H12AffineFastState.compose env25879 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25879 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env25880 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,121,4113,1,115,4096,2129,52,0,4161,33,17,2,121,65,2049,4096,4096,2128,68,33,36,32,4160,513]

theorem envBound25880 : H12AffineFastState.Bounded env25880 := by
  intro p hp
  have h : env25880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25879_25880 : H12AffineEnvironment.transform 7 36 env25879 = env25880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25879 == env25880) = true)

theorem identity25880 : scanCanonicalize (H12AffineFastState.compose env25880 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25880 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25881 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,1,35,4096,2049,52,0,4113,33,17,2,41,17,2049,4096,4096,2048,20,33,36,32,4112,513]

theorem envBound25881 : H12AffineFastState.Bounded env25881 := by
  intro p hp
  have h : env25881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25880_25881 : H12AffineEnvironment.transform 5 16 env25880 = env25881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25880 == env25881) = true)

theorem identity25881 : scanCanonicalize (H12AffineFastState.compose env25881 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound25881 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25882 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2064,41,2049,1,35,2064,2049,52,0,2049,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,513]

theorem envBound25882 : H12AffineFastState.Bounded env25882 := by
  intro p hp
  have h : env25882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25881_25882 : H12AffineEnvironment.transform 11 2064 env25881 = env25882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env25881 == env25882) = true)

theorem identity25882 : scanCanonicalize (H12AffineFastState.compose env25882 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound25882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25883 : List Nat := [2,4,8,16,32,16,8,36,27,52,2048,2064,41,2049,1,35,2064,2049,52,0,2049,33,17,2,41,17,2049,2064,2064,2048,20,33,36,32,2048,26]

theorem envBound25883 : H12AffineFastState.Bounded env25883 := by
  intro p hp
  have h : env25883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25882_25883 : H12AffineEnvironment.transform 8 27 env25882 = env25883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env25882 == env25883) = true)

def env25884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21929,41412,21763,8328,65,100694,115151,58580,35325,94422,95531,256,73771,115086,22273]

theorem envBound25884 : H12AffineFastState.Bounded env25884 := by
  intro p hp
  have h : env25884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25872_25884 : H12AffineEnvironment.transform 16 49169 env25872 = env25884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25872 == env25884) = true)

theorem identity25884 : scanCanonicalize (H12AffineFastState.compose env25884 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound25884 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,13389,10280,1024,29789,4161,21929,21912,21763,8328,65,97546,79251,4232,32161,94422,95531,256,73771,79314,22273]

theorem envBound25885 : H12AffineFastState.Bounded env25885 := by
  intro p hp
  have h : env25885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25884_25885 : H12AffineEnvironment.transform 14 29788 env25884 = env25885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env25884 == env25885) = true)

theorem identity25885 : scanCanonicalize (H12AffineFastState.compose env25885 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound25885 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env25886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1221,16384,20633,65536,4232,3309,1024,20632,4161,21929,21912,21763,1101,65,88527,69974,4232,22884,87059,86510,256,66798,69911,22273]

theorem envBound25886 : H12AffineFastState.Bounded env25886 := by
  intro p hp
  have h : env25886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25885_25886 : H12AffineEnvironment.transform 12 1221 env25885 = env25886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env25885 == env25886) = true)

theorem identity25886 : scanCanonicalize (H12AffineFastState.compose env25886 (packedSelected [1,3,4,5,7,9,19,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound25886 : packedSelected [1,3,4,5,7,9,19,27,28] rootPS < 2^1333 := by decide +kernel

def env25887 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,269,16384,20633,65536,4232,2341,456,20632,4161,20577,20560,20683,389,65,88527,69974,4232,22884,86491,86510,256,65830,69911,21193]

theorem envBound25887 : H12AffineFastState.Bounded env25887 := by
  intro p hp
  have h : env25887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25886_25887 : H12AffineEnvironment.transform 9 456 env25886 = env25887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env25886 == env25887) = true)

theorem identity25887 : scanCanonicalize (H12AffineFastState.compose env25887 (packedSelected [0,1,2,3,6,7,8,10,16,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound25887 : packedSelected [0,1,2,3,6,7,8,10,16,24] rootPS < 2^1333 := by decide +kernel

def env25888 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,269,16384,20633,398,4232,2341,456,20632,4161,20577,20560,20683,389,65,22593,4312,4232,22884,20565,20576,256,168,4249,21193]

theorem envBound25888 : H12AffineFastState.Bounded env25888 := by
  intro p hp
  have h : env25888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25887_25888 : H12AffineEnvironment.transform 15 398 env25887 = env25888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env25887 == env25888) = true)

theorem identity25888 : scanCanonicalize (H12AffineFastState.compose env25888 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25888 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25889 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,269,16384,20633,398,4232,2341,408,20632,4113,20529,20480,20635,389,17,22545,4232,4232,22836,20485,20528,256,168,4249,21145]

theorem envBound25889 : H12AffineFastState.Bounded env25889 := by
  intro p hp
  have h : env25889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25888_25889 : H12AffineEnvironment.transform 5 16 env25888 = env25889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25888 == env25889) = true)

theorem identity25889 : scanCanonicalize (H12AffineFastState.compose env25889 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound25889 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env25890 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,269,4264,49,398,4232,2341,408,48,4113,153,168,51,389,17,2233,4232,4232,2460,173,152,256,168,4249,561]

theorem envBound25890 : H12AffineFastState.Bounded env25890 := by
  intro p hp
  have h : env25890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25889_25890 : H12AffineEnvironment.transform 13 4264 env25889 = env25890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env25889 == env25890) = true)

theorem identity25890 : scanCanonicalize (H12AffineFastState.compose env25890 (packedSelected [0,2,3,4,5,6,7,9,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2460) := by decide +kernel

theorem selectedBound25890 : packedSelected [0,2,3,4,5,6,7,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env25891 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,2460,269,2356,49,398,2324,2341,408,48,2445,153,168,51,389,17,2233,2324,2324,2460,173,152,256,168,2309,561]

theorem envBound25891 : H12AffineFastState.Bounded env25891 := by
  intro p hp
  have h : env25891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25890_25891 : H12AffineEnvironment.transform 11 2460 env25890 = env25891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2460 env25890 == env25891) = true)

theorem identity25891 : scanCanonicalize (H12AffineFastState.compose env25891 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound25891 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25892 : List Nat := [2,4,8,16,32,16,128,157,512,5,2048,2049,144,2217,49,19,2185,2232,5,48,2064,153,168,51,24,17,2233,2185,2185,2049,173,152,157,168,2200,561]

theorem envBound25892 : H12AffineFastState.Bounded env25892 := by
  intro p hp
  have h : env25892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25891_25892 : H12AffineEnvironment.transform 7 157 env25891 = env25892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env25891 == env25892) = true)

theorem identity25892 : scanCanonicalize (H12AffineFastState.compose env25892 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound25892 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25893 : List Nat := [2,4,8,16,32,16,24,5,512,5,2048,2049,8,2097,49,19,2065,2080,5,48,2064,1,48,51,24,17,2081,2065,2065,2049,53,0,5,48,2048,561]

theorem envBound25893 : H12AffineFastState.Bounded env25893 := by
  intro p hp
  have h : env25893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25892_25893 : H12AffineEnvironment.transform 6 24 env25892 = env25893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env25892 == env25893) = true)

theorem identity25893 : scanCanonicalize (H12AffineFastState.compose env25893 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25893 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env25894 : List Nat := [2,4,8,16,1,16,24,5,512,5,2048,2049,8,2064,16,19,2065,2049,5,17,2064,1,17,18,24,17,2048,2065,2065,2049,20,0,5,17,2048,528]

theorem envBound25894 : H12AffineFastState.Bounded env25894 := by
  intro p hp
  have h : env25894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25893_25894 : H12AffineEnvironment.transform 4 1 env25893 = env25894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25893 == env25894) = true)

theorem identity25894 : scanCanonicalize (H12AffineFastState.compose env25894 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound25894 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25895 : List Nat := [2,4,8,16,1,16,24,5,512,5,0,1,8,16,16,19,17,1,5,17,16,1,17,18,24,17,0,17,17,1,20,0,5,17,0,528]

theorem envBound25895 : H12AffineFastState.Bounded env25895 := by
  intro p hp
  have h : env25895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25894_25895 : H12AffineEnvironment.transform 10 0 env25894 = env25895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25894 == env25895) = true)

theorem identity25895 : scanCanonicalize (H12AffineFastState.compose env25895 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25895 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25896 : List Nat := [2,4,8,1,1,1,9,5,512,5,0,1,8,1,1,2,0,1,5,0,1,1,0,3,9,0,0,0,0,1,5,0,5,0,0,513]

theorem envBound25896 : H12AffineFastState.Bounded env25896 := by
  intro p hp
  have h : env25896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25895_25896 : H12AffineEnvironment.transform 3 1 env25895 = env25896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25895 == env25896) = true)

theorem identity25896 : scanCanonicalize (H12AffineFastState.compose env25896 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25897 : List Nat := [2,0,8,1,1,1,9,1,512,1,0,1,8,1,1,2,0,1,1,0,1,1,0,3,9,0,0,0,0,1,1,0,1,0,0,513]

theorem envBound25897 : H12AffineFastState.Bounded env25897 := by
  intro p hp
  have h : env25897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25896_25897 : H12AffineEnvironment.transform 1 0 env25896 = env25897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25896 == env25897) = true)

theorem identity25897 : scanCanonicalize (H12AffineFastState.compose env25897 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound25897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25898 : List Nat := [2,0,8,1,1,1,9,1,9,1,0,1,8,1,1,2,0,1,1,0,1,1,0,3,9,0,0,0,0,1,1,0,1,0,0,8]

theorem envBound25898 : H12AffineFastState.Bounded env25898 := by
  intro p hp
  have h : env25898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25897_25898 : H12AffineEnvironment.transform 8 9 env25897 = env25898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env25897 == env25898) = true)

theorem identity25898 : scanCanonicalize (H12AffineFastState.compose env25898 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound25898 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25899 : List Nat := [2,0,2,1,1,1,3,1,3,1,0,1,2,1,1,2,0,1,1,0,1,1,0,3,3,0,0,0,0,1,1,0,1,0,0,2]

theorem envBound25899 : H12AffineFastState.Bounded env25899 := by
  intro p hp
  have h : env25899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25898_25899 : H12AffineEnvironment.transform 2 2 env25898 = env25899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env25898 == env25899) = true)

def env25900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169400,156116,21763,8328,65,215367,115151,140484,35325,241862,243002,256,254011,197022,169745]

theorem envBound25900 : H12AffineFastState.Bounded env25900 := by
  intro p hp
  have h : env25900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25871_25900 : H12AffineEnvironment.transform 17 10281 env25871 = env25900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env25871 == env25900) = true)

def env25901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21928,41412,21763,8328,65,100695,115151,58580,35325,94422,95530,256,73771,115086,22273]

theorem envBound25901 : H12AffineFastState.Bounded env25901 := by
  intro p hp
  have h : env25901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25900_25901 : H12AffineEnvironment.transform 16 49168 env25900 = env25901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env25900 == env25901) = true)

theorem identity25901 : scanCanonicalize (H12AffineFastState.compose env25901 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound25901 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38297,10281,1024,32769,4161,33,41412,138,8328,65,100695,103494,45405,35325,75103,73891,256,73771,103431,648]

theorem envBound25902 : H12AffineFastState.Bounded env25902 := by
  intro p hp
  have h : env25902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25901_25902 : H12AffineEnvironment.transform 13 5513 env25901 = env25902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env25901 == env25902) = true)

theorem identity25902 : scanCanonicalize (H12AffineFastState.compose env25902 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25902 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10281,1024,32769,4161,33,41293,3,8193,65,100695,103494,45405,35188,75103,73770,256,73771,103431,513]

theorem envBound25903 : H12AffineFastState.Bounded env25903 := by
  intro p hp
  have h : env25903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25902_25903 : H12AffineEnvironment.transform 6 9 env25902 = env25903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25902 == env25903) = true)

theorem identity25903 : scanCanonicalize (H12AffineFastState.compose env25903 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound25903 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env25904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8283,38160,10281,1024,32769,4161,33,41293,3,8193,65,43276,46109,45405,35188,1284,113,256,112,46172,513]

theorem envBound25904 : H12AffineFastState.Bounded env25904 := by
  intro p hp
  have h : env25904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25903_25904 : H12AffineEnvironment.transform 15 8283 env25903 = env25904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env25903 == env25904) = true)

theorem identity25904 : scanCanonicalize (H12AffineFastState.compose env25904 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound25904 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env25905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,8283,5393,10281,1024,0,4161,33,8524,3,8193,65,10509,13340,12636,2421,1284,113,256,112,13405,513]

theorem envBound25905 : H12AffineFastState.Bounded env25905 := by
  intro p hp
  have h : env25905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25904_25905 : H12AffineEnvironment.transform 14 1 env25904 = env25905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env25904 == env25905) = true)

theorem identity25905 : scanCanonicalize (H12AffineFastState.compose env25905 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25905 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,343,5393,2341,1024,0,4161,33,64,3,269,65,2049,5392,4176,2421,1284,113,256,112,5457,513]

theorem envBound25906 : H12AffineFastState.Bounded env25906 := by
  intro p hp
  have h : env25906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25905_25906 : H12AffineEnvironment.transform 12 268 env25905 = env25906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25905 == env25906) = true)

theorem identity25906 : scanCanonicalize (H12AffineFastState.compose env25906 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25906 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25907 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4113,33,16,3,269,17,2049,5392,4096,2341,1284,33,256,32,5377,513]

theorem envBound25907 : H12AffineFastState.Bounded env25907 := by
  intro p hp
  have h : env25907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25906_25907 : H12AffineEnvironment.transform 5 16 env25906 = env25907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25906 == env25907) = true)

theorem identity25907 : scanCanonicalize (H12AffineFastState.compose env25907 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25908 : List Nat := [2,4,8,16,32,16,9,21,512,1024,2048,4096,25,5141,1,18,5124,2096,1024,0,4113,33,16,3,24,17,2049,5125,4096,2096,1041,33,21,32,5140,513]

theorem envBound25908 : H12AffineFastState.Bounded env25908 := by
  intro p hp
  have h : env25908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25907_25908 : H12AffineEnvironment.transform 7 21 env25907 = env25908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25907 == env25908) = true)

theorem identity25908 : scanCanonicalize (H12AffineFastState.compose env25908 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound25908 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25909 : List Nat := [2,4,8,16,32,16,9,21,512,1024,2048,3118,25,2107,1,18,2090,2096,1024,0,3135,33,16,3,24,17,2049,2091,3118,2096,1041,33,21,32,2106,513]

theorem envBound25909 : H12AffineFastState.Bounded env25909 := by
  intro p hp
  have h : env25909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25908_25909 : H12AffineEnvironment.transform 11 3118 env25908 = env25909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env25908 == env25909) = true)

theorem identity25909 : scanCanonicalize (H12AffineFastState.compose env25909 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25909 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25910 : List Nat := [2,4,8,16,32,16,9,21,17,1024,2048,3118,25,2107,1,18,2090,2096,1024,0,3135,33,16,3,24,17,2049,2091,3118,2096,1041,33,21,32,2106,16]

theorem envBound25910 : H12AffineFastState.Bounded env25910 := by
  intro p hp
  have h : env25910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25909_25910 : H12AffineEnvironment.transform 8 17 env25909 = env25910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25909 == env25910) = true)

theorem identity25910 : scanCanonicalize (H12AffineFastState.compose env25910 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound25910 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25911 : List Nat := [2,4,8,16,32,16,9,21,17,1024,1028,42,25,1087,1,18,1070,1076,1024,0,59,33,16,3,24,17,1029,1071,42,1076,1041,33,21,32,1086,16]

theorem envBound25911 : H12AffineFastState.Bounded env25911 := by
  intro p hp
  have h : env25911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25910_25911 : H12AffineEnvironment.transform 10 1028 env25910 = env25911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env25910 == env25911) = true)

theorem identity25911 : scanCanonicalize (H12AffineFastState.compose env25911 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25911 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25912 : List Nat := [2,4,8,16,11,16,9,21,17,1024,1028,1,25,1044,1,18,1029,1055,1024,0,16,10,16,3,24,17,1029,1028,1,1055,1041,10,21,11,1045,16]

theorem envBound25912 : H12AffineFastState.Bounded env25912 := by
  intro p hp
  have h : env25912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25911_25912 : H12AffineEnvironment.transform 4 11 env25911 = env25912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25911 == env25912) = true)

theorem identity25912 : scanCanonicalize (H12AffineFastState.compose env25912 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound25912 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25913 : List Nat := [2,4,8,16,11,16,9,21,17,15,11,1,25,27,1,18,10,16,15,0,16,10,16,3,24,17,10,11,1,16,30,10,21,11,26,16]

theorem envBound25913 : H12AffineFastState.Bounded env25913 := by
  intro p hp
  have h : env25913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25912_25913 : H12AffineEnvironment.transform 9 15 env25912 = env25913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env25912 == env25913) = true)

theorem identity25913 : scanCanonicalize (H12AffineFastState.compose env25913 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25914 : List Nat := [2,4,6,16,5,16,7,21,17,1,5,1,23,21,1,18,4,16,1,0,16,4,16,3,22,17,4,5,1,16,16,4,21,5,20,16]

theorem envBound25914 : H12AffineFastState.Bounded env25914 := by
  intro p hp
  have h : env25914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25913_25914 : H12AffineEnvironment.transform 2 6 env25913 = env25914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25913 == env25914) = true)

theorem identity25914 : scanCanonicalize (H12AffineFastState.compose env25914 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound25914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25915 : List Nat := [2,4,6,7,5,7,7,2,6,1,5,1,0,2,1,5,4,7,1,0,7,4,7,3,1,6,4,5,1,7,7,4,2,5,3,7]

theorem envBound25915 : H12AffineFastState.Bounded env25915 := by
  intro p hp
  have h : env25915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25914_25915 : H12AffineEnvironment.transform 3 7 env25914 = env25915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env25914 == env25915) = true)

theorem identity25915 : scanCanonicalize (H12AffineFastState.compose env25915 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25915 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env25916 : List Nat := [2,1,3,2,0,2,2,2,3,1,0,1,0,2,1,0,1,2,1,0,2,1,2,3,1,3,1,0,1,2,2,1,2,0,3,2]

theorem envBound25916 : H12AffineFastState.Bounded env25916 := by
  intro p hp
  have h : env25916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25915_25916 : H12AffineEnvironment.transform 1 1 env25915 = env25916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25915 == env25916) = true)

def env25917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21929,41413,21763,8328,65,100694,115151,58581,35325,94423,95531,256,73770,115087,22272]

theorem envBound25917 : H12AffineFastState.Bounded env25917 := by
  intro p hp
  have h : env25917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25900_25917 : H12AffineEnvironment.transform 16 49169 env25900 = env25917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env25900 == env25917) = true)

theorem identity25917 : scanCanonicalize (H12AffineFastState.compose env25917 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound25917 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10281,1024,32769,4161,168,41413,2,8328,65,100694,103630,45524,35325,75222,73770,256,73770,103566,513]

theorem envBound25918 : H12AffineFastState.Bounded env25918 := by
  intro p hp
  have h : env25918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25917_25918 : H12AffineEnvironment.transform 13 5377 env25917 = env25918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25917 == env25918) = true)

theorem identity25918 : scanCanonicalize (H12AffineFastState.compose env25918 (packedSelected [0,1,5,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound25918 : packedSelected [0,1,5,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env25919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,262,38160,10281,1024,32769,4161,168,41413,2,8328,65,34896,38344,45524,35325,9424,8492,256,8492,38280,513]

theorem envBound25919 : H12AffineFastState.Bounded env25919 := by
  intro p hp
  have h : env25919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25918_25919 : H12AffineEnvironment.transform 15 262 env25918 = env25919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env25918 == env25919) = true)

theorem identity25919 : scanCanonicalize (H12AffineFastState.compose env25919 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound25919 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env25920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,262,13508,10281,1024,8661,4161,168,17,2,8328,65,10628,13340,4096,10281,9424,8492,256,8492,13404,513]

theorem envBound25920 : H12AffineFastState.Bounded env25920 := by
  intro p hp
  have h : env25920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25919_25920 : H12AffineEnvironment.transform 14 8660 env25919 = env25920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env25919 == env25920) = true)

theorem identity25920 : scanCanonicalize (H12AffineFastState.compose env25920 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound25920 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,262,5528,2421,1024,137,4161,168,17,2,468,65,2264,5440,4096,2421,1420,112,256,112,5376,513]

theorem envBound25921 : H12AffineFastState.Bounded env25921 := by
  intro p hp
  have h : env25921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25920_25921 : H12AffineEnvironment.transform 12 348 env25920 = env25921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env25920 == env25921) = true)

theorem identity25921 : scanCanonicalize (H12AffineFastState.compose env25921 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound25921 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25922 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,81,262,5441,2421,1024,80,4161,113,17,2,269,65,2049,5440,4096,2421,1365,112,256,112,5376,513]

theorem envBound25922 : H12AffineFastState.Bounded env25922 := by
  intro p hp
  have h : env25922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25921_25922 : H12AffineEnvironment.transform 6 89 env25921 = env25922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env25921 == env25922) = true)

theorem identity25922 : scanCanonicalize (H12AffineFastState.compose env25922 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound25922 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env25923 : List Nat := [2,4,8,16,32,64,89,110,512,1024,2048,4096,50,5231,81,104,5167,2075,1024,80,4161,113,17,2,99,65,2049,5166,4096,2075,1083,112,110,112,5230,513]

theorem envBound25923 : H12AffineFastState.Bounded env25923 := by
  intro p hp
  have h : env25923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25922_25923 : H12AffineEnvironment.transform 7 110 env25922 = env25923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env25922 == env25923) = true)

theorem identity25923 : scanCanonicalize (H12AffineFastState.compose env25923 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound25923 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env25924 : List Nat := [2,4,8,16,32,64,89,110,512,1024,1125,4096,50,5231,81,104,5167,1150,1024,80,4161,113,17,2,99,65,1124,5166,4096,1150,1083,112,110,112,5230,513]

theorem envBound25924 : H12AffineFastState.Bounded env25924 := by
  intro p hp
  have h : env25924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25923_25924 : H12AffineEnvironment.transform 10 1125 env25923 = env25924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env25923 == env25924) = true)

theorem identity25924 : scanCanonicalize (H12AffineFastState.compose env25924 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound25924 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env25925 : List Nat := [2,4,8,16,32,64,89,110,512,1024,1125,1044,50,123,81,104,59,1150,1024,80,1109,113,17,2,99,65,1124,58,1044,1150,1083,112,110,112,122,513]

theorem envBound25925 : H12AffineFastState.Bounded env25925 := by
  intro p hp
  have h : env25925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25924_25925 : H12AffineEnvironment.transform 11 1044 env25924 = env25925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env25924 == env25925) = true)

theorem identity25925 : scanCanonicalize (H12AffineFastState.compose env25925 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25925 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env25926 : List Nat := [2,4,3,16,32,64,82,101,512,1024,1125,1044,50,112,81,99,48,1141,1024,80,1109,113,17,2,99,65,1124,49,1044,1141,1072,112,101,112,113,513]

theorem envBound25926 : H12AffineFastState.Bounded env25926 := by
  intro p hp
  have h : env25926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25925_25926 : H12AffineEnvironment.transform 2 3 env25925 = env25926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25925 == env25926) = true)

theorem identity25926 : scanCanonicalize (H12AffineFastState.compose env25926 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25926 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25927 : List Nat := [2,4,3,16,32,0,18,37,512,1024,1061,1044,50,48,17,35,48,1077,1024,16,1045,49,17,2,35,1,1060,49,1044,1077,1072,48,37,48,49,513]

theorem envBound25927 : H12AffineFastState.Bounded env25927 := by
  intro p hp
  have h : env25927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25926_25927 : H12AffineEnvironment.transform 5 0 env25926 = env25927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25926 == env25927) = true)

theorem identity25927 : scanCanonicalize (H12AffineFastState.compose env25927 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound25927 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25928 : List Nat := [2,4,3,16,32,0,18,37,512,0,37,20,50,48,17,35,48,53,0,16,21,49,17,2,35,1,36,49,20,53,48,48,37,48,49,513]

theorem envBound25928 : H12AffineFastState.Bounded env25928 := by
  intro p hp
  have h : env25928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25927_25928 : H12AffineEnvironment.transform 9 0 env25927 = env25928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env25927 == env25928) = true)

theorem identity25928 : scanCanonicalize (H12AffineFastState.compose env25928 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25928 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env25929 : List Nat := [2,4,3,16,16,0,18,21,512,0,21,20,2,0,17,19,0,5,0,16,21,1,17,2,19,1,20,1,20,5,0,0,21,0,1,513]

theorem envBound25929 : H12AffineFastState.Bounded env25929 := by
  intro p hp
  have h : env25929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25928_25929 : H12AffineEnvironment.transform 4 16 env25928 = env25929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25928 == env25929) = true)

theorem identity25929 : scanCanonicalize (H12AffineFastState.compose env25929 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25930 : List Nat := [2,4,3,1,1,0,3,4,512,0,4,5,2,0,0,2,0,5,0,1,4,1,0,2,2,1,5,1,5,5,0,0,4,0,1,513]

theorem envBound25930 : H12AffineFastState.Bounded env25930 := by
  intro p hp
  have h : env25930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25929_25930 : H12AffineEnvironment.transform 3 1 env25929 = env25930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25929 == env25930) = true)

theorem identity25930 : scanCanonicalize (H12AffineFastState.compose env25930 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25930 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25931 : List Nat := [2,4,3,1,1,0,3,4,0,0,4,5,2,0,0,2,0,5,0,1,4,1,0,2,2,1,5,1,5,5,0,0,4,0,1,1]

theorem envBound25931 : H12AffineFastState.Bounded env25931 := by
  intro p hp
  have h : env25931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25930_25931 : H12AffineEnvironment.transform 8 0 env25930 = env25931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25930 == env25931) = true)

theorem identity25931 : scanCanonicalize (H12AffineFastState.compose env25931 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound25931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25932 : List Nat := [0,4,1,1,1,0,1,4,0,0,4,5,0,0,0,0,0,5,0,1,4,1,0,0,0,1,5,1,5,5,0,0,4,0,1,1]

theorem envBound25932 : H12AffineFastState.Bounded env25932 := by
  intro p hp
  have h : env25932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25931_25932 : H12AffineEnvironment.transform 0 0 env25931 = env25932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env25931 == env25932) = true)

theorem identity25932 : scanCanonicalize (H12AffineFastState.compose env25932 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25932 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25933 : List Nat := [0,1,1,1,1,0,1,1,0,0,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,1,0,1,0,0,0,0,1,0,1,1]

theorem envBound25933 : H12AffineFastState.Bounded env25933 := by
  intro p hp
  have h : env25933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25932_25933 : H12AffineEnvironment.transform 1 1 env25932 = env25933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25932 == env25933) = true)

def env25934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound25934 : H12AffineFastState.Bounded env25934 := by
  intro p hp
  have h : env25934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25692_25934 : H12AffineEnvironment.transform 18 1025 env25692 = env25934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25692 == env25934) = true)

theorem identity25934 : scanCanonicalize (H12AffineFastState.compose env25934 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound25934 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env25935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,4194304,8388608,16777216,8328,65,29868032,17066162,8763759,8830977,25265169,21268990,257,25438354,25479478,25207751]

theorem envBound25935 : H12AffineFastState.Bounded env25935 := by
  intro p hp
  have h : env25935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25934_25935 : H12AffineEnvironment.transform 20 388158 env25934 = env25935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env25934 == env25935) = true)

def env25936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,4194304,8388608,351656,8328,65,12754344,79130,8763759,8830977,8706489,4314198,257,8484154,8492190,8781423]

theorem envBound25936 : H12AffineFastState.Bounded env25936 := by
  intro p hp
  have h : env25936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25935_25936 : H12AffineEnvironment.transform 23 351656 env25935 = env25936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351656 env25935 == env25936) = true)

def env25937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,4194304,8388608,95496,8328,65,12754344,79130,8491471,8579233,8450329,4314198,257,8484154,8492190,8509135]

theorem envBound25937 : H12AffineFastState.Bounded env25937 := by
  intro p hp
  have h : env25937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25936_25937 : H12AffineEnvironment.transform 17 10400 env25936 = env25937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env25936 == env25937) = true)

def env25938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,32,8388608,95496,8328,65,8560008,79130,8491471,8579233,8450329,119926,257,8484154,8492190,8509135]

theorem envBound25938 : H12AffineFastState.Bounded env25938 := by
  intro p hp
  have h : env25938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25937_25938 : H12AffineEnvironment.transform 21 32 env25937 = env25938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env25937 == env25938) = true)

theorem identity25938 : scanCanonicalize (H12AffineFastState.compose env25938 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 62661) := by decide +kernel

theorem selectedBound25938 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,32,62661,95496,8328,65,158029,79130,91402,138340,1500,119926,257,98815,90203,74250]

theorem envBound25939 : H12AffineFastState.Bounded env25939 := by
  intro p hp
  have h : env25939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25938_25939 : H12AffineEnvironment.transform 22 62661 env25938 = env25939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 62661 env25938 == env25939) = true)

theorem identity25939 : scanCanonicalize (H12AffineFastState.compose env25939 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25939 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env25940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58517,32,62661,21763,8328,65,158029,5393,17665,138340,1500,62589,257,41460,16464,513]

theorem envBound25940 : H12AffineFastState.Bounded env25940 := by
  intro p hp
  have h : env25940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25939_25940 : H12AffineEnvironment.transform 15 8203 env25939 = env25940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25939 == env25940) = true)

theorem identity25940 : scanCanonicalize (H12AffineFastState.compose env25940 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound25940 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env25941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1025,32769,58517,32,62661,21763,8328,65,10589,5393,17665,23668,1500,62589,257,41460,16464,513]

theorem envBound25941 : H12AffineFastState.Bounded env25941 := by
  intro p hp
  have h : env25941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25940_25941 : H12AffineEnvironment.transform 16 16400 env25940 = env25941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env25940 == env25941) = true)

theorem identity25941 : scanCanonicalize (H12AffineFastState.compose env25941 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound25941 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25942 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,16384,32768,8203,16400,10400,409,32769,57613,32,61789,20635,8328,65,10589,4233,16537,23020,68,61925,257,41460,16464,513]

theorem envBound25942 : H12AffineFastState.Bounded env25942 := by
  intro p hp
  have h : env25942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25941_25942 : H12AffineEnvironment.transform 9 408 env25941 = env25942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env25941 == env25942) = true)

theorem identity25942 : scanCanonicalize (H12AffineFastState.compose env25942 (packedSelected [0,14,17,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25942 : packedSelected [0,14,17,27] rootPS < 2^1333 := by decide +kernel

def env25943 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,16384,32768,8203,16400,10400,409,32769,57613,32,61708,20635,8328,16,10508,4233,16537,22973,21,61876,257,41381,16385,513]

theorem envBound25943 : H12AffineFastState.Bounded env25943 := by
  intro p hp
  have h : env25943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25942_25943 : H12AffineEnvironment.transform 5 17 env25942 = env25943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25942 == env25943) = true)

theorem identity25943 : scanCanonicalize (H12AffineFastState.compose env25943 (packedSelected [1,2,4,6,8,9,10,11,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 18432) := by decide +kernel

theorem selectedBound25943 : packedSelected [1,2,4,6,8,9,10,11,15,18,23] rootPS < 2^1333 := by decide +kernel

def env25944 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,16384,18432,8203,16400,10400,409,18433,10509,32,14604,20635,8328,16,10508,4233,16537,22973,21,14772,257,27045,16385,513]

theorem envBound25944 : H12AffineFastState.Bounded env25944 := by
  intro p hp
  have h : env25944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25943_25944 : H12AffineEnvironment.transform 14 18432 env25943 = env25944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18432 env25943 == env25944) = true)

theorem identity25944 : scanCanonicalize (H12AffineFastState.compose env25944 (packedSelected [0,3,5,7,10,11,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound25944 : packedSelected [0,3,5,7,10,11,14,17] rootPS < 2^1333 := by decide +kernel

def env25945 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,1,2049,8203,17,10400,409,2048,10509,32,14604,4250,8328,16,10508,4233,152,6588,21,14772,257,10660,0,513]

theorem envBound25945 : H12AffineFastState.Bounded env25945 := by
  intro p hp
  have h : env25945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25944_25945 : H12AffineEnvironment.transform 13 1 env25944 = env25945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env25944 == env25945) = true)

theorem identity25945 : scanCanonicalize (H12AffineFastState.compose env25945 (packedSelected [6,7,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound25945 : packedSelected [6,7,9,15] rootPS < 2^1333 := by decide +kernel

def env25946 : List Nat := [2,4,8,16,32,17,128,256,512,408,293,4096,8192,1,292,8203,17,8581,409,293,8232,32,12329,4250,8328,16,8233,4233,152,4249,21,12433,257,8321,0,513]

theorem envBound25946 : H12AffineFastState.Bounded env25946 := by
  intro p hp
  have h : env25946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25945_25946 : H12AffineEnvironment.transform 10 293 env25945 = env25946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env25945 == env25946) = true)

theorem identity25946 : scanCanonicalize (H12AffineFastState.compose env25946 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25946 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env25947 : List Nat := [2,4,8,16,32,17,128,173,512,53,136,4096,8192,1,137,8203,17,8232,52,136,8232,32,12329,4250,8328,16,8233,4233,152,4249,21,12433,172,8321,0,513]

theorem envBound25947 : H12AffineFastState.Bounded env25947 := by
  intro p hp
  have h : env25947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25946_25947 : H12AffineEnvironment.transform 7 173 env25946 = env25947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25946 == env25947) = true)

theorem identity25947 : scanCanonicalize (H12AffineFastState.compose env25947 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25947 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env25948 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,8192,1,0,8203,17,8232,52,1,8232,32,12329,4115,8193,16,8233,4096,17,4112,21,12312,37,8200,0,513]

theorem envBound25948 : H12AffineFastState.Bounded env25948 := by
  intro p hp
  have h : env25948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25947_25948 : H12AffineEnvironment.transform 6 9 env25947 = env25948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25947 == env25948) = true)

theorem identity25948 : scanCanonicalize (H12AffineFastState.compose env25948 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound25948 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25949 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,40,1,0,35,17,0,52,1,0,32,4097,4115,41,16,1,4096,17,4112,21,4144,37,32,0,513]

theorem envBound25949 : H12AffineFastState.Bounded env25949 := by
  intro p hp
  have h : env25949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25948_25949 : H12AffineEnvironment.transform 12 40 env25948 = env25949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env25948 == env25949) = true)

theorem identity25949 : scanCanonicalize (H12AffineFastState.compose env25949 (packedSelected [0,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound25949 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env25950 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,40,1,0,35,17,0,52,1,0,32,16,2,41,16,1,17,17,1,21,33,37,32,0,513]

theorem envBound25950 : H12AffineFastState.Bounded env25950 := by
  intro p hp
  have h : env25950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25949_25950 : H12AffineEnvironment.transform 11 17 env25949 = env25950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env25949 == env25950) = true)

theorem identity25950 : scanCanonicalize (H12AffineFastState.compose env25950 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25951 : List Nat := [2,4,8,0,32,1,9,36,512,37,1,1,40,1,0,35,1,0,36,1,0,32,0,2,41,0,1,1,1,1,5,33,37,32,0,513]

theorem envBound25951 : H12AffineFastState.Bounded env25951 := by
  intro p hp
  have h : env25951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25950_25951 : H12AffineEnvironment.transform 3 0 env25950 = env25951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25950 == env25951) = true)

theorem identity25951 : scanCanonicalize (H12AffineFastState.compose env25951 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound25951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25952 : List Nat := [2,4,8,0,32,1,9,36,10,37,1,1,40,1,0,35,1,0,36,1,0,32,0,2,41,0,1,1,1,1,5,33,37,32,0,11]

theorem envBound25952 : H12AffineFastState.Bounded env25952 := by
  intro p hp
  have h : env25952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25951_25952 : H12AffineEnvironment.transform 8 10 env25951 = env25952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env25951 == env25952) = true)

theorem identity25952 : scanCanonicalize (H12AffineFastState.compose env25952 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound25952 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25953 : List Nat := [2,4,3,0,32,1,2,36,1,37,1,1,35,1,0,35,1,0,36,1,0,32,0,2,34,0,1,1,1,1,5,33,37,32,0,0]

theorem envBound25953 : H12AffineFastState.Bounded env25953 := by
  intro p hp
  have h : env25953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25952_25953 : H12AffineEnvironment.transform 2 3 env25952 = env25953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env25952 == env25953) = true)

def env25954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,33,8388608,95496,8328,65,8560009,79130,8491471,8579233,8450329,119927,257,8484154,8492190,8509135]

theorem envBound25954 : H12AffineFastState.Bounded env25954 := by
  intro p hp
  have h : env25954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25937_25954 : H12AffineEnvironment.transform 21 33 env25937 = env25954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env25937 == env25954) = true)

theorem identity25954 : scanCanonicalize (H12AffineFastState.compose env25954 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound25954 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env25955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1025,29909,77898,33,8388608,95496,8328,65,8546653,79130,8480027,8526965,8390093,73891,257,8484154,8478794,8462875]

theorem envBound25955 : H12AffineFastState.Bounded env25955 := by
  intro p hp
  have h : env25955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25954_25955 : H12AffineEnvironment.transform 14 29908 env25954 = env25955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env25954 == env25955) = true)

def env25956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,77898,33,8388608,73736,8328,65,8535133,79130,8466459,8526965,8390093,73891,257,8462394,8467786,8462875]

theorem envBound25956 : H12AffineFastState.Bounded env25956 := by
  intro p hp
  have h : env25956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25955_25956 : H12AffineEnvironment.transform 13 5376 env25955 = env25956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env25955 == env25956) = true)

theorem identity25956 : scanCanonicalize (H12AffineFastState.compose env25956 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound25956 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,131072,10400,1025,8661,4161,33,8388608,3,8328,65,8535133,5393,8392720,8526965,8390093,168,257,8388657,8394049,8389136]

theorem envBound25957 : H12AffineFastState.Bounded env25957 := by
  intro p hp
  have h : env25957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25956_25957 : H12AffineEnvironment.transform 15 8203 env25956 = env25957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env25956 == env25957) = true)

theorem identity25957 : scanCanonicalize (H12AffineFastState.compose env25957 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(22+1) ^^^ 136449) := by decide +kernel

theorem selectedBound25957 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env25958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,131072,10400,1025,8661,4161,33,136449,3,8328,65,10588,5393,132369,2420,135372,168,257,136496,131136,136977]

theorem envBound25958 : H12AffineFastState.Bounded env25958 := by
  intro p hp
  have h : env25958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25957_25958 : H12AffineEnvironment.transform 22 136449 env25957 = env25958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env25957 == env25958) = true)

theorem identity25958 : scanCanonicalize (H12AffineFastState.compose env25958 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound25958 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env25959 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5373,8233,8203,131072,10400,1025,8232,4161,33,136444,3,8328,65,10401,5356,132332,2185,135372,168,252,136397,131136,136940]

theorem envBound25959 : H12AffineFastState.Bounded env25959 := by
  intro p hp
  have h : env25959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25958_25959 : H12AffineEnvironment.transform 7 253 env25958 = env25959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env25958 == env25959) = true)

theorem identity25959 : scanCanonicalize (H12AffineFastState.compose env25959 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25959 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env25960 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5340,8200,8203,131072,10369,1025,8201,4161,0,136413,3,8328,65,10368,5325,132301,2185,135372,137,221,136397,131136,136909]

theorem envBound25960 : H12AffineFastState.Bounded env25960 := by
  intro p hp
  have h : env25960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25959_25960 : H12AffineEnvironment.transform 4 1 env25959 = env25960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25959 == env25960) = true)

theorem identity25960 : scanCanonicalize (H12AffineFastState.compose env25960 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5324) := by decide +kernel

theorem selectedBound25960 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25961 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8192,5340,8200,8203,5324,10369,1025,8201,4161,0,17,3,8328,65,10368,5325,4097,2185,1024,137,221,1,5260,513]

theorem envBound25961 : H12AffineFastState.Bounded env25961 := by
  intro p hp
  have h : env25961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25960_25961 : H12AffineEnvironment.transform 16 5324 env25960 = env25961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5324 env25960 == env25961) = true)

theorem identity25961 : scanCanonicalize (H12AffineFastState.compose env25961 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound25961 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25962 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,128,5340,136,139,5324,2049,1025,137,4161,0,17,3,8,65,2048,5325,4097,2185,1024,137,221,1,5260,513]

theorem envBound25962 : H12AffineFastState.Bounded env25962 := by
  intro p hp
  have h : env25962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25961_25962 : H12AffineEnvironment.transform 12 128 env25961 = env25962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env25961 == env25962) = true)

theorem identity25962 : scanCanonicalize (H12AffineFastState.compose env25962 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound25962 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25963 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,4096,128,5260,136,139,5276,2049,1025,137,4113,0,17,3,8,17,2048,5277,4097,2185,1024,137,141,1,5260,513]

theorem envBound25963 : H12AffineFastState.Bounded env25963 := by
  intro p hp
  have h : env25963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25962_25963 : H12AffineEnvironment.transform 5 16 env25962 = env25963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25962 == env25963) = true)

theorem identity25963 : scanCanonicalize (H12AffineFastState.compose env25963 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound25963 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25964 : List Nat := [2,4,8,16,1,16,128,140,512,1024,2048,0,128,1164,136,139,1180,2049,1025,137,17,0,17,3,8,17,2048,1181,1,2185,1024,137,141,1,1164,513]

theorem envBound25964 : H12AffineFastState.Bounded env25964 := by
  intro p hp
  have h : env25964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25963_25964 : H12AffineEnvironment.transform 11 0 env25963 = env25964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25963 == env25964) = true)

theorem identity25964 : scanCanonicalize (H12AffineFastState.compose env25964 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25964 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env25965 : List Nat := [2,4,8,16,1,16,128,140,1,1024,2048,0,128,1164,136,139,1180,2049,1025,137,17,0,17,3,8,17,2048,1181,1,2185,1024,137,141,1,1164,0]

theorem envBound25965 : H12AffineFastState.Bounded env25965 := by
  intro p hp
  have h : env25965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25964_25965 : H12AffineEnvironment.transform 8 1 env25964 = env25965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25964 == env25965) = true)

theorem identity25965 : scanCanonicalize (H12AffineFastState.compose env25965 (packedSelected [3,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound25965 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env25966 : List Nat := [2,4,8,16,1,16,128,140,1,20,2048,0,128,152,136,139,136,2049,21,137,17,0,17,3,8,17,2048,137,1,2185,20,137,141,1,152,0]

theorem envBound25966 : H12AffineFastState.Bounded env25966 := by
  intro p hp
  have h : env25966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25965_25966 : H12AffineEnvironment.transform 9 20 env25965 = env25966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env25965 == env25966) = true)

def env25967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,77898,33,8388608,73737,8328,65,8535132,79130,8466458,8526965,8390093,73891,257,8462395,8467787,8462875]

theorem envBound25967 : H12AffineFastState.Bounded env25967 := by
  intro p hp
  have h : env25967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25955_25967 : H12AffineEnvironment.transform 13 5377 env25955 = env25967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env25955 == env25967) = true)

theorem identity25967 : scanCanonicalize (H12AffineFastState.compose env25967 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound25967 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,131072,10400,1025,8660,4297,33,8388608,138,8328,65,8535132,5529,8392857,8526965,8390093,32,257,8388792,8394184,8389272]

theorem envBound25968 : H12AffineFastState.Bounded env25968 := by
  intro p hp
  have h : env25968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25967_25968 : H12AffineEnvironment.transform 15 8323 env25967 = env25968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env25967 == env25968) = true)

theorem identity25968 : scanCanonicalize (H12AffineFastState.compose env25968 (packedSelected [3,4,7,9,19,24,27,31] rootPS)) = affineNative (2^(22+1) ^^^ 136448) := by decide +kernel

theorem selectedBound25968 : packedSelected [3,4,7,9,19,24,27,31] rootPS < 2^1333 := by decide +kernel

def env25969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,131072,10400,1025,8660,4297,33,136448,138,8328,65,10588,5529,132505,2421,135373,32,257,136632,131272,137112]

theorem envBound25969 : H12AffineFastState.Bounded env25969 := by
  intro p hp
  have h : env25969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25968_25969 : H12AffineEnvironment.transform 22 136448 env25968 = env25969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env25968 == env25969) = true)

theorem identity25969 : scanCanonicalize (H12AffineFastState.compose env25969 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound25969 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8323,5529,10400,1025,8660,4297,33,153,138,8328,65,10588,5529,4096,2421,1364,32,257,33,5457,513]

theorem envBound25970 : H12AffineFastState.Bounded env25970 := by
  intro p hp
  have h : env25970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25969_25970 : H12AffineEnvironment.transform 16 5529 env25969 = env25970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env25969 == env25970) = true)

theorem identity25970 : scanCanonicalize (H12AffineFastState.compose env25970 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25970 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env25971 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8323,5529,10400,1025,8581,4248,33,153,138,8328,16,10509,5529,4096,2340,1285,32,257,33,5376,513]

theorem envBound25971 : H12AffineFastState.Bounded env25971 := by
  intro p hp
  have h : env25971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25970_25971 : H12AffineEnvironment.transform 5 17 env25970 = env25971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25970 == env25971) = true)

theorem identity25971 : scanCanonicalize (H12AffineFastState.compose env25971 (packedSelected [0,1,3,4,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound25971 : packedSelected [0,1,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env25972 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4380,5377,4248,4511,5529,6588,1025,4249,4248,33,153,138,4500,16,6161,5529,4096,2340,1285,32,257,33,5376,513]

theorem envBound25972 : H12AffineFastState.Bounded env25972 := by
  intro p hp
  have h : env25972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25971_25972 : H12AffineEnvironment.transform 12 4380 env25971 = env25972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env25971 == env25972) = true)

theorem identity25972 : scanCanonicalize (H12AffineFastState.compose env25972 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25972 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25973 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,4153,5156,4248,4282,5308,6297,1025,4249,4248,33,153,138,4273,16,6161,5308,4096,2049,1056,32,36,33,5157,513]

theorem envBound25973 : H12AffineFastState.Bounded env25973 := by
  intro p hp
  have h : env25973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25972_25973 : H12AffineEnvironment.transform 7 37 env25972 = env25973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25972 == env25973) = true)

theorem identity25973 : scanCanonicalize (H12AffineFastState.compose env25973 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound25973 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25974 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,3108,3101,2048,3260,3230,2200,1213,1025,3261,3260,33,153,138,3221,16,1077,2200,3108,2049,1056,32,36,33,2049,513]

theorem envBound25974 : H12AffineFastState.Bounded env25974 := by
  intro p hp
  have h : env25974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25973_25974 : H12AffineEnvironment.transform 11 3108 env25973 = env25974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env25973 == env25974) = true)

theorem identity25974 : scanCanonicalize (H12AffineFastState.compose env25974 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound25974 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env25975 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,2200,2209,2048,2048,2082,2200,1,189,2049,2048,33,153,138,2089,16,137,2200,2200,2049,156,32,36,33,2049,513]

theorem envBound25975 : H12AffineFastState.Bounded env25975 := by
  intro p hp
  have h : env25975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25974_25975 : H12AffineEnvironment.transform 9 188 env25974 = env25975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env25974 == env25975) = true)

theorem identity25975 : scanCanonicalize (H12AffineFastState.compose env25975 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound25975 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25976 : List Nat := [2,4,8,16,32,17,128,37,512,188,1,153,160,1,1,35,153,1,189,0,1,33,153,138,40,16,137,153,153,0,156,32,36,33,0,513]

theorem envBound25976 : H12AffineFastState.Bounded env25976 := by
  intro p hp
  have h : env25976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25975_25976 : H12AffineEnvironment.transform 10 1 env25975 = env25976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25975 == env25976) = true)

theorem identity25976 : scanCanonicalize (H12AffineFastState.compose env25976 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25976 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25977 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,1,1,35,17,1,53,0,1,33,17,2,40,16,1,17,17,0,20,32,36,33,0,513]

theorem envBound25977 : H12AffineFastState.Bounded env25977 := by
  intro p hp
  have h : env25977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25976_25977 : H12AffineEnvironment.transform 6 8 env25976 = env25977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25976 == env25977) = true)

theorem identity25977 : scanCanonicalize (H12AffineFastState.compose env25977 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25977 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25978 : List Nat := [2,4,8,16,16,17,8,21,512,4,1,17,24,1,1,19,17,1,5,0,1,17,17,2,24,16,1,17,17,0,20,16,20,17,0,513]

theorem envBound25978 : H12AffineFastState.Bounded env25978 := by
  intro p hp
  have h : env25978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25977_25978 : H12AffineEnvironment.transform 4 16 env25977 = env25978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25977 == env25978) = true)

theorem identity25978 : scanCanonicalize (H12AffineFastState.compose env25978 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound25978 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25979 : List Nat := [2,4,8,1,1,0,8,4,512,4,1,0,9,1,1,2,0,1,5,0,1,0,0,2,9,1,1,0,0,0,5,1,5,0,0,513]

theorem envBound25979 : H12AffineFastState.Bounded env25979 := by
  intro p hp
  have h : env25979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25978_25979 : H12AffineEnvironment.transform 3 1 env25978 = env25979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25978 == env25979) = true)

theorem identity25979 : scanCanonicalize (H12AffineFastState.compose env25979 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25980 : List Nat := [2,4,8,1,1,0,8,4,0,4,1,0,9,1,1,2,0,1,5,0,1,0,0,2,9,1,1,0,0,0,5,1,5,0,0,1]

theorem envBound25980 : H12AffineFastState.Bounded env25980 := by
  intro p hp
  have h : env25980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25979_25980 : H12AffineEnvironment.transform 8 0 env25979 = env25980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25979 == env25980) = true)

def env25981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,4194304,8388608,95497,8328,65,12754344,79130,8491470,8579232,8450328,4314198,257,8484154,8492190,8509134]

theorem envBound25981 : H12AffineFastState.Bounded env25981 := by
  intro p hp
  have h : env25981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25936_25981 : H12AffineEnvironment.transform 17 10401 env25936 = env25981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env25936 == env25981) = true)

def env25982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,32,8388608,95497,8328,65,8560008,79130,8491470,8579232,8450328,119926,257,8484154,8492190,8509134]

theorem envBound25982 : H12AffineFastState.Bounded env25982 := by
  intro p hp
  have h : env25982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25981_25982 : H12AffineEnvironment.transform 21 32 env25981 = env25982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env25981 == env25982) = true)

def env25983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,32,8388608,95497,8192,65,8559872,79130,8491334,8579112,8450328,119926,257,8484154,8492054,8508998]

theorem envBound25983 : H12AffineFastState.Bounded env25983 := by
  intro p hp
  have h : env25983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25982_25983 : H12AffineEnvironment.transform 6 8 env25982 = env25983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25982 == env25983) = true)

theorem identity25983 : scanCanonicalize (H12AffineFastState.compose env25983 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 119879) := by decide +kernel

theorem selectedBound25983 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,32,119879,95497,8192,65,215367,79130,17665,212079,75103,119926,257,41341,16465,513]

theorem envBound25984 : H12AffineFastState.Bounded env25984 := by
  intro p hp
  have h : env25984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25983_25984 : H12AffineEnvironment.transform 22 119879 env25983 = env25984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 119879 env25983 == env25984) = true)

theorem identity25984 : scanCanonicalize (H12AffineFastState.compose env25984 (packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound25984 : packedSelected [1,2,3,4,6,9,11,16,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env25985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57629,10281,1025,32769,115735,32,119879,95497,8192,65,108634,79130,17665,122226,75103,119926,257,41341,16465,513]

theorem envBound25985 : H12AffineFastState.Bounded env25985 := by
  intro p hp
  have h : env25985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25984_25985 : H12AffineEnvironment.transform 16 57629 env25984 = env25985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env25984 == env25985) = true)

theorem identity25985 : scanCanonicalize (H12AffineFastState.compose env25985 (packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound25985 : packedSelected [1,2,4,6,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env25986 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41051,57629,10281,1025,32769,25676,32,29724,54610,8192,65,2049,38209,17665,32041,34052,29741,257,41341,16465,513]

theorem envBound25986 : H12AffineFastState.Bounded env25986 := by
  intro p hp
  have h : env25986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25985_25986 : H12AffineEnvironment.transform 15 41051 env25985 = env25986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env25985 == env25986) = true)

theorem identity25986 : scanCanonicalize (H12AffineFastState.compose env25986 (packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound25986 : packedSelected [0,1,2,6,7,8,10,14,15,18] rootPS < 2^1333 := by decide +kernel

def env25987 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,343,16401,10281,1025,8461,25676,32,29724,29790,8192,65,2049,13389,17665,32041,9224,29741,257,113,16465,513]

theorem envBound25987 : H12AffineFastState.Bounded env25987 := by
  intro p hp
  have h : env25987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25986_25987 : H12AffineEnvironment.transform 14 8460 env25986 = env25987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env25986 == env25987) = true)

theorem identity25987 : scanCanonicalize (H12AffineFastState.compose env25987 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound25987 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env25988 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,81,343,16401,2420,1025,80,17681,32,21825,21763,349,65,2049,5392,17665,23668,1365,21872,257,113,16465,513]

theorem envBound25988 : H12AffineFastState.Bounded env25988 := by
  intro p hp
  have h : env25988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25987_25988 : H12AffineEnvironment.transform 12 349 env25987 = env25988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env25987 == env25988) = true)

theorem identity25988 : scanCanonicalize (H12AffineFastState.compose env25988 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound25988 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env25989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,81,343,5441,2420,1025,80,4161,32,17,83,349,65,2049,5392,4177,2340,1365,32,257,113,5377,513]

theorem envBound25989 : H12AffineFastState.Bounded env25989 := by
  intro p hp
  have h : env25989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25988_25989 : H12AffineEnvironment.transform 13 5456 env25988 = env25989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env25988 == env25989) = true)

theorem identity25989 : scanCanonicalize (H12AffineFastState.compose env25989 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3685) := by decide +kernel

theorem selectedBound25989 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env25990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3685,349,2869,81,343,2852,2420,1025,80,3620,32,17,83,349,65,2049,2933,3636,2340,1365,32,257,113,2916,513]

theorem envBound25990 : H12AffineFastState.Bounded env25990 := by
  intro p hp
  have h : env25990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25989_25990 : H12AffineEnvironment.transform 11 3685 env25989 = env25990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3685 env25989 == env25990) = true)

theorem identity25990 : scanCanonicalize (H12AffineFastState.compose env25990 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound25990 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env25991 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,3345,349,2113,81,343,2128,2420,1025,80,3408,32,17,83,349,65,2049,2049,3392,2340,1365,32,257,113,2064,373]

theorem envBound25991 : H12AffineFastState.Bounded env25991 := by
  intro p hp
  have h : env25991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25990_25991 : H12AffineEnvironment.transform 8 372 env25990 = env25991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env25990 == env25991) = true)

theorem identity25991 : scanCanonicalize (H12AffineFastState.compose env25991 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound25991 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env25992 : List Nat := [2,4,8,16,32,64,8,101,17,1024,2048,3188,56,2113,81,50,2128,2065,1025,80,3125,32,17,83,56,65,2049,2049,3109,2113,1072,32,100,113,2064,16]

theorem envBound25992 : H12AffineFastState.Bounded env25992 := by
  intro p hp
  have h : env25992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25991_25992 : H12AffineEnvironment.transform 7 101 env25991 = env25992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env25991 == env25992) = true)

theorem identity25992 : scanCanonicalize (H12AffineFastState.compose env25992 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound25992 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env25993 : List Nat := [2,4,8,16,32,64,8,101,17,117,2048,2049,56,2113,81,50,2128,2065,116,80,2112,32,17,83,56,65,2049,2049,2128,2113,69,32,100,113,2064,16]

theorem envBound25993 : H12AffineFastState.Bounded env25993 := by
  intro p hp
  have h : env25993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25992_25993 : H12AffineEnvironment.transform 9 117 env25992 = env25993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env25992 == env25993) = true)

theorem identity25993 : scanCanonicalize (H12AffineFastState.compose env25993 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound25993 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25994 : List Nat := [2,4,8,16,32,64,8,101,17,117,16,17,56,81,81,50,64,1,116,80,80,32,17,83,56,65,17,17,64,81,69,32,100,113,0,16]

theorem envBound25994 : H12AffineFastState.Bounded env25994 := by
  intro p hp
  have h : env25994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25993_25994 : H12AffineEnvironment.transform 10 16 env25993 = env25994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env25993 == env25994) = true)

def env25995 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,8388608,95497,8193,65,8559873,79130,8491335,8579113,8450328,119926,257,8484154,8492055,8508999]

theorem envBound25995 : H12AffineFastState.Bounded env25995 := by
  intro p hp
  have h : env25995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25982_25995 : H12AffineEnvironment.transform 6 9 env25982 = env25995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25982 == env25995) = true)

theorem identity25995 : scanCanonicalize (H12AffineFastState.compose env25995 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 95515) := by decide +kernel

theorem selectedBound25995 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env25996 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,32,95515,95497,8193,65,256026,79130,58460,236850,99331,119926,257,33,57612,41820]

theorem envBound25996 : H12AffineFastState.Bounded env25996 := by
  intro p hp
  have h : env25996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25995_25996 : H12AffineEnvironment.transform 22 95515 env25995 = env25996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 95515 env25995 == env25996) = true)

theorem identity25996 : scanCanonicalize (H12AffineFastState.compose env25996 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound25996 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env25997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,46157,10280,1025,32769,115734,32,95515,95497,8193,65,89175,79130,58460,76159,99331,119926,257,33,57612,41820]

theorem envBound25997 : H12AffineFastState.Bounded env25997 := by
  intro p hp
  have h : env25997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25996_25997 : H12AffineEnvironment.transform 16 46157 env25996 = env25997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env25996 == env25997) = true)

theorem identity25997 : scanCanonicalize (H12AffineFastState.compose env25997 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound25997 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env25998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10280,1025,32769,4160,32,41293,41311,8193,65,34817,57676,58460,64809,20565,32,257,33,57612,41820]

theorem envBound25998 : H12AffineFastState.Bounded env25998 := by
  intro p hp
  have h : env25998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25997_25998 : H12AffineEnvironment.transform 15 54358 env25997 = env25998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env25997 == env25998) = true)

theorem identity25998 : scanCanonicalize (H12AffineFastState.compose env25998 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound25998 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,5392,10280,1025,8540,4160,32,16,2,8193,65,10588,16401,17665,23668,20565,32,257,33,16465,513]

theorem envBound25999 : H12AffineFastState.Bounded env25999 := by
  intro p hp
  have h : env25999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25998_25999 : H12AffineEnvironment.transform 14 8541 env25998 = env25999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env25998 == env25999) = true)

theorem identity25999 : scanCanonicalize (H12AffineFastState.compose env25999 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound25999 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,9498,5392,10280,1025,8540,4160,32,16,2,8193,65,10588,4096,5392,3173,68,32,257,33,4160,513]

theorem envBound26000 : H12AffineFastState.Bounded env26000 := by
  intro p hp
  have h : env26000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25999_26000 : H12AffineEnvironment.transform 13 4113 env25999 = env26000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env25999 == env26000) = true)

theorem identity26000 : scanCanonicalize (H12AffineFastState.compose env26000 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound26000 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2405,8192,2420,8541,9498,3189,10280,1025,8540,2341,32,16,2,8193,65,10588,2405,3189,3173,68,32,257,33,2341,513]

theorem envBound26001 : H12AffineFastState.Bounded env26001 := by
  intro p hp
  have h : env26001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26000_26001 : H12AffineEnvironment.transform 11 2405 env26000 = env26001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env26000 == env26001) = true)

theorem identity26001 : scanCanonicalize (H12AffineFastState.compose env26001 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26001 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env26002 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,2113,8192,2128,8313,9278,3189,10280,1025,8312,2049,32,16,2,8193,65,10360,2113,3189,3173,68,32,37,33,2049,513]

theorem envBound26002 : H12AffineFastState.Bounded env26002 := by
  intro p hp
  have h : env26002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26001_26002 : H12AffineEnvironment.transform 7 36 env26001 = env26002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26001 == env26002) = true)

theorem identity26002 : scanCanonicalize (H12AffineFastState.compose env26002 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26002 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26003 : List Nat := [2,4,8,16,32,64,9,36,512,53,2048,2113,8192,2128,8313,8203,2112,10280,52,8312,2049,32,16,2,8193,65,10360,2113,2112,2128,68,32,37,33,2049,513]

theorem envBound26003 : H12AffineFastState.Bounded env26003 := by
  intro p hp
  have h : env26003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26002_26003 : H12AffineEnvironment.transform 9 53 env26002 = env26003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26002 == env26003) = true)

theorem identity26003 : scanCanonicalize (H12AffineFastState.compose env26003 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound26003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26004 : List Nat := [2,4,8,16,32,64,9,36,512,53,49,112,8192,97,8313,8203,113,8217,52,8312,48,32,16,2,8193,65,8265,112,113,97,68,32,37,33,48,513]

theorem envBound26004 : H12AffineFastState.Bounded env26004 := by
  intro p hp
  have h : env26004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26003_26004 : H12AffineEnvironment.transform 10 49 env26003 = env26004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env26003 == env26004) = true)

theorem identity26004 : scanCanonicalize (H12AffineFastState.compose env26004 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 600) := by decide +kernel

theorem selectedBound26004 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26005 : List Nat := [2,4,8,16,32,64,9,36,512,53,49,112,600,97,545,595,113,577,52,544,48,32,16,2,601,65,529,112,113,97,68,32,37,33,48,513]

theorem envBound26005 : H12AffineFastState.Bounded env26005 := by
  intro p hp
  have h : env26005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26004_26005 : H12AffineEnvironment.transform 12 600 env26004 = env26005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 600 env26004 == env26005) = true)

theorem identity26005 : scanCanonicalize (H12AffineFastState.compose env26005 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound26005 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26006 : List Nat := [2,4,8,16,32,64,9,36,32,53,49,112,120,97,1,115,113,97,52,0,48,32,16,2,121,65,49,112,113,97,68,32,37,33,48,33]

theorem envBound26006 : H12AffineFastState.Bounded env26006 := by
  intro p hp
  have h : env26006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26005_26006 : H12AffineEnvironment.transform 8 32 env26005 = env26006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env26005 == env26006) = true)

theorem identity26006 : scanCanonicalize (H12AffineFastState.compose env26006 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound26006 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26007 : List Nat := [2,4,8,16,32,1,9,36,32,53,49,49,57,32,1,50,48,32,52,0,48,32,16,2,56,0,49,49,48,32,5,32,37,33,48,33]

theorem envBound26007 : H12AffineFastState.Bounded env26007 := by
  intro p hp
  have h : env26007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26006_26007 : H12AffineEnvironment.transform 5 1 env26006 = env26007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env26006 == env26007) = true)

theorem identity26007 : scanCanonicalize (H12AffineFastState.compose env26007 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound26007 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26008 : List Nat := [2,4,8,16,0,1,9,4,0,21,17,17,25,0,1,18,16,0,20,0,16,0,16,2,24,0,17,17,16,0,5,0,5,1,16,1]

theorem envBound26008 : H12AffineFastState.Bounded env26008 := by
  intro p hp
  have h : env26008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26007_26008 : H12AffineEnvironment.transform 4 0 env26007 = env26008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env26007 == env26008) = true)

def env26009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,33,8388608,95497,8328,65,8560009,79130,8491470,8579232,8450328,119927,257,8484154,8492190,8509134]

theorem envBound26009 : H12AffineFastState.Bounded env26009 := by
  intro p hp
  have h : env26009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25981_26009 : H12AffineEnvironment.transform 21 33 env25981 = env26009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env25981 == env26009) = true)

theorem identity26009 : scanCanonicalize (H12AffineFastState.compose env26009 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound26009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,115871,33,17,95497,8328,65,171416,79130,102879,190641,61705,119927,257,95531,103567,120543]

theorem envBound26010 : H12AffineFastState.Bounded env26010 := by
  intro p hp
  have h : env26010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26009_26010 : H12AffineEnvironment.transform 22 17 env26009 = env26010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env26009 == env26010) = true)

theorem identity26010 : scanCanonicalize (H12AffineFastState.compose env26010 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound26010 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env26011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10401,1025,32769,4161,33,17,41431,8328,65,171416,57796,17665,190641,61705,169,257,41461,16465,513]

theorem envBound26011 : H12AffineFastState.Bounded env26011 := by
  intro p hp
  have h : env26011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26010_26011 : H12AffineEnvironment.transform 15 54494 env26010 = env26011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env26010 == env26011) = true)

def env26012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4161,33,17,41311,8192,65,171280,57676,17665,190521,61705,33,257,41341,16465,513]

theorem envBound26012 : H12AffineFastState.Bounded env26012 := by
  intro p hp
  have h : env26012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26011_26012 : H12AffineEnvironment.transform 6 8 env26011 = env26012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26011 == env26012) = true)

theorem identity26012 : scanCanonicalize (H12AffineFastState.compose env26012 (packedSelected [0,4,7,9,12,15,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound26012 : packedSelected [0,4,7,9,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env26013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5392,10281,1025,32769,4161,33,17,41311,8192,65,34816,57676,17665,64809,61705,33,257,41341,16465,513]

theorem envBound26013 : H12AffineFastState.Bounded env26013 := by
  intro p hp
  have h : env26013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26012_26013 : H12AffineEnvironment.transform 16 5392 env26012 = env26013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env26012 == env26013) = true)

theorem identity26013 : scanCanonicalize (H12AffineFastState.compose env26013 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound26013 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env26014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,5392,10281,1025,32769,4161,33,17,41311,8192,65,34816,38161,12636,35188,34132,33,257,41341,13324,513]

theorem envBound26014 : H12AffineFastState.Bounded env26014 := by
  intro p hp
  have h : env26014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26013_26014 : H12AffineEnvironment.transform 13 13405 env26013 = env26014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env26013 == env26014) = true)

theorem identity26014 : scanCanonicalize (H12AffineFastState.compose env26014 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26014 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env26015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,342,5392,10281,1025,8540,4161,33,17,2,8192,65,10589,13388,12636,10281,9225,33,257,32,13324,513]

theorem envBound26015 : H12AffineFastState.Bounded env26015 := by
  intro p hp
  have h : env26015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26014_26015 : H12AffineEnvironment.transform 14 8541 env26014 = env26015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26014 == env26015) = true)

theorem identity26015 : scanCanonicalize (H12AffineFastState.compose env26015 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26015 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env26016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,80,342,5392,2340,1025,81,4161,33,17,2,269,65,2128,5441,4177,2340,1284,33,257,32,5377,513]

theorem envBound26016 : H12AffineFastState.Bounded env26016 := by
  intro p hp
  have h : env26016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26015_26016 : H12AffineEnvironment.transform 12 269 env26015 = env26016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26015 == env26016) = true)

theorem identity26016 : scanCanonicalize (H12AffineFastState.compose env26016 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26016 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26017 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,33,17,2,269,17,2048,5393,4097,2340,1284,33,257,32,5377,513]

theorem envBound26017 : H12AffineFastState.Bounded env26017 := by
  intro p hp
  have h : env26017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26016_26017 : H12AffineEnvironment.transform 5 16 env26016 = env26017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26016 == env26017) = true)

theorem identity26017 : scanCanonicalize (H12AffineFastState.compose env26017 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26018 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5172,2048,1025,1,4113,33,17,2,41,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound26018 : H12AffineFastState.Bounded env26018 := by
  intro p hp
  have h : env26018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26017_26018 : H12AffineEnvironment.transform 7 36 env26017 = env26018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26017 == env26018) = true)

theorem identity26018 : scanCanonicalize (H12AffineFastState.compose env26018 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound26018 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26019 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,17,41,1077,0,34,1061,2048,1025,1,0,33,17,2,41,17,2048,1060,16,2048,1056,33,37,32,1076,513]

theorem envBound26019 : H12AffineFastState.Bounded env26019 := by
  intro p hp
  have h : env26019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26018_26019 : H12AffineEnvironment.transform 11 17 env26018 = env26019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env26018 == env26019) = true)

theorem identity26019 : scanCanonicalize (H12AffineFastState.compose env26019 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound26019 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26020 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,17,41,1077,0,34,1061,0,1025,1,0,33,17,2,41,17,0,1060,16,0,1056,33,37,32,1076,513]

theorem envBound26020 : H12AffineFastState.Bounded env26020 := by
  intro p hp
  have h : env26020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26019_26020 : H12AffineEnvironment.transform 10 0 env26019 = env26020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26019 == env26020) = true)

theorem identity26020 : scanCanonicalize (H12AffineFastState.compose env26020 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26020 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26021 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,41,0,0,34,16,0,52,1,0,33,17,2,41,17,0,17,16,0,21,33,37,32,1,513]

theorem envBound26021 : H12AffineFastState.Bounded env26021 := by
  intro p hp
  have h : env26021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26020_26021 : H12AffineEnvironment.transform 9 53 env26020 = env26021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26020 == env26021) = true)

theorem identity26021 : scanCanonicalize (H12AffineFastState.compose env26021 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26022 : List Nat := [2,4,3,16,32,16,3,36,512,53,0,17,34,0,0,34,16,0,52,1,0,33,17,2,34,17,0,17,16,0,21,33,37,32,1,513]

theorem envBound26022 : H12AffineFastState.Bounded env26022 := by
  intro p hp
  have h : env26022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26021_26022 : H12AffineEnvironment.transform 2 3 env26021 = env26022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env26021 == env26022) = true)

def env26023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1025,32769,4161,33,17,41310,8193,65,171281,57677,17665,190520,61705,32,257,41340,16465,513]

theorem envBound26023 : H12AffineFastState.Bounded env26023 := by
  intro p hp
  have h : env26023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26011_26023 : H12AffineEnvironment.transform 6 9 env26011 = env26023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26011 == env26023) = true)

theorem identity26023 : scanCanonicalize (H12AffineFastState.compose env26023 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound26023 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10280,1025,8540,4161,33,17,3,8193,65,146508,16400,17665,149861,20564,32,257,33,16465,513]

theorem envBound26024 : H12AffineFastState.Bounded env26024 := by
  intro p hp
  have h : env26024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26023_26024 : H12AffineEnvironment.transform 14 8541 env26023 = env26024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env26023 == env26024) = true)

theorem identity26024 : scanCanonicalize (H12AffineFastState.compose env26024 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26024 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env26025 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,8192,16384,8541,27931,131072,10280,1025,8540,2128,33,17,3,8193,65,140381,16400,17665,149861,18501,32,257,33,16465,513]

theorem envBound26025 : H12AffineFastState.Bounded env26025 := by
  intro p hp
  have h : env26025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26024_26025 : H12AffineEnvironment.transform 11 2065 env26024 = env26025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env26024 == env26025) = true)

theorem identity26025 : scanCanonicalize (H12AffineFastState.compose env26025 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound26025 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env26026 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,1,19527,131072,2420,1025,0,2128,33,17,3,349,65,132353,16400,17665,149861,18501,32,257,33,16465,513]

theorem envBound26026 : H12AffineFastState.Bounded env26026 := by
  intro p hp
  have h : env26026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26025_26026 : H12AffineEnvironment.transform 12 348 env26025 = env26026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env26025 == env26026) = true)

theorem identity26026 : scanCanonicalize (H12AffineFastState.compose env26026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 2065) := by decide +kernel

theorem selectedBound26026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26027 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,348,16384,1,19527,2065,2420,1025,0,2128,33,17,3,349,65,3344,16400,17665,16756,18501,32,257,33,16465,513]

theorem envBound26027 : H12AffineFastState.Bounded env26027 := by
  intro p hp
  have h : env26027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26026_26027 : H12AffineEnvironment.transform 16 2065 env26026 = env26027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2065 env26026 == env26027) = true)

theorem identity26027 : scanCanonicalize (H12AffineFastState.compose env26027 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound26027 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env26028 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2065,348,16384,1,18775,2065,2420,273,0,2128,33,17,3,349,65,2048,16400,16401,16756,18501,32,257,33,16465,513]

theorem envBound26028 : H12AffineFastState.Bounded env26028 := by
  intro p hp
  have h : env26028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26027_26028 : H12AffineEnvironment.transform 9 272 env26027 = env26028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env26027 == env26028) = true)

theorem identity26028 : scanCanonicalize (H12AffineFastState.compose env26028 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 2123) := by decide +kernel

theorem selectedBound26028 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env26029 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2065,348,2123,1,284,2065,2420,273,0,2128,33,17,3,349,65,2048,2139,2138,2367,14,32,257,33,2074,513]

theorem envBound26029 : H12AffineFastState.Bounded env26029 := by
  intro p hp
  have h : env26029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26028_26029 : H12AffineEnvironment.transform 13 2123 env26028 = env26029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2123 env26028 == env26029) = true)

theorem identity26029 : scanCanonicalize (H12AffineFastState.compose env26029 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26029 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env26030 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2065,269,2074,1,284,2065,2341,273,0,2049,33,17,3,268,16,2048,2058,2059,2367,14,32,257,33,2074,513]

theorem envBound26030 : H12AffineFastState.Bounded env26030 := by
  intro p hp
  have h : env26030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26029_26030 : H12AffineEnvironment.transform 5 17 env26029 = env26030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26029 == env26030) = true)

theorem identity26030 : scanCanonicalize (H12AffineFastState.compose env26030 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26030 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26031 : List Nat := [2,4,8,16,32,17,9,20,512,4,2048,2065,25,2074,1,8,2065,2097,5,0,2049,33,17,3,24,16,2048,2058,2059,2091,14,32,21,33,2074,513]

theorem envBound26031 : H12AffineFastState.Bounded env26031 := by
  intro p hp
  have h : env26031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26030_26031 : H12AffineEnvironment.transform 7 20 env26030 = env26031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26030 == env26031) = true)

theorem identity26031 : scanCanonicalize (H12AffineFastState.compose env26031 (packedSelected [2,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26031 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26032 : List Nat := [2,4,8,10,32,11,9,14,512,4,2048,2059,3,2048,1,8,2059,2091,5,0,2049,33,11,3,2,10,2048,2058,2059,2091,14,32,15,33,2048,513]

theorem envBound26032 : H12AffineFastState.Bounded env26032 := by
  intro p hp
  have h : env26032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26031_26032 : H12AffineEnvironment.transform 3 10 env26031 = env26032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26031 == env26032) = true)

theorem identity26032 : scanCanonicalize (H12AffineFastState.compose env26032 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound26032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26033 : List Nat := [2,4,8,10,32,11,9,14,512,4,10,1,3,10,1,8,1,33,5,0,11,33,11,3,2,10,10,0,1,33,14,32,15,33,10,513]

theorem envBound26033 : H12AffineFastState.Bounded env26033 := by
  intro p hp
  have h : env26033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26032_26033 : H12AffineEnvironment.transform 10 10 env26032 = env26033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env26032 == env26033) = true)

theorem identity26033 : scanCanonicalize (H12AffineFastState.compose env26033 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26033 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26034 : List Nat := [2,4,8,10,11,11,9,14,512,4,10,1,3,10,1,8,1,10,5,0,11,10,11,3,2,10,10,0,1,10,14,11,15,10,10,513]

theorem envBound26034 : H12AffineFastState.Bounded env26034 := by
  intro p hp
  have h : env26034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26033_26034 : H12AffineEnvironment.transform 4 11 env26033 = env26034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26033 == env26034) = true)

theorem identity26034 : scanCanonicalize (H12AffineFastState.compose env26034 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound26034 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26035 : List Nat := [2,4,8,10,11,11,9,14,15,4,10,1,3,10,1,8,1,10,5,0,11,10,11,3,2,10,10,0,1,10,14,11,15,10,10,14]

theorem envBound26035 : H12AffineFastState.Bounded env26035 := by
  intro p hp
  have h : env26035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26034_26035 : H12AffineEnvironment.transform 8 15 env26034 = env26035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env26034 == env26035) = true)

theorem identity26035 : scanCanonicalize (H12AffineFastState.compose env26035 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26035 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26036 : List Nat := [2,4,0,2,3,3,1,6,7,4,2,1,3,2,1,0,1,2,5,0,3,2,3,3,2,2,2,0,1,2,6,3,7,2,2,6]

theorem envBound26036 : H12AffineFastState.Bounded env26036 := by
  intro p hp
  have h : env26036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26035_26036 : H12AffineEnvironment.transform 2 0 env26035 = env26036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26035 == env26036) = true)

def env26037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,4194304,8388608,351657,8328,65,12754345,79131,8763759,8830977,8706488,4314199,257,8484155,8492191,8781422]

theorem envBound26037 : H12AffineFastState.Bounded env26037 := by
  intro p hp
  have h : env26037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25935_26037 : H12AffineEnvironment.transform 23 351657 env25935 = env26037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351657 env25935 == env26037) = true)

def env26038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,4194304,8388608,95497,8328,65,12754345,79131,8491471,8579233,8450328,4314199,257,8484155,8492191,8509134]

theorem envBound26038 : H12AffineFastState.Bounded env26038 := by
  intro p hp
  have h : env26038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26037_26038 : H12AffineEnvironment.transform 17 10400 env26037 = env26038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env26037 == env26038) = true)

def env26039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,32,8388608,95497,8328,65,8560009,79131,8491471,8579233,8450328,119927,257,8484155,8492191,8509134]

theorem envBound26039 : H12AffineFastState.Bounded env26039 := by
  intro p hp
  have h : env26039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26038_26039 : H12AffineEnvironment.transform 21 32 env26038 = env26039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env26038 == env26039) = true)

theorem identity26039 : scanCanonicalize (H12AffineFastState.compose env26039 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound26039 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10400,1025,32769,58517,32,8388608,21762,8328,65,8560009,5392,8434116,8579233,8450328,62588,257,8410416,8434836,8451781]

theorem envBound26040 : H12AffineFastState.Bounded env26040 := by
  intro p hp
  have h : env26040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26039_26040 : H12AffineEnvironment.transform 15 8203 env26039 = env26040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env26039 == env26040) = true)

def env26041 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58397,32,8388608,21762,8192,65,8559873,5392,8433996,8579113,8450328,62588,257,8410416,8434716,8451661]

theorem envBound26041 : H12AffineFastState.Bounded env26041 := by
  intro p hp
  have h : env26041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26040_26041 : H12AffineEnvironment.transform 6 8 env26040 = env26041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26040 == env26041) = true)

theorem identity26041 : scanCanonicalize (H12AffineFastState.compose env26041 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound26041 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10280,1025,29788,4160,32,8388608,21762,8192,65,8546652,5392,8406289,8526964,8389957,33,257,8410416,8405057,8389136]

theorem envBound26042 : H12AffineFastState.Bounded env26042 := by
  intro p hp
  have h : env26042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26041_26042 : H12AffineEnvironment.transform 14 29789 env26041 = env26042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env26041 == env26042) = true)

theorem identity26042 : scanCanonicalize (H12AffineFastState.compose env26042 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(22+1) ^^^ 309) := by decide +kernel

theorem selectedBound26042 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env26043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,10280,1025,29788,4160,32,309,21762,8192,65,157801,5392,17444,138561,1136,33,257,21509,16756,805]

theorem envBound26043 : H12AffineFastState.Bounded env26043 := by
  intro p hp
  have h : env26043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26042_26043 : H12AffineEnvironment.transform 22 309 env26042 = env26043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 309 env26042 == env26043) = true)

theorem identity26043 : scanCanonicalize (H12AffineFastState.compose env26043 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound26043 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env26044 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,29789,8203,131072,10280,1025,29788,4160,32,17,21542,8192,65,157801,5172,17444,138341,1136,33,37,21509,16464,513]

theorem envBound26044 : H12AffineFastState.Bounded env26044 := by
  intro p hp
  have h : env26044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26043_26044 : H12AffineEnvironment.transform 7 36 env26043 = env26044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env26043 == env26044) = true)

theorem identity26044 : scanCanonicalize (H12AffineFastState.compose env26044 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound26044 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env26045 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,16384,16464,5126,131072,7205,1025,16465,4160,32,17,21542,5133,65,154724,5172,17444,138341,1136,33,37,21509,16464,513]

theorem envBound26045 : H12AffineFastState.Bounded env26045 := by
  intro p hp
  have h : env26045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26044_26045 : H12AffineEnvironment.transform 12 5133 env26044 = env26045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env26044 == env26045) = true)

theorem identity26045 : scanCanonicalize (H12AffineFastState.compose env26045 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 21556) := by decide +kernel

theorem selectedBound26045 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env26046 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,16384,16464,5126,21556,7205,1025,16465,4160,32,17,21542,5133,65,2128,5172,17444,18513,1136,33,37,21509,16464,513]

theorem envBound26046 : H12AffineFastState.Bounded env26046 := by
  intro p hp
  have h : env26046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26045_26046 : H12AffineEnvironment.transform 16 21556 env26045 = env26046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21556 env26045 == env26046) = true)

theorem identity26046 : scanCanonicalize (H12AffineFastState.compose env26046 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound26046 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env26047 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,5133,7204,7284,5126,2064,7205,1025,7285,4160,32,17,2050,5133,65,2128,5172,6144,5237,1136,33,37,2081,7284,513]

theorem envBound26047 : H12AffineFastState.Bounded env26047 := by
  intro p hp
  have h : env26047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26046_26047 : H12AffineEnvironment.transform 13 7204 env26046 = env26047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env26046 == env26047) = true)

theorem identity26047 : scanCanonicalize (H12AffineFastState.compose env26047 (packedSelected [0,1,2,3,5,6,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26047 : packedSelected [0,1,2,3,5,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env26048 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,4096,5133,4113,4161,5126,1061,4112,1025,4160,4160,32,17,1079,5133,65,1125,5172,5173,5237,1136,33,37,1044,4161,513]

theorem envBound26048 : H12AffineFastState.Bounded env26048 := by
  intro p hp
  have h : env26048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26047_26048 : H12AffineEnvironment.transform 10 1077 env26047 = env26048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env26047 == env26048) = true)

theorem identity26048 : scanCanonicalize (H12AffineFastState.compose env26048 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound26048 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env26049 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1077,65,1100,80,0,1095,1061,81,1025,1,1,32,17,1079,1100,65,1125,1141,1140,1076,1136,33,37,1044,0,513]

theorem envBound26049 : H12AffineFastState.Bounded env26049 := by
  intro p hp
  have h : env26049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26048_26049 : H12AffineEnvironment.transform 11 65 env26048 = env26049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env26048 == env26049) = true)

theorem identity26049 : scanCanonicalize (H12AffineFastState.compose env26049 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26049 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26050 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,17,1052,0,0,1047,1061,1,1025,1,1,32,17,1079,1052,17,1077,1061,1060,1076,1056,33,37,1044,0,513]

theorem envBound26050 : H12AffineFastState.Bounded env26050 := by
  intro p hp
  have h : env26050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26049_26050 : H12AffineEnvironment.transform 5 16 env26049 = env26050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26049 == env26050) = true)

def env26051 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58396,32,8388608,21762,8193,65,8559872,5392,8433997,8579112,8450328,62588,257,8410416,8434717,8451660]

theorem envBound26051 : H12AffineFastState.Bounded env26051 := by
  intro p hp
  have h : env26051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26040_26051 : H12AffineEnvironment.transform 6 9 env26040 = env26051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26040 == env26051) = true)

theorem identity26051 : scanCanonicalize (H12AffineFastState.compose env26051 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound26051 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26052 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10281,1025,32769,45341,32,8388608,3,8193,65,8559872,5392,8433997,8568105,8430617,41341,257,8388657,8434717,8430413]

theorem envBound26052 : H12AffineFastState.Bounded env26052 := by
  intro p hp
  have h : env26052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26051_26052 : H12AffineEnvironment.transform 13 5377 env26051 = env26052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env26051 == env26052) = true)

theorem identity26052 : scanCanonicalize (H12AffineFastState.compose env26052 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(22+1) ^^^ 144396) := by decide +kernel

theorem selectedBound26052 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env26053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10281,1025,32769,45341,32,144396,3,8193,65,43276,5392,165185,35109,167957,41341,257,144445,163857,169793]

theorem envBound26053 : H12AffineFastState.Bounded env26053 := by
  intro p hp
  have h : env26053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26052_26053 : H12AffineEnvironment.transform 22 144396 env26052 = env26053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 144396 env26052 == env26053) = true)

theorem identity26053 : scanCanonicalize (H12AffineFastState.compose env26053 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound26053 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env26054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8203,131072,10281,1025,1,12573,32,144396,3,8193,65,10508,5392,132417,2341,135189,8573,257,144445,131089,137025]

theorem envBound26054 : H12AffineFastState.Bounded env26054 := by
  intro p hp
  have h : env26054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26053_26054 : H12AffineEnvironment.transform 14 0 env26053 = env26054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env26053 == env26054) = true)

theorem identity26054 : scanCanonicalize (H12AffineFastState.compose env26054 (packedSelected [0,1,6,7,8,14,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound26054 : packedSelected [0,1,6,7,8,14,16,19] rootPS < 2^1333 := by decide +kernel

def env26055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8203,5221,10281,1025,1,12573,32,8297,3,8193,65,10508,5392,4388,2341,1136,8573,257,8280,5236,804]

theorem envBound26055 : H12AffineFastState.Bounded env26055 := by
  intro p hp
  have h : env26055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26054_26055 : H12AffineEnvironment.transform 16 5221 env26054 = env26055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env26054 == env26055) = true)

theorem identity26055 : scanCanonicalize (H12AffineFastState.compose env26055 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound26055 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env26056 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5156,0,8203,5221,10281,1025,1,12344,32,8297,3,8193,65,10281,5173,4097,2048,1136,8280,36,8280,5236,513]

theorem envBound26056 : H12AffineFastState.Bounded env26056 := by
  intro p hp
  have h : env26056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26055_26056 : H12AffineEnvironment.transform 7 37 env26055 = env26056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env26055 == env26056) = true)

theorem identity26056 : scanCanonicalize (H12AffineFastState.compose env26056 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound26056 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env26057 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,5156,0,1046,5221,3124,1025,1,5157,32,1140,3,1052,65,3124,5173,4097,2048,1136,1093,36,1093,5236,513]

theorem envBound26057 : H12AffineFastState.Bounded env26057 := by
  intro p hp
  have h : env26057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26056_26057 : H12AffineEnvironment.transform 12 1053 env26056 = env26057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env26056 == env26057) = true)

theorem identity26057 : scanCanonicalize (H12AffineFastState.compose env26057 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26057 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env26058 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,40,4113,0,35,4176,2049,52,1,4112,32,65,3,41,65,2049,4096,4097,2048,69,112,36,112,4161,513]

theorem envBound26058 : H12AffineFastState.Bounded env26058 := by
  intro p hp
  have h : env26058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26057_26058 : H12AffineEnvironment.transform 9 53 env26057 = env26058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26057 == env26058) = true)

theorem identity26058 : scanCanonicalize (H12AffineFastState.compose env26058 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound26058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26059 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,0,40,17,0,35,80,2049,52,1,16,32,65,3,41,65,2049,0,1,2048,69,112,36,112,65,513]

theorem envBound26059 : H12AffineFastState.Bounded env26059 := by
  intro p hp
  have h : env26059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26058_26059 : H12AffineEnvironment.transform 11 0 env26058 = env26059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26058 == env26059) = true)

theorem identity26059 : scanCanonicalize (H12AffineFastState.compose env26059 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26059 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26060 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,0,40,17,0,35,0,2049,52,1,16,32,17,3,41,17,2049,0,1,2048,21,32,36,32,17,513]

theorem envBound26060 : H12AffineFastState.Bounded env26060 := by
  intro p hp
  have h : env26060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26059_26060 : H12AffineEnvironment.transform 5 16 env26059 = env26060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26059 == env26060) = true)

theorem identity26060 : scanCanonicalize (H12AffineFastState.compose env26060 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 565) := by decide +kernel

theorem selectedBound26060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26061 : List Nat := [2,4,8,16,32,16,9,37,512,53,565,0,40,17,0,35,0,564,52,1,16,32,17,3,41,17,564,0,1,565,21,32,36,32,17,513]

theorem envBound26061 : H12AffineFastState.Bounded env26061 := by
  intro p hp
  have h : env26061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26060_26061 : H12AffineEnvironment.transform 10 565 env26060 = env26061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 565 env26060 == env26061) = true)

theorem identity26061 : scanCanonicalize (H12AffineFastState.compose env26061 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound26061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26062 : List Nat := [2,4,8,16,32,16,9,37,44,53,25,0,40,17,0,35,0,24,52,1,16,32,17,3,41,17,24,0,1,25,21,32,36,32,17,45]

theorem envBound26062 : H12AffineFastState.Bounded env26062 := by
  intro p hp
  have h : env26062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26061_26062 : H12AffineEnvironment.transform 8 44 env26061 = env26062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env26061 == env26062) = true)

theorem identity26062 : scanCanonicalize (H12AffineFastState.compose env26062 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound26062 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26063 : List Nat := [2,4,8,3,32,3,9,37,44,38,10,0,40,2,0,35,0,11,39,1,3,32,2,3,41,2,11,0,1,10,6,32,36,32,2,45]

theorem envBound26063 : H12AffineFastState.Bounded env26063 := by
  intro p hp
  have h : env26063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26062_26063 : H12AffineEnvironment.transform 3 3 env26062 = env26063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env26062 == env26063) = true)

theorem identity26063 : scanCanonicalize (H12AffineFastState.compose env26063 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound26063 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26064 : List Nat := [2,4,8,3,8,3,9,13,4,14,10,0,0,2,0,11,0,11,15,1,3,8,2,3,1,2,11,0,1,10,6,8,12,8,2,5]

theorem envBound26064 : H12AffineFastState.Bounded env26064 := by
  intro p hp
  have h : env26064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26063_26064 : H12AffineEnvironment.transform 4 8 env26063 = env26064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env26063 == env26064) = true)

def env26065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,33,8388608,95497,8328,65,8560008,79131,8491471,8579233,8450328,119926,257,8484155,8492191,8509134]

theorem envBound26065 : H12AffineFastState.Bounded env26065 := by
  intro p hp
  have h : env26065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26038_26065 : H12AffineEnvironment.transform 21 33 env26038 = env26065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env26038 == env26065) = true)

theorem identity26065 : scanCanonicalize (H12AffineFastState.compose env26065 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound26065 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env26066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,115870,33,73754,95497,8328,65,245138,79131,45525,247995,119042,119926,257,21793,46213,63188]

theorem envBound26066 : H12AffineFastState.Bounded env26066 := by
  intro p hp
  have h : env26066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26065_26066 : H12AffineEnvironment.transform 22 73754 env26065 = env26066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env26065 == env26066) = true)

def env26067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,33,73754,95497,8192,65,245018,79131,45405,247859,119042,119926,257,21793,46093,63068]

theorem envBound26067 : H12AffineFastState.Bounded env26067 := by
  intro p hp
  have h : env26067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26066_26067 : H12AffineEnvironment.transform 6 8 env26066 = env26067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26066 == env26067) = true)

theorem identity26067 : scanCanonicalize (H12AffineFastState.compose env26067 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound26067 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10280,1025,32769,4160,33,62540,41311,8192,65,158028,57677,45405,138341,1364,32,257,21793,46093,63068]

theorem envBound26068 : H12AffineFastState.Bounded env26068 := by
  intro p hp
  have h : env26068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26067_26068 : H12AffineEnvironment.transform 15 54358 env26067 = env26068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env26067 == env26068) = true)

theorem identity26068 : scanCanonicalize (H12AffineFastState.compose env26068 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound26068 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env26069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,41051,131072,10280,1025,32769,4160,33,32833,41311,8192,65,138561,38208,45405,138341,1364,32,257,8492,46093,33361]

theorem envBound26069 : H12AffineFastState.Bounded env26069 := by
  intro p hp
  have h : env26069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26068_26069 : H12AffineEnvironment.transform 13 13325 env26068 = env26069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env26068 == env26069) = true)

theorem identity26069 : scanCanonicalize (H12AffineFastState.compose env26069 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound26069 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env26070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4112,32768,33862,131072,3125,1025,32769,4160,33,32833,34114,1053,65,138561,38208,38208,138341,1364,32,257,1329,36880,33361]

theorem envBound26070 : H12AffineFastState.Bounded env26070 := by
  intro p hp
  have h : env26070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26069_26070 : H12AffineEnvironment.transform 12 1053 env26069 = env26070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env26069 == env26070) = true)

theorem identity26070 : scanCanonicalize (H12AffineFastState.compose env26070 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound26070 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env26071 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4112,32768,33862,4096,3125,1025,32769,4160,33,32833,34114,1053,65,3393,38208,38208,3173,1364,32,257,1329,36880,33361]

theorem envBound26071 : H12AffineFastState.Bounded env26071 := by
  intro p hp
  have h : env26071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26070_26071 : H12AffineEnvironment.transform 16 4096 env26070 = env26071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env26070 == env26071) = true)

theorem identity26071 : scanCanonicalize (H12AffineFastState.compose env26071 (packedSelected [3,4,5,9,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26071 : packedSelected [3,4,5,9,10,11,14] rootPS < 2^1333 := by decide +kernel

def env26072 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,4096,1053,4112,32768,33862,4096,0,1025,32769,4160,33,32833,34114,1053,65,372,38208,38208,80,1364,32,257,1329,36880,33361]

theorem envBound26072 : H12AffineFastState.Bounded env26072 := by
  intro p hp
  have h : env26072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26071_26072 : H12AffineEnvironment.transform 10 1077 env26071 = env26072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env26071 == env26072) = true)

theorem identity26072 : scanCanonicalize (H12AffineFastState.compose env26072 (packedSelected [0,1,2,6,7,8,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound26072 : packedSelected [0,1,2,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env26073 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,1360,1053,1344,32768,33862,1360,0,1025,32769,1296,33,32833,34114,1053,65,372,32784,32784,80,1364,32,257,1329,34112,33361]

theorem envBound26073 : H12AffineFastState.Bounded env26073 := by
  intro p hp
  have h : env26073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26072_26073 : H12AffineEnvironment.transform 11 1360 env26072 = env26073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env26072 == env26073) = true)

theorem identity26073 : scanCanonicalize (H12AffineFastState.compose env26073 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound26073 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env26074 : List Nat := [2,4,8,16,32,64,8,85,512,1024,1077,1029,1053,1045,32768,33862,1029,0,1025,32769,1093,33,32833,33815,1053,65,33,32784,32784,80,1025,32,84,1124,33813,33361]

theorem envBound26074 : H12AffineFastState.Bounded env26074 := by
  intro p hp
  have h : env26074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26073_26074 : H12AffineEnvironment.transform 7 85 env26073 = env26074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env26073 == env26074) = true)

theorem identity26074 : scanCanonicalize (H12AffineFastState.compose env26074 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26074 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26075 : List Nat := [2,4,8,16,32,64,8,85,512,101,80,96,120,112,32768,32803,96,0,100,32769,32,33,32833,32882,120,65,33,32784,32784,80,100,32,84,1,32880,33361]

theorem envBound26075 : H12AffineFastState.Bounded env26075 := by
  intro p hp
  have h : env26075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26074_26075 : H12AffineEnvironment.transform 9 101 env26074 = env26075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26074 == env26075) = true)

theorem identity26075 : scanCanonicalize (H12AffineFastState.compose env26075 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound26075 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env26076 : List Nat := [2,4,8,16,32,48,8,37,512,21,32,16,8,0,32768,32803,16,0,20,32769,32,33,32817,32770,8,49,33,32784,32784,32,20,32,36,1,32768,33313]

theorem envBound26076 : H12AffineFastState.Bounded env26076 := by
  intro p hp
  have h : env26076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26075_26076 : H12AffineEnvironment.transform 5 48 env26075 = env26076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env26075 == env26076) = true)

def env26077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,33,73754,95497,8193,65,245019,79131,45404,247858,119042,119926,257,21793,46092,63069]

theorem envBound26077 : H12AffineFastState.Bounded env26077 := by
  intro p hp
  have h : env26077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26066_26077 : H12AffineEnvironment.transform 6 9 env26066 = env26077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26066 == env26077) = true)

theorem identity26077 : scanCanonicalize (H12AffineFastState.compose env26077 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound26077 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env26078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10281,1025,32769,45341,33,21776,3,8193,65,182289,16401,45404,179512,41992,41340,257,21793,46092,63069]

theorem envBound26078 : H12AffineFastState.Bounded env26078 := by
  intro p hp
  have h : env26078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26077_26078 : H12AffineEnvironment.transform 15 29962 env26077 = env26078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env26077 == env26078) = true)

theorem identity26078 : scanCanonicalize (H12AffineFastState.compose env26078 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound26078 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env26079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,5393,10281,1025,32769,45341,33,21776,3,8193,65,56576,16401,45404,43049,41992,41340,257,21793,46092,63069]

theorem envBound26079 : H12AffineFastState.Bounded env26079 := by
  intro p hp
  have h : env26079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26078_26079 : H12AffineEnvironment.transform 16 5393 env26078 = env26079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env26078 == env26079) = true)

theorem identity26079 : scanCanonicalize (H12AffineFastState.compose env26079 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound26079 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env26080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29993,29962,5393,10281,1025,29992,17460,33,21776,3,8193,65,10281,16401,17525,23808,20769,21589,257,21793,16677,884]

theorem envBound26080 : H12AffineFastState.Bounded env26080 := by
  intro p hp
  have h : env26080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26079_26080 : H12AffineEnvironment.transform 14 29993 env26079 = env26080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env26079 == env26080) = true)

theorem identity26080 : scanCanonicalize (H12AffineFastState.compose env26080 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound26080 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env26081 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29788,29823,5220,10281,1025,29789,17460,33,21605,3,8193,65,10281,16401,17525,23669,20564,21589,116,21588,16464,513]

theorem envBound26081 : H12AffineFastState.Bounded env26081 := by
  intro p hp
  have h : env26081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26080_26081 : H12AffineEnvironment.transform 7 117 env26080 = env26081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env26080 == env26081) = true)

theorem identity26081 : scanCanonicalize (H12AffineFastState.compose env26081 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound26081 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env26082 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5156,8312,8283,5220,10281,1025,8313,4112,33,65,3,8193,65,10281,5173,4177,2129,1136,113,116,112,5236,513]

theorem envBound26082 : H12AffineFastState.Bounded env26082 := by
  intro p hp
  have h : env26082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26081_26082 : H12AffineEnvironment.transform 13 5156 env26081 = env26082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env26081 == env26082) = true)

theorem identity26082 : scanCanonicalize (H12AffineFastState.compose env26082 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26082 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26083 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5156,8232,8203,5172,10281,1025,8233,4112,33,17,3,8193,17,10281,5173,4097,2049,1056,33,36,32,5156,513]

theorem envBound26083 : H12AffineFastState.Bounded env26083 := by
  intro p hp
  have h : env26083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26082_26083 : H12AffineEnvironment.transform 5 16 env26082 = env26083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26082 == env26083) = true)

theorem identity26083 : scanCanonicalize (H12AffineFastState.compose env26083 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound26083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26084 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,1084,5156,1044,1079,5172,3093,1025,1045,4112,33,17,3,1085,17,3093,5173,4097,2049,1056,33,36,32,5156,513]

theorem envBound26084 : H12AffineFastState.Bounded env26084 := by
  intro p hp
  have h : env26084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26083_26084 : H12AffineEnvironment.transform 12 1084 env26083 = env26084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env26083 == env26084) = true)

theorem identity26084 : scanCanonicalize (H12AffineFastState.compose env26084 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound26084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26085 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,4096,1084,5156,1044,1079,5172,1077,1025,1045,4112,33,17,3,1085,17,1077,5173,4097,33,1056,33,36,32,5156,513]

theorem envBound26085 : H12AffineFastState.Bounded env26085 := by
  intro p hp
  have h : env26085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26084_26085 : H12AffineEnvironment.transform 10 32 env26084 = env26085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env26084 == env26085) = true)

theorem identity26085 : scanCanonicalize (H12AffineFastState.compose env26085 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound26085 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env26086 : List Nat := [2,4,8,16,32,16,9,37,512,1024,32,1573,1084,513,1044,1079,529,1077,1025,1045,1589,33,17,3,1085,17,1077,528,1572,33,1056,33,36,32,513,513]

theorem envBound26086 : H12AffineFastState.Bounded env26086 := by
  intro p hp
  have h : env26086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26085_26086 : H12AffineEnvironment.transform 11 1573 env26085 = env26086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env26085 == env26086) = true)

theorem identity26086 : scanCanonicalize (H12AffineFastState.compose env26086 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound26086 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26087 : List Nat := [2,4,8,16,32,16,9,37,512,53,32,528,9,513,33,2,529,0,52,32,512,33,17,3,8,17,0,528,529,33,21,33,36,32,513,513]

theorem envBound26087 : H12AffineFastState.Bounded env26087 := by
  intro p hp
  have h : env26087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26086_26087 : H12AffineEnvironment.transform 9 53 env26086 = env26087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env26086 == env26087) = true)

theorem identity26087 : scanCanonicalize (H12AffineFastState.compose env26087 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound26087 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26088 : List Nat := [2,4,8,16,32,16,9,37,48,53,32,32,9,49,33,2,33,0,52,32,48,33,17,3,8,17,0,32,33,33,21,33,36,32,49,49]

theorem envBound26088 : H12AffineFastState.Bounded env26088 := by
  intro p hp
  have h : env26088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26087_26088 : H12AffineEnvironment.transform 8 48 env26087 = env26088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env26087 == env26088) = true)

theorem identity26088 : scanCanonicalize (H12AffineFastState.compose env26088 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound26088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26089 : List Nat := [2,4,8,1,32,1,9,37,33,36,32,32,9,32,33,2,33,0,37,32,33,33,0,3,8,0,0,32,33,33,4,33,36,32,32,32]

theorem envBound26089 : H12AffineFastState.Bounded env26089 := by
  intro p hp
  have h : env26089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26088_26089 : H12AffineEnvironment.transform 3 1 env26088 = env26089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env26088 == env26089) = true)

theorem identity26089 : scanCanonicalize (H12AffineFastState.compose env26089 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound26089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26090 : List Nat := [2,4,3,1,32,1,2,37,33,36,32,32,2,32,33,2,33,0,37,32,33,33,0,3,3,0,0,32,33,33,4,33,36,32,32,32]

theorem envBound26090 : H12AffineFastState.Bounded env26090 := by
  intro p hp
  have h : env26090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1