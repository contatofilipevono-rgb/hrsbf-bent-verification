import H12CloudChart1Data144

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound36771 : H12AffineFastState.Bounded env36771 := by
  intro p hp
  have h : env36771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36770_36771 : H12AffineEnvironment.transform 10 137 env36770 = env36771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env36770 == env36771) = true)

theorem identity36771 : scanCanonicalize (H12AffineFastState.compose env36771 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36771 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env36772 : List Nat := [2,4,8,16,32,16,128,37,130,189,137,153,161,0,1,171,16,0,188,0,137,168,16,3,41,16,0,16,152,1,20,33,36,32,1,131]

theorem envBound36772 : H12AffineFastState.Bounded env36772 := by
  intro p hp
  have h : env36772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36771_36772 : H12AffineEnvironment.transform 7 37 env36771 = env36772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36771 == env36772) = true)

theorem identity36772 : scanCanonicalize (H12AffineFastState.compose env36772 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36773 : List Nat := [2,4,8,16,1,16,128,4,130,156,137,153,128,0,1,138,16,0,157,0,137,137,16,3,8,16,0,16,152,1,20,0,5,1,1,131]

theorem envBound36773 : H12AffineFastState.Bounded env36773 := by
  intro p hp
  have h : env36773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36772_36773 : H12AffineEnvironment.transform 4 1 env36772 = env36773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36772 == env36773) = true)

theorem identity36773 : scanCanonicalize (H12AffineFastState.compose env36773 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36773 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36774 : List Nat := [2,4,3,16,1,16,128,4,130,151,130,146,128,0,1,129,16,0,150,0,130,130,16,3,3,16,0,16,147,1,20,0,5,1,1,131]

theorem envBound36774 : H12AffineFastState.Bounded env36774 := by
  intro p hp
  have h : env36774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36773_36774 : H12AffineEnvironment.transform 2 3 env36773 = env36774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36773 == env36774) = true)

theorem identity36774 : scanCanonicalize (H12AffineFastState.compose env36774 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 23) := by decide +kernel

theorem selectedBound36774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36775 : List Nat := [2,4,3,16,1,16,23,4,21,0,21,5,23,0,1,22,16,0,1,0,21,21,16,3,3,16,0,16,4,1,20,0,5,1,1,20]

theorem envBound36775 : H12AffineFastState.Bounded env36775 := by
  intro p hp
  have h : env36775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36774_36775 : H12AffineEnvironment.transform 6 23 env36774 = env36775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 23 env36774 == env36775) = true)

theorem identity36775 : scanCanonicalize (H12AffineFastState.compose env36775 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36775 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36776 : List Nat := [2,0,3,16,1,16,19,0,17,0,17,1,19,0,1,18,16,0,1,0,17,17,16,3,3,16,0,16,0,1,16,0,1,1,1,16]

theorem envBound36776 : H12AffineFastState.Bounded env36776 := by
  intro p hp
  have h : env36776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36775_36776 : H12AffineEnvironment.transform 1 0 env36775 = env36776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36775 == env36776) = true)

theorem identity36776 : scanCanonicalize (H12AffineFastState.compose env36776 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound36776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36777 : List Nat := [2,0,3,3,1,3,0,0,2,0,2,1,0,0,1,1,3,0,1,0,2,2,3,3,3,3,0,3,0,1,3,0,1,1,1,3]

theorem envBound36777 : H12AffineFastState.Bounded env36777 := by
  intro p hp
  have h : env36777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36776_36777 : H12AffineEnvironment.transform 3 3 env36776 = env36777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env36776 == env36777) = true)

def env36778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,21928,41412,73736,8328,64,43356,46277,58580,56573,1500,33,257,21793,46213,74251]

theorem envBound36778 : H12AffineFastState.Bounded env36778 := by
  intro p hp
  have h : env36778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36761_36778 : H12AffineEnvironment.transform 16 38161 env36761 = env36778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env36761 == env36778) = true)

theorem identity36778 : scanCanonicalize (H12AffineFastState.compose env36778 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13389,10280,1025,8541,4160,21928,152,73736,8328,64,2048,5529,17800,32161,1500,33,257,21793,5593,74251]

theorem envBound36779 : H12AffineFastState.Bounded env36779 := by
  intro p hp
  have h : env36779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36778_36779 : H12AffineEnvironment.transform 14 8540 env36778 = env36779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36778 == env36779) = true)

theorem identity36779 : scanCanonicalize (H12AffineFastState.compose env36779 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36779 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,65536,5392,2421,1025,0,4160,21928,152,65877,469,64,2048,5529,17800,23804,1500,33,257,21793,5593,66390]

theorem envBound36780 : H12AffineFastState.Bounded env36780 := by
  intro p hp
  have h : env36780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36779_36780 : H12AffineEnvironment.transform 12 349 env36779 = env36780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36779 == env36780) = true)

theorem identity36780 : scanCanonicalize (H12AffineFastState.compose env36780 (packedSelected [5,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36780 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env36781 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,16384,1,65536,4096,2421,273,0,4160,20664,152,65877,469,64,2048,4233,16536,23020,204,33,257,20529,4297,66390]

theorem envBound36781 : H12AffineFastState.Bounded env36781 := by
  intro p hp
  have h : env36781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36780_36781 : H12AffineEnvironment.transform 9 272 env36780 = env36781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36780 == env36781) = true)

theorem identity36781 : scanCanonicalize (H12AffineFastState.compose env36781 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound36781 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env36782 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4405,1,65536,4096,2421,273,0,4160,397,152,65877,469,64,2048,4233,4525,2265,204,33,257,260,4297,66390]

theorem envBound36782 : H12AffineFastState.Bounded env36782 := by
  intro p hp
  have h : env36782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36781_36782 : H12AffineEnvironment.transform 13 4405 env36781 = env36782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env36781 == env36782) = true)

theorem identity36782 : scanCanonicalize (H12AffineFastState.compose env36782 (packedSelected [2,3,5,6,9,10,11,14,16,18,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound36782 : packedSelected [2,3,5,6,9,10,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env36783 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,161,4297,1,65536,4096,2185,237,0,4160,113,152,65705,41,64,2048,4233,4177,2265,204,33,253,248,4297,66218]

theorem envBound36783 : H12AffineFastState.Bounded env36783 := by
  intro p hp
  have h : env36783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36782_36783 : H12AffineEnvironment.transform 7 252 env36782 = env36783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env36782 == env36783) = true)

theorem identity36783 : scanCanonicalize (H12AffineFastState.compose env36783 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36783 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env36784 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,161,4297,1,34,4096,2185,237,0,4160,113,152,139,41,64,2048,4233,4177,2265,204,33,253,248,4297,648]

theorem envBound36784 : H12AffineFastState.Bounded env36784 := by
  intro p hp
  have h : env36784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36783_36784 : H12AffineEnvironment.transform 15 34 env36783 = env36784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36783 == env36784) = true)

theorem identity36784 : scanCanonicalize (H12AffineFastState.compose env36784 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound36784 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36785 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,2201,161,2128,1,34,2201,2185,237,0,2265,113,152,139,41,64,2048,2064,2248,2265,204,33,253,248,2128,648]

theorem envBound36785 : H12AffineFastState.Bounded env36785 := by
  intro p hp
  have h : env36785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36784_36785 : H12AffineEnvironment.transform 11 2201 env36784 = env36785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env36784 == env36785) = true)

theorem identity36785 : scanCanonicalize (H12AffineFastState.compose env36785 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36785 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36786 : List Nat := [2,4,8,16,32,16,128,172,512,188,2048,2201,161,2048,1,34,2201,2185,189,0,2185,33,152,139,41,16,2048,2064,2200,2185,156,33,173,168,2048,648]

theorem envBound36786 : H12AffineFastState.Bounded env36786 := by
  intro p hp
  have h : env36786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36785_36786 : H12AffineEnvironment.transform 5 16 env36785 = env36786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36785 == env36786) = true)

theorem identity36786 : scanCanonicalize (H12AffineFastState.compose env36786 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound36786 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36787 : List Nat := [2,4,8,16,32,16,128,172,512,188,545,696,161,545,1,34,696,680,189,0,680,33,152,139,41,16,545,561,697,680,156,33,173,168,545,648]

theorem envBound36787 : H12AffineFastState.Bounded env36787 := by
  intro p hp
  have h : env36787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36786_36787 : H12AffineEnvironment.transform 10 545 env36786 = env36787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env36786 == env36787) = true)

theorem identity36787 : scanCanonicalize (H12AffineFastState.compose env36787 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound36787 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env36788 : List Nat := [2,4,8,16,32,16,24,52,512,36,545,544,57,545,1,34,544,560,37,0,560,33,0,19,41,16,545,561,545,560,4,33,53,48,545,528]

theorem envBound36788 : H12AffineFastState.Bounded env36788 := by
  intro p hp
  have h : env36788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36787_36788 : H12AffineEnvironment.transform 6 24 env36787 = env36788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env36787 == env36788) = true)

theorem identity36788 : scanCanonicalize (H12AffineFastState.compose env36788 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36788 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36789 : List Nat := [2,4,8,16,0,16,24,20,512,4,513,512,25,513,1,2,512,528,5,0,528,1,0,19,9,16,513,529,513,528,4,1,21,16,513,528]

theorem envBound36789 : H12AffineFastState.Bounded env36789 := by
  intro p hp
  have h : env36789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36788_36789 : H12AffineEnvironment.transform 4 0 env36788 = env36789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36788 == env36789) = true)

theorem identity36789 : scanCanonicalize (H12AffineFastState.compose env36789 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36790 : List Nat := [2,4,8,1,0,1,9,5,512,4,513,512,8,513,1,2,512,513,5,0,513,1,0,2,9,1,513,512,513,513,4,1,4,1,513,513]

theorem envBound36790 : H12AffineFastState.Bounded env36790 := by
  intro p hp
  have h : env36790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36789_36790 : H12AffineEnvironment.transform 3 1 env36789 = env36790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36789 == env36790) = true)

theorem identity36790 : scanCanonicalize (H12AffineFastState.compose env36790 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound36790 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36791 : List Nat := [2,4,8,1,0,1,9,5,5,4,4,5,8,4,1,2,5,4,5,0,4,1,0,2,9,1,4,5,4,4,4,1,4,1,4,4]

theorem envBound36791 : H12AffineFastState.Bounded env36791 := by
  intro p hp
  have h : env36791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36790_36791 : H12AffineEnvironment.transform 8 5 env36790 = env36791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env36790 == env36791) = true)

theorem identity36791 : scanCanonicalize (H12AffineFastState.compose env36791 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36792 : List Nat := [2,4,5,1,0,1,4,5,5,4,4,5,5,4,1,2,5,4,5,0,4,1,0,2,4,1,4,5,4,4,4,1,4,1,4,4]

theorem envBound36792 : H12AffineFastState.Bounded env36792 := by
  intro p hp
  have h : env36792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36791_36792 : H12AffineEnvironment.transform 2 5 env36791 = env36792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36791 == env36792) = true)

theorem identity36792 : scanCanonicalize (H12AffineFastState.compose env36792 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36792 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36793 : List Nat := [1,4,5,1,0,1,4,5,5,4,4,5,5,4,1,1,5,4,5,0,4,1,0,1,4,1,4,5,4,4,4,1,4,1,4,4]

theorem envBound36793 : H12AffineFastState.Bounded env36793 := by
  intro p hp
  have h : env36793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36792_36793 : H12AffineEnvironment.transform 0 1 env36792 = env36793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36792 == env36793) = true)

theorem identity36793 : scanCanonicalize (H12AffineFastState.compose env36793 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36793 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36794 : List Nat := [1,1,0,1,0,1,1,0,0,1,1,0,0,1,1,1,0,1,0,0,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1]

theorem envBound36794 : H12AffineFastState.Bounded env36794 := by
  intro p hp
  have h : env36794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36793_36794 : H12AffineEnvironment.transform 1 1 env36793 = env36794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36793 == env36794) = true)

def env36795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180408,144597,242969,8328,64,43356,139732,160197,56572,1500,32,257,21793,46213,74251]

theorem envBound36795 : H12AffineFastState.Bounded env36795 := by
  intro p hp
  have h : env36795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36760_36795 : H12AffineEnvironment.transform 17 10281 env36760 = env36795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36760 == env36795) = true)

def env36796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,21928,41413,73737,8328,64,43356,46276,58581,56572,1500,32,257,21793,46213,74251]

theorem envBound36796 : H12AffineFastState.Bounded env36796 := by
  intro p hp
  have h : env36796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36795_36796 : H12AffineEnvironment.transform 16 38160 env36795 = env36796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env36795 == env36796) = true)

def env36797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,65536,38160,10281,1025,32769,4160,8572,41413,73737,8328,64,43356,46276,36865,43048,1500,32,257,8693,46213,74251]

theorem envBound36797 : H12AffineFastState.Bounded env36797 := by
  intro p hp
  have h : env36797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36796_36797 : H12AffineEnvironment.transform 13 13524 env36796 = env36797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env36796 == env36797) = true)

theorem identity36797 : scanCanonicalize (H12AffineFastState.compose env36797 (packedSelected [3,4,5,7,9,10,14,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound36797 : packedSelected [3,4,5,7,9,10,14,27,35] rootPS < 2^1333 := by decide +kernel

def env36798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,41091,38160,10281,1025,32769,4160,8572,41413,32906,8328,64,43356,46276,36865,43048,1500,32,257,8693,46213,33416]

theorem envBound36798 : H12AffineFastState.Bounded env36798 := by
  intro p hp
  have h : env36798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36797_36798 : H12AffineEnvironment.transform 15 41091 env36797 = env36798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env36797 == env36798) = true)

theorem identity36798 : scanCanonicalize (H12AffineFastState.compose env36798 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36798 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env36799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,32768,33246,38160,2420,1025,32769,4160,33,32920,32906,469,64,34817,38297,36865,35189,1500,32,257,168,38360,33416]

theorem envBound36799 : H12AffineFastState.Bounded env36799 := by
  intro p hp
  have h : env36799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36798_36799 : H12AffineEnvironment.transform 12 349 env36798 = env36799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36798 == env36799) = true)

theorem identity36799 : scanCanonicalize (H12AffineFastState.compose env36799 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound36799 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,0,478,5392,2420,1025,1,4160,33,152,138,469,64,2049,5529,4097,2421,1500,32,257,168,5592,648]

theorem envBound36800 : H12AffineFastState.Bounded env36800 := by
  intro p hp
  have h : env36800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36799_36800 : H12AffineEnvironment.transform 14 0 env36799 = env36800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env36799 == env36800) = true)

def env36801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38160,10281,1025,32769,4160,8573,41413,73737,8328,64,43356,46276,36864,43049,1500,32,257,8692,46213,74251]

theorem envBound36801 : H12AffineFastState.Bounded env36801 := by
  intro p hp
  have h : env36801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36796_36801 : H12AffineEnvironment.transform 13 13525 env36796 = env36801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env36796 == env36801) = true)

theorem identity36801 : scanCanonicalize (H12AffineFastState.compose env36801 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36801 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,38160,10281,1025,32769,4160,8573,41413,3,8328,64,43356,46276,36864,43049,1500,32,257,8692,46213,513]

theorem envBound36802 : H12AffineFastState.Bounded env36802 := by
  intro p hp
  have h : env36802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36801_36802 : H12AffineEnvironment.transform 15 8202 env36801 = env36802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36801 == env36802) = true)

theorem identity36802 : scanCanonicalize (H12AffineFastState.compose env36802 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound36802 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8660,8202,13508,10281,1025,8661,4160,8573,17,3,8328,64,2184,5392,12756,2557,1500,32,257,8692,5457,513]

theorem envBound36803 : H12AffineFastState.Bounded env36803 := by
  intro p hp
  have h : env36803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36802_36803 : H12AffineEnvironment.transform 14 8660 env36802 = env36803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env36802 == env36803) = true)

theorem identity36803 : scanCanonicalize (H12AffineFastState.compose env36803 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36803 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,136,342,5528,2421,1025,137,4160,33,17,3,468,64,2184,5392,4232,2557,1500,32,257,168,5457,513]

theorem envBound36804 : H12AffineFastState.Bounded env36804 := by
  intro p hp
  have h : env36804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36803_36804 : H12AffineEnvironment.transform 12 348 env36803 = env36804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36803 == env36804) = true)

theorem identity36804 : scanCanonicalize (H12AffineFastState.compose env36804 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36804 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,342,5393,2421,1025,0,4160,33,17,3,349,64,2049,5392,4097,2420,1365,32,257,33,5457,513]

theorem envBound36805 : H12AffineFastState.Bounded env36805 := by
  intro p hp
  have h : env36805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36804_36805 : H12AffineEnvironment.transform 6 9 env36804 = env36805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36804 == env36805) = true)

theorem identity36805 : scanCanonicalize (H12AffineFastState.compose env36805 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36805 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36806 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4161,1,342,4176,2421,320,0,4160,33,17,3,349,64,2049,4177,4097,2420,20,32,257,33,4112,513]

theorem envBound36806 : H12AffineFastState.Bounded env36806 := by
  intro p hp
  have h : env36806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36805_36806 : H12AffineEnvironment.transform 9 321 env36805 = env36806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36805 == env36806) = true)

theorem identity36806 : scanCanonicalize (H12AffineFastState.compose env36806 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound36806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36807 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,309,348,372,1,342,357,2421,320,0,373,33,17,3,349,64,2049,356,308,2420,20,32,257,33,293,513]

theorem envBound36807 : H12AffineFastState.Bounded env36807 := by
  intro p hp
  have h : env36807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36806_36807 : H12AffineEnvironment.transform 11 309 env36806 = env36807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env36806 == env36807) = true)

theorem identity36807 : scanCanonicalize (H12AffineFastState.compose env36807 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36807 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36808 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,65,40,0,1,34,17,2049,52,0,1,33,17,3,41,64,2049,16,64,2048,20,32,117,33,81,513]

theorem envBound36808 : H12AffineFastState.Bounded env36808 := by
  intro p hp
  have h : env36808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36807_36808 : H12AffineEnvironment.transform 7 116 env36807 = env36808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36807 == env36808) = true)

theorem identity36808 : scanCanonicalize (H12AffineFastState.compose env36808 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36808 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36809 : List Nat := [2,4,8,16,32,64,9,116,512,53,0,65,40,0,1,34,17,1,52,0,1,33,17,3,41,64,1,16,64,0,20,32,117,33,81,513]

theorem envBound36809 : H12AffineFastState.Bounded env36809 := by
  intro p hp
  have h : env36809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36808_36809 : H12AffineEnvironment.transform 10 0 env36808 = env36809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36808 == env36809) = true)

def env36810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,21929,41412,73736,8328,64,43356,46277,58580,56572,1500,32,257,21793,46213,74251]

theorem envBound36810 : H12AffineFastState.Bounded env36810 := by
  intro p hp
  have h : env36810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36795_36810 : H12AffineEnvironment.transform 16 38161 env36795 = env36810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env36795 == env36810) = true)

theorem identity36810 : scanCanonicalize (H12AffineFastState.compose env36810 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36810 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,21793,41292,73736,8192,64,43356,46157,58460,56436,1364,32,257,21793,46093,74251]

theorem envBound36811 : H12AffineFastState.Bounded env36811 := by
  intro p hp
  have h : env36811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36810_36811 : H12AffineEnvironment.transform 6 8 env36810 = env36811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36810 == env36811) = true)

theorem identity36811 : scanCanonicalize (H12AffineFastState.compose env36811 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound36811 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,38161,10281,1025,32769,4160,21793,41292,32770,8192,64,43356,46157,58460,56436,1364,32,257,21793,46093,33281]

theorem envBound36812 : H12AffineFastState.Bounded env36812 := by
  intro p hp
  have h : env36812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36811_36812 : H12AffineEnvironment.transform 15 40970 env36811 = env36812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env36811 == env36812) = true)

theorem identity36812 : scanCanonicalize (H12AffineFastState.compose env36812 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound36812 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,5393,10281,1025,1,4160,21793,8524,2,8192,64,10588,13389,25692,23668,1364,32,257,21793,13325,513]

theorem envBound36813 : H12AffineFastState.Bounded env36813 := by
  intro p hp
  have h : env36813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36812_36813 : H12AffineEnvironment.transform 14 0 env36812 = env36813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env36812 == env36813) = true)

theorem identity36813 : scanCanonicalize (H12AffineFastState.compose env36813 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound36813 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env36814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,5393,10281,1025,1,4160,8572,8524,2,8192,64,10588,13389,4097,10281,1364,32,257,8572,13325,513]

theorem envBound36814 : H12AffineFastState.Bounded env36814 := by
  intro p hp
  have h : env36814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36813_36814 : H12AffineEnvironment.transform 13 13405 env36813 = env36814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env36813 == env36814) = true)

theorem identity36814 : scanCanonicalize (H12AffineFastState.compose env36814 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36814 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,0,263,5393,2340,1025,1,4160,113,65,2,269,64,2129,5440,4097,2340,1364,32,257,113,5376,513]

theorem envBound36815 : H12AffineFastState.Bounded env36815 := by
  intro p hp
  have h : env36815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36814_36815 : H12AffineEnvironment.transform 12 269 env36814 = env36815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36814 == env36815) = true)

theorem identity36815 : scanCanonicalize (H12AffineFastState.compose env36815 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36815 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36816 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1025,1,4112,33,17,2,269,16,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound36816 : H12AffineFastState.Bounded env36816 := by
  intro p hp
  have h : env36816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36815_36816 : H12AffineEnvironment.transform 5 16 env36815 = env36816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36815 == env36816) = true)

theorem identity36816 : scanCanonicalize (H12AffineFastState.compose env36816 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound36816 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36817 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,269,1045,0,263,1028,2340,1025,1,261,33,17,2,269,16,2049,1029,276,2340,1284,32,257,33,1045,513]

theorem envBound36817 : H12AffineFastState.Bounded env36817 := by
  intro p hp
  have h : env36817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36816_36817 : H12AffineEnvironment.transform 11 277 env36816 = env36817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env36816 == env36817) = true)

theorem identity36817 : scanCanonicalize (H12AffineFastState.compose env36817 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound36817 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36818 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,277,269,1,0,263,16,2340,21,1,261,33,17,2,269,16,2049,17,276,2340,272,32,257,33,1,513]

theorem envBound36818 : H12AffineFastState.Bounded env36818 := by
  intro p hp
  have h : env36818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36817_36818 : H12AffineEnvironment.transform 9 20 env36817 = env36818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36817 == env36818) = true)

theorem identity36818 : scanCanonicalize (H12AffineFastState.compose env36818 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound36818 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36819 : List Nat := [2,4,8,16,32,16,8,256,260,20,2048,277,269,1,0,263,16,2340,21,1,261,33,17,2,269,16,2049,17,276,2340,272,32,257,33,1,261]

theorem envBound36819 : H12AffineFastState.Bounded env36819 := by
  intro p hp
  have h : env36819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36818_36819 : H12AffineEnvironment.transform 8 260 env36818 = env36819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env36818 == env36819) = true)

theorem identity36819 : scanCanonicalize (H12AffineFastState.compose env36819 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound36819 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36820 : List Nat := [2,4,8,16,32,16,8,256,260,20,49,277,269,1,0,263,16,277,21,1,261,33,17,2,269,16,48,17,276,277,272,32,257,33,1,261]

theorem envBound36820 : H12AffineFastState.Bounded env36820 := by
  intro p hp
  have h : env36820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36819_36820 : H12AffineEnvironment.transform 10 49 env36819 = env36820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env36819 == env36820) = true)

theorem identity36820 : scanCanonicalize (H12AffineFastState.compose env36820 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36820 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36821 : List Nat := [2,4,8,16,16,16,8,256,260,20,1,277,269,1,0,263,16,277,21,1,261,17,17,2,269,16,0,17,276,277,272,16,257,17,1,261]

theorem envBound36821 : H12AffineFastState.Bounded env36821 := by
  intro p hp
  have h : env36821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36820_36821 : H12AffineEnvironment.transform 4 16 env36820 = env36821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36820 == env36821) = true)

theorem identity36821 : scanCanonicalize (H12AffineFastState.compose env36821 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36821 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env36822 : List Nat := [2,4,8,16,16,16,8,5,1,20,1,16,8,1,0,2,16,16,21,1,0,17,17,2,8,16,0,17,17,16,21,16,4,17,1,0]

theorem envBound36822 : H12AffineFastState.Bounded env36822 := by
  intro p hp
  have h : env36822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36821_36822 : H12AffineEnvironment.transform 7 5 env36821 = env36822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36821 == env36822) = true)

def env36823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144596,242969,8328,64,43357,139733,160197,324820,1501,272392,257,21793,46213,74250]

theorem envBound36823 : H12AffineFastState.Bounded env36823 := by
  intro p hp
  have h : env36823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36759_36823 : H12AffineEnvironment.transform 20 4161 env36759 = env36823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36759 == env36823) = true)

theorem identity36823 : scanCanonicalize (H12AffineFastState.compose env36823 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound36823 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272512,62661,95496,8328,64,43357,57796,45524,324820,1501,272392,257,21793,46213,74250]

theorem envBound36824 : H12AffineFastState.Bounded env36824 := by
  intro p hp
  have h : env36824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36823_36824 : H12AffineEnvironment.transform 16 49169 env36823 = env36824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env36823 == env36824) = true)

theorem identity36824 : scanCanonicalize (H12AffineFastState.compose env36824 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36824 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,4161,272512,62661,21763,8328,64,43357,57796,45524,324820,1501,272392,257,21793,46213,513]

theorem envBound36825 : H12AffineFastState.Bounded env36825 := by
  intro p hp
  have h : env36825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36824_36825 : H12AffineEnvironment.transform 15 8203 env36824 = env36825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36824 == env36825) = true)

theorem identity36825 : scanCanonicalize (H12AffineFastState.compose env36825 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound36825 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,56573,1025,32769,4161,62589,62661,21763,8328,64,43357,57796,45524,10281,1501,62709,257,21793,46213,513]

theorem envBound36826 : H12AffineFastState.Bounded env36826 := by
  intro p hp
  have h : env36826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36825_36826 : H12AffineEnvironment.transform 17 56573 env36825 = env36826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env36825 == env36826) = true)

theorem identity36826 : scanCanonicalize (H12AffineFastState.compose env36826 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound36826 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env36827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,13341,10481,1025,29709,4161,113,201,21763,8328,64,23889,5576,17880,10281,1501,249,257,21793,16521,513]

theorem envBound36827 : H12AffineFastState.Bounded env36827 := by
  intro p hp
  have h : env36827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36826_36827 : H12AffineEnvironment.transform 14 29708 env36826 = env36827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env36826 == env36827) = true)

theorem identity36827 : scanCanonicalize (H12AffineFastState.compose env36827 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36827 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env36828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,8203,13341,10361,1025,29709,4161,113,65,21763,8192,64,23889,5440,17744,10281,1365,113,257,21793,16385,513]

theorem envBound36828 : H12AffineFastState.Bounded env36828 := by
  intro p hp
  have h : env36828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36827_36828 : H12AffineEnvironment.transform 6 8 env36827 = env36828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36827 == env36828) = true)

theorem identity36828 : scanCanonicalize (H12AffineFastState.compose env36828 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36828 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36829 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,13341,10281,1025,29709,4113,33,17,21763,8192,16,23809,5392,17664,10281,1285,33,257,21793,16385,513]

theorem envBound36829 : H12AffineFastState.Bounded env36829 := by
  intro p hp
  have h : env36829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36828_36829 : H12AffineEnvironment.transform 5 16 env36828 = env36829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36828 == env36829) = true)

theorem identity36829 : scanCanonicalize (H12AffineFastState.compose env36829 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound36829 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36830 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,0,8203,13341,10281,1025,1,4113,33,17,8463,8192,16,10509,5392,12556,10281,1285,33,257,8493,13325,513]

theorem envBound36830 : H12AffineFastState.Bounded env36830 := by
  intro p hp
  have h : env36830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36829_36830 : H12AffineEnvironment.transform 13 13324 env36829 = env36830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env36829 == env36830) = true)

theorem identity36830 : scanCanonicalize (H12AffineFastState.compose env36830 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36830 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36831 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8192,13324,0,8203,13341,10281,1025,1,4113,33,17,8202,8192,16,10248,5141,12297,10281,1024,33,4,8232,13325,513]

theorem envBound36831 : H12AffineFastState.Bounded env36831 := by
  intro p hp
  have h : env36831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36830_36831 : H12AffineEnvironment.transform 7 5 env36830 = env36831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36830 == env36831) = true)

theorem identity36831 : scanCanonicalize (H12AffineFastState.compose env36831 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound36831 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36832 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8,5124,0,3,5141,2081,1025,1,4113,33,17,2,8,16,2048,5141,4097,2081,1024,33,4,32,5125,513]

theorem envBound36832 : H12AffineFastState.Bounded env36832 := by
  intro p hp
  have h : env36832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36831_36832 : H12AffineEnvironment.transform 12 8 env36831 = env36832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env36831 == env36832) = true)

theorem identity36832 : scanCanonicalize (H12AffineFastState.compose env36832 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36833 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5124,0,3,5141,2048,1025,1,4113,0,17,2,8,16,2048,5141,4097,2048,1024,0,4,1,5125,513]

theorem envBound36833 : H12AffineFastState.Bounded env36833 := by
  intro p hp
  have h : env36833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36832_36833 : H12AffineEnvironment.transform 4 1 env36832 = env36833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36832 == env36833) = true)

theorem identity36833 : scanCanonicalize (H12AffineFastState.compose env36833 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound36833 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36834 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,4096,8,5124,0,3,5141,522,1025,1,4113,0,17,2,8,16,522,5141,4097,522,1024,0,4,1,5125,513]

theorem envBound36834 : H12AffineFastState.Bounded env36834 := by
  intro p hp
  have h : env36834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36833_36834 : H12AffineEnvironment.transform 10 522 env36833 = env36834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env36833 == env36834) = true)

def env36835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound36835 : H12AffineFastState.Bounded env36835 := by
  intro p hp
  have h : env36835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36383_36835 : H12AffineEnvironment.transform 26 30393345 env36383 = env36835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env36383 == env36835) = true)

def env36836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound36836 : H12AffineFastState.Bounded env36836 := by
  intro p hp
  have h : env36836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36835_36836 : H12AffineEnvironment.transform 18 1024 env36835 = env36836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env36835 == env36836) = true)

theorem identity36836 : scanCanonicalize (H12AffineFastState.compose env36836 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36836 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,8388608,16777216,8328,64,29843924,18949465,10507600,8806869,25241029,23160256,256,27354488,27337993,25166355]

theorem envBound36837 : H12AffineFastState.Bounded env36837 := by
  intro p hp
  have h : env36837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36836_36837 : H12AffineEnvironment.transform 14 8661 env36836 = env36837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36836 == env36837) = true)

def env36838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147456,16777216,8328,64,21307860,18949465,2233680,270805,16999877,23160256,256,19080568,19096841,16925203]

theorem envBound36838 : H12AffineFastState.Bounded env36838 := by
  intro p hp
  have h : env36838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36837_36838 : H12AffineEnvironment.transform 22 147456 env36837 = env36838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env36837 == env36838) = true)

theorem identity36838 : scanCanonicalize (H12AffineFastState.compose env36838 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147474) := by decide +kernel

theorem selectedBound36838 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147456,147474,8328,64,4678086,2319691,2233680,270805,75223,6497746,256,2188650,2172187,513]

theorem envBound36839 : H12AffineFastState.Bounded env36839 := by
  intro p hp
  have h : env36839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36838_36839 : H12AffineEnvironment.transform 23 147474 env36838 = env36839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147474 env36838 == env36839) = true)

def env36840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1024,8660,2097152,4194304,147456,147474,8328,64,4409702,2319691,2233680,2421,75223,6497746,256,2188650,2172187,513]

theorem envBound36840 : H12AffineFastState.Bounded env36840 := by
  intro p hp
  have h : env36840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36840 : H12AffineEnvironment.transform 17 10400 env36839 = env36840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36839 == env36840) = true)

theorem identity36840 : scanCanonicalize (H12AffineFastState.compose env36840 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound36840 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16536,10400,1024,8660,2097152,4194304,152,138,8328,64,4262398,2172371,2119112,2421,75223,6382922,256,2188650,2172187,513]

theorem envBound36841 : H12AffineFastState.Bounded env36841 := by
  intro p hp
  have h : env36841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36840_36841 : H12AffineEnvironment.transform 16 16536 env36840 = env36841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env36840 == env36841) = true)

theorem identity36841 : scanCanonicalize (H12AffineFastState.compose env36841 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound36841 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,16536,10400,1024,8660,2097152,4194304,152,138,8328,64,4204925,2098512,2119112,2421,1364,6309321,256,2115049,2098584,513]

theorem envBound36842 : H12AffineFastState.Bounded env36842 := by
  intro p hp
  have h : env36842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36841_36842 : H12AffineEnvironment.transform 15 8323 env36841 = env36842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env36841 == env36842) = true)

theorem identity36842 : scanCanonicalize (H12AffineFastState.compose env36842 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 5593) := by decide +kernel

theorem selectedBound36842 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env36843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,16536,10400,1024,8660,5593,4194304,152,138,8328,64,4204925,4233,16401,2421,1364,4214800,256,20528,4161,513]

theorem envBound36843 : H12AffineFastState.Bounded env36843 := by
  intro p hp
  have h : env36843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36842_36843 : H12AffineEnvironment.transform 20 5593 env36842 = env36843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5593 env36842 == env36843) = true)

theorem identity36843 : scanCanonicalize (H12AffineFastState.compose env36843 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound36843 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env36844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8661,8323,4232,10400,1024,8660,5593,4194304,152,138,8328,64,4204925,4233,4097,2421,1364,4194304,256,32,4161,513]

theorem envBound36844 : H12AffineFastState.Bounded env36844 := by
  intro p hp
  have h : env36844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36843_36844 : H12AffineEnvironment.transform 13 4112 env36843 = env36844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env36843 == env36844) = true)

theorem identity36844 : scanCanonicalize (H12AffineFastState.compose env36844 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36844 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4112,8581,8323,4232,10400,1024,8580,5513,4194304,152,138,8328,16,4204845,4233,4097,2341,1284,4194304,256,32,4113,513]

theorem envBound36845 : H12AffineFastState.Bounded env36845 := by
  intro p hp
  have h : env36845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36844_36845 : H12AffineEnvironment.transform 5 16 env36844 = env36845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36844 == env36845) = true)

theorem identity36845 : scanCanonicalize (H12AffineFastState.compose env36845 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound36845 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env36846 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,2048,8581,8323,2200,10400,1024,8580,3481,4194304,152,138,8328,16,4204845,2201,2065,2341,1284,4194304,256,32,2049,513]

theorem envBound36846 : H12AffineFastState.Bounded env36846 := by
  intro p hp
  have h : env36846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36845_36846 : H12AffineEnvironment.transform 11 2064 env36845 = env36846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env36845 == env36846) = true)

theorem identity36846 : scanCanonicalize (H12AffineFastState.compose env36846 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 2080) := by decide +kernel

theorem selectedBound36846 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env36847 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,2048,8581,8323,2200,10400,1024,8580,3481,2080,152,138,8328,16,8461,2201,2065,2341,1284,2080,256,32,2049,513]

theorem envBound36847 : H12AffineFastState.Bounded env36847 := by
  intro p hp
  have h : env36847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36846_36847 : H12AffineEnvironment.transform 21 2080 env36846 = env36847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2080 env36846 == env36847) = true)

theorem identity36847 : scanCanonicalize (H12AffineFastState.compose env36847 (packedSelected [0,1,2,3,5,6,7,8,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound36847 : packedSelected [0,1,2,3,5,6,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env36848 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,3384,2048,3261,3515,2200,1432,1024,3260,3481,2080,152,138,3504,16,3125,2201,2065,2341,1284,2080,256,32,2049,513]

theorem envBound36848 : H12AffineFastState.Bounded env36848 := by
  intro p hp
  have h : env36848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36847_36848 : H12AffineEnvironment.transform 12 3384 env36847 = env36848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env36847 == env36848) = true)

theorem identity36848 : scanCanonicalize (H12AffineFastState.compose env36848 (packedSelected [2,4,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound36848 : packedSelected [2,4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env36849 : List Nat := [2,4,8,16,32,16,128,256,512,1024,293,309,1053,293,1432,1182,445,1432,1024,1433,1212,261,152,138,1173,16,1296,444,308,0,1284,261,256,32,292,513]

theorem envBound36849 : H12AffineFastState.Bounded env36849 := by
  intro p hp
  have h : env36849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36848_36849 : H12AffineEnvironment.transform 10 293 env36848 = env36849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env36848 == env36849) = true)

theorem identity36849 : scanCanonicalize (H12AffineFastState.compose env36849 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36849 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36850 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,309,1053,293,1297,1047,308,1297,1024,1296,1077,261,17,3,1052,16,1296,309,308,0,1284,261,256,32,292,513]

theorem envBound36850 : H12AffineFastState.Bounded env36850 := by
  intro p hp
  have h : env36850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36849_36850 : H12AffineEnvironment.transform 6 9 env36849 = env36850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36849 == env36850) = true)

theorem identity36850 : scanCanonicalize (H12AffineFastState.compose env36850 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36850 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36851 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1,17,1053,1,1077,1047,16,1077,1024,1076,1077,33,17,3,1052,16,1076,17,16,0,1056,33,36,32,0,513]

theorem envBound36851 : H12AffineFastState.Bounded env36851 := by
  intro p hp
  have h : env36851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36850_36851 : H12AffineEnvironment.transform 7 36 env36850 = env36851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36850 == env36851) = true)

theorem identity36851 : scanCanonicalize (H12AffineFastState.compose env36851 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36852 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,17,40,1,0,34,16,0,53,1,0,33,17,3,41,16,1,17,16,0,21,33,36,32,0,513]

theorem envBound36852 : H12AffineFastState.Bounded env36852 := by
  intro p hp
  have h : env36852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36851_36852 : H12AffineEnvironment.transform 9 53 env36851 = env36852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36851 == env36852) = true)

theorem identity36852 : scanCanonicalize (H12AffineFastState.compose env36852 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36853 : List Nat := [2,4,8,16,1,16,9,5,512,20,1,17,9,1,0,3,16,0,20,1,0,0,17,3,8,16,1,17,16,0,21,0,5,1,0,513]

theorem envBound36853 : H12AffineFastState.Bounded env36853 := by
  intro p hp
  have h : env36853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36852_36853 : H12AffineEnvironment.transform 4 1 env36852 = env36853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36852 == env36853) = true)

theorem identity36853 : scanCanonicalize (H12AffineFastState.compose env36853 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36854 : List Nat := [2,4,8,16,1,16,9,5,0,20,1,17,9,1,0,3,16,0,20,1,0,0,17,3,8,16,1,17,16,0,21,0,5,1,0,1]

theorem envBound36854 : H12AffineFastState.Bounded env36854 := by
  intro p hp
  have h : env36854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36853_36854 : H12AffineEnvironment.transform 8 0 env36853 = env36854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36853 == env36854) = true)

def env36855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1024,8660,2097152,4194304,147456,147474,8328,64,4409703,2319691,2233680,2420,75223,6497746,256,2188650,2172187,513]

theorem envBound36855 : H12AffineFastState.Bounded env36855 := by
  intro p hp
  have h : env36855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36855 : H12AffineEnvironment.transform 17 10401 env36839 = env36855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36839 == env36855) = true)

theorem identity36855 : scanCanonicalize (H12AffineFastState.compose env36855 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36855 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147474,8192,64,4409703,2319691,2233680,2420,75103,6497626,256,2188650,2172187,513]

theorem envBound36856 : H12AffineFastState.Bounded env36856 := by
  intro p hp
  have h : env36856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36855_36856 : H12AffineEnvironment.transform 6 8 env36855 = env36856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36855 == env36856) = true)

theorem identity36856 : scanCanonicalize (H12AffineFastState.compose env36856 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound36856 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env36857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,91466,4194304,147456,147474,8192,64,4409703,131073,225306,2420,75103,4341776,256,32,16465,513]

theorem envBound36857 : H12AffineFastState.Bounded env36857 := by
  intro p hp
  have h : env36857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36856_36857 : H12AffineEnvironment.transform 20 91466 env36856 = env36857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env36856 == env36857) = true)

theorem identity36857 : scanCanonicalize (H12AffineFastState.compose env36857 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound36857 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,91466,4194304,16,2,8192,64,4262263,16401,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound36858 : H12AffineFastState.Bounded env36858 := by
  intro p hp
  have h : env36858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36857_36858 : H12AffineEnvironment.transform 16 16400 env36857 = env36858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36857 == env36858) = true)

theorem identity36858 : scanCanonicalize (H12AffineFastState.compose env36858 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound36858 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,91466,73770,16,2,8192,64,10589,16401,77834,2420,75103,73770,256,32,16465,513]

theorem envBound36859 : H12AffineFastState.Bounded env36859 := by
  intro p hp
  have h : env36859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36858_36859 : H12AffineEnvironment.transform 21 73770 env36858 = env36859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env36858 == env36859) = true)

theorem identity36859 : scanCanonicalize (H12AffineFastState.compose env36859 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound36859 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8282,16400,10281,1024,8540,17680,112,16,2,8192,64,10589,16401,4176,2420,1285,112,256,32,16465,513]

theorem envBound36860 : H12AffineFastState.Bounded env36860 := by
  intro p hp
  have h : env36860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36859_36860 : H12AffineEnvironment.transform 15 8282 env36859 = env36860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env36859 == env36860) = true)

theorem identity36860 : scanCanonicalize (H12AffineFastState.compose env36860 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36860 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,263,16400,2420,1024,1,17680,112,16,2,349,64,2048,16401,4176,2420,1285,112,256,32,16465,513]

theorem envBound36861 : H12AffineFastState.Bounded env36861 := by
  intro p hp
  have h : env36861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36860_36861 : H12AffineEnvironment.transform 12 349 env36860 = env36861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36860 == env36861) = true)

theorem identity36861 : scanCanonicalize (H12AffineFastState.compose env36861 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36861 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,0,263,5220,2420,1024,1,4452,112,16,2,349,64,2048,5221,4176,2420,1285,112,256,32,5157,513]

theorem envBound36862 : H12AffineFastState.Bounded env36862 := by
  intro p hp
  have h : env36862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36861_36862 : H12AffineEnvironment.transform 13 5236 env36861 = env36862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36861 == env36862) = true)

theorem identity36862 : scanCanonicalize (H12AffineFastState.compose env36862 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36862 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36863 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,0,263,5173,2341,1024,1,4405,33,16,2,268,17,2048,5172,4097,2341,1285,33,256,32,5157,513]

theorem envBound36863 : H12AffineFastState.Bounded env36863 := by
  intro p hp
  have h : env36863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36862_36863 : H12AffineEnvironment.transform 5 17 env36862 = env36863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36862 == env36863) = true)

def env36864 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,268,2837,0,263,2821,2341,1024,1,3589,33,16,2,268,17,2048,2820,3889,2341,1285,33,256,32,2837,513]

theorem envBound36864 : H12AffineFastState.Bounded env36864 := by
  intro p hp
  have h : env36864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36863_36864 : H12AffineEnvironment.transform 11 3888 env36863 = env36864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env36863 == env36864) = true)

def env36865 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,268,1045,0,263,1029,1573,1024,1,261,33,16,2,268,17,1792,1028,49,1573,1285,33,256,32,1045,513]

theorem envBound36865 : H12AffineFastState.Bounded env36865 := by
  intro p hp
  have h : env36865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36864_36865 : H12AffineEnvironment.transform 10 1792 env36864 = env36865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env36864 == env36865) = true)

theorem identity36865 : scanCanonicalize (H12AffineFastState.compose env36865 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound36865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36866 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,48,268,560,0,263,544,0,549,1,261,33,16,2,268,17,293,545,49,0,800,33,256,32,560,513]

theorem envBound36866 : H12AffineFastState.Bounded env36866 := by
  intro p hp
  have h : env36866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36865_36866 : H12AffineEnvironment.transform 9 549 env36865 = env36866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env36865 == env36866) = true)

def env36867 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,268,32,0,263,48,0,53,1,261,33,16,2,268,17,293,49,49,0,304,33,256,32,32,17]

theorem envBound36867 : H12AffineFastState.Bounded env36867 := by
  intro p hp
  have h : env36867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36866_36867 : H12AffineEnvironment.transform 8 16 env36866 = env36867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36866 == env36867) = true)

theorem identity36867 : scanCanonicalize (H12AffineFastState.compose env36867 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36868 : List Nat := [2,4,8,16,32,17,8,4,16,53,33,48,8,32,0,3,48,0,53,1,1,33,16,2,8,17,33,49,49,0,52,33,4,32,32,17]

theorem envBound36868 : H12AffineFastState.Bounded env36868 := by
  intro p hp
  have h : env36868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36867_36868 : H12AffineEnvironment.transform 7 4 env36867 = env36868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36867 == env36868) = true)

def leafEnv36868 : List Nat := [2,4,8,16,32,17,8,4,16,53,33,48,8,32,0,3,48,0,53,1,1,33,16,2,52,8,1,17,33,49,49,0,52,33,4,32,4,3,32,17,1,1,0]

def active36868 : List Nat := [0,1,2,3,4]

def tree36868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36868 : H12WitnessSearch.Good tree36868 := H12GlobalWitnessIndex.good

theorem leafIdentity36868 : H12AffineFastState.composeSystem env36868 rootObs = leafEnv36868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36868 rootObs == leafEnv36868) = true)

theorem terminalChecked36868 : H12PackedTerminal.terminalCheckFast leafEnv36868 active36868 tree36868 = true := by decide +kernel

def env36869 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,48,268,33,0,263,49,0,52,1,261,33,16,2,268,17,293,48,49,0,305,33,256,32,33,16]

theorem envBound36869 : H12AffineFastState.Bounded env36869 := by
  intro p hp
  have h : env36869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36866_36869 : H12AffineEnvironment.transform 8 17 env36866 = env36869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36866 == env36869) = true)

theorem identity36869 : scanCanonicalize (H12AffineFastState.compose env36869 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36870 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,268,33,0,263,43,0,46,1,261,33,10,2,268,11,293,42,43,0,299,33,256,32,33,10]

theorem envBound36870 : H12AffineFastState.Bounded env36870 := by
  intro p hp
  have h : env36870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36869_36870 : H12AffineEnvironment.transform 3 10 env36869 = env36870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36869 == env36870) = true)

def leafEnv36870 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,268,33,0,263,43,0,46,1,261,33,10,2,299,268,1,11,293,42,43,0,299,33,256,32,4,263,33,10,1,261,0]

def active36870 : List Nat := [0,1,2,4,7]

def tree36870 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36870 : H12WitnessSearch.Good tree36870 := H12GlobalWitnessIndex.good

theorem leafIdentity36870 : H12AffineFastState.composeSystem env36870 rootObs = leafEnv36870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36870 rootObs == leafEnv36870) = true)

theorem terminalChecked36870 : H12PackedTerminal.terminalCheckFast leafEnv36870 active36870 tree36870 = true := by decide +kernel

def env36871 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,268,1044,0,263,1028,1572,1024,1,260,33,16,2,268,17,1793,1029,48,1572,1285,33,256,32,1044,513]

theorem envBound36871 : H12AffineFastState.Bounded env36871 := by
  intro p hp
  have h : env36871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36864_36871 : H12AffineEnvironment.transform 10 1793 env36864 = env36871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env36864 == env36871) = true)

theorem identity36871 : scanCanonicalize (H12AffineFastState.compose env36871 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound36871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36872 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1076,49,268,1044,0,263,1028,1297,1024,1,260,33,16,2,268,17,1076,1029,48,1297,1285,33,256,32,1044,308]

theorem envBound36872 : H12AffineFastState.Bounded env36872 := by
  intro p hp
  have h : env36872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36871_36872 : H12AffineEnvironment.transform 8 309 env36871 = env36872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env36871 == env36872) = true)

def env36873 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,268,32,0,263,48,293,52,1,260,33,16,2,268,17,0,49,48,293,305,33,256,32,32,308]

theorem envBound36873 : H12AffineFastState.Bounded env36873 := by
  intro p hp
  have h : env36873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36872_36873 : H12AffineEnvironment.transform 9 52 env36872 = env36873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36872 == env36873) = true)

theorem identity36873 : scanCanonicalize (H12AffineFastState.compose env36873 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36874 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,268,32,0,263,43,293,47,1,260,33,11,2,268,10,0,42,43,293,298,33,256,32,32,303]

theorem envBound36874 : H12AffineFastState.Bounded env36874 := by
  intro p hp
  have h : env36874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36873_36874 : H12AffineEnvironment.transform 3 11 env36873 = env36874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36873 == env36874) = true)

def leafEnv36874 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,268,32,0,263,43,293,47,1,260,33,11,2,298,268,1,10,0,42,43,293,298,33,256,32,4,263,32,303,1,260,0]

def active36874 : List Nat := [0,1,2,4,7]

def tree36874 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36874 : H12WitnessSearch.Good tree36874 := H12GlobalWitnessIndex.good

theorem leafIdentity36874 : H12AffineFastState.composeSystem env36874 rootObs = leafEnv36874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36874 rootObs == leafEnv36874) = true)

theorem terminalChecked36874 : H12PackedTerminal.terminalCheckFast leafEnv36874 active36874 tree36874 = true := by decide +kernel

def env36875 : List Nat := [2,4,8,16,32,17,8,256,309,53,1,49,268,33,0,263,49,292,53,1,260,33,16,2,268,17,1,48,48,292,304,33,256,32,33,308]

theorem envBound36875 : H12AffineFastState.Bounded env36875 := by
  intro p hp
  have h : env36875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36872_36875 : H12AffineEnvironment.transform 9 53 env36872 = env36875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36872 == env36875) = true)

theorem identity36875 : scanCanonicalize (H12AffineFastState.compose env36875 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36876 : List Nat := [2,4,8,16,1,17,8,256,276,20,1,16,268,0,0,263,16,261,20,1,260,0,16,2,268,17,1,17,17,261,273,0,256,1,0,277]

theorem envBound36876 : H12AffineFastState.Bounded env36876 := by
  intro p hp
  have h : env36876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36875_36876 : H12AffineEnvironment.transform 4 1 env36875 = env36876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36875 == env36876) = true)

def leafEnv36876 : List Nat := [2,4,8,16,1,17,8,256,276,20,1,16,268,0,0,263,16,261,20,1,260,0,16,2,273,268,1,17,1,17,17,261,273,0,256,1,4,263,0,277,1,260,0]

def active36876 : List Nat := [0,1,2,3,7]

def tree36876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36876 : H12WitnessSearch.Good tree36876 := H12GlobalWitnessIndex.good

theorem leafIdentity36876 : H12AffineFastState.composeSystem env36876 rootObs = leafEnv36876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36876 rootObs == leafEnv36876) = true)

theorem terminalChecked36876 : H12PackedTerminal.terminalCheckFast leafEnv36876 active36876 tree36876 = true := by decide +kernel

def env36877 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2836,0,263,2820,2341,1024,1,3588,33,16,2,268,17,2048,2821,3888,2341,1285,33,256,32,2836,513]

theorem envBound36877 : H12AffineFastState.Bounded env36877 := by
  intro p hp
  have h : env36877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36863_36877 : H12AffineEnvironment.transform 11 3889 env36863 = env36877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env36863 == env36877) = true)

def env36878 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1044,0,263,1028,1573,1024,1,260,33,16,2,268,17,1792,1029,48,1573,1285,33,256,32,1044,513]

theorem envBound36878 : H12AffineFastState.Bounded env36878 := by
  intro p hp
  have h : env36878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36877_36878 : H12AffineEnvironment.transform 10 1792 env36877 = env36878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env36877 == env36878) = true)

theorem identity36878 : scanCanonicalize (H12AffineFastState.compose env36878 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36879 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1297,49,268,1044,0,263,1028,1076,1024,1,260,33,16,2,268,17,1297,1029,48,1076,1285,33,256,32,1044,16]

theorem envBound36879 : H12AffineFastState.Bounded env36879 := by
  intro p hp
  have h : env36879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36878_36879 : H12AffineEnvironment.transform 8 17 env36878 = env36879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36878 == env36879) = true)

def env36880 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,268,32,0,263,48,0,52,1,260,33,16,2,268,17,293,49,48,0,305,33,256,32,32,16]

theorem envBound36880 : H12AffineFastState.Bounded env36880 := by
  intro p hp
  have h : env36880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36879_36880 : H12AffineEnvironment.transform 9 52 env36879 = env36880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36879 == env36880) = true)

theorem identity36880 : scanCanonicalize (H12AffineFastState.compose env36880 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36881 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,268,32,0,263,42,0,46,1,260,33,10,2,268,11,293,43,42,0,299,33,256,32,32,10]

theorem envBound36881 : H12AffineFastState.Bounded env36881 := by
  intro p hp
  have h : env36881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36880_36881 : H12AffineEnvironment.transform 3 10 env36880 = env36881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36880 == env36881) = true)

def leafEnv36881 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,268,32,0,263,42,0,46,1,260,33,10,2,299,268,1,11,293,43,42,0,299,33,256,32,4,263,32,10,1,260,0]

def active36881 : List Nat := [0,1,2,4,7]

def tree36881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36881 : H12WitnessSearch.Good tree36881 := H12GlobalWitnessIndex.good

theorem leafIdentity36881 : H12AffineFastState.composeSystem env36881 rootObs = leafEnv36881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36881 rootObs == leafEnv36881) = true)

theorem terminalChecked36881 : H12PackedTerminal.terminalCheckFast leafEnv36881 active36881 tree36881 = true := by decide +kernel

def env36882 : List Nat := [2,4,8,16,32,17,8,256,17,53,292,49,268,33,0,263,49,1,53,1,260,33,16,2,268,17,292,48,48,1,304,33,256,32,33,16]

theorem envBound36882 : H12AffineFastState.Bounded env36882 := by
  intro p hp
  have h : env36882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36879_36882 : H12AffineEnvironment.transform 9 53 env36879 = env36882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36879 == env36882) = true)

theorem identity36882 : scanCanonicalize (H12AffineFastState.compose env36882 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36883 : List Nat := [2,4,8,16,32,17,8,4,17,53,32,49,8,33,0,3,49,1,53,1,0,33,16,2,8,17,32,48,48,1,52,33,4,32,33,16]

theorem envBound36883 : H12AffineFastState.Bounded env36883 := by
  intro p hp
  have h : env36883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36882_36883 : H12AffineEnvironment.transform 7 4 env36882 = env36883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36882 == env36883) = true)

def leafEnv36883 : List Nat := [2,4,8,16,32,17,8,4,17,53,32,49,8,33,0,3,49,1,53,1,0,33,16,2,52,8,1,17,32,48,48,1,52,33,4,32,4,3,33,16,1,0,0]

def active36883 : List Nat := [0,1,2,3,4]

def tree36883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36883 : H12WitnessSearch.Good tree36883 := H12GlobalWitnessIndex.good

theorem leafIdentity36883 : H12AffineFastState.composeSystem env36883 rootObs = leafEnv36883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36883 rootObs == leafEnv36883) = true)

theorem terminalChecked36883 : H12PackedTerminal.terminalCheckFast leafEnv36883 active36883 tree36883 = true := by decide +kernel

def env36884 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1045,0,263,1029,1572,1024,1,261,33,16,2,268,17,1793,1028,49,1572,1285,33,256,32,1045,513]

theorem envBound36884 : H12AffineFastState.Bounded env36884 := by
  intro p hp
  have h : env36884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36877_36884 : H12AffineEnvironment.transform 10 1793 env36877 = env36884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env36877 == env36884) = true)

theorem identity36884 : scanCanonicalize (H12AffineFastState.compose env36884 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound36884 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36885 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,48,268,788,0,263,772,293,769,1,261,33,16,2,268,17,0,773,49,293,516,33,256,32,788,513]

theorem envBound36885 : H12AffineFastState.Bounded env36885 := by
  intro p hp
  have h : env36885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36884_36885 : H12AffineEnvironment.transform 9 769 env36884 = env36885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env36884 == env36885) = true)

def env36886 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,268,32,0,263,48,293,53,1,261,33,16,2,268,17,0,49,49,293,304,33,256,32,32,309]

theorem envBound36886 : H12AffineFastState.Bounded env36886 := by
  intro p hp
  have h : env36886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36885_36886 : H12AffineEnvironment.transform 8 308 env36885 = env36886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env36885 == env36886) = true)

theorem identity36886 : scanCanonicalize (H12AffineFastState.compose env36886 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36886 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36887 : List Nat := [2,4,8,16,1,17,8,256,277,20,0,17,268,1,0,263,17,260,20,1,261,0,16,2,268,17,0,16,16,260,273,0,256,1,1,276]

theorem envBound36887 : H12AffineFastState.Bounded env36887 := by
  intro p hp
  have h : env36887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36886_36887 : H12AffineEnvironment.transform 4 1 env36886 = env36887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36886 == env36887) = true)

def leafEnv36887 : List Nat := [2,4,8,16,1,17,8,256,277,20,0,17,268,1,0,263,17,260,20,1,261,0,16,2,273,268,1,17,0,16,16,260,273,0,256,1,4,263,1,276,1,261,0]

def active36887 : List Nat := [0,1,2,3,7]

def tree36887 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36887 : H12WitnessSearch.Good tree36887 := H12GlobalWitnessIndex.good

theorem leafIdentity36887 : H12AffineFastState.composeSystem env36887 rootObs = leafEnv36887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36887 rootObs == leafEnv36887) = true)

theorem terminalChecked36887 : H12PackedTerminal.terminalCheckFast leafEnv36887 active36887 tree36887 = true := by decide +kernel

def env36888 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,48,268,33,0,263,49,293,52,1,261,33,16,2,268,17,0,48,49,293,305,33,256,32,33,308]

theorem envBound36888 : H12AffineFastState.Bounded env36888 := by
  intro p hp
  have h : env36888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36885_36888 : H12AffineEnvironment.transform 8 309 env36885 = env36888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env36885 == env36888) = true)

theorem identity36888 : scanCanonicalize (H12AffineFastState.compose env36888 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36889 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,268,33,0,263,42,293,47,1,261,33,11,2,268,10,0,43,42,293,298,33,256,32,33,303]

theorem envBound36889 : H12AffineFastState.Bounded env36889 := by
  intro p hp
  have h : env36889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36888_36889 : H12AffineEnvironment.transform 3 11 env36888 = env36889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36888 == env36889) = true)

def leafEnv36889 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,268,33,0,263,42,293,47,1,261,33,11,2,298,268,1,10,0,43,42,293,298,33,256,32,4,263,33,303,1,261,0]

def active36889 : List Nat := [0,1,2,4,7]

def tree36889 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36889 : H12WitnessSearch.Good tree36889 := H12GlobalWitnessIndex.good

theorem leafIdentity36889 : H12AffineFastState.composeSystem env36889 rootObs = leafEnv36889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36889 rootObs == leafEnv36889) = true)

theorem terminalChecked36889 : H12PackedTerminal.terminalCheckFast leafEnv36889 active36889 tree36889 = true := by decide +kernel

def env36890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,262144,1024,8660,2097152,4194304,147457,16777216,8328,64,21307861,18949465,2233681,270804,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound36890 : H12AffineFastState.Bounded env36890 := by
  intro p hp
  have h : env36890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36837_36890 : H12AffineEnvironment.transform 22 147457 env36837 = env36890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env36837 == env36890) = true)

def env36891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10400,1024,8660,2097152,4194304,147457,16777216,8328,64,21039477,18949465,2233681,2420,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound36891 : H12AffineFastState.Bounded env36891 := by
  intro p hp
  have h : env36891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36890_36891 : H12AffineEnvironment.transform 17 10400 env36890 = env36891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36890 == env36891) = true)

theorem identity36891 : scanCanonicalize (H12AffineFastState.compose env36891 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound36891 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1024,8660,2097152,4194304,152,16777216,8328,64,21039477,18949465,2119112,2420,16852317,23160256,256,18965984,18949521,16777867]

theorem envBound36892 : H12AffineFastState.Bounded env36892 := by
  intro p hp
  have h : env36892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36891_36892 : H12AffineEnvironment.transform 16 16537 env36891 = env36892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env36891 == env36892) = true)

theorem identity36892 : scanCanonicalize (H12AffineFastState.compose env36892 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 73736) := by decide +kernel

theorem selectedBound36892 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env36893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1024,8660,2097152,4194304,152,73736,8328,64,4204925,2098513,2119112,2420,1365,6309320,256,2115048,2098585,74371]

theorem envBound36893 : H12AffineFastState.Bounded env36893 := by
  intro p hp
  have h : env36893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36892_36893 : H12AffineEnvironment.transform 23 73736 env36892 = env36893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73736 env36892 == env36893) = true)

theorem identity36893 : scanCanonicalize (H12AffineFastState.compose env36893 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound36893 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env36894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1024,8660,2097152,73890,152,73736,8328,64,68063,2098513,2119112,2420,1365,2188650,256,2115048,2098585,74371]

theorem envBound36894 : H12AffineFastState.Bounded env36894 := by
  intro p hp
  have h : env36894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36893_36894 : H12AffineEnvironment.transform 21 73890 env36893 = env36894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env36893 == env36894) = true)

theorem identity36894 : scanCanonicalize (H12AffineFastState.compose env36894 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 83015) := by decide +kernel

theorem selectedBound36894 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env36895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10400,1024,8660,83015,73890,152,73736,8328,64,68063,82198,70031,2420,1365,8493,256,65967,82398,74371]

theorem envBound36895 : H12AffineFastState.Bounded env36895 := by
  intro p hp
  have h : env36895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36894_36895 : H12AffineEnvironment.transform 20 83015 env36894 = env36895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 83015 env36894 == env36895) = true)

theorem identity36895 : scanCanonicalize (H12AffineFastState.compose env36895 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13808) := by decide +kernel

theorem selectedBound36895 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,19,20,23] rootPS < 2^1333 := by decide +kernel

def env36896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,8661,65536,13673,10400,1024,8660,78263,73890,152,73736,8328,64,68063,79078,70031,2420,1365,8493,256,65967,78894,74371]

theorem envBound36896 : H12AffineFastState.Bounded env36896 := by
  intro p hp
  have h : env36896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36895_36896 : H12AffineEnvironment.transform 13 13808 env36895 = env36896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13808 env36895 == env36896) = true)

theorem identity36896 : scanCanonicalize (H12AffineFastState.compose env36896 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound36896 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env36897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13808,8661,8322,13673,10400,1024,8660,4405,32,152,138,8328,64,10589,5220,12557,2420,1365,8493,256,8493,5292,513]

theorem envBound36897 : H12AffineFastState.Bounded env36897 := by
  intro p hp
  have h : env36897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36896_36897 : H12AffineEnvironment.transform 15 8322 env36896 = env36897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env36896 == env36897) = true)

theorem identity36897 : scanCanonicalize (H12AffineFastState.compose env36897 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound36897 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36898 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13608,8461,8282,13673,10360,1024,8460,4405,32,64,82,8272,64,10589,5220,12557,2420,1365,8493,256,8493,5236,513]

theorem envBound36898 : H12AffineFastState.Bounded env36898 := by
  intro p hp
  have h : env36898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36897_36898 : H12AffineEnvironment.transform 6 88 env36897 = env36898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36897 == env36898) = true)

theorem identity36898 : scanCanonicalize (H12AffineFastState.compose env36898 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1809) := by decide +kernel

theorem selectedBound36898 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36899 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1809,8192,8761,8461,8282,8824,10360,1024,8460,1572,32,64,82,8272,64,10589,885,9756,2420,1365,8493,256,8493,869,513]

theorem envBound36899 : H12AffineFastState.Bounded env36899 := by
  intro p hp
  have h : env36899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36898_36899 : H12AffineEnvironment.transform 11 1809 env36898 = env36899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1809 env36898 == env36899) = true)

theorem identity36899 : scanCanonicalize (H12AffineFastState.compose env36899 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound36899 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env36900 : List Nat := [2,4,8,16,32,64,88,256,512,1024,528,1809,8192,8761,8461,8282,8824,8808,1024,8460,1572,32,64,82,8272,64,9037,885,9756,868,1365,8493,256,8493,869,513]

theorem envBound36900 : H12AffineFastState.Bounded env36900 := by
  intro p hp
  have h : env36900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36899_36900 : H12AffineEnvironment.transform 10 528 env36899 = env36900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env36899 == env36900) = true)

theorem identity36900 : scanCanonicalize (H12AffineFastState.compose env36900 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 569) := by decide +kernel

theorem selectedBound36900 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env36901 : List Nat := [2,4,8,16,32,64,88,256,512,1024,528,1809,569,0,820,611,65,81,1024,821,1572,32,64,82,617,64,372,885,1061,868,1365,788,256,788,869,513]

theorem envBound36901 : H12AffineFastState.Bounded env36901 := by
  intro p hp
  have h : env36901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36900_36901 : H12AffineEnvironment.transform 12 569 env36900 = env36901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 569 env36900 == env36901) = true)

theorem identity36901 : scanCanonicalize (H12AffineFastState.compose env36901 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound36901 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env36902 : List Nat := [2,4,8,16,32,64,88,256,512,612,528,373,569,0,820,611,65,81,612,821,64,32,64,82,617,64,372,885,577,868,817,788,256,788,869,513]

theorem envBound36902 : H12AffineFastState.Bounded env36902 := by
  intro p hp
  have h : env36902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36901_36902 : H12AffineEnvironment.transform 9 612 env36901 = env36902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env36901 == env36902) = true)

theorem identity36902 : scanCanonicalize (H12AffineFastState.compose env36902 (packedSelected [1,2,3,6,14] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound36902 : packedSelected [1,2,3,6,14] rootPS < 2^1333 := by decide +kernel

def env36903 : List Nat := [2,4,8,16,32,64,88,256,81,53,65,373,104,0,357,50,65,81,53,356,64,32,64,82,56,64,372,292,16,309,352,325,256,325,308,80]

theorem envBound36903 : H12AffineFastState.Bounded env36903 := by
  intro p hp
  have h : env36903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36902_36903 : H12AffineEnvironment.transform 8 81 env36902 = env36903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env36902 == env36903) = true)

theorem identity36903 : scanCanonicalize (H12AffineFastState.compose env36903 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36903 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36904 : List Nat := [2,4,8,0,32,64,72,256,65,37,65,357,104,0,357,34,65,65,37,356,64,32,64,66,40,64,356,292,0,293,352,325,256,325,292,64]

theorem envBound36904 : H12AffineFastState.Bounded env36904 := by
  intro p hp
  have h : env36904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36903_36904 : H12AffineEnvironment.transform 3 0 env36903 = env36904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36903 == env36904) = true)

theorem identity36904 : scanCanonicalize (H12AffineFastState.compose env36904 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound36904 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36905 : List Nat := [2,4,8,0,32,64,72,100,65,37,65,1,104,0,1,34,65,65,37,0,64,32,64,66,40,64,0,64,0,65,4,33,100,33,64,64]

theorem envBound36905 : H12AffineFastState.Bounded env36905 := by
  intro p hp
  have h : env36905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36904_36905 : H12AffineEnvironment.transform 7 100 env36904 = env36905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env36904 == env36905) = true)

theorem identity36905 : scanCanonicalize (H12AffineFastState.compose env36905 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36906 : List Nat := [2,4,8,0,0,64,72,68,65,5,65,1,72,0,1,2,65,65,5,0,64,0,64,66,8,64,0,64,0,65,4,1,68,1,64,64]

theorem envBound36906 : H12AffineFastState.Bounded env36906 := by
  intro p hp
  have h : env36906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36905_36906 : H12AffineEnvironment.transform 4 0 env36905 = env36906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36905 == env36906) = true)

theorem identity36906 : scanCanonicalize (H12AffineFastState.compose env36906 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36907 : List Nat := [2,4,8,0,0,1,9,5,0,5,0,1,9,0,1,2,0,0,5,0,1,0,1,3,8,1,0,1,0,0,4,1,5,1,1,1]

theorem envBound36907 : H12AffineFastState.Bounded env36907 := by
  intro p hp
  have h : env36907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36906_36907 : H12AffineEnvironment.transform 5 1 env36906 = env36907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36906 == env36907) = true)

def env36908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1024,8660,2097152,4194304,147457,16777216,8328,64,21039476,18949465,2233681,2421,16999876,23160256,256,19080569,19096840,16925202]

theorem envBound36908 : H12AffineFastState.Bounded env36908 := by
  intro p hp
  have h : env36908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36890_36908 : H12AffineEnvironment.transform 17 10401 env36890 = env36908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36890 == env36908) = true)

theorem identity36908 : scanCanonicalize (H12AffineFastState.compose env36908 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36908 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,16777216,8192,64,21039476,18949465,2233681,2421,16999756,23160136,256,19080569,19096840,16925202]

theorem envBound36909 : H12AffineFastState.Bounded env36909 := by
  intro p hp
  have h : env36909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36908_36909 : H12AffineEnvironment.transform 6 8 env36908 = env36909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36908 == env36909) = true)

def env36910 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,4096,8192,16384,8541,65536,131072,10281,68,8540,2097152,4194304,147457,16777216,8192,64,21039476,18948381,2232597,2421,16998664,23159052,256,19079485,19095884,16925202]

theorem envBound36910 : H12AffineFastState.Bounded env36910 := by
  intro p hp
  have h : env36910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36909_36910 : H12AffineEnvironment.transform 9 68 env36909 = env36910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env36909 == env36910) = true)

def env36911 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,4194304,147457,16777216,8192,16,21039396,18948381,2232597,2341,16998664,23159052,256,19079485,19095836,16925202]

theorem envBound36911 : H12AffineFastState.Bounded env36911 := by
  intro p hp
  have h : env36911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36910_36911 : H12AffineEnvironment.transform 5 16 env36910 = env36911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36910 == env36911) = true)

theorem identity36911 : scanCanonicalize (H12AffineFastState.compose env36911 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(23+1) ^^^ 4341810) := by decide +kernel

theorem selectedBound36911 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36912 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,4194304,147457,4341810,8192,16,215318,6512943,2232597,2341,4268346,2302270,256,6381839,6365486,4194848]

theorem envBound36912 : H12AffineFastState.Bounded env36912 := by
  intro p hp
  have h : env36912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36911_36912 : H12AffineEnvironment.transform 23 4341810 env36911 = env36912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4341810 env36911 == env36912) = true)

theorem identity36912 : scanCanonicalize (H12AffineFastState.compose env36912 (packedSelected [1,2,3,5,6,7,11,14,16,18,26,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 2113829) := by decide +kernel

theorem selectedBound36912 : packedSelected [1,2,3,5,6,7,11,14,16,18,26,27,28] rootPS < 2^1333 := by decide +kernel

def env36913 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,2097152,2113829,147457,2228503,8192,16,215318,204810,2232597,2341,2187295,2302270,256,73770,90123,2114309]

theorem envBound36913 : H12AffineFastState.Bounded env36913 := by
  intro p hp
  have h : env36913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36912_36913 : H12AffineEnvironment.transform 21 2113829 env36912 = env36913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113829 env36912 == env36913) = true)

theorem identity36913 : scanCanonicalize (H12AffineFastState.compose env36913 (packedSelected [0,1,2,5,6,7,8,9,11,14,16,18,22,24] rootPS)) = affineNative (2^(20+1) ^^^ 16644) := by decide +kernel

theorem selectedBound36913 : packedSelected [0,1,2,5,6,7,8,9,11,14,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env36914 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,8192,16384,8461,65536,131072,10281,20,8460,16644,33,147457,147475,8192,16,215318,204810,151569,2341,74011,221242,256,73770,90123,513]

theorem envBound36914 : H12AffineFastState.Bounded env36914 := by
  intro p hp
  have h : env36914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36913_36914 : H12AffineEnvironment.transform 20 16644 env36913 = env36914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16644 env36913 == env36914) = true)

theorem identity36914 : scanCanonicalize (H12AffineFastState.compose env36914 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36914 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36915 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,269,16384,0,65536,131072,2340,20,1,16644,33,147457,147475,269,16,215318,196871,151569,2341,65558,213303,256,65831,82182,513]

theorem envBound36915 : H12AffineFastState.Bounded env36915 := by
  intro p hp
  have h : env36915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36914_36915 : H12AffineEnvironment.transform 12 269 env36914 = env36915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36914 == env36915) = true)

theorem identity36915 : scanCanonicalize (H12AffineFastState.compose env36915 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound36915 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36916 : List Nat := [2,4,8,16,32,16,8,256,512,20,2048,4096,269,16384,0,65536,82199,2340,20,1,16644,33,65814,65796,269,16,2049,16400,69894,2341,65558,32,256,65831,82182,513]

theorem envBound36916 : H12AffineFastState.Bounded env36916 := by
  intro p hp
  have h : env36916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36915_36916 : H12AffineEnvironment.transform 16 82199 env36915 = env36916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env36915 == env36916) = true)

def env36917 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,4194304,147457,16777216,8192,17,21039397,18948381,2232597,2340,16998664,23159052,256,19079485,19095837,16925202]

theorem envBound36917 : H12AffineFastState.Bounded env36917 := by
  intro p hp
  have h : env36917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36910_36917 : H12AffineEnvironment.transform 5 17 env36910 = env36917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36910 == env36917) = true)

theorem identity36917 : scanCanonicalize (H12AffineFastState.compose env36917 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound36917 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36918 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,73771,147457,16777216,8192,17,16787726,18948381,2232597,2340,16998664,18891047,256,19079485,19095837,16925202]

theorem envBound36918 : H12AffineFastState.Bounded env36918 := by
  intro p hp
  have h : env36918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36917_36918 : H12AffineEnvironment.transform 21 73771 env36917 = env36918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env36917 == env36918) = true)

theorem identity36918 : scanCanonicalize (H12AffineFastState.compose env36918 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound36918 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36919 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8460,65536,131072,10281,21,8461,2097152,73771,147457,147475,8192,17,157981,2318606,2232597,2340,74011,2228532,256,2187566,2171150,513]

theorem envBound36919 : H12AffineFastState.Bounded env36919 := by
  intro p hp
  have h : env36919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36918_36919 : H12AffineEnvironment.transform 23 147475 env36918 = env36919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env36918 == env36919) = true)

theorem identity36919 : scanCanonicalize (H12AffineFastState.compose env36919 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound36919 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36920 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,8192,16384,8460,65536,90138,10281,21,8461,2097152,73771,73755,73737,8192,17,67847,2097428,2191631,2340,74011,2187566,256,2187566,2171150,513]

theorem envBound36920 : H12AffineFastState.Bounded env36920 := by
  intro p hp
  have h : env36920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36919_36920 : H12AffineEnvironment.transform 16 90138 env36919 = env36920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env36919 == env36920) = true)

theorem identity36920 : scanCanonicalize (H12AffineFastState.compose env36920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36921 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,269,16384,1,65536,82199,2340,21,0,2097152,65830,65814,65796,269,17,67847,2097428,2183170,2340,65558,2179107,256,2179107,2162691,513]

theorem envBound36921 : H12AffineFastState.Bounded env36921 := by
  intro p hp
  have h : env36921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36920_36921 : H12AffineEnvironment.transform 12 269 env36920 = env36921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36920 == env36921) = true)

def env36922 : List Nat := [2,4,8,16,32,64,8,256,512,69,2048,4096,8192,16384,8541,65536,131072,10281,69,8540,2097152,4194304,147457,16777216,8192,64,21039476,18948380,2232596,2421,16998665,23159053,256,19079484,19095885,16925202]

theorem envBound36922 : H12AffineFastState.Bounded env36922 := by
  intro p hp
  have h : env36922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36909_36922 : H12AffineEnvironment.transform 9 69 env36909 = env36922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env36909 == env36922) = true)

def env36923 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,4194304,147457,16777216,8192,16,21039396,18948380,2232596,2341,16998665,23159053,256,19079484,19095837,16925202]

theorem envBound36923 : H12AffineFastState.Bounded env36923 := by
  intro p hp
  have h : env36923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36922_36923 : H12AffineEnvironment.transform 5 16 env36922 = env36923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36922 == env36923) = true)

theorem identity36923 : scanCanonicalize (H12AffineFastState.compose env36923 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound36923 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36924 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,33,147457,16777216,8192,16,16845061,18948380,2232596,2341,16998665,18964780,256,19079484,19095837,16925202]

theorem envBound36924 : H12AffineFastState.Bounded env36924 := by
  intro p hp
  have h : env36924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36923_36924 : H12AffineEnvironment.transform 21 33 env36923 = env36924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env36923 == env36924) = true)

theorem identity36924 : scanCanonicalize (H12AffineFastState.compose env36924 (packedSelected [1,2,6,8,11,12,15,17,18,19] rootPS)) = affineNative (2^(23+1) ^^^ 2121738) := by decide +kernel

theorem selectedBound36924 : packedSelected [1,2,6,8,11,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env36925 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,2097152,33,147457,2121738,8192,16,2189583,82198,2232596,2341,2294019,65830,256,213302,196887,2236952]

theorem envBound36925 : H12AffineFastState.Bounded env36925 := by
  intro p hp
  have h : env36925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36924_36925 : H12AffineEnvironment.transform 23 2121738 env36924 = env36925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2121738 env36924 == env36925) = true)

theorem identity36925 : scanCanonicalize (H12AffineFastState.compose env36925 (packedSelected [4,9,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 16644) := by decide +kernel

theorem selectedBound36925 : packedSelected [4,9,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env36926 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8461,65536,131072,10281,21,8460,16644,33,147457,8462,8192,16,75787,82198,151568,2341,212999,65830,256,213302,196887,156444]

theorem envBound36926 : H12AffineFastState.Bounded env36926 := by
  intro p hp
  have h : env36926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36925_36926 : H12AffineEnvironment.transform 20 16644 env36925 = env36926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16644 env36925 == env36926) = true)

theorem identity36926 : scanCanonicalize (H12AffineFastState.compose env36926 (packedSelected [2,4,6,9,11,14,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound36926 : packedSelected [2,4,6,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env36927 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,4096,8192,16384,8461,65536,16401,10281,21,8460,16644,33,16,8462,8192,16,75787,82198,4097,2341,65558,65830,256,65831,82182,8973]

theorem envBound36927 : H12AffineFastState.Bounded env36927 := by
  intro p hp
  have h : env36927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36926_36927 : H12AffineEnvironment.transform 16 16401 env36926 = env36927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36926 == env36927) = true)

theorem identity36927 : scanCanonicalize (H12AffineFastState.compose env36927 (packedSelected [11,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36927 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env36928 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,8192,16384,8461,65536,16401,10249,21,8460,16644,1,16,8462,8192,16,75787,82198,4097,2309,65558,65798,256,65799,82182,8973]

theorem envBound36928 : H12AffineFastState.Bounded env36928 := by
  intro p hp
  have h : env36928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36927_36928 : H12AffineEnvironment.transform 4 0 env36927 = env36928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36927 == env36928) = true)

theorem identity36928 : scanCanonicalize (H12AffineFastState.compose env36928 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 12313) := by decide +kernel

theorem selectedBound36928 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36929 : List Nat := [2,4,8,16,0,16,8,256,512,21,2048,4096,8192,12313,8461,65536,12296,10249,21,8460,12573,1,16,8462,8192,16,75787,78095,4097,2309,65558,65798,256,65799,78111,8973]

theorem envBound36929 : H12AffineFastState.Bounded env36929 := by
  intro p hp
  have h : env36929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36928_36929 : H12AffineEnvironment.transform 13 12313 env36928 = env36929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12313 env36928 == env36929) = true)

def env36930 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,4194304,147457,16777216,8192,17,21039397,18948380,2232596,2340,16998665,23159053,256,19079484,19095836,16925202]

theorem envBound36930 : H12AffineFastState.Bounded env36930 := by
  intro p hp
  have h : env36930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36922_36930 : H12AffineEnvironment.transform 5 17 env36922 = env36930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36922 == env36930) = true)

theorem identity36930 : scanCanonicalize (H12AffineFastState.compose env36930 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(23+1) ^^^ 4415544) := by decide +kernel

theorem selectedBound36930 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36931 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,4194304,147457,4415544,8192,17,157981,6439204,2232596,2340,4194609,2228533,256,6308100,6291748,4268586]

theorem envBound36931 : H12AffineFastState.Bounded env36931 := by
  intro p hp
  have h : env36931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36930_36931 : H12AffineEnvironment.transform 23 4415544 env36930 = env36931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4415544 env36930 == env36931) = true)

theorem identity36931 : scanCanonicalize (H12AffineFastState.compose env36931 (packedSelected [0,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2113828) := by decide +kernel

theorem selectedBound36931 : packedSelected [0,14,17,27] rootPS < 2^1333 := by decide +kernel

def env36932 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,65536,131072,10281,20,8461,2097152,2113828,147457,2302236,8192,17,157981,131072,2232596,2340,2113557,2228533,256,32,16384,2188046]

theorem envBound36932 : H12AffineFastState.Bounded env36932 := by
  intro p hp
  have h : env36932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36931_36932 : H12AffineEnvironment.transform 21 2113828 env36931 = env36932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113828 env36931 == env36932) = true)

theorem identity36932 : scanCanonicalize (H12AffineFastState.compose env36932 (packedSelected [1,2,3,5,6,8,10,11,12,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound36932 : packedSelected [1,2,3,5,6,8,10,11,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env36933 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,65536,24860,10281,20,8461,2097152,2113828,8477,2179072,8192,17,2049,24860,2125832,2340,2113557,2121769,256,32,16384,2188046]

theorem envBound36933 : H12AffineFastState.Bounded env36933 := by
  intro p hp
  have h : env36933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36932_36933 : H12AffineEnvironment.transform 16 24860 env36932 = env36933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env36932 == env36933) = true)

theorem identity36933 : scanCanonicalize (H12AffineFastState.compose env36933 (packedSelected [0,7,12,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 24584) := by decide +kernel

theorem selectedBound36933 : packedSelected [0,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env36934 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,65536,24860,10281,20,8461,24584,8492,8477,73736,8192,17,2049,24860,4096,2340,8221,33,256,32,16384,66310]

theorem envBound36934 : H12AffineFastState.Bounded env36934 := by
  intro p hp
  have h : env36934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36933_36934 : H12AffineEnvironment.transform 20 24584 env36933 = env36934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24584 env36933 == env36934) = true)

theorem identity36934 : scanCanonicalize (H12AffineFastState.compose env36934 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 10250) := by decide +kernel

theorem selectedBound36934 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env36935 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,4096,8192,16384,8460,10250,24860,10281,20,8461,24584,8492,8477,2050,8192,17,2049,24860,4096,2340,8221,33,256,32,16384,11020]

theorem envBound36935 : H12AffineFastState.Bounded env36935 := by
  intro p hp
  have h : env36935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36934_36935 : H12AffineEnvironment.transform 15 10250 env36934 = env36935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10250 env36934 == env36935) = true)

theorem identity36935 : scanCanonicalize (H12AffineFastState.compose env36935 (packedSelected [1,2,3,6,7,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound36935 : packedSelected [1,2,3,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36936 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,8192,16384,8460,10250,24860,10281,20,8461,24584,8492,8477,2050,8192,17,2049,24860,49,2340,8221,33,256,32,16384,11020]

theorem envBound36936 : H12AffineFastState.Bounded env36936 := by
  intro p hp
  have h : env36936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36935_36936 : H12AffineEnvironment.transform 11 49 env36935 = env36936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36935 == env36936) = true)

theorem identity36936 : scanCanonicalize (H12AffineFastState.compose env36936 (packedSelected [0,2,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36936 : packedSelected [0,2,6,7,10] rootPS < 2^1333 := by decide +kernel

def env36937 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,269,16384,1,2311,16401,2340,20,0,16645,33,16,2050,269,17,2049,16401,49,2340,272,33,256,32,16384,2561]

theorem envBound36937 : H12AffineFastState.Bounded env36937 := by
  intro p hp
  have h : env36937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36936_36937 : H12AffineEnvironment.transform 12 269 env36936 = env36937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36936 == env36937) = true)

theorem identity36937 : scanCanonicalize (H12AffineFastState.compose env36937 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound36937 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36938 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,49,269,2340,1,2311,2357,2340,20,0,2081,33,16,2050,269,17,2049,2357,49,2340,272,33,256,32,2340,2561]

theorem envBound36938 : H12AffineFastState.Bounded env36938 := by
  intro p hp
  have h : env36938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36937_36938 : H12AffineEnvironment.transform 13 2340 env36937 = env36938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env36937 == env36938) = true)

theorem identity36938 : scanCanonicalize (H12AffineFastState.compose env36938 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36938 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env36939 : List Nat := [2,4,8,16,32,17,8,256,512,20,32,49,269,260,1,295,277,260,20,0,1,33,16,34,269,17,33,277,49,260,272,33,256,32,260,545]

theorem envBound36939 : H12AffineFastState.Bounded env36939 := by
  intro p hp
  have h : env36939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36938_36939 : H12AffineEnvironment.transform 10 32 env36938 = env36939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36938 == env36939) = true)

def env36940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound36940 : H12AffineFastState.Bounded env36940 := by
  intro p hp
  have h : env36940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36835_36940 : H12AffineEnvironment.transform 18 1025 env36835 = env36940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env36835 == env36940) = true)

theorem identity36940 : scanCanonicalize (H12AffineFastState.compose env36940 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8601941) := by decide +kernel

theorem selectedBound36940 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8601941,8328,64,4489557,10667480,10507600,8830977,181573,14820501,257,2262521,2253916,254610]

theorem envBound36941 : H12AffineFastState.Bounded env36941 := by
  intro p hp
  have h : env36941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36940_36941 : H12AffineEnvironment.transform 23 8601941 env36940 = env36941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8601941 env36940 == env36941) = true)

def env36942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,8388608,8601941,8328,64,4489557,8393984,8553864,8830977,181573,12645453,257,21793,46212,254610]

theorem envBound36942 : H12AffineFastState.Bounded env36942 := by
  intro p hp
  have h : env36942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36941_36942 : H12AffineEnvironment.transform 20 184536 env36941 = env36942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184536 env36941 == env36942) = true)

def env36943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180360,98781,8328,64,4489557,185736,17664,262281,181573,4338885,257,21793,46212,254610]

theorem envBound36943 : H12AffineFastState.Bounded env36943 := by
  intro p hp
  have h : env36943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36942_36943 : H12AffineEnvironment.transform 22 180360 env36942 = env36943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env36942 == env36943) = true)

def env36944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180360,98781,8328,64,43477,185736,17664,262281,181573,400453,257,21793,46212,254610]

theorem envBound36944 : H12AffineFastState.Bounded env36944 := by
  intro p hp
  have h : env36944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36943_36944 : H12AffineEnvironment.transform 21 272512 env36943 = env36944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36943 == env36944) = true)

theorem identity36944 : scanCanonicalize (H12AffineFastState.compose env36944 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound36944 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,58517,272512,62661,98781,8328,64,43477,57797,17664,262281,61704,272392,257,21793,46212,120543]

theorem envBound36945 : H12AffineFastState.Bounded env36945 := by
  intro p hp
  have h : env36945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36944_36945 : H12AffineEnvironment.transform 16 13389 env36944 = env36945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env36944 == env36945) = true)

def env36946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10280,1025,32769,58517,168,62661,98781,8328,64,43477,57797,17664,10401,61704,32,257,21793,46212,120543]

theorem envBound36946 : H12AffineFastState.Bounded env36946 := by
  intro p hp
  have h : env36946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36945_36946 : H12AffineEnvironment.transform 17 10280 env36945 = env36946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36945 == env36946) = true)

theorem identity36946 : scanCanonicalize (H12AffineFastState.compose env36946 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound36946 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env36947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20497,65536,13389,10280,1025,20496,13444,168,9428,86476,8328,64,31172,12756,17664,10401,8473,32,257,21793,25749,67278]

theorem envBound36947 : H12AffineFastState.Bounded env36947 := by
  intro p hp
  have h : env36947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36946_36947 : H12AffineEnvironment.transform 14 20497 env36946 = env36947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env36946 == env36947) = true)

theorem identity36947 : scanCanonicalize (H12AffineFastState.compose env36947 (packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound36947 : packedSelected [1,3,4,7,8,9,15,16,17,18,19,20,23,24,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env36948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,8461,65536,13389,10280,1025,8460,13444,168,9428,73936,8328,64,2264,12756,13340,10401,8473,32,257,9277,5513,67278]

theorem envBound36948 : H12AffineFastState.Bounded env36948 := by
  intro p hp
  have h : env36948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36947_36948 : H12AffineEnvironment.transform 13 12572 env36947 = env36948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env36947 == env36948) = true)

theorem identity36948 : scanCanonicalize (H12AffineFastState.compose env36948 (packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound36948 : packedSelected [0,3,4,5,7,10,11,16,18,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env36949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12572,8461,251,13389,10280,1025,8460,13444,168,9428,8235,8328,64,2264,12756,13340,10401,8473,32,257,9277,5513,1589]

theorem envBound36949 : H12AffineFastState.Bounded env36949 := by
  intro p hp
  have h : env36949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36948_36949 : H12AffineEnvironment.transform 15 251 env36948 = env36949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env36948 == env36949) = true)

theorem identity36949 : scanCanonicalize (H12AffineFastState.compose env36949 (packedSelected [0,1,4,7,8,11,12,15,16,17,18,19,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound36949 : packedSelected [0,1,4,7,8,11,12,15,16,17,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36950 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,8192,12572,8461,251,12677,10280,457,8460,12620,168,8476,8235,8328,64,2264,12756,12756,10401,8473,32,257,8693,4161,1021]

theorem envBound36950 : H12AffineFastState.Bounded env36950 := by
  intro p hp
  have h : env36950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36949_36950 : H12AffineEnvironment.transform 9 456 env36949 = env36950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env36949 == env36950) = true)

theorem identity36950 : scanCanonicalize (H12AffineFastState.compose env36950 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound36950 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env36951 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,240,4588,509,251,4469,2264,457,508,4540,168,492,219,120,64,2264,4388,4388,2129,489,32,257,261,4161,1021]

theorem envBound36951 : H12AffineFastState.Bounded env36951 := by
  intro p hp
  have h : env36951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36950_36951 : H12AffineEnvironment.transform 12 240 env36950 = env36951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env36950 == env36951) = true)

theorem identity36951 : scanCanonicalize (H12AffineFastState.compose env36951 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36951 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36952 : List Nat := [2,4,8,16,32,64,128,116,512,188,2048,4096,240,4248,137,251,4097,2264,189,136,4296,168,152,219,120,64,2264,4176,4176,2129,157,32,117,113,4161,649]

theorem envBound36952 : H12AffineFastState.Bounded env36952 := by
  intro p hp
  have h : env36952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36951_36952 : H12AffineEnvironment.transform 7 116 env36951 = env36952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36951 == env36952) = true)

theorem identity36952 : scanCanonicalize (H12AffineFastState.compose env36952 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound36952 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env36953 : List Nat := [2,4,8,16,32,64,128,116,512,188,2048,2113,240,2265,137,251,2112,2264,189,136,2185,168,152,219,120,64,2264,2065,2065,2129,157,32,117,113,2048,649]

theorem envBound36953 : H12AffineFastState.Bounded env36953 := by
  intro p hp
  have h : env36953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36952_36953 : H12AffineEnvironment.transform 11 2113 env36952 = env36953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env36952 == env36953) = true)

def env36954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,10281,1025,32769,58517,169,62661,98781,8328,64,43477,57797,17664,10400,61704,33,257,21793,46212,120543]

theorem envBound36954 : H12AffineFastState.Bounded env36954 := by
  intro p hp
  have h : env36954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36945_36954 : H12AffineEnvironment.transform 17 10281 env36945 = env36954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36945 == env36954) = true)

theorem identity36954 : scanCanonicalize (H12AffineFastState.compose env36954 (packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound36954 : packedSelected [1,3,4,7,8,9,10,11,16,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env36955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,13389,10281,1025,32769,58517,169,62661,29790,8328,64,43477,57797,17664,10400,61704,33,257,21793,46212,9052]

theorem envBound36955 : H12AffineFastState.Bounded env36955 := by
  intro p hp
  have h : env36955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36954_36955 : H12AffineEnvironment.transform 15 62851 env36954 = env36955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env36954 == env36955) = true)

theorem identity36955 : scanCanonicalize (H12AffineFastState.compose env36955 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36955 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,54494,5392,2420,1025,32769,50632,169,54680,21763,469,64,34952,49304,17664,2557,53333,33,257,21793,38361,513]

theorem envBound36956 : H12AffineFastState.Bounded env36956 := by
  intro p hp
  have h : env36956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36955_36956 : H12AffineEnvironment.transform 12 349 env36955 = env36956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36955 == env36956) = true)

theorem identity36956 : scanCanonicalize (H12AffineFastState.compose env36956 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound36956 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env36957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5592,32768,33030,5392,2420,1025,32769,36880,169,32832,219,469,64,34952,38208,4312,2557,34189,33,257,249,38361,513]

theorem envBound36957 : H12AffineFastState.Bounded env36957 := by
  intro p hp
  have h : env36957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36956_36957 : H12AffineEnvironment.transform 13 5592 env36956 = env36957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env36956 == env36957) = true)

theorem identity36957 : scanCanonicalize (H12AffineFastState.compose env36957 (packedSelected [0,3,5,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound36957 : packedSelected [0,3,5,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5592,137,399,5392,2420,1025,136,4249,169,201,219,469,64,2049,5577,4312,2557,1284,33,257,249,5456,513]

theorem envBound36958 : H12AffineFastState.Bounded env36958 := by
  intro p hp
  have h : env36958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36957_36958 : H12AffineEnvironment.transform 14 137 env36957 = env36958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env36957 == env36958) = true)

theorem identity36958 : scanCanonicalize (H12AffineFastState.compose env36958 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36958 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36959 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,137,399,5392,2341,1025,136,4249,169,152,138,388,17,2049,5528,4233,2476,1284,33,257,168,5377,513]

theorem envBound36959 : H12AffineFastState.Bounded env36959 := by
  intro p hp
  have h : env36959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36958_36959 : H12AffineEnvironment.transform 5 17 env36958 = env36959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36958 == env36959) = true)

theorem identity36959 : scanCanonicalize (H12AffineFastState.compose env36959 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2706) := by decide +kernel

theorem selectedBound36959 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36960 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2706,268,3867,137,399,3970,2341,1025,136,2571,169,152,138,388,17,2049,3850,2587,2476,1284,33,257,168,3987,513]

theorem envBound36960 : H12AffineFastState.Bounded env36960 := by
  intro p hp
  have h : env36960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36959_36960 : H12AffineEnvironment.transform 11 2706 env36959 = env36960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2706 env36959 == env36960) = true)

theorem identity36960 : scanCanonicalize (H12AffineFastState.compose env36960 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36960 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env36961 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2706,40,3647,137,171,3750,2049,1025,136,2571,169,152,138,160,17,2049,3630,2587,2184,1056,33,37,168,3767,513]

theorem envBound36961 : H12AffineFastState.Bounded env36961 := by
  intro p hp
  have h : env36961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36960_36961 : H12AffineEnvironment.transform 7 36 env36960 = env36961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36960 == env36961) = true)

theorem identity36961 : scanCanonicalize (H12AffineFastState.compose env36961 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound36961 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36962 : List Nat := [2,4,8,16,32,17,128,36,10,1024,2048,2200,40,3125,137,171,3244,2049,1025,136,2049,169,152,138,160,17,2049,3108,2065,2184,1056,33,37,168,3261,11]

theorem envBound36962 : H12AffineFastState.Bounded env36962 := by
  intro p hp
  have h : env36962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36961_36962 : H12AffineEnvironment.transform 8 10 env36961 = env36962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env36961 == env36962) = true)

theorem identity36962 : scanCanonicalize (H12AffineFastState.compose env36962 (packedSelected [1,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound36962 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env36963 : List Nat := [2,4,8,16,32,17,128,36,10,1024,136,16,40,1213,137,171,1060,137,1025,136,137,169,152,138,160,17,137,1196,153,0,1056,33,37,168,1077,11]

theorem envBound36963 : H12AffineFastState.Bounded env36963 := by
  intro p hp
  have h : env36963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36962_36963 : H12AffineEnvironment.transform 10 136 env36962 = env36963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env36962 == env36963) = true)

theorem identity36963 : scanCanonicalize (H12AffineFastState.compose env36963 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36963 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env36964 : List Nat := [2,3,8,16,32,17,128,35,10,1024,136,16,40,1210,137,171,1059,137,1025,136,137,169,152,138,160,17,137,1195,153,0,1056,33,34,168,1074,11]

theorem envBound36964 : H12AffineFastState.Bounded env36964 := by
  intro p hp
  have h : env36964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36963_36964 : H12AffineEnvironment.transform 1 3 env36963 = env36964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36963 == env36964) = true)

def env36965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180360,98781,8328,64,43476,185736,17664,262281,181573,400452,257,21793,46212,254610]

theorem envBound36965 : H12AffineFastState.Bounded env36965 := by
  intro p hp
  have h : env36965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36943_36965 : H12AffineEnvironment.transform 21 272513 env36943 = env36965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36943 == env36965) = true)

theorem identity36965 : scanCanonicalize (H12AffineFastState.compose env36965 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound36965 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140300,272513,144476,95497,8328,64,23808,139612,17664,262281,143761,400452,257,21793,16464,202310]

theorem envBound36966 : H12AffineFastState.Bounded env36966 := by
  intro p hp
  have h : env36966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36965_36966 : H12AffineEnvironment.transform 14 29908 env36965 = env36966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env36965 == env36966) = true)

def env36967 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272393,144476,95497,8192,64,23808,139612,17664,262145,143641,400452,257,21793,16464,202310]

theorem envBound36967 : H12AffineFastState.Bounded env36967 := by
  intro p hp
  have h : env36967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36966_36967 : H12AffineEnvironment.transform 6 8 env36966 = env36967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36966 == env36967) = true)

theorem identity36967 : scanCanonicalize (H12AffineFastState.compose env36967 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound36967 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env36968 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,89378,1025,29789,140300,95531,144476,95497,8192,64,23808,139612,17664,89379,143641,213350,257,21793,16464,202310]

theorem envBound36968 : H12AffineFastState.Bounded env36968 := by
  intro p hp
  have h : env36968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36967_36968 : H12AffineEnvironment.transform 17 89378 env36967 = env36968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env36967 == env36968) = true)

theorem identity36968 : scanCanonicalize (H12AffineFastState.compose env36968 (packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound36968 : packedSelected [0,3,4,5,10,12,14,15,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env36969 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21874,131072,2128,1025,29789,140300,8281,144476,8315,8192,64,23808,139612,17664,2129,143641,136212,257,21793,16464,148276]

theorem envBound36969 : H12AffineFastState.Bounded env36969 := by
  intro p hp
  have h : env36969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36968_36969 : H12AffineEnvironment.transform 15 21874 env36968 = env36969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env36968 == env36969) = true)

theorem identity36969 : scanCanonicalize (H12AffineFastState.compose env36969 (packedSelected [0,4,5,7,12,15,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound36969 : packedSelected [0,4,5,7,12,15,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,373,8283,131072,2128,1025,372,140300,8281,144476,8315,8192,64,10281,139612,12329,2129,143641,136212,257,8200,13689,144925]

theorem envBound36970 : H12AffineFastState.Bounded env36970 := by
  intro p hp
  have h : env36970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36969_36970 : H12AffineEnvironment.transform 13 13609 env36969 = env36970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env36969 == env36970) = true)

theorem identity36970 : scanCanonicalize (H12AffineFastState.compose env36970 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36970 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env36971 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,1,8283,131072,2128,1025,0,140300,8281,144476,8315,8192,64,10281,139304,12329,2129,143469,136212,117,8200,13325,144925]

theorem envBound36971 : H12AffineFastState.Bounded env36971 := by
  intro p hp
  have h : env36971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36970_36971 : H12AffineEnvironment.transform 7 116 env36970 = env36971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36970 == env36971) = true)

theorem identity36971 : scanCanonicalize (H12AffineFastState.compose env36971 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound36971 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env36972 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5156,1,34,131072,2128,1025,0,132213,32,136229,2,121,64,2128,131153,4176,2129,135188,136212,117,113,5236,136804]

theorem envBound36972 : H12AffineFastState.Bounded env36972 := by
  intro p hp
  have h : env36972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36971_36972 : H12AffineEnvironment.transform 12 121 env36971 = env36972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env36971 == env36972) = true)

theorem identity36972 : scanCanonicalize (H12AffineFastState.compose env36972 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound36972 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env36973 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5156,1,34,5173,2128,1025,0,4160,32,16,2,121,64,2128,5220,4176,2129,1057,33,117,113,5236,593]

theorem envBound36973 : H12AffineFastState.Bounded env36973 := by
  intro p hp
  have h : env36973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36972_36973 : H12AffineEnvironment.transform 16 5173 env36972 = env36973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env36972 == env36973) = true)

theorem identity36973 : scanCanonicalize (H12AffineFastState.compose env36973 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound36973 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env36974 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3103,121,2107,1,34,2090,2128,1025,0,3167,32,16,2,121,64,2128,2171,3151,2129,1057,33,117,113,2155,593]

theorem envBound36974 : H12AffineFastState.Bounded env36974 := by
  intro p hp
  have h : env36974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36973_36974 : H12AffineEnvironment.transform 11 3103 env36973 = env36974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env36973 == env36974) = true)

theorem identity36974 : scanCanonicalize (H12AffineFastState.compose env36974 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound36974 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36975 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,3103,8,2107,1,34,2090,2081,1025,0,3118,32,16,2,8,49,2081,2058,3134,2080,1057,33,4,0,2074,544]

theorem envBound36975 : H12AffineFastState.Bounded env36975 := by
  intro p hp
  have h : env36975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36974_36975 : H12AffineEnvironment.transform 5 49 env36974 = env36975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env36974 == env36975) = true)

theorem identity36975 : scanCanonicalize (H12AffineFastState.compose env36975 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36975 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36976 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,3103,8,2075,1,2,2058,2049,1025,0,3086,0,16,2,8,17,2049,2058,3102,2048,1025,1,4,0,2074,512]

theorem envBound36976 : H12AffineFastState.Bounded env36976 := by
  intro p hp
  have h : env36976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36975_36976 : H12AffineEnvironment.transform 4 0 env36975 = env36976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36975 == env36976) = true)

theorem identity36976 : scanCanonicalize (H12AffineFastState.compose env36976 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound36976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36977 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1054,1,8,1029,1,2,1044,1055,1025,0,16,0,16,2,8,17,1055,1044,0,1054,1025,1,4,0,1028,512]

theorem envBound36977 : H12AffineFastState.Bounded env36977 := by
  intro p hp
  have h : env36977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36976_36977 : H12AffineEnvironment.transform 10 1054 env36976 = env36977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env36976 == env36977) = true)

theorem identity36977 : scanCanonicalize (H12AffineFastState.compose env36977 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36978 : List Nat := [2,4,8,16,0,17,8,5,512,21,11,1,8,16,1,2,1,10,20,0,16,0,16,2,8,17,10,1,0,11,20,1,4,0,17,512]

theorem envBound36978 : H12AffineFastState.Bounded env36978 := by
  intro p hp
  have h : env36978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36977_36978 : H12AffineEnvironment.transform 9 21 env36977 = env36978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36977 == env36978) = true)

theorem identity36978 : scanCanonicalize (H12AffineFastState.compose env36978 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound36978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36979 : List Nat := [2,4,7,16,0,17,7,5,512,21,4,1,7,16,1,2,1,5,20,0,16,0,16,2,7,17,5,1,0,4,20,1,4,0,17,512]

theorem envBound36979 : H12AffineFastState.Bounded env36979 := by
  intro p hp
  have h : env36979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36978_36979 : H12AffineEnvironment.transform 2 7 env36978 = env36979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env36978 == env36979) = true)

theorem identity36979 : scanCanonicalize (H12AffineFastState.compose env36979 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36979 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36980 : List Nat := [2,4,7,6,0,7,7,5,512,3,4,1,7,6,1,2,1,5,2,0,6,0,6,2,7,7,5,1,0,4,2,1,4,0,7,512]

theorem envBound36980 : H12AffineFastState.Bounded env36980 := by
  intro p hp
  have h : env36980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36979_36980 : H12AffineEnvironment.transform 3 6 env36979 = env36980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36979 == env36980) = true)

def env36981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140300,272392,144476,95497,8193,64,23808,139612,17664,262144,143640,400452,257,21793,16464,202310]

theorem envBound36981 : H12AffineFastState.Bounded env36981 := by
  intro p hp
  have h : env36981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36966_36981 : H12AffineEnvironment.transform 6 9 env36966 = env36981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36966 == env36981) = true)

theorem identity36981 : scanCanonicalize (H12AffineFastState.compose env36981 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound36981 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env36982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,23668,1025,29788,140300,29820,144476,95497,8193,64,23808,139612,17664,23668,143640,147504,257,21793,16464,202310]

theorem envBound36982 : H12AffineFastState.Bounded env36982 := by
  intro p hp
  have h : env36982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36981_36982 : H12AffineEnvironment.transform 17 23668 env36981 = env36982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env36981 == env36982) = true)

theorem identity36982 : scanCanonicalize (H12AffineFastState.compose env36982 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound36982 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env36983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,16400,23668,1025,29788,25628,29820,29772,95497,8193,64,23808,24908,17664,23668,28936,32,257,21793,16464,87638]

theorem envBound36983 : H12AffineFastState.Bounded env36983 := by
  intro p hp
  have h : env36983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36982_36983 : H12AffineEnvironment.transform 16 16400 env36982 = env36983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36982 == env36983) = true)

theorem identity36983 : scanCanonicalize (H12AffineFastState.compose env36983 (packedSelected [0,1,5,7,9,10,12,14,15,16,18,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound36983 : packedSelected [0,1,5,7,9,10,12,14,15,16,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env36984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,30043,16400,23668,1025,29788,25628,29820,29772,82,8193,64,23808,24908,17664,23668,28936,32,257,21793,16464,8973]

theorem envBound36984 : H12AffineFastState.Bounded env36984 := by
  intro p hp
  have h : env36984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36983_36984 : H12AffineEnvironment.transform 15 30043 env36983 = env36984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env36983 == env36984) = true)

theorem identity36984 : scanCanonicalize (H12AffineFastState.compose env36984 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36984 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36985 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,29962,16400,23589,1025,29709,25628,29741,29725,3,8193,17,23808,24861,17664,23589,28936,32,257,21793,16385,8973]

theorem envBound36985 : H12AffineFastState.Bounded env36985 := by
  intro p hp
  have h : env36985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36984_36985 : H12AffineEnvironment.transform 5 17 env36984 = env36985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36984 == env36985) = true)

theorem identity36985 : scanCanonicalize (H12AffineFastState.compose env36985 (packedSelected [0,1,3,4,5,7,8,9,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36985 : packedSelected [0,1,3,4,5,7,8,9,12,14,18] rootPS < 2^1333 := by decide +kernel

def env36986 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,21511,16400,23589,1025,21760,17681,21792,21776,3,268,17,23808,16400,17664,23589,20485,32,257,21793,16385,512]

theorem envBound36986 : H12AffineFastState.Bounded env36986 := by
  intro p hp
  have h : env36986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36985_36986 : H12AffineEnvironment.transform 12 269 env36985 = env36986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36985 == env36986) = true)

theorem identity36986 : scanCanonicalize (H12AffineFastState.compose env36986 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 2080) := by decide +kernel

theorem selectedBound36986 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36987 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,2080,7457,7207,2096,5125,1025,7456,3377,7424,7472,3,268,17,5408,2096,3360,5125,6181,32,257,7425,2081,512]

theorem envBound36987 : H12AffineFastState.Bounded env36987 := by
  intro p hp
  have h : env36987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36986_36987 : H12AffineEnvironment.transform 13 2080 env36986 = env36987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2080 env36986 == env36987) = true)

theorem identity36987 : scanCanonicalize (H12AffineFastState.compose env36987 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36988 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,269,2049,7424,7174,2065,5125,1025,7425,3344,7424,7441,3,268,17,5377,2065,3329,5125,6148,1,257,7425,2048,512]

theorem envBound36988 : H12AffineFastState.Bounded env36988 := by
  intro p hp
  have h : env36988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36987_36988 : H12AffineEnvironment.transform 4 1 env36987 = env36988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36987 == env36988) = true)

theorem identity36988 : scanCanonicalize (H12AffineFastState.compose env36988 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound36988 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36989 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,3076,269,2049,260,2,2065,2049,1025,261,3344,260,277,3,268,17,2309,2065,3329,2049,1024,1,257,261,2048,512]

theorem envBound36989 : H12AffineFastState.Bounded env36989 := by
  intro p hp
  have h : env36989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36988_36989 : H12AffineEnvironment.transform 11 3076 env36988 = env36989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env36988 == env36989) = true)

theorem identity36989 : scanCanonicalize (H12AffineFastState.compose env36989 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36989 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env36990 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,3076,8,2049,1,2,2065,2049,1025,0,3093,1,16,3,9,17,2048,2065,3076,2049,1024,1,4,0,2048,512]

theorem envBound36990 : H12AffineFastState.Bounded env36990 := by
  intro p hp
  have h : env36990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36989_36990 : H12AffineEnvironment.transform 7 5 env36989 = env36990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36989 == env36990) = true)

theorem identity36990 : scanCanonicalize (H12AffineFastState.compose env36990 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36990 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36991 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,2065,8,2049,1,2,2065,2049,20,0,2048,1,16,3,9,17,2048,2065,2065,2049,21,1,4,0,2048,512]

theorem envBound36991 : H12AffineFastState.Bounded env36991 := by
  intro p hp
  have h : env36991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36990_36991 : H12AffineEnvironment.transform 9 21 env36990 = env36991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36990 == env36991) = true)

def env36992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,4194304,180361,98780,8328,64,4489557,185737,17665,262280,181573,4338884,257,21793,46212,254610]

theorem envBound36992 : H12AffineFastState.Bounded env36992 := by
  intro p hp
  have h : env36992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36942_36992 : H12AffineEnvironment.transform 22 180361 env36942 = env36992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env36942 == env36992) = true)

def env36993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272512,180361,98780,8328,64,43477,185737,17665,262280,181573,400452,257,21793,46212,254610]

theorem envBound36993 : H12AffineFastState.Bounded env36993 := by
  intro p hp
  have h : env36993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36992_36993 : H12AffineEnvironment.transform 21 272512 env36992 = env36993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env36992 == env36993) = true)

theorem identity36993 : scanCanonicalize (H12AffineFastState.compose env36993 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound36993 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4160,272512,17,98780,8328,64,43477,5393,17665,262280,1501,318684,257,21793,46212,74250]

theorem envBound36994 : H12AffineFastState.Bounded env36994 := by
  intro p hp
  have h : env36994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36993_36994 : H12AffineEnvironment.transform 16 49304 env36993 = env36994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env36993 == env36994) = true)

theorem identity36994 : scanCanonicalize (H12AffineFastState.compose env36994 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36994 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49304,262144,1025,32769,4160,272512,17,41431,8328,64,43477,5393,17665,262280,1501,318684,257,21793,46212,513]

theorem envBound36995 : H12AffineFastState.Bounded env36995 := by
  intro p hp
  have h : env36995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36994_36995 : H12AffineEnvironment.transform 15 8203 env36994 = env36995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36994 == env36995) = true)

def env36996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184536,272513,180361,98780,8328,64,43476,185737,17665,262280,181573,400453,257,21793,46212,254610]

theorem envBound36996 : H12AffineFastState.Bounded env36996 := by
  intro p hp
  have h : env36996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36992_36996 : H12AffineEnvironment.transform 21 272513 env36992 = env36996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env36992 == env36996) = true)

def env36997 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272393,180225,98644,8192,64,43356,185601,17665,262144,181573,400453,257,21793,46092,254490]

theorem envBound36997 : H12AffineFastState.Bounded env36997 := by
  intro p hp
  have h : env36997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36996_36997 : H12AffineEnvironment.transform 6 8 env36996 = env36997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36996 == env36997) = true)

theorem identity36997 : scanCanonicalize (H12AffineFastState.compose env36997 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound36997 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env36998 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,262144,1025,32769,184400,272393,180225,8542,8192,64,43356,185601,17665,262144,181573,400453,257,21793,46092,147984]

theorem envBound36998 : H12AffineFastState.Bounded env36998 := by
  intro p hp
  have h : env36998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36997_36998 : H12AffineEnvironment.transform 15 40970 env36997 = env36998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env36997 == env36998) = true)

theorem identity36998 : scanCanonicalize (H12AffineFastState.compose env36998 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound36998 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env36999 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,43049,1025,32769,184400,32800,180225,8542,8192,64,43356,185601,17665,43049,181573,177260,257,21793,46092,147984]

theorem envBound36999 : H12AffineFastState.Bounded env36999 := by
  intro p hp
  have h : env36999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36998_36999 : H12AffineEnvironment.transform 17 43049 env36998 = env36999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env36998 == env36999) = true)

theorem identity36999 : scanCanonicalize (H12AffineFastState.compose env36999 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound36999 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37000 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57677,43049,1025,32769,12573,32800,8524,8542,8192,64,43356,13388,17665,43049,9224,21793,257,21793,46092,41821]

theorem envBound37000 : H12AffineFastState.Bounded env37000 := by
  intro p hp
  have h : env37000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36999_37000 : H12AffineEnvironment.transform 16 57677 env36999 = env37000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env36999 == env37000) = true)

theorem identity37000 : scanCanonicalize (H12AffineFastState.compose env37000 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37000 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env37001 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33110,49169,35189,1025,32769,4161,32800,16,2,348,64,34816,5392,17665,35189,1364,21793,257,21793,38224,33281]

theorem envBound37001 : H12AffineFastState.Bounded env37001 := by
  intro p hp
  have h : env37001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37000_37001 : H12AffineEnvironment.transform 12 348 env37000 = env37001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37000 == env37001) = true)

theorem identity37001 : scanCanonicalize (H12AffineFastState.compose env37001 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound37001 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env37002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,32768,33110,37941,35189,1025,32769,4161,32800,16,2,348,64,34816,5392,4389,35189,1364,261,257,261,38224,33281]

theorem envBound37002 : H12AffineFastState.Bounded env37002 := by
  intro p hp
  have h : env37002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37001_37002 : H12AffineEnvironment.transform 13 5156 env37001 = env37002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env37001 == env37002) = true)

theorem identity37002 : scanCanonicalize (H12AffineFastState.compose env37002 (packedSelected [0,1,7,8,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound37002 : packedSelected [0,1,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env37003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,1344,32768,33110,34129,35189,1025,32769,293,32800,16,2,348,64,34816,1140,65,35189,1364,261,257,261,33844,33281]

theorem envBound37003 : H12AffineFastState.Bounded env37003 := by
  intro p hp
  have h : env37003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37002_37003 : H12AffineEnvironment.transform 11 356 env37002 = env37003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env37002 == env37003) = true)

theorem identity37003 : scanCanonicalize (H12AffineFastState.compose env37003 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37003 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env37004 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,356,348,81,32768,33110,32832,35189,272,32769,293,32800,16,2,348,64,34816,357,65,35189,69,261,257,261,33061,33281]

theorem envBound37004 : H12AffineFastState.Bounded env37004 := by
  intro p hp
  have h : env37004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37003_37004 : H12AffineEnvironment.transform 9 273 env37003 = env37004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37003 == env37004) = true)

theorem identity37004 : scanCanonicalize (H12AffineFastState.compose env37004 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound37004 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37005 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,356,348,81,372,34,308,2049,272,373,293,340,16,2,348,64,2420,357,65,2049,69,261,257,261,81,885]

theorem envBound37005 : H12AffineFastState.Bounded env37005 := by
  intro p hp
  have h : env37005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37004_37005 : H12AffineEnvironment.transform 14 372 env37004 = env37005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env37004 == env37005) = true)

def env37006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180224,98645,8193,64,43357,185600,17665,262145,181573,400453,257,21793,46093,254491]

theorem envBound37006 : H12AffineFastState.Bounded env37006 := by
  intro p hp
  have h : env37006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36996_37006 : H12AffineEnvironment.transform 6 9 env36996 = env37006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36996 == env37006) = true)

def env37007 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,16,98645,8193,64,43357,5392,17665,262145,1365,318549,257,21793,46093,74251]

theorem envBound37007 : H12AffineFastState.Bounded env37007 := by
  intro p hp
  have h : env37007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37006_37007 : H12AffineEnvironment.transform 16 49168 env37006 = env37007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env37006 == env37007) = true)

theorem identity37007 : scanCanonicalize (H12AffineFastState.compose env37007 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 130095) := by decide +kernel

theorem selectedBound37007 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130095,1025,32769,4161,119847,16,98645,8193,64,43357,5392,17665,130094,1365,73850,257,21793,46093,74251]

theorem envBound37008 : H12AffineFastState.Bounded env37008 := by
  intro p hp
  have h : env37008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37007_37008 : H12AffineEnvironment.transform 17 130095 env37007 = env37008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130095 env37007 == env37008) = true)

theorem identity37008 : scanCanonicalize (H12AffineFastState.compose env37008 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound37008 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,46108,100387,1025,32769,4161,106539,16,98645,8193,64,43357,5392,12557,100386,1365,73850,257,8493,46093,74251]

theorem envBound37009 : H12AffineFastState.Bounded env37009 := by
  intro p hp
  have h : env37009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37008_37009 : H12AffineEnvironment.transform 13 13324 env37008 = env37009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env37008 == env37009) = true)

theorem identity37009 : scanCanonicalize (H12AffineFastState.compose env37009 (packedSelected [1,5,8,10,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37009 : packedSelected [1,5,8,10,24,31] rootPS < 2^1333 := by decide +kernel

def env37010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,8202,46108,43049,1025,32769,4161,32801,16,41311,8193,64,43357,5392,12557,43048,1365,112,257,8493,46093,513]

theorem envBound37010 : H12AffineFastState.Bounded env37010 := by
  intro p hp
  have h : env37010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37009_37010 : H12AffineEnvironment.transform 15 8202 env37009 = env37010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37009 == env37010) = true)

theorem identity37010 : scanCanonicalize (H12AffineFastState.compose env37010 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37010 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,8202,5441,2420,1025,8540,4161,8572,16,2,8193,64,2048,5392,12557,2421,1365,112,257,8493,5456,513]

theorem envBound37011 : H12AffineFastState.Bounded env37011 := by
  intro p hp
  have h : env37011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37010_37011 : H12AffineEnvironment.transform 14 8541 env37010 = env37011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37010 == env37011) = true)

def env37012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,98645,8193,64,43357,5393,17665,262145,1364,318548,257,21793,46093,74250]

theorem envBound37012 : H12AffineFastState.Bounded env37012 := by
  intro p hp
  have h : env37012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37006_37012 : H12AffineEnvironment.transform 16 49169 env37006 = env37012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env37006 == env37012) = true)

theorem identity37012 : scanCanonicalize (H12AffineFastState.compose env37012 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37012 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,33,17,98645,8193,64,43357,5393,17665,10280,1364,62589,257,21793,46093,74250]

theorem envBound37013 : H12AffineFastState.Bounded env37013 := by
  intro p hp
  have h : env37013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37012_37013 : H12AffineEnvironment.transform 17 10281 env37012 = env37013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37012 == env37013) = true)

theorem identity37013 : scanCanonicalize (H12AffineFastState.compose env37013 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound37013 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37014 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,49169,10281,1025,32769,4160,33,17,8543,8193,64,43357,5393,17665,10280,1364,62589,257,21793,46093,33280]

theorem envBound37014 : H12AffineFastState.Bounded env37014 := by
  intro p hp
  have h : env37014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37013_37014 : H12AffineEnvironment.transform 15 40970 env37013 = env37014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env37013 == env37014) = true)

theorem identity37014 : scanCanonicalize (H12AffineFastState.compose env37014 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37014 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env37015 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,46156,10281,1025,32769,4160,33,17,8543,8193,64,43357,5393,12636,10280,1364,32800,257,8572,46093,33280]

theorem envBound37015 : H12AffineFastState.Bounded env37015 := by
  intro p hp
  have h : env37015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37014_37015 : H12AffineEnvironment.transform 13 13405 env37014 = env37015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37014 == env37015) = true)

theorem identity37015 : scanCanonicalize (H12AffineFastState.compose env37015 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37015 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37016 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,342,5392,10281,1025,8541,4160,33,17,8543,8193,64,2049,5393,12636,10280,1364,8572,257,8572,5457,9052]

theorem envBound37016 : H12AffineFastState.Bounded env37016 := by
  intro p hp
  have h : env37016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37015_37016 : H12AffineEnvironment.transform 14 8540 env37015 = env37016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37015 == env37016) = true)

theorem identity37016 : scanCanonicalize (H12AffineFastState.compose env37016 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37016 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37017 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,12620,8540,342,4097,10281,272,8541,4160,33,17,8543,8193,64,2049,4096,12636,10280,69,8572,257,8572,4160,9052]

theorem envBound37017 : H12AffineFastState.Bounded env37017 := by
  intro p hp
  have h : env37017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37016_37017 : H12AffineEnvironment.transform 9 273 env37016 = env37017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37016 == env37017) = true)

theorem identity37017 : scanCanonicalize (H12AffineFastState.compose env37017 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound37017 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37018 : List Nat := [2,4,8,16,32,64,9,85,512,68,2048,4096,8192,12313,8201,3,4097,10281,69,8200,4160,33,17,8202,8193,64,2049,4096,12297,10280,69,8233,84,8233,4160,8713]

theorem envBound37018 : H12AffineFastState.Bounded env37018 := by
  intro p hp
  have h : env37018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37017_37018 : H12AffineEnvironment.transform 7 85 env37017 = env37018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env37017 == env37018) = true)

theorem identity37018 : scanCanonicalize (H12AffineFastState.compose env37018 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 4153) := by decide +kernel

theorem selectedBound37018 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env37019 : List Nat := [2,4,8,16,32,64,9,85,512,68,2048,4096,4153,32,4144,3,4097,6160,69,4145,4160,33,17,4147,4152,64,2049,4096,48,6161,69,4112,84,4112,4160,4656]

theorem envBound37019 : H12AffineFastState.Bounded env37019 := by
  intro p hp
  have h : env37019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37018_37019 : H12AffineEnvironment.transform 12 4153 env37018 = env37019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4153 env37018 == env37019) = true)

theorem identity37019 : scanCanonicalize (H12AffineFastState.compose env37019 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37019 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37020 : List Nat := [2,4,8,16,32,17,9,4,512,21,2048,4096,4153,32,4144,3,4097,6160,20,4145,4113,33,17,4147,4152,17,2049,4096,48,6161,20,4112,5,4112,4113,4656]

theorem envBound37020 : H12AffineFastState.Bounded env37020 := by
  intro p hp
  have h : env37020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37019_37020 : H12AffineEnvironment.transform 5 17 env37019 = env37020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37019 == env37020) = true)

theorem identity37020 : scanCanonicalize (H12AffineFastState.compose env37020 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound37020 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env37021 : List Nat := [2,4,8,16,32,17,9,4,512,21,2048,2096,2057,32,2048,3,2097,32,20,2049,2081,33,17,2051,2056,17,2049,2096,48,33,20,2080,5,2080,2081,2560]

theorem envBound37021 : H12AffineFastState.Bounded env37021 := by
  intro p hp
  have h : env37021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37020_37021 : H12AffineEnvironment.transform 11 2096 env37020 = env37021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env37020 == env37021) = true)

theorem identity37021 : scanCanonicalize (H12AffineFastState.compose env37021 (packedSelected [14] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37021 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1