import H12CloudChart1Data024

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env6194 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,16384,8353,25898,1196,262144,1024,8353,1281,281856,281888,138,8329,281888,279841,16385,16813,19745,16641,17581,256,17664,280609,282253]

theorem envBound6194 : H12AffineFastState.Bounded env6194 := by
  intro p hp
  have h : env6194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6193_6194 : H12AffineEnvironment.transform 21 281856 env6193 = env6194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281856 env6193 == env6194) = true)

theorem identity6194 : scanCanonicalize (H12AffineFastState.compose env6194 (packedSelected [0,6,7,9,11,13,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 11522) := by decide +kernel

theorem selectedBound6194 : packedSelected [0,6,7,9,11,13,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6195 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,11522,8353,2088,1196,262144,1024,8353,1281,270338,270370,138,8329,270370,272419,11523,11439,8227,11267,10671,256,10242,271651,271247]

theorem envBound6195 : H12AffineFastState.Bounded env6195 := by
  intro p hp
  have h : env6195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6194_6195 : H12AffineEnvironment.transform 13 11522 env6194 = env6195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11522 env6194 == env6195) = true)

theorem identity6195 : scanCanonicalize (H12AffineFastState.compose env6195 (packedSelected [0,1,4,5,7,8,13,17,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6195 : packedSelected [0,1,4,5,7,8,13,17,22,24] rootPS < 2^1333 := by decide +kernel

def env6196 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,11522,8353,2088,1196,2184,1024,8353,1281,10378,10410,138,8329,10410,8363,11523,11439,8227,11267,10671,256,10242,11691,11015]

theorem envBound6196 : H12AffineFastState.Bounded env6196 := by
  intro p hp
  have h : env6196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6195_6196 : H12AffineEnvironment.transform 17 2184 env6195 = env6196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6195 == env6196) = true)

theorem identity6196 : scanCanonicalize (H12AffineFastState.compose env6196 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6196 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6197 : List Nat := [2,4,8,0,32,0,128,256,32,1024,2048,1281,8192,11522,8353,2088,1196,2184,1024,8353,1281,10378,10410,138,8329,10410,8363,11523,11439,8227,11267,10671,256,10242,11691,10535]

theorem envBound6197 : H12AffineFastState.Bounded env6197 := by
  intro p hp
  have h : env6197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6196_6197 : H12AffineEnvironment.transform 8 32 env6196 = env6197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6196 == env6197) = true)

theorem identity6197 : scanCanonicalize (H12AffineFastState.compose env6197 (packedSelected [3,5,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 386) := by decide +kernel

theorem selectedBound6197 : packedSelected [3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env6198 : List Nat := [2,4,8,0,32,0,128,256,32,386,2048,131,8192,10368,8353,2088,302,2184,386,8353,131,10378,10410,138,8329,10410,8363,10369,10541,8227,10625,10671,256,10242,10281,10535]

theorem envBound6198 : H12AffineFastState.Bounded env6198 := by
  intro p hp
  have h : env6198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6197_6198 : H12AffineEnvironment.transform 9 386 env6197 = env6198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 386 env6197 == env6198) = true)

theorem identity6198 : scanCanonicalize (H12AffineFastState.compose env6198 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 34) := by decide +kernel

theorem selectedBound6198 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env6199 : List Nat := [2,4,8,0,32,0,128,256,32,386,2048,131,34,2210,131,2088,302,2184,386,131,131,2216,2184,138,171,2184,137,2211,2319,1,2467,2445,256,2080,2059,2309]

theorem envBound6199 : H12AffineFastState.Bounded env6199 := by
  intro p hp
  have h : env6199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6198_6199 : H12AffineEnvironment.transform 12 34 env6198 = env6199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 34 env6198 == env6199) = true)

theorem identity6199 : scanCanonicalize (H12AffineFastState.compose env6199 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound6199 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env6200 : List Nat := [2,4,8,0,32,0,128,14,32,140,2048,131,34,2210,131,2088,32,2184,140,131,131,2216,2184,138,171,2184,137,2211,2049,1,2221,2179,14,2080,2059,2059]

theorem envBound6200 : H12AffineFastState.Bounded env6200 := by
  intro p hp
  have h : env6200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6199_6200 : H12AffineEnvironment.transform 7 14 env6199 = env6200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env6199 == env6200) = true)

theorem identity6200 : scanCanonicalize (H12AffineFastState.compose env6200 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound6200 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env6201 : List Nat := [2,4,8,0,32,0,2,14,32,14,2048,1,34,2080,1,2088,32,2058,14,1,1,2090,2058,8,41,2058,11,2081,2049,1,2095,2049,14,2080,2059,2059]

theorem envBound6201 : H12AffineFastState.Bounded env6201 := by
  intro p hp
  have h : env6201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6200_6201 : H12AffineEnvironment.transform 6 2 env6200 = env6201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env6200 == env6201) = true)

theorem identity6201 : scanCanonicalize (H12AffineFastState.compose env6201 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6201 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6202 : List Nat := [2,4,8,0,10,0,2,14,10,14,2048,1,8,2058,1,2050,10,2058,14,1,1,2048,2058,8,3,2058,11,2059,2049,1,2053,2049,14,2058,2059,2059]

theorem envBound6202 : H12AffineFastState.Bounded env6202 := by
  intro p hp
  have h : env6202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6201_6202 : H12AffineEnvironment.transform 4 10 env6201 = env6202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6201 == env6202) = true)

theorem identity6202 : scanCanonicalize (H12AffineFastState.compose env6202 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound6202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6203 : List Nat := [2,4,8,0,10,0,2,14,10,14,1,1,8,11,1,3,10,11,14,1,1,1,11,8,3,11,11,10,0,1,4,0,14,11,10,10]

theorem envBound6203 : H12AffineFastState.Bounded env6203 := by
  intro p hp
  have h : env6203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6202_6203 : H12AffineEnvironment.transform 10 1 env6202 = env6203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env6202 == env6203) = true)

theorem identity6203 : scanCanonicalize (H12AffineFastState.compose env6203 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6203 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6204 : List Nat := [2,4,2,0,0,0,2,4,0,4,1,1,2,1,1,3,0,1,4,1,1,1,1,2,3,1,1,0,0,1,4,0,4,1,0,0]

theorem envBound6204 : H12AffineFastState.Bounded env6204 := by
  intro p hp
  have h : env6204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6203_6204 : H12AffineEnvironment.transform 2 2 env6203 = env6204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6203 == env6204) = true)

def env6205 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,4096,8192,16384,13728,25899,4525,262144,1024,13728,4096,4194304,4194337,5515,8329,4194337,279841,16385,16813,22560,16640,17581,256,20481,4195617,4195213]

theorem envBound6205 : H12AffineFastState.Bounded env6205 := by
  intro p hp
  have h : env6205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6179_6205 : H12AffineEnvironment.transform 3 1 env6179 = env6205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6179 == env6205) = true)

theorem identity6205 : scanCanonicalize (H12AffineFastState.compose env6205 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound6205 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6206 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1196,8192,16384,8460,25899,1281,262144,1024,8460,1196,4194304,4194337,295,8329,4194337,279841,16385,16813,19596,16640,17581,256,17581,4195617,4195213]

theorem envBound6206 : H12AffineFastState.Bounded env6206 := by
  intro p hp
  have h : env6206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6205_6206 : H12AffineEnvironment.transform 11 1196 env6205 = env6206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env6205 == env6206) = true)

theorem identity6206 : scanCanonicalize (H12AffineFastState.compose env6206 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6206 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6207 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,8200,25647,1029,262144,1024,8200,1196,4194304,4194337,35,8329,4194337,279589,16385,16553,19596,16388,17581,4,17581,4195365,4194953]

theorem envBound6207 : H12AffineFastState.Bounded env6207 := by
  intro p hp
  have h : env6207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6206_6207 : H12AffineEnvironment.transform 7 4 env6206 = env6207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6206 == env6207) = true)

theorem identity6207 : scanCanonicalize (H12AffineFastState.compose env6207 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6207 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6208 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,8200,25647,1029,2185,1024,8200,1196,4194304,4194337,35,8329,4194337,19628,16385,16553,19596,16388,17581,4,17581,4195365,4194953]

theorem envBound6208 : H12AffineFastState.Bounded env6208 := by
  intro p hp
  have h : env6208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6207_6208 : H12AffineEnvironment.transform 17 2185 env6207 = env6208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6207 == env6208) = true)

theorem identity6208 : scanCanonicalize (H12AffineFastState.compose env6208 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6208 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6209 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,16384,8200,25614,1029,2185,1024,8200,1165,4194304,4194304,2,8329,4194304,19597,16385,16520,19596,16388,17548,4,17548,4195332,4194953]

theorem envBound6209 : H12AffineFastState.Bounded env6209 := by
  intro p hp
  have h : env6209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6208_6209 : H12AffineEnvironment.transform 4 1 env6208 = env6209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6208 == env6209) = true)

theorem identity6209 : scanCanonicalize (H12AffineFastState.compose env6209 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 27654) := by decide +kernel

theorem selectedBound6209 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6210 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,16384,8200,25614,1029,2185,1024,8200,1165,27654,27654,2,8329,27654,19597,16385,16520,19596,16388,17548,4,17548,26626,28303]

theorem envBound6210 : H12AffineFastState.Bounded env6210 := by
  intro p hp
  have h : env6210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6209_6210 : H12AffineEnvironment.transform 21 27654 env6209 = env6210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27654 env6209 == env6210) = true)

theorem identity6210 : scanCanonicalize (H12AffineFastState.compose env6210 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 11396) := by decide +kernel

theorem selectedBound6210 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6211 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,8192,11396,8200,2186,1029,2185,1024,8200,1165,130,130,2,8329,130,8201,11397,11276,8200,11392,10248,4,10248,1158,523]

theorem envBound6211 : H12AffineFastState.Bounded env6211 := by
  intro p hp
  have h : env6211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6210_6211 : H12AffineEnvironment.transform 13 11396 env6210 = env6211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11396 env6210 == env6211) = true)

theorem identity6211 : scanCanonicalize (H12AffineFastState.compose env6211 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound6211 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env6212 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1165,2056,1164,2048,2186,1029,2185,1024,2048,1165,130,130,2,2177,130,2049,1165,1028,2048,1160,0,4,0,1158,523]

theorem envBound6212 : H12AffineFastState.Bounded env6212 := by
  intro p hp
  have h : env6212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6211_6212 : H12AffineEnvironment.transform 12 2056 env6211 = env6212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env6211 == env6212) = true)

theorem identity6212 : scanCanonicalize (H12AffineFastState.compose env6212 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6212 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6213 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1029,2056,1028,2048,2050,1029,2049,1024,2048,1029,10,10,2,2057,10,2049,1029,1028,2048,1024,0,4,0,1038,523]

theorem envBound6213 : H12AffineFastState.Bounded env6213 := by
  intro p hp
  have h : env6213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6212_6213 : H12AffineEnvironment.transform 6 8 env6212 = env6213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6212 == env6213) = true)

theorem identity6213 : scanCanonicalize (H12AffineFastState.compose env6213 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound6213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6214 : List Nat := [2,4,8,1,1,1,8,4,512,1024,1039,1029,1031,1028,1039,1037,1029,1038,1024,1039,1029,10,10,2,1030,10,1038,1029,1028,1039,1024,0,4,0,1038,523]

theorem envBound6214 : H12AffineFastState.Bounded env6214 := by
  intro p hp
  have h : env6214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6213_6214 : H12AffineEnvironment.transform 10 1039 env6213 = env6214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env6213 == env6214) = true)

def env6215 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,4240785,41003,8329,4240785,323713,16385,16813,22560,16657,17580,256,20481,4239489,4240940]

theorem envBound6215 : H12AffineFastState.Bounded env6215 := by
  intro p hp
  have h : env6215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6177_6215 : H12AffineEnvironment.transform 22 4240785 env6177 = env6215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240785 env6177 == env6215) = true)

theorem identity6215 : scanCanonicalize (H12AffineFastState.compose env6215 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound6215 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6216 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13341,25914,4525,262144,1024,13341,4096,4194304,4194700,5174,8329,4194700,279708,16385,16813,22560,16657,17580,256,20481,4195484,4194865]

theorem envBound6216 : H12AffineFastState.Bounded env6216 := by
  intro p hp
  have h : env6216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6215_6216 : H12AffineEnvironment.transform 14 13341 env6215 = env6216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env6215 == env6216) = true)

def env6217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1280,8192,16384,8477,25914,1197,262144,1024,8477,1280,4194304,4194700,310,8329,4194700,279708,16385,16813,19744,16657,17580,256,17665,4195484,4194865]

theorem envBound6217 : H12AffineFastState.Bounded env6217 := by
  intro p hp
  have h : env6217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6216_6217 : H12AffineEnvironment.transform 11 1280 env6216 = env6217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env6216 == env6217) = true)

theorem identity6217 : scanCanonicalize (H12AffineFastState.compose env6217 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6217 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6218 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1197,8192,16384,8368,25751,1197,262144,1024,8368,1197,4194304,4194337,155,8329,4194337,279708,16385,16384,19597,16572,17580,173,17580,4195484,4194865]

theorem envBound6218 : H12AffineFastState.Bounded env6218 := by
  intro p hp
  have h : env6218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6217_6218 : H12AffineEnvironment.transform 7 173 env6217 = env6218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6217 == env6218) = true)

theorem identity6218 : scanCanonicalize (H12AffineFastState.compose env6218 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6218 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6219 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8217,25662,1028,262144,1024,8217,1028,4194304,4194337,50,8224,4194337,279605,16385,16384,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6219 : H12AffineFastState.Bounded env6219 := by
  intro p hp
  have h : env6219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6218_6219 : H12AffineEnvironment.transform 6 41 env6218 = env6219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6218 == env6219) = true)

theorem identity6219 : scanCanonicalize (H12AffineFastState.compose env6219 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound6219 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6220 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8217,25662,1028,19508,1024,8217,1028,4194304,4194337,50,8224,4194337,2049,16385,16384,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6220 : H12AffineFastState.Bounded env6220 := by
  intro p hp
  have h : env6220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6219_6220 : H12AffineEnvironment.transform 17 19508 env6219 = env6220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env6219 == env6220) = true)

theorem identity6220 : scanCanonicalize (H12AffineFastState.compose env6220 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 24601) := by decide +kernel

theorem selectedBound6220 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env6221 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,16384,8217,25662,1028,19508,1024,8217,1028,24601,24632,50,8224,24632,2049,16385,16384,19492,16405,17413,4,17413,25644,25128]

theorem envBound6221 : H12AffineFastState.Bounded env6221 := by
  intro p hp
  have h : env6221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6220_6221 : H12AffineEnvironment.transform 21 24601 env6220 = env6221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 24601 env6220 == env6221) = true)

theorem identity6221 : scanCanonicalize (H12AffineFastState.compose env6221 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(13+1) ^^^ 8739) := by decide +kernel

theorem selectedBound6221 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env6222 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,8192,8739,8217,1565,1028,11799,1024,8217,1028,570,539,50,8224,539,2049,8738,8739,11783,8758,9766,4,9766,1551,11]

theorem envBound6222 : H12AffineFastState.Bounded env6222 := by
  intro p hp
  have h : env6222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6221_6222 : H12AffineEnvironment.transform 13 8739 env6221 = env6222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8739 env6221 == env6222) = true)

theorem identity6222 : scanCanonicalize (H12AffineFastState.compose env6222 (packedSelected [0,2,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound6222 : packedSelected [0,2,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env6223 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1028,1574,1029,1599,1565,1028,2097,1024,1599,1028,570,539,50,1542,539,2049,1028,1029,2081,1040,0,4,0,1551,11]

theorem envBound6223 : H12AffineFastState.Bounded env6223 := by
  intro p hp
  have h : env6223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6222_6223 : H12AffineEnvironment.transform 12 1574 env6222 = env6223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env6222 == env6223) = true)

theorem identity6223 : scanCanonicalize (H12AffineFastState.compose env6223 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound6223 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6224 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1541,1028,1574,1029,1599,1565,1028,1588,1024,1599,1028,570,539,50,1542,539,1540,1028,1029,1572,1040,0,4,0,1551,11]

theorem envBound6224 : H12AffineFastState.Bounded env6224 := by
  intro p hp
  have h : env6224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6223_6224 : H12AffineEnvironment.transform 10 1541 env6223 = env6224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env6223 == env6224) = true)

theorem identity6224 : scanCanonicalize (H12AffineFastState.compose env6224 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6224 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6225 : List Nat := [2,4,8,16,32,16,41,4,33,1024,1060,1028,1031,1029,1054,1084,1028,1045,1024,1054,1028,27,58,50,1063,58,1061,1028,1029,1029,1040,0,4,0,1070,11]

theorem envBound6225 : H12AffineFastState.Bounded env6225 := by
  intro p hp
  have h : env6225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6224_6225 : H12AffineEnvironment.transform 8 33 env6224 = env6225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6224 == env6225) = true)

theorem identity6225 : scanCanonicalize (H12AffineFastState.compose env6225 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound6225 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6226 : List Nat := [2,4,8,0,32,0,41,4,33,1024,1060,1028,1031,1029,1038,1068,1028,1029,1024,1038,1028,11,42,34,1063,42,1061,1028,1029,1029,1024,0,4,0,1070,11]

theorem envBound6226 : H12AffineFastState.Bounded env6226 := by
  intro p hp
  have h : env6226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6225_6226 : H12AffineEnvironment.transform 3 0 env6225 = env6226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6225 == env6226) = true)

theorem identity6226 : scanCanonicalize (H12AffineFastState.compose env6226 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound6226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6227 : List Nat := [2,4,8,0,32,0,41,4,33,37,1,33,34,32,43,9,33,32,37,43,33,11,42,34,2,42,0,33,32,32,37,0,4,0,11,11]

theorem envBound6227 : H12AffineFastState.Bounded env6227 := by
  intro p hp
  have h : env6227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6226_6227 : H12AffineEnvironment.transform 9 37 env6226 = env6227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env6226 == env6227) = true)

theorem identity6227 : scanCanonicalize (H12AffineFastState.compose env6227 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6227 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6228 : List Nat := [2,4,8,0,11,0,2,4,10,14,1,10,9,11,0,9,10,11,14,0,10,11,1,9,2,1,0,10,11,11,14,0,4,0,11,11]

theorem envBound6228 : H12AffineFastState.Bounded env6228 := by
  intro p hp
  have h : env6228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6227_6228 : H12AffineEnvironment.transform 4 11 env6227 = env6228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6227 == env6228) = true)

theorem identity6228 : scanCanonicalize (H12AffineFastState.compose env6228 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6229 : List Nat := [2,4,6,0,5,0,2,4,4,0,1,4,7,5,0,7,4,5,0,0,4,5,1,7,2,1,0,4,5,5,0,0,4,0,5,5]

theorem envBound6229 : H12AffineFastState.Bounded env6229 := by
  intro p hp
  have h : env6229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6228_6229 : H12AffineEnvironment.transform 2 6 env6228 = env6229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6228 == env6229) = true)

theorem identity6229 : scanCanonicalize (H12AffineFastState.compose env6229 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6230 : List Nat := [2,1,3,0,0,0,2,1,1,0,1,1,2,0,0,2,1,0,0,0,1,0,1,2,2,1,0,1,0,0,0,0,1,0,0,0]

theorem envBound6230 : H12AffineFastState.Bounded env6230 := by
  intro p hp
  have h : env6230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6229_6230 : H12AffineEnvironment.transform 1 1 env6229 = env6230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6229 == env6230) = true)

def env6231 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8476,25914,1196,262144,1024,8476,1281,4194304,4194700,311,8329,4194700,279708,16385,16813,19745,16657,17580,256,17664,4195484,4194865]

theorem envBound6231 : H12AffineFastState.Bounded env6231 := by
  intro p hp
  have h : env6231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6216_6231 : H12AffineEnvironment.transform 11 1281 env6216 = env6231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env6216 == env6231) = true)

theorem identity6231 : scanCanonicalize (H12AffineFastState.compose env6231 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2460) := by decide +kernel

theorem selectedBound6231 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6232 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8476,25914,1196,2460,1024,8476,1281,4194304,4194700,311,8329,4194700,19712,16385,16813,19745,16657,17580,256,17664,4195484,4194865]

theorem envBound6232 : H12AffineFastState.Bounded env6232 := by
  intro p hp
  have h : env6232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6231_6232 : H12AffineEnvironment.transform 17 2460 env6231 = env6232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2460 env6231 == env6232) = true)

theorem identity6232 : scanCanonicalize (H12AffineFastState.compose env6232 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6232 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env6233 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,8192,16384,8476,25914,1029,2357,1024,8476,1281,4194304,4194597,311,8224,4194597,19712,16385,16644,19745,16657,17413,256,17664,4195381,4194865]

theorem envBound6233 : H12AffineFastState.Bounded env6233 := by
  intro p hp
  have h : env6233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6232_6233 : H12AffineEnvironment.transform 6 41 env6232 = env6233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6232 == env6233) = true)

theorem identity6233 : scanCanonicalize (H12AffineFastState.compose env6233 (packedSelected [2,6,7,9,10,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 17712) := by decide +kernel

theorem selectedBound6233 : packedSelected [2,6,7,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6234 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,8192,16384,8476,25914,1029,2357,1024,8476,1281,17712,17429,311,8224,17429,19712,16385,16644,19745,16657,17413,256,17664,16645,18177]

theorem envBound6234 : H12AffineFastState.Bounded env6234 := by
  intro p hp
  have h : env6234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6233_6234 : H12AffineEnvironment.transform 21 17712 env6233 = env6234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17712 env6233 == env6234) = true)

theorem identity6234 : scanCanonicalize (H12AffineFastState.compose env6234 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1817) := by decide +kernel

theorem selectedBound6234 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env6235 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,1817,16384,1541,16931,1029,2357,1024,1541,1281,17712,17429,311,1849,17429,19712,16385,16644,19745,16657,17413,256,17664,16645,18177]

theorem envBound6235 : H12AffineFastState.Bounded env6235 := by
  intro p hp
  have h : env6235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6234_6235 : H12AffineEnvironment.transform 12 1817 env6234 = env6235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1817 env6234 == env6235) = true)

theorem identity6235 : scanCanonicalize (H12AffineFastState.compose env6235 (packedSelected [1,3,6,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 1818) := by decide +kernel

theorem selectedBound6235 : packedSelected [1,3,6,10,12] rootPS < 2^1333 := by decide +kernel

def env6236 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1281,1817,1818,1541,1337,1029,2357,1024,1541,1281,554,783,311,1849,783,2586,1819,1566,2619,1547,799,256,538,1567,27]

theorem envBound6236 : H12AffineFastState.Bounded env6236 := by
  intro p hp
  have h : env6236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6235_6236 : H12AffineEnvironment.transform 13 1818 env6235 = env6236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1818 env6235 == env6236) = true)

theorem identity6236 : scanCanonicalize (H12AffineFastState.compose env6236 (packedSelected [0,1,2,5,9,10,17] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6236 : packedSelected [0,1,2,5,9,10,17] rootPS < 2^1333 := by decide +kernel

def env6237 : List Nat := [2,4,8,16,27,16,18,256,512,1024,2048,1281,1817,1818,1541,1282,1029,2318,1024,1541,1281,529,783,268,1794,783,2586,1819,1566,2560,1547,799,256,538,1567,27]

theorem envBound6237 : H12AffineFastState.Bounded env6237 := by
  intro p hp
  have h : env6237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6236_6237 : H12AffineEnvironment.transform 4 27 env6236 = env6237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6236 == env6237) = true)

theorem identity6237 : scanCanonicalize (H12AffineFastState.compose env6237 (packedSelected [2,3,8,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound6237 : packedSelected [2,3,8,10,20] rootPS < 2^1333 := by decide +kernel

def env6238 : List Nat := [2,4,8,16,27,16,18,20,512,1024,2048,1045,1549,1550,1541,1046,1029,2074,1024,1541,1045,529,539,24,1558,539,2586,1551,1566,2560,1547,523,20,538,1567,27]

theorem envBound6238 : H12AffineFastState.Bounded env6238 := by
  intro p hp
  have h : env6238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6237_6238 : H12AffineEnvironment.transform 7 20 env6237 = env6238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env6237 == env6238) = true)

theorem identity6238 : scanCanonicalize (H12AffineFastState.compose env6238 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6239 : List Nat := [2,4,8,16,27,16,18,20,512,1024,1038,1045,1549,1550,1541,1046,1029,1044,1024,1541,1045,529,539,24,1558,539,1556,1551,1566,1550,1547,523,20,538,1567,27]

theorem envBound6239 : H12AffineFastState.Bounded env6239 := by
  intro p hp
  have h : env6239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6238_6239 : H12AffineEnvironment.transform 10 1038 env6238 = env6239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env6238 == env6239) = true)

theorem identity6239 : scanCanonicalize (H12AffineFastState.compose env6239 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6239 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env6240 : List Nat := [2,4,8,16,27,16,18,20,1,1024,1038,1045,1036,1039,1028,1046,1029,1044,1024,1028,1045,16,26,24,1047,26,1045,1038,1055,1039,1034,10,20,27,1054,27]

theorem envBound6240 : H12AffineFastState.Bounded env6240 := by
  intro p hp
  have h : env6240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6239_6240 : H12AffineEnvironment.transform 8 1 env6239 = env6240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6239 == env6240) = true)

theorem identity6240 : scanCanonicalize (H12AffineFastState.compose env6240 (packedSelected [1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound6240 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env6241 : List Nat := [2,4,8,16,27,16,18,20,1,21,27,0,25,26,17,3,16,1,21,17,0,16,26,24,2,26,0,27,10,26,31,10,20,27,11,27]

theorem envBound6241 : H12AffineFastState.Bounded env6241 := by
  intro p hp
  have h : env6241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6240_6241 : H12AffineEnvironment.transform 9 21 env6240 = env6241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env6240 == env6241) = true)

def env6242 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,4194304,8388608,41003,8329,8388609,323712,16385,16812,22561,16657,12644669,256,20480,4239489,8389564]

theorem envBound6242 : H12AffineFastState.Bounded env6242 := by
  intro p hp
  have h : env6242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6176_6242 : H12AffineEnvironment.transform 5 17 env6176 = env6242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6176 == env6242) = true)

theorem identity6242 : scanCanonicalize (H12AffineFastState.compose env6242 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6242 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6243 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,4194304,444,41003,8329,445,323712,16385,16812,22561,16657,4255873,256,20480,4239489,512]

theorem envBound6243 : H12AffineFastState.Bounded env6243 := by
  intro p hp
  have h : env6243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6242_6243 : H12AffineEnvironment.transform 22 444 env6242 = env6243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6242 == env6243) = true)

theorem identity6243 : scanCanonicalize (H12AffineFastState.compose env6243 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6243 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6244 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4096,41349,444,41003,8329,445,323712,16385,16812,22561,16657,20740,256,20480,4356,512]

theorem envBound6244 : H12AffineFastState.Bounded env6244 := by
  intro p hp
  have h : env6244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6243_6244 : H12AffineEnvironment.transform 21 41349 env6243 = env6244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6243 == env6244) = true)

theorem identity6244 : scanCanonicalize (H12AffineFastState.compose env6244 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6244 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6245 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25914,4524,262144,1024,26261,4096,18192,444,18110,8329,445,267797,16385,16812,22561,16657,20740,256,20480,4356,512]

theorem envBound6245 : H12AffineFastState.Bounded env6245 := by
  intro p hp
  have h : env6245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6244_6245 : H12AffineEnvironment.transform 14 26261 env6244 = env6245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6244 == env6245) = true)

theorem identity6245 : scanCanonicalize (H12AffineFastState.compose env6245 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound6245 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6246 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25914,1044,262144,1024,26261,1464,18192,444,18110,8329,445,263085,16385,16812,19865,16657,17596,256,17848,1212,512]

theorem envBound6246 : H12AffineFastState.Bounded env6246 := by
  intro p hp
  have h : env6246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6245_6246 : H12AffineEnvironment.transform 11 1464 env6245 = env6246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env6245 == env6246) = true)

theorem identity6246 : scanCanonicalize (H12AffineFastState.compose env6246 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound6246 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25914,1044,2340,1024,26261,1464,18192,444,18110,8329,445,2697,16385,16812,19865,16657,17596,256,17848,1212,512]

theorem envBound6247 : H12AffineFastState.Bounded env6247 := by
  intro p hp
  have h : env6247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6246_6247 : H12AffineEnvironment.transform 17 2340 env6246 = env6247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env6246 == env6247) = true)

theorem identity6247 : scanCanonicalize (H12AffineFastState.compose env6247 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound6247 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6248 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1945,8460,8867,1044,2340,1024,8460,1464,137,444,295,8329,445,2697,1944,1589,2560,1672,805,256,545,1212,512]

theorem envBound6248 : H12AffineFastState.Bounded env6248 := by
  intro p hp
  have h : env6248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6247_6248 : H12AffineEnvironment.transform 13 1945 env6247 = env6248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env6247 == env6248) = true)

theorem identity6248 : scanCanonicalize (H12AffineFastState.compose env6248 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6248 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env6249 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1296,8192,1841,8460,8715,1044,2340,1024,8460,1296,33,276,295,8225,277,2593,1840,1589,2560,1568,805,256,545,1044,512]

theorem envBound6249 : H12AffineFastState.Bounded env6249 := by
  intro p hp
  have h : env6249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6248_6249 : H12AffineEnvironment.transform 6 40 env6248 = env6249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6248 == env6249) = true)

theorem identity6249 : scanCanonicalize (H12AffineFastState.compose env6249 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6249 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6250 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1589,8200,8715,1044,2080,1024,8200,1044,33,16,35,8225,17,2593,1588,1589,2560,1568,545,4,545,1044,512]

theorem envBound6250 : H12AffineFastState.Bounded env6250 := by
  intro p hp
  have h : env6250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6249_6250 : H12AffineEnvironment.transform 7 4 env6249 = env6250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6249 == env6250) = true)

theorem identity6250 : scanCanonicalize (H12AffineFastState.compose env6250 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6250 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6251 : List Nat := [2,4,8,16,32,17,40,4,32,1024,2048,1044,8192,1045,8200,8235,1044,2080,1024,8200,1044,33,16,35,8225,17,2049,1044,1045,2080,1024,1,4,1,1044,32]

theorem envBound6251 : H12AffineFastState.Bounded env6251 := by
  intro p hp
  have h : env6251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6250_6251 : H12AffineEnvironment.transform 8 32 env6250 = env6251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6250 == env6251) = true)

theorem identity6251 : scanCanonicalize (H12AffineFastState.compose env6251 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound6251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6252 : List Nat := [2,4,8,16,32,17,40,4,32,1024,2048,1044,2098,1045,2106,2073,1044,2080,1024,2106,1044,33,16,35,2067,17,2049,1044,1045,2080,1024,1,4,1,1044,32]

theorem envBound6252 : H12AffineFastState.Bounded env6252 := by
  intro p hp
  have h : env6252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6251_6252 : H12AffineEnvironment.transform 12 2098 env6251 = env6252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env6251 == env6252) = true)

theorem identity6252 : scanCanonicalize (H12AffineFastState.compose env6252 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6253 : List Nat := [2,4,8,16,27,17,19,4,27,1024,2048,1044,2057,1045,2049,2073,1044,2075,1024,2049,1044,26,16,24,2067,17,2049,1044,1045,2075,1024,1,4,1,1044,27]

theorem envBound6253 : H12AffineFastState.Bounded env6253 := by
  intro p hp
  have h : env6253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6252_6253 : H12AffineEnvironment.transform 4 27 env6252 = env6253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6252 == env6253) = true)

theorem identity6253 : scanCanonicalize (H12AffineFastState.compose env6253 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound6253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6254 : List Nat := [2,4,8,16,27,17,19,4,27,20,2048,0,2057,1,2049,2073,0,2075,20,2049,0,26,16,24,2067,17,2049,0,1,2075,20,1,4,1,0,27]

theorem envBound6254 : H12AffineFastState.Bounded env6254 := by
  intro p hp
  have h : env6254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6253_6254 : H12AffineEnvironment.transform 9 20 env6253 = env6254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env6253 == env6254) = true)

theorem identity6254 : scanCanonicalize (H12AffineFastState.compose env6254 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound6254 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6255 : List Nat := [2,4,8,16,27,17,19,4,27,20,26,0,19,1,27,3,0,1,20,27,0,26,16,24,9,17,27,0,1,1,20,1,4,1,0,27]

theorem envBound6255 : H12AffineFastState.Bounded env6255 := by
  intro p hp
  have h : env6255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6254_6255 : H12AffineEnvironment.transform 10 26 env6254 = env6255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env6254 == env6255) = true)

theorem identity6255 : scanCanonicalize (H12AffineFastState.compose env6255 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6255 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6256 : List Nat := [2,4,8,11,0,10,8,4,0,15,1,0,8,1,0,3,0,1,15,0,0,1,11,3,9,10,0,0,1,1,15,1,4,1,0,0]

theorem envBound6256 : H12AffineFastState.Bounded env6256 := by
  intro p hp
  have h : env6256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6255_6256 : H12AffineEnvironment.transform 3 11 env6255 = env6256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6255 == env6256) = true)

def env6257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323792,16385,16893,22641,74794,12644669,257,20560,4239489,8389612]

theorem envBound6257 : H12AffineFastState.Bounded env6257 := by
  intro p hp
  have h : env6257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6174_6257 : H12AffineEnvironment.transform 18 1025 env6174 = env6257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6174 == env6257) = true)

theorem identity6257 : scanCanonicalize (H12AffineFastState.compose env6257 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73786) := by decide +kernel

theorem selectedBound6257 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,73786,41003,8329,73835,323792,16385,16893,22641,74794,4313351,257,20560,4239489,74710]

theorem envBound6258 : H12AffineFastState.Bounded env6258 := by
  intro p hp
  have h : env6258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6257_6258 : H12AffineEnvironment.transform 22 73786 env6257 = env6258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73786 env6257 == env6258) = true)

def env6259 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,73786,41003,8329,73787,323712,16385,16813,22561,74794,4313351,257,20480,4239489,74630]

theorem envBound6259 : H12AffineFastState.Bounded env6259 := by
  intro p hp
  have h : env6259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6258_6259 : H12AffineEnvironment.transform 5 16 env6258 = env6259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6258 == env6259) = true)

theorem identity6259 : scanCanonicalize (H12AffineFastState.compose env6259 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound6259 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6260 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1025,32768,4096,4194304,444,41003,8329,445,323712,16385,16813,22561,1452,4255873,257,20480,4239489,512]

theorem envBound6260 : H12AffineFastState.Bounded env6260 := by
  intro p hp
  have h : env6260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6259_6260 : H12AffineEnvironment.transform 15 8582 env6259 = env6260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env6259 == env6260) = true)

theorem identity6260 : scanCanonicalize (H12AffineFastState.compose env6260 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6260 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6261 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1025,32768,4096,41348,444,41003,8329,445,323712,16385,16813,22561,1452,20741,257,20480,4357,512]

theorem envBound6261 : H12AffineFastState.Bounded env6261 := by
  intro p hp
  have h : env6261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6260_6261 : H12AffineEnvironment.transform 21 41348 env6260 = env6261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6260 == env6261) = true)

theorem identity6261 : scanCanonicalize (H12AffineFastState.compose env6261 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6261 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8582,4525,262144,1025,26260,4096,18192,444,18111,8329,445,267796,16385,16813,22561,1452,20741,257,20480,4357,512]

theorem envBound6262 : H12AffineFastState.Bounded env6262 := by
  intro p hp
  have h : env6262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6261_6262 : H12AffineEnvironment.transform 14 26260 env6261 = env6262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6261 == env6262) = true)

theorem identity6262 : scanCanonicalize (H12AffineFastState.compose env6262 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound6262 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6263 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,14224,8582,4525,262144,1025,14224,4096,5652,444,6075,8329,445,267796,4357,4265,2341,1452,1,257,260,4357,512]

theorem envBound6263 : H12AffineFastState.Bounded env6263 := by
  intro p hp
  have h : env6263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6262_6263 : H12AffineEnvironment.transform 13 4356 env6262 = env6263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env6262 == env6263) = true)

theorem identity6263 : scanCanonicalize (H12AffineFastState.compose env6263 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6263 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env6264 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,8322,4265,262144,1025,13972,4096,5652,184,5823,8329,185,267796,4097,4265,2081,1192,1,5,0,4097,512]

theorem envBound6264 : H12AffineFastState.Bounded env6264 := by
  intro p hp
  have h : env6264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6263_6264 : H12AffineEnvironment.transform 7 4 env6263 = env6264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6263 == env6264) = true)

theorem identity6264 : scanCanonicalize (H12AffineFastState.compose env6264 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound6264 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6265 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,8322,4265,7869,1025,13972,4096,5652,184,5823,8329,185,2217,4097,4265,2081,1192,1,5,0,4097,512]

theorem envBound6265 : H12AffineFastState.Bounded env6265 := by
  intro p hp
  have h : env6265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6264_6265 : H12AffineEnvironment.transform 17 7869 env6264 = env6265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env6264 == env6265) = true)

theorem identity6265 : scanCanonicalize (H12AffineFastState.compose env6265 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound6265 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6266 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1588,8192,1588,8352,8322,1693,2185,1025,8352,1588,32,184,139,8329,185,2217,1589,1693,2081,1192,1,5,0,1589,512]

theorem envBound6266 : H12AffineFastState.Bounded env6266 := by
  intro p hp
  have h : env6266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6265_6266 : H12AffineEnvironment.transform 11 1588 env6265 = env6266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env6265 == env6266) = true)

theorem identity6266 : scanCanonicalize (H12AffineFastState.compose env6266 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 155) := by decide +kernel

theorem selectedBound6266 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6267 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1588,155,1588,59,25,1693,2185,1025,59,1588,32,184,139,18,185,2217,1589,1693,2081,1192,1,5,0,1589,512]

theorem envBound6267 : H12AffineFastState.Bounded env6267 := by
  intro p hp
  have h : env6267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6266_6267 : H12AffineEnvironment.transform 12 155 env6266 = env6267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 155 env6266 == env6267) = true)

theorem identity6267 : scanCanonicalize (H12AffineFastState.compose env6267 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound6267 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env6268 : List Nat := [2,4,8,16,32,16,128,4,512,1024,691,1588,155,1588,59,25,1693,570,1025,59,1588,32,184,139,18,185,538,1589,1693,658,1192,1,5,0,1589,512]

theorem envBound6268 : H12AffineFastState.Bounded env6268 := by
  intro p hp
  have h : env6268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6267_6268 : H12AffineEnvironment.transform 10 691 env6267 = env6268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env6267 == env6268) = true)

theorem identity6268 : scanCanonicalize (H12AffineFastState.compose env6268 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6268 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env6269 : List Nat := [2,4,8,10,32,10,128,4,512,1024,681,1582,129,1582,33,3,1671,544,1025,33,1582,32,162,139,8,163,512,1583,1671,648,1192,1,5,0,1583,512]

theorem envBound6269 : H12AffineFastState.Bounded env6269 := by
  intro p hp
  have h : env6269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6268_6269 : H12AffineEnvironment.transform 3 10 env6268 = env6269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6268 == env6269) = true)

theorem identity6269 : scanCanonicalize (H12AffineFastState.compose env6269 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6269 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env6270 : List Nat := [2,4,8,10,32,10,8,4,512,1024,545,1582,9,1582,33,3,1551,544,1025,33,1582,32,42,3,8,43,512,1583,1551,512,1056,1,5,0,1583,512]

theorem envBound6270 : H12AffineFastState.Bounded env6270 := by
  intro p hp
  have h : env6270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6269_6270 : H12AffineEnvironment.transform 6 8 env6269 = env6270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6269 == env6270) = true)

theorem identity6270 : scanCanonicalize (H12AffineFastState.compose env6270 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6270 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6271 : List Nat := [2,4,8,10,0,10,8,4,512,1024,513,1550,9,1550,1,3,1551,512,1025,1,1550,0,10,3,8,11,512,1551,1551,512,1024,1,5,0,1551,512]

theorem envBound6271 : H12AffineFastState.Bounded env6271 := by
  intro p hp
  have h : env6271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6270_6271 : H12AffineEnvironment.transform 4 0 env6270 = env6271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6270 == env6271) = true)

theorem identity6271 : scanCanonicalize (H12AffineFastState.compose env6271 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6272 : List Nat := [2,4,8,10,0,10,8,4,11,1024,10,1029,9,1029,1,3,1028,11,1025,1,1029,0,10,3,8,11,11,1028,1028,11,1024,1,5,0,1028,11]

theorem envBound6272 : H12AffineFastState.Bounded env6272 := by
  intro p hp
  have h : env6272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6271_6272 : H12AffineEnvironment.transform 8 11 env6271 = env6272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6271 == env6272) = true)

theorem identity6272 : scanCanonicalize (H12AffineFastState.compose env6272 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6272 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6273 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,2,1029,1,3,1028,0,1025,1,1029,0,1,3,3,0,0,1028,1028,0,1024,1,5,0,1028,0]

theorem envBound6273 : H12AffineFastState.Bounded env6273 := by
  intro p hp
  have h : env6273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6272_6273 : H12AffineEnvironment.transform 2 3 env6272 = env6273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6272 == env6273) = true)

def leafEnv6273 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,2,1029,1,3,1028,0,1025,1,1029,0,1,3,1025,3,1,0,0,1028,1028,0,1024,1,5,0,5,3,1028,0,1,1029,0]

def active6273 : List Nat := [0,1,9]

def tree6273 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6273 : H12WitnessSearch.Good tree6273 := H12GlobalWitnessIndex.good

theorem leafIdentity6273 : H12AffineFastState.composeSystem env6273 rootObs = leafEnv6273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6273 rootObs == leafEnv6273) = true)

theorem terminalChecked6273 : H12PackedTerminal.terminalCheckFast leafEnv6273 active6273 tree6273 = true := by decide +kernel

def env6274 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,73786,41003,8329,73786,323713,16385,16812,22560,74794,4313351,257,20481,4239489,74631]

theorem envBound6274 : H12AffineFastState.Bounded env6274 := by
  intro p hp
  have h : env6274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6258_6274 : H12AffineEnvironment.transform 5 17 env6258 = env6274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6258 == env6274) = true)

def env6275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,41088,73786,41003,8329,73786,323713,16385,16812,22560,74794,94599,257,20481,4097,74631]

theorem envBound6275 : H12AffineFastState.Bounded env6275 := by
  intro p hp
  have h : env6275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6274_6275 : H12AffineEnvironment.transform 21 41088 env6274 = env6275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6274 == env6275) = true)

theorem identity6275 : scanCanonicalize (H12AffineFastState.compose env6275 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound6275 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,4524,262144,1025,32768,4096,41088,185,41003,8329,185,323713,16385,16812,22560,1193,20740,257,20481,4097,772]

theorem envBound6276 : H12AffineFastState.Bounded env6276 := by
  intro p hp
  have h : env6276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6275_6276 : H12AffineEnvironment.transform 15 8323 env6275 = env6276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env6275 == env6276) = true)

theorem identity6276 : scanCanonicalize (H12AffineFastState.compose env6276 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 61361) := by decide +kernel

theorem selectedBound6276 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6277 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8323,4524,61361,1025,32768,4096,41088,185,41003,8329,185,7984,16385,16812,22560,1193,20740,257,20481,4097,772]

theorem envBound6277 : H12AffineFastState.Bounded env6277 := by
  intro p hp
  have h : env6277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6276_6277 : H12AffineEnvironment.transform 17 61361 env6276 = env6277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61361 env6276 == env6277) = true)

theorem identity6277 : scanCanonicalize (H12AffineFastState.compose env6277 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound6277 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1945,8192,16384,32768,8323,1589,61361,1025,32768,1945,41088,185,41003,8329,185,2217,16385,16812,20409,1193,18077,257,18328,1944,772]

theorem envBound6278 : H12AffineFastState.Bounded env6278 := by
  intro p hp
  have h : env6278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6277_6278 : H12AffineEnvironment.transform 11 1945 env6277 = env6278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env6277 == env6278) = true)

theorem identity6278 : scanCanonicalize (H12AffineFastState.compose env6278 (packedSelected [1,4,5,7,8,9,13,21,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6278 : packedSelected [1,4,5,7,8,9,13,21,24,27] rootPS < 2^1333 := by decide +kernel

def env6279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1945,8192,16384,26261,8323,1589,2340,1025,26261,1945,17941,185,18110,8329,185,2217,16385,16812,20409,1193,18077,257,18328,1944,772]

theorem envBound6279 : H12AffineFastState.Bounded env6279 := by
  intro p hp
  have h : env6279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6278_6279 : H12AffineEnvironment.transform 14 26261 env6278 = env6279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6278 == env6279) = true)

theorem identity6279 : scanCanonicalize (H12AffineFastState.compose env6279 (packedSelected [0,1,2,6,7,8,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound6279 : packedSelected [0,1,2,6,7,8,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6280 : List Nat := [2,4,8,16,32,17,18,256,512,1024,2048,1803,8192,16384,26119,8209,1589,2340,1025,26119,1803,17941,43,17964,8219,43,2107,16385,16702,20267,1083,17935,257,18186,1802,772]

theorem envBound6280 : H12AffineFastState.Bounded env6280 := by
  intro p hp
  have h : env6280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6279_6280 : H12AffineEnvironment.transform 6 18 env6279 = env6280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env6279 == env6280) = true)

theorem identity6280 : scanCanonicalize (H12AffineFastState.compose env6280 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound6280 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env6281 : List Nat := [2,4,8,16,32,17,18,256,512,1024,2048,1803,8192,1841,8502,8209,1589,2340,1025,8502,1803,292,43,285,8219,43,2107,1840,1551,2074,1083,318,257,59,1802,772]

theorem envBound6281 : H12AffineFastState.Bounded env6281 := by
  intro p hp
  have h : env6281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6280_6281 : H12AffineEnvironment.transform 13 1841 env6280 = env6281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env6280 == env6281) = true)

theorem identity6281 : scanCanonicalize (H12AffineFastState.compose env6281 (packedSelected [2,3,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound6281 : packedSelected [2,3,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env6282 : List Nat := [2,4,8,16,32,17,18,46,512,1024,2048,1573,8192,1567,8216,8209,1589,2058,1025,8216,1573,10,43,51,8219,43,2107,1566,1551,2074,1083,16,47,59,1572,554]

theorem envBound6282 : H12AffineFastState.Bounded env6282 := by
  intro p hp
  have h : env6282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6281_6282 : H12AffineEnvironment.transform 7 46 env6281 = env6282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env6281 == env6282) = true)

theorem identity6282 : scanCanonicalize (H12AffineFastState.compose env6282 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6282 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6283 : List Nat := [2,4,8,1,32,0,3,46,512,1024,2048,1573,8192,1550,8201,8192,1572,2058,1025,8201,1573,10,43,34,8202,43,2090,1551,1551,2059,1066,1,47,42,1572,554]

theorem envBound6283 : H12AffineFastState.Bounded env6283 := by
  intro p hp
  have h : env6283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6282_6283 : H12AffineEnvironment.transform 3 1 env6282 = env6283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6282 == env6283) = true)

theorem identity6283 : scanCanonicalize (H12AffineFastState.compose env6283 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2594) := by decide +kernel

theorem selectedBound6283 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env6284 : List Nat := [2,4,8,1,32,0,3,46,512,1024,2048,1573,2594,1550,2603,2594,1572,2058,1025,2603,1573,10,43,34,2600,43,2090,1551,1551,2059,1066,1,47,42,1572,554]

theorem envBound6284 : H12AffineFastState.Bounded env6284 := by
  intro p hp
  have h : env6284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6283_6284 : H12AffineEnvironment.transform 12 2594 env6283 = env6284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2594 env6283 == env6284) = true)

def env6285 : List Nat := [2,4,8,1,32,0,3,46,512,1024,1572,1573,1030,1550,1039,1030,1572,1582,1025,1039,1573,10,43,34,1036,43,1550,1551,1551,1583,1066,1,47,42,1572,554]

theorem envBound6285 : H12AffineFastState.Bounded env6285 := by
  intro p hp
  have h : env6285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6284_6285 : H12AffineEnvironment.transform 10 1572 env6284 = env6285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env6284 == env6285) = true)

def env6286 : List Nat := [2,4,8,1,32,0,3,46,0,1024,1060,1061,1030,1038,1039,1030,1060,1070,1025,1039,1061,10,43,34,1036,43,1038,1039,1039,1071,1066,1,47,42,1060,42]

theorem envBound6286 : H12AffineFastState.Bounded env6286 := by
  intro p hp
  have h : env6286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6285_6286 : H12AffineEnvironment.transform 8 0 env6285 = env6286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6285 == env6286) = true)

theorem identity6286 : scanCanonicalize (H12AffineFastState.compose env6286 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound6286 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6287 : List Nat := [2,4,8,1,32,0,3,46,0,36,0,1,34,42,43,34,0,10,37,43,1,10,43,34,40,43,42,43,43,11,14,1,47,42,0,42]

theorem envBound6287 : H12AffineFastState.Bounded env6287 := by
  intro p hp
  have h : env6287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6286_6287 : H12AffineEnvironment.transform 9 36 env6286 = env6287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env6286 == env6287) = true)

def env6288 : List Nat := [2,0,8,1,32,0,3,42,0,32,0,1,34,42,43,34,0,10,33,43,1,10,43,34,40,43,42,43,43,11,10,1,43,42,0,42]

theorem envBound6288 : H12AffineFastState.Bounded env6288 := by
  intro p hp
  have h : env6288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6287_6288 : H12AffineEnvironment.transform 1 0 env6287 = env6288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6287 == env6288) = true)

theorem identity6288 : scanCanonicalize (H12AffineFastState.compose env6288 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6289 : List Nat := [2,0,8,1,10,0,3,0,0,10,0,1,8,0,1,8,0,10,11,1,1,10,1,8,2,1,0,1,1,11,10,1,1,0,0,0]

theorem envBound6289 : H12AffineFastState.Bounded env6289 := by
  intro p hp
  have h : env6289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6288_6289 : H12AffineEnvironment.transform 4 10 env6288 = env6289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6288 == env6289) = true)

theorem identity6289 : scanCanonicalize (H12AffineFastState.compose env6289 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6289 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6290 : List Nat := [2,0,2,1,0,0,3,0,0,0,0,1,2,0,1,2,0,0,1,1,1,0,1,2,2,1,0,1,1,1,0,1,1,0,0,0]

theorem envBound6290 : H12AffineFastState.Bounded env6290 := by
  intro p hp
  have h : env6290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6289_6290 : H12AffineEnvironment.transform 2 2 env6289 = env6290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6289 == env6290) = true)

def leafEnv6290 : List Nat := [2,0,2,1,0,0,3,0,0,0,0,1,2,0,1,2,0,0,1,1,1,0,1,2,1,2,1,1,0,1,1,1,0,1,1,0,1,3,0,0,1,0,0]

def active6290 : List Nat := [0]

def tree6290 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6290 : H12WitnessSearch.Good tree6290 := H12GlobalWitnessIndex.good

theorem leafIdentity6290 : H12AffineFastState.composeSystem env6290 rootObs = leafEnv6290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6290 rootObs == leafEnv6290) = true)

theorem terminalChecked6290 : H12PackedTerminal.terminalCheckFast leafEnv6290 active6290 tree6290 = true := by decide +kernel

def env6291 : List Nat := [2,1,8,1,32,0,3,43,0,33,0,1,34,42,43,34,0,10,32,43,1,10,43,34,40,43,42,43,43,11,11,1,42,42,0,42]

theorem envBound6291 : H12AffineFastState.Bounded env6291 := by
  intro p hp
  have h : env6291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6287_6291 : H12AffineEnvironment.transform 1 1 env6287 = env6291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6287 == env6291) = true)

def env6292 : List Nat := [2,1,8,1,0,0,3,11,0,1,0,1,2,10,11,2,0,10,0,11,1,10,11,2,8,11,10,11,11,11,11,1,10,10,0,10]

theorem envBound6292 : H12AffineFastState.Bounded env6292 := by
  intro p hp
  have h : env6292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6291_6292 : H12AffineEnvironment.transform 4 0 env6291 = env6292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6291 == env6292) = true)

def leafEnv6292 : List Nat := [2,1,8,1,0,0,3,11,0,1,0,1,2,10,11,2,0,10,0,11,1,10,11,2,10,8,1,11,10,11,11,11,11,1,10,10,0,3,0,10,1,0,0]

def active6292 : List Nat := [0,2]

def tree6292 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6292 : H12WitnessSearch.Good tree6292 := H12GlobalWitnessIndex.good

theorem leafIdentity6292 : H12AffineFastState.composeSystem env6292 rootObs = leafEnv6292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6292 rootObs == leafEnv6292) = true)

theorem terminalChecked6292 : H12PackedTerminal.terminalCheckFast leafEnv6292 active6292 tree6292 = true := by decide +kernel

def env6293 : List Nat := [2,1,8,1,1,0,3,10,0,0,0,1,3,11,10,3,0,10,1,10,1,10,10,3,9,10,11,10,10,11,11,1,11,11,0,11]

theorem envBound6293 : H12AffineFastState.Bounded env6293 := by
  intro p hp
  have h : env6293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6291_6293 : H12AffineEnvironment.transform 4 1 env6291 = env6293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6291 == env6293) = true)

theorem identity6293 : scanCanonicalize (H12AffineFastState.compose env6293 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6293 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6294 : List Nat := [2,1,2,1,1,0,3,0,0,0,0,1,3,1,0,3,0,0,1,0,1,0,0,3,3,0,1,0,0,1,1,1,1,1,0,1]

theorem envBound6294 : H12AffineFastState.Bounded env6294 := by
  intro p hp
  have h : env6294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6293_6294 : H12AffineEnvironment.transform 2 2 env6293 = env6294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6293 == env6294) = true)

def leafEnv6294 : List Nat := [2,1,2,1,1,0,3,0,0,0,0,1,3,1,0,3,0,0,1,0,1,0,0,3,0,3,1,0,1,0,0,1,1,1,1,1,0,3,0,1,1,0,0]

def active6294 : List Nat := [0]

def tree6294 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6294 : H12WitnessSearch.Good tree6294 := H12GlobalWitnessIndex.good

theorem leafIdentity6294 : H12AffineFastState.composeSystem env6294 rootObs = leafEnv6294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6294 rootObs == leafEnv6294) = true)

theorem terminalChecked6294 : H12PackedTerminal.terminalCheckFast leafEnv6294 active6294 tree6294 = true := by decide +kernel

def env6295 : List Nat := [2,4,8,1,32,0,3,46,1,1024,1061,1060,1030,1039,1039,1030,1061,1071,1025,1039,1060,10,43,34,1036,43,1039,1038,1038,1070,1066,1,47,42,1061,43]

theorem envBound6295 : H12AffineFastState.Bounded env6295 := by
  intro p hp
  have h : env6295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6285_6295 : H12AffineEnvironment.transform 8 1 env6285 = env6295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6285 == env6295) = true)

theorem identity6295 : scanCanonicalize (H12AffineFastState.compose env6295 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound6295 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6296 : List Nat := [2,4,8,1,32,0,3,46,1,47,10,11,41,32,32,41,10,0,46,32,11,10,43,34,35,43,32,33,33,1,5,1,47,42,10,43]

theorem envBound6296 : H12AffineFastState.Bounded env6296 := by
  intro p hp
  have h : env6296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6295_6296 : H12AffineEnvironment.transform 9 47 env6295 = env6296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env6295 == env6296) = true)

theorem identity6296 : scanCanonicalize (H12AffineFastState.compose env6296 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6296 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6297 : List Nat := [2,4,8,1,11,0,3,5,1,4,10,11,2,11,11,2,10,0,5,11,11,10,0,9,8,0,11,10,10,1,5,1,4,1,10,0]

theorem envBound6297 : H12AffineFastState.Bounded env6297 := by
  intro p hp
  have h : env6297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6296_6297 : H12AffineEnvironment.transform 4 11 env6296 = env6297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6296 == env6297) = true)

theorem identity6297 : scanCanonicalize (H12AffineFastState.compose env6297 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6298 : List Nat := [2,1,8,1,11,0,3,0,1,1,10,11,2,11,11,2,10,0,0,11,11,10,0,9,8,0,11,10,10,1,0,1,1,1,10,0]

theorem envBound6298 : H12AffineFastState.Bounded env6298 := by
  intro p hp
  have h : env6298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6297_6298 : H12AffineEnvironment.transform 1 1 env6297 = env6298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6297 == env6298) = true)

def env6299 : List Nat := [2,4,8,1,32,0,3,46,512,1024,1573,1573,1031,1550,1038,1031,1572,1583,1025,1038,1573,10,43,34,1037,43,1551,1551,1551,1582,1066,1,47,42,1572,554]

theorem envBound6299 : H12AffineFastState.Bounded env6299 := by
  intro p hp
  have h : env6299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6284_6299 : H12AffineEnvironment.transform 10 1573 env6284 = env6299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env6284 == env6299) = true)

theorem identity6299 : scanCanonicalize (H12AffineFastState.compose env6299 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6300 : List Nat := [2,4,8,1,10,0,3,4,512,1024,1551,1551,1031,1550,1038,1031,1550,1541,1025,1038,1551,10,1,8,1037,1,1551,1551,1551,1540,1024,1,5,0,1550,512]

theorem envBound6300 : H12AffineFastState.Bounded env6300 := by
  intro p hp
  have h : env6300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6299_6300 : H12AffineEnvironment.transform 4 10 env6299 = env6300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6299 == env6300) = true)

theorem identity6300 : scanCanonicalize (H12AffineFastState.compose env6300 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6300 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env6301 : List Nat := [2,4,2,1,0,0,3,4,512,1024,1541,1541,1031,1540,1028,1031,1540,1541,1025,1028,1541,0,1,2,1031,1,1541,1541,1541,1540,1024,1,5,0,1540,512]

theorem envBound6301 : H12AffineFastState.Bounded env6301 := by
  intro p hp
  have h : env6301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6300_6301 : H12AffineEnvironment.transform 2 2 env6300 = env6301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6300 == env6301) = true)

theorem identity6301 : scanCanonicalize (H12AffineFastState.compose env6301 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6302 : List Nat := [2,4,2,1,0,0,3,4,0,1024,1029,1029,1031,1028,1028,1031,1028,1029,1025,1028,1029,0,1,2,1031,1,1029,1029,1029,1028,1024,1,5,0,1028,0]

theorem envBound6302 : H12AffineFastState.Bounded env6302 := by
  intro p hp
  have h : env6302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6301_6302 : H12AffineEnvironment.transform 8 0 env6301 = env6302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6301 == env6302) = true)

theorem identity6302 : scanCanonicalize (H12AffineFastState.compose env6302 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6302 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6303 : List Nat := [2,4,2,1,0,0,3,4,0,5,0,0,2,1,1,2,1,0,4,1,0,0,1,2,2,1,0,0,0,1,5,1,5,0,1,0]

theorem envBound6303 : H12AffineFastState.Bounded env6303 := by
  intro p hp
  have h : env6303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6302_6303 : H12AffineEnvironment.transform 9 5 env6302 = env6303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6302 == env6303) = true)

def leafEnv6303 : List Nat := [2,4,2,1,0,0,3,4,0,5,0,0,2,1,1,2,1,0,4,1,0,0,1,2,4,2,1,1,0,0,0,1,5,1,5,0,5,3,1,0,1,1,0]

def active6303 : List Nat := [0,1]

def tree6303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6303 : H12WitnessSearch.Good tree6303 := H12GlobalWitnessIndex.good

theorem leafIdentity6303 : H12AffineFastState.composeSystem env6303 rootObs = leafEnv6303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6303 rootObs == leafEnv6303) = true)

theorem terminalChecked6303 : H12PackedTerminal.terminalCheckFast leafEnv6303 active6303 tree6303 = true := by decide +kernel

def env6304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,41089,73786,41003,8329,73786,323713,16385,16812,22560,74794,94598,257,20481,4096,74631]

theorem envBound6304 : H12AffineFastState.Bounded env6304 := by
  intro p hp
  have h : env6304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6274_6304 : H12AffineEnvironment.transform 21 41089 env6274 = env6304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6274 == env6304) = true)

theorem identity6304 : scanCanonicalize (H12AffineFastState.compose env6304 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6304 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6305 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1025,32768,4096,41089,73786,41003,8329,73786,323713,16385,16553,22560,74794,94339,4,20481,4096,74370]

theorem envBound6305 : H12AffineFastState.Bounded env6305 := by
  intro p hp
  have h : env6305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6304_6305 : H12AffineEnvironment.transform 7 5 env6304 = env6305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6304 == env6305) = true)

theorem identity6305 : scanCanonicalize (H12AffineFastState.compose env6305 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 100354) := by decide +kernel

theorem selectedBound6305 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6306 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,65536,4265,100354,1025,32768,4096,41089,73786,41003,8329,73786,96387,16385,16553,22560,74794,94339,4,20481,4096,74370]

theorem envBound6306 : H12AffineFastState.Bounded env6306 := by
  intro p hp
  have h : env6306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6305_6306 : H12AffineEnvironment.transform 17 100354 env6305 = env6306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100354 env6305 == env6306) = true)

theorem identity6306 : scanCanonicalize (H12AffineFastState.compose env6306 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 50711) := by decide +kernel

theorem selectedBound6306 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env6307 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,16384,32768,50711,4265,19989,1025,32768,4096,41089,58925,41003,8329,58925,48788,16385,16553,22560,57917,46740,4,20481,4096,58517]

theorem envBound6307 : H12AffineFastState.Bounded env6307 := by
  intro p hp
  have h : env6307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6306_6307 : H12AffineEnvironment.transform 15 50711 env6306 = env6307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50711 env6306 == env6307) = true)

theorem identity6307 : scanCanonicalize (H12AffineFastState.compose env6307 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6307 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env6308 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1693,8192,16384,32768,50711,1588,19989,1025,32768,1693,41089,58925,41003,8329,58925,43017,16385,16553,20157,57917,40969,4,18076,1693,58517]

theorem envBound6308 : H12AffineFastState.Bounded env6308 := by
  intro p hp
  have h : env6308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6307_6308 : H12AffineEnvironment.transform 11 1693 env6307 = env6308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6307 == env6308) = true)

theorem identity6308 : scanCanonicalize (H12AffineFastState.compose env6308 (packedSelected [0,1,8,10,11,15,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6308 : packedSelected [0,1,8,10,11,15,20,27] rootPS < 2^1333 := by decide +kernel

def env6309 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1693,8192,16384,26261,8322,1588,19989,1025,26261,1693,17940,184,18110,8329,184,20124,16385,16553,20157,1192,18076,4,18076,1693,512]

theorem envBound6309 : H12AffineFastState.Bounded env6309 := by
  intro p hp
  have h : env6309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6308_6309 : H12AffineEnvironment.transform 14 26261 env6308 = env6309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6308 == env6309) = true)

theorem identity6309 : scanCanonicalize (H12AffineFastState.compose env6309 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6309 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6310 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1693,8192,1692,8201,8322,1588,2185,1025,8201,1693,136,184,34,8329,184,2048,1693,1589,2081,1192,0,4,0,1693,512]

theorem envBound6310 : H12AffineFastState.Bounded env6310 := by
  intro p hp
  have h : env6310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6309_6310 : H12AffineEnvironment.transform 13 1692 env6309 = env6310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1692 env6309 == env6310) = true)

def env6311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849104,16385,16893,547953,598059,12644668,525568,545872,4239488,8914925]

theorem envBound6311 : H12AffineFastState.Bounded env6311 := by
  intro p hp
  have h : env6311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6173_6311 : H12AffineEnvironment.transform 20 4097 env6173 = env6311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env6173 == env6311) = true)

def env6312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323792,16385,16893,22641,74795,12644668,256,20560,4239488,8389613]

theorem envBound6312 : H12AffineFastState.Bounded env6312 := by
  intro p hp
  have h : env6312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6311_6312 : H12AffineEnvironment.transform 18 1024 env6311 = env6312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6311 == env6312) = true)

theorem identity6312 : scanCanonicalize (H12AffineFastState.compose env6312 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310443) := by decide +kernel

theorem selectedBound6312 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4310443,41003,8329,4310523,323792,16385,16893,22641,74795,78999,256,20560,4239488,4310598]

theorem envBound6313 : H12AffineFastState.Bounded env6313 := by
  intro p hp
  have h : env6313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6312_6313 : H12AffineEnvironment.transform 22 4310443 env6312 = env6313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310443 env6312 == env6313) = true)

def env6314 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4310443,41003,8329,4310443,323712,16385,16813,22561,74795,78999,256,20480,4239488,4310550]

theorem envBound6314 : H12AffineFastState.Bounded env6314 := by
  intro p hp
  have h : env6314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6313_6314 : H12AffineEnvironment.transform 5 16 env6313 = env6314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6313 == env6314) = true)

theorem identity6314 : scanCanonicalize (H12AffineFastState.compose env6314 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115734) := by decide +kernel

theorem selectedBound6314 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6315 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115734,445,41003,8329,445,323712,16385,16813,22561,74795,78999,256,20480,95382,512]

theorem envBound6315 : H12AffineFastState.Bounded env6315 := by
  intro p hp
  have h : env6315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6314_6315 : H12AffineEnvironment.transform 21 115734 env6314 = env6315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115734 env6314 == env6315) = true)

theorem identity6315 : scanCanonicalize (H12AffineFastState.compose env6315 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound6315 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6316 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1024,32768,4097,41348,445,41003,8329,445,323712,16385,16813,22561,16825,20741,256,20480,4356,512]

theorem envBound6316 : H12AffineFastState.Bounded env6316 := by
  intro p hp
  have h : env6316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6315_6316 : H12AffineEnvironment.transform 15 26002 env6315 = env6316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env6315 == env6316) = true)

theorem identity6316 : scanCanonicalize (H12AffineFastState.compose env6316 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6316 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6317 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26002,4525,262144,1024,26260,4097,18192,445,18111,8329,445,267796,16385,16813,22561,16825,20741,256,20480,4356,512]

theorem envBound6317 : H12AffineFastState.Bounded env6317 := by
  intro p hp
  have h : env6317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6316_6317 : H12AffineEnvironment.transform 14 26260 env6316 = env6317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6316 == env6317) = true)

theorem identity6317 : scanCanonicalize (H12AffineFastState.compose env6317 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6317 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6318 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26002,1213,262144,1024,26260,1297,18192,445,18111,8329,445,262916,16385,16813,19761,16825,17429,256,17680,1044,512]

theorem envBound6318 : H12AffineFastState.Bounded env6318 := by
  intro p hp
  have h : env6318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6317_6318 : H12AffineEnvironment.transform 11 1296 env6317 = env6318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6317 == env6318) = true)

theorem identity6318 : scanCanonicalize (H12AffineFastState.compose env6318 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6318 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6319 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1840,8612,8866,1213,262144,1024,8612,1297,32,445,399,8329,445,262916,1841,1693,2561,1673,805,256,544,1044,512]

theorem envBound6319 : H12AffineFastState.Bounded env6319 := by
  intro p hp
  have h : env6319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6318_6319 : H12AffineEnvironment.transform 13 1840 env6318 = env6319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env6318 == env6319) = true)

theorem identity6319 : scanCanonicalize (H12AffineFastState.compose env6319 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6319 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6320 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8201,8866,1213,262144,1024,8201,1212,32,16,34,8329,16,262825,1692,1693,2561,1673,648,173,544,1044,512]

theorem envBound6320 : H12AffineFastState.Bounded env6320 := by
  intro p hp
  have h : env6320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6319_6320 : H12AffineEnvironment.transform 7 173 env6319 = env6320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6319 == env6320) = true)

theorem identity6320 : scanCanonicalize (H12AffineFastState.compose env6320 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound6320 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6321 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1693,8201,8866,1213,1583,1024,8201,1212,32,16,34,8329,16,1158,1692,1693,2561,1673,648,173,544,1044,512]

theorem envBound6321 : H12AffineFastState.Bounded env6321 := by
  intro p hp
  have h : env6321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6320_6321 : H12AffineEnvironment.transform 17 1583 env6320 = env6321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env6320 == env6321) = true)

def env6322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4310443,41003,8329,4310442,323713,16385,16812,22560,74795,78999,256,20481,4239488,4310551]

theorem envBound6322 : H12AffineFastState.Bounded env6322 := by
  intro p hp
  have h : env6322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6313_6322 : H12AffineEnvironment.transform 5 17 env6313 = env6322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6313 == env6322) = true)

def env6323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,65536,1196,262144,1024,32768,1281,4194304,4310443,41003,8329,4310442,320897,16385,16812,19744,74795,74135,256,17665,4236672,4310551]

theorem envBound6323 : H12AffineFastState.Bounded env6323 := by
  intro p hp
  have h : env6323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6322_6323 : H12AffineEnvironment.transform 11 1280 env6322 = env6323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env6322 == env6323) = true)

theorem identity6323 : scanCanonicalize (H12AffineFastState.compose env6323 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50214) := by decide +kernel

theorem selectedBound6323 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6324 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1280,8192,16384,32768,50214,1196,262144,1024,32768,1281,4194304,4194701,41003,8329,4194700,320897,16385,16812,19744,57357,58801,256,17665,4236672,4194865]

theorem envBound6324 : H12AffineFastState.Bounded env6324 := by
  intro p hp
  have h : env6324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6323_6324 : H12AffineEnvironment.transform 15 50214 env6323 = env6324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50214 env6323 == env6324) = true)

def env6325 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,32768,50214,1196,262144,1024,32768,1281,4194304,4194701,41003,8329,4194700,320897,16385,16812,19744,57357,58785,256,17665,4236672,4194849]

theorem envBound6325 : H12AffineFastState.Bounded env6325 := by
  intro p hp
  have h : env6325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6324_6325 : H12AffineEnvironment.transform 3 0 env6324 = env6325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6324 == env6325) = true)

theorem identity6325 : scanCanonicalize (H12AffineFastState.compose env6325 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6325 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6326 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8200,25646,1196,262144,1024,8200,1281,4194304,4194701,35,8329,4194700,279945,16385,16812,19744,16389,17833,256,17665,4195720,4194849]

theorem envBound6326 : H12AffineFastState.Bounded env6326 := by
  intro p hp
  have h : env6326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6325_6326 : H12AffineEnvironment.transform 14 8200 env6325 = env6326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6325 == env6326) = true)

theorem identity6326 : scanCanonicalize (H12AffineFastState.compose env6326 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound6326 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6327 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1280,8192,16384,8200,25646,1196,262144,1024,8200,1281,32,429,35,8329,428,279945,16385,16812,19744,16389,17833,256,17665,1448,513]

theorem envBound6327 : H12AffineFastState.Bounded env6327 := by
  intro p hp
  have h : env6327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6326_6327 : H12AffineEnvironment.transform 21 32 env6326 = env6327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env6326 == env6327) = true)

theorem identity6327 : scanCanonicalize (H12AffineFastState.compose env6327 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound6327 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6328 : List Nat := [2,4,8,0,32,1,128,256,293,1024,2048,1280,8192,16384,8200,25646,1196,262144,1024,8200,1281,32,429,35,8329,428,279945,16385,16812,19744,16389,17833,256,17665,1448,292]

theorem envBound6328 : H12AffineFastState.Bounded env6328 := by
  intro p hp
  have h : env6328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6327_6328 : H12AffineEnvironment.transform 8 293 env6327 = env6328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env6327 == env6328) = true)

theorem identity6328 : scanCanonicalize (H12AffineFastState.compose env6328 (packedSelected [1,2,3,11,12,15,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6328 : packedSelected [1,2,3,11,12,15,17,18,21] rootPS < 2^1333 := by decide +kernel

def env6329 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,8192,16384,8200,25646,1196,262144,1024,8200,1028,32,168,35,8329,169,279692,16385,16553,19493,16389,17580,5,17412,1197,33]

theorem envBound6329 : H12AffineFastState.Bounded env6329 := by
  intro p hp
  have h : env6329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6328_6329 : H12AffineEnvironment.transform 7 5 env6328 = env6329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6328 == env6329) = true)

theorem identity6329 : scanCanonicalize (H12AffineFastState.compose env6329 (packedSelected [0,1,4,6,7,9,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 3115) := by decide +kernel

theorem selectedBound6329 : packedSelected [0,1,4,6,7,9,13,15] rootPS < 2^1333 := by decide +kernel

def env6330 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,8192,3115,8200,10245,1196,262144,1024,8200,1028,32,168,35,8329,169,264359,3114,3202,14,3118,2183,5,2095,1197,33]

theorem envBound6330 : H12AffineFastState.Bounded env6330 := by
  intro p hp
  have h : env6330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6329_6330 : H12AffineEnvironment.transform 13 3115 env6329 = env6330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3115 env6329 == env6330) = true)

theorem identity6330 : scanCanonicalize (H12AffineFastState.compose env6330 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6330 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6331 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,8192,3115,8200,10245,1196,2185,1024,8200,1028,32,168,35,8329,169,46,3114,3202,14,3118,2183,5,2095,1197,33]

theorem envBound6331 : H12AffineFastState.Bounded env6331 := by
  intro p hp
  have h : env6331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6330_6331 : H12AffineEnvironment.transform 17 2185 env6330 = env6331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6330 == env6331) = true)

theorem identity6331 : scanCanonicalize (H12AffineFastState.compose env6331 (packedSelected [0,1,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 39) := by decide +kernel

theorem selectedBound6331 : packedSelected [0,1,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env6332 : List Nat := [2,4,8,0,32,1,128,5,32,1024,2048,1029,39,3115,47,2082,1196,2185,1024,47,1028,32,168,35,174,169,46,3114,3202,14,3118,2183,5,2095,1197,33]

theorem envBound6332 : H12AffineFastState.Bounded env6332 := by
  intro p hp
  have h : env6332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6331_6332 : H12AffineEnvironment.transform 12 39 env6331 = env6332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 39 env6331 == env6332) = true)

theorem identity6332 : scanCanonicalize (H12AffineFastState.compose env6332 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound6332 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env6333 : List Nat := [2,4,8,0,32,1,128,5,32,134,2048,131,39,2221,47,2082,42,2185,134,47,130,32,168,35,174,169,46,2220,2052,14,2216,2183,5,2095,43,33]

theorem envBound6333 : H12AffineFastState.Bounded env6333 := by
  intro p hp
  have h : env6333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6332_6333 : H12AffineEnvironment.transform 9 134 env6332 = env6333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env6332 == env6333) = true)

theorem identity6333 : scanCanonicalize (H12AffineFastState.compose env6333 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound6333 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env6334 : List Nat := [2,4,8,0,32,1,35,5,32,37,2048,32,39,2062,47,2082,42,2090,37,47,33,32,11,35,13,10,46,2063,2052,14,2059,2084,5,2095,43,33]

theorem envBound6334 : H12AffineFastState.Bounded env6334 := by
  intro p hp
  have h : env6334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6333_6334 : H12AffineEnvironment.transform 6 35 env6333 = env6334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env6333 == env6334) = true)

theorem identity6334 : scanCanonicalize (H12AffineFastState.compose env6334 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound6334 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env6335 : List Nat := [2,4,8,0,32,1,35,5,32,37,32,32,39,46,47,2,42,10,37,47,33,32,11,35,13,10,46,47,36,14,43,4,5,15,43,33]

theorem envBound6335 : H12AffineFastState.Bounded env6335 := by
  intro p hp
  have h : env6335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6334_6335 : H12AffineEnvironment.transform 10 32 env6334 = env6335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env6334 == env6335) = true)

theorem identity6335 : scanCanonicalize (H12AffineFastState.compose env6335 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6335 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env6336 : List Nat := [2,4,3,0,32,1,35,5,32,37,32,32,39,37,36,2,33,1,37,36,33,32,0,35,6,1,37,36,36,5,32,4,5,4,32,33]

theorem envBound6336 : H12AffineFastState.Bounded env6336 := by
  intro p hp
  have h : env6336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6335_6336 : H12AffineEnvironment.transform 2 3 env6335 = env6336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6335 == env6336) = true)

theorem identity6336 : scanCanonicalize (H12AffineFastState.compose env6336 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound6336 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6337 : List Nat := [2,4,3,0,5,1,6,5,5,0,5,5,2,0,1,2,4,1,0,1,4,5,0,6,6,1,0,1,1,5,5,4,5,4,5,4]

theorem envBound6337 : H12AffineFastState.Bounded env6337 := by
  intro p hp
  have h : env6337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6336_6337 : H12AffineEnvironment.transform 4 5 env6336 = env6337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env6336 == env6337) = true)

def leafEnv6337 : List Nat := [2,4,3,0,5,1,6,5,5,0,5,5,2,0,1,2,4,1,0,1,4,5,0,6,4,6,1,1,0,1,1,5,5,4,5,4,5,7,5,4,1,0,0]

def active6337 : List Nat := [0,1]

def tree6337 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6337 : H12WitnessSearch.Good tree6337 := H12GlobalWitnessIndex.good

theorem leafIdentity6337 : H12AffineFastState.composeSystem env6337 rootObs = leafEnv6337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6337 rootObs == leafEnv6337) = true)

theorem terminalChecked6337 : H12PackedTerminal.terminalCheckFast leafEnv6337 active6337 tree6337 = true := by decide +kernel

def env6338 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1280,8192,16384,32768,50214,1196,262144,1024,32768,1281,4194304,4194701,41003,8329,4194700,320897,16385,16812,19744,57357,58784,256,17665,4236672,4194848]

theorem envBound6338 : H12AffineFastState.Bounded env6338 := by
  intro p hp
  have h : env6338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6324_6338 : H12AffineEnvironment.transform 3 1 env6324 = env6338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6324 == env6338) = true)

theorem identity6338 : scanCanonicalize (H12AffineFastState.compose env6338 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6338 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6339 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50214,1196,262144,1024,32768,1029,4194304,4194441,41003,8329,4194440,320645,16385,16552,19492,57357,58532,4,17413,4236420,4194848]

theorem envBound6339 : H12AffineFastState.Bounded env6339 := by
  intro p hp
  have h : env6339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6338_6339 : H12AffineEnvironment.transform 7 4 env6338 = env6339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6338 == env6339) = true)

theorem identity6339 : scanCanonicalize (H12AffineFastState.compose env6339 (packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6339 : packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env6340 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50214,1196,2081,1024,32768,1029,4194304,4194441,41003,8329,4194440,60580,16385,16552,19492,57357,58532,4,17413,4236420,4194848]

theorem envBound6340 : H12AffineFastState.Bounded env6340 := by
  intro p hp
  have h : env6340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6339_6340 : H12AffineEnvironment.transform 17 2081 env6339 = env6340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6339 == env6340) = true)

theorem identity6340 : scanCanonicalize (H12AffineFastState.compose env6340 (packedSelected [1,2,4,6,8,9,13,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 59906) := by decide +kernel

theorem selectedBound6340 : packedSelected [1,2,4,6,8,9,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6341 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,32768,50214,1196,2081,1024,32768,1029,59906,60043,41003,8329,60042,60580,16385,16552,19492,57357,58532,4,17413,20102,59426]

theorem envBound6341 : H12AffineFastState.Bounded env6341 := by
  intro p hp
  have h : env6341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6340_6341 : H12AffineEnvironment.transform 21 59906 env6340 = env6341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 59906 env6340 == env6341) = true)

theorem identity6341 : scanCanonicalize (H12AffineFastState.compose env6341 (packedSelected [1,2,4,6,8,9,17,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6341 : packedSelected [1,2,4,6,8,9,17,21,23] rootPS < 2^1333 := by decide +kernel

def env6342 : List Nat := [2,4,8,1,32,0,128,4,512,1024,2048,1028,8192,16384,8201,25647,1196,2081,1024,8201,1029,18955,19074,34,8329,19075,19629,16385,16552,19492,16388,17581,4,17413,20102,18475]

theorem envBound6342 : H12AffineFastState.Bounded env6342 := by
  intro p hp
  have h : env6342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6341_6342 : H12AffineEnvironment.transform 14 8201 env6341 = env6342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6341 == env6342) = true)

theorem identity6342 : scanCanonicalize (H12AffineFastState.compose env6342 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound6342 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6343 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1582,1028,8192,16384,8201,25647,1196,1551,1024,8201,1029,17445,17580,34,8329,17581,17027,16385,16552,16906,16388,17581,4,17413,16552,17925]

theorem envBound6343 : H12AffineFastState.Bounded env6343 := by
  intro p hp
  have h : env6343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6342_6343 : H12AffineEnvironment.transform 10 1582 env6342 = env6343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env6342 == env6343) = true)

theorem identity6343 : scanCanonicalize (H12AffineFastState.compose env6343 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 8738) := by decide +kernel

theorem selectedBound6343 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env6344 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1582,1028,8192,8738,8201,1549,1196,1551,1024,8201,1029,9735,9870,34,8329,9871,8353,8739,8842,8232,8742,9871,4,9767,8842,9255]

theorem envBound6344 : H12AffineFastState.Bounded env6344 := by
  intro p hp
  have h : env6344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6343_6344 : H12AffineEnvironment.transform 13 8738 env6343 = env6344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8738 env6343 == env6344) = true)

theorem identity6344 : scanCanonicalize (H12AffineFastState.compose env6344 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1548) := by decide +kernel

theorem selectedBound6344 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6345 : List Nat := [2,4,8,1,32,0,128,4,512,1024,1582,1028,1548,1070,1541,1549,1196,1551,1024,1541,1029,11,130,34,1669,131,1709,1071,1158,1572,1066,131,4,43,1158,555]

theorem envBound6345 : H12AffineFastState.Bounded env6345 := by
  intro p hp
  have h : env6345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6344_6345 : H12AffineEnvironment.transform 12 1548 env6344 = env6345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1548 env6344 == env6345) = true)

theorem identity6345 : scanCanonicalize (H12AffineFastState.compose env6345 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6345 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6346 : List Nat := [2,4,8,1,32,0,128,4,512,14,544,10,514,32,523,515,162,513,14,523,11,11,130,34,651,131,675,33,136,554,36,131,4,43,136,555]

theorem envBound6346 : H12AffineFastState.Bounded env6346 := by
  intro p hp
  have h : env6346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6345_6346 : H12AffineEnvironment.transform 9 14 env6345 = env6346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6345 == env6346) = true)

theorem identity6346 : scanCanonicalize (H12AffineFastState.compose env6346 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6346 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env6347 : List Nat := [2,4,8,1,11,0,128,4,512,14,523,10,514,11,523,515,137,513,14,523,11,11,130,9,651,131,648,10,136,513,15,131,4,0,136,512]

theorem envBound6347 : H12AffineFastState.Bounded env6347 := by
  intro p hp
  have h : env6347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6346_6347 : H12AffineEnvironment.transform 4 11 env6346 = env6347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6346 == env6347) = true)

theorem identity6347 : scanCanonicalize (H12AffineFastState.compose env6347 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6347 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env6348 : List Nat := [2,4,8,1,11,0,128,4,11,14,0,10,9,11,0,8,137,10,14,0,11,11,130,9,128,131,131,10,136,10,15,131,4,0,136,11]

theorem envBound6348 : H12AffineFastState.Bounded env6348 := by
  intro p hp
  have h : env6348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6347_6348 : H12AffineEnvironment.transform 8 11 env6347 = env6348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6347 == env6348) = true)

def env6349 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,65536,1197,262144,1024,32768,1280,4194304,4310443,41003,8329,4310442,320896,16385,16812,19745,74795,74134,256,17664,4236673,4310551]

theorem envBound6349 : H12AffineFastState.Bounded env6349 := by
  intro p hp
  have h : env6349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6322_6349 : H12AffineEnvironment.transform 11 1281 env6322 = env6349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env6322 == env6349) = true)

theorem identity6349 : scanCanonicalize (H12AffineFastState.compose env6349 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50587) := by decide +kernel

theorem selectedBound6349 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6350 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1281,8192,16384,32768,50587,1197,262144,1024,32768,1280,4194304,4194352,41003,8329,4194353,320896,16385,16812,19745,57776,58381,256,17664,4236673,4195212]

theorem envBound6350 : H12AffineFastState.Bounded env6350 := by
  intro p hp
  have h : env6350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6349_6350 : H12AffineEnvironment.transform 15 50587 env6349 = env6350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50587 env6349 == env6350) = true)

def env6351 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50571,1197,262144,1024,32768,1280,4194304,4194336,41003,8329,4194337,320896,16385,16812,19745,57760,58381,256,17664,4236673,4195212]

theorem envBound6351 : H12AffineFastState.Bounded env6351 := by
  intro p hp
  have h : env6351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6350_6351 : H12AffineEnvironment.transform 3 0 env6350 = env6351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6350 == env6351) = true)

def env6352 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50571,1197,262144,1024,32768,1280,41088,41120,41003,8329,41121,320896,16385,16812,19745,57760,58381,256,17664,1281,41740]

theorem envBound6352 : H12AffineFastState.Bounded env6352 := by
  intro p hp
  have h : env6352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6351_6352 : H12AffineEnvironment.transform 21 41088 env6351 = env6352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6351 == env6352) = true)

theorem identity6352 : scanCanonicalize (H12AffineFastState.compose env6352 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6352 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6353 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8200,25987,1197,262144,1024,8200,1280,136,168,35,8329,169,279944,16385,16812,19745,16808,17413,256,17664,1281,772]

theorem envBound6353 : H12AffineFastState.Bounded env6353 := by
  intro p hp
  have h : env6353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6352_6353 : H12AffineEnvironment.transform 14 8200 env6352 = env6353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6352 == env6353) = true)

theorem identity6353 : scanCanonicalize (H12AffineFastState.compose env6353 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20140) := by decide +kernel

theorem selectedBound6353 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6354 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,8200,25987,1197,20140,1024,8200,1280,136,168,35,8329,169,2852,16385,16812,19745,16808,17413,256,17664,1281,772]

theorem envBound6354 : H12AffineFastState.Bounded env6354 := by
  intro p hp
  have h : env6354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6353_6354 : H12AffineEnvironment.transform 17 20140 env6353 = env6354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20140 env6353 == env6354) = true)

theorem identity6354 : scanCanonicalize (H12AffineFastState.compose env6354 (packedSelected [1,5,10,12,13,15,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6354 : packedSelected [1,5,10,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env6355 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,8192,16384,8200,25735,1197,20140,1024,8200,1028,136,168,35,8329,169,2592,16385,16552,19493,16556,17413,4,17412,1029,512]

theorem envBound6355 : H12AffineFastState.Bounded env6355 := by
  intro p hp
  have h : env6355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6354_6355 : H12AffineEnvironment.transform 7 4 env6354 = env6355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6354 == env6355) = true)

theorem identity6355 : scanCanonicalize (H12AffineFastState.compose env6355 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound6355 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env6356 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,3629,16384,3621,19114,1197,20140,1024,3621,1028,136,168,35,3748,169,2592,16385,16552,19493,16556,17413,4,17412,1029,512]

theorem envBound6356 : H12AffineFastState.Bounded env6356 := by
  intro p hp
  have h : env6356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6355_6356 : H12AffineEnvironment.transform 12 3629 env6355 = env6356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env6355 == env6356) = true)

theorem identity6356 : scanCanonicalize (H12AffineFastState.compose env6356 (packedSelected [0,2,3,4,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 3719) := by decide +kernel

theorem selectedBound6356 : packedSelected [0,2,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env6357 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,1029,3629,3719,3621,1069,1197,43,1024,3621,1028,136,168,35,3748,169,2592,3718,3631,674,3627,2690,4,2691,1029,512]

theorem envBound6357 : H12AffineFastState.Bounded env6357 := by
  intro p hp
  have h : env6357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6356_6357 : H12AffineEnvironment.transform 13 3719 env6356 = env6357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3719 env6356 == env6357) = true)

theorem identity6357 : scanCanonicalize (H12AffineFastState.compose env6357 (packedSelected [2,3,6,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound6357 : packedSelected [2,3,6,10,17] rootPS < 2^1333 := by decide +kernel

def env6358 : List Nat := [2,4,8,0,32,1,128,4,512,1024,10,1029,1575,1677,1583,1069,1197,43,1024,1583,1028,136,168,35,1710,169,554,1676,1573,674,1569,648,4,649,1029,512]

theorem envBound6358 : H12AffineFastState.Bounded env6358 := by
  intro p hp
  have h : env6358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6357_6358 : H12AffineEnvironment.transform 10 10 env6357 = env6358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env6357 == env6358) = true)

theorem identity6358 : scanCanonicalize (H12AffineFastState.compose env6358 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6358 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env6359 : List Nat := [2,4,8,0,32,1,128,4,512,5,10,0,546,648,554,40,168,43,5,554,1,136,168,35,683,169,554,649,544,674,548,648,4,649,0,512]

theorem envBound6359 : H12AffineFastState.Bounded env6359 := by
  intro p hp
  have h : env6359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6358_6359 : H12AffineEnvironment.transform 9 5 env6358 = env6359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6358 == env6359) = true)

def env6360 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1281,8192,16384,32768,50571,1197,262144,1024,32768,1280,41089,41121,41003,8329,41120,320896,16385,16812,19745,57760,58381,256,17664,1280,41741]

theorem envBound6360 : H12AffineFastState.Bounded env6360 := by
  intro p hp
  have h : env6360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6351_6360 : H12AffineEnvironment.transform 21 41089 env6351 = env6360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6351 == env6360) = true)

theorem identity6360 : scanCanonicalize (H12AffineFastState.compose env6360 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6360 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6361 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,16384,32768,50318,1197,262144,1024,32768,1029,41089,41121,41003,8329,41120,320645,16385,16553,19492,57509,58381,5,17413,1029,41480]

theorem envBound6361 : H12AffineFastState.Bounded env6361 := by
  intro p hp
  have h : env6361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6360_6361 : H12AffineEnvironment.transform 7 5 env6360 = env6361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6360 == env6361) = true)

theorem identity6361 : scanCanonicalize (H12AffineFastState.compose env6361 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound6361 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6362 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1677,32768,33283,1197,262144,1024,32768,1029,41089,41121,41003,8329,41120,303624,1676,1572,2729,42536,41600,5,648,1029,41480]

theorem envBound6362 : H12AffineFastState.Bounded env6362 := by
  intro p hp
  have h : env6362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6361_6362 : H12AffineEnvironment.transform 13 1677 env6361 = env6362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env6361 == env6362) = true)

theorem identity6362 : scanCanonicalize (H12AffineFastState.compose env6362 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6362 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env6363 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1677,8200,8715,1197,262144,1024,8200,1029,137,169,35,8329,168,262656,1676,1572,2729,1568,648,5,648,1029,512]

theorem envBound6363 : H12AffineFastState.Bounded env6363 := by
  intro p hp
  have h : env6363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6362_6363 : H12AffineEnvironment.transform 14 8200 env6362 = env6363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6362 == env6363) = true)

theorem identity6363 : scanCanonicalize (H12AffineFastState.compose env6363 (packedSelected [2,3,6,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 11277) := by decide +kernel

theorem selectedBound6363 : packedSelected [2,3,6,10,13] rootPS < 2^1333 := by decide +kernel

def env6364 : List Nat := [2,4,8,0,32,1,128,5,512,1024,2048,1028,8192,1677,8200,8715,1197,11277,1024,8200,1029,137,169,35,8329,168,11789,1676,1572,2729,1568,648,5,648,1029,512]

theorem envBound6364 : H12AffineFastState.Bounded env6364 := by
  intro p hp
  have h : env6364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6363_6364 : H12AffineEnvironment.transform 17 11277 env6363 = env6364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11277 env6363 == env6364) = true)

theorem identity6364 : scanCanonicalize (H12AffineFastState.compose env6364 (packedSelected [5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound6364 : packedSelected [5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env6365 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1070,1028,8192,1677,8200,8715,1197,8227,1024,8200,1029,137,169,35,8329,168,8739,1676,1572,1671,1568,648,5,648,1029,512]

theorem envBound6365 : H12AffineFastState.Bounded env6365 := by
  intro p hp
  have h : env6365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6364_6365 : H12AffineEnvironment.transform 10 1070 env6364 = env6365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env6364 == env6365) = true)

theorem identity6365 : scanCanonicalize (H12AffineFastState.compose env6365 (packedSelected [2,3,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound6365 : packedSelected [2,3,6,8,12] rootPS < 2^1333 := by decide +kernel

def env6366 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1070,1028,1701,1677,1709,1198,1197,1670,1024,1709,1029,137,169,35,1580,168,1158,1676,1572,1671,1568,648,5,648,1029,512]

theorem envBound6366 : H12AffineFastState.Bounded env6366 := by
  intro p hp
  have h : env6366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6365_6366 : H12AffineEnvironment.transform 12 1701 env6365 = env6366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env6365 == env6366) = true)

theorem identity6366 : scanCanonicalize (H12AffineFastState.compose env6366 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound6366 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env6367 : List Nat := [2,4,8,0,32,1,128,5,512,36,10,32,641,681,649,138,137,674,36,649,33,137,169,35,520,168,162,680,512,675,516,648,5,648,33,512]

theorem envBound6367 : H12AffineFastState.Bounded env6367 := by
  intro p hp
  have h : env6367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6366_6367 : H12AffineEnvironment.transform 9 36 env6366 = env6367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env6366 == env6367) = true)

theorem identity6367 : scanCanonicalize (H12AffineFastState.compose env6367 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound6367 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6368 : List Nat := [2,4,8,0,32,1,128,5,137,36,10,32,8,32,0,138,137,43,36,0,33,137,169,35,129,168,162,33,137,42,141,1,5,1,33,137]

theorem envBound6368 : H12AffineFastState.Bounded env6368 := by
  intro p hp
  have h : env6368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6367_6368 : H12AffineEnvironment.transform 8 137 env6367 = env6368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env6367 == env6368) = true)

theorem identity6368 : scanCanonicalize (H12AffineFastState.compose env6368 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6369 : List Nat := [2,4,3,0,32,1,128,5,130,36,1,32,3,32,0,129,130,32,36,0,33,130,162,35,129,163,162,33,130,33,134,1,5,1,33,130]

theorem envBound6369 : H12AffineFastState.Bounded env6369 := by
  intro p hp
  have h : env6369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6368_6369 : H12AffineEnvironment.transform 2 3 env6368 = env6369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6368 == env6369) = true)

theorem identity6369 : scanCanonicalize (H12AffineFastState.compose env6369 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound6369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6370 : List Nat := [2,4,3,0,32,1,2,5,0,36,1,32,3,32,0,3,0,32,36,0,33,0,32,35,3,33,32,33,0,33,4,1,5,1,33,0]

theorem envBound6370 : H12AffineFastState.Bounded env6370 := by
  intro p hp
  have h : env6370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6369_6370 : H12AffineEnvironment.transform 6 2 env6369 = env6370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env6369 == env6370) = true)

def env6371 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,32768,50570,1197,262144,1024,32768,1280,4194304,4194337,41003,8329,4194336,320896,16385,16812,19745,57761,58381,256,17664,4236673,4195212]

theorem envBound6371 : H12AffineFastState.Bounded env6371 := by
  intro p hp
  have h : env6371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6350_6371 : H12AffineEnvironment.transform 3 1 env6350 = env6371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6350 == env6371) = true)

theorem identity6371 : scanCanonicalize (H12AffineFastState.compose env6371 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound6371 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6372 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1281,8192,16384,8461,25735,1197,262144,1024,8461,1280,4194304,4194337,294,8329,4194336,279693,16385,16812,19745,16556,17664,256,17664,4195468,4195212]

theorem envBound6372 : H12AffineFastState.Bounded env6372 := by
  intro p hp
  have h : env6372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6371_6372 : H12AffineEnvironment.transform 14 8461 env6371 = env6372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env6371 == env6372) = true)

theorem identity6372 : scanCanonicalize (H12AffineFastState.compose env6372 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6372 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6373 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8200,25735,1197,262144,1024,8200,1029,4194304,4194337,35,8329,4194336,279693,16385,16553,19492,16556,17413,5,17413,4195468,4194953]

theorem envBound6373 : H12AffineFastState.Bounded env6373 := by
  intro p hp
  have h : env6373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6372_6373 : H12AffineEnvironment.transform 7 5 env6372 = env6373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6372 == env6373) = true)

theorem identity6373 : scanCanonicalize (H12AffineFastState.compose env6373 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6373 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6374 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8200,25735,1197,2184,1024,8200,1029,4194304,4194337,35,8329,4194336,19461,16385,16553,19492,16556,17413,5,17413,4195468,4194953]

theorem envBound6374 : H12AffineFastState.Bounded env6374 := by
  intro p hp
  have h : env6374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6373_6374 : H12AffineEnvironment.transform 17 2184 env6373 = env6374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6373 == env6374) = true)

theorem identity6374 : scanCanonicalize (H12AffineFastState.compose env6374 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6374 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6375 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8200,25735,1165,2184,1024,8200,1029,4194304,4194305,3,8329,4194304,19461,16385,16521,19460,16524,17413,5,17413,4195468,4194953]

theorem envBound6375 : H12AffineFastState.Bounded env6375 := by
  intro p hp
  have h : env6375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6374_6375 : H12AffineEnvironment.transform 4 0 env6374 = env6375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6374 == env6375) = true)

theorem identity6375 : scanCanonicalize (H12AffineFastState.compose env6375 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 10378) := by decide +kernel

theorem selectedBound6375 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6376 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8200,25735,1165,2184,1024,8200,1029,10378,10379,3,8329,10378,19461,16385,16521,19460,16524,17413,5,17413,11270,10755]

theorem envBound6376 : H12AffineFastState.Bounded env6376 := by
  intro p hp
  have h : env6376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6375_6376 : H12AffineEnvironment.transform 21 10378 env6375 = env6376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10378 env6375 == env6376) = true)

theorem identity6376 : scanCanonicalize (H12AffineFastState.compose env6376 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound6376 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6377 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,8192,16384,8200,25614,1028,2049,1024,8200,1029,10243,10242,3,8192,10243,19461,16385,16384,19460,16389,17413,5,17413,11270,10755]

theorem envBound6377 : H12AffineFastState.Bounded env6377 := by
  intro p hp
  have h : env6377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6376_6377 : H12AffineEnvironment.transform 6 9 env6376 = env6377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env6376 == env6377) = true)

theorem identity6377 : scanCanonicalize (H12AffineFastState.compose env6377 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound6377 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6378 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,2563,16384,2571,19981,1028,2049,1024,2571,1029,512,513,3,2563,512,19461,16385,16384,19460,16389,17413,5,17413,1541,0]

theorem envBound6378 : H12AffineFastState.Bounded env6378 := by
  intro p hp
  have h : env6378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6377_6378 : H12AffineEnvironment.transform 12 2563 env6377 = env6378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env6377 == env6378) = true)

theorem identity6378 : scanCanonicalize (H12AffineFastState.compose env6378 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound6378 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6379 : List Nat := [2,4,8,1,0,0,9,5,512,1024,2048,1028,2563,1029,2571,2568,1028,2049,1024,2571,1029,512,513,3,2563,512,2048,1028,1029,2049,1024,0,5,0,1541,0]

theorem envBound6379 : H12AffineFastState.Bounded env6379 := by
  intro p hp
  have h : env6379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6378_6379 : H12AffineEnvironment.transform 13 1029 env6378 = env6379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env6378 == env6379) = true)

theorem identity6379 : scanCanonicalize (H12AffineFastState.compose env6379 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound6379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6380 : List Nat := [2,4,8,1,0,0,9,5,512,1024,1540,1028,1031,1029,1039,1036,1028,1541,1024,1039,1029,512,513,3,1031,512,1540,1028,1029,1541,1024,0,5,0,1541,0]

theorem envBound6380 : H12AffineFastState.Bounded env6380 := by
  intro p hp
  have h : env6380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6379_6380 : H12AffineEnvironment.transform 10 1540 env6379 = env6380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env6379 == env6380) = true)

def env6381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,12644668,257,20561,4239488,8389612]

theorem envBound6381 : H12AffineFastState.Bounded env6381 := by
  intro p hp
  have h : env6381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6311_6381 : H12AffineEnvironment.transform 18 1025 env6311 = env6381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6311 == env6381) = true)

theorem identity6381 : scanCanonicalize (H12AffineFastState.compose env6381 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98474) := by decide +kernel

theorem selectedBound6381 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,98474,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,8483222,257,20561,77866,8389612]

theorem envBound6382 : H12AffineFastState.Bounded env6382 := by
  intro p hp
  have h : env6382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6381_6382 : H12AffineEnvironment.transform 21 98474 env6381 = env6382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98474 env6381 == env6382) = true)

def env6383 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98474,8388608,41003,8329,8388609,323713,16385,16813,22560,74794,8483222,257,20481,77866,8389564]

theorem envBound6383 : H12AffineFastState.Bounded env6383 := by
  intro p hp
  have h : env6383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6382_6383 : H12AffineEnvironment.transform 5 16 env6382 = env6383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6382 == env6383) = true)

def env6384 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98306,8388608,41003,8225,8388609,323625,16385,16645,22560,74794,8483134,257,20481,77866,8389396]

theorem envBound6384 : H12AffineFastState.Bounded env6384 := by
  intro p hp
  have h : env6384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6383_6384 : H12AffineEnvironment.transform 6 40 env6383 = env6384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6383 == env6384) = true)

theorem identity6384 : scanCanonicalize (H12AffineFastState.compose env6384 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 284980) := by decide +kernel

theorem selectedBound6384 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6385 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1025,32768,4097,98306,284980,41003,8225,284981,323625,16385,16645,22560,74794,337930,257,20481,77866,285216]

theorem envBound6385 : H12AffineFastState.Bounded env6385 := by
  intro p hp
  have h : env6385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6384_6385 : H12AffineEnvironment.transform 22 284980 env6384 = env6385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284980 env6384 == env6385) = true)

theorem identity6385 : scanCanonicalize (H12AffineFastState.compose env6385 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6385 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env6386 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,2080,1025,32768,4097,98306,20756,41003,8225,20757,63497,16385,16645,22560,74794,73770,257,20481,77866,20992]

theorem envBound6386 : H12AffineFastState.Bounded env6386 := by
  intro p hp
  have h : env6386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6385_6386 : H12AffineEnvironment.transform 17 2080 env6385 = env6386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6385 == env6386) = true)

theorem identity6386 : scanCanonicalize (H12AffineFastState.compose env6386 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound6386 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6387 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,16384,8461,65536,4357,2080,1025,8461,4097,73999,20756,294,8225,20757,22788,16385,16645,22560,74794,73770,257,20481,77866,20992]

theorem envBound6387 : H12AffineFastState.Bounded env6387 := by
  intro p hp
  have h : env6387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6386_6387 : H12AffineEnvironment.transform 14 8461 env6386 = env6387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env6386 == env6387) = true)

theorem identity6387 : scanCanonicalize (H12AffineFastState.compose env6387 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound6387 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6388 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,8192,11545,8461,65536,4357,2080,1025,8461,4097,73999,15373,294,8225,15372,13341,11544,11292,13625,74794,73770,257,15640,77866,16153]

theorem envBound6388 : H12AffineFastState.Bounded env6388 := by
  intro p hp
  have h : env6388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6387_6388 : H12AffineEnvironment.transform 13 11545 env6387 = env6388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env6387 == env6388) = true)

theorem identity6388 : scanCanonicalize (H12AffineFastState.compose env6388 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7961) := by decide +kernel

theorem selectedBound6388 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env6389 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,7961,4608,7700,65536,4357,2080,1025,7700,4097,73238,788,294,7992,789,2820,4609,4869,2592,72499,73523,257,513,69427,0]

theorem envBound6389 : H12AffineFastState.Bounded env6389 := by
  intro p hp
  have h : env6389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6388_6389 : H12AffineEnvironment.transform 12 7961 env6388 = env6389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7961 env6388 == env6389) = true)

theorem identity6389 : scanCanonicalize (H12AffineFastState.compose env6389 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound6389 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env6390 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1589,2348,1077,2081,65536,1840,2080,1025,2081,1588,67619,788,294,2317,789,2820,1076,1328,2592,68870,67846,257,513,69427,0]

theorem envBound6390 : H12AffineFastState.Bounded env6390 := by
  intro p hp
  have h : env6390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6389_6390 : H12AffineEnvironment.transform 11 1589 env6389 = env6390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env6389 == env6390) = true)

theorem identity6390 : scanCanonicalize (H12AffineFastState.compose env6390 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 2823) := by decide +kernel

theorem selectedBound6390 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env6391 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1589,2348,1077,2081,2823,1840,2080,1025,2081,1588,804,788,294,2317,789,2820,1076,1328,2592,1537,513,257,513,1076,0]

theorem envBound6391 : H12AffineFastState.Bounded env6391 := by
  intro p hp
  have h : env6391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6390_6391 : H12AffineEnvironment.transform 15 2823 env6390 = env6391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2823 env6390 == env6391) = true)

theorem identity6391 : scanCanonicalize (H12AffineFastState.compose env6391 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1291) := by decide +kernel

theorem selectedBound6391 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6392 : List Nat := [2,4,8,16,32,16,40,256,512,1024,1291,1589,1063,1077,1322,1548,1840,1323,1025,1322,1588,804,788,294,1030,789,1551,1076,1328,1835,1537,513,257,513,1076,0]

theorem envBound6392 : H12AffineFastState.Bounded env6392 := by
  intro p hp
  have h : env6392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6391_6392 : H12AffineEnvironment.transform 10 1291 env6391 = env6392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1291 env6391 == env6392) = true)

theorem identity6392 : scanCanonicalize (H12AffineFastState.compose env6392 (packedSelected [0,4,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6392 : packedSelected [0,4,10,13] rootPS < 2^1333 := by decide +kernel

def env6393 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1039,1589,1063,1077,1070,1548,1588,1071,1025,1070,1588,544,528,34,1030,529,1551,1076,1076,1583,1537,513,5,513,1076,0]

theorem envBound6393 : H12AffineFastState.Bounded env6393 := by
  intro p hp
  have h : env6393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6392_6393 : H12AffineEnvironment.transform 7 4 env6392 = env6393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6392 == env6393) = true)

theorem identity6393 : scanCanonicalize (H12AffineFastState.compose env6393 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound6393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6394 : List Nat := [2,4,8,16,32,16,40,4,512,565,570,0,530,512,539,57,1,538,564,539,1,544,528,34,563,529,58,513,513,26,52,513,5,513,513,0]

theorem envBound6394 : H12AffineFastState.Bounded env6394 := by
  intro p hp
  have h : env6394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6393_6394 : H12AffineEnvironment.transform 9 565 env6393 = env6394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env6393 == env6394) = true)

theorem identity6394 : scanCanonicalize (H12AffineFastState.compose env6394 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound6394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6395 : List Nat := [2,4,8,16,32,16,40,4,26,47,32,0,8,26,1,57,1,0,46,1,1,58,10,34,41,11,58,27,27,26,52,27,5,27,27,0]

theorem envBound6395 : H12AffineFastState.Bounded env6395 := by
  intro p hp
  have h : env6395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6394_6395 : H12AffineEnvironment.transform 8 26 env6394 = env6395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env6394 == env6395) = true)

def env6396 : List Nat := [2,4,8,4,32,4,40,4,14,47,32,0,8,14,1,45,1,0,46,1,1,46,10,34,41,11,46,15,15,14,32,15,5,15,15,0]

theorem envBound6396 : H12AffineFastState.Bounded env6396 := by
  intro p hp
  have h : env6396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6395_6396 : H12AffineEnvironment.transform 3 4 env6395 = env6396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6395 == env6396) = true)

def env6397 : List Nat := [2,0,8,0,32,0,40,0,10,43,32,0,8,10,1,41,1,0,42,1,1,42,10,34,41,11,42,11,11,10,32,11,1,11,11,0]

theorem envBound6397 : H12AffineFastState.Bounded env6397 := by
  intro p hp
  have h : env6397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6396_6397 : H12AffineEnvironment.transform 1 0 env6396 = env6397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6396 == env6397) = true)

def env6398 : List Nat := [2,1,8,1,32,1,40,1,11,42,32,0,8,11,1,40,1,0,43,1,1,43,10,34,41,11,43,10,10,11,32,10,0,10,10,0]

theorem envBound6398 : H12AffineFastState.Bounded env6398 := by
  intro p hp
  have h : env6398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6396_6398 : H12AffineEnvironment.transform 1 1 env6396 = env6398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6396 == env6398) = true)

theorem identity6398 : scanCanonicalize (H12AffineFastState.compose env6398 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6398 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6399 : List Nat := [2,1,2,1,32,1,34,1,1,32,32,0,2,1,1,34,1,0,33,1,1,33,0,34,35,1,33,0,0,1,32,0,0,0,0,0]

theorem envBound6399 : H12AffineFastState.Bounded env6399 := by
  intro p hp
  have h : env6399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6398_6399 : H12AffineEnvironment.transform 2 2 env6398 = env6399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6398 == env6399) = true)

def leafEnv6399 : List Nat := [2,1,2,1,32,1,34,1,1,32,32,0,2,1,1,34,1,0,33,1,1,33,0,34,33,35,1,1,33,0,0,1,32,0,0,0,0,3,0,0,1,0,0]

def active6399 : List Nat := [0,4]

def tree6399 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6399 : H12WitnessSearch.Good tree6399 := H12GlobalWitnessIndex.good

theorem leafIdentity6399 : H12AffineFastState.composeSystem env6399 rootObs = leafEnv6399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6399 rootObs == leafEnv6399) = true)

theorem terminalChecked6399 : H12PackedTerminal.terminalCheckFast leafEnv6399 active6399 tree6399 = true := by decide +kernel

def env6400 : List Nat := [2,4,8,5,32,5,40,4,15,47,32,0,8,15,1,44,1,0,46,1,1,47,10,34,41,11,47,14,14,15,33,14,5,14,14,0]

theorem envBound6400 : H12AffineFastState.Bounded env6400 := by
  intro p hp
  have h : env6400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6395_6400 : H12AffineEnvironment.transform 3 5 env6395 = env6400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6395 == env6400) = true)

theorem identity6400 : scanCanonicalize (H12AffineFastState.compose env6400 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6400 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6401 : List Nat := [2,4,7,5,32,5,39,4,0,32,32,0,7,0,1,35,1,0,33,1,1,32,5,34,38,4,32,1,1,0,33,1,5,1,1,0]

theorem envBound6401 : H12AffineFastState.Bounded env6401 := by
  intro p hp
  have h : env6401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6400_6401 : H12AffineEnvironment.transform 2 7 env6400 = env6401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6400 == env6401) = true)

def env6402 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98307,8388608,41003,8224,8388609,323624,16385,16644,22560,74794,8483135,257,20481,77866,8389397]

theorem envBound6402 : H12AffineFastState.Bounded env6402 := by
  intro p hp
  have h : env6402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6383_6402 : H12AffineEnvironment.transform 6 41 env6383 = env6402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6383 == env6402) = true)

theorem identity6402 : scanCanonicalize (H12AffineFastState.compose env6402 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 74046) := by decide +kernel

theorem selectedBound6402 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6403 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,98307,74046,41003,8224,74047,323624,16385,16644,22560,74794,20481,257,20481,77866,74283]

theorem envBound6403 : H12AffineFastState.Bounded env6403 := by
  intro p hp
  have h : env6403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6402_6403 : H12AffineEnvironment.transform 22 74046 env6402 = env6403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 74046 env6402 == env6403) = true)

theorem identity6403 : scanCanonicalize (H12AffineFastState.compose env6403 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6403 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6404 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,98307,73786,41003,8224,73787,323624,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound6404 : H12AffineFastState.Bounded env6404 := by
  intro p hp
  have h : env6404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6403_6404 : H12AffineEnvironment.transform 7 4 env6403 = env6404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6403 == env6404) = true)

theorem identity6404 : scanCanonicalize (H12AffineFastState.compose env6404 (packedSelected [7,13,17,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 120835) := by decide +kernel

theorem selectedBound6404 : packedSelected [7,13,17,20,27] rootPS < 2^1333 := by decide +kernel

def env6405 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,32768,65536,4096,120835,1025,32768,4097,98307,73786,41003,8224,73787,75819,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound6405 : H12AffineFastState.Bounded env6405 := by
  intro p hp
  have h : env6405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6404_6405 : H12AffineEnvironment.transform 17 120835 env6404 = env6405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 120835 env6404 == env6405) = true)

theorem identity6405 : scanCanonicalize (H12AffineFastState.compose env6405 (packedSelected [2,3,5,6,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6405 : packedSelected [2,3,5,6,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6406 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,1550,65536,4096,89613,1025,1550,4097,67085,73786,9765,8224,73787,75819,16385,16384,22560,74794,20481,5,20481,77866,74283]

theorem envBound6406 : H12AffineFastState.Bounded env6406 := by
  intro p hp
  have h : env6406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6405_6406 : H12AffineEnvironment.transform 14 1550 env6405 = env6406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1550 env6405 == env6406) = true)

theorem identity6406 : scanCanonicalize (H12AffineFastState.compose env6406 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 22061) := by decide +kernel

theorem selectedBound6406 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6407 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,8192,16384,1550,22061,4096,2080,1025,1550,4097,20512,30231,9765,8224,30230,32262,16385,16384,22560,29191,20481,5,20481,26119,29702]

theorem envBound6407 : H12AffineFastState.Bounded env6407 := by
  intro p hp
  have h : env6407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6406_6407 : H12AffineEnvironment.transform 15 22061 env6406 = env6407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22061 env6406 == env6407) = true)

theorem identity6407 : scanCanonicalize (H12AffineFastState.compose env6407 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound6407 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env6408 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,4096,1543,16384,1550,22061,4096,2080,1025,1550,4097,20512,20496,34,1575,20497,22529,16385,16384,22560,21504,20481,5,20481,16384,20993]

theorem envBound6408 : H12AffineFastState.Bounded env6408 := by
  intro p hp
  have h : env6408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6407_6408 : H12AffineEnvironment.transform 12 1543 env6407 = env6408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env6407 == env6408) = true)

theorem identity6408 : scanCanonicalize (H12AffineFastState.compose env6408 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2603) := by decide +kernel

theorem selectedBound6408 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6409 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,2603,1543,16384,1550,19462,2603,2080,1025,1550,2602,18955,19003,34,1575,19002,16938,16385,16384,16907,20011,18986,5,18986,16384,18474]

theorem envBound6409 : H12AffineFastState.Bounded env6409 := by
  intro p hp
  have h : env6409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6408_6409 : H12AffineEnvironment.transform 11 2603 env6408 = env6409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2603 env6408 == env6409) = true)

theorem identity6409 : scanCanonicalize (H12AffineFastState.compose env6409 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound6409 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6410 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,2603,1543,1572,1550,2594,2603,2080,1025,1550,2602,3119,3103,34,1575,3102,1038,1573,1572,1071,2063,3086,5,3086,1572,3598]

theorem envBound6410 : H12AffineFastState.Bounded env6410 := by
  intro p hp
  have h : env6410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6409_6410 : H12AffineEnvironment.transform 13 1572 env6409 = env6410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env6409 == env6410) = true)

theorem identity6410 : scanCanonicalize (H12AffineFastState.compose env6410 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound6410 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6411 : List Nat := [2,4,8,16,32,16,41,4,49,1024,2048,2074,1078,1045,1087,2067,2074,2080,1025,1087,2075,3119,3103,34,1046,3102,1038,1044,1045,1071,2063,3086,5,3086,1045,3135]

theorem envBound6411 : H12AffineFastState.Bounded env6411 := by
  intro p hp
  have h : env6411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6410_6411 : H12AffineEnvironment.transform 8 49 env6410 = env6411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env6410 == env6411) = true)

theorem identity6411 : scanCanonicalize (H12AffineFastState.compose env6411 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound6411 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6412 : List Nat := [2,4,8,16,32,16,41,4,49,36,2048,2074,18,49,27,2067,2074,2080,37,27,2075,2059,2107,34,50,2106,42,48,49,11,2063,2090,5,2090,49,2075]

theorem envBound6412 : H12AffineFastState.Bounded env6412 := by
  intro p hp
  have h : env6412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6411_6412 : H12AffineEnvironment.transform 9 36 env6411 = env6412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env6411 == env6412) = true)

theorem identity6412 : scanCanonicalize (H12AffineFastState.compose env6412 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound6412 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6413 : List Nat := [2,4,8,16,32,16,41,4,49,36,43,49,18,49,27,56,49,11,37,27,48,32,16,34,50,17,42,48,49,11,36,1,5,1,49,48]

theorem envBound6413 : H12AffineFastState.Bounded env6413 := by
  intro p hp
  have h : env6413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6412_6413 : H12AffineEnvironment.transform 10 43 env6412 = env6413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env6412 == env6413) = true)

theorem identity6413 : scanCanonicalize (H12AffineFastState.compose env6413 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6413 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6414 : List Nat := [2,1,8,16,32,16,41,1,49,33,43,49,18,49,27,56,49,11,32,27,48,32,16,34,50,17,42,48,49,11,33,1,0,1,49,48]

theorem envBound6414 : H12AffineFastState.Bounded env6414 := by
  intro p hp
  have h : env6414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6413_6414 : H12AffineEnvironment.transform 1 1 env6413 = env6414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6413 == env6414) = true)

theorem identity6414 : scanCanonicalize (H12AffineFastState.compose env6414 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6414 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env6415 : List Nat := [2,1,8,16,16,16,25,1,1,17,27,1,18,1,27,8,1,11,16,27,0,16,16,18,2,17,26,0,1,11,17,1,0,1,1,0]

theorem envBound6415 : H12AffineFastState.Bounded env6415 := by
  intro p hp
  have h : env6415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6414_6415 : H12AffineEnvironment.transform 4 16 env6414 = env6415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6414 == env6415) = true)

theorem identity6415 : scanCanonicalize (H12AffineFastState.compose env6415 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6415 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6416 : List Nat := [2,1,2,16,16,16,19,1,1,17,17,1,18,1,17,2,1,1,16,17,0,16,16,18,2,17,16,0,1,1,17,1,0,1,1,0]

theorem envBound6416 : H12AffineFastState.Bounded env6416 := by
  intro p hp
  have h : env6416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6415_6416 : H12AffineEnvironment.transform 2 2 env6415 = env6416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6415 == env6416) = true)

theorem identity6416 : scanCanonicalize (H12AffineFastState.compose env6416 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound6416 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env6417 : List Nat := [2,1,2,0,0,0,3,1,1,1,1,1,2,1,1,2,1,1,0,1,0,0,0,2,2,1,0,0,1,1,1,1,0,1,1,0]

theorem envBound6417 : H12AffineFastState.Bounded env6417 := by
  intro p hp
  have h : env6417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6416_6417 : H12AffineEnvironment.transform 3 0 env6416 = env6417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6416 == env6417) = true)

def env6418 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98474,8388608,41003,8329,8388608,323712,16385,16812,22561,74794,8483222,257,20480,77866,8389565]

theorem envBound6418 : H12AffineFastState.Bounded env6418 := by
  intro p hp
  have h : env6418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6382_6418 : H12AffineEnvironment.transform 5 17 env6382 = env6418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6382 == env6418) = true)

theorem identity6418 : scanCanonicalize (H12AffineFastState.compose env6418 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6418 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6419 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,98474,445,41003,8329,445,323712,16385,16812,22561,74794,94251,257,20480,77866,512]

theorem envBound6419 : H12AffineFastState.Bounded env6419 := by
  intro p hp
  have h : env6419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6418_6419 : H12AffineEnvironment.transform 22 445 env6418 = env6419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6418 == env6419) = true)

theorem identity6419 : scanCanonicalize (H12AffineFastState.compose env6419 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6419 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6420 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1025,32768,4097,41349,445,41003,8329,445,323712,16385,16812,22561,1285,20740,257,20480,4357,512]

theorem envBound6420 : H12AffineFastState.Bounded env6420 := by
  intro p hp
  have h : env6420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6419_6420 : H12AffineEnvironment.transform 15 8495 env6419 = env6420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6419 == env6420) = true)

theorem identity6420 : scanCanonicalize (H12AffineFastState.compose env6420 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6420 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6421 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1025,26261,4097,18192,445,18110,8329,445,267797,16385,16812,22561,1285,20740,257,20480,4357,512]

theorem envBound6421 : H12AffineFastState.Bounded env6421 := by
  intro p hp
  have h : env6421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6420_6421 : H12AffineEnvironment.transform 14 26261 env6420 = env6421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6420 == env6421) = true)

theorem identity6421 : scanCanonicalize (H12AffineFastState.compose env6421 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound6421 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6422 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,262144,1025,14136,4097,5821,445,5907,8329,445,267797,4524,4097,2444,1285,169,257,429,4357,512]

theorem envBound6422 : H12AffineFastState.Bounded env6422 := by
  intro p hp
  have h : env6422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6421_6422 : H12AffineEnvironment.transform 13 4525 env6421 = env6422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env6421 == env6422) = true)

theorem identity6422 : scanCanonicalize (H12AffineFastState.compose env6422 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6422 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6423 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,14136,8495,4524,2184,1025,14136,4097,5821,445,5907,8329,445,7837,4524,4097,2444,1285,169,257,429,4357,512]

theorem envBound6423 : H12AffineFastState.Bounded env6423 := by
  intro p hp
  have h : env6423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6422_6423 : H12AffineEnvironment.transform 17 2184 env6422 = env6423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6422 == env6423) = true)

theorem identity6423 : scanCanonicalize (H12AffineFastState.compose env6423 (packedSelected [18,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6423 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6424 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,4356,14136,8495,4357,2081,1025,14136,4097,5652,276,5907,8224,276,7732,4357,4097,2341,1285,0,257,260,4357,512]

theorem envBound6424 : H12AffineFastState.Bounded env6424 := by
  intro p hp
  have h : env6424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6423_6424 : H12AffineEnvironment.transform 6 41 env6423 = env6424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6423 == env6424) = true)

theorem identity6424 : scanCanonicalize (H12AffineFastState.compose env6424 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6424 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6425 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,8192,4097,13885,8234,4096,2081,1025,13885,4097,5652,17,5654,8224,17,7732,4096,4097,2080,1024,0,4,1,4096,512]

theorem envBound6425 : H12AffineFastState.Bounded env6425 := by
  intro p hp
  have h : env6425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6424_6425 : H12AffineEnvironment.transform 7 5 env6424 = env6425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6424 == env6425) = true)

theorem identity6425 : scanCanonicalize (H12AffineFastState.compose env6425 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 7740) := by decide +kernel

theorem selectedBound6425 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6426 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,4096,7740,4097,2049,7702,4096,2081,1025,2049,4097,5652,17,5654,7708,17,7732,4096,4097,2080,1024,0,4,1,4096,512]

theorem envBound6426 : H12AffineFastState.Bounded env6426 := by
  intro p hp
  have h : env6426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6425_6426 : H12AffineEnvironment.transform 12 7740 env6425 = env6426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7740 env6425 == env6426) = true)

theorem identity6426 : scanCanonicalize (H12AffineFastState.compose env6426 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6426 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6427 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1551,4096,4147,4097,1550,4121,4096,1582,1025,1550,4097,5652,17,5654,4115,17,4155,4096,4097,1583,1024,0,4,1,4096,512]

theorem envBound6427 : H12AffineFastState.Bounded env6427 := by
  intro p hp
  have h : env6427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6426_6427 : H12AffineEnvironment.transform 10 1551 env6426 = env6427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6426 == env6427) = true)

theorem identity6427 : scanCanonicalize (H12AffineFastState.compose env6427 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound6427 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6428 : List Nat := [2,4,8,16,32,17,41,5,33,1024,1070,4096,4147,4097,1071,4121,4096,1039,1025,1071,4097,5173,17,5175,4115,17,4155,4096,4097,1038,1024,0,4,1,4096,33]

theorem envBound6428 : H12AffineFastState.Bounded env6428 := by
  intro p hp
  have h : env6428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6427_6428 : H12AffineEnvironment.transform 8 33 env6427 = env6428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env6427 == env6428) = true)

theorem identity6428 : scanCanonicalize (H12AffineFastState.compose env6428 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound6428 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6429 : List Nat := [2,4,8,16,32,17,41,5,33,14,32,4096,4147,4097,33,4121,4096,1,15,33,4097,4155,17,4153,4115,17,4155,4096,4097,0,14,0,4,1,4096,33]

theorem envBound6429 : H12AffineFastState.Bounded env6429 := by
  intro p hp
  have h : env6429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6428_6429 : H12AffineEnvironment.transform 9 14 env6428 = env6429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env6428 == env6429) = true)

theorem identity6429 : scanCanonicalize (H12AffineFastState.compose env6429 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6430 : List Nat := [2,4,8,16,26,17,19,5,27,14,26,4096,4105,4097,27,4121,4096,1,15,27,4097,4097,17,4099,4115,17,4097,4096,4097,0,14,0,4,1,4096,27]

theorem envBound6430 : H12AffineFastState.Bounded env6430 := by
  intro p hp
  have h : env6430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6429_6430 : H12AffineEnvironment.transform 4 26 env6429 = env6430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6429 == env6430) = true)

theorem identity6430 : scanCanonicalize (H12AffineFastState.compose env6430 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6431 : List Nat := [2,4,8,11,1,10,8,5,0,14,1,4096,4105,4097,0,4098,4096,1,15,0,4097,4097,10,4099,4104,10,4097,4096,4097,0,14,0,4,1,4096,0]

theorem envBound6431 : H12AffineFastState.Bounded env6431 := by
  intro p hp
  have h : env6431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6430_6431 : H12AffineEnvironment.transform 3 11 env6430 = env6431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6430 == env6431) = true)

def env6432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914001,2942160,16384,16892,2641009,598058,14737724,525568,2638928,6332544,8914925]

theorem envBound6432 : H12AffineFastState.Bounded env6432 := by
  intro p hp
  have h : env6432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6172_6432 : H12AffineEnvironment.transform 25 8914001 env6172 = env6432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env6172 == env6432) = true)

def env6433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849104,16384,16892,547953,598058,12644668,525568,545872,4239488,8914925]

theorem envBound6433 : H12AffineFastState.Bounded env6433 := by
  intro p hp
  have h : env6433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6432_6433 : H12AffineEnvironment.transform 20 4096 env6432 = env6433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env6432 == env6433) = true)

def env6434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323792,16384,16892,22641,74794,12644668,256,20560,4239488,8389613]

theorem envBound6434 : H12AffineFastState.Bounded env6434 := by
  intro p hp
  have h : env6434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6433_6434 : H12AffineEnvironment.transform 18 1024 env6433 = env6434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6433 == env6434) = true)

theorem identity6434 : scanCanonicalize (H12AffineFastState.compose env6434 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73922) := by decide +kernel

theorem selectedBound6434 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,73922,41003,8329,73875,323792,16384,16892,22641,74794,4313598,256,20560,4239488,74543]

theorem envBound6435 : H12AffineFastState.Bounded env6435 := by
  intro p hp
  have h : env6435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6434_6435 : H12AffineEnvironment.transform 22 73922 env6434 = env6435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73922 env6434 == env6435) = true)

def env6436 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,73874,41003,8329,73875,323712,16384,16812,22561,74794,4313518,256,20480,4239488,74543]

theorem envBound6436 : H12AffineFastState.Bounded env6436 := by
  intro p hp
  have h : env6436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6435_6436 : H12AffineEnvironment.transform 5 16 env6435 = env6436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6435 == env6436) = true)

def env6437 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41088,73874,41003,8329,73875,323712,16384,16812,22561,74794,94510,256,20480,4096,74543]

theorem envBound6437 : H12AffineFastState.Bounded env6437 := by
  intro p hp
  have h : env6437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6436_6437 : H12AffineEnvironment.transform 21 41088 env6436 = env6437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6436 == env6437) = true)

theorem identity6437 : scanCanonicalize (H12AffineFastState.compose env6437 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound6437 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6438 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8234,4525,262144,1024,32768,4096,41088,184,41003,8329,185,323712,16384,16812,22561,1024,20740,256,20480,4096,773]

theorem envBound6438 : H12AffineFastState.Bounded env6438 := by
  intro p hp
  have h : env6438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6437_6438 : H12AffineEnvironment.transform 15 8234 env6437 = env6438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env6437 == env6438) = true)

theorem identity6438 : scanCanonicalize (H12AffineFastState.compose env6438 (packedSelected [0,3,5,7,8,13,15,17,18,20,23,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound6438 : packedSelected [0,3,5,7,8,13,15,17,18,20,23,28,38] rootPS < 2^1333 := by decide +kernel

def env6439 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8234,4525,7869,1024,32768,4096,41088,184,41003,8329,185,60989,16384,16812,22561,1024,20740,256,20480,4096,773]

theorem envBound6439 : H12AffineFastState.Bounded env6439 := by
  intro p hp
  have h : env6439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6438_6439 : H12AffineEnvironment.transform 17 7869 env6438 = env6439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env6438 == env6439) = true)

def env6440 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,8234,4525,7869,1024,32768,4096,41088,184,41003,8329,185,48789,4264,4356,2185,1024,428,256,168,4096,773]

theorem envBound6440 : H12AffineFastState.Bounded env6440 := by
  intro p hp
  have h : env6440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6439_6440 : H12AffineEnvironment.transform 13 4264 env6439 = env6440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env6439 == env6440) = true)

theorem identity6440 : scanCanonicalize (H12AffineFastState.compose env6440 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6440 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6441 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4264,32768,8234,4097,7869,1024,32768,4096,41088,184,41003,8329,185,48789,4264,4264,2185,1024,0,172,168,4096,681]

theorem envBound6441 : H12AffineFastState.Bounded env6441 := by
  intro p hp
  have h : env6441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6440_6441 : H12AffineEnvironment.transform 7 172 env6440 = env6441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6440 == env6441) = true)

theorem identity6441 : scanCanonicalize (H12AffineFastState.compose env6441 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6441 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6442 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,4096,32768,8234,4097,7701,1024,32768,4096,41000,16,41003,8225,17,48701,4096,4096,2081,1024,0,4,0,4096,513]

theorem envBound6442 : H12AffineFastState.Bounded env6442 := by
  intro p hp
  have h : env6442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6441_6442 : H12AffineEnvironment.transform 6 40 env6441 = env6442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6441 == env6442) = true)

theorem identity6442 : scanCanonicalize (H12AffineFastState.compose env6442 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6443 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1551,4096,8192,4096,32768,8234,4097,4122,1024,32768,4096,41000,16,41003,8225,17,45106,4096,4096,1582,1024,0,4,0,4096,513]

theorem envBound6443 : H12AffineFastState.Bounded env6443 := by
  intro p hp
  have h : env6443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6442_6443 : H12AffineEnvironment.transform 10 1551 env6442 = env6443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6442 == env6443) = true)

end H12CloudChart1