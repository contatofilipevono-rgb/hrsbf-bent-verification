import H12CloudChart1Data237

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans60383_60384 : H12AffineEnvironment.transform 4 17 env60383 = env60384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60383 == env60384) = true)

theorem identity60384 : scanCanonicalize (H12AffineFastState.compose env60384 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound60384 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60385 : List Nat := [2,4,8,16,17,64,89,95,0,31,26,75,24,27,75,67,27,81,30,75,1,16,64,82,72,17,26,26,75,81,68,16,95,17,27,0]

theorem envBound60385 : H12AffineFastState.Bounded env60385 := by
  intro p hp
  have h : env60385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60384_60385 : H12AffineEnvironment.transform 6 89 env60384 = env60385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env60384 == env60385) = true)

theorem identity60385 : scanCanonicalize (H12AffineFastState.compose env60385 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60385 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60386 : List Nat := [2,4,8,16,17,17,8,14,0,31,26,26,24,27,26,18,27,0,30,26,1,16,17,3,25,17,26,26,26,0,21,16,14,17,27,0]

theorem envBound60386 : H12AffineFastState.Bounded env60386 := by
  intro p hp
  have h : env60386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60385_60386 : H12AffineEnvironment.transform 5 17 env60385 = env60386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60385 == env60386) = true)

theorem identity60386 : scanCanonicalize (H12AffineFastState.compose env60386 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60386 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60387 : List Nat := [2,4,8,11,10,10,8,14,0,4,1,1,3,0,1,9,0,0,5,1,1,11,10,3,2,10,1,1,1,0,14,11,14,10,0,0]

theorem envBound60387 : H12AffineFastState.Bounded env60387 := by
  intro p hp
  have h : env60387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60386_60387 : H12AffineEnvironment.transform 3 11 env60386 = env60387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60386 == env60387) = true)

def env60388 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound60388 : H12AffineFastState.Bounded env60388 := by
  intro p hp
  have h : env60388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60361_60388 : H12AffineEnvironment.transform 8 1 env60361 = env60388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60361 == env60388) = true)

theorem identity60388 : scanCanonicalize (H12AffineFastState.compose env60388 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound60388 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60389 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,7433,4176,2128,65536,69083,262144,1025,2128,2097152,1417,6344,3158,1288,6297,2365812,4177,69003,66899,65543,68095,256,65675,69083,6281]

theorem envBound60389 : H12AffineFastState.Bounded env60389 := by
  intro p hp
  have h : env60389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60388_60389 : H12AffineEnvironment.transform 12 7433 env60388 = env60389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env60388 == env60389) = true)

def env60390 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,2097152,1417,64,3158,1288,17,2359804,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound60390 : H12AffineFastState.Bounded env60390 := by
  intro p hp
  have h : env60390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60389_60390 : H12AffineEnvironment.transform 11 2184 env60389 = env60390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env60389 == env60390) = true)

theorem identity60390 : scanCanonicalize (H12AffineFastState.compose env60390 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound60390 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60391 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,65650,1417,64,3158,1288,17,328078,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound60391 : H12AffineFastState.Bounded env60391 := by
  intro p hp
  have h : env60391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60390_60391 : H12AffineEnvironment.transform 20 65650 env60390 = env60391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env60390 == env60391) = true)

theorem identity60391 : scanCanonicalize (H12AffineFastState.compose env60391 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound60391 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60392 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2128,65536,69083,97,1025,2128,65650,1417,64,3158,1288,17,66031,2265,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound60392 : H12AffineFastState.Bounded env60392 := by
  intro p hp
  have h : env60392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60391_60392 : H12AffineEnvironment.transform 17 97 env60391 = env60392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env60391 == env60392) = true)

theorem identity60392 : scanCanonicalize (H12AffineFastState.compose env60392 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60392 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60393 : List Nat := [2,4,8,16,32,64,128,256,1,409,2048,2184,24,2264,2128,65536,67650,97,408,2128,65650,16,64,2511,145,17,66031,2265,67602,65738,65543,68095,256,65675,67650,1]

theorem envBound60393 : H12AffineFastState.Bounded env60393 := by
  intro p hp
  have h : env60393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60392_60393 : H12AffineEnvironment.transform 9 409 env60392 = env60393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60392 == env60393) = true)

theorem identity60393 : scanCanonicalize (H12AffineFastState.compose env60393 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60393 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60394 : List Nat := [2,4,8,16,16,64,128,256,1,409,2048,2184,24,2264,2128,65536,67650,81,408,2128,65602,16,64,2511,145,17,66015,2265,67602,65738,65543,68047,256,65675,67650,1]

theorem envBound60394 : H12AffineFastState.Bounded env60394 := by
  intro p hp
  have h : env60394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60393_60394 : H12AffineEnvironment.transform 4 16 env60393 = env60394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60393 == env60394) = true)

theorem identity60394 : scanCanonicalize (H12AffineFastState.compose env60394 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound60394 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60395 : List Nat := [2,4,8,16,16,64,128,256,1,409,2048,2184,24,2264,2128,155,2265,81,408,2128,217,16,64,2511,145,17,324,2265,2185,81,156,2388,256,16,2265,1]

theorem envBound60395 : H12AffineFastState.Bounded env60395 := by
  intro p hp
  have h : env60395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60394_60395 : H12AffineEnvironment.transform 15 155 env60394 = env60395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env60394 == env60395) = true)

theorem identity60395 : scanCanonicalize (H12AffineFastState.compose env60395 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60395 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env60396 : List Nat := [2,4,8,16,16,64,128,256,1,409,324,460,24,412,276,155,413,81,408,276,217,16,64,139,145,17,324,413,461,81,156,16,256,16,413,1]

theorem envBound60396 : H12AffineFastState.Bounded env60396 := by
  intro p hp
  have h : env60396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60395_60396 : H12AffineEnvironment.transform 10 324 env60395 = env60396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60395 == env60396) = true)

theorem identity60396 : scanCanonicalize (H12AffineFastState.compose env60396 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60396 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60397 : List Nat := [2,4,8,16,16,64,128,21,1,140,81,217,24,137,1,155,136,81,141,1,217,16,64,139,145,17,81,136,216,81,156,16,21,16,136,1]

theorem envBound60397 : H12AffineFastState.Bounded env60397 := by
  intro p hp
  have h : env60397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60396_60397 : H12AffineEnvironment.transform 7 21 env60396 = env60397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60396 == env60397) = true)

theorem identity60397 : scanCanonicalize (H12AffineFastState.compose env60397 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60398 : List Nat := [2,4,8,16,16,64,19,21,1,31,81,74,24,26,1,8,27,81,30,1,74,16,64,24,2,17,81,27,75,81,15,16,21,16,27,1]

theorem envBound60398 : H12AffineFastState.Bounded env60398 := by
  intro p hp
  have h : env60398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60397_60398 : H12AffineEnvironment.transform 6 19 env60397 = env60398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60397 == env60398) = true)

theorem identity60398 : scanCanonicalize (H12AffineFastState.compose env60398 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound60398 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60399 : List Nat := [2,4,8,16,16,10,19,21,1,31,27,0,24,26,1,8,27,27,30,1,0,16,10,24,2,17,27,27,1,27,15,16,21,16,27,1]

theorem envBound60399 : H12AffineFastState.Bounded env60399 := by
  intro p hp
  have h : env60399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60398_60399 : H12AffineEnvironment.transform 5 10 env60398 = env60399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env60398 == env60399) = true)

theorem identity60399 : scanCanonicalize (H12AffineFastState.compose env60399 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60399 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60400 : List Nat := [2,4,8,10,10,10,9,15,1,5,1,0,2,0,1,8,1,1,4,1,0,10,10,2,2,11,1,1,1,1,15,10,15,10,1,1]

theorem envBound60400 : H12AffineFastState.Bounded env60400 := by
  intro p hp
  have h : env60400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60399_60400 : H12AffineEnvironment.transform 3 10 env60399 = env60400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60399 == env60400) = true)

def env60401 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,2097152,1417,65,3158,1288,16,2359805,2264,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound60401 : H12AffineFastState.Bounded env60401 := by
  intro p hp
  have h : env60401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60389_60401 : H12AffineEnvironment.transform 11 2185 env60389 = env60401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60389 == env60401) = true)

theorem identity60401 : scanCanonicalize (H12AffineFastState.compose env60401 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound60401 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60402 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,372,1417,65,3158,1288,16,262281,2264,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound60402 : H12AffineFastState.Bounded env60402 := by
  intro p hp
  have h : env60402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60401_60402 : H12AffineEnvironment.transform 20 372 env60401 = env60402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env60401 == env60402) = true)

theorem identity60402 : scanCanonicalize (H12AffineFastState.compose env60402 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60402 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60403 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1448,65536,65571,262144,1025,1448,372,1417,65,430,1288,16,262281,1312,65651,66899,65543,66567,256,65675,65571,0]

theorem envBound60403 : H12AffineFastState.Bounded env60403 := by
  intro p hp
  have h : env60403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60402_60403 : H12AffineEnvironment.transform 10 1528 env60402 = env60403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60402 == env60403) = true)

theorem identity60403 : scanCanonicalize (H12AffineFastState.compose env60403 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 65723) := by decide +kernel

theorem selectedBound60403 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60404 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1448,65536,65571,65723,1025,1448,372,1417,65,430,1288,16,65586,1312,65651,66899,65543,66567,256,65675,65571,0]

theorem envBound60404 : H12AffineFastState.Bounded env60404 := by
  intro p hp
  have h : env60404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60403_60404 : H12AffineEnvironment.transform 17 65723 env60403 = env60404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65723 env60403 == env60404) = true)

theorem identity60404 : scanCanonicalize (H12AffineFastState.compose env60404 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound60404 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60405 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,1393,1408,1313,1448,1063,1028,1180,1025,1448,372,1417,65,430,1288,16,1045,1312,1108,372,1056,32,256,1196,1028,0]

theorem envBound60405 : H12AffineFastState.Bounded env60405 := by
  intro p hp
  have h : env60405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60404_60405 : H12AffineEnvironment.transform 15 1063 env60404 = env60405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env60404 == env60405) = true)

theorem identity60405 : scanCanonicalize (H12AffineFastState.compose env60405 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60405 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60406 : List Nat := [2,4,8,16,32,64,128,256,1,221,293,428,349,508,373,250,217,65,220,373,372,340,65,430,469,16,200,509,137,372,253,32,256,113,217,0]

theorem envBound60406 : H12AffineFastState.Bounded env60406 := by
  intro p hp
  have h : env60406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60405_60406 : H12AffineEnvironment.transform 9 221 env60405 = env60406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60405 == env60406) = true)

theorem identity60406 : scanCanonicalize (H12AffineFastState.compose env60406 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound60406 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env60407 : List Nat := [2,4,8,16,32,64,128,141,1,221,168,33,208,113,248,250,217,65,220,248,249,217,65,35,88,16,200,112,137,249,253,32,141,113,217,0]

theorem envBound60407 : H12AffineFastState.Bounded env60407 := by
  intro p hp
  have h : env60407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60406_60407 : H12AffineEnvironment.transform 7 141 env60406 = env60407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env60406 == env60407) = true)

theorem identity60407 : scanCanonicalize (H12AffineFastState.compose env60407 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60407 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60408 : List Nat := [2,4,8,16,32,17,128,141,1,140,168,33,129,32,169,171,136,16,141,169,168,136,16,35,9,16,153,33,137,168,172,32,141,32,136,0]

theorem envBound60408 : H12AffineFastState.Bounded env60408 := by
  intro p hp
  have h : env60408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60407_60408 : H12AffineEnvironment.transform 5 17 env60407 = env60408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60407 == env60408) = true)

theorem identity60408 : scanCanonicalize (H12AffineFastState.compose env60408 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound60408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60409 : List Nat := [2,4,8,16,32,17,43,38,1,39,3,33,42,32,2,0,35,16,38,2,3,35,16,35,9,16,50,33,34,3,7,32,38,32,35,0]

theorem envBound60409 : H12AffineFastState.Bounded env60409 := by
  intro p hp
  have h : env60409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60408_60409 : H12AffineEnvironment.transform 6 43 env60408 = env60409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env60408 == env60409) = true)

theorem identity60409 : scanCanonicalize (H12AffineFastState.compose env60409 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound60409 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60410 : List Nat := [2,4,8,8,32,9,43,38,1,39,3,33,42,32,2,0,35,8,38,2,3,35,8,35,9,8,42,33,34,3,7,32,38,32,35,0]

theorem envBound60410 : H12AffineFastState.Bounded env60410 := by
  intro p hp
  have h : env60410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60409_60410 : H12AffineEnvironment.transform 3 8 env60409 = env60410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env60409 == env60410) = true)

theorem identity60410 : scanCanonicalize (H12AffineFastState.compose env60410 (packedSelected [1,3,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60410 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env60411 : List Nat := [1,4,8,8,32,9,40,37,1,36,0,33,41,32,1,0,32,8,37,1,0,32,8,32,9,8,41,33,33,0,4,32,37,32,32,0]

theorem envBound60411 : H12AffineFastState.Bounded env60411 := by
  intro p hp
  have h : env60411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60410_60411 : H12AffineEnvironment.transform 0 1 env60410 = env60411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60410 == env60411) = true)

theorem identity60411 : scanCanonicalize (H12AffineFastState.compose env60411 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60412 : List Nat := [1,4,8,8,9,9,1,12,1,13,0,8,0,9,1,0,9,8,12,1,0,9,8,9,9,8,0,8,8,0,4,9,12,9,9,0]

theorem envBound60412 : H12AffineFastState.Bounded env60412 := by
  intro p hp
  have h : env60412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60411_60412 : H12AffineEnvironment.transform 4 9 env60411 = env60412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60411 == env60412) = true)

theorem identity60412 : scanCanonicalize (H12AffineFastState.compose env60412 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60412 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60413 : List Nat := [1,4,1,1,0,0,1,5,1,4,0,1,0,0,1,0,0,1,5,1,0,0,1,0,0,1,0,1,1,0,4,0,5,0,0,0]

theorem envBound60413 : H12AffineFastState.Bounded env60413 := by
  intro p hp
  have h : env60413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60412_60413 : H12AffineEnvironment.transform 2 1 env60412 = env60413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60412 == env60413) = true)

def env60414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397001,8388689,6561533,4177,77954,4260571,8463814,8465982,256,4261123,78034,8389184]

theorem envBound60414 : H12AffineFastState.Bounded env60414 := by
  intro p hp
  have h : env60414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60220_60414 : H12AffineEnvironment.transform 26 6561533 env60220 = env60414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env60220 == env60414) = true)

def env60415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399766,8397001,8388689,2366325,4177,77954,67411,8463814,8465982,256,65675,78034,8389184]

theorem envBound60415 : H12AffineFastState.Bounded env60415 := by
  intro p hp
  have h : env60415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60414_60415 : H12AffineEnvironment.transform 21 1416 env60414 = env60415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env60414 == env60415) = true)

def env60416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3670,1289,9617,2366325,4177,77954,67411,65542,68606,256,65675,78034,10112]

theorem envBound60416 : H12AffineFastState.Bounded env60416 := by
  intro p hp
  have h : env60416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60415_60416 : H12AffineEnvironment.transform 22 9664 env60415 = env60416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60415 == env60416) = true)

def env60417 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1289,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound60417 : H12AffineFastState.Bounded env60417 := by
  intro p hp
  have h : env60417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60416_60417 : H12AffineEnvironment.transform 8 0 env60416 = env60417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60416 == env60417) = true)

theorem identity60417 : scanCanonicalize (H12AffineFastState.compose env60417 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound60417 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60418 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,65650,1416,9664,3158,1289,9617,334087,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound60418 : H12AffineFastState.Bounded env60418 := by
  intro p hp
  have h : env60418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60417_60418 : H12AffineEnvironment.transform 20 65650 env60417 = env60418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env60417 == env60418) = true)

def env60419 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,65650,1416,64,3158,1289,17,334087,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound60419 : H12AffineFastState.Bounded env60419 := by
  intro p hp
  have h : env60419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60418_60419 : H12AffineEnvironment.transform 12 1408 env60418 = env60419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60418 == env60419) = true)

theorem identity60419 : scanCanonicalize (H12AffineFastState.compose env60419 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60419 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60420 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,262144,1025,2129,65650,1416,64,3158,1289,17,328078,2264,69003,66899,65542,68094,256,65675,69083,0]

theorem envBound60420 : H12AffineFastState.Bounded env60420 := by
  intro p hp
  have h : env60420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60419_60420 : H12AffineEnvironment.transform 11 2185 env60419 = env60420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60419 == env60420) = true)

theorem identity60420 : scanCanonicalize (H12AffineFastState.compose env60420 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound60420 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60421 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2129,65536,69083,96,1025,2129,65650,1416,64,3158,1289,17,66030,2264,69003,66899,65542,68094,256,65675,69083,0]

theorem envBound60421 : H12AffineFastState.Bounded env60421 := by
  intro p hp
  have h : env60421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60420_60421 : H12AffineEnvironment.transform 17 96 env60420 = env60421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env60420 == env60421) = true)

theorem identity60421 : scanCanonicalize (H12AffineFastState.compose env60421 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60421 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60422 : List Nat := [2,4,8,16,32,64,128,256,0,408,2048,2185,24,2265,2129,65536,67651,96,409,2129,65650,16,64,2510,145,17,66030,2264,67603,65739,65542,68094,256,65675,67651,0]

theorem envBound60422 : H12AffineFastState.Bounded env60422 := by
  intro p hp
  have h : env60422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60421_60422 : H12AffineEnvironment.transform 9 408 env60421 = env60422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60421 == env60422) = true)

theorem identity60422 : scanCanonicalize (H12AffineFastState.compose env60422 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound60422 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60423 : List Nat := [2,4,8,16,32,64,128,256,0,408,372,509,24,429,293,65536,65847,96,409,293,65650,16,64,186,145,17,66030,428,65895,65739,65542,65674,256,65675,65847,0]

theorem envBound60423 : H12AffineFastState.Bounded env60423 := by
  intro p hp
  have h : env60423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60422_60423 : H12AffineEnvironment.transform 10 372 env60422 = env60423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env60422 == env60423) = true)

theorem identity60423 : scanCanonicalize (H12AffineFastState.compose env60423 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound60423 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60424 : List Nat := [2,4,8,16,32,64,128,256,0,408,372,509,24,429,293,171,412,96,409,293,217,16,64,186,145,17,325,428,460,96,173,33,256,32,412,0]

theorem envBound60424 : H12AffineFastState.Bounded env60424 := by
  intro p hp
  have h : env60424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60423_60424 : H12AffineEnvironment.transform 15 171 env60423 = env60424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env60423 == env60424) = true)

theorem identity60424 : scanCanonicalize (H12AffineFastState.compose env60424 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60424 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60425 : List Nat := [2,4,8,16,32,64,128,110,0,246,26,147,24,195,75,171,242,96,247,75,217,16,64,186,145,17,43,194,162,96,173,33,110,32,242,0]

theorem envBound60425 : H12AffineFastState.Bounded env60425 := by
  intro p hp
  have h : env60425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60424_60425 : H12AffineEnvironment.transform 7 110 env60424 = env60425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60424 == env60425) = true)

def env60426 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,65650,1416,65,3158,1289,16,334087,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound60426 : H12AffineFastState.Bounded env60426 := by
  intro p hp
  have h : env60426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60418_60426 : H12AffineEnvironment.transform 12 1409 env60418 = env60426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60418 == env60426) = true)

theorem identity60426 : scanCanonicalize (H12AffineFastState.compose env60426 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6542) := by decide +kernel

theorem selectedBound60426 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60427 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6542,3293,262144,1025,2129,6652,1416,65,3158,1289,16,262281,4177,3213,7389,6536,4208,256,6405,3293,1]

theorem envBound60427 : H12AffineFastState.Bounded env60427 := by
  intro p hp
  have h : env60427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60426_60427 : H12AffineEnvironment.transform 15 6542 env60426 = env60427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6542 env60426 == env60427) = true)

theorem identity60427 : scanCanonicalize (H12AffineFastState.compose env60427 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60427 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60428 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,5238,293,262144,1025,1449,5124,1416,65,430,1289,16,262281,4177,373,4389,5232,4208,256,5373,293,1]

theorem envBound60428 : H12AffineFastState.Bounded env60428 := by
  intro p hp
  have h : env60428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60427_60428 : H12AffineEnvironment.transform 10 1528 env60427 = env60428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60427 == env60428) = true)

theorem identity60428 : scanCanonicalize (H12AffineFastState.compose env60428 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 444) := by decide +kernel

theorem selectedBound60428 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60429 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,5238,293,444,1025,1449,5124,1416,65,430,1289,16,309,4177,373,4389,5232,4208,256,5373,293,1]

theorem envBound60429 : H12AffineFastState.Bounded env60429 := by
  intro p hp
  have h : env60429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60428_60429 : H12AffineEnvironment.transform 17 444 env60428 = env60429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 444 env60428 == env60429) = true)

theorem identity60429 : scanCanonicalize (H12AffineFastState.compose env60429 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound60429 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60430 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,80,1409,0,1449,1062,293,444,1025,1449,1108,1416,65,430,1289,16,309,1,373,373,1056,32,256,1197,293,1]

theorem envBound60430 : H12AffineFastState.Bounded env60430 := by
  intro p hp
  have h : env60430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60429_60430 : H12AffineEnvironment.transform 11 80 env60429 = env60430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env60429 == env60430) = true)

theorem identity60430 : scanCanonicalize (H12AffineFastState.compose env60430 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60430 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60431 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,80,348,0,372,251,293,444,220,372,137,341,65,430,468,16,309,1,373,373,253,32,256,112,293,1]

theorem envBound60431 : H12AffineFastState.Bounded env60431 := by
  intro p hp
  have h : env60431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60430_60431 : H12AffineEnvironment.transform 9 221 env60430 = env60431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60430 == env60431) = true)

theorem identity60431 : scanCanonicalize (H12AffineFastState.compose env60431 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60431 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60432 : List Nat := [2,4,8,16,32,16,128,256,0,141,293,0,268,0,292,171,293,444,140,292,137,261,17,430,388,16,309,1,293,293,173,32,256,32,293,1]

theorem envBound60432 : H12AffineFastState.Bounded env60432 := by
  intro p hp
  have h : env60432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60431_60432 : H12AffineEnvironment.transform 5 16 env60431 = env60432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60431 == env60432) = true)

theorem identity60432 : scanCanonicalize (H12AffineFastState.compose env60432 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60432 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60433 : List Nat := [2,4,8,16,0,16,128,256,0,141,261,0,268,0,260,139,261,412,140,260,137,261,17,398,388,16,277,1,261,261,141,0,256,0,261,1]

theorem envBound60433 : H12AffineFastState.Bounded env60433 := by
  intro p hp
  have h : env60433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60432_60433 : H12AffineEnvironment.transform 4 0 env60432 = env60433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60432 == env60433) = true)

theorem identity60433 : scanCanonicalize (H12AffineFastState.compose env60433 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound60433 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60434 : List Nat := [2,4,8,16,0,16,0,256,0,13,261,0,268,0,260,11,261,284,12,260,9,261,17,270,260,16,277,1,261,261,13,0,256,0,261,1]

theorem envBound60434 : H12AffineFastState.Bounded env60434 := by
  intro p hp
  have h : env60434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60433_60434 : H12AffineEnvironment.transform 6 0 env60433 = env60434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env60433 == env60434) = true)

theorem identity60434 : scanCanonicalize (H12AffineFastState.compose env60434 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound60434 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60435 : List Nat := [2,4,8,16,0,16,0,6,0,13,3,0,10,0,2,11,3,26,12,2,9,3,17,8,2,16,19,1,3,3,13,0,6,0,3,1]

theorem envBound60435 : H12AffineFastState.Bounded env60435 := by
  intro p hp
  have h : env60435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60434_60435 : H12AffineEnvironment.transform 7 6 env60434 = env60435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env60434 == env60435) = true)

theorem identity60435 : scanCanonicalize (H12AffineFastState.compose env60435 (packedSelected [1,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60435 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60436 : List Nat := [2,4,2,16,0,16,0,6,0,7,3,0,0,0,2,1,3,16,6,2,3,3,17,2,2,16,19,1,3,3,7,0,6,0,3,1]

theorem envBound60436 : H12AffineFastState.Bounded env60436 := by
  intro p hp
  have h : env60436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60435_60436 : H12AffineEnvironment.transform 2 2 env60435 = env60436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60435 == env60436) = true)

theorem identity60436 : scanCanonicalize (H12AffineFastState.compose env60436 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60437 : List Nat := [2,4,2,2,0,2,0,6,0,7,3,0,0,0,2,1,3,2,6,2,3,3,3,2,2,2,1,1,3,3,7,0,6,0,3,1]

theorem envBound60437 : H12AffineFastState.Bounded env60437 := by
  intro p hp
  have h : env60437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60436_60437 : H12AffineEnvironment.transform 3 2 env60436 = env60437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60436 == env60437) = true)

theorem identity60437 : scanCanonicalize (H12AffineFastState.compose env60437 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60437 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60438 : List Nat := [1,4,1,1,0,1,0,5,0,4,0,0,0,0,1,1,0,1,5,1,0,0,0,1,1,1,1,1,0,0,4,0,5,0,0,1]

theorem envBound60438 : H12AffineFastState.Bounded env60438 := by
  intro p hp
  have h : env60438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60437_60438 : H12AffineEnvironment.transform 0 1 env60437 = env60438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60437 == env60438) = true)

def env60439 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1289,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound60439 : H12AffineFastState.Bounded env60439 := by
  intro p hp
  have h : env60439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60416_60439 : H12AffineEnvironment.transform 8 1 env60416 = env60439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60416 == env60439) = true)

theorem identity60439 : scanCanonicalize (H12AffineFastState.compose env60439 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 75251) := by decide +kernel

theorem selectedBound60439 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60440 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,75251,1416,9664,3159,1289,9617,343175,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound60440 : H12AffineFastState.Bounded env60440 := by
  intro p hp
  have h : env60440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60439_60440 : H12AffineEnvironment.transform 20 75251 env60439 = env60440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 75251 env60439 == env60440) = true)

def env60441 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,65651,1416,64,3159,1289,17,334087,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound60441 : H12AffineFastState.Bounded env60441 := by
  intro p hp
  have h : env60441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60440_60441 : H12AffineEnvironment.transform 12 1408 env60440 = env60441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60440 == env60441) = true)

theorem identity60441 : scanCanonicalize (H12AffineFastState.compose env60441 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound60441 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60442 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,65651,1416,64,3159,1289,17,328078,2264,69003,66898,65542,68095,256,65675,69083,1]

theorem envBound60442 : H12AffineFastState.Bounded env60442 := by
  intro p hp
  have h : env60442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60441_60442 : H12AffineEnvironment.transform 11 2185 env60441 = env60442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env60441 == env60442) = true)

theorem identity60442 : scanCanonicalize (H12AffineFastState.compose env60442 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound60442 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60443 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2185,1408,2265,2128,65536,69083,97,1025,2128,65651,1416,64,3159,1289,17,66031,2264,69003,66898,65542,68095,256,65675,69083,1]

theorem envBound60443 : H12AffineFastState.Bounded env60443 := by
  intro p hp
  have h : env60443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60442_60443 : H12AffineEnvironment.transform 17 97 env60442 = env60443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env60442 == env60443) = true)

theorem identity60443 : scanCanonicalize (H12AffineFastState.compose env60443 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60443 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60444 : List Nat := [2,4,8,16,32,64,128,256,1,408,2048,2185,24,2265,2128,65536,67651,97,409,2128,65651,16,64,2511,145,17,66031,2264,67603,65738,65542,68095,256,65675,67651,1]

theorem envBound60444 : H12AffineFastState.Bounded env60444 := by
  intro p hp
  have h : env60444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60443_60444 : H12AffineEnvironment.transform 9 408 env60443 = env60444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60443 == env60444) = true)

theorem identity60444 : scanCanonicalize (H12AffineFastState.compose env60444 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60444 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60445 : List Nat := [2,4,8,16,16,64,128,256,1,408,2048,2185,24,2265,2128,65536,67651,81,409,2128,65603,16,64,2511,145,17,66015,2264,67603,65738,65542,68047,256,65675,67651,1]

theorem envBound60445 : H12AffineFastState.Bounded env60445 := by
  intro p hp
  have h : env60445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60444_60445 : H12AffineEnvironment.transform 4 16 env60444 = env60445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60444 == env60445) = true)

theorem identity60445 : scanCanonicalize (H12AffineFastState.compose env60445 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound60445 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60446 : List Nat := [2,4,8,16,16,64,128,256,1,408,2048,2185,24,2265,2128,155,2264,81,409,2128,216,16,64,2511,145,17,324,2264,2184,81,157,2388,256,16,2264,1]

theorem envBound60446 : H12AffineFastState.Bounded env60446 := by
  intro p hp
  have h : env60446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60445_60446 : H12AffineEnvironment.transform 15 155 env60445 = env60446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env60445 == env60446) = true)

theorem identity60446 : scanCanonicalize (H12AffineFastState.compose env60446 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60446 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env60447 : List Nat := [2,4,8,16,16,64,128,256,1,408,325,460,24,412,277,155,413,81,409,277,216,16,64,138,145,17,324,413,461,81,157,17,256,16,413,1]

theorem envBound60447 : H12AffineFastState.Bounded env60447 := by
  intro p hp
  have h : env60447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60446_60447 : H12AffineEnvironment.transform 10 325 env60446 = env60447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60446 == env60447) = true)

def env60448 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,65650,1416,65,3159,1289,16,334086,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound60448 : H12AffineFastState.Bounded env60448 := by
  intro p hp
  have h : env60448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60440_60448 : H12AffineEnvironment.transform 12 1409 env60440 = env60448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60440 == env60448) = true)

theorem identity60448 : scanCanonicalize (H12AffineFastState.compose env60448 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6543) := by decide +kernel

theorem selectedBound60448 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60449 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6543,3292,262144,1025,2128,6653,1416,65,3159,1289,16,262281,4177,3212,7389,6537,4208,256,6404,3292,0]

theorem envBound60449 : H12AffineFastState.Bounded env60449 := by
  intro p hp
  have h : env60449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60448_60449 : H12AffineEnvironment.transform 15 6543 env60448 = env60449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6543 env60448 == env60449) = true)

theorem identity60449 : scanCanonicalize (H12AffineFastState.compose env60449 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60449 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60450 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,5238,293,262144,1025,1449,5124,1416,65,430,1289,16,262281,4177,373,4388,5232,4208,256,5373,293,0]

theorem envBound60450 : H12AffineFastState.Bounded env60450 := by
  intro p hp
  have h : env60450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60449_60450 : H12AffineEnvironment.transform 10 1529 env60449 = env60450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60449 == env60450) = true)

theorem identity60450 : scanCanonicalize (H12AffineFastState.compose env60450 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 444) := by decide +kernel

theorem selectedBound60450 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60451 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,5238,293,444,1025,1449,5124,1416,65,430,1289,16,309,4177,373,4388,5232,4208,256,5373,293,0]

theorem envBound60451 : H12AffineFastState.Bounded env60451 := by
  intro p hp
  have h : env60451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60450_60451 : H12AffineEnvironment.transform 17 444 env60450 = env60451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 444 env60450 == env60451) = true)

theorem identity60451 : scanCanonicalize (H12AffineFastState.compose env60451 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound60451 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60452 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,80,1409,0,1449,1062,293,444,1025,1449,1108,1416,65,430,1289,16,309,1,373,372,1056,32,256,1197,293,0]

theorem envBound60452 : H12AffineFastState.Bounded env60452 := by
  intro p hp
  have h : env60452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60451_60452 : H12AffineEnvironment.transform 11 80 env60451 = env60452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env60451 == env60452) = true)

theorem identity60452 : scanCanonicalize (H12AffineFastState.compose env60452 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60452 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60453 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,80,349,0,373,250,293,444,221,373,136,340,65,430,469,16,309,1,373,372,252,32,256,113,293,0]

theorem envBound60453 : H12AffineFastState.Bounded env60453 := by
  intro p hp
  have h : env60453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60452_60453 : H12AffineEnvironment.transform 9 220 env60452 = env60453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60452 == env60453) = true)

theorem identity60453 : scanCanonicalize (H12AffineFastState.compose env60453 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60453 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60454 : List Nat := [2,4,8,16,32,64,128,172,1,220,137,80,241,0,217,250,137,16,221,217,136,248,65,2,121,16,153,1,217,216,252,32,172,113,137,0]

theorem envBound60454 : H12AffineFastState.Bounded env60454 := by
  intro p hp
  have h : env60454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60453_60454 : H12AffineEnvironment.transform 7 172 env60453 = env60454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60453 == env60454) = true)

theorem identity60454 : scanCanonicalize (H12AffineFastState.compose env60454 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60454 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60455 : List Nat := [2,4,8,16,32,33,128,172,1,189,137,49,144,0,184,155,137,16,188,184,136,153,32,2,24,16,153,1,184,185,157,32,172,16,137,0]

theorem envBound60455 : H12AffineFastState.Bounded env60455 := by
  intro p hp
  have h : env60455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60454_60455 : H12AffineEnvironment.transform 5 33 env60454 = env60455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60454 == env60455) = true)

theorem identity60455 : scanCanonicalize (H12AffineFastState.compose env60455 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 32) := by decide +kernel

theorem selectedBound60455 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60456 : List Nat := [2,4,8,16,32,33,32,12,1,29,41,49,48,0,24,59,41,16,28,24,40,57,32,2,24,16,57,1,24,25,61,32,12,16,41,0]

theorem envBound60456 : H12AffineFastState.Bounded env60456 := by
  intro p hp
  have h : env60456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60455_60456 : H12AffineEnvironment.transform 6 32 env60455 = env60456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 32 env60455 == env60456) = true)

theorem identity60456 : scanCanonicalize (H12AffineFastState.compose env60456 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound60456 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60457 : List Nat := [2,4,8,16,19,18,19,12,1,29,26,2,3,0,24,8,26,16,28,24,27,10,19,2,24,16,10,1,24,25,14,19,12,16,26,0]

theorem envBound60457 : H12AffineFastState.Bounded env60457 := by
  intro p hp
  have h : env60457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60456_60457 : H12AffineEnvironment.transform 4 19 env60456 = env60457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env60456 == env60457) = true)

theorem identity60457 : scanCanonicalize (H12AffineFastState.compose env60457 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60458 : List Nat := [2,4,8,0,3,2,3,12,1,13,10,2,3,0,8,8,10,0,12,8,11,10,3,2,8,0,10,1,8,9,14,3,12,0,10,0]

theorem envBound60458 : H12AffineFastState.Bounded env60458 := by
  intro p hp
  have h : env60458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60457_60458 : H12AffineEnvironment.transform 3 0 env60457 = env60458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60457 == env60458) = true)

theorem identity60458 : scanCanonicalize (H12AffineFastState.compose env60458 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60458 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60459 : List Nat := [2,4,3,0,3,2,3,7,1,6,1,2,3,0,3,3,1,0,7,3,0,1,3,2,3,0,1,1,3,2,5,3,7,0,1,0]

theorem envBound60459 : H12AffineFastState.Bounded env60459 := by
  intro p hp
  have h : env60459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60458_60459 : H12AffineEnvironment.transform 2 3 env60458 = env60459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60458 == env60459) = true)

theorem identity60459 : scanCanonicalize (H12AffineFastState.compose env60459 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60459 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60460 : List Nat := [1,4,0,0,0,1,0,4,1,5,1,1,0,0,0,0,1,0,4,0,0,1,0,1,0,0,1,1,0,1,5,0,4,0,1,0]

theorem envBound60460 : H12AffineFastState.Bounded env60460 := by
  intro p hp
  have h : env60460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60459_60460 : H12AffineEnvironment.transform 0 1 env60459 = env60460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60459 == env60460) = true)

def env60461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3671,1288,9616,2366325,4177,77954,67411,65543,68607,256,65675,78034,10113]

theorem envBound60461 : H12AffineFastState.Bounded env60461 := by
  intro p hp
  have h : env60461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60415_60461 : H12AffineEnvironment.transform 22 9665 env60415 = env60461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60415 == env60461) = true)

def env60462 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound60462 : H12AffineFastState.Bounded env60462 := by
  intro p hp
  have h : env60462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60461_60462 : H12AffineEnvironment.transform 8 0 env60461 = env60462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60461 == env60462) = true)

theorem identity60462 : scanCanonicalize (H12AffineFastState.compose env60462 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 15779) := by decide +kernel

theorem selectedBound60462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60463 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,15779,3441,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365813,4177,3361,14576,15780,13404,256,15656,3441,9601]

theorem envBound60463 : H12AffineFastState.Bounded env60463 := by
  intro p hp
  have h : env60463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60462_60463 : H12AffineEnvironment.transform 15 15779 env60462 = env60463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15779 env60462 == env60463) = true)

def env60464 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,2097152,1416,65,3159,1288,16,2365813,4177,3361,7536,6180,4572,256,6312,3441,1]

theorem envBound60464 : H12AffineFastState.Bounded env60464 := by
  intro p hp
  have h : env60464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60463_60464 : H12AffineEnvironment.transform 12 1408 env60463 = env60464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60463 == env60464) = true)

theorem identity60464 : scanCanonicalize (H12AffineFastState.compose env60464 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60464 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60465 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,6652,1416,65,3159,1288,16,262281,4177,3361,7536,6180,4572,256,6312,3441,1]

theorem envBound60465 : H12AffineFastState.Bounded env60465 := by
  intro p hp
  have h : env60465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60464_60465 : H12AffineEnvironment.transform 20 6652 env60464 = env60465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60464 == env60465) = true)

theorem identity60465 : scanCanonicalize (H12AffineFastState.compose env60465 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60465 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60466 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,5595,137,262144,1025,1449,5124,1416,65,431,1288,16,262281,4177,217,4232,5596,4572,256,5456,137,1]

theorem envBound60466 : H12AffineFastState.Bounded env60466 := by
  intro p hp
  have h : env60466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60465_60466 : H12AffineEnvironment.transform 10 1528 env60465 = env60466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60465 == env60466) = true)

theorem identity60466 : scanCanonicalize (H12AffineFastState.compose env60466 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 17) := by decide +kernel

theorem selectedBound60466 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60467 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,5595,137,17,1025,1449,5124,1416,65,431,1288,16,152,4177,217,4232,5596,4572,256,5456,137,1]

theorem envBound60467 : H12AffineFastState.Bounded env60467 := by
  intro p hp
  have h : env60467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60466_60467 : H12AffineEnvironment.transform 17 17 env60466 = env60467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17 env60466 == env60467) = true)

theorem identity60467 : scanCanonicalize (H12AffineFastState.compose env60467 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound60467 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60468 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,509,1408,429,1449,1062,137,17,1025,1449,1529,1416,65,431,1288,16,152,428,217,373,1057,33,256,1197,137,1]

theorem envBound60468 : H12AffineFastState.Bounded env60468 := by
  intro p hp
  have h : env60468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60467_60468 : H12AffineEnvironment.transform 11 509 env60467 = env60468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env60467 == env60468) = true)

theorem identity60468 : scanCanonicalize (H12AffineFastState.compose env60468 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60468 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60469 : List Nat := [2,4,8,16,32,64,128,256,0,221,293,509,349,429,372,251,137,17,220,372,292,341,65,431,469,16,152,428,217,373,252,33,256,112,137,1]

theorem envBound60469 : H12AffineFastState.Bounded env60469 := by
  intro p hp
  have h : env60469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60468_60469 : H12AffineEnvironment.transform 9 221 env60468 = env60469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60468 == env60469) = true)

theorem identity60469 : scanCanonicalize (H12AffineFastState.compose env60469 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60469 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60470 : List Nat := [2,4,8,16,32,64,128,172,0,221,137,81,241,1,216,251,137,17,220,216,136,249,65,3,121,16,152,0,217,217,252,33,172,112,137,1]

theorem envBound60470 : H12AffineFastState.Bounded env60470 := by
  intro p hp
  have h : env60470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60469_60470 : H12AffineEnvironment.transform 7 172 env60469 = env60470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60469 == env60470) = true)

theorem identity60470 : scanCanonicalize (H12AffineFastState.compose env60470 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound60470 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60471 : List Nat := [2,4,8,16,32,64,120,84,0,37,113,81,9,1,32,3,113,17,36,32,112,1,65,3,121,16,96,0,33,33,4,33,84,112,113,1]

theorem envBound60471 : H12AffineFastState.Bounded env60471 := by
  intro p hp
  have h : env60471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60470_60471 : H12AffineEnvironment.transform 6 120 env60470 = env60471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env60470 == env60471) = true)

theorem identity60471 : scanCanonicalize (H12AffineFastState.compose env60471 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60471 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60472 : List Nat := [2,4,8,16,32,58,2,46,0,37,11,43,9,1,32,3,11,17,36,32,10,1,59,3,3,16,26,0,33,33,4,33,46,10,11,1]

theorem envBound60472 : H12AffineFastState.Bounded env60472 := by
  intro p hp
  have h : env60472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60471_60472 : H12AffineEnvironment.transform 5 58 env60471 = env60472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60471 == env60472) = true)

theorem identity60472 : scanCanonicalize (H12AffineFastState.compose env60472 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60472 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60473 : List Nat := [2,4,8,16,2,24,2,12,0,7,11,9,9,1,2,3,11,17,6,2,10,1,25,3,3,16,26,0,3,3,4,3,12,10,11,1]

theorem envBound60473 : H12AffineFastState.Bounded env60473 := by
  intro p hp
  have h : env60473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60472_60473 : H12AffineEnvironment.transform 4 2 env60472 = env60473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60472 == env60473) = true)

theorem identity60473 : scanCanonicalize (H12AffineFastState.compose env60473 (packedSelected [0,1,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60473 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env60474 : List Nat := [2,4,0,16,2,16,2,4,0,7,3,1,1,1,2,3,3,17,6,2,2,1,17,3,3,16,18,0,3,3,4,3,4,2,3,1]

theorem envBound60474 : H12AffineFastState.Bounded env60474 := by
  intro p hp
  have h : env60474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60473_60474 : H12AffineEnvironment.transform 2 0 env60473 = env60474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60473 == env60474) = true)

theorem identity60474 : scanCanonicalize (H12AffineFastState.compose env60474 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60474 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60475 : List Nat := [2,4,0,1,2,1,2,4,0,7,3,1,1,1,2,3,3,0,6,2,2,1,0,3,3,1,3,0,3,3,4,3,4,2,3,1]

theorem envBound60475 : H12AffineFastState.Bounded env60475 := by
  intro p hp
  have h : env60475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60474_60475 : H12AffineEnvironment.transform 3 1 env60474 = env60475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60474 == env60475) = true)

theorem identity60475 : scanCanonicalize (H12AffineFastState.compose env60475 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60475 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60476 : List Nat := [1,4,0,1,1,1,1,4,0,4,0,1,1,1,1,0,0,0,5,1,1,1,0,0,0,1,0,0,0,0,4,0,4,1,0,1]

theorem envBound60476 : H12AffineFastState.Bounded env60476 := by
  intro p hp
  have h : env60476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60475_60476 : H12AffineEnvironment.transform 0 1 env60475 = env60476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60475 == env60476) = true)

def env60477 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,2097152,1416,64,3159,1288,17,2365813,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound60477 : H12AffineFastState.Bounded env60477 := by
  intro p hp
  have h : env60477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60463_60477 : H12AffineEnvironment.transform 12 1409 env60463 = env60477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60463 == env60477) = true)

theorem identity60477 : scanCanonicalize (H12AffineFastState.compose env60477 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound60477 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60478 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,262144,1025,2129,216,1416,64,3159,1288,17,268717,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound60478 : H12AffineFastState.Bounded env60478 := by
  intro p hp
  have h : env60478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60477_60478 : H12AffineEnvironment.transform 20 216 env60477 = env60478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env60477 == env60478) = true)

theorem identity60478 : scanCanonicalize (H12AffineFastState.compose env60478 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60478 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60479 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,6178,3441,6377,1025,2129,216,1416,64,3159,1288,17,324,4177,3361,7537,6181,4573,256,6313,3441,0]

theorem envBound60479 : H12AffineFastState.Bounded env60479 := by
  intro p hp
  have h : env60479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60478_60479 : H12AffineEnvironment.transform 17 6377 env60478 = env60479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60478 == env60479) = true)

theorem identity60479 : scanCanonicalize (H12AffineFastState.compose env60479 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60479 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60480 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1409,413,2129,2543,3441,2340,1025,2129,216,1416,64,3159,1288,17,324,412,3361,3260,2536,16,256,2404,3441,0]

theorem envBound60480 : H12AffineFastState.Bounded env60480 := by
  intro p hp
  have h : env60480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60479_60480 : H12AffineEnvironment.transform 11 461 env60479 = env60480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60479 == env60480) = true)

theorem identity60480 : scanCanonicalize (H12AffineFastState.compose env60480 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60480 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60481 : List Nat := [2,4,8,16,32,64,128,256,0,408,2048,461,25,413,2129,2543,2281,2340,409,2129,216,16,64,2511,144,17,324,412,2233,2340,2536,16,256,2404,2281,0]

theorem envBound60481 : H12AffineFastState.Bounded env60481 := by
  intro p hp
  have h : env60481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60480_60481 : H12AffineEnvironment.transform 9 408 env60480 = env60481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60480 == env60481) = true)

theorem identity60481 : scanCanonicalize (H12AffineFastState.compose env60481 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60481 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60482 : List Nat := [2,4,8,16,32,64,128,256,0,408,325,461,25,413,276,170,428,97,409,276,216,16,64,138,144,17,324,412,508,97,173,16,256,33,428,0]

theorem envBound60482 : H12AffineFastState.Bounded env60482 := by
  intro p hp
  have h : env60482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60481_60482 : H12AffineEnvironment.transform 10 325 env60481 = env60482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60481 == env60482) = true)

theorem identity60482 : scanCanonicalize (H12AffineFastState.compose env60482 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60482 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60483 : List Nat := [2,4,8,16,32,64,128,94,0,198,27,147,25,195,74,170,242,97,199,74,216,16,64,138,144,17,26,194,162,97,173,16,94,33,242,0]

theorem envBound60483 : H12AffineFastState.Bounded env60483 := by
  intro p hp
  have h : env60483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60482_60483 : H12AffineEnvironment.transform 7 94 env60482 = env60483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60482 == env60483) = true)

theorem identity60483 : scanCanonicalize (H12AffineFastState.compose env60483 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60483 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60484 : List Nat := [2,4,8,16,16,64,128,94,0,198,27,147,25,195,74,154,194,81,199,74,216,16,64,138,144,17,26,194,146,81,157,16,94,17,194,0]

theorem envBound60484 : H12AffineFastState.Bounded env60484 := by
  intro p hp
  have h : env60484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60483_60484 : H12AffineEnvironment.transform 4 16 env60483 = env60484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60483 == env60484) = true)

def env60485 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound60485 : H12AffineFastState.Bounded env60485 := by
  intro p hp
  have h : env60485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60461_60485 : H12AffineEnvironment.transform 8 1 env60461 = env60485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60461 == env60485) = true)

theorem identity60485 : scanCanonicalize (H12AffineFastState.compose env60485 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 6178) := by decide +kernel

theorem selectedBound60485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60486 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,6178,10480,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365812,4177,10400,7536,6181,4572,256,6313,10480,9600]

theorem envBound60486 : H12AffineFastState.Bounded env60486 := by
  intro p hp
  have h : env60486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60485_60486 : H12AffineEnvironment.transform 15 6178 env60485 = env60486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6178 env60485 == env60486) = true)

def env60487 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6178,3440,262144,1025,2128,2097152,1416,65,3158,1288,16,2365812,4177,3360,7536,6181,4572,256,6313,3440,0]

theorem envBound60487 : H12AffineFastState.Bounded env60487 := by
  intro p hp
  have h : env60487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60486_60487 : H12AffineEnvironment.transform 12 1408 env60486 = env60487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60486 == env60487) = true)

theorem identity60487 : scanCanonicalize (H12AffineFastState.compose env60487 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60487 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60488 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,6178,3440,262144,1025,2128,6653,1416,65,3158,1288,16,262281,4177,3360,7536,6181,4572,256,6313,3440,0]

theorem envBound60488 : H12AffineFastState.Bounded env60488 := by
  intro p hp
  have h : env60488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60487_60488 : H12AffineEnvironment.transform 20 6653 env60487 = env60488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60487 == env60488) = true)

theorem identity60488 : scanCanonicalize (H12AffineFastState.compose env60488 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60488 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60489 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,5595,137,262144,1025,1449,5124,1416,65,431,1288,16,262281,4177,217,4233,5596,4572,256,5456,137,0]

theorem envBound60489 : H12AffineFastState.Bounded env60489 := by
  intro p hp
  have h : env60489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60488_60489 : H12AffineEnvironment.transform 10 1529 env60488 = env60489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60488 == env60489) = true)

theorem identity60489 : scanCanonicalize (H12AffineFastState.compose env60489 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 17) := by decide +kernel

theorem selectedBound60489 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60490 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,5595,137,17,1025,1449,5124,1416,65,431,1288,16,152,4177,217,4233,5596,4572,256,5456,137,0]

theorem envBound60490 : H12AffineFastState.Bounded env60490 := by
  intro p hp
  have h : env60490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60489_60490 : H12AffineEnvironment.transform 17 17 env60489 = env60490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17 env60489 == env60490) = true)

theorem identity60490 : scanCanonicalize (H12AffineFastState.compose env60490 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound60490 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60491 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,509,1408,429,1449,1062,137,17,1025,1449,1529,1416,65,431,1288,16,152,428,217,372,1057,33,256,1197,137,0]

theorem envBound60491 : H12AffineFastState.Bounded env60491 := by
  intro p hp
  have h : env60491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60490_60491 : H12AffineEnvironment.transform 11 509 env60490 = env60491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env60490 == env60491) = true)

theorem identity60491 : scanCanonicalize (H12AffineFastState.compose env60491 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60491 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60492 : List Nat := [2,4,8,16,32,64,128,256,1,220,293,509,348,429,373,250,137,17,221,373,293,340,65,431,468,16,152,428,217,372,253,33,256,113,137,0]

theorem envBound60492 : H12AffineFastState.Bounded env60492 := by
  intro p hp
  have h : env60492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60491_60492 : H12AffineEnvironment.transform 9 220 env60491 = env60492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60491 == env60492) = true)

theorem identity60492 : scanCanonicalize (H12AffineFastState.compose env60492 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60492 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60493 : List Nat := [2,4,8,16,32,16,128,256,1,140,293,429,268,429,293,170,137,17,141,293,293,260,17,431,388,16,152,428,137,292,173,33,256,33,137,0]

theorem envBound60493 : H12AffineFastState.Bounded env60493 := by
  intro p hp
  have h : env60493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60492_60493 : H12AffineEnvironment.transform 5 16 env60492 = env60493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60492 == env60493) = true)

theorem identity60493 : scanCanonicalize (H12AffineFastState.compose env60493 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound60493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60494 : List Nat := [2,4,8,16,32,16,26,256,1,22,293,311,268,311,293,48,19,17,23,293,293,260,17,309,286,16,2,310,19,292,55,33,256,33,19,0]

theorem envBound60494 : H12AffineFastState.Bounded env60494 := by
  intro p hp
  have h : env60494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60493_60494 : H12AffineEnvironment.transform 6 26 env60493 = env60494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env60493 == env60494) = true)

theorem identity60494 : scanCanonicalize (H12AffineFastState.compose env60494 (packedSelected [1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 22) := by decide +kernel

theorem selectedBound60494 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60495 : List Nat := [2,4,8,16,32,16,26,22,1,22,51,33,26,33,51,48,19,17,23,51,51,18,17,35,8,16,2,32,19,50,55,33,22,33,19,0]

theorem envBound60495 : H12AffineFastState.Bounded env60495 := by
  intro p hp
  have h : env60495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60494_60495 : H12AffineEnvironment.transform 7 22 env60494 = env60495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 22 env60494 == env60495) = true)

theorem identity60495 : scanCanonicalize (H12AffineFastState.compose env60495 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60495 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60496 : List Nat := [2,4,2,16,32,16,16,22,1,22,51,33,16,33,51,48,19,17,23,51,51,18,17,35,2,16,2,32,19,50,55,33,22,33,19,0]

theorem envBound60496 : H12AffineFastState.Bounded env60496 := by
  intro p hp
  have h : env60496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60495_60496 : H12AffineEnvironment.transform 2 2 env60495 = env60496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60495 == env60496) = true)

def env60497 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,2097152,1416,64,3158,1288,17,2365812,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound60497 : H12AffineFastState.Bounded env60497 := by
  intro p hp
  have h : env60497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60486_60497 : H12AffineEnvironment.transform 12 1409 env60486 = env60497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60486 == env60497) = true)

theorem identity60497 : scanCanonicalize (H12AffineFastState.compose env60497 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 217) := by decide +kernel

theorem selectedBound60497 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60498 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,262144,1025,2128,217,1416,64,3158,1288,17,268717,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound60498 : H12AffineFastState.Bounded env60498 := by
  intro p hp
  have h : env60498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60497_60498 : H12AffineEnvironment.transform 20 217 env60497 = env60498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 217 env60497 == env60498) = true)

theorem identity60498 : scanCanonicalize (H12AffineFastState.compose env60498 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60498 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60499 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,6178,3441,6376,1025,2128,217,1416,64,3158,1288,17,325,4177,3361,7536,6181,4572,256,6313,3441,1]

theorem envBound60499 : H12AffineFastState.Bounded env60499 := by
  intro p hp
  have h : env60499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60498_60499 : H12AffineEnvironment.transform 17 6376 env60498 = env60499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60498 == env60499) = true)

theorem identity60499 : scanCanonicalize (H12AffineFastState.compose env60499 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60499 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60500 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1409,412,2128,2542,3441,2340,1025,2128,217,1416,64,3158,1288,17,325,413,3361,3260,2537,16,256,2405,3441,1]

theorem envBound60500 : H12AffineFastState.Bounded env60500 := by
  intro p hp
  have h : env60500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60499_60500 : H12AffineEnvironment.transform 11 460 env60499 = env60500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60499 == env60500) = true)

theorem identity60500 : scanCanonicalize (H12AffineFastState.compose env60500 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60500 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60501 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,460,1409,412,276,170,1077,96,1025,276,217,1416,64,1298,1288,17,325,413,1125,1528,173,16,256,33,1077,1]

theorem envBound60501 : H12AffineFastState.Bounded env60501 := by
  intro p hp
  have h : env60501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60500_60501 : H12AffineEnvironment.transform 10 324 env60500 = env60501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60500 == env60501) = true)

theorem identity60501 : scanCanonicalize (H12AffineFastState.compose env60501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound60501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60502 : List Nat := [2,4,8,16,32,64,128,256,1,408,324,460,25,412,276,170,429,96,409,276,217,16,64,138,144,17,325,413,509,96,173,16,256,33,429,1]

theorem envBound60502 : H12AffineFastState.Bounded env60502 := by
  intro p hp
  have h : env60502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60501_60502 : H12AffineEnvironment.transform 9 408 env60501 = env60502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env60501 == env60502) = true)

theorem identity60502 : scanCanonicalize (H12AffineFastState.compose env60502 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60502 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60503 : List Nat := [2,4,8,16,32,64,128,110,1,246,42,162,25,242,122,170,195,96,247,122,217,16,64,138,144,17,43,243,147,96,173,16,110,33,195,1]

theorem envBound60503 : H12AffineFastState.Bounded env60503 := by
  intro p hp
  have h : env60503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60502_60503 : H12AffineEnvironment.transform 7 110 env60502 = env60503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60502 == env60503) = true)

theorem identity60503 : scanCanonicalize (H12AffineFastState.compose env60503 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60503 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60504 : List Nat := [2,4,8,16,16,64,128,94,1,198,26,146,25,194,74,154,195,80,199,74,217,16,64,138,144,17,27,195,147,80,157,16,94,17,195,1]

theorem envBound60504 : H12AffineFastState.Bounded env60504 := by
  intro p hp
  have h : env60504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60503_60504 : H12AffineEnvironment.transform 4 16 env60503 = env60504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60503 == env60504) = true)

def env60505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399766,8397001,8388689,2366324,4177,77954,67410,8463814,8465982,256,65674,78034,8389184]

theorem envBound60505 : H12AffineFastState.Bounded env60505 := by
  intro p hp
  have h : env60505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60414_60505 : H12AffineEnvironment.transform 21 1417 env60414 = env60505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env60414 == env60505) = true)

def env60506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3670,1289,9617,2366324,4177,77954,67410,65542,68606,256,65674,78034,10112]

theorem envBound60506 : H12AffineFastState.Bounded env60506 := by
  intro p hp
  have h : env60506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60505_60506 : H12AffineEnvironment.transform 22 9664 env60505 = env60506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60505 == env60506) = true)

def env60507 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1289,9617,2365812,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound60507 : H12AffineFastState.Bounded env60507 := by
  intro p hp
  have h : env60507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60506_60507 : H12AffineEnvironment.transform 8 0 env60506 = env60507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60506 == env60507) = true)

theorem identity60507 : scanCanonicalize (H12AffineFastState.compose env60507 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 76078) := by decide +kernel

theorem selectedBound60507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60508 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,76078,1417,9664,3158,1289,9617,340058,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound60508 : H12AffineFastState.Bounded env60508 := by
  intro p hp
  have h : env60508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60507_60508 : H12AffineEnvironment.transform 20 76078 env60507 = env60508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 76078 env60507 == env60508) = true)

def env60509 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,68782,1417,64,3158,1289,17,333274,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound60509 : H12AffineFastState.Bounded env60509 := by
  intro p hp
  have h : env60509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60508_60509 : H12AffineEnvironment.transform 12 1408 env60508 = env60509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60508 == env60509) = true)

theorem identity60509 : scanCanonicalize (H12AffineFastState.compose env60509 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound60509 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60510 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1408,1029,2129,65536,65799,262144,1025,2129,68782,1417,64,3158,1289,17,328079,1028,65879,66898,65542,68094,256,65674,65799,0]

theorem envBound60510 : H12AffineFastState.Bounded env60510 := by
  intro p hp
  have h : env60510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60509_60510 : H12AffineEnvironment.transform 11 1109 env60509 = env60510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env60509 == env60510) = true)

theorem identity60510 : scanCanonicalize (H12AffineFastState.compose env60510 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound60510 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60511 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1109,1408,1029,2129,65536,65799,3261,1025,2129,68782,1417,64,3158,1289,17,68914,1028,65879,66898,65542,68094,256,65674,65799,0]

theorem envBound60511 : H12AffineFastState.Bounded env60511 := by
  intro p hp
  have h : env60511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60510_60511 : H12AffineEnvironment.transform 17 3261 env60510 = env60511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env60510 == env60511) = true)

theorem identity60511 : scanCanonicalize (H12AffineFastState.compose env60511 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60511 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60512 : List Nat := [2,4,8,16,32,64,128,256,0,1024,325,1109,1408,1029,276,65536,65799,1528,1025,276,67051,1417,64,1299,1289,17,66679,1028,65879,66898,65542,65723,256,65674,65799,0]

theorem envBound60512 : H12AffineFastState.Bounded env60512 := by
  intro p hp
  have h : env60512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60511_60512 : H12AffineEnvironment.transform 10 325 env60511 = env60512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60511 == env60512) = true)

theorem identity60512 : scanCanonicalize (H12AffineFastState.compose env60512 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60512 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60513 : List Nat := [2,4,8,16,16,64,128,256,0,1024,325,1109,1408,1029,276,65536,65799,1480,1025,276,67035,1417,64,1299,1289,17,66631,1028,65879,66898,65542,65675,256,65674,65799,0]

theorem envBound60513 : H12AffineFastState.Bounded env60513 := by
  intro p hp
  have h : env60513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60512_60513 : H12AffineEnvironment.transform 4 16 env60512 = env60513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60512 == env60513) = true)

theorem identity60513 : scanCanonicalize (H12AffineFastState.compose env60513 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound60513 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60514 : List Nat := [2,4,8,16,16,64,128,256,0,1024,325,1109,1408,1029,276,154,413,1480,1025,276,1345,1417,64,1299,1289,17,1245,1028,461,1480,156,17,256,16,413,0]

theorem envBound60514 : H12AffineFastState.Bounded env60514 := by
  intro p hp
  have h : env60514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60513_60514 : H12AffineEnvironment.transform 15 154 env60513 = env60514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env60513 == env60514) = true)

theorem identity60514 : scanCanonicalize (H12AffineFastState.compose env60514 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60514 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60515 : List Nat := [2,4,8,16,16,64,128,94,0,1024,27,1109,1246,1029,74,154,195,1174,1025,74,1055,1239,64,1101,1111,17,1245,1028,147,1174,156,17,94,16,195,0]

theorem envBound60515 : H12AffineFastState.Bounded env60515 := by
  intro p hp
  have h : env60515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60514_60515 : H12AffineEnvironment.transform 7 94 env60514 = env60515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60514 == env60515) = true)

theorem identity60515 : scanCanonicalize (H12AffineFastState.compose env60515 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound60515 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env60516 : List Nat := [2,4,8,16,16,64,128,94,0,198,27,147,24,195,74,154,195,80,199,74,217,17,64,139,145,17,27,194,147,80,156,17,94,16,195,0]

theorem envBound60516 : H12AffineFastState.Bounded env60516 := by
  intro p hp
  have h : env60516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60515_60516 : H12AffineEnvironment.transform 9 198 env60515 = env60516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env60515 == env60516) = true)

theorem identity60516 : scanCanonicalize (H12AffineFastState.compose env60516 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound60516 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60517 : List Nat := [2,4,8,16,16,64,89,94,0,31,27,74,24,26,74,67,26,80,30,74,0,17,64,82,72,17,27,27,74,80,69,17,94,16,26,0]

theorem envBound60517 : H12AffineFastState.Bounded env60517 := by
  intro p hp
  have h : env60517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60516_60517 : H12AffineEnvironment.transform 6 89 env60516 = env60517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env60516 == env60517) = true)

theorem identity60517 : scanCanonicalize (H12AffineFastState.compose env60517 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60518 : List Nat := [2,4,8,16,16,16,9,14,0,31,27,26,24,26,26,19,26,0,30,26,0,17,16,2,24,17,27,27,26,0,21,17,14,16,26,0]

theorem envBound60518 : H12AffineFastState.Bounded env60518 := by
  intro p hp
  have h : env60518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60517_60518 : H12AffineEnvironment.transform 5 16 env60517 = env60518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60517 == env60518) = true)

theorem identity60518 : scanCanonicalize (H12AffineFastState.compose env60518 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound60518 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60519 : List Nat := [2,4,8,11,11,11,9,14,0,4,0,1,3,1,1,8,1,0,5,1,0,10,11,2,3,10,0,0,1,0,14,10,14,11,1,0]

theorem envBound60519 : H12AffineFastState.Bounded env60519 := by
  intro p hp
  have h : env60519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60518_60519 : H12AffineEnvironment.transform 3 11 env60518 = env60519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env60518 == env60519) = true)

def env60520 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,68783,1417,65,3158,1289,16,333275,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound60520 : H12AffineFastState.Bounded env60520 := by
  intro p hp
  have h : env60520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60508_60520 : H12AffineEnvironment.transform 12 1409 env60508 = env60520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60508 == env60520) = true)

theorem identity60520 : scanCanonicalize (H12AffineFastState.compose env60520 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound60520 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60521 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5458,1,262144,1025,2129,6653,1417,65,3158,1289,16,262281,4177,81,4096,5460,7340,256,5592,1,1]

theorem envBound60521 : H12AffineFastState.Bounded env60521 := by
  intro p hp
  have h : env60521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60520_60521 : H12AffineEnvironment.transform 15 5458 env60520 = env60521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env60520 == env60521) = true)

theorem identity60521 : scanCanonicalize (H12AffineFastState.compose env60521 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60521 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60522 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,5458,1,262144,1025,1449,5125,1417,65,430,1289,16,262281,4177,81,4096,5460,4436,256,5592,1,1]

theorem envBound60522 : H12AffineFastState.Bounded env60522 := by
  intro p hp
  have h : env60522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60521_60522 : H12AffineEnvironment.transform 10 1528 env60521 = env60522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60521 == env60522) = true)

theorem identity60522 : scanCanonicalize (H12AffineFastState.compose env60522 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 153) := by decide +kernel

theorem selectedBound60522 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60523 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,5458,1,153,1025,1449,5125,1417,65,430,1289,16,16,4177,81,4096,5460,4436,256,5592,1,1]

theorem envBound60523 : H12AffineFastState.Bounded env60523 := by
  intro p hp
  have h : env60523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60522_60523 : H12AffineEnvironment.transform 17 153 env60522 = env60523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 153 env60522 == env60523) = true)

theorem identity60523 : scanCanonicalize (H12AffineFastState.compose env60523 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound60523 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60524 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,372,1409,292,1449,1062,1,153,1025,1449,1393,1417,65,430,1289,16,16,293,81,372,1056,32,256,1196,1,1]

theorem envBound60524 : H12AffineFastState.Bounded env60524 := by
  intro p hp
  have h : env60524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60523_60524 : H12AffineEnvironment.transform 11 372 env60523 = env60524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env60523 == env60524) = true)

theorem identity60524 : scanCanonicalize (H12AffineFastState.compose env60524 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60524 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60525 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,372,349,292,373,250,1,153,221,373,429,341,65,430,469,16,16,293,81,372,252,32,256,112,1,1]

theorem envBound60525 : H12AffineFastState.Bounded env60525 := by
  intro p hp
  have h : env60525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60524_60525 : H12AffineEnvironment.transform 9 220 env60524 = env60525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60524 == env60525) = true)

theorem identity60525 : scanCanonicalize (H12AffineFastState.compose env60525 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60525 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60526 : List Nat := [2,4,8,16,32,16,128,256,0,140,292,292,269,292,293,170,1,153,141,293,429,261,17,430,389,16,16,293,1,292,172,32,256,32,1,1]

theorem envBound60526 : H12AffineFastState.Bounded env60526 := by
  intro p hp
  have h : env60526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60525_60526 : H12AffineEnvironment.transform 5 16 env60525 = env60526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60525 == env60526) = true)

theorem identity60526 : scanCanonicalize (H12AffineFastState.compose env60526 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60526 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60527 : List Nat := [1,4,8,16,32,16,128,256,0,140,292,292,269,292,293,169,1,153,141,293,429,261,17,429,389,16,16,293,1,292,172,32,256,32,1,1]

theorem envBound60527 : H12AffineFastState.Bounded env60527 := by
  intro p hp
  have h : env60527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60526_60527 : H12AffineEnvironment.transform 0 1 env60526 = env60527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60526 == env60527) = true)

theorem identity60527 : scanCanonicalize (H12AffineFastState.compose env60527 (packedSelected [1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60527 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60528 : List Nat := [1,4,8,16,32,16,40,256,0,36,292,292,269,292,293,1,1,49,37,293,261,261,17,261,301,16,16,293,1,292,4,32,256,32,1,1]

theorem envBound60528 : H12AffineFastState.Bounded env60528 := by
  intro p hp
  have h : env60528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60527_60528 : H12AffineEnvironment.transform 6 40 env60527 = env60528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60527 == env60528) = true)

theorem identity60528 : scanCanonicalize (H12AffineFastState.compose env60528 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound60528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60529 : List Nat := [1,4,8,16,9,16,1,256,0,13,269,269,269,269,268,1,1,24,12,268,261,261,17,261,260,16,16,268,1,269,4,9,256,9,1,1]

theorem envBound60529 : H12AffineFastState.Bounded env60529 := by
  intro p hp
  have h : env60529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60528_60529 : H12AffineEnvironment.transform 4 9 env60528 = env60529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env60528 == env60529) = true)

theorem identity60529 : scanCanonicalize (H12AffineFastState.compose env60529 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60529 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60530 : List Nat := [1,4,8,16,9,16,1,20,0,13,25,25,25,25,24,1,1,24,12,24,17,17,17,17,16,16,16,24,1,25,4,9,20,9,1,1]

theorem envBound60530 : H12AffineFastState.Bounded env60530 := by
  intro p hp
  have h : env60530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60529_60530 : H12AffineEnvironment.transform 7 20 env60529 = env60530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60529 == env60530) = true)

theorem identity60530 : scanCanonicalize (H12AffineFastState.compose env60530 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60530 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60531 : List Nat := [1,4,8,1,9,1,1,5,0,13,8,8,8,8,9,1,1,9,12,9,0,0,0,0,1,1,1,9,1,8,4,9,5,9,1,1]

theorem envBound60531 : H12AffineFastState.Bounded env60531 := by
  intro p hp
  have h : env60531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60530_60531 : H12AffineEnvironment.transform 3 1 env60530 = env60531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60530 == env60531) = true)

theorem identity60531 : scanCanonicalize (H12AffineFastState.compose env60531 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60531 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60532 : List Nat := [1,4,0,1,1,1,1,5,0,5,0,0,0,0,1,1,1,1,4,1,0,0,0,0,1,1,1,1,1,0,4,1,5,1,1,1]

theorem envBound60532 : H12AffineFastState.Bounded env60532 := by
  intro p hp
  have h : env60532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60531_60532 : H12AffineEnvironment.transform 2 0 env60531 = env60532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60531 == env60532) = true)

def env60533 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1289,9617,2365813,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound60533 : H12AffineFastState.Bounded env60533 := by
  intro p hp
  have h : env60533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60506_60533 : H12AffineEnvironment.transform 8 1 env60506 = env60533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60506 == env60533) = true)

theorem identity60533 : scanCanonicalize (H12AffineFastState.compose env60533 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound60533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60534 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,68782,1417,9664,3159,1289,9617,333275,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound60534 : H12AffineFastState.Bounded env60534 := by
  intro p hp
  have h : env60534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60533_60534 : H12AffineEnvironment.transform 20 68782 env60533 = env60534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env60533 == env60534) = true)

def env60535 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,68782,1417,64,3159,1289,17,333275,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound60535 : H12AffineFastState.Bounded env60535 := by
  intro p hp
  have h : env60535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60534_60535 : H12AffineEnvironment.transform 12 1408 env60534 = env60535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60534 == env60535) = true)

theorem identity60535 : scanCanonicalize (H12AffineFastState.compose env60535 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound60535 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60536 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,68782,1417,64,3159,1289,17,328079,1029,65878,66899,65542,68095,256,65674,65798,1]

theorem envBound60536 : H12AffineFastState.Bounded env60536 := by
  intro p hp
  have h : env60536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60535_60536 : H12AffineEnvironment.transform 11 1108 env60535 = env60536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env60535 == env60536) = true)

theorem identity60536 : scanCanonicalize (H12AffineFastState.compose env60536 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound60536 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60537 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2128,65536,65798,3261,1025,2128,68782,1417,64,3159,1289,17,68914,1029,65878,66899,65542,68095,256,65674,65798,1]

theorem envBound60537 : H12AffineFastState.Bounded env60537 := by
  intro p hp
  have h : env60537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60536_60537 : H12AffineEnvironment.transform 17 3261 env60536 = env60537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env60536 == env60537) = true)

theorem identity60537 : scanCanonicalize (H12AffineFastState.compose env60537 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60537 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60538 : List Nat := [2,4,8,16,32,64,128,256,1,1024,324,1108,1408,1028,276,65536,65798,1529,1025,276,67050,1417,64,1299,1289,17,66678,1029,65878,66899,65542,65723,256,65674,65798,1]

theorem envBound60538 : H12AffineFastState.Bounded env60538 := by
  intro p hp
  have h : env60538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60537_60538 : H12AffineEnvironment.transform 10 324 env60537 = env60538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60537 == env60538) = true)

theorem identity60538 : scanCanonicalize (H12AffineFastState.compose env60538 (packedSelected [0,1,4,5,7,9,11,17] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound60538 : packedSelected [0,1,4,5,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env60539 : List Nat := [2,4,8,16,32,64,128,256,1,425,324,509,41,429,276,65536,65798,80,424,276,65603,32,64,186,160,17,66015,428,65878,65786,65542,65723,256,65674,65798,1]

theorem envBound60539 : H12AffineFastState.Bounded env60539 := by
  intro p hp
  have h : env60539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60538_60539 : H12AffineEnvironment.transform 9 425 env60538 = env60539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env60538 == env60539) = true)

theorem identity60539 : scanCanonicalize (H12AffineFastState.compose env60539 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound60539 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60540 : List Nat := [2,4,8,16,32,64,128,256,1,425,324,509,41,429,276,170,428,80,424,276,233,32,64,186,160,17,373,428,508,80,172,17,256,32,428,1]

theorem envBound60540 : H12AffineFastState.Bounded env60540 := by
  intro p hp
  have h : env60540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60539_60540 : H12AffineEnvironment.transform 15 170 env60539 = env60540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env60539 == env60540) = true)

theorem identity60540 : scanCanonicalize (H12AffineFastState.compose env60540 (packedSelected [1,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60540 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env60541 : List Nat := [2,4,8,16,17,64,128,256,1,408,324,460,24,412,276,155,413,80,409,276,216,17,64,139,145,17,324,413,461,80,157,17,256,17,413,1]

theorem envBound60541 : H12AffineFastState.Bounded env60541 := by
  intro p hp
  have h : env60541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60540_60541 : H12AffineEnvironment.transform 4 17 env60540 = env60541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60540 == env60541) = true)

theorem identity60541 : scanCanonicalize (H12AffineFastState.compose env60541 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60541 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60542 : List Nat := [2,4,8,16,17,64,128,20,1,140,80,216,24,136,0,155,137,80,141,0,216,17,64,139,145,17,80,137,217,80,157,17,20,17,137,1]

theorem envBound60542 : H12AffineFastState.Bounded env60542 := by
  intro p hp
  have h : env60542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60541_60542 : H12AffineEnvironment.transform 7 20 env60541 = env60542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60541 == env60542) = true)

theorem identity60542 : scanCanonicalize (H12AffineFastState.compose env60542 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60543 : List Nat := [2,4,8,16,17,64,19,20,1,31,80,75,24,27,0,8,26,80,30,0,75,17,64,24,2,17,80,26,74,80,14,17,20,17,26,1]

theorem envBound60543 : H12AffineFastState.Bounded env60543 := by
  intro p hp
  have h : env60543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60542_60543 : H12AffineEnvironment.transform 6 19 env60542 = env60543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60542 == env60543) = true)

theorem identity60543 : scanCanonicalize (H12AffineFastState.compose env60543 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound60543 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60544 : List Nat := [2,4,8,16,17,11,19,20,1,31,27,0,24,27,0,8,26,27,30,0,0,17,11,24,2,17,27,26,1,27,14,17,20,17,26,1]

theorem envBound60544 : H12AffineFastState.Bounded env60544 := by
  intro p hp
  have h : env60544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60543_60544 : H12AffineEnvironment.transform 5 11 env60543 = env60544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env60543 == env60544) = true)

theorem identity60544 : scanCanonicalize (H12AffineFastState.compose env60544 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60544 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60545 : List Nat := [2,4,8,10,11,11,9,14,1,5,1,0,2,1,0,8,0,1,4,0,0,11,11,2,2,11,1,0,1,1,14,11,14,11,0,1]

theorem envBound60545 : H12AffineFastState.Bounded env60545 := by
  intro p hp
  have h : env60545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60544_60545 : H12AffineEnvironment.transform 3 10 env60544 = env60545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60544 == env60545) = true)

def env60546 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,68782,1417,65,3159,1289,16,333275,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound60546 : H12AffineFastState.Bounded env60546 := by
  intro p hp
  have h : env60546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60534_60546 : H12AffineEnvironment.transform 12 1409 env60534 = env60546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60534 == env60546) = true)

theorem identity60546 : scanCanonicalize (H12AffineFastState.compose env60546 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5458) := by decide +kernel

theorem selectedBound60546 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60547 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5458,1,262144,1025,2128,6652,1417,65,3159,1289,16,262281,4177,81,4097,5460,7341,256,5592,1,0]

theorem envBound60547 : H12AffineFastState.Bounded env60547 := by
  intro p hp
  have h : env60547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60546_60547 : H12AffineEnvironment.transform 15 5458 env60546 = env60547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5458 env60546 == env60547) = true)

theorem identity60547 : scanCanonicalize (H12AffineFastState.compose env60547 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60547 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60548 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,5458,1,262144,1025,1449,5125,1417,65,430,1289,16,262281,4177,81,4097,5460,4436,256,5592,1,0]

theorem envBound60548 : H12AffineFastState.Bounded env60548 := by
  intro p hp
  have h : env60548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60547_60548 : H12AffineEnvironment.transform 10 1529 env60547 = env60548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60547 == env60548) = true)

theorem identity60548 : scanCanonicalize (H12AffineFastState.compose env60548 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 153) := by decide +kernel

theorem selectedBound60548 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60549 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,5458,1,153,1025,1449,5125,1417,65,430,1289,16,16,4177,81,4097,5460,4436,256,5592,1,0]

theorem envBound60549 : H12AffineFastState.Bounded env60549 := by
  intro p hp
  have h : env60549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60548_60549 : H12AffineEnvironment.transform 17 153 env60548 = env60549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 153 env60548 == env60549) = true)

theorem identity60549 : scanCanonicalize (H12AffineFastState.compose env60549 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 372) := by decide +kernel

theorem selectedBound60549 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60550 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,372,1409,292,1449,1062,1,153,1025,1449,1393,1417,65,430,1289,16,16,293,81,373,1056,32,256,1196,1,0]

theorem envBound60550 : H12AffineFastState.Bounded env60550 := by
  intro p hp
  have h : env60550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60549_60550 : H12AffineEnvironment.transform 11 372 env60549 = env60550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 372 env60549 == env60550) = true)

theorem identity60550 : scanCanonicalize (H12AffineFastState.compose env60550 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60550 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60551 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,372,348,292,372,251,1,153,220,372,428,340,65,430,468,16,16,293,81,373,253,32,256,113,1,0]

theorem envBound60551 : H12AffineFastState.Bounded env60551 := by
  intro p hp
  have h : env60551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60550_60551 : H12AffineEnvironment.transform 9 221 env60550 = env60551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60550 == env60551) = true)

theorem identity60551 : scanCanonicalize (H12AffineFastState.compose env60551 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60551 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60552 : List Nat := [2,4,8,16,32,64,128,172,1,221,136,216,240,136,216,251,1,153,220,216,0,248,65,2,120,16,16,137,81,217,253,32,172,113,1,0]

theorem envBound60552 : H12AffineFastState.Bounded env60552 := by
  intro p hp
  have h : env60552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60551_60552 : H12AffineEnvironment.transform 7 172 env60551 = env60552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60551 == env60552) = true)

theorem identity60552 : scanCanonicalize (H12AffineFastState.compose env60552 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound60552 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60553 : List Nat := [2,4,8,16,32,33,128,172,1,188,136,185,145,136,185,154,1,153,189,185,0,153,32,2,25,16,16,137,48,184,156,32,172,16,1,0]

theorem envBound60553 : H12AffineFastState.Bounded env60553 := by
  intro p hp
  have h : env60553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60552_60553 : H12AffineEnvironment.transform 5 33 env60552 = env60553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env60552 == env60553) = true)

theorem identity60553 : scanCanonicalize (H12AffineFastState.compose env60553 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60554 : List Nat := [2,4,8,3,32,33,128,172,1,175,136,170,130,136,170,137,1,138,174,170,0,138,32,2,10,3,3,137,35,171,143,32,172,3,1,0]

theorem envBound60554 : H12AffineFastState.Bounded env60554 := by
  intro p hp
  have h : env60554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60553_60554 : H12AffineEnvironment.transform 3 3 env60553 = env60554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60553 == env60554) = true)

theorem identity60554 : scanCanonicalize (H12AffineFastState.compose env60554 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound60554 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env60555 : List Nat := [2,4,8,3,32,33,0,44,1,47,8,42,2,8,42,9,1,10,46,42,0,10,32,2,10,3,3,9,35,43,15,32,44,3,1,0]

theorem envBound60555 : H12AffineFastState.Bounded env60555 := by
  intro p hp
  have h : env60555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60554_60555 : H12AffineEnvironment.transform 6 0 env60554 = env60555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env60554 == env60555) = true)

theorem identity60555 : scanCanonicalize (H12AffineFastState.compose env60555 (packedSelected [3,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60555 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env60556 : List Nat := [2,4,0,3,32,33,0,36,1,39,0,34,2,0,34,1,1,2,38,34,0,2,32,2,2,3,3,1,35,35,7,32,36,3,1,0]

theorem envBound60556 : H12AffineFastState.Bounded env60556 := by
  intro p hp
  have h : env60556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60555_60556 : H12AffineEnvironment.transform 2 0 env60555 = env60556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60555 == env60556) = true)

theorem identity60556 : scanCanonicalize (H12AffineFastState.compose env60556 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60557 : List Nat := [2,4,0,3,0,1,0,4,1,7,0,2,2,0,2,1,1,2,6,2,0,2,0,2,2,3,3,1,3,3,7,0,4,3,1,0]

theorem envBound60557 : H12AffineFastState.Bounded env60557 := by
  intro p hp
  have h : env60557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60556_60557 : H12AffineEnvironment.transform 4 0 env60556 = env60557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60556 == env60557) = true)

theorem identity60557 : scanCanonicalize (H12AffineFastState.compose env60557 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60557 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60558 : List Nat := [1,4,0,0,0,1,0,4,1,4,0,1,1,0,1,1,1,1,5,1,0,1,0,1,1,0,0,1,0,0,4,0,4,0,1,0]

theorem envBound60558 : H12AffineFastState.Bounded env60558 := by
  intro p hp
  have h : env60558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60557_60558 : H12AffineEnvironment.transform 0 1 env60557 = env60558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60557 == env60558) = true)

def env60559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3671,1288,9616,2366324,4177,77954,67410,65543,68607,256,65674,78034,10113]

theorem envBound60559 : H12AffineFastState.Bounded env60559 := by
  intro p hp
  have h : env60559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60505_60559 : H12AffineEnvironment.transform 22 9665 env60505 = env60559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60505 == env60559) = true)

def env60560 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound60560 : H12AffineFastState.Bounded env60560 := by
  intro p hp
  have h : env60560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60559_60560 : H12AffineEnvironment.transform 8 0 env60559 = env60560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60559 == env60560) = true)

theorem identity60560 : scanCanonicalize (H12AffineFastState.compose env60560 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound60560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60561 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,5374,9260,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365812,4177,9340,4524,5369,7425,256,5236,9260,9601]

theorem envBound60561 : H12AffineFastState.Bounded env60561 := by
  intro p hp
  have h : env60561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60560_60561 : H12AffineEnvironment.transform 15 5374 env60560 = env60561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env60560 == env60561) = true)

def env60562 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,2097152,1417,65,3159,1288,16,2365812,4177,508,4524,5369,7425,256,5236,428,1]

theorem envBound60562 : H12AffineFastState.Bounded env60562 := by
  intro p hp
  have h : env60562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60561_60562 : H12AffineEnvironment.transform 12 1408 env60561 = env60562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60561 == env60562) = true)

theorem identity60562 : scanCanonicalize (H12AffineFastState.compose env60562 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60562 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60563 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,6653,1417,65,3159,1288,16,262281,4177,508,4524,5369,7425,256,5236,428,1]

theorem envBound60563 : H12AffineFastState.Bounded env60563 := by
  intro p hp
  have h : env60563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60562_60563 : H12AffineEnvironment.transform 20 6653 env60562 = env60563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60562 == env60563) = true)

theorem identity60563 : scanCanonicalize (H12AffineFastState.compose env60563 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60563 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60564 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,5374,428,262144,1025,1449,5125,1417,65,431,1288,16,262281,4177,508,4524,5369,4345,256,5236,428,1]

theorem envBound60564 : H12AffineFastState.Bounded env60564 := by
  intro p hp
  have h : env60564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60563_60564 : H12AffineEnvironment.transform 10 1528 env60563 = env60564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60563 == env60564) = true)

theorem identity60564 : scanCanonicalize (H12AffineFastState.compose env60564 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 309) := by decide +kernel

theorem selectedBound60564 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60565 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,5374,428,309,1025,1449,5125,1417,65,431,1288,16,444,4177,508,4524,5369,4345,256,5236,428,1]

theorem envBound60565 : H12AffineFastState.Bounded env60565 := by
  intro p hp
  have h : env60565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60564_60565 : H12AffineEnvironment.transform 17 309 env60564 = env60565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 309 env60564 == env60565) = true)

theorem identity60565 : scanCanonicalize (H12AffineFastState.compose env60565 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound60565 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60566 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,216,1408,136,1449,1062,428,309,1025,1449,1245,1417,65,431,1288,16,444,137,508,372,1057,33,256,1196,428,1]

theorem envBound60566 : H12AffineFastState.Bounded env60566 := by
  intro p hp
  have h : env60566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60565_60566 : H12AffineEnvironment.transform 11 216 env60565 = env60566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env60565 == env60566) = true)

theorem identity60566 : scanCanonicalize (H12AffineFastState.compose env60566 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 220) := by decide +kernel

theorem selectedBound60566 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60567 : List Nat := [2,4,8,16,32,64,128,256,0,220,292,216,348,136,373,250,428,309,221,373,1,341,65,431,468,16,444,137,508,372,253,33,256,112,428,1]

theorem envBound60567 : H12AffineFastState.Bounded env60567 := by
  intro p hp
  have h : env60567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60566_60567 : H12AffineEnvironment.transform 9 220 env60566 = env60567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 220 env60566 == env60567) = true)

theorem identity60567 : scanCanonicalize (H12AffineFastState.compose env60567 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60567 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60568 : List Nat := [2,4,8,16,32,64,128,172,0,220,136,216,240,136,217,250,0,153,221,217,1,249,65,3,120,16,16,137,80,216,253,33,172,112,0,1]

theorem envBound60568 : H12AffineFastState.Bounded env60568 := by
  intro p hp
  have h : env60568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60567_60568 : H12AffineEnvironment.transform 7 172 env60567 = env60568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60567 == env60568) = true)

theorem identity60568 : scanCanonicalize (H12AffineFastState.compose env60568 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound60568 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env60569 : List Nat := [2,4,8,16,32,49,128,172,0,173,136,169,129,136,168,139,0,153,172,168,1,136,48,3,9,16,16,137,33,169,140,33,172,1,0,1]

theorem envBound60569 : H12AffineFastState.Bounded env60569 := by
  intro p hp
  have h : env60569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60568_60569 : H12AffineEnvironment.transform 5 49 env60568 = env60569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env60568 == env60569) = true)

theorem identity60569 : scanCanonicalize (H12AffineFastState.compose env60569 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound60569 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60570 : List Nat := [2,4,8,16,26,11,128,150,0,151,136,147,129,136,146,139,0,153,150,146,1,136,10,3,9,16,16,137,27,147,140,27,150,1,0,1]

theorem envBound60570 : H12AffineFastState.Bounded env60570 := by
  intro p hp
  have h : env60570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60569_60570 : H12AffineEnvironment.transform 4 26 env60569 = env60570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env60569 == env60570) = true)

theorem identity60570 : scanCanonicalize (H12AffineFastState.compose env60570 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound60570 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60571 : List Nat := [2,4,8,16,26,11,26,12,0,13,18,9,27,18,8,17,0,3,12,8,1,18,10,3,9,16,16,19,27,9,22,27,12,1,0,1]

theorem envBound60571 : H12AffineFastState.Bounded env60571 := by
  intro p hp
  have h : env60571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60570_60571 : H12AffineEnvironment.transform 6 26 env60570 = env60571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env60570 == env60571) = true)

theorem identity60571 : scanCanonicalize (H12AffineFastState.compose env60571 (packedSelected [3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60571 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env60572 : List Nat := [2,4,8,1,11,11,11,12,0,13,3,9,10,3,8,0,0,3,12,8,1,3,10,3,9,1,1,2,10,9,7,10,12,1,0,1]

theorem envBound60572 : H12AffineFastState.Bounded env60572 := by
  intro p hp
  have h : env60572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60571_60572 : H12AffineEnvironment.transform 3 1 env60571 = env60572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60571 == env60572) = true)

theorem identity60572 : scanCanonicalize (H12AffineFastState.compose env60572 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60572 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60573 : List Nat := [2,4,1,1,2,2,2,5,0,4,3,0,3,3,1,0,0,3,5,1,1,3,3,3,0,1,1,2,3,0,7,3,5,1,0,1]

theorem envBound60573 : H12AffineFastState.Bounded env60573 := by
  intro p hp
  have h : env60573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60572_60573 : H12AffineEnvironment.transform 2 1 env60572 = env60573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60572 == env60573) = true)

theorem identity60573 : scanCanonicalize (H12AffineFastState.compose env60573 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60573 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60574 : List Nat := [0,4,1,1,0,0,0,5,0,4,1,0,1,1,1,0,0,1,5,1,1,1,1,1,0,1,1,0,1,0,5,1,5,1,0,1]

theorem envBound60574 : H12AffineFastState.Bounded env60574 := by
  intro p hp
  have h : env60574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60573_60574 : H12AffineEnvironment.transform 0 0 env60573 = env60574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60573 == env60574) = true)

def env60575 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5374,429,262144,1025,2129,2097152,1417,64,3159,1288,17,2365812,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound60575 : H12AffineFastState.Bounded env60575 := by
  intro p hp
  have h : env60575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60561_60575 : H12AffineEnvironment.transform 12 1409 env60561 = env60575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60561 == env60575) = true)

theorem identity60575 : scanCanonicalize (H12AffineFastState.compose env60575 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60575 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60576 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5374,429,262144,1025,2129,3076,1417,64,3159,1288,17,267632,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound60576 : H12AffineFastState.Bounded env60576 := by
  intro p hp
  have h : env60576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60575_60576 : H12AffineEnvironment.transform 20 3076 env60575 = env60576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60575 == env60576) = true)

theorem identity60576 : scanCanonicalize (H12AffineFastState.compose env60576 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound60576 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60577 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,5374,429,6376,1025,2129,3076,1417,64,3159,1288,17,3480,4177,509,4524,5369,7425,256,5236,429,0]

theorem envBound60577 : H12AffineFastState.Bounded env60577 := by
  intro p hp
  have h : env60577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60576_60577 : H12AffineEnvironment.transform 17 6376 env60576 = env60577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env60576 == env60577) = true)

theorem identity60577 : scanCanonicalize (H12AffineFastState.compose env60577 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound60577 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60578 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1409,412,2129,1330,429,2340,1025,2129,3076,1417,64,3159,1288,17,3480,413,509,96,1333,3277,256,1464,429,0]

theorem envBound60578 : H12AffineFastState.Bounded env60578 := by
  intro p hp
  have h : env60578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60577_60578 : H12AffineEnvironment.transform 11 460 env60577 = env60578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env60577 == env60578) = true)

theorem identity60578 : scanCanonicalize (H12AffineFastState.compose env60578 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound60578 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60579 : List Nat := [2,4,8,16,32,64,128,256,0,1024,324,460,1409,412,277,1330,429,96,1025,277,1344,1417,64,1299,1288,17,1244,413,509,96,1333,1417,256,1464,429,0]

theorem envBound60579 : H12AffineFastState.Bounded env60579 := by
  intro p hp
  have h : env60579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60578_60579 : H12AffineEnvironment.transform 10 324 env60578 = env60579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env60578 == env60579) = true)

theorem identity60579 : scanCanonicalize (H12AffineFastState.compose env60579 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60579 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60580 : List Nat := [2,4,8,16,32,64,128,256,0,409,324,460,24,412,277,171,429,96,408,277,217,16,64,138,145,17,325,413,509,96,172,16,256,33,429,0]

theorem envBound60580 : H12AffineFastState.Bounded env60580 := by
  intro p hp
  have h : env60580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60579_60580 : H12AffineEnvironment.transform 9 409 env60579 = env60580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60579 == env60580) = true)

theorem identity60580 : scanCanonicalize (H12AffineFastState.compose env60580 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound60580 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60581 : List Nat := [2,4,8,16,32,64,128,94,0,199,26,146,24,194,75,171,243,96,198,75,217,16,64,138,145,17,27,195,163,96,172,16,94,33,243,0]

theorem envBound60581 : H12AffineFastState.Bounded env60581 := by
  intro p hp
  have h : env60581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60580_60581 : H12AffineEnvironment.transform 7 94 env60580 = env60581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env60580 == env60581) = true)

theorem identity60581 : scanCanonicalize (H12AffineFastState.compose env60581 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60581 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60582 : List Nat := [2,4,8,16,16,64,128,94,0,199,26,146,24,194,75,155,195,80,198,75,217,16,64,138,145,17,27,195,147,80,156,16,94,17,195,0]

theorem envBound60582 : H12AffineFastState.Bounded env60582 := by
  intro p hp
  have h : env60582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60581_60582 : H12AffineEnvironment.transform 4 16 env60581 = env60582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60581 == env60582) = true)

def env60583 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound60583 : H12AffineFastState.Bounded env60583 := by
  intro p hp
  have h : env60583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60559_60583 : H12AffineEnvironment.transform 8 1 env60559 = env60583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60559 == env60583) = true)

theorem identity60583 : scanCanonicalize (H12AffineFastState.compose env60583 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound60583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60584 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,12670,428,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365813,4177,508,13357,12665,14464,256,12788,428,9600]

theorem envBound60584 : H12AffineFastState.Bounded env60584 := by
  intro p hp
  have h : env60584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60583_60584 : H12AffineEnvironment.transform 15 12670 env60583 = env60584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env60583 == env60584) = true)

def env60585 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,2097152,1417,65,3158,1288,16,2365813,4177,508,4525,5369,7424,256,5236,428,0]

theorem envBound60585 : H12AffineFastState.Bounded env60585 := by
  intro p hp
  have h : env60585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60584_60585 : H12AffineEnvironment.transform 12 1408 env60584 = env60585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60584 == env60585) = true)

theorem identity60585 : scanCanonicalize (H12AffineFastState.compose env60585 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60585 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60586 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,6652,1417,65,3158,1288,16,262281,4177,508,4525,5369,7424,256,5236,428,0]

theorem envBound60586 : H12AffineFastState.Bounded env60586 := by
  intro p hp
  have h : env60586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60585_60586 : H12AffineEnvironment.transform 20 6652 env60585 = env60586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60585 == env60586) = true)

theorem identity60586 : scanCanonicalize (H12AffineFastState.compose env60586 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60586 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60587 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,5374,428,262144,1025,1449,5125,1417,65,431,1288,16,262281,4177,508,4525,5369,4345,256,5236,428,0]

theorem envBound60587 : H12AffineFastState.Bounded env60587 := by
  intro p hp
  have h : env60587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60586_60587 : H12AffineEnvironment.transform 10 1529 env60586 = env60587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60586 == env60587) = true)

theorem identity60587 : scanCanonicalize (H12AffineFastState.compose env60587 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 309) := by decide +kernel

theorem selectedBound60587 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60588 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,5374,428,309,1025,1449,5125,1417,65,431,1288,16,444,4177,508,4525,5369,4345,256,5236,428,0]

theorem envBound60588 : H12AffineFastState.Bounded env60588 := by
  intro p hp
  have h : env60588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60587_60588 : H12AffineEnvironment.transform 17 309 env60587 = env60588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 309 env60587 == env60588) = true)

theorem identity60588 : scanCanonicalize (H12AffineFastState.compose env60588 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound60588 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60589 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,216,1408,136,1449,1062,428,309,1025,1449,1245,1417,65,431,1288,16,444,137,508,373,1057,33,256,1196,428,0]

theorem envBound60589 : H12AffineFastState.Bounded env60589 := by
  intro p hp
  have h : env60589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60588_60589 : H12AffineEnvironment.transform 11 216 env60588 = env60589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env60588 == env60589) = true)

theorem identity60589 : scanCanonicalize (H12AffineFastState.compose env60589 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound60589 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60590 : List Nat := [2,4,8,16,32,64,128,256,1,221,292,216,349,136,372,251,428,309,220,372,0,340,65,431,469,16,444,137,508,373,252,33,256,113,428,0]

theorem envBound60590 : H12AffineFastState.Bounded env60590 := by
  intro p hp
  have h : env60590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60589_60590 : H12AffineEnvironment.transform 9 221 env60589 = env60590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env60589 == env60590) = true)

theorem identity60590 : scanCanonicalize (H12AffineFastState.compose env60590 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60590 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60591 : List Nat := [2,4,8,16,32,16,128,256,1,141,292,136,269,136,292,171,428,309,140,292,0,260,17,431,389,16,444,137,428,293,172,33,256,33,428,0]

theorem envBound60591 : H12AffineFastState.Bounded env60591 := by
  intro p hp
  have h : env60591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60590_60591 : H12AffineEnvironment.transform 5 16 env60590 = env60591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60590 == env60591) = true)

theorem identity60591 : scanCanonicalize (H12AffineFastState.compose env60591 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound60591 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60592 : List Nat := [2,4,8,16,32,16,27,256,1,22,292,19,269,19,292,48,311,309,23,292,0,260,17,308,286,16,295,18,311,293,55,33,256,33,311,0]

theorem envBound60592 : H12AffineFastState.Bounded env60592 := by
  intro p hp
  have h : env60592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60591_60592 : H12AffineEnvironment.transform 6 27 env60591 = env60592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env60591 == env60592) = true)

theorem identity60592 : scanCanonicalize (H12AffineFastState.compose env60592 (packedSelected [3,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60592 : packedSelected [3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60593 : List Nat := [2,4,8,16,2,16,27,256,1,22,262,19,269,19,262,18,277,279,23,262,0,260,17,278,286,16,261,18,277,263,21,3,256,3,277,0]

theorem envBound60593 : H12AffineFastState.Bounded env60593 := by
  intro p hp
  have h : env60593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60592_60593 : H12AffineEnvironment.transform 4 2 env60592 = env60593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60592 == env60593) = true)

theorem identity60593 : scanCanonicalize (H12AffineFastState.compose env60593 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60593 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60594 : List Nat := [2,4,8,0,2,0,11,256,1,6,262,3,269,3,262,2,261,263,7,262,0,260,1,262,270,0,261,2,261,263,5,3,256,3,261,0]

theorem envBound60594 : H12AffineFastState.Bounded env60594 := by
  intro p hp
  have h : env60594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60593_60594 : H12AffineEnvironment.transform 3 0 env60593 = env60594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60593 == env60594) = true)

theorem identity60594 : scanCanonicalize (H12AffineFastState.compose env60594 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60594 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60595 : List Nat := [2,4,1,0,2,0,2,256,1,6,262,3,260,3,262,2,261,263,7,262,0,260,1,262,263,0,261,2,261,263,5,3,256,3,261,0]

theorem envBound60595 : H12AffineFastState.Bounded env60595 := by
  intro p hp
  have h : env60595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60594_60595 : H12AffineEnvironment.transform 2 1 env60594 = env60595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60594 == env60595) = true)

theorem identity60595 : scanCanonicalize (H12AffineFastState.compose env60595 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60595 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60596 : List Nat := [1,4,1,0,1,0,1,256,1,5,261,0,260,0,261,1,261,260,4,261,0,260,1,261,260,0,261,1,261,260,5,0,256,0,261,0]

theorem envBound60596 : H12AffineFastState.Bounded env60596 := by
  intro p hp
  have h : env60596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60595_60596 : H12AffineEnvironment.transform 0 1 env60595 = env60596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60595 == env60596) = true)

theorem identity60596 : scanCanonicalize (H12AffineFastState.compose env60596 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound60596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60597 : List Nat := [1,4,1,0,1,0,1,4,1,5,1,0,0,0,1,1,1,0,4,1,0,0,1,1,0,0,1,1,1,0,5,0,4,0,1,0]

theorem envBound60597 : H12AffineFastState.Bounded env60597 := by
  intro p hp
  have h : env60597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60596_60597 : H12AffineEnvironment.transform 7 4 env60596 = env60597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env60596 == env60597) = true)

def env60598 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5375,428,262144,1025,2128,2097152,1417,64,3158,1288,17,2365813,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound60598 : H12AffineFastState.Bounded env60598 := by
  intro p hp
  have h : env60598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60584_60598 : H12AffineEnvironment.transform 12 1409 env60584 = env60598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60584 == env60598) = true)

theorem identity60598 : scanCanonicalize (H12AffineFastState.compose env60598 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound60598 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60599 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5375,428,262144,1025,2128,3076,1417,64,3158,1288,17,267633,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound60599 : H12AffineFastState.Bounded env60599 := by
  intro p hp
  have h : env60599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60598_60599 : H12AffineEnvironment.transform 20 3076 env60598 = env60599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env60598 == env60599) = true)

theorem identity60599 : scanCanonicalize (H12AffineFastState.compose env60599 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound60599 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60600 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,5375,428,6377,1025,2128,3076,1417,64,3158,1288,17,3480,4177,508,4524,5368,7425,256,5237,428,1]

theorem envBound60600 : H12AffineFastState.Bounded env60600 := by
  intro p hp
  have h : env60600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60599_60600 : H12AffineEnvironment.transform 17 6377 env60599 = env60600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env60599 == env60600) = true)

theorem identity60600 : scanCanonicalize (H12AffineFastState.compose env60600 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60600 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60601 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1409,413,2128,1330,428,2340,1025,2128,3076,1417,64,3158,1288,17,3480,412,508,97,1333,3276,256,1464,428,1]

theorem envBound60601 : H12AffineFastState.Bounded env60601 := by
  intro p hp
  have h : env60601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60600_60601 : H12AffineEnvironment.transform 11 461 env60600 = env60601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60600 == env60601) = true)

theorem identity60601 : scanCanonicalize (H12AffineFastState.compose env60601 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound60601 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env60602 : List Nat := [2,4,8,16,32,64,128,256,1,409,2048,461,24,413,2128,171,428,2340,408,2128,2461,16,64,2511,145,17,2049,412,508,97,172,2389,256,33,428,1]

theorem envBound60602 : H12AffineFastState.Bounded env60602 := by
  intro p hp
  have h : env60602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60601_60602 : H12AffineEnvironment.transform 9 409 env60601 = env60602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env60601 == env60602) = true)

theorem identity60602 : scanCanonicalize (H12AffineFastState.compose env60602 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound60602 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60603 : List Nat := [2,4,8,16,32,64,128,256,1,409,325,461,24,413,277,171,428,97,408,277,216,16,64,138,145,17,324,412,508,97,172,16,256,33,428,1]

theorem envBound60603 : H12AffineFastState.Bounded env60603 := by
  intro p hp
  have h : env60603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60602_60603 : H12AffineEnvironment.transform 10 325 env60602 = env60603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env60602 == env60603) = true)

theorem identity60603 : scanCanonicalize (H12AffineFastState.compose env60603 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound60603 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60604 : List Nat := [2,4,8,16,32,64,128,110,1,247,43,163,24,243,123,171,194,97,246,123,216,16,64,138,145,17,42,242,146,97,172,16,110,33,194,1]

theorem envBound60604 : H12AffineFastState.Bounded env60604 := by
  intro p hp
  have h : env60604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60603_60604 : H12AffineEnvironment.transform 7 110 env60603 = env60604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env60603 == env60604) = true)

theorem identity60604 : scanCanonicalize (H12AffineFastState.compose env60604 (packedSelected [0,1,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60604 : packedSelected [0,1,6,11] rootPS < 2^1333 := by decide +kernel

def env60605 : List Nat := [2,4,8,16,16,64,128,94,1,199,27,147,24,195,75,155,194,81,198,75,216,16,64,138,145,17,26,194,146,81,156,16,94,17,194,1]

theorem envBound60605 : H12AffineFastState.Bounded env60605 := by
  intro p hp
  have h : env60605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60604_60605 : H12AffineEnvironment.transform 4 16 env60604 = env60605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60604 == env60605) = true)

def env60606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8388688,134217728,4176,77954,4294795,8463814,149237954,256,136679855,78034,33563273]

theorem envBound60606 : H12AffineFastState.Bounded env60606 := by
  intro p hp
  have h : env60606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59107_60606 : H12AffineEnvironment.transform 13 4177 env59107 = env60606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env59107 == env60606) = true)

theorem identity60606 : scanCanonicalize (H12AffineFastState.compose env60606 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound60606 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env60607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388688,134217728,4176,77954,4294795,8463814,149237954,256,136679855,78034,513]

theorem envBound60607 : H12AffineFastState.Bounded env60607 := by
  intro p hp
  have h : env60607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60606_60607 : H12AffineEnvironment.transform 24 8328 env60606 = env60607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env60606 == env60607) = true)

theorem identity60607 : scanCanonicalize (H12AffineFastState.compose env60607 (packedSelected [4,9,16] rootPS)) = affineNative (2^(26+1) ^^^ 8724554) := by decide +kernel

theorem selectedBound60607 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,2097152,4194304,8388608,8430023,8328,8388688,8724554,4176,77954,4294795,8463814,6295688,256,10531301,78034,513]

theorem envBound60608 : H12AffineFastState.Bounded env60608 := by
  intro p hp
  have h : env60608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60607_60608 : H12AffineEnvironment.transform 26 8724554 env60607 = env60608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8724554 env60607 == env60608) = true)

theorem identity60608 : scanCanonicalize (H12AffineFastState.compose env60608 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound60608 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,4194304,8388608,8430023,8328,8388688,8724554,4176,77954,4294795,8463814,4194441,256,8430052,78034,513]

theorem envBound60609 : H12AffineFastState.Bounded env60609 := by
  intro p hp
  have h : env60609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60608_60609 : H12AffineEnvironment.transform 20 4097 env60608 = env60609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env60608 == env60609) = true)

theorem identity60609 : scanCanonicalize (H12AffineFastState.compose env60609 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4292674) := by decide +kernel

theorem selectedBound60609 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env60610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,4194304,4292674,4268421,8328,4292626,4497416,4176,77954,4294795,4236676,4194441,256,4268454,78034,513]

theorem envBound60610 : H12AffineFastState.Bounded env60610 := by
  intro p hp
  have h : env60610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60609_60610 : H12AffineEnvironment.transform 22 4292674 env60609 = env60610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292674 env60609 == env60610) = true)

theorem identity60610 : scanCanonicalize (H12AffineFastState.compose env60610 (packedSelected [6,25] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound60610 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env60611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,78034,262144,1025,32768,4097,397,98767,73736,8328,98719,303493,4176,77954,100614,41993,260,256,73771,78034,513]

theorem envBound60611 : H12AffineFastState.Bounded env60611 := by
  intro p hp
  have h : env60611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60610_60611 : H12AffineEnvironment.transform 21 397 env60610 = env60611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env60610 == env60611) = true)

theorem identity60611 : scanCanonicalize (H12AffineFastState.compose env60611 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound60611 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,8283,4233,262144,1025,32768,4097,397,41364,83,8328,41412,303493,4176,4313,43357,41993,260,256,112,4233,513]

theorem envBound60612 : H12AffineFastState.Bounded env60612 := by
  intro p hp
  have h : env60612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60611_60612 : H12AffineEnvironment.transform 15 8283 env60611 = env60612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env60611 == env60612) = true)

theorem identity60612 : scanCanonicalize (H12AffineFastState.compose env60612 (packedSelected [0,6,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound60612 : packedSelected [0,6,7,20] rootPS < 2^1333 := by decide +kernel

def env60613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,8432,8283,4233,262144,1025,8432,4097,397,356,83,8328,308,262517,4176,4313,2477,1273,260,256,112,4233,513]

theorem envBound60613 : H12AffineFastState.Bounded env60613 := by
  intro p hp
  have h : env60613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60612_60613 : H12AffineEnvironment.transform 14 8432 env60612 = env60613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env60612 == env60613) = true)

theorem identity60613 : scanCanonicalize (H12AffineFastState.compose env60613 (packedSelected [2,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound60613 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env60614 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,4177,8432,8283,4233,262144,1025,8432,4097,33,200,83,8328,152,262361,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60614 : H12AffineFastState.Bounded env60614 := by
  intro p hp
  have h : env60614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60613_60614 : H12AffineEnvironment.transform 7 172 env60613 = env60614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env60613 == env60614) = true)

theorem identity60614 : scanCanonicalize (H12AffineFastState.compose env60614 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 4681) := by decide +kernel

theorem selectedBound60614 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env60615 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,4681,4177,4793,4626,4233,262144,1025,4793,4097,33,200,83,4801,152,262361,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60615 : H12AffineFastState.Bounded env60615 := by
  intro p hp
  have h : env60615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60614_60615 : H12AffineEnvironment.transform 12 4681 env60614 = env60615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4681 env60614 == env60615) = true)

theorem identity60615 : scanCanonicalize (H12AffineFastState.compose env60615 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 5182) := by decide +kernel

theorem selectedBound60615 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60616 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,4681,4177,4793,4626,4233,5182,1025,4793,4097,33,200,83,4801,152,5351,4176,4313,2049,1273,168,172,112,4233,513]

theorem envBound60616 : H12AffineFastState.Bounded env60616 := by
  intro p hp
  have h : env60616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60615_60616 : H12AffineEnvironment.transform 17 5182 env60615 = env60616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5182 env60615 == env60616) = true)

def env60617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131152,4315354,8463814,4294967296,256,4307611964,131073,33563273]

theorem envBound60617 : H12AffineFastState.Bounded env60617 := by
  intro p hp
  have h : env60617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59104_60617 : H12AffineEnvironment.transform 34 131073 env59104 = env60617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env59104 == env60617) = true)

theorem identity60617 : scanCanonicalize (H12AffineFastState.compose env60617 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 147157138) := by decide +kernel

theorem selectedBound60617 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env60618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,134217728,16385,131152,4315354,8463814,147157138,256,134578606,131073,33563273]

theorem envBound60618 : H12AffineFastState.Bounded env60618 := by
  intro p hp
  have h : env60618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60617_60618 : H12AffineEnvironment.transform 31 147157138 env60617 = env60618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147157138 env60617 == env60618) = true)

theorem identity60618 : scanCanonicalize (H12AffineFastState.compose env60618 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(26+1) ^^^ 12992837) := by decide +kernel

theorem selectedBound60618 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env60619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,8388608,8430023,33554432,8409089,12992837,16385,131152,4315354,8463814,209367,256,12828907,131073,33563273]

theorem envBound60619 : H12AffineFastState.Bounded env60619 := by
  intro p hp
  have h : env60619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60618_60619 : H12AffineEnvironment.transform 26 12992837 env60618 = env60619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12992837 env60618 == env60619) = true)

def env60620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304863,33554432,6342041,2544861,16385,131152,4315354,6402142,209367,256,2315635,131073,33563273]

theorem envBound60620 : H12AffineFastState.Bounded env60620 := by
  intro p hp
  have h : env60620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60619_60620 : H12AffineEnvironment.transform 22 6329752 env60619 = env60620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329752 env60619 == env60620) = true)

def env60621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,6329752,6304863,4247640,6342041,2544861,16385,131152,4315354,6402142,209367,256,2315635,131073,4256465]

theorem envBound60621 : H12AffineFastState.Bounded env60621 := by
  intro p hp
  have h : env60621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60620_60621 : H12AffineEnvironment.transform 24 4247640 env60620 = env60621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env60620 == env60621) = true)

def env60622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2269392,144712,169103,2257032,157001,2544861,16385,131152,2324490,200846,209367,256,2315635,131073,2249217]

theorem envBound60622 : H12AffineFastState.Bounded env60622 := by
  intro p hp
  have h : env60622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60621_60622 : H12AffineEnvironment.transform 21 2269392 env60621 = env60622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env60621 == env60622) = true)

def env60623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,46480,144712,169103,26056,157001,311709,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60623 : H12AffineFastState.Bounded env60623 := by
  intro p hp
  have h : env60623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60622_60623 : H12AffineEnvironment.transform 20 136512 env60622 = env60623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env60622 == env60623) = true)

def env60624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1025,32768,136512,46480,144712,169103,26056,157001,103453,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60624 : H12AffineFastState.Bounded env60624 := by
  intro p hp
  have h : env60624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60623_60624 : H12AffineEnvironment.transform 17 87424 env60623 = env60624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env60623 == env60624) = true)

theorem identity60624 : scanCanonicalize (H12AffineFastState.compose env60624 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 9445) := by decide +kernel

theorem selectedBound60624 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9445,32768,65536,131072,78181,1025,32768,136512,46480,144712,169103,301,131500,103453,9444,131152,68015,200846,209367,256,74966,131073,9124]

theorem envBound60625 : H12AffineFastState.Bounded env60625 := by
  intro p hp
  have h : env60625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60624_60625 : H12AffineEnvironment.transform 13 9445 env60624 = env60625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9445 env60624 == env60625) = true)

def env60626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,65536,131072,69825,1025,32768,136512,37940,136428,169103,301,131500,103453,1344,131152,68015,200846,200819,256,66930,131073,512]

theorem envBound60626 : H12AffineFastState.Bounded env60626 := by
  intro p hp
  have h : env60626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60625_60626 : H12AffineEnvironment.transform 12 420 env60625 = env60626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env60625 == env60626) = true)

theorem identity60626 : scanCanonicalize (H12AffineFastState.compose env60626 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound60626 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,420,1345,32768,65536,131072,67024,1025,32768,131153,33061,131581,164254,301,131500,98572,1344,131152,68015,198047,197986,256,66930,131073,512]

theorem envBound60627 : H12AffineFastState.Bounded env60627 := by
  intro p hp
  have h : env60627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60626_60627 : H12AffineEnvironment.transform 11 1297 env60626 = env60627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env60626 == env60627) = true)

def env60628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,32768,65536,131072,69824,1025,32768,136512,37941,136429,169103,301,131500,103453,1345,131152,68015,200846,200818,256,66931,131073,513]

theorem envBound60628 : H12AffineFastState.Bounded env60628 := by
  intro p hp
  have h : env60628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60625_60628 : H12AffineEnvironment.transform 12 421 env60625 = env60628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env60625 == env60628) = true)

theorem identity60628 : scanCanonicalize (H12AffineFastState.compose env60628 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound60628 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env60629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,32768,38046,131072,33886,1025,32768,136512,37941,136429,169103,301,131500,131,1345,131152,40241,164880,165100,256,37357,131073,513]

theorem envBound60629 : H12AffineFastState.Bounded env60629 := by
  intro p hp
  have h : env60629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60628_60629 : H12AffineEnvironment.transform 15 38046 env60628 = env60629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env60628 == env60629) = true)

theorem identity60629 : scanCanonicalize (H12AffineFastState.compose env60629 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 445) := by decide +kernel

theorem selectedBound60629 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env60630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,32768,38046,445,33886,1025,32768,5373,37941,5456,38194,301,17,131,1345,493,40241,34221,34129,256,37357,444,513]

theorem envBound60630 : H12AffineFastState.Bounded env60630 := by
  intro p hp
  have h : env60630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60629_60630 : H12AffineEnvironment.transform 16 445 env60629 = env60630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 445 env60629 == env60630) = true)

theorem identity60630 : scanCanonicalize (H12AffineFastState.compose env60630 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound60630 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env60631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,1109,4299,445,11,1025,1109,5373,4192,5456,4455,301,17,131,1345,493,6500,504,260,256,5560,444,513]

theorem envBound60631 : H12AffineFastState.Bounded env60631 := by
  intro p hp
  have h : env60631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60630_60631 : H12AffineEnvironment.transform 14 1109 env60630 = env60631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env60630 == env60631) = true)

theorem identity60631 : scanCanonicalize (H12AffineFastState.compose env60631 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3767) := by decide +kernel

theorem selectedBound60631 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3767,421,1344,1109,3708,445,11,1025,1109,2634,3799,3047,4048,301,17,131,1345,493,2003,504,260,256,2831,444,513]

theorem envBound60632 : H12AffineFastState.Bounded env60632 := by
  intro p hp
  have h : env60632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60631_60632 : H12AffineEnvironment.transform 11 3767 env60631 = env60632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3767 env60631 == env60632) = true)

theorem identity60632 : scanCanonicalize (H12AffineFastState.compose env60632 (packedSelected [0,1,5,7,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound60632 : packedSelected [0,1,5,7,10,13,16] rootPS < 2^1333 := by decide +kernel

def env60633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1803,444,421,1344,1109,375,445,11,1025,1109,1345,476,1260,219,301,17,131,1345,493,2003,504,260,256,1028,444,513]

theorem envBound60633 : H12AffineFastState.Bounded env60633 := by
  intro p hp
  have h : env60633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60632_60633 : H12AffineEnvironment.transform 10 1803 env60632 = env60633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env60632 == env60633) = true)

theorem identity60633 : scanCanonicalize (H12AffineFastState.compose env60633 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60633 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env60634 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1782,65,88,1213,1109,138,64,11,1025,1109,1212,33,1260,219,208,17,131,1212,16,1582,5,249,253,1028,65,513]

theorem envBound60634 : H12AffineFastState.Bounded env60634 := by
  intro p hp
  have h : env60634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60633_60634 : H12AffineEnvironment.transform 7 253 env60633 = env60634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60633 == env60634) = true)

theorem identity60634 : scanCanonicalize (H12AffineFastState.compose env60634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound60634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60635 : List Nat := [2,4,8,16,32,64,128,253,216,1024,1070,65,88,1213,1109,138,64,11,1025,1109,1212,33,1260,219,208,17,131,1212,16,1270,5,249,253,1028,65,217]

theorem envBound60635 : H12AffineFastState.Bounded env60635 := by
  intro p hp
  have h : env60635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60634_60635 : H12AffineEnvironment.transform 8 216 env60634 = env60635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env60634 == env60635) = true)

theorem identity60635 : scanCanonicalize (H12AffineFastState.compose env60635 (packedSelected [1,2,3,4,5,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound60635 : packedSelected [1,2,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60636 : List Nat := [2,4,8,16,32,64,128,253,216,166,136,65,88,27,243,138,64,11,167,243,26,33,74,219,208,17,131,26,16,80,5,249,253,162,65,217]

theorem envBound60636 : H12AffineFastState.Bounded env60636 := by
  intro p hp
  have h : env60636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60635_60636 : H12AffineEnvironment.transform 9 166 env60635 = env60636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env60635 == env60636) = true)

theorem identity60636 : scanCanonicalize (H12AffineFastState.compose env60636 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound60636 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env60637 : List Nat := [2,4,8,16,32,64,19,110,75,53,27,65,88,27,96,25,64,11,52,96,26,33,74,72,67,17,16,26,16,80,5,106,110,49,65,74]

theorem envBound60637 : H12AffineFastState.Bounded env60637 := by
  intro p hp
  have h : env60637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60636_60637 : H12AffineEnvironment.transform 6 19 env60636 = env60637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env60636 == env60637) = true)

theorem identity60637 : scanCanonicalize (H12AffineFastState.compose env60637 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound60637 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env60638 : List Nat := [2,4,8,16,32,26,19,52,17,53,27,27,2,27,58,25,26,11,52,58,26,33,16,18,25,17,16,26,16,10,5,48,52,49,27,16]

theorem envBound60638 : H12AffineFastState.Bounded env60638 := by
  intro p hp
  have h : env60638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60637_60638 : H12AffineEnvironment.transform 5 26 env60637 = env60638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env60637 == env60638) = true)

theorem identity60638 : scanCanonicalize (H12AffineFastState.compose env60638 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60639 : List Nat := [2,4,8,16,10,26,19,30,17,31,27,27,2,27,16,25,26,11,30,16,26,11,16,18,25,17,16,26,16,10,5,26,30,27,27,16]

theorem envBound60639 : H12AffineFastState.Bounded env60639 := by
  intro p hp
  have h : env60639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60638_60639 : H12AffineEnvironment.transform 4 10 env60638 = env60639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60638 == env60639) = true)

theorem identity60639 : scanCanonicalize (H12AffineFastState.compose env60639 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60640 : List Nat := [2,4,8,2,10,8,1,12,3,13,9,9,2,9,2,11,8,11,12,2,8,11,2,0,11,3,2,8,2,10,5,8,12,9,9,2]

theorem envBound60640 : H12AffineFastState.Bounded env60640 := by
  intro p hp
  have h : env60640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60639_60640 : H12AffineEnvironment.transform 3 2 env60639 = env60640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60639 == env60640) = true)

def env60641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1025,32768,136512,46480,144712,169103,26056,157001,103452,16385,131152,93514,200846,209367,256,81971,131073,18241]

theorem envBound60641 : H12AffineFastState.Bounded env60641 := by
  intro p hp
  have h : env60641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60623_60641 : H12AffineEnvironment.transform 17 87425 env60623 = env60641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env60623 == env60641) = true)

theorem identity60641 : scanCanonicalize (H12AffineFastState.compose env60641 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound60641 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1