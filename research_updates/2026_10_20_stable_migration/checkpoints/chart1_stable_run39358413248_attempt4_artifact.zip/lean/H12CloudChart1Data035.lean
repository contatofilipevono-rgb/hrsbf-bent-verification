import H12CloudChart1Data034

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env8698 : List Nat := [2,4,2,16,1,64,128,214,1,214,1,146,145,17,146,18,146,130,4,146,65,81,194,82,18,146,211,17,16,130,4,81,4,130,194,80]

theorem envBound8698 : H12AffineFastState.Bounded env8698 := by
  intro p hp
  have h : env8698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8697_8698 : H12AffineEnvironment.transform 2 2 env8697 = env8698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8697 == env8698) = true)

theorem identity8698 : scanCanonicalize (H12AffineFastState.compose env8698 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8698 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8699 : List Nat := [2,4,2,1,1,64,128,199,1,199,1,131,128,0,131,3,131,130,4,131,65,64,194,67,3,131,194,0,1,130,4,64,4,130,194,65]

theorem envBound8699 : H12AffineFastState.Bounded env8699 := by
  intro p hp
  have h : env8699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8698_8699 : H12AffineEnvironment.transform 3 1 env8698 = env8699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8698 == env8699) = true)

theorem identity8699 : scanCanonicalize (H12AffineFastState.compose env8699 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8700 : List Nat := [2,4,2,1,1,64,2,69,1,69,1,1,2,0,1,3,1,0,4,1,65,64,64,67,3,1,64,0,1,0,4,64,4,0,64,65]

theorem envBound8700 : H12AffineFastState.Bounded env8700 := by
  intro p hp
  have h : env8700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8699_8700 : H12AffineEnvironment.transform 6 2 env8699 = env8700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8699 == env8700) = true)

theorem identity8700 : scanCanonicalize (H12AffineFastState.compose env8700 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8700 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8701 : List Nat := [2,4,2,1,1,1,2,4,1,4,1,1,2,0,1,3,1,0,4,1,0,1,1,2,3,1,1,0,1,0,4,1,4,0,1,0]

theorem envBound8701 : H12AffineFastState.Bounded env8701 := by
  intro p hp
  have h : env8701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8700_8701 : H12AffineEnvironment.transform 5 1 env8700 = env8701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8700 == env8701) = true)

theorem identity8701 : scanCanonicalize (H12AffineFastState.compose env8701 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8702 : List Nat := [2,1,2,1,1,1,2,1,1,1,1,1,2,0,1,3,1,0,1,1,0,1,1,2,3,1,1,0,1,0,1,1,1,0,1,0]

theorem envBound8702 : H12AffineFastState.Bounded env8702 := by
  intro p hp
  have h : env8702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8701_8702 : H12AffineEnvironment.transform 1 1 env8701 = env8702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8701 == env8702) = true)

def env8703 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,94889,4765,8201,65,16960,4720,90337,8329,21041,78536,4745,4744,75786,4,90850,4765,73770,78579,90819]

theorem envBound8703 : H12AffineFastState.Bounded env8703 := by
  intro p hp
  have h : env8703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8678_8703 : H12AffineEnvironment.transform 17 94889 env8678 = env8703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94889 env8678 == env8703) = true)

def env8704 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,77977,4765,8201,65,112,4720,74449,8329,4097,78536,4745,4744,75786,4,73938,4765,73770,78579,73971]

theorem envBound8704 : H12AffineFastState.Bounded env8704 := by
  intro p hp
  have h : env8704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8703_8704 : H12AffineEnvironment.transform 13 560 env8703 = env8704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8703 == env8704) = true)

theorem identity8704 : scanCanonicalize (H12AffineFastState.compose env8704 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12979) := by decide +kernel

theorem selectedBound8704 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8705 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,12979,4096,554,4765,8201,65,112,4720,4194,8329,4097,123,4745,4744,6841,4,4705,4765,4761,64,4672]

theorem envBound8705 : H12AffineFastState.Bounded env8705 := by
  intro p hp
  have h : env8705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8704_8705 : H12AffineEnvironment.transform 15 12979 env8704 = env8705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12979 env8704 == env8705) = true)

theorem identity8705 : scanCanonicalize (H12AffineFastState.compose env8705 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8705 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8706 : List Nat := [2,4,8,16,32,64,128,253,32,253,2048,4096,8192,16,8201,12435,4096,10,4285,8201,65,112,4176,4194,8329,4097,123,4265,4264,6297,4,4161,4285,4281,64,4192]

theorem envBound8706 : H12AffineFastState.Bounded env8706 := by
  intro p hp
  have h : env8706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8705_8706 : H12AffineEnvironment.transform 8 32 env8705 = env8706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8705 == env8706) = true)

theorem identity8706 : scanCanonicalize (H12AffineFastState.compose env8706 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound8706 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8707 : List Nat := [2,4,8,16,32,64,128,253,32,253,210,4096,8192,16,8201,12435,4096,10,4285,8201,65,112,4176,4194,8329,4097,123,4265,4264,4171,4,4161,4285,4281,64,4192]

theorem envBound8707 : H12AffineFastState.Bounded env8707 := by
  intro p hp
  have h : env8707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8706_8707 : H12AffineEnvironment.transform 10 210 env8706 = env8707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env8706 == env8707) = true)

theorem identity8707 : scanCanonicalize (H12AffineFastState.compose env8707 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound8707 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env8708 : List Nat := [2,4,8,16,32,64,128,253,32,253,210,233,8192,16,8201,8314,233,10,84,8201,65,112,185,139,8329,232,123,64,65,162,4,168,84,80,64,137]

theorem envBound8708 : H12AffineFastState.Bounded env8708 := by
  intro p hp
  have h : env8708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8707_8708 : H12AffineEnvironment.transform 11 233 env8707 = env8708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env8707 == env8708) = true)

theorem identity8708 : scanCanonicalize (H12AffineFastState.compose env8708 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 114) := by decide +kernel

theorem selectedBound8708 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env8709 : List Nat := [2,4,8,16,32,64,128,253,32,253,210,233,114,16,123,8,233,10,84,123,65,112,185,139,251,232,123,64,65,162,4,168,84,80,64,137]

theorem envBound8709 : H12AffineFastState.Bounded env8709 := by
  intro p hp
  have h : env8709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8708_8709 : H12AffineEnvironment.transform 12 114 env8708 = env8709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 114 env8708 == env8709) = true)

theorem identity8709 : scanCanonicalize (H12AffineFastState.compose env8709 (packedSelected [1,2,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8709 : packedSelected [1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env8710 : List Nat := [2,4,8,0,32,64,128,237,32,237,194,233,98,0,107,8,233,10,68,107,65,96,169,139,235,232,107,64,65,162,4,168,68,64,64,137]

theorem envBound8710 : H12AffineFastState.Bounded env8710 := by
  intro p hp
  have h : env8710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8709_8710 : H12AffineEnvironment.transform 3 0 env8709 = env8710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8709 == env8710) = true)

theorem identity8710 : scanCanonicalize (H12AffineFastState.compose env8710 (packedSelected [2,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8710 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env8711 : List Nat := [2,4,8,0,32,11,128,166,32,166,137,162,41,0,32,8,162,10,15,32,10,43,169,139,160,163,32,11,10,162,4,168,15,11,11,137]

theorem envBound8711 : H12AffineFastState.Bounded env8711 := by
  intro p hp
  have h : env8711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8710_8711 : H12AffineEnvironment.transform 5 11 env8710 = env8711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8710 == env8711) = true)

theorem identity8711 : scanCanonicalize (H12AffineFastState.compose env8711 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8711 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8712 : List Nat := [2,4,8,0,10,11,128,140,10,140,137,136,3,0,10,8,136,10,15,10,10,1,131,139,138,137,10,11,10,136,4,130,15,11,11,137]

theorem envBound8712 : H12AffineFastState.Bounded env8712 := by
  intro p hp
  have h : env8712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8711_8712 : H12AffineEnvironment.transform 4 10 env8711 = env8712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8711 == env8712) = true)

theorem identity8712 : scanCanonicalize (H12AffineFastState.compose env8712 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8713 : List Nat := [2,4,3,0,1,0,128,135,1,135,130,131,3,0,1,3,131,1,4,1,1,1,131,128,129,130,1,0,1,131,4,130,4,0,0,130]

theorem envBound8713 : H12AffineFastState.Bounded env8713 := by
  intro p hp
  have h : env8713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8712_8713 : H12AffineEnvironment.transform 2 3 env8712 = env8713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8712 == env8713) = true)

theorem identity8713 : scanCanonicalize (H12AffineFastState.compose env8713 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8714 : List Nat := [2,4,3,0,1,0,2,5,1,5,0,1,3,0,1,3,1,1,4,1,1,1,1,2,3,0,1,0,1,1,4,0,4,0,0,0]

theorem envBound8714 : H12AffineFastState.Bounded env8714 := by
  intro p hp
  have h : env8714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8713_8714 : H12AffineEnvironment.transform 6 2 env8713 = env8714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8713 == env8714) = true)

theorem identity8714 : scanCanonicalize (H12AffineFastState.compose env8714 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8715 : List Nat := [2,1,3,0,1,0,2,0,1,0,0,1,3,0,1,3,1,1,1,1,1,1,1,2,3,0,1,0,1,1,1,0,1,0,0,0]

theorem envBound8715 : H12AffineFastState.Bounded env8715 := by
  intro p hp
  have h : env8715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8714_8715 : H12AffineEnvironment.transform 1 1 env8714 = env8715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8714 == env8715) = true)

def env8716 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,77976,4765,8201,65,113,4720,74448,8329,4096,78536,4745,4744,75786,4,73939,4765,73770,78579,73970]

theorem envBound8716 : H12AffineFastState.Bounded env8716 := by
  intro p hp
  have h : env8716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8703_8716 : H12AffineEnvironment.transform 13 561 env8703 = env8716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8703 == env8716) = true)

theorem identity8716 : scanCanonicalize (H12AffineFastState.compose env8716 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12874) := by decide +kernel

theorem selectedBound8716 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8717 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,12874,4096,722,4765,8201,65,113,4720,4250,8329,4096,130,4745,4744,6720,4,4761,4765,4704,185,4792]

theorem envBound8717 : H12AffineFastState.Bounded env8717 := by
  intro p hp
  have h : env8717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8716_8717 : H12AffineEnvironment.transform 15 12874 env8716 = env8717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12874 env8716 == env8717) = true)

theorem identity8717 : scanCanonicalize (H12AffineFastState.compose env8717 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound8717 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env8718 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,2194,8192,561,8201,10968,2194,722,2575,8201,65,113,2786,2056,8329,2194,130,2587,2586,722,4,2571,2575,2802,185,2602]

theorem envBound8718 : H12AffineFastState.Bounded env8718 := by
  intro p hp
  have h : env8718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8717_8718 : H12AffineEnvironment.transform 11 2194 env8717 = env8718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env8717 == env8718) = true)

theorem identity8718 : scanCanonicalize (H12AffineFastState.compose env8718 (packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound8718 : packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS < 2^1333 := by decide +kernel

def env8719 : List Nat := [2,4,8,16,32,64,128,253,112,253,2048,2194,8192,65,8201,10408,2194,162,2175,8201,65,113,2194,2056,8329,2194,130,2155,2154,162,4,2171,2175,2178,185,2138]

theorem envBound8719 : H12AffineFastState.Bounded env8719 := by
  intro p hp
  have h : env8719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8718_8719 : H12AffineEnvironment.transform 8 112 env8718 = env8719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env8718 == env8719) = true)

theorem identity8719 : scanCanonicalize (H12AffineFastState.compose env8719 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8719 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8720 : List Nat := [2,4,8,16,32,16,128,173,32,173,2048,2194,8192,17,8201,10408,2194,162,2095,8201,17,33,2194,2056,8329,2194,130,2107,2106,162,4,2091,2095,2178,185,2058]

theorem envBound8720 : H12AffineFastState.Bounded env8720 := by
  intro p hp
  have h : env8720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8719_8720 : H12AffineEnvironment.transform 5 16 env8719 = env8720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8719 == env8720) = true)

theorem identity8720 : scanCanonicalize (H12AffineFastState.compose env8720 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 153) := by decide +kernel

theorem selectedBound8720 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8721 : List Nat := [2,4,8,16,32,16,128,173,32,173,153,11,8192,17,8201,8241,11,162,182,8201,17,33,11,145,8329,11,130,162,163,162,4,178,182,27,185,147]

theorem envBound8721 : H12AffineFastState.Bounded env8721 := by
  intro p hp
  have h : env8721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8720_8721 : H12AffineEnvironment.transform 10 153 env8720 = env8721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 153 env8720 == env8721) = true)

theorem identity8721 : scanCanonicalize (H12AffineFastState.compose env8721 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound8721 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env8722 : List Nat := [2,4,8,16,32,16,24,53,32,53,1,11,8192,17,8201,8241,11,58,46,8201,17,33,11,9,8209,11,26,58,59,58,4,42,46,27,33,11]

theorem envBound8722 : H12AffineFastState.Bounded env8722 := by
  intro p hp
  have h : env8722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8721_8722 : H12AffineEnvironment.transform 6 24 env8721 = env8722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env8721 == env8722) = true)

theorem identity8722 : scanCanonicalize (H12AffineFastState.compose env8722 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound8722 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env8723 : List Nat := [2,4,8,16,32,16,24,53,32,53,1,11,51,17,58,2,11,58,46,58,17,33,11,9,34,11,26,58,59,58,4,42,46,27,33,11]

theorem envBound8723 : H12AffineFastState.Bounded env8723 := by
  intro p hp
  have h : env8723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8722_8723 : H12AffineEnvironment.transform 12 51 env8722 = env8723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env8722 == env8723) = true)

theorem identity8723 : scanCanonicalize (H12AffineFastState.compose env8723 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound8723 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8724 : List Nat := [2,4,8,16,27,16,24,14,27,14,1,11,8,17,1,2,11,1,21,1,17,26,11,9,25,11,26,1,0,1,4,17,21,27,26,11]

theorem envBound8724 : H12AffineFastState.Bounded env8724 := by
  intro p hp
  have h : env8724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8723_8724 : H12AffineEnvironment.transform 4 27 env8723 = env8724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env8723 == env8724) = true)

theorem identity8724 : scanCanonicalize (H12AffineFastState.compose env8724 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8725 : List Nat := [2,4,8,0,11,0,8,14,11,14,1,11,8,1,1,2,11,1,5,1,1,10,11,9,9,11,10,1,0,1,4,1,5,11,10,11]

theorem envBound8725 : H12AffineFastState.Bounded env8725 := by
  intro p hp
  have h : env8725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8724_8725 : H12AffineEnvironment.transform 3 0 env8724 = env8725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8724 == env8725) = true)

theorem identity8725 : scanCanonicalize (H12AffineFastState.compose env8725 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8726 : List Nat := [2,4,3,0,0,0,3,5,0,5,1,0,3,1,1,2,0,1,5,1,1,1,0,2,2,0,1,1,0,1,4,1,5,0,1,0]

theorem envBound8726 : H12AffineFastState.Bounded env8726 := by
  intro p hp
  have h : env8726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8725_8726 : H12AffineEnvironment.transform 2 3 env8725 = env8726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8725 == env8726) = true)

def env8727 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5004,90337,8329,21041,278624,4214984,4215092,75787,504,4268382,4961,73771,2175667,90942]

theorem envBound8727 : H12AffineFastState.Bounded env8727 := by
  intro p hp
  have h : env8727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8658_8727 : H12AffineEnvironment.transform 18 4961 env8658 = env8727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8658 == env8727) = true)

theorem identity8727 : scanCanonicalize (H12AffineFastState.compose env8727 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24771) := by decide +kernel

theorem selectedBound8727 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8728 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,2097152,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4961,16616,2118256,1021]

theorem envBound8728 : H12AffineFastState.Bounded env8728 := by
  intro p hp
  have h : env8728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8727_8728 : H12AffineEnvironment.transform 15 24771 env8727 = env8728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24771 env8727 == env8728) = true)

def env8729 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,64,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4961,16616,21040,1021]

theorem envBound8729 : H12AffineFastState.Bounded env8729 := by
  intro p hp
  have h : env8729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8728_8729 : H12AffineEnvironment.transform 20 64 env8728 = env8729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8728 == env8729) = true)

theorem identity8729 : scanCanonicalize (H12AffineFastState.compose env8729 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17350) := by decide +kernel

theorem selectedBound8729 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8730 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,17350,4961,8692,64,4194304,5004,34,8329,21041,934,4214984,4215092,18632,504,4211101,4961,16616,21040,1021]

theorem envBound8730 : H12AffineFastState.Bounded env8730 := by
  intro p hp
  have h : env8730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8729_8730 : H12AffineEnvironment.transform 17 17350 env8729 = env8730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17350 env8729 == env8730) = true)

def env8731 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8235,4605,814,4961,8692,64,4194304,5004,34,8329,4825,934,4198432,4198876,2080,504,4194677,4961,0,4824,1021]

theorem envBound8731 : H12AffineFastState.Bounded env8731 := by
  intro p hp
  have h : env8731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8730_8731 : H12AffineEnvironment.transform 13 232 env8730 = env8731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8730 == env8731) = true)

theorem identity8731 : scanCanonicalize (H12AffineFastState.compose env8731 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8731 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8732 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8235,4605,814,4961,8692,64,477,5004,34,8329,4825,934,4605,4097,2080,504,168,4961,0,4824,1021]

theorem envBound8732 : H12AffineFastState.Bounded env8732 := by
  intro p hp
  have h : env8732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8731_8732 : H12AffineEnvironment.transform 21 477 env8731 = env8732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8731 == env8732) = true)

def env8733 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8235,4605,502,4537,8692,64,477,4436,34,8329,4097,382,4605,4097,2080,504,168,4537,0,4096,293]

theorem envBound8733 : H12AffineFastState.Bounded env8733 := by
  intro p hp
  have h : env8733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8732_8733 : H12AffineEnvironment.transform 8 216 env8732 = env8733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8732 == env8733) = true)

theorem identity8733 : scanCanonicalize (H12AffineFastState.compose env8733 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8733 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8734 : List Nat := [2,4,8,16,32,16,128,256,136,256,2048,4096,8192,184,8612,8235,4525,422,4537,8612,16,397,4356,34,8329,4097,302,4525,4097,2080,424,168,4537,0,4096,293]

theorem envBound8734 : H12AffineFastState.Bounded env8734 := by
  intro p hp
  have h : env8734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8733_8734 : H12AffineEnvironment.transform 5 16 env8733 = env8734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8733 == env8734) = true)

theorem identity8734 : scanCanonicalize (H12AffineFastState.compose env8734 (packedSelected [13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound8734 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8735 : List Nat := [2,4,8,16,32,16,128,256,136,256,130,4096,8192,184,8612,8235,4525,422,4537,8612,16,397,4356,34,8329,4097,302,4525,4097,162,424,168,4537,0,4096,293]

theorem envBound8735 : H12AffineFastState.Bounded env8735 := by
  intro p hp
  have h : env8735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8734_8735 : H12AffineEnvironment.transform 10 130 env8734 = env8735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env8734 == env8735) = true)

theorem identity8735 : scanCanonicalize (H12AffineFastState.compose env8735 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound8735 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8736 : List Nat := [2,4,8,16,32,16,128,256,136,256,130,185,8192,184,8612,8235,276,422,256,8612,16,397,445,34,8329,184,302,276,184,162,424,168,256,0,185,293]

theorem envBound8736 : H12AffineFastState.Bounded env8736 := by
  intro p hp
  have h : env8736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8735_8736 : H12AffineEnvironment.transform 11 185 env8735 = env8736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env8735 == env8736) = true)

theorem identity8736 : scanCanonicalize (H12AffineFastState.compose env8736 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8736 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env8737 : List Nat := [2,4,8,16,11,16,128,256,136,256,130,146,8192,147,8591,8192,276,397,256,8591,16,397,406,9,8329,147,261,276,147,137,387,131,256,0,146,270]

theorem envBound8737 : H12AffineFastState.Bounded env8737 := by
  intro p hp
  have h : env8737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8736_8737 : H12AffineEnvironment.transform 4 11 env8736 = env8737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8736 == env8737) = true)

theorem identity8737 : scanCanonicalize (H12AffineFastState.compose env8737 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound8737 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8738 : List Nat := [2,4,8,16,11,16,128,256,136,256,130,146,138,147,261,138,276,397,256,261,16,397,406,9,3,147,261,276,147,137,387,131,256,0,146,270]

theorem envBound8738 : H12AffineFastState.Bounded env8738 := by
  intro p hp
  have h : env8738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8737_8738 : H12AffineEnvironment.transform 12 138 env8737 = env8738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env8737 == env8738) = true)

theorem identity8738 : scanCanonicalize (H12AffineFastState.compose env8738 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound8738 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env8739 : List Nat := [2,4,8,16,11,16,128,30,136,30,130,146,138,147,27,138,10,147,30,27,16,147,136,9,3,147,27,10,147,137,157,131,30,0,146,16]

theorem envBound8739 : H12AffineFastState.Bounded env8739 := by
  intro p hp
  have h : env8739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8738_8739 : H12AffineEnvironment.transform 7 30 env8738 = env8739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env8738 == env8739) = true)

theorem identity8739 : scanCanonicalize (H12AffineFastState.compose env8739 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8739 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8740 : List Nat := [2,4,3,16,0,16,128,21,131,21,130,146,129,147,16,129,1,147,21,16,16,147,131,2,3,147,16,1,147,130,150,131,21,0,146,16]

theorem envBound8740 : H12AffineFastState.Bounded env8740 := by
  intro p hp
  have h : env8740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8739_8740 : H12AffineEnvironment.transform 2 3 env8739 = env8740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8739 == env8740) = true)

def env8741 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8235,4605,503,4536,8692,64,477,4437,34,8329,4096,383,4605,4097,2080,504,168,4536,0,4097,292]

theorem envBound8741 : H12AffineFastState.Bounded env8741 := by
  intro p hp
  have h : env8741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8732_8741 : H12AffineEnvironment.transform 8 217 env8732 = env8741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8732 == env8741) = true)

theorem identity8741 : scanCanonicalize (H12AffineFastState.compose env8741 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8741 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8742 : List Nat := [2,4,8,16,32,64,128,4,217,4,2048,4096,8192,232,8432,8235,4345,243,4284,8432,64,217,4177,34,8329,4096,123,4345,4097,2080,252,168,4284,0,4097,32]

theorem envBound8742 : H12AffineFastState.Bounded env8742 := by
  intro p hp
  have h : env8742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8741_8742 : H12AffineEnvironment.transform 7 4 env8741 = env8742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8741 == env8742) = true)

theorem identity8742 : scanCanonicalize (H12AffineFastState.compose env8742 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8742 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8743 : List Nat := [2,4,8,16,32,64,128,4,217,4,2048,2242,8192,232,8432,8235,2107,243,2174,8432,64,217,2195,34,8329,2242,123,2107,2243,2080,252,168,2174,0,2243,32]

theorem envBound8743 : H12AffineFastState.Bounded env8743 := by
  intro p hp
  have h : env8743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8742_8743 : H12AffineEnvironment.transform 11 2242 env8742 = env8743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8742 == env8743) = true)

theorem identity8743 : scanCanonicalize (H12AffineFastState.compose env8743 (packedSelected [0,2,4,7,9,11,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound8743 : packedSelected [0,2,4,7,9,11,13,18] rootPS < 2^1333 := by decide +kernel

def env8744 : List Nat := [2,4,8,16,32,64,50,4,107,4,2048,2160,8192,90,8258,8235,2107,65,2174,8258,64,107,2081,34,8251,2160,123,2107,2161,2080,78,26,2174,0,2161,32]

theorem envBound8744 : H12AffineFastState.Bounded env8744 := by
  intro p hp
  have h : env8744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8743_8744 : H12AffineEnvironment.transform 6 50 env8743 = env8744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env8743 == env8744) = true)

theorem identity8744 : scanCanonicalize (H12AffineFastState.compose env8744 (packedSelected [0,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8744 : packedSelected [0,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8745 : List Nat := [2,4,8,16,32,16,50,4,59,4,2048,2080,8192,10,8210,8235,2107,17,2094,8210,16,59,2081,34,8251,2080,43,2107,2081,2080,30,26,2094,0,2081,32]

theorem envBound8745 : H12AffineFastState.Bounded env8745 := by
  intro p hp
  have h : env8745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8744_8745 : H12AffineEnvironment.transform 5 16 env8744 = env8745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8744 == env8745) = true)

theorem identity8745 : scanCanonicalize (H12AffineFastState.compose env8745 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8745 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8746 : List Nat := [2,4,8,16,1,16,19,4,26,4,2048,2049,8192,10,8210,8202,2074,17,2063,8210,16,26,2048,3,8218,2049,10,2074,2048,2049,30,26,2063,0,2048,1]

theorem envBound8746 : H12AffineFastState.Bounded env8746 := by
  intro p hp
  have h : env8746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8745_8746 : H12AffineEnvironment.transform 4 1 env8745 = env8746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8745 == env8746) = true)

theorem identity8746 : scanCanonicalize (H12AffineFastState.compose env8746 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8746 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8747 : List Nat := [2,4,8,16,1,16,19,4,26,4,2048,2049,24,10,10,18,2074,17,2063,10,16,26,2048,3,2,2049,10,2074,2048,2049,30,26,2063,0,2048,1]

theorem envBound8747 : H12AffineFastState.Bounded env8747 := by
  intro p hp
  have h : env8747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8746_8747 : H12AffineEnvironment.transform 12 24 env8746 = env8747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8746 == env8747) = true)

theorem identity8747 : scanCanonicalize (H12AffineFastState.compose env8747 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8747 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8748 : List Nat := [2,4,8,0,1,0,3,4,10,4,2048,2049,8,10,10,2,2058,1,2063,10,0,10,2048,3,2,2049,10,2058,2048,2049,14,10,2063,0,2048,1]

theorem envBound8748 : H12AffineFastState.Bounded env8748 := by
  intro p hp
  have h : env8748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8747_8748 : H12AffineEnvironment.transform 3 0 env8747 = env8748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8747 == env8748) = true)

theorem identity8748 : scanCanonicalize (H12AffineFastState.compose env8748 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8748 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8749 : List Nat := [2,4,3,0,1,0,3,4,1,4,2048,2049,3,1,1,2,2049,1,2052,1,0,1,2048,3,2,2049,1,2049,2048,2049,5,1,2052,0,2048,1]

theorem envBound8749 : H12AffineFastState.Bounded env8749 := by
  intro p hp
  have h : env8749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8748_8749 : H12AffineEnvironment.transform 2 3 env8748 = env8749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8748 == env8749) = true)

theorem identity8749 : scanCanonicalize (H12AffineFastState.compose env8749 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound8749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8750 : List Nat := [2,4,3,0,1,0,3,4,1,4,0,1,3,1,1,2,1,1,4,1,0,1,0,3,2,1,1,1,0,1,5,1,4,0,0,1]

theorem envBound8750 : H12AffineFastState.Bounded env8750 := by
  intro p hp
  have h : env8750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8749_8750 : H12AffineEnvironment.transform 10 0 env8749 = env8750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8749 == env8750) = true)

def leafEnv8750 : List Nat := [2,4,3,0,1,0,3,4,1,4,0,1,3,1,1,2,1,1,4,1,0,1,0,3,5,2,1,1,1,1,0,1,5,1,4,0,4,2,0,1,1,0,0]

def active8750 : List Nat := [0,1]

def tree8750 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8750 : H12WitnessSearch.Good tree8750 := H12GlobalWitnessIndex.good

theorem leafIdentity8750 : H12AffineFastState.composeSystem env8750 rootObs = leafEnv8750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8750 rootObs == leafEnv8750) = true)

theorem terminalChecked8750 : H12PackedTerminal.terminalCheckFast leafEnv8750 active8750 tree8750 = true := by decide +kernel

def env8751 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8234,4605,815,4961,8692,64,4194304,5004,34,8329,4824,934,4198433,4198877,2081,504,4194676,4961,1,4825,1021]

theorem envBound8751 : H12AffineFastState.Bounded env8751 := by
  intro p hp
  have h : env8751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8730_8751 : H12AffineEnvironment.transform 13 233 env8730 = env8751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8730 == env8751) = true)

theorem identity8751 : scanCanonicalize (H12AffineFastState.compose env8751 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8751 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8752 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,4096,8192,233,8352,8234,4265,635,4661,8352,64,4194304,4824,34,8329,4824,754,4198433,4198537,2081,172,4194336,4661,1,4825,681]

theorem envBound8752 : H12AffineFastState.Bounded env8752 := by
  intro p hp
  have h : env8752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8751_8752 : H12AffineEnvironment.transform 7 84 env8751 = env8752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8751 == env8752) = true)

theorem identity8752 : scanCanonicalize (H12AffineFastState.compose env8752 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound8752 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8753 : List Nat := [2,4,8,16,32,64,128,84,512,84,2048,2195,8192,233,8352,8234,2106,635,2726,8352,64,4194304,2635,34,8329,2635,754,4196530,4196378,2081,172,4194336,2726,1,2634,681]

theorem envBound8753 : H12AffineFastState.Bounded env8753 := by
  intro p hp
  have h : env8753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8752_8753 : H12AffineEnvironment.transform 11 2195 env8752 = env8753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env8752 == env8753) = true)

theorem identity8753 : scanCanonicalize (H12AffineFastState.compose env8753 (packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound8753 : packedSelected [3,4,7,9,10,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env8754 : List Nat := [2,4,8,16,32,64,128,84,512,84,603,712,8192,233,8352,8234,609,635,253,8352,64,4194304,16,34,8329,16,754,4195049,4194881,634,172,4194336,253,1,17,681]

theorem envBound8754 : H12AffineFastState.Bounded env8754 := by
  intro p hp
  have h : env8754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8753_8754 : H12AffineEnvironment.transform 10 603 env8753 = env8754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env8753 == env8754) = true)

theorem identity8754 : scanCanonicalize (H12AffineFastState.compose env8754 (packedSelected [13,15,17,38] rootPS)) = affineNative (2^(21+1) ^^^ 216) := by decide +kernel

theorem selectedBound8754 : packedSelected [13,15,17,38] rootPS < 2^1333 := by decide +kernel

def env8755 : List Nat := [2,4,8,16,32,64,128,84,512,84,603,712,8192,233,8352,8234,609,635,253,8352,64,216,16,34,8329,16,754,561,665,634,172,248,253,1,17,681]

theorem envBound8755 : H12AffineFastState.Bounded env8755 := by
  intro p hp
  have h : env8755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8754_8755 : H12AffineEnvironment.transform 21 216 env8754 = env8755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 216 env8754 == env8755) = true)

theorem identity8755 : scanCanonicalize (H12AffineFastState.compose env8755 (packedSelected [10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 627) := by decide +kernel

theorem selectedBound8755 : packedSelected [10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env8756 : List Nat := [2,4,8,16,32,64,128,84,512,84,603,712,627,233,723,601,609,635,253,723,64,216,16,34,762,16,754,561,665,634,172,248,253,1,17,681]

theorem envBound8756 : H12AffineFastState.Bounded env8756 := by
  intro p hp
  have h : env8756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8755_8756 : H12AffineEnvironment.transform 12 627 env8755 = env8756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 627 env8755 == env8756) = true)

theorem identity8756 : scanCanonicalize (H12AffineFastState.compose env8756 (packedSelected [1,5,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8756 : packedSelected [1,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env8757 : List Nat := [2,4,8,16,32,11,128,31,512,31,528,643,568,162,664,530,554,560,182,664,11,147,16,34,689,16,697,561,665,561,172,179,182,1,17,681]

theorem envBound8757 : H12AffineFastState.Bounded env8757 := by
  intro p hp
  have h : env8757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8756_8757 : H12AffineEnvironment.transform 5 11 env8756 = env8757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8756 == env8757) = true)

theorem identity8757 : scanCanonicalize (H12AffineFastState.compose env8757 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound8757 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8758 : List Nat := [2,4,8,16,32,11,3,31,512,31,528,512,568,33,539,530,554,560,53,539,11,16,16,34,562,16,570,561,538,561,47,48,53,1,17,554]

theorem envBound8758 : H12AffineFastState.Bounded env8758 := by
  intro p hp
  have h : env8758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8757_8758 : H12AffineEnvironment.transform 6 3 env8757 = env8758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env8757 == env8758) = true)

theorem identity8758 : scanCanonicalize (H12AffineFastState.compose env8758 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound8758 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env8759 : List Nat := [2,4,8,16,32,11,3,31,10,31,26,10,50,33,17,24,32,58,53,17,11,16,16,34,56,16,48,59,16,59,47,48,53,1,17,32]

theorem envBound8759 : H12AffineFastState.Bounded env8759 := by
  intro p hp
  have h : env8759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8758_8759 : H12AffineEnvironment.transform 8 10 env8758 = env8759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env8758 == env8759) = true)

theorem identity8759 : scanCanonicalize (H12AffineFastState.compose env8759 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8759 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8760 : List Nat := [2,4,8,0,32,11,3,15,10,15,10,10,34,33,1,8,32,42,37,1,11,0,0,34,40,0,32,43,0,43,47,32,37,1,1,32]

theorem envBound8760 : H12AffineFastState.Bounded env8760 := by
  intro p hp
  have h : env8760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8759_8760 : H12AffineEnvironment.transform 3 0 env8759 = env8760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8759 == env8760) = true)

theorem identity8760 : scanCanonicalize (H12AffineFastState.compose env8760 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8760 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8761 : List Nat := [2,4,2,0,32,1,3,5,0,5,0,0,34,33,1,2,32,32,37,1,1,0,0,34,34,0,32,33,0,33,37,32,37,1,1,32]

theorem envBound8761 : H12AffineFastState.Bounded env8761 := by
  intro p hp
  have h : env8761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8760_8761 : H12AffineEnvironment.transform 2 2 env8760 = env8761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8760 == env8761) = true)

theorem identity8761 : scanCanonicalize (H12AffineFastState.compose env8761 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8762 : List Nat := [2,4,2,0,0,1,3,5,0,5,0,0,2,1,1,2,0,0,5,1,1,0,0,2,2,0,0,1,0,1,5,0,5,1,1,0]

theorem envBound8762 : H12AffineFastState.Bounded env8762 := by
  intro p hp
  have h : env8762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8761_8762 : H12AffineEnvironment.transform 4 0 env8761 = env8762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8761 == env8762) = true)

def leafEnv8762 : List Nat := [2,4,2,0,0,1,3,5,0,5,0,0,2,1,1,2,0,0,5,1,1,0,0,2,5,2,1,0,0,1,0,1,5,0,5,1,4,3,1,0,1,0,0]

def active8762 : List Nat := [0,1]

def tree8762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8762 : H12WitnessSearch.Good tree8762 := H12GlobalWitnessIndex.good

theorem leafIdentity8762 : H12AffineFastState.composeSystem env8762 rootObs = leafEnv8762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8762 rootObs == leafEnv8762) = true)

theorem terminalChecked8762 : H12PackedTerminal.terminalCheckFast leafEnv8762 active8762 tree8762 = true := by decide +kernel

def env8763 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,262144,4961,8692,65,4194304,5004,34,8329,21041,278624,4214984,4215092,18632,504,4211101,4961,16616,21041,1021]

theorem envBound8763 : H12AffineFastState.Bounded env8763 := by
  intro p hp
  have h : env8763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8728_8763 : H12AffineEnvironment.transform 20 65 env8728 = env8763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8728 == env8763) = true)

theorem identity8763 : scanCanonicalize (H12AffineFastState.compose env8763 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20903) := by decide +kernel

theorem selectedBound8763 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8764 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24771,4605,20903,4961,8692,65,4194304,5004,34,8329,21041,4551,4214984,4215092,18632,504,4211101,4961,16616,21041,1021]

theorem envBound8764 : H12AffineFastState.Bounded env8764 := by
  intro p hp
  have h : env8764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8763_8764 : H12AffineEnvironment.transform 17 20903 env8763 = env8764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20903 env8763 == env8764) = true)

def env8765 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8235,4605,4431,4961,8692,65,4194304,5004,34,8329,4825,4551,4198432,4198876,2080,504,4194677,4961,0,4825,1021]

theorem envBound8765 : H12AffineFastState.Bounded env8765 := by
  intro p hp
  have h : env8765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8764_8765 : H12AffineEnvironment.transform 13 232 env8764 = env8765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 232 env8764 == env8765) = true)

theorem identity8765 : scanCanonicalize (H12AffineFastState.compose env8765 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8765 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8766 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,232,8692,8235,4605,4431,4961,8692,65,476,5004,34,8329,4825,4551,4604,4096,2080,504,169,4961,0,4825,1021]

theorem envBound8766 : H12AffineFastState.Bounded env8766 := by
  intro p hp
  have h : env8766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8765_8766 : H12AffineEnvironment.transform 21 476 env8765 = env8766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8765 == env8766) = true)

theorem identity8766 : scanCanonicalize (H12AffineFastState.compose env8766 (packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8766 : packedSelected [1,3,4,7,9,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env8767 : List Nat := [2,4,8,16,32,17,128,256,512,256,2048,4096,8192,185,8613,8235,4524,4382,4912,8613,16,397,5004,34,8329,4744,4502,4525,4096,2080,425,169,4912,0,4744,940]

theorem envBound8767 : H12AffineFastState.Bounded env8767 := by
  intro p hp
  have h : env8767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8766_8767 : H12AffineEnvironment.transform 5 17 env8766 = env8767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8766 == env8767) = true)

theorem identity8767 : scanCanonicalize (H12AffineFastState.compose env8767 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound8767 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env8768 : List Nat := [2,4,8,16,32,17,128,256,512,256,934,4096,8192,185,8613,8235,4524,4382,4912,8613,16,397,5004,34,8329,4744,4502,4525,4096,902,425,169,4912,0,4744,940]

theorem envBound8768 : H12AffineFastState.Bounded env8768 := by
  intro p hp
  have h : env8768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8767_8768 : H12AffineEnvironment.transform 10 934 env8767 = env8768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env8767 == env8768) = true)

theorem identity8768 : scanCanonicalize (H12AffineFastState.compose env8768 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound8768 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8769 : List Nat := [2,4,8,16,32,17,128,256,512,256,934,820,8192,185,8613,8235,664,554,4,8613,16,397,184,34,8329,444,674,665,820,902,425,169,4,0,444,940]

theorem envBound8769 : H12AffineFastState.Bounded env8769 := by
  intro p hp
  have h : env8769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8768_8769 : H12AffineEnvironment.transform 11 820 env8768 = env8769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env8768 == env8769) = true)

theorem identity8769 : scanCanonicalize (H12AffineFastState.compose env8769 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8769 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env8770 : List Nat := [2,4,8,16,32,17,128,36,512,36,642,528,8192,185,8321,8235,664,554,4,8321,16,169,184,34,8329,152,674,665,528,674,141,169,4,0,152,648]

theorem envBound8770 : H12AffineFastState.Bounded env8770 := by
  intro p hp
  have h : env8770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8769_8770 : H12AffineEnvironment.transform 7 36 env8769 = env8770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8769 == env8770) = true)

theorem identity8770 : scanCanonicalize (H12AffineFastState.compose env8770 (packedSelected [3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound8770 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env8771 : List Nat := [2,4,8,16,32,17,128,36,512,36,642,528,128,185,1,171,664,554,4,1,16,169,184,34,9,152,674,665,528,674,141,169,4,0,152,648]

theorem envBound8771 : H12AffineFastState.Bounded env8771 := by
  intro p hp
  have h : env8771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8770_8771 : H12AffineEnvironment.transform 12 128 env8770 = env8771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env8770 == env8771) = true)

theorem identity8771 : scanCanonicalize (H12AffineFastState.compose env8771 (packedSelected [7,11] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound8771 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env8772 : List Nat := [2,4,8,16,32,17,50,36,512,36,560,528,50,11,1,25,554,554,4,1,16,27,10,34,9,42,528,555,528,528,63,27,4,0,42,570]

theorem envBound8772 : H12AffineFastState.Bounded env8772 := by
  intro p hp
  have h : env8772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8771_8772 : H12AffineEnvironment.transform 6 50 env8771 = env8772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env8771 == env8772) = true)

theorem identity8772 : scanCanonicalize (H12AffineFastState.compose env8772 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound8772 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8773 : List Nat := [2,4,8,16,32,17,50,36,17,36,33,1,50,11,1,25,59,59,4,1,16,27,10,34,9,42,1,58,1,1,63,27,4,0,42,43]

theorem envBound8773 : H12AffineFastState.Bounded env8773 := by
  intro p hp
  have h : env8773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8772_8773 : H12AffineEnvironment.transform 8 17 env8772 = env8773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env8772 == env8773) = true)

theorem identity8773 : scanCanonicalize (H12AffineFastState.compose env8773 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8773 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env8774 : List Nat := [2,4,8,16,26,17,8,30,17,30,27,1,8,11,1,25,1,1,4,1,16,27,10,24,9,16,1,0,1,1,5,27,4,0,16,17]

theorem envBound8774 : H12AffineFastState.Bounded env8774 := by
  intro p hp
  have h : env8774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8773_8774 : H12AffineEnvironment.transform 4 26 env8773 = env8774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8773 == env8774) = true)

theorem identity8774 : scanCanonicalize (H12AffineFastState.compose env8774 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8775 : List Nat := [2,4,8,1,11,0,8,15,0,15,10,1,8,11,1,8,1,1,4,1,1,10,10,9,9,1,1,0,1,1,5,10,4,0,1,0]

theorem envBound8775 : H12AffineFastState.Bounded env8775 := by
  intro p hp
  have h : env8775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8774_8775 : H12AffineEnvironment.transform 3 1 env8774 = env8775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8774 == env8775) = true)

def env8776 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,233,8692,8234,4605,4430,4961,8692,65,4194304,5004,34,8329,4824,4551,4198433,4198877,2081,504,4194676,4961,1,4824,1021]

theorem envBound8776 : H12AffineFastState.Bounded env8776 := by
  intro p hp
  have h : env8776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8764_8776 : H12AffineEnvironment.transform 13 233 env8764 = env8776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 233 env8764 == env8776) = true)

theorem identity8776 : scanCanonicalize (H12AffineFastState.compose env8776 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8776 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8777 : List Nat := [2,4,8,16,32,64,128,85,512,85,2048,4096,8192,233,8353,8234,4264,4123,4660,8353,65,4194304,4825,34,8329,4824,4242,4198433,4198536,2081,173,4194337,4660,1,4824,680]

theorem envBound8777 : H12AffineFastState.Bounded env8777 := by
  intro p hp
  have h : env8777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8776_8777 : H12AffineEnvironment.transform 7 85 env8776 = env8777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8776 == env8777) = true)

theorem identity8777 : scanCanonicalize (H12AffineFastState.compose env8777 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound8777 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env8778 : List Nat := [2,4,8,16,32,64,128,85,512,85,674,4096,8192,233,8353,8234,4264,4123,4660,8353,65,4194304,4825,34,8329,4824,4242,4198433,4198536,643,173,4194337,4660,1,4824,680]

theorem envBound8778 : H12AffineFastState.Bounded env8778 := by
  intro p hp
  have h : env8778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8777_8778 : H12AffineEnvironment.transform 10 674 env8777 = env8778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env8777 == env8778) = true)

theorem identity8778 : scanCanonicalize (H12AffineFastState.compose env8778 (packedSelected [1,3,4,7,9,12,14,15,27] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound8778 : packedSelected [1,3,4,7,9,12,14,15,27] rootPS < 2^1333 := by decide +kernel

def env8779 : List Nat := [2,4,8,16,32,64,128,85,512,85,674,4096,8192,233,8353,8234,4264,4123,4660,8353,65,112,4825,34,8329,4824,4242,4177,4344,643,173,81,4660,1,4824,680]

theorem envBound8779 : H12AffineFastState.Bounded env8779 := by
  intro p hp
  have h : env8779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8778_8779 : H12AffineEnvironment.transform 21 112 env8778 = env8779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env8778 == env8779) = true)

theorem identity8779 : scanCanonicalize (H12AffineFastState.compose env8779 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8779 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env8780 : List Nat := [2,4,8,16,32,64,40,85,512,85,522,4096,8192,65,8201,8234,4096,4123,4660,8201,65,112,4721,34,8225,4720,4154,4177,4176,555,5,81,4660,1,4720,512]

theorem envBound8780 : H12AffineFastState.Bounded env8780 := by
  intro p hp
  have h : env8780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8779_8780 : H12AffineEnvironment.transform 6 40 env8779 = env8780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8779 == env8780) = true)

theorem identity8780 : scanCanonicalize (H12AffineFastState.compose env8780 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 522) := by decide +kernel

theorem selectedBound8780 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8781 : List Nat := [2,4,8,16,32,64,40,85,512,85,522,522,8192,65,8201,8234,522,529,62,8201,65,112,123,34,8225,122,560,603,602,555,5,81,62,1,122,512]

theorem envBound8781 : H12AffineFastState.Bounded env8781 := by
  intro p hp
  have h : env8781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8780_8781 : H12AffineEnvironment.transform 11 522 env8780 = env8781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 522 env8780 == env8781) = true)

theorem identity8781 : scanCanonicalize (H12AffineFastState.compose env8781 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound8781 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8782 : List Nat := [2,4,8,16,32,64,40,85,27,85,17,17,8192,65,8201,8234,17,10,62,8201,65,112,123,34,8225,122,43,64,65,48,5,81,62,1,122,27]

theorem envBound8782 : H12AffineFastState.Bounded env8782 := by
  intro p hp
  have h : env8782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8781_8782 : H12AffineEnvironment.transform 8 27 env8781 = env8782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env8781 == env8782) = true)

theorem identity8782 : scanCanonicalize (H12AffineFastState.compose env8782 (packedSelected [0,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8782 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env8783 : List Nat := [2,4,8,16,32,17,40,4,27,4,17,17,8192,16,8201,8234,17,10,62,8201,16,33,42,34,8225,43,43,17,16,48,5,0,62,1,43,27]

theorem envBound8783 : H12AffineFastState.Bounded env8783 := by
  intro p hp
  have h : env8783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8782_8783 : H12AffineEnvironment.transform 5 17 env8782 = env8783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8782 == env8783) = true)

theorem identity8783 : scanCanonicalize (H12AffineFastState.compose env8783 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8784 : List Nat := [2,4,8,16,17,17,25,4,27,4,17,17,8192,16,8201,8219,17,10,15,8201,16,16,27,19,8208,26,26,17,16,1,5,0,15,1,26,27]

theorem envBound8784 : H12AffineFastState.Bounded env8784 := by
  intro p hp
  have h : env8784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8783_8784 : H12AffineEnvironment.transform 4 17 env8783 = env8784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8783 == env8784) = true)

theorem identity8784 : scanCanonicalize (H12AffineFastState.compose env8784 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8784 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8785 : List Nat := [2,4,2,16,17,17,19,4,17,4,17,17,8192,16,8195,8209,17,0,5,8195,16,16,17,19,8208,16,16,17,16,1,5,0,5,1,16,17]

theorem envBound8785 : H12AffineFastState.Bounded env8785 := by
  intro p hp
  have h : env8785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8784_8785 : H12AffineEnvironment.transform 2 2 env8784 = env8785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8784 == env8785) = true)

theorem identity8785 : scanCanonicalize (H12AffineFastState.compose env8785 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound8785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8786 : List Nat := [2,4,2,16,17,17,19,4,17,4,17,17,2,16,1,19,17,0,5,1,16,16,17,19,18,16,16,17,16,1,5,0,5,1,16,17]

theorem envBound8786 : H12AffineFastState.Bounded env8786 := by
  intro p hp
  have h : env8786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8785_8786 : H12AffineEnvironment.transform 12 2 env8785 = env8786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env8785 == env8786) = true)

theorem identity8786 : scanCanonicalize (H12AffineFastState.compose env8786 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8786 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8787 : List Nat := [2,4,2,0,1,1,3,4,1,4,1,1,2,0,1,3,1,0,5,1,0,0,1,3,2,0,0,1,0,1,5,0,5,1,0,1]

theorem envBound8787 : H12AffineFastState.Bounded env8787 := by
  intro p hp
  have h : env8787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8786_8787 : H12AffineEnvironment.transform 3 0 env8786 = env8787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8786 == env8787) = true)

def env8788 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855761,134217728,138678440,138678612,151259274,529048,155451871,524289,151257258,153358899,16778207]

theorem envBound8788 : H12AffineFastState.Bounded env8788 := by
  intro p hp
  have h : env8788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8146_8788 : H12AffineEnvironment.transform 9 257 env8146 = env8788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env8146 == env8788) = true)

def env8789 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,16777216,8329,16855761,807680,4735912,4735572,17324938,529048,21517023,524289,17322922,19415347,16778207]

theorem envBound8789 : H12AffineFastState.Bounded env8789 := by
  intro p hp
  have h : env8789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8788_8789 : H12AffineEnvironment.transform 26 807680 env8788 = env8789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807680 env8788 == env8789) = true)

def env8790 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524524,90336,8329,21041,807680,4735912,4735572,605034,529048,4796991,524289,602954,2695635,90943]

theorem envBound8790 : H12AffineFastState.Bounded env8790 := by
  intro p hp
  have h : env8790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8789_8790 : H12AffineEnvironment.transform 23 90336 env8789 = env8790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8789 == env8790) = true)

def env8791 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5004,90336,8329,21041,278624,4214984,4215092,75786,504,4268383,4961,73770,2175667,90943]

theorem envBound8791 : H12AffineFastState.Bounded env8791 := by
  intro p hp
  have h : env8791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8790_8791 : H12AffineEnvironment.transform 18 4960 env8790 = env8791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8790 == env8791) = true)

theorem identity8791 : scanCanonicalize (H12AffineFastState.compose env8791 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8791 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8792 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,2097152,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4764,73770,2175667,90818]

theorem envBound8792 : H12AffineFastState.Bounded env8792 := by
  intro p hp
  have h : env8792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8791_8792 : H12AffineEnvironment.transform 7 253 env8791 = env8792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8791 == env8792) = true)

def env8793 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4764,73770,78579,90818]

theorem envBound8793 : H12AffineFastState.Bounded env8793 := by
  intro p hp
  have h : env8793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8792_8793 : H12AffineEnvironment.transform 20 64 env8792 = env8793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8792 == env8793) = true)

theorem identity8793 : scanCanonicalize (H12AffineFastState.compose env8793 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 20642) := by decide +kernel

theorem selectedBound8793 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8794 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,20642,4765,8201,64,4194304,4721,90336,8329,21041,4290,4214984,4214985,75786,5,4268194,4764,73770,78579,90818]

theorem envBound8794 : H12AffineFastState.Bounded env8794 := by
  intro p hp
  have h : env8794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8793_8794 : H12AffineEnvironment.transform 17 20642 env8793 = env8794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20642 env8793 == env8794) = true)

def env8795 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,20642,4765,8201,64,16960,4721,90336,8329,21041,4290,4744,4745,75786,5,90850,4764,73770,78579,90818]

theorem envBound8795 : H12AffineFastState.Bounded env8795 := by
  intro p hp
  have h : env8795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8794_8795 : H12AffineEnvironment.transform 21 16960 env8794 = env8795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8794 == env8795) = true)

def env8796 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,4754,4765,8201,64,112,4721,74448,8329,4097,4290,4744,4745,75786,5,73938,4764,73770,78579,73970]

theorem envBound8796 : H12AffineFastState.Bounded env8796 := by
  intro p hp
  have h : env8796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8795_8796 : H12AffineEnvironment.transform 13 560 env8795 = env8796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8795 == env8796) = true)

theorem identity8796 : scanCanonicalize (H12AffineFastState.compose env8796 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8796 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8797 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,184,8192,560,8201,65536,184,554,549,8201,64,112,713,74448,8329,185,122,560,561,75786,5,73938,548,73770,74315,73970]

theorem envBound8797 : H12AffineFastState.Bounded env8797 := by
  intro p hp
  have h : env8797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8796_8797 : H12AffineEnvironment.transform 11 184 env8796 = env8797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8796 == env8797) = true)

theorem identity8797 : scanCanonicalize (H12AffineFastState.compose env8797 (packedSelected [13,14,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8797 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env8798 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,184,8192,560,8201,8323,184,554,549,8201,64,112,713,595,8329,185,122,560,561,2185,5,81,548,169,712,113]

theorem envBound8798 : H12AffineFastState.Bounded env8798 := by
  intro p hp
  have h : env8798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8797_8798 : H12AffineEnvironment.transform 15 8323 env8797 = env8798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8797 == env8798) = true)

theorem identity8798 : scanCanonicalize (H12AffineFastState.compose env8798 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound8798 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8799 : List Nat := [2,4,8,16,32,64,128,253,512,252,131,184,8192,560,8201,8323,184,554,549,8201,64,112,713,595,8329,185,122,560,561,10,5,81,548,169,712,113]

theorem envBound8799 : H12AffineFastState.Bounded env8799 := by
  intro p hp
  have h : env8799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8798_8799 : H12AffineEnvironment.transform 10 131 env8798 = env8799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env8798 == env8799) = true)

theorem identity8799 : scanCanonicalize (H12AffineFastState.compose env8799 (packedSelected [4,5,8,9,11,12,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound8799 : packedSelected [4,5,8,9,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env8800 : List Nat := [2,4,8,16,32,64,128,253,162,252,131,184,8192,146,8201,8323,184,136,135,8201,64,112,107,241,8329,185,122,146,147,10,5,81,134,169,106,113]

theorem envBound8800 : H12AffineFastState.Bounded env8800 := by
  intro p hp
  have h : env8800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8799_8800 : H12AffineEnvironment.transform 8 162 env8799 = env8800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env8799 == env8800) = true)

theorem identity8800 : scanCanonicalize (H12AffineFastState.compose env8800 (packedSelected [2,3,4,7,8,11,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 67) := by decide +kernel

theorem selectedBound8800 : packedSelected [2,3,4,7,8,11,13,14] rootPS < 2^1333 := by decide +kernel

def env8801 : List Nat := [2,4,8,16,32,64,128,253,162,252,131,184,67,146,74,192,184,136,135,74,64,112,107,241,202,185,122,146,147,10,5,81,134,169,106,113]

theorem envBound8801 : H12AffineFastState.Bounded env8801 := by
  intro p hp
  have h : env8801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8800_8801 : H12AffineEnvironment.transform 12 67 env8800 = env8801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 67 env8800 == env8801) = true)

theorem identity8801 : scanCanonicalize (H12AffineFastState.compose env8801 (packedSelected [0,1,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound8801 : packedSelected [0,1,8,9] rootPS < 2^1333 := by decide +kernel

def env8802 : List Nat := [2,4,8,16,32,64,34,95,0,94,33,26,67,48,74,98,26,42,37,74,64,112,107,83,104,27,122,48,49,10,5,81,36,11,106,113]

theorem envBound8802 : H12AffineFastState.Bounded env8802 := by
  intro p hp
  have h : env8802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8801_8802 : H12AffineEnvironment.transform 6 34 env8801 = env8802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env8801 == env8802) = true)

theorem identity8802 : scanCanonicalize (H12AffineFastState.compose env8802 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8802 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8803 : List Nat := [2,4,8,16,0,64,2,95,0,94,1,26,67,16,74,66,26,10,5,74,64,80,75,83,72,27,90,16,17,10,5,81,4,11,74,81]

theorem envBound8803 : H12AffineFastState.Bounded env8803 := by
  intro p hp
  have h : env8803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8802_8803 : H12AffineEnvironment.transform 4 0 env8802 = env8803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8802 == env8803) = true)

theorem identity8803 : scanCanonicalize (H12AffineFastState.compose env8803 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8803 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env8804 : List Nat := [2,4,8,16,0,10,2,21,0,20,1,26,9,16,0,8,26,10,5,0,10,26,1,25,2,27,16,16,17,10,5,27,4,11,0,27]

theorem envBound8804 : H12AffineFastState.Bounded env8804 := by
  intro p hp
  have h : env8804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8803_8804 : H12AffineEnvironment.transform 5 10 env8803 = env8804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8803 == env8804) = true)

theorem identity8804 : scanCanonicalize (H12AffineFastState.compose env8804 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8804 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8805 : List Nat := [2,4,8,1,0,10,2,4,0,5,1,11,9,1,0,8,11,10,5,0,10,11,1,8,2,10,1,1,0,10,5,10,4,11,0,10]

theorem envBound8805 : H12AffineFastState.Bounded env8805 := by
  intro p hp
  have h : env8805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8804_8805 : H12AffineEnvironment.transform 3 1 env8804 = env8805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8804 == env8805) = true)

theorem identity8805 : scanCanonicalize (H12AffineFastState.compose env8805 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8806 : List Nat := [2,4,2,1,0,0,2,4,0,5,1,1,3,1,0,2,1,0,5,0,0,1,1,2,2,0,1,1,0,0,5,0,4,1,0,0]

theorem envBound8806 : H12AffineFastState.Bounded env8806 := by
  intro p hp
  have h : env8806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8805_8806 : H12AffineEnvironment.transform 2 2 env8805 = env8806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8805 == env8806) = true)

def env8807 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,4755,4765,8201,64,113,4721,74449,8329,4096,4290,4744,4745,75786,5,73939,4764,73770,78579,73971]

theorem envBound8807 : H12AffineFastState.Bounded env8807 := by
  intro p hp
  have h : env8807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8795_8807 : H12AffineEnvironment.transform 13 561 env8795 = env8807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8795 == env8807) = true)

theorem identity8807 : scanCanonicalize (H12AffineFastState.compose env8807 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound8807 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8808 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,65,8192,561,8201,65536,65,722,732,8201,64,113,560,74449,8329,65,131,713,712,75786,5,73939,733,73770,74418,73971]

theorem envBound8808 : H12AffineFastState.Bounded env8808 := by
  intro p hp
  have h : env8808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8807_8808 : H12AffineEnvironment.transform 11 65 env8807 = env8808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env8807 == env8808) = true)

theorem identity8808 : scanCanonicalize (H12AffineFastState.compose env8808 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound8808 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env8809 : List Nat := [2,4,8,16,32,64,128,253,512,252,122,65,8192,561,8201,65536,65,722,732,8201,64,113,560,74449,8329,65,131,713,712,73840,5,73939,733,73770,74418,73971]

theorem envBound8809 : H12AffineFastState.Bounded env8809 := by
  intro p hp
  have h : env8809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8808_8809 : H12AffineEnvironment.transform 10 122 env8808 = env8809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env8808 == env8809) = true)

theorem identity8809 : scanCanonicalize (H12AffineFastState.compose env8809 (packedSelected [1,3,4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8809 : packedSelected [1,3,4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8810 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,8192,561,8201,65536,16,643,653,8201,17,32,560,74368,8329,16,131,664,665,73761,5,73858,652,73770,74418,73890]

theorem envBound8810 : H12AffineFastState.Bounded env8810 := by
  intro p hp
  have h : env8810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8809_8810 : H12AffineEnvironment.transform 5 17 env8809 = env8810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8809 == env8810) = true)

theorem identity8810 : scanCanonicalize (H12AffineFastState.compose env8810 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8810 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8811 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,8192,561,8201,8715,16,643,653,8201,17,32,560,139,8329,16,131,664,665,554,5,649,652,545,185,681]

theorem envBound8811 : H12AffineFastState.Bounded env8811 := by
  intro p hp
  have h : env8811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8810_8811 : H12AffineEnvironment.transform 15 8715 env8810 = env8811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8810 == env8811) = true)

theorem identity8811 : scanCanonicalize (H12AffineFastState.compose env8811 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound8811 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env8812 : List Nat := [2,4,8,16,32,17,128,172,512,173,43,16,656,561,665,155,16,643,653,665,17,32,560,139,537,16,131,664,665,554,5,649,652,545,185,681]

theorem envBound8812 : H12AffineFastState.Bounded env8812 := by
  intro p hp
  have h : env8812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8811_8812 : H12AffineEnvironment.transform 12 656 env8811 = env8812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env8811 == env8812) = true)

theorem identity8812 : scanCanonicalize (H12AffineFastState.compose env8812 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8812 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8813 : List Nat := [2,4,8,16,32,17,128,172,33,173,43,16,177,16,184,155,16,162,172,184,17,32,17,139,56,16,131,185,184,11,5,168,173,0,185,136]

theorem envBound8813 : H12AffineFastState.Bounded env8813 := by
  intro p hp
  have h : env8813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8812_8813 : H12AffineEnvironment.transform 8 33 env8812 = env8813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8812 == env8813) = true)

theorem identity8813 : scanCanonicalize (H12AffineFastState.compose env8813 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8813 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8814 : List Nat := [2,4,8,16,32,17,18,62,33,63,43,16,35,16,42,9,16,48,62,42,17,32,17,25,56,16,17,43,42,11,5,58,63,0,43,26]

theorem envBound8814 : H12AffineFastState.Bounded env8814 := by
  intro p hp
  have h : env8814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8813_8814 : H12AffineEnvironment.transform 6 18 env8813 = env8814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8813 == env8814) = true)

theorem identity8814 : scanCanonicalize (H12AffineFastState.compose env8814 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8814 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8815 : List Nat := [2,4,8,16,17,17,18,15,16,14,26,16,18,16,27,9,16,1,15,27,17,17,17,25,9,16,17,26,27,11,5,11,14,0,26,26]

theorem envBound8815 : H12AffineFastState.Bounded env8815 := by
  intro p hp
  have h : env8815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8814_8815 : H12AffineEnvironment.transform 4 17 env8814 = env8815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8814 == env8815) = true)

theorem identity8815 : scanCanonicalize (H12AffineFastState.compose env8815 (packedSelected [0,1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8815 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env8816 : List Nat := [2,4,8,0,1,1,2,15,0,14,10,0,2,0,11,9,0,1,15,11,1,1,1,9,9,0,1,10,11,11,5,11,14,0,10,10]

theorem envBound8816 : H12AffineFastState.Bounded env8816 := by
  intro p hp
  have h : env8816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8815_8816 : H12AffineEnvironment.transform 3 0 env8815 = env8816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8815 == env8816) = true)

theorem identity8816 : scanCanonicalize (H12AffineFastState.compose env8816 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8817 : List Nat := [2,4,2,0,1,1,2,5,0,4,0,0,2,0,1,3,0,1,5,1,1,1,1,3,3,0,1,0,1,1,5,1,4,0,0,0]

theorem envBound8817 : H12AffineFastState.Bounded env8817 := by
  intro p hp
  have h : env8817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8816_8817 : H12AffineEnvironment.transform 2 2 env8816 = env8817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8816 == env8817) = true)

def env8818 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,20642,4765,8201,64,16961,4721,90336,8329,21041,4290,4745,4744,75786,5,90851,4764,73770,78579,90818]

theorem envBound8818 : H12AffineFastState.Bounded env8818 := by
  intro p hp
  have h : env8818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8794_8818 : H12AffineEnvironment.transform 21 16961 env8794 = env8818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8794 == env8818) = true)

def env8819 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,65536,4096,4754,4765,8201,64,113,4721,74448,8329,4097,4290,4745,4744,75786,5,73939,4764,73770,78579,73970]

theorem envBound8819 : H12AffineFastState.Bounded env8819 := by
  intro p hp
  have h : env8819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8818_8819 : H12AffineEnvironment.transform 13 560 env8818 = env8819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8818 == env8819) = true)

theorem identity8819 : scanCanonicalize (H12AffineFastState.compose env8819 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12875) := by decide +kernel

theorem selectedBound8819 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8820 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,560,8201,12875,4096,4754,4765,8201,64,113,4721,4251,8329,4097,4290,4745,4744,6721,5,4760,4764,4705,184,4793]

theorem envBound8820 : H12AffineFastState.Bounded env8820 := by
  intro p hp
  have h : env8820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8819_8820 : H12AffineEnvironment.transform 15 12875 env8819 = env8820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12875 env8819 == env8820) = true)

theorem identity8820 : scanCanonicalize (H12AffineFastState.compose env8820 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound8820 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env8821 : List Nat := [2,4,8,16,32,64,128,253,512,252,211,4096,8192,560,8201,12875,4096,4754,4765,8201,64,113,4721,4251,8329,4097,4290,4745,4744,4754,5,4760,4764,4705,184,4793]

theorem envBound8821 : H12AffineFastState.Bounded env8821 := by
  intro p hp
  have h : env8821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8820_8821 : H12AffineEnvironment.transform 10 211 env8820 = env8821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env8820 == env8821) = true)

theorem identity8821 : scanCanonicalize (H12AffineFastState.compose env8821 (packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 112) := by decide +kernel

theorem selectedBound8821 : packedSelected [0,1,3,4,7,9,12,14,15,17,21] rootPS < 2^1333 := by decide +kernel

def env8822 : List Nat := [2,4,8,16,32,64,128,253,112,252,211,4096,8192,64,8201,12347,4096,4322,4333,8201,64,113,4097,4251,8329,4097,4290,4345,4344,4322,5,4328,4332,4113,184,4297]

theorem envBound8822 : H12AffineFastState.Bounded env8822 := by
  intro p hp
  have h : env8822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8821_8822 : H12AffineEnvironment.transform 8 112 env8821 = env8822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env8821 == env8822) = true)

theorem identity8822 : scanCanonicalize (H12AffineFastState.compose env8822 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8822 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8823 : List Nat := [2,4,8,16,32,16,128,173,32,172,131,4096,8192,16,8201,12347,4096,4274,4285,8201,16,33,4097,4251,8329,4097,4242,4265,4264,4274,5,4280,4284,4113,184,4249]

theorem envBound8823 : H12AffineFastState.Bounded env8823 := by
  intro p hp
  have h : env8823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8822_8823 : H12AffineEnvironment.transform 5 16 env8822 = env8823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8822 == env8823) = true)

theorem identity8823 : scanCanonicalize (H12AffineFastState.compose env8823 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8823 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8824 : List Nat := [2,4,8,11,32,11,128,173,32,172,131,4096,8192,11,8201,12320,4096,4265,4262,8201,11,33,4097,4224,8329,4097,4233,4265,4264,4265,5,4259,4263,4106,163,4226]

theorem envBound8824 : H12AffineFastState.Bounded env8824 := by
  intro p hp
  have h : env8824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8823_8824 : H12AffineEnvironment.transform 3 11 env8823 = env8824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8823 == env8824) = true)

theorem identity8824 : scanCanonicalize (H12AffineFastState.compose env8824 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound8824 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env8825 : List Nat := [2,4,8,11,32,11,128,173,32,172,131,32,8192,11,8201,8192,32,137,134,8201,11,33,33,160,8329,33,169,137,136,137,5,131,135,42,163,162]

theorem envBound8825 : H12AffineFastState.Bounded env8825 := by
  intro p hp
  have h : env8825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8824_8825 : H12AffineEnvironment.transform 11 32 env8824 = env8825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env8824 == env8825) = true)

theorem identity8825 : scanCanonicalize (H12AffineFastState.compose env8825 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound8825 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env8826 : List Nat := [2,4,8,11,32,11,128,173,32,172,131,32,41,11,32,41,32,137,134,32,11,33,33,160,160,33,169,137,136,137,5,131,135,42,163,162]

theorem envBound8826 : H12AffineFastState.Bounded env8826 := by
  intro p hp
  have h : env8826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8825_8826 : H12AffineEnvironment.transform 12 41 env8825 = env8826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env8825 == env8826) = true)

theorem identity8826 : scanCanonicalize (H12AffineFastState.compose env8826 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound8826 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8827 : List Nat := [2,4,8,11,32,11,9,36,32,37,10,32,41,11,32,41,32,0,15,32,11,33,33,41,41,33,32,0,1,0,5,10,14,42,42,43]

theorem envBound8827 : H12AffineFastState.Bounded env8827 := by
  intro p hp
  have h : env8827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8826_8827 : H12AffineEnvironment.transform 6 9 env8826 = env8827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8826 == env8827) = true)

theorem identity8827 : scanCanonicalize (H12AffineFastState.compose env8827 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8827 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8828 : List Nat := [2,4,3,0,32,0,2,36,32,37,1,32,34,0,32,34,32,0,4,32,0,33,33,34,34,33,32,0,1,0,5,1,5,33,33,32]

theorem envBound8828 : H12AffineFastState.Bounded env8828 := by
  intro p hp
  have h : env8828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8827_8828 : H12AffineEnvironment.transform 2 3 env8827 = env8828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8827 == env8828) = true)

def env8829 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,65536,4096,4755,4765,8201,64,112,4721,74449,8329,4096,4290,4745,4744,75786,5,73938,4764,73770,78579,73971]

theorem envBound8829 : H12AffineFastState.Bounded env8829 := by
  intro p hp
  have h : env8829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8818_8829 : H12AffineEnvironment.transform 13 561 env8818 = env8829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8818 == env8829) = true)

theorem identity8829 : scanCanonicalize (H12AffineFastState.compose env8829 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12978) := by decide +kernel

theorem selectedBound8829 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8830 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,561,8201,12978,4096,4755,4765,8201,64,112,4721,4195,8329,4096,4290,4745,4744,6840,5,4704,4764,4760,65,4673]

theorem envBound8830 : H12AffineFastState.Bounded env8830 := by
  intro p hp
  have h : env8830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8829_8830 : H12AffineEnvironment.transform 15 12978 env8829 = env8830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12978 env8829 == env8830) = true)

theorem identity8830 : scanCanonicalize (H12AffineFastState.compose env8830 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8830 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8831 : List Nat := [2,4,8,16,32,64,128,253,32,252,2048,4096,8192,17,8201,12434,4096,4275,4285,8201,64,112,4177,4195,8329,4096,4290,4265,4264,6296,5,4160,4284,4280,65,4193]

theorem envBound8831 : H12AffineFastState.Bounded env8831 := by
  intro p hp
  have h : env8831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8830_8831 : H12AffineEnvironment.transform 8 32 env8830 = env8831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8830 == env8831) = true)

theorem identity8831 : scanCanonicalize (H12AffineFastState.compose env8831 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8831 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8832 : List Nat := [2,4,8,16,32,64,128,253,32,252,2048,2155,8192,17,8201,10489,2155,2264,2262,8201,64,112,2106,2056,8329,2155,2217,2242,2243,243,5,2091,2263,2259,65,2058]

theorem envBound8832 : H12AffineFastState.Bounded env8832 := by
  intro p hp
  have h : env8832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8831_8832 : H12AffineEnvironment.transform 11 2155 env8831 = env8832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8831 == env8832) = true)

theorem identity8832 : scanCanonicalize (H12AffineFastState.compose env8832 (packedSelected [0,1,3,7,12,13,15,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound8832 : packedSelected [0,1,3,7,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env8833 : List Nat := [2,4,8,16,32,64,128,253,32,252,131,232,8192,17,8201,8314,232,91,85,8201,64,112,185,139,8329,232,42,65,64,243,5,168,84,80,65,137]

theorem envBound8833 : H12AffineFastState.Bounded env8833 := by
  intro p hp
  have h : env8833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8832_8833 : H12AffineEnvironment.transform 10 131 env8832 = env8833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env8832 == env8833) = true)

theorem identity8833 : scanCanonicalize (H12AffineFastState.compose env8833 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound8833 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env8834 : List Nat := [2,4,8,16,32,64,128,253,32,252,131,232,138,17,131,240,232,91,85,131,64,112,185,139,3,232,42,65,64,243,5,168,84,80,65,137]

theorem envBound8834 : H12AffineFastState.Bounded env8834 := by
  intro p hp
  have h : env8834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8833_8834 : H12AffineEnvironment.transform 12 138 env8833 = env8834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env8833 == env8834) = true)

theorem identity8834 : scanCanonicalize (H12AffineFastState.compose env8834 (packedSelected [0,1,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8834 : packedSelected [0,1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env8835 : List Nat := [2,4,8,16,1,64,128,220,1,221,131,201,138,17,131,209,201,91,85,131,64,81,152,139,3,201,11,65,64,210,5,137,84,80,65,137]

theorem envBound8835 : H12AffineFastState.Bounded env8835 := by
  intro p hp
  have h : env8835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8834_8835 : H12AffineEnvironment.transform 4 1 env8834 = env8835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8834 == env8835) = true)

theorem identity8835 : scanCanonicalize (H12AffineFastState.compose env8835 (packedSelected [1,2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8835 : packedSelected [1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env8836 : List Nat := [2,4,8,0,1,64,128,204,1,205,131,201,138,1,131,193,201,75,69,131,64,65,136,139,3,201,11,65,64,194,5,137,68,64,65,137]

theorem envBound8836 : H12AffineFastState.Bounded env8836 := by
  intro p hp
  have h : env8836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8835_8836 : H12AffineEnvironment.transform 3 0 env8835 = env8836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8835 == env8836) = true)

theorem identity8836 : scanCanonicalize (H12AffineFastState.compose env8836 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8836 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8837 : List Nat := [2,4,8,0,1,11,128,135,1,134,131,130,138,1,131,138,130,0,14,131,11,10,136,139,3,130,11,10,11,137,5,137,15,11,10,137]

theorem envBound8837 : H12AffineFastState.Bounded env8837 := by
  intro p hp
  have h : env8837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8836_8837 : H12AffineEnvironment.transform 5 11 env8836 = env8837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8836 == env8837) = true)

theorem identity8837 : scanCanonicalize (H12AffineFastState.compose env8837 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8837 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8838 : List Nat := [2,4,2,0,1,1,128,135,1,134,131,130,128,1,131,128,130,0,4,131,1,0,130,129,3,130,1,0,1,131,5,131,5,1,0,131]

theorem envBound8838 : H12AffineFastState.Bounded env8838 := by
  intro p hp
  have h : env8838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8837_8838 : H12AffineEnvironment.transform 2 2 env8837 = env8838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8837 == env8838) = true)

def env8839 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,4194304,4721,90336,8329,21041,278624,4214984,4214985,75786,5,4268194,4764,73770,78578,90818]

theorem envBound8839 : H12AffineFastState.Bounded env8839 := by
  intro p hp
  have h : env8839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8792_8839 : H12AffineEnvironment.transform 20 65 env8792 = env8839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8792 == env8839) = true)

theorem identity8839 : scanCanonicalize (H12AffineFastState.compose env8839 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 17091) := by decide +kernel

theorem selectedBound8839 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8840 : List Nat := [2,4,8,16,32,64,128,253,512,252,2048,4096,8192,16384,8201,65536,4096,17091,4765,8201,65,4194304,4721,90336,8329,21041,675,4214984,4214985,75786,5,4268194,4764,73770,78578,90818]

theorem envBound8840 : H12AffineFastState.Bounded env8840 := by
  intro p hp
  have h : env8840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8839_8840 : H12AffineEnvironment.transform 17 17091 env8839 = env8840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17091 env8839 == env8840) = true)

def env8841 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8201,65536,4096,17019,4645,8201,65,4194304,4721,90200,8241,21041,539,4214896,4214897,75786,5,4268058,4644,73770,78410,90746]

theorem envBound8841 : H12AffineFastState.Bounded env8841 := by
  intro p hp
  have h : env8841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8840_8841 : H12AffineEnvironment.transform 6 56 env8840 = env8841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8840 == env8841) = true)

theorem identity8841 : scanCanonicalize (H12AffineFastState.compose env8841 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8731) := by decide +kernel

theorem selectedBound8841 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8842 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8201,8731,4096,17019,4645,8201,65,4194304,4721,16963,8241,21041,539,4214896,4214897,2577,5,4194817,4644,561,4177,16481]

theorem envBound8842 : H12AffineFastState.Bounded env8842 := by
  intro p hp
  have h : env8842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8841_8842 : H12AffineEnvironment.transform 15 8731 env8841 = env8842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8731 env8841 == env8842) = true)

theorem identity8842 : scanCanonicalize (H12AffineFastState.compose env8842 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 48) := by decide +kernel

theorem selectedBound8842 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env8843 : List Nat := [2,4,8,16,32,64,56,69,512,68,2048,4096,8192,16384,8201,8731,4096,17019,4645,8201,65,48,4721,16963,8241,21041,539,20544,20545,2577,5,561,4644,561,4177,16481]

theorem envBound8843 : H12AffineFastState.Bounded env8843 := by
  intro p hp
  have h : env8843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8842_8843 : H12AffineEnvironment.transform 21 48 env8842 = env8843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 48 env8842 == env8843) = true)

theorem identity8843 : scanCanonicalize (H12AffineFastState.compose env8843 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8843 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8844 : List Nat := [2,4,8,16,32,64,56,69,96,68,2048,4096,8192,16384,8201,8315,4096,16411,4165,8201,65,48,4113,16419,8241,20561,123,20544,20545,2161,5,81,4164,81,4177,16481]

theorem envBound8844 : H12AffineFastState.Bounded env8844 := by
  intro p hp
  have h : env8844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8843_8844 : H12AffineEnvironment.transform 8 96 env8843 = env8844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8843 == env8844) = true)

theorem identity8844 : scanCanonicalize (H12AffineFastState.compose env8844 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8844 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8845 : List Nat := [2,4,8,16,32,64,56,69,96,68,2048,2155,8192,16384,8201,8315,2155,16411,2094,8201,65,48,2170,16419,8241,18490,123,18475,18474,2161,5,81,2095,81,2106,16481]

theorem envBound8845 : H12AffineFastState.Bounded env8845 := by
  intro p hp
  have h : env8845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8844_8845 : H12AffineEnvironment.transform 11 2155 env8844 = env8845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8844 == env8845) = true)

theorem identity8845 : scanCanonicalize (H12AffineFastState.compose env8845 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound8845 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env8846 : List Nat := [2,4,8,16,32,64,56,69,96,68,2048,2155,8192,0,8201,8315,2155,27,2094,8201,65,48,2170,35,8241,2106,123,2091,2090,2161,5,81,2095,81,2106,97]

theorem envBound8846 : H12AffineFastState.Bounded env8846 := by
  intro p hp
  have h : env8846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8845_8846 : H12AffineEnvironment.transform 13 0 env8845 = env8846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env8845 == env8846) = true)

def env8847 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8201,65536,4096,17018,4644,8201,65,4194304,4721,90201,8240,21041,538,4214897,4214896,75786,5,4268059,4645,73770,78411,90747]

theorem envBound8847 : H12AffineFastState.Bounded env8847 := by
  intro p hp
  have h : env8847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8840_8847 : H12AffineEnvironment.transform 6 57 env8840 = env8847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8840 == env8847) = true)

theorem identity8847 : scanCanonicalize (H12AffineFastState.compose env8847 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 16977) := by decide +kernel

theorem selectedBound8847 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8848 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8201,65536,4096,17018,4644,8201,65,16977,4721,90201,8240,21041,538,4640,4641,75786,5,90698,4645,73770,78411,90747]

theorem envBound8848 : H12AffineFastState.Bounded env8848 := by
  intro p hp
  have h : env8848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8847_8848 : H12AffineEnvironment.transform 21 16977 env8847 = env8848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16977 env8847 == env8848) = true)

theorem identity8848 : scanCanonicalize (H12AffineFastState.compose env8848 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8731) := by decide +kernel

theorem selectedBound8848 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env8849 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,16384,8201,8731,4096,17018,4644,8201,65,16977,4721,16962,8240,21041,538,4640,4641,2577,5,16465,4645,561,4176,16480]

theorem envBound8849 : H12AffineFastState.Bounded env8849 := by
  intro p hp
  have h : env8849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8848_8849 : H12AffineEnvironment.transform 15 8731 env8848 = env8849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8731 env8848 == env8849) = true)

theorem identity8849 : scanCanonicalize (H12AffineFastState.compose env8849 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 624) := by decide +kernel

theorem selectedBound8849 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env8850 : List Nat := [2,4,8,16,32,64,57,68,512,69,2048,4096,8192,624,8201,8731,4096,10,4644,8201,65,33,4721,50,8240,4161,538,4640,4641,2577,5,545,4645,561,4176,528]

theorem envBound8850 : H12AffineFastState.Bounded env8850 := by
  intro p hp
  have h : env8850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8849_8850 : H12AffineEnvironment.transform 13 624 env8849 = env8850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 624 env8849 == env8850) = true)

theorem identity8850 : scanCanonicalize (H12AffineFastState.compose env8850 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound8850 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8851 : List Nat := [2,4,8,16,32,64,57,68,512,69,586,4096,8192,624,8201,8731,4096,10,4644,8201,65,33,4721,50,8240,4161,538,4640,4641,91,5,545,4645,561,4176,528]

theorem envBound8851 : H12AffineFastState.Bounded env8851 := by
  intro p hp
  have h : env8851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8850_8851 : H12AffineEnvironment.transform 10 586 env8850 = env8851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env8850 == env8851) = true)

theorem identity8851 : scanCanonicalize (H12AffineFastState.compose env8851 (packedSelected [0,7,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8851 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8852 : List Nat := [2,4,8,0,32,64,41,68,512,69,586,4096,8192,608,8201,8715,4096,10,4644,8201,65,33,4705,34,8224,4161,522,4640,4641,75,5,545,4645,545,4160,512]

theorem envBound8852 : H12AffineFastState.Bounded env8852 := by
  intro p hp
  have h : env8852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8851_8852 : H12AffineEnvironment.transform 3 0 env8851 = env8852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8851 == env8852) = true)

theorem identity8852 : scanCanonicalize (H12AffineFastState.compose env8852 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4681) := by decide +kernel

theorem selectedBound8852 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env8853 : List Nat := [2,4,8,0,32,64,41,68,512,69,586,4096,4681,608,4672,4162,4096,10,4644,4672,65,33,4705,34,4713,4161,522,4640,4641,75,5,545,4645,545,4160,512]

theorem envBound8853 : H12AffineFastState.Bounded env8853 := by
  intro p hp
  have h : env8853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8852_8853 : H12AffineEnvironment.transform 12 4681 env8852 = env8853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4681 env8852 == env8853) = true)

theorem identity8853 : scanCanonicalize (H12AffineFastState.compose env8853 (packedSelected [0,2,3,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound8853 : packedSelected [0,2,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8854 : List Nat := [2,4,8,0,32,64,41,68,97,69,43,4096,4136,1,4129,4162,4096,10,4165,4129,65,33,4096,34,4104,4161,107,4161,4160,75,5,64,4164,64,4160,97]

theorem envBound8854 : H12AffineFastState.Bounded env8854 := by
  intro p hp
  have h : env8854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8853_8854 : H12AffineEnvironment.transform 8 97 env8853 = env8854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8853 == env8854) = true)

theorem identity8854 : scanCanonicalize (H12AffineFastState.compose env8854 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound8854 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env8855 : List Nat := [2,4,8,0,32,33,41,37,0,36,43,4096,4136,1,4129,4131,4096,10,4132,4129,32,33,4096,34,4104,4128,10,4128,4129,42,5,33,4133,33,4129,0]

theorem envBound8855 : H12AffineFastState.Bounded env8855 := by
  intro p hp
  have h : env8855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8854_8855 : H12AffineEnvironment.transform 5 33 env8854 = env8855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env8854 == env8855) = true)

theorem identity8855 : scanCanonicalize (H12AffineFastState.compose env8855 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8855 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8856 : List Nat := [2,4,8,0,1,0,8,4,0,5,10,4096,4105,1,4096,4098,4096,10,4101,4096,1,0,4096,3,4104,4097,10,4097,4096,11,5,0,4100,0,4096,0]

theorem envBound8856 : H12AffineFastState.Bounded env8856 := by
  intro p hp
  have h : env8856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8855_8856 : H12AffineEnvironment.transform 4 1 env8855 = env8856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8855 == env8856) = true)

theorem identity8856 : scanCanonicalize (H12AffineFastState.compose env8856 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8856 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8857 : List Nat := [2,4,2,0,1,0,2,4,0,5,0,4096,4099,1,4096,4098,4096,0,4101,4096,1,0,4096,3,4098,4097,0,4097,4096,1,5,0,4100,0,4096,0]

theorem envBound8857 : H12AffineFastState.Bounded env8857 := by
  intro p hp
  have h : env8857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8856_8857 : H12AffineEnvironment.transform 2 2 env8856 = env8857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8856 == env8857) = true)

theorem identity8857 : scanCanonicalize (H12AffineFastState.compose env8857 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound8857 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8858 : List Nat := [2,4,2,0,1,0,2,4,0,5,0,0,3,1,0,2,0,0,5,0,1,0,0,3,2,1,0,1,0,1,5,0,4,0,0,0]

theorem envBound8858 : H12AffineFastState.Bounded env8858 := by
  intro p hp
  have h : env8858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8857_8858 : H12AffineEnvironment.transform 11 0 env8857 = env8858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env8857 == env8858) = true)

def env8859 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5005,90336,8329,21041,278625,4214985,4215093,75787,505,4268382,4960,73771,2175666,90943]

theorem envBound8859 : H12AffineFastState.Bounded env8859 := by
  intro p hp
  have h : env8859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8790_8859 : H12AffineEnvironment.transform 18 4961 env8790 = env8859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8790 == env8859) = true)

theorem identity8859 : scanCanonicalize (H12AffineFastState.compose env8859 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8859 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8860 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,2097152,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4960,16617,2118256,1021]

theorem envBound8860 : H12AffineFastState.Bounded env8860 := by
  intro p hp
  have h : env8860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8859_8860 : H12AffineEnvironment.transform 15 24770 env8859 = env8860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8859 == env8860) = true)

def env8861 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,64,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4960,16617,21040,1021]

theorem envBound8861 : H12AffineFastState.Bounded env8861 := by
  intro p hp
  have h : env8861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8860_8861 : H12AffineEnvironment.transform 20 64 env8860 = env8861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8860 == env8861) = true)

theorem identity8861 : scanCanonicalize (H12AffineFastState.compose env8861 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282926) := by decide +kernel

theorem selectedBound8861 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8862 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,64,282926,5005,34,8329,21041,278625,262631,262171,18633,505,266418,4960,16617,21040,1021]

theorem envBound8862 : H12AffineFastState.Bounded env8862 := by
  intro p hp
  have h : env8862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8861_8862 : H12AffineEnvironment.transform 21 282926 env8861 = env8862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282926 env8861 == env8862) = true)

def env8863 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8692,8946,4605,262144,4961,8692,64,267038,5005,34,8329,4097,262737,262631,262171,2809,505,266418,4960,729,4096,1021]

theorem envBound8863 : H12AffineFastState.Bounded env8863 := by
  intro p hp
  have h : env8863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8862_8863 : H12AffineEnvironment.transform 13 560 env8862 = env8863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8862 == env8863) = true)

def env8864 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8234,4605,262144,4537,8692,64,266694,4437,34,8329,4097,262281,262631,262171,2081,505,266418,4536,1,4096,293]

theorem envBound8864 : H12AffineFastState.Bounded env8864 := by
  intro p hp
  have h : env8864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8863_8864 : H12AffineEnvironment.transform 8 216 env8863 = env8864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8863 == env8864) = true)

theorem identity8864 : scanCanonicalize (H12AffineFastState.compose env8864 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8864 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8865 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,232,8353,8234,4264,262144,4332,8353,64,266387,4096,34,8329,4097,262281,262322,262171,2081,172,266418,4333,1,4096,112]

theorem envBound8865 : H12AffineFastState.Bounded env8865 := by
  intro p hp
  have h : env8865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8864_8865 : H12AffineEnvironment.transform 7 85 env8864 = env8865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8864 == env8865) = true)

theorem identity8865 : scanCanonicalize (H12AffineFastState.compose env8865 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8865 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8866 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,4096,8192,232,8353,8234,4264,90,4332,8353,64,4297,4096,34,8329,4097,211,232,65,2081,172,4328,4333,1,4096,112]

theorem envBound8866 : H12AffineFastState.Bounded env8866 := by
  intro p hp
  have h : env8866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8865_8866 : H12AffineEnvironment.transform 17 90 env8865 = env8866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8865 == env8866) = true)

theorem identity8866 : scanCanonicalize (H12AffineFastState.compose env8866 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8866 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8867 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,2242,8192,232,8353,8234,2154,90,2094,8353,64,2059,2242,34,8329,2243,211,232,65,2081,172,2090,2095,1,2242,112]

theorem envBound8867 : H12AffineFastState.Bounded env8867 := by
  intro p hp
  have h : env8867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8866_8867 : H12AffineEnvironment.transform 11 2242 env8866 = env8867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8866 == env8867) = true)

theorem identity8867 : scanCanonicalize (H12AffineFastState.compose env8867 (packedSelected [3,7,8,9,10,11,13,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound8867 : packedSelected [3,7,8,9,10,11,13,14,18] rootPS < 2^1333 := by decide +kernel

def env8868 : List Nat := [2,4,8,16,32,64,128,85,216,84,2048,2242,56,232,153,18,2154,90,2094,153,64,2059,2242,34,177,2243,211,232,65,2081,172,2090,2095,1,2242,112]

theorem envBound8868 : H12AffineFastState.Bounded env8868 := by
  intro p hp
  have h : env8868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8867_8868 : H12AffineEnvironment.transform 12 56 env8867 = env8868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env8867 == env8868) = true)

theorem identity8868 : scanCanonicalize (H12AffineFastState.compose env8868 (packedSelected [0,1,4,7,8,9,12,14,19] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound8868 : packedSelected [0,1,4,7,8,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env8869 : List Nat := [2,4,8,16,32,64,128,85,216,84,10,200,56,232,153,18,96,90,36,153,64,1,200,34,177,201,211,232,65,43,172,32,37,1,200,112]

theorem envBound8869 : H12AffineFastState.Bounded env8869 := by
  intro p hp
  have h : env8869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8868_8869 : H12AffineEnvironment.transform 10 10 env8868 = env8869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env8868 == env8869) = true)

theorem identity8869 : scanCanonicalize (H12AffineFastState.compose env8869 (packedSelected [0,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound8869 : packedSelected [0,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8870 : List Nat := [2,4,8,16,32,64,3,85,91,84,10,75,56,107,26,18,96,90,36,26,64,1,75,34,50,74,80,107,65,43,47,32,37,1,75,112]

theorem envBound8870 : H12AffineFastState.Bounded env8870 := by
  intro p hp
  have h : env8870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8869_8870 : H12AffineEnvironment.transform 6 3 env8869 = env8870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env8869 == env8870) = true)

theorem identity8870 : scanCanonicalize (H12AffineFastState.compose env8870 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8870 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env8871 : List Nat := [2,4,8,16,10,64,3,85,91,84,10,75,18,65,26,18,74,90,14,26,64,1,75,8,24,74,80,65,65,1,5,10,15,1,75,90]

theorem envBound8871 : H12AffineFastState.Bounded env8871 := by
  intro p hp
  have h : env8871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8870_8871 : H12AffineEnvironment.transform 4 10 env8870 = env8871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8870 == env8871) = true)

theorem identity8871 : scanCanonicalize (H12AffineFastState.compose env8871 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound8871 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env8872 : List Nat := [2,4,7,16,5,64,3,85,84,84,5,68,18,65,21,18,69,85,1,21,64,1,68,7,23,69,80,65,65,1,5,5,0,1,68,85]

theorem envBound8872 : H12AffineFastState.Bounded env8872 := by
  intro p hp
  have h : env8872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8871_8872 : H12AffineEnvironment.transform 2 7 env8871 = env8872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env8871 == env8872) = true)

theorem identity8872 : scanCanonicalize (H12AffineFastState.compose env8872 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8872 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env8873 : List Nat := [2,4,7,16,5,1,3,20,21,21,5,5,18,0,21,18,4,20,1,21,1,1,5,7,23,4,17,0,0,1,5,5,0,1,5,20]

theorem envBound8873 : H12AffineFastState.Bounded env8873 := by
  intro p hp
  have h : env8873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8872_8873 : H12AffineEnvironment.transform 5 1 env8872 = env8873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8872 == env8873) = true)

theorem identity8873 : scanCanonicalize (H12AffineFastState.compose env8873 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound8873 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8874 : List Nat := [2,4,7,4,5,1,3,0,1,1,5,5,6,0,1,6,4,0,1,1,1,1,5,7,3,4,5,0,0,1,5,5,0,1,5,0]

theorem envBound8874 : H12AffineFastState.Bounded env8874 := by
  intro p hp
  have h : env8874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8873_8874 : H12AffineEnvironment.transform 3 4 env8873 = env8874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env8873 == env8874) = true)

def env8875 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8235,4605,262144,4536,8692,64,266695,4436,34,8329,4097,262280,262631,262171,2080,505,266418,4537,0,4096,292]

theorem envBound8875 : H12AffineFastState.Bounded env8875 := by
  intro p hp
  have h : env8875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8863_8875 : H12AffineEnvironment.transform 8 217 env8863 = env8875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8863 == env8875) = true)

theorem identity8875 : scanCanonicalize (H12AffineFastState.compose env8875 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4123) := by decide +kernel

theorem selectedBound8875 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8876 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8235,4605,4123,4536,8692,64,476,4436,34,8329,4097,4243,4604,4096,2080,505,169,4537,0,4096,292]

theorem envBound8876 : H12AffineFastState.Bounded env8876 := by
  intro p hp
  have h : env8876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8875_8876 : H12AffineEnvironment.transform 17 4123 env8875 = env8876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4123 env8875 == env8876) = true)

theorem identity8876 : scanCanonicalize (H12AffineFastState.compose env8876 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound8876 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8877 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,232,8192,233,8692,8235,277,243,336,8692,64,476,444,34,8329,233,123,276,232,2080,505,169,337,0,232,292]

theorem envBound8877 : H12AffineFastState.Bounded env8877 := by
  intro p hp
  have h : env8877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8876_8877 : H12AffineEnvironment.transform 11 232 env8876 = env8877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env8876 == env8877) = true)

theorem identity8877 : scanCanonicalize (H12AffineFastState.compose env8877 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound8877 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env8878 : List Nat := [2,4,8,16,32,64,128,256,217,257,122,232,8192,233,8692,8235,277,243,336,8692,64,476,444,34,8329,233,123,276,232,90,505,169,337,0,232,292]

theorem envBound8878 : H12AffineFastState.Bounded env8878 := by
  intro p hp
  have h : env8878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8877_8878 : H12AffineEnvironment.transform 10 122 env8877 = env8878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env8877 == env8878) = true)

theorem identity8878 : scanCanonicalize (H12AffineFastState.compose env8878 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound8878 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8879 : List Nat := [2,4,8,16,32,64,128,172,217,173,122,232,8192,233,8280,8235,185,243,252,8280,64,112,16,34,8329,233,123,184,232,90,85,169,253,0,232,136]

theorem envBound8879 : H12AffineFastState.Bounded env8879 := by
  intro p hp
  have h : env8879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8878_8879 : H12AffineEnvironment.transform 7 172 env8878 = env8879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env8878 == env8879) = true)

theorem identity8879 : scanCanonicalize (H12AffineFastState.compose env8879 (packedSelected [2,5,8,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8879 : packedSelected [2,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env8880 : List Nat := [2,4,8,16,32,64,128,172,217,173,122,232,98,233,58,73,185,243,252,58,64,112,16,34,235,233,123,184,232,90,85,169,253,0,232,136]

theorem envBound8880 : H12AffineFastState.Bounded env8880 := by
  intro p hp
  have h : env8880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8879_8880 : H12AffineEnvironment.transform 12 98 env8879 = env8880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8879 == env8880) = true)

theorem identity8880 : scanCanonicalize (H12AffineFastState.compose env8880 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8880 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8881 : List Nat := [2,4,8,16,32,48,128,172,169,173,10,152,18,153,58,57,185,131,140,58,48,0,16,34,155,153,11,184,152,42,37,169,141,0,152,136]

theorem envBound8881 : H12AffineFastState.Bounded env8881 := by
  intro p hp
  have h : env8881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8880_8881 : H12AffineEnvironment.transform 5 48 env8880 = env8881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8880 == env8881) = true)

theorem identity8881 : scanCanonicalize (H12AffineFastState.compose env8881 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8881 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8882 : List Nat := [2,4,8,16,32,48,8,36,33,37,10,16,18,17,58,57,49,11,4,58,48,0,16,34,19,17,11,48,16,42,37,33,5,0,16,0]

theorem envBound8882 : H12AffineFastState.Bounded env8882 := by
  intro p hp
  have h : env8882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8881_8882 : H12AffineEnvironment.transform 6 8 env8881 = env8882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8881 == env8882) = true)

theorem identity8882 : scanCanonicalize (H12AffineFastState.compose env8882 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8882 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8883 : List Nat := [2,4,8,16,1,17,8,5,0,4,10,16,18,17,27,24,16,11,4,27,17,0,16,3,19,17,11,17,16,11,4,0,5,0,16,0]

theorem envBound8883 : H12AffineFastState.Bounded env8883 := by
  intro p hp
  have h : env8883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8882_8883 : H12AffineEnvironment.transform 4 1 env8882 = env8883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8882 == env8883) = true)

theorem identity8883 : scanCanonicalize (H12AffineFastState.compose env8883 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8884 : List Nat := [2,4,2,16,1,17,2,5,0,4,0,16,18,17,17,18,16,1,4,17,17,0,16,3,19,17,1,17,16,1,4,0,5,0,16,0]

theorem envBound8884 : H12AffineFastState.Bounded env8884 := by
  intro p hp
  have h : env8884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8883_8884 : H12AffineEnvironment.transform 2 2 env8883 = env8884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8883 == env8884) = true)

theorem identity8884 : scanCanonicalize (H12AffineFastState.compose env8884 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8885 : List Nat := [2,4,2,1,1,0,2,5,0,4,0,1,3,0,0,3,1,1,4,0,0,0,1,3,2,0,1,0,1,1,4,0,5,0,1,0]

theorem envBound8885 : H12AffineFastState.Bounded env8885 := by
  intro p hp
  have h : env8885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8884_8885 : H12AffineEnvironment.transform 3 1 env8884 = env8885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8884 == env8885) = true)

def env8886 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8692,8947,4605,262144,4961,8692,64,267039,5005,34,8329,4096,262736,262631,262171,2808,505,266418,4960,728,4097,1021]

theorem envBound8886 : H12AffineFastState.Bounded env8886 := by
  intro p hp
  have h : env8886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8862_8886 : H12AffineEnvironment.transform 13 561 env8862 = env8886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8862 == env8886) = true)

def env8887 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8235,4605,262144,4537,8692,64,266695,4437,34,8329,4096,262280,262631,262171,2080,505,266418,4536,0,4097,293]

theorem envBound8887 : H12AffineFastState.Bounded env8887 := by
  intro p hp
  have h : env8887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8886_8887 : H12AffineEnvironment.transform 8 216 env8886 = env8887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8886 == env8887) = true)

theorem identity8887 : scanCanonicalize (H12AffineFastState.compose env8887 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4123) := by decide +kernel

theorem selectedBound8887 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8888 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8235,4605,4123,4537,8692,64,476,4437,34,8329,4096,4243,4604,4096,2080,505,169,4536,0,4097,293]

theorem envBound8888 : H12AffineFastState.Bounded env8888 := by
  intro p hp
  have h : env8888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8887_8888 : H12AffineEnvironment.transform 17 4123 env8887 = env8888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4123 env8887 == env8888) = true)

theorem identity8888 : scanCanonicalize (H12AffineFastState.compose env8888 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound8888 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8889 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,444,8192,233,8692,8235,65,423,5,8692,64,476,233,34,8329,444,303,64,444,2080,505,169,4,0,445,293]

theorem envBound8889 : H12AffineFastState.Bounded env8889 := by
  intro p hp
  have h : env8889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8888_8889 : H12AffineEnvironment.transform 11 444 env8888 = env8889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env8888 == env8889) = true)

theorem identity8889 : scanCanonicalize (H12AffineFastState.compose env8889 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound8889 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8890 : List Nat := [2,4,8,16,32,64,128,256,216,257,211,444,8192,233,8692,8235,65,423,5,8692,64,476,233,34,8329,444,303,64,444,243,505,169,4,0,445,293]

theorem envBound8890 : H12AffineFastState.Bounded env8890 := by
  intro p hp
  have h : env8890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8889_8890 : H12AffineEnvironment.transform 10 211 env8889 = env8890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env8889 == env8890) = true)

theorem identity8890 : scanCanonicalize (H12AffineFastState.compose env8890 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8890 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env8891 : List Nat := [2,4,8,16,32,64,128,84,216,85,211,232,8192,233,8352,8235,65,243,5,8352,64,136,233,34,8329,232,123,64,232,243,173,169,4,0,233,113]

theorem envBound8891 : H12AffineFastState.Bounded env8891 := by
  intro p hp
  have h : env8891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8890_8891 : H12AffineEnvironment.transform 7 84 env8890 = env8891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8890 == env8891) = true)

theorem identity8891 : scanCanonicalize (H12AffineFastState.compose env8891 (packedSelected [1,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound8891 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env8892 : List Nat := [2,4,8,16,32,64,99,84,59,85,48,11,8192,10,8259,8235,65,16,5,8259,64,107,10,34,8298,11,123,64,11,16,78,74,4,0,10,113]

theorem envBound8892 : H12AffineFastState.Bounded env8892 := by
  intro p hp
  have h : env8892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8891_8892 : H12AffineEnvironment.transform 6 99 env8891 = env8892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env8891 == env8892) = true)

theorem identity8892 : scanCanonicalize (H12AffineFastState.compose env8892 (packedSelected [0,2,3,4,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound8892 : packedSelected [0,2,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env8893 : List Nat := [2,4,8,16,32,64,99,84,59,85,48,11,72,10,11,99,65,16,5,11,64,107,10,34,34,11,123,64,11,16,78,74,4,0,10,113]

theorem envBound8893 : H12AffineFastState.Bounded env8893 := by
  intro p hp
  have h : env8893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8892_8893 : H12AffineEnvironment.transform 12 72 env8892 = env8893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env8892 == env8893) = true)

theorem identity8893 : scanCanonicalize (H12AffineFastState.compose env8893 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8893 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8894 : List Nat := [2,4,8,16,17,64,82,84,10,85,1,11,72,10,11,82,65,16,5,11,64,90,10,19,19,11,74,64,11,16,78,74,4,0,10,64]

theorem envBound8894 : H12AffineFastState.Bounded env8894 := by
  intro p hp
  have h : env8894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8893_8894 : H12AffineEnvironment.transform 4 17 env8893 = env8894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8893 == env8894) = true)

theorem identity8894 : scanCanonicalize (H12AffineFastState.compose env8894 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8894 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env8895 : List Nat := [2,4,8,10,11,64,72,78,10,79,1,11,72,10,11,72,65,10,5,11,64,64,10,9,9,11,74,64,11,10,78,74,4,0,10,64]

theorem envBound8895 : H12AffineFastState.Bounded env8895 := by
  intro p hp
  have h : env8895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8894_8895 : H12AffineEnvironment.transform 3 10 env8894 = env8895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8894 == env8895) = true)

theorem identity8895 : scanCanonicalize (H12AffineFastState.compose env8895 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8895 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8896 : List Nat := [2,4,2,0,1,64,66,68,0,69,1,1,66,0,1,66,65,0,5,1,64,64,0,3,3,1,64,64,1,0,68,64,4,0,0,64]

theorem envBound8896 : H12AffineFastState.Bounded env8896 := by
  intro p hp
  have h : env8896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8895_8896 : H12AffineEnvironment.transform 2 2 env8895 = env8896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8895 == env8896) = true)

def env8897 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8234,4605,262144,4536,8692,64,266694,4436,34,8329,4096,262281,262631,262171,2081,505,266418,4537,1,4097,292]

theorem envBound8897 : H12AffineFastState.Bounded env8897 := by
  intro p hp
  have h : env8897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8886_8897 : H12AffineEnvironment.transform 8 217 env8886 = env8897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8886 == env8897) = true)

theorem identity8897 : scanCanonicalize (H12AffineFastState.compose env8897 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8897 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8898 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,4096,8192,232,8353,8234,4264,262144,4333,8353,64,266387,4097,34,8329,4096,262281,262322,262171,2081,172,266418,4332,1,4097,113]

theorem envBound8898 : H12AffineFastState.Bounded env8898 := by
  intro p hp
  have h : env8898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8897_8898 : H12AffineEnvironment.transform 7 85 env8897 = env8898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8897 == env8898) = true)

theorem identity8898 : scanCanonicalize (H12AffineFastState.compose env8898 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound8898 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8899 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,65,8192,232,8353,8234,233,262144,172,8353,64,262354,64,34,8329,65,262281,262322,262171,2081,172,262387,173,1,64,113]

theorem envBound8899 : H12AffineFastState.Bounded env8899 := by
  intro p hp
  have h : env8899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8898_8899 : H12AffineEnvironment.transform 11 65 env8898 = env8899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env8898 == env8899) = true)

theorem identity8899 : scanCanonicalize (H12AffineFastState.compose env8899 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 2160) := by decide +kernel

theorem selectedBound8899 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8900 : List Nat := [2,4,8,16,32,64,128,85,217,84,2048,65,8192,232,8353,8234,233,2160,172,8353,64,2210,64,34,8329,65,2297,2242,2155,2081,172,2179,173,1,64,113]

theorem envBound8900 : H12AffineFastState.Bounded env8900 := by
  intro p hp
  have h : env8900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8899_8900 : H12AffineEnvironment.transform 17 2160 env8899 = env8900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2160 env8899 == env8900) = true)

theorem identity8900 : scanCanonicalize (H12AffineFastState.compose env8900 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8900 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8901 : List Nat := [2,4,8,16,32,64,120,85,33,84,2048,65,8192,16,8281,8234,17,2160,84,8281,64,2138,64,34,8305,65,2049,2106,2155,2081,84,2171,85,1,64,113]

theorem envBound8901 : H12AffineFastState.Bounded env8901 := by
  intro p hp
  have h : env8901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8900_8901 : H12AffineEnvironment.transform 6 120 env8900 = env8901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8900 == env8901) = true)

theorem identity8901 : scanCanonicalize (H12AffineFastState.compose env8901 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound8901 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8902 : List Nat := [2,4,8,16,32,64,120,85,33,84,65,65,8192,16,8281,8234,17,49,84,8281,64,27,64,34,8305,65,64,123,42,96,84,58,85,1,64,113]

theorem envBound8902 : H12AffineFastState.Bounded env8902 := by
  intro p hp
  have h : env8902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8901_8902 : H12AffineEnvironment.transform 10 65 env8901 = env8902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env8901 == env8902) = true)

theorem identity8902 : scanCanonicalize (H12AffineFastState.compose env8902 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound8902 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env8903 : List Nat := [2,4,8,16,32,64,120,85,33,84,65,65,3,16,90,41,17,49,84,90,64,27,64,34,114,65,64,123,42,96,84,58,85,1,64,113]

theorem envBound8903 : H12AffineFastState.Bounded env8903 := by
  intro p hp
  have h : env8903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8902_8903 : H12AffineEnvironment.transform 12 3 env8902 = env8903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env8902 == env8903) = true)

theorem identity8903 : scanCanonicalize (H12AffineFastState.compose env8903 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8903 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8904 : List Nat := [2,4,8,0,32,64,104,69,33,68,65,65,3,0,74,41,1,33,68,74,64,11,64,34,98,65,64,107,42,96,68,42,69,1,64,97]

theorem envBound8904 : H12AffineFastState.Bounded env8904 := by
  intro p hp
  have h : env8904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8903_8904 : H12AffineEnvironment.transform 3 0 env8903 = env8904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8903 == env8904) = true)

theorem identity8904 : scanCanonicalize (H12AffineFastState.compose env8904 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8904 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8905 : List Nat := [2,4,8,0,32,1,41,4,33,5,0,0,3,0,11,41,1,33,5,11,1,11,1,34,35,0,1,42,42,33,5,42,4,1,1,32]

theorem envBound8905 : H12AffineFastState.Bounded env8905 := by
  intro p hp
  have h : env8905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8904_8905 : H12AffineEnvironment.transform 5 1 env8904 = env8905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8904 == env8905) = true)

theorem identity8905 : scanCanonicalize (H12AffineFastState.compose env8905 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8906 : List Nat := [2,4,8,0,11,1,2,4,10,5,0,0,3,0,11,2,1,10,5,11,1,11,1,9,8,0,1,1,1,10,5,1,4,1,1,11]

theorem envBound8906 : H12AffineFastState.Bounded env8906 := by
  intro p hp
  have h : env8906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8905_8906 : H12AffineEnvironment.transform 4 11 env8905 = env8906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8905 == env8906) = true)

theorem identity8906 : scanCanonicalize (H12AffineFastState.compose env8906 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8907 : List Nat := [2,1,8,0,11,1,2,1,10,0,0,0,3,0,11,2,1,10,0,11,1,11,1,9,8,0,1,1,1,10,0,1,1,1,1,11]

theorem envBound8907 : H12AffineFastState.Bounded env8907 := by
  intro p hp
  have h : env8907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8906_8907 : H12AffineEnvironment.transform 1 1 env8906 = env8907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8906 == env8907) = true)

theorem identity8907 : scanCanonicalize (H12AffineFastState.compose env8907 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8907 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8908 : List Nat := [2,1,3,0,0,1,2,1,1,0,0,0,3,0,0,2,1,1,0,0,1,0,1,2,3,0,1,1,1,1,0,1,1,1,1,0]

theorem envBound8908 : H12AffineFastState.Bounded env8908 := by
  intro p hp
  have h : env8908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8907_8908 : H12AffineEnvironment.transform 2 3 env8907 = env8908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8907 == env8908) = true)

def env8909 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,65,4194304,5005,34,8329,21041,278625,4214985,4215093,18633,505,4211100,4960,16617,21041,1021]

theorem envBound8909 : H12AffineFastState.Bounded env8909 := by
  intro p hp
  have h : env8909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8860_8909 : H12AffineEnvironment.transform 20 65 env8860 = env8909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8860 == env8909) = true)

theorem identity8909 : scanCanonicalize (H12AffineFastState.compose env8909 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279374) := by decide +kernel

theorem selectedBound8909 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8910 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,16384,8692,24770,4605,262144,4961,8692,65,279374,5005,34,8329,21041,278625,267143,266875,18633,505,262866,4960,16617,21041,1021]

theorem envBound8910 : H12AffineFastState.Bounded env8910 := by
  intro p hp
  have h : env8910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8909_8910 : H12AffineEnvironment.transform 21 279374 env8909 = env8910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279374 env8909 == env8910) = true)

def env8911 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,560,8692,8946,4605,262144,4961,8692,65,262526,5005,34,8329,4097,262737,267143,266875,2809,505,262866,4960,729,4097,1021]

theorem envBound8911 : H12AffineFastState.Bounded env8911 := by
  intro p hp
  have h : env8911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8910_8911 : H12AffineEnvironment.transform 13 560 env8910 = env8911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8910 == env8911) = true)

def env8912 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,232,8692,8234,4605,262144,4537,8692,65,262526,4437,34,8329,4097,262281,266591,266403,2081,505,262154,4536,1,4097,293]

theorem envBound8912 : H12AffineFastState.Bounded env8912 := by
  intro p hp
  have h : env8912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8911_8912 : H12AffineEnvironment.transform 8 216 env8911 = env8912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8911 == env8912) = true)

theorem identity8912 : scanCanonicalize (H12AffineFastState.compose env8912 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8912 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8913 : List Nat := [2,4,8,16,32,64,128,84,216,85,2048,4096,8192,232,8352,8234,4265,262144,4333,8352,65,262186,4097,34,8329,4097,262281,266251,266403,2081,173,262154,4332,1,4097,113]

theorem envBound8913 : H12AffineFastState.Bounded env8913 := by
  intro p hp
  have h : env8913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8912_8913 : H12AffineEnvironment.transform 7 84 env8912 = env8913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8912 == env8913) = true)

theorem identity8913 : scanCanonicalize (H12AffineFastState.compose env8913 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8913 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8914 : List Nat := [2,4,8,16,32,64,120,84,32,85,2048,4096,8192,16,8280,8234,4177,262144,4117,8280,65,262186,4097,34,8305,4097,262257,266251,266331,2081,85,262154,4116,1,4097,113]

theorem envBound8914 : H12AffineFastState.Bounded env8914 := by
  intro p hp
  have h : env8914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8913_8914 : H12AffineEnvironment.transform 6 120 env8913 = env8914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8913 == env8914) = true)

theorem identity8914 : scanCanonicalize (H12AffineFastState.compose env8914 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 6240) := by decide +kernel

theorem selectedBound8914 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8915 : List Nat := [2,4,8,16,32,64,120,84,32,85,2048,4096,8192,16,8280,8234,4177,6240,4117,8280,65,6218,4097,34,8305,4097,6161,2155,2107,2081,85,6250,4116,1,4097,113]

theorem envBound8915 : H12AffineFastState.Bounded env8915 := by
  intro p hp
  have h : env8915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8914_8915 : H12AffineEnvironment.transform 17 6240 env8914 = env8915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6240 env8914 == env8915) = true)

theorem identity8915 : scanCanonicalize (H12AffineFastState.compose env8915 (packedSelected [0,1,3,4,7,9,12,13,14,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2154) := by decide +kernel

theorem selectedBound8915 : packedSelected [0,1,3,4,7,9,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env8916 : List Nat := [2,4,8,16,32,64,120,84,32,85,2048,2154,8192,16,8280,8234,2107,10,2175,8280,65,32,2155,34,8305,2155,123,2155,2107,2081,85,0,2174,1,2155,113]

theorem envBound8916 : H12AffineFastState.Bounded env8916 := by
  intro p hp
  have h : env8916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8915_8916 : H12AffineEnvironment.transform 11 2154 env8915 = env8916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2154 env8915 == env8916) = true)

theorem identity8916 : scanCanonicalize (H12AffineFastState.compose env8916 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound8916 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env8917 : List Nat := [2,4,8,16,32,64,120,84,32,85,2048,2154,2050,16,2138,2088,2107,10,2175,2138,65,32,2155,34,2163,2155,123,2155,2107,2081,85,0,2174,1,2155,113]

theorem envBound8917 : H12AffineFastState.Bounded env8917 := by
  intro p hp
  have h : env8917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8916_8917 : H12AffineEnvironment.transform 12 2050 env8916 = env8917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env8916 == env8917) = true)

theorem identity8917 : scanCanonicalize (H12AffineFastState.compose env8917 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8917 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env8918 : List Nat := [2,4,8,16,16,64,72,84,16,85,2048,2138,2050,16,2138,2072,2059,10,2127,2138,65,16,2139,18,2115,2139,75,2139,2059,2065,85,0,2126,1,2139,65]

theorem envBound8918 : H12AffineFastState.Bounded env8918 := by
  intro p hp
  have h : env8918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8917_8918 : H12AffineEnvironment.transform 4 16 env8917 = env8918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8917 == env8918) = true)

theorem identity8918 : scanCanonicalize (H12AffineFastState.compose env8918 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound8918 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env8919 : List Nat := [2,4,8,16,16,64,72,84,16,85,16,74,18,16,74,8,27,10,95,74,65,16,75,18,83,75,75,75,27,1,85,0,94,1,75,65]

theorem envBound8919 : H12AffineFastState.Bounded env8919 := by
  intro p hp
  have h : env8919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8918_8919 : H12AffineEnvironment.transform 10 16 env8918 = env8919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env8918 == env8919) = true)

theorem identity8919 : scanCanonicalize (H12AffineFastState.compose env8919 (packedSelected [2,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8919 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env8920 : List Nat := [2,4,8,16,16,1,9,21,16,20,16,11,18,16,11,8,27,10,30,11,0,16,10,18,18,10,10,10,27,1,20,0,31,1,10,0]

theorem envBound8920 : H12AffineFastState.Bounded env8920 := by
  intro p hp
  have h : env8920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8919_8920 : H12AffineEnvironment.transform 5 1 env8919 = env8920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8919 == env8920) = true)

theorem identity8920 : scanCanonicalize (H12AffineFastState.compose env8920 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8921 : List Nat := [2,4,8,0,0,1,9,5,0,4,0,11,2,0,11,8,11,10,14,11,0,0,10,2,2,10,10,10,11,1,4,0,15,1,10,0]

theorem envBound8921 : H12AffineFastState.Bounded env8921 := by
  intro p hp
  have h : env8921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8920_8921 : H12AffineEnvironment.transform 3 0 env8920 = env8921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8920 == env8921) = true)

theorem identity8921 : scanCanonicalize (H12AffineFastState.compose env8921 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8922 : List Nat := [2,4,2,0,0,1,3,5,0,4,0,1,2,0,1,2,1,0,4,1,0,0,0,2,2,0,0,0,1,1,4,0,5,1,0,0]

theorem envBound8922 : H12AffineFastState.Bounded env8922 := by
  intro p hp
  have h : env8922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8921_8922 : H12AffineEnvironment.transform 2 2 env8921 = env8922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8921 == env8922) = true)

def leafEnv8922 : List Nat := [2,4,2,0,0,1,3,5,0,4,0,1,2,0,1,2,1,0,4,1,0,0,0,2,4,2,1,0,0,0,1,1,4,0,5,1,4,3,0,0,1,1,0]

def active8922 : List Nat := [0,1]

def tree8922 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8922 : H12WitnessSearch.Good tree8922 := H12GlobalWitnessIndex.good

theorem leafIdentity8922 : H12AffineFastState.composeSystem env8922 rootObs = leafEnv8922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8922 rootObs == leafEnv8922) = true)

theorem terminalChecked8922 : H12PackedTerminal.terminalCheckFast leafEnv8922 active8922 tree8922 = true := by decide +kernel

def env8923 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8235,4605,262144,4536,8692,65,262526,4436,34,8329,4097,262280,266590,266402,2080,505,262155,4537,0,4097,292]

theorem envBound8923 : H12AffineFastState.Bounded env8923 := by
  intro p hp
  have h : env8923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8911_8923 : H12AffineEnvironment.transform 8 217 env8911 = env8923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8911 == env8923) = true)

theorem identity8923 : scanCanonicalize (H12AffineFastState.compose env8923 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound8923 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8924 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,233,8692,8235,4605,163,4536,8692,65,477,4436,34,8329,4097,43,4605,4097,2080,505,168,4537,0,4097,292]

theorem envBound8924 : H12AffineFastState.Bounded env8924 := by
  intro p hp
  have h : env8924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8923_8924 : H12AffineEnvironment.transform 17 163 env8923 = env8924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env8923 == env8924) = true)

theorem identity8924 : scanCanonicalize (H12AffineFastState.compose env8924 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8924 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8925 : List Nat := [2,4,8,16,32,64,128,4,217,5,2048,4096,8192,233,8432,8235,4345,163,4284,8432,65,217,4176,34,8329,4097,43,4345,4097,2080,253,168,4285,0,4097,32]

theorem envBound8925 : H12AffineFastState.Bounded env8925 := by
  intro p hp
  have h : env8925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8924_8925 : H12AffineEnvironment.transform 7 4 env8924 = env8925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8924 == env8925) = true)

theorem identity8925 : scanCanonicalize (H12AffineFastState.compose env8925 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound8925 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8926 : List Nat := [2,4,8,16,32,64,128,4,217,5,2048,2195,8192,233,8432,8235,2154,163,2095,8432,65,217,2243,34,8329,2194,43,2154,2194,2080,253,168,2094,0,2194,32]

theorem envBound8926 : H12AffineFastState.Bounded env8926 := by
  intro p hp
  have h : env8926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8925_8926 : H12AffineEnvironment.transform 11 2195 env8925 = env8926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env8925 == env8926) = true)

theorem identity8926 : scanCanonicalize (H12AffineFastState.compose env8926 (packedSelected [0,2,4,7,9,11,13,18] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8926 : packedSelected [0,2,4,7,9,11,13,18] rootPS < 2^1333 := by decide +kernel

def env8927 : List Nat := [2,4,8,16,32,11,128,4,146,5,2048,2195,8192,162,8379,8235,2081,163,2095,8379,10,146,2184,34,8329,2194,43,2081,2194,2080,182,168,2094,0,2194,32]

theorem envBound8927 : H12AffineFastState.Bounded env8927 := by
  intro p hp
  have h : env8927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8926_8927 : H12AffineEnvironment.transform 5 11 env8926 = env8927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8926 == env8927) = true)

theorem identity8927 : scanCanonicalize (H12AffineFastState.compose env8927 (packedSelected [1,4,5,9,13,14] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8927 : packedSelected [1,4,5,9,13,14] rootPS < 2^1333 := by decide +kernel

def env8928 : List Nat := [2,4,8,16,32,11,41,4,59,5,2048,2106,8192,11,8210,8235,2081,10,2095,8210,10,59,2081,34,8224,2107,43,2081,2107,2080,31,1,2094,0,2107,32]

theorem envBound8928 : H12AffineFastState.Bounded env8928 := by
  intro p hp
  have h : env8928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8927_8928 : H12AffineEnvironment.transform 6 41 env8927 = env8928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8927 == env8928) = true)

theorem identity8928 : scanCanonicalize (H12AffineFastState.compose env8928 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2105) := by decide +kernel

theorem selectedBound8928 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8929 : List Nat := [2,4,8,16,32,11,41,4,59,5,2048,2106,2105,11,2091,2066,2081,10,2095,2091,10,59,2081,34,2073,2107,43,2081,2107,2080,31,1,2094,0,2107,32]

theorem envBound8929 : H12AffineFastState.Bounded env8929 := by
  intro p hp
  have h : env8929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8928_8929 : H12AffineEnvironment.transform 12 2105 env8928 = env8929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2105 env8928 == env8929) = true)

theorem identity8929 : scanCanonicalize (H12AffineFastState.compose env8929 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound8929 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env8930 : List Nat := [2,4,8,16,32,11,41,4,59,5,27,33,34,11,48,9,58,10,52,48,10,59,58,34,2,32,43,58,32,59,31,1,53,0,32,32]

theorem envBound8930 : H12AffineFastState.Bounded env8930 := by
  intro p hp
  have h : env8930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8929_8930 : H12AffineEnvironment.transform 10 27 env8929 = env8930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env8929 == env8930) = true)

theorem identity8930 : scanCanonicalize (H12AffineFastState.compose env8930 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8930 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env8931 : List Nat := [2,4,8,0,32,11,41,4,43,5,11,33,34,11,32,9,42,10,36,32,10,43,42,34,2,32,43,42,32,43,15,1,37,0,32,32]

theorem envBound8931 : H12AffineFastState.Bounded env8931 := by
  intro p hp
  have h : env8931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8930_8931 : H12AffineEnvironment.transform 3 0 env8930 = env8931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8930 == env8931) = true)

theorem identity8931 : scanCanonicalize (H12AffineFastState.compose env8931 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8931 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8932 : List Nat := [2,4,3,0,32,0,34,4,32,5,0,33,34,0,32,2,33,1,36,32,1,32,33,34,2,32,32,33,32,32,4,1,37,0,32,32]

theorem envBound8932 : H12AffineFastState.Bounded env8932 := by
  intro p hp
  have h : env8932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8931_8932 : H12AffineEnvironment.transform 2 3 env8931 = env8932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8931 == env8932) = true)

theorem identity8932 : scanCanonicalize (H12AffineFastState.compose env8932 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8933 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,0,3,0,1,2,0,1,5,1,1,1,0,3,2,1,1,0,1,1,4,1,4,0,1,1]

theorem envBound8933 : H12AffineFastState.Bounded env8933 := by
  intro p hp
  have h : env8933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8932_8933 : H12AffineEnvironment.transform 4 1 env8932 = env8933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8932 == env8933) = true)

def leafEnv8933 : List Nat := [2,4,3,0,1,0,3,4,1,5,0,0,3,0,1,2,0,1,5,1,1,1,0,3,4,2,1,1,1,0,1,1,4,1,4,0,4,2,1,1,1,1,0]

def active8933 : List Nat := [0,1]

def tree8933 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8933 : H12WitnessSearch.Good tree8933 := H12GlobalWitnessIndex.good

theorem leafIdentity8933 : H12AffineFastState.composeSystem env8933 rootObs = leafEnv8933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8933 rootObs == leafEnv8933) = true)

theorem terminalChecked8933 : H12PackedTerminal.terminalCheckFast leafEnv8933 active8933 tree8933 = true := by decide +kernel

def env8934 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,4096,8192,561,8692,8947,4605,262144,4961,8692,65,262527,5005,34,8329,4096,262736,267143,266875,2808,505,262866,4960,728,4096,1021]

theorem envBound8934 : H12AffineFastState.Bounded env8934 := by
  intro p hp
  have h : env8934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8910_8934 : H12AffineEnvironment.transform 13 561 env8910 = env8934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8910 == env8934) = true)

def env8935 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8235,4605,262144,4537,8692,65,262527,4437,34,8329,4096,262280,266591,266403,2080,505,262154,4536,0,4096,293]

theorem envBound8935 : H12AffineFastState.Bounded env8935 := by
  intro p hp
  have h : env8935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8934_8935 : H12AffineEnvironment.transform 8 216 env8934 = env8935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8934 == env8935) = true)

theorem identity8935 : scanCanonicalize (H12AffineFastState.compose env8935 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 162) := by decide +kernel

theorem selectedBound8935 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8936 : List Nat := [2,4,8,16,32,64,128,256,216,257,2048,4096,8192,233,8692,8235,4605,162,4537,8692,65,477,4437,34,8329,4096,42,4605,4097,2080,505,168,4536,0,4096,293]

theorem envBound8936 : H12AffineFastState.Bounded env8936 := by
  intro p hp
  have h : env8936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8935_8936 : H12AffineEnvironment.transform 17 162 env8935 = env8936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 162 env8935 == env8936) = true)

theorem identity8936 : scanCanonicalize (H12AffineFastState.compose env8936 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8936 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8937 : List Nat := [2,4,8,16,32,16,128,256,136,257,2048,4096,8192,185,8612,8235,4525,162,4537,8612,17,397,4357,34,8329,4096,42,4525,4097,2080,425,168,4536,0,4096,293]

theorem envBound8937 : H12AffineFastState.Bounded env8937 := by
  intro p hp
  have h : env8937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8936_8937 : H12AffineEnvironment.transform 5 16 env8936 = env8937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8936 == env8937) = true)

theorem identity8937 : scanCanonicalize (H12AffineFastState.compose env8937 (packedSelected [13,14,17] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound8937 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8938 : List Nat := [2,4,8,16,32,16,128,256,136,257,390,4096,8192,185,8612,8235,4525,162,4537,8612,17,397,4357,34,8329,4096,42,4525,4097,422,425,168,4536,0,4096,293]

theorem envBound8938 : H12AffineFastState.Bounded env8938 := by
  intro p hp
  have h : env8938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8937_8938 : H12AffineEnvironment.transform 10 390 env8937 = env8938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env8937 == env8938) = true)

theorem identity8938 : scanCanonicalize (H12AffineFastState.compose env8938 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8938 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8939 : List Nat := [2,4,8,16,32,16,128,256,136,257,390,184,8192,185,8612,8235,277,162,257,8612,17,397,445,34,8329,184,42,277,185,422,425,168,256,0,184,293]

theorem envBound8939 : H12AffineFastState.Bounded env8939 := by
  intro p hp
  have h : env8939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8938_8939 : H12AffineEnvironment.transform 11 184 env8938 = env8939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8938 == env8939) = true)

theorem identity8939 : scanCanonicalize (H12AffineFastState.compose env8939 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound8939 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env8940 : List Nat := [2,4,8,16,32,16,2,256,10,257,260,58,8192,59,8486,8235,277,32,257,8486,17,271,319,34,8203,58,42,277,59,292,299,42,256,0,58,293]

theorem envBound8940 : H12AffineFastState.Bounded env8940 := by
  intro p hp
  have h : env8940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8939_8940 : H12AffineEnvironment.transform 6 2 env8939 = env8940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env8939 == env8940) = true)

theorem identity8940 : scanCanonicalize (H12AffineFastState.compose env8940 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound8940 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env8941 : List Nat := [2,4,8,16,32,16,2,256,10,257,260,58,268,59,42,295,277,32,257,42,17,271,319,34,263,58,42,277,59,292,299,42,256,0,58,293]

theorem envBound8941 : H12AffineFastState.Bounded env8941 := by
  intro p hp
  have h : env8941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8940_8941 : H12AffineEnvironment.transform 12 268 env8940 = env8941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env8940 == env8941) = true)

theorem identity8941 : scanCanonicalize (H12AffineFastState.compose env8941 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8941 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env8942 : List Nat := [2,4,8,16,17,16,2,256,10,257,260,11,268,10,27,278,277,17,257,27,17,271,270,19,263,11,27,277,10,277,282,27,256,0,11,276]

theorem envBound8942 : H12AffineFastState.Bounded env8942 := by
  intro p hp
  have h : env8942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8941_8942 : H12AffineEnvironment.transform 4 17 env8941 = env8942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8941 == env8942) = true)

theorem identity8942 : scanCanonicalize (H12AffineFastState.compose env8942 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound8942 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env8943 : List Nat := [2,4,8,16,17,16,2,14,10,15,10,11,2,10,27,24,27,17,15,27,17,1,0,19,9,11,27,27,10,27,20,27,14,0,11,26]

theorem envBound8943 : H12AffineFastState.Bounded env8943 := by
  intro p hp
  have h : env8943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8942_8943 : H12AffineEnvironment.transform 7 14 env8942 = env8943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env8942 == env8943) = true)

theorem identity8943 : scanCanonicalize (H12AffineFastState.compose env8943 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8943 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8944 : List Nat := [2,4,2,16,17,16,2,4,0,5,0,1,2,0,17,18,17,17,5,17,17,1,0,19,3,1,17,17,0,17,20,17,4,0,1,16]

theorem envBound8944 : H12AffineFastState.Bounded env8944 := by
  intro p hp
  have h : env8944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8943_8944 : H12AffineEnvironment.transform 2 2 env8943 = env8944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8943 == env8944) = true)

def env8945 : List Nat := [2,4,8,16,32,64,128,256,217,257,2048,4096,8192,232,8692,8234,4605,262144,4536,8692,65,262527,4436,34,8329,4096,262281,266590,266402,2081,505,262155,4537,1,4096,292]

theorem envBound8945 : H12AffineFastState.Bounded env8945 := by
  intro p hp
  have h : env8945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8934_8945 : H12AffineEnvironment.transform 8 217 env8934 = env8945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8934 == env8945) = true)

theorem identity8945 : scanCanonicalize (H12AffineFastState.compose env8945 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8945 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8946 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,232,8352,8234,4265,262144,4332,8352,65,262187,4096,34,8329,4096,262281,266250,266402,2081,173,262155,4333,1,4096,112]

theorem envBound8946 : H12AffineFastState.Bounded env8946 := by
  intro p hp
  have h : env8946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8945_8946 : H12AffineEnvironment.transform 7 84 env8945 = env8946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8945 == env8946) = true)

theorem identity8946 : scanCanonicalize (H12AffineFastState.compose env8946 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8946 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8947 : List Nat := [2,4,8,16,32,64,128,84,217,85,2048,4096,8192,232,8352,8234,4265,90,4332,8352,65,113,4096,34,8329,4096,211,4176,4344,2081,173,81,4333,1,4096,112]

theorem envBound8947 : H12AffineFastState.Bounded env8947 := by
  intro p hp
  have h : env8947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8946_8947 : H12AffineEnvironment.transform 17 90 env8946 = env8947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8946 == env8947) = true)

theorem identity8947 : scanCanonicalize (H12AffineFastState.compose env8947 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8947 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8948 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,4096,8192,65,8201,8234,4096,90,4165,8201,65,113,4096,34,8224,4096,122,4176,4177,2081,4,81,4164,1,4096,112]

theorem envBound8948 : H12AffineFastState.Bounded env8948 := by
  intro p hp
  have h : env8948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8947_8948 : H12AffineEnvironment.transform 6 41 env8947 = env8948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8947 == env8948) = true)

theorem identity8948 : scanCanonicalize (H12AffineFastState.compose env8948 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 6217) := by decide +kernel

theorem selectedBound8948 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8949 : List Nat := [2,4,8,16,32,64,41,84,112,85,2048,4096,6217,65,6208,6243,4096,90,4165,6208,65,113,4096,34,6249,4096,122,4176,4177,2081,4,81,4164,1,4096,112]

theorem envBound8949 : H12AffineFastState.Bounded env8949 := by
  intro p hp
  have h : env8949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8948_8949 : H12AffineEnvironment.transform 12 6217 env8948 = env8949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6217 env8948 == env8949) = true)

end H12CloudChart1