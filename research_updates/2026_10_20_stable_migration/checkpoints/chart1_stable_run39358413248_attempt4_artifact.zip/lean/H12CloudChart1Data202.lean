import H12CloudChart1Data201

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem treeGood51174 : H12WitnessSearch.Good tree51174 := H12GlobalWitnessIndex.good

theorem leafIdentity51174 : H12AffineFastState.composeSystem env51174 rootObs = leafEnv51174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51174 rootObs == leafEnv51174) = true)

theorem terminalChecked51174 : H12PackedTerminal.terminalCheckFast leafEnv51174 active51174 tree51174 = true := by decide +kernel

def env51175 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1044,1,35,1028,2048,1025,0,33,33,16,2,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound51175 : H12AffineFastState.Bounded env51175 := by
  intro p hp
  have h : env51175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51168_51175 : H12AffineEnvironment.transform 11 49 env51168 = env51175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env51168 == env51175) = true)

theorem identity51175 : scanCanonicalize (H12AffineFastState.compose env51175 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51176 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,40,1044,1,35,1028,0,1025,0,33,33,16,2,40,17,0,1029,48,0,1056,32,37,33,1044,513]

theorem envBound51176 : H12AffineFastState.Bounded env51176 := by
  intro p hp
  have h : env51176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51175_51176 : H12AffineEnvironment.transform 10 0 env51175 = env51176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51175 == env51176) = true)

def env51177 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,32,1,35,48,0,53,0,33,33,16,2,40,17,0,49,48,0,20,32,37,33,32,513]

theorem envBound51177 : H12AffineFastState.Bounded env51177 := by
  intro p hp
  have h : env51177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51176_51177 : H12AffineEnvironment.transform 9 52 env51176 = env51177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51176 == env51177) = true)

theorem identity51177 : scanCanonicalize (H12AffineFastState.compose env51177 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51178 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,8,0,1,3,16,0,21,0,1,1,16,2,8,17,0,17,16,0,20,0,5,1,0,513]

theorem envBound51178 : H12AffineFastState.Bounded env51178 := by
  intro p hp
  have h : env51178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51177_51178 : H12AffineEnvironment.transform 4 0 env51177 = env51178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51177 == env51178) = true)

def leafEnv51178 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,8,0,1,3,16,0,21,0,1,1,16,2,21,8,1,17,0,17,16,0,20,0,5,1,5,3,0,513,1,1,0]

def active51178 : List Nat := [0,1,2,3,8]

def tree51178 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51178 : H12WitnessSearch.Good tree51178 := H12GlobalWitnessIndex.good

theorem leafIdentity51178 : H12AffineFastState.composeSystem env51178 rootObs = leafEnv51178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51178 rootObs == leafEnv51178) = true)

theorem terminalChecked51178 : H12PackedTerminal.terminalCheckFast leafEnv51178 active51178 tree51178 = true := by decide +kernel

def env51179 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,40,33,1,35,49,0,52,0,33,33,16,2,40,17,0,48,48,0,21,32,37,33,33,513]

theorem envBound51179 : H12AffineFastState.Bounded env51179 := by
  intro p hp
  have h : env51179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51176_51179 : H12AffineEnvironment.transform 9 53 env51176 = env51179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51176 == env51179) = true)

theorem identity51179 : scanCanonicalize (H12AffineFastState.compose env51179 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound51179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51180 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,40,33,1,35,49,0,52,0,33,33,16,2,40,17,0,48,48,0,21,32,37,33,33,11]

theorem envBound51180 : H12AffineFastState.Bounded env51180 := by
  intro p hp
  have h : env51180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51179_51180 : H12AffineEnvironment.transform 8 10 env51179 = env51180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env51179 == env51180) = true)

def leafEnv51180 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,40,33,1,35,49,0,52,0,33,33,16,2,20,40,1,17,0,48,48,0,21,32,37,33,5,35,33,11,1,33,0]

def active51180 : List Nat := [0,1,2,3,4]

def tree51180 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51180 : H12WitnessSearch.Good tree51180 := H12GlobalWitnessIndex.good

theorem leafIdentity51180 : H12AffineFastState.composeSystem env51180 rootObs = leafEnv51180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51180 rootObs == leafEnv51180) = true)

theorem terminalChecked51180 : H12PackedTerminal.terminalCheckFast leafEnv51180 active51180 tree51180 = true := by decide +kernel

def env51181 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,115734,272392,119830,98565,8193,17,121862,114966,17664,357643,119043,329731,257,21792,46093,62988]

theorem envBound51181 : H12AffineFastState.Bounded env51181 := by
  intro p hp
  have h : env51181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51161_51181 : H12AffineEnvironment.transform 6 9 env51161 = env51181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51161 == env51181) = true)

theorem identity51181 : scanCanonicalize (H12AffineFastState.compose env51181 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41263) := by decide +kernel

theorem selectedBound51181 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env51182 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41263,24860,262144,1025,32769,25913,272392,30009,8234,8193,17,32041,24633,17664,316452,28716,305452,257,21792,46093,62988]

theorem envBound51182 : H12AffineFastState.Bounded env51182 := by
  intro p hp
  have h : env51182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51181_51182 : H12AffineEnvironment.transform 15 41263 env51181 = env51182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41263 env51181 == env51182) = true)

theorem identity51182 : scanCanonicalize (H12AffineFastState.compose env51182 (packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound51182 : packedSelected [1,2,4,5,6,7,8,11,14,17,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env51183 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,41263,24860,43049,1025,32769,25913,32801,30009,8234,8193,17,32041,24633,17664,31757,28716,261,257,21792,46093,62988]

theorem envBound51183 : H12AffineFastState.Bounded env51183 := by
  intro p hp
  have h : env51183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51182_51183 : H12AffineEnvironment.transform 17 43049 env51182 = env51183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env51182 == env51183) = true)

theorem identity51183 : scanCanonicalize (H12AffineFastState.compose env51183 (packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51183 : packedSelected [0,1,2,6,7,8,11,12,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env51184 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,32768,41263,5392,43049,1025,32769,4405,32801,309,8234,8193,17,2341,5173,12556,2049,1056,261,257,8492,46093,33280]

theorem envBound51184 : H12AffineFastState.Bounded env51184 := by
  intro p hp
  have h : env51184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51183_51184 : H12AffineEnvironment.transform 13 13324 env51183 = env51184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51183 == env51184) = true)

theorem identity51184 : scanCanonicalize (H12AffineFastState.compose env51184 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 15372) := by decide +kernel

theorem selectedBound51184 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51185 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,15372,7459,5392,5157,1025,15373,4405,15405,309,8234,8193,17,2341,5173,12556,2049,1056,261,257,8492,2049,15884]

theorem envBound51185 : H12AffineFastState.Bounded env51185 := by
  intro p hp
  have h : env51185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51184_51185 : H12AffineEnvironment.transform 14 15372 env51184 = env51185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15372 env51184 == env51185) = true)

theorem identity51185 : scanCanonicalize (H12AffineFastState.compose env51185 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3385) := by decide +kernel

theorem selectedBound51185 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env51186 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,3385,6453,4405,7459,5392,5157,1025,4404,4405,4372,309,3347,3384,17,2341,5173,7221,2049,1056,261,257,3093,2049,4917]

theorem envBound51186 : H12AffineFastState.Bounded env51186 := by
  intro p hp
  have h : env51186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51185_51186 : H12AffineEnvironment.transform 12 3385 env51185 = env51186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3385 env51185 == env51186) = true)

theorem identity51186 : scanCanonicalize (H12AffineFastState.compose env51186 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51186 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env51187 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,2317,6453,4405,6423,4388,4113,53,4404,4405,4372,309,2343,2316,17,2341,4097,6145,2049,20,261,257,2081,2049,4917]

theorem envBound51187 : H12AffineFastState.Bounded env51187 := by
  intro p hp
  have h : env51187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51186_51187 : H12AffineEnvironment.transform 9 52 env51186 = env51187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51186 == env51187) = true)

theorem identity51187 : scanCanonicalize (H12AffineFastState.compose env51187 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound51187 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env51188 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2065,2317,292,2340,262,2357,2048,53,2341,2340,2309,309,2343,2316,17,2341,2064,16,2049,20,261,257,2081,2049,2852]

theorem envBound51188 : H12AffineFastState.Bounded env51188 := by
  intro p hp
  have h : env51188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51187_51188 : H12AffineEnvironment.transform 11 2065 env51187 = env51188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env51187 == env51188) = true)

theorem identity51188 : scanCanonicalize (H12AffineFastState.compose env51188 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51188 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51189 : List Nat := [2,4,8,1,32,0,9,256,512,37,2048,2048,2317,292,2340,262,2340,2048,36,2341,2340,2309,292,2343,2316,0,2341,2049,1,2049,5,261,257,2081,2049,2852]

theorem envBound51189 : H12AffineFastState.Bounded env51189 := by
  intro p hp
  have h : env51189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51188_51189 : H12AffineEnvironment.transform 3 1 env51188 = env51189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51188 == env51189) = true)

theorem identity51189 : scanCanonicalize (H12AffineFastState.compose env51189 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51189 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51190 : List Nat := [2,4,8,1,0,0,9,256,512,5,2048,2048,2317,260,2308,262,2308,2048,4,2309,2308,2309,260,2311,2316,0,2309,2049,1,2049,5,261,257,2049,2049,2820]

theorem envBound51190 : H12AffineFastState.Bounded env51190 := by
  intro p hp
  have h : env51190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51189_51190 : H12AffineEnvironment.transform 4 0 env51189 = env51190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51189 == env51190) = true)

theorem identity51190 : scanCanonicalize (H12AffineFastState.compose env51190 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51191 : List Nat := [2,4,8,1,0,0,9,5,512,5,2048,2048,2056,1,2049,3,2049,2048,4,2048,2049,2048,1,2050,2057,0,2048,2049,1,2049,5,0,4,2049,2049,2561]

theorem envBound51191 : H12AffineFastState.Bounded env51191 := by
  intro p hp
  have h : env51191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51190_51191 : H12AffineEnvironment.transform 7 5 env51190 = env51191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51190 == env51191) = true)

theorem identity51191 : scanCanonicalize (H12AffineFastState.compose env51191 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51191 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51192 : List Nat := [2,4,8,1,0,0,9,5,512,5,0,0,8,1,1,3,1,0,4,0,1,0,1,2,9,0,0,1,1,1,5,0,4,1,1,513]

theorem envBound51192 : H12AffineFastState.Bounded env51192 := by
  intro p hp
  have h : env51192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51191_51192 : H12AffineEnvironment.transform 10 0 env51191 = env51192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51191 == env51192) = true)

theorem identity51192 : scanCanonicalize (H12AffineFastState.compose env51192 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound51192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51193 : List Nat := [2,4,8,1,0,0,9,5,5,5,0,0,8,1,1,3,1,0,4,0,1,0,1,2,9,0,0,1,1,1,5,0,4,1,1,4]

theorem envBound51193 : H12AffineFastState.Bounded env51193 := by
  intro p hp
  have h : env51193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51192_51193 : H12AffineEnvironment.transform 8 5 env51192 = env51193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env51192 == env51193) = true)

theorem identity51193 : scanCanonicalize (H12AffineFastState.compose env51193 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound51193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51194 : List Nat := [2,4,5,1,0,0,4,5,5,5,0,0,5,1,1,3,1,0,4,0,1,0,1,2,4,0,0,1,1,1,5,0,4,1,1,4]

theorem envBound51194 : H12AffineFastState.Bounded env51194 := by
  intro p hp
  have h : env51194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51193_51194 : H12AffineEnvironment.transform 2 5 env51193 = env51194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env51193 == env51194) = true)

theorem identity51194 : scanCanonicalize (H12AffineFastState.compose env51194 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51194 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51195 : List Nat := [2,3,2,1,0,0,3,2,2,2,0,0,2,1,1,3,1,0,3,0,1,0,1,2,3,0,0,1,1,1,2,0,3,1,1,3]

theorem envBound51195 : H12AffineFastState.Bounded env51195 := by
  intro p hp
  have h : env51195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51194_51195 : H12AffineEnvironment.transform 1 3 env51194 = env51195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51194 == env51195) = true)

def env51196 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,4194304,2101249,2114835,8328,17,4584463,115103,17665,2404636,119042,4268162,257,2199998,2191386,63108]

theorem envBound51196 : H12AffineFastState.Bounded env51196 := by
  intro p hp
  have h : env51196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51143_51196 : H12AffineEnvironment.transform 22 2101249 env51143 = env51196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101249 env51143 == env51196) = true)

def env51197 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,121999,115103,17665,2404636,119042,329730,257,2199998,2191386,63108]

theorem envBound51197 : H12AffineFastState.Bounded env51197 := by
  intro p hp
  have h : env51197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51196_51197 : H12AffineEnvironment.transform 21 272512 env51196 = env51197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51196 == env51197) = true)

theorem identity51197 : scanCanonicalize (H12AffineFastState.compose env51197 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51197 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51198 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24860,262144,1025,32769,2097152,272512,2101249,2114835,8328,17,64645,57749,17665,2404636,61704,272392,257,2142644,2117648,63108]

theorem envBound51198 : H12AffineFastState.Bounded env51198 := by
  intro p hp
  have h : env51198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51197_51198 : H12AffineEnvironment.transform 15 8202 env51197 = env51198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51197 == env51198) = true)

def env51199 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16828,262144,1025,32769,2097152,264224,2101249,2114835,40,17,56357,49461,17665,2396604,53672,264360,257,2134292,2117648,54820]

theorem envBound51199 : H12AffineFastState.Bounded env51199 := by
  intro p hp
  have h : env51199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51198_51199 : H12AffineEnvironment.transform 12 160 env51198 = env51199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env51198 == env51199) = true)

theorem identity51199 : scanCanonicalize (H12AffineFastState.compose env51199 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound51199 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env51200 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,32768,170,16828,2476,1025,32769,2097152,396,2101249,2114835,40,17,56357,49461,17665,2136080,53672,260,257,2134292,2117648,54820]

theorem envBound51200 : H12AffineFastState.Bounded env51200 := by
  intro p hp
  have h : env51200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51199_51200 : H12AffineEnvironment.transform 17 2476 env51199 = env51200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env51199 == env51200) = true)

theorem identity51200 : scanCanonicalize (H12AffineFastState.compose env51200 (packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound51200 : packedSelected [2,5,6,9,11,12,14,15,16,18,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env51201 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5513,32768,170,5173,2476,1025,32769,2097152,396,2101249,2101402,40,17,35244,38076,4232,2136080,33825,260,257,2134292,2098585,33709]

theorem envBound51201 : H12AffineFastState.Bounded env51201 := by
  intro p hp
  have h : env51201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51200_51201 : H12AffineEnvironment.transform 13 5513 env51200 = env51201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env51200 == env51201) = true)

theorem identity51201 : scanCanonicalize (H12AffineFastState.compose env51201 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 4404) := by decide +kernel

theorem selectedBound51201 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env51202 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,5513,32768,170,5173,2476,1025,32769,4404,396,309,430,40,17,35244,38076,4232,35108,33825,260,257,32800,5293,33709]

theorem envBound51202 : H12AffineFastState.Bounded env51202 := by
  intro p hp
  have h : env51202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51201_51202 : H12AffineEnvironment.transform 20 4404 env51201 = env51202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4404 env51201 == env51202) = true)

theorem identity51202 : scanCanonicalize (H12AffineFastState.compose env51202 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound51202 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env51203 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,160,5156,32768,170,5173,2049,1025,32769,4249,33,152,3,40,17,34817,38076,4232,34953,33825,169,172,32800,5293,33280]

theorem envBound51203 : H12AffineFastState.Bounded env51203 := by
  intro p hp
  have h : env51203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51202_51203 : H12AffineEnvironment.transform 7 173 env51202 = env51203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env51202 == env51203) = true)

theorem identity51203 : scanCanonicalize (H12AffineFastState.compose env51203 (packedSelected [0,2,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 5157) := by decide +kernel

theorem selectedBound51203 : packedSelected [0,2,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51204 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,160,5156,5157,170,5173,2049,1025,5156,4249,33,152,3,40,17,7204,153,4232,7340,4100,169,172,5125,5293,5669]

theorem envBound51204 : H12AffineFastState.Bounded env51204 := by
  intro p hp
  have h : env51204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51203_51204 : H12AffineEnvironment.transform 14 5157 env51203 = env51204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5157 env51203 == env51204) = true)

theorem identity51204 : scanCanonicalize (H12AffineFastState.compose env51204 (packedSelected [0,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound51204 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env51205 : List Nat := [2,4,8,16,32,17,128,173,512,52,2048,4096,160,4112,4113,170,4097,2049,53,4112,4249,33,152,3,40,17,6160,153,4232,6296,4100,169,172,4145,4249,4625]

theorem envBound51205 : H12AffineFastState.Bounded env51205 := by
  intro p hp
  have h : env51205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51204_51205 : H12AffineEnvironment.transform 9 52 env51204 = env51205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51204 == env51205) = true)

theorem identity51205 : scanCanonicalize (H12AffineFastState.compose env51205 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51205 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51206 : List Nat := [2,4,8,16,32,17,128,173,512,52,1,4096,160,4112,4113,170,4097,0,53,4112,4249,33,152,3,40,17,4113,153,4232,4249,4100,169,172,4145,4249,4625]

theorem envBound51206 : H12AffineFastState.Bounded env51206 := by
  intro p hp
  have h : env51206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51205_51206 : H12AffineEnvironment.transform 10 1 env51205 = env51206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51205 == env51206) = true)

theorem identity51206 : scanCanonicalize (H12AffineFastState.compose env51206 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound51206 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env51207 : List Nat := [2,4,8,16,32,17,128,173,512,52,1,17,160,1,0,170,16,0,53,1,136,33,152,3,40,17,0,153,153,136,21,169,172,32,136,512]

theorem envBound51207 : H12AffineFastState.Bounded env51207 := by
  intro p hp
  have h : env51207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51206_51207 : H12AffineEnvironment.transform 11 17 env51206 = env51207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51206 == env51207) = true)

theorem identity51207 : scanCanonicalize (H12AffineFastState.compose env51207 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51207 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51208 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,41,1,0,35,16,0,53,1,1,33,17,3,40,17,0,16,16,1,21,32,37,32,1,512]

theorem envBound51208 : H12AffineFastState.Bounded env51208 := by
  intro p hp
  have h : env51208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51207_51208 : H12AffineEnvironment.transform 6 9 env51207 = env51208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51207 == env51208) = true)

theorem identity51208 : scanCanonicalize (H12AffineFastState.compose env51208 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound51208 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51209 : List Nat := [2,4,8,16,32,17,9,36,4,52,1,17,41,1,0,35,16,0,53,1,1,33,17,3,40,17,0,16,16,1,21,32,37,32,1,4]

theorem envBound51209 : H12AffineFastState.Bounded env51209 := by
  intro p hp
  have h : env51209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51208_51209 : H12AffineEnvironment.transform 8 4 env51208 = env51209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env51208 == env51209) = true)

theorem identity51209 : scanCanonicalize (H12AffineFastState.compose env51209 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound51209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51210 : List Nat := [2,4,8,7,32,6,9,36,4,35,1,6,41,1,0,35,7,0,34,1,1,33,6,3,40,6,0,7,7,1,2,32,37,32,1,4]

theorem envBound51210 : H12AffineFastState.Bounded env51210 := by
  intro p hp
  have h : env51210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51209_51210 : H12AffineEnvironment.transform 3 7 env51209 = env51210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env51209 == env51210) = true)

theorem identity51210 : scanCanonicalize (H12AffineFastState.compose env51210 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound51210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51211 : List Nat := [2,4,8,7,6,6,9,2,4,5,1,6,15,1,0,5,7,0,4,1,1,7,6,3,14,6,0,7,7,1,2,6,3,6,1,4]

theorem envBound51211 : H12AffineFastState.Bounded env51211 := by
  intro p hp
  have h : env51211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51210_51211 : H12AffineEnvironment.transform 4 6 env51210 = env51211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env51210 == env51211) = true)

theorem identity51211 : scanCanonicalize (H12AffineFastState.compose env51211 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound51211 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51212 : List Nat := [2,4,4,7,6,6,5,2,4,5,1,6,3,1,0,5,7,0,4,1,1,7,6,3,2,6,0,7,7,1,2,6,3,6,1,4]

theorem envBound51212 : H12AffineFastState.Bounded env51212 := by
  intro p hp
  have h : env51212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51211_51212 : H12AffineEnvironment.transform 2 4 env51211 = env51212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env51211 == env51212) = true)

theorem identity51212 : scanCanonicalize (H12AffineFastState.compose env51212 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound51212 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env51213 : List Nat := [2,3,3,0,1,1,2,2,3,2,1,1,3,1,0,2,0,0,3,1,1,0,1,3,2,1,0,0,0,1,2,1,3,1,1,3]

theorem envBound51213 : H12AffineFastState.Bounded env51213 := by
  intro p hp
  have h : env51213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51212_51213 : H12AffineEnvironment.transform 1 3 env51212 = env51213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env51212 == env51213) = true)

def env51214 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16829,262144,1025,32769,2097152,264225,2101249,2114835,41,17,56356,49460,17665,2396605,53673,264361,257,2134293,2117648,54821]

theorem envBound51214 : H12AffineFastState.Bounded env51214 := by
  intro p hp
  have h : env51214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51198_51214 : H12AffineEnvironment.transform 12 161 env51198 = env51214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env51198 == env51214) = true)

theorem identity51214 : scanCanonicalize (H12AffineFastState.compose env51214 (packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound51214 : packedSelected [7,8,10,12,14,15,16,17,27,28] rootPS < 2^1333 := by decide +kernel

def env51215 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,32768,171,16829,2340,1025,32769,2097152,261,2101249,2114835,41,17,56356,49460,17665,2136217,53673,397,257,2134293,2117648,54821]

theorem envBound51215 : H12AffineFastState.Bounded env51215 := by
  intro p hp
  have h : env51215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51214_51215 : H12AffineEnvironment.transform 17 2340 env51214 = env51215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env51214 == env51215) = true)

theorem identity51215 : scanCanonicalize (H12AffineFastState.compose env51215 (packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound51215 : packedSelected [0,2,3,4,6,7,9,10,11,14,17,19,23,24] rootPS < 2^1333 := by decide +kernel

def env51216 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,161,16384,429,171,16829,2340,1025,428,2097152,261,2101249,2114835,41,17,23945,16537,17665,2103604,20484,397,257,2101432,2117648,22408]

theorem envBound51216 : H12AffineFastState.Bounded env51216 := by
  intro p hp
  have h : env51216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51215_51216 : H12AffineEnvironment.transform 14 429 env51215 = env51216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env51215 == env51216) = true)

theorem identity51216 : scanCanonicalize (H12AffineFastState.compose env51216 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound51216 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51217 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,16384,137,171,16537,2048,1025,136,2097152,33,2101249,2114615,41,17,23725,16537,17445,2103312,20484,169,37,2101432,2117648,22188]

theorem envBound51217 : H12AffineFastState.Bounded env51217 := by
  intro p hp
  have h : env51217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51216_51217 : H12AffineEnvironment.transform 7 36 env51216 = env51217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env51216 == env51217) = true)

theorem identity51217 : scanCanonicalize (H12AffineFastState.compose env51217 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound51217 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env51218 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,16384,137,171,16537,2048,1025,136,17596,33,21693,139,41,17,23725,16537,17445,23724,20484,169,37,21508,5292,22188]

theorem envBound51218 : H12AffineFastState.Bounded env51218 := by
  intro p hp
  have h : env51218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51217_51218 : H12AffineEnvironment.transform 20 17596 env51217 = env51218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env51217 == env51218) = true)

theorem identity51218 : scanCanonicalize (H12AffineFastState.compose env51218 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound51218 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env51219 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2200,161,16384,137,171,16537,2048,1025,136,17596,33,19493,139,41,17,17461,16537,17445,17460,18588,169,37,19612,3124,20020]

theorem envBound51219 : H12AffineFastState.Bounded env51219 := by
  intro p hp
  have h : env51219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51218_51219 : H12AffineEnvironment.transform 11 2200 env51218 = env51219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env51218 == env51219) = true)

theorem identity51219 : scanCanonicalize (H12AffineFastState.compose env51219 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound51219 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env51220 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2200,161,3125,137,171,3244,2048,1025,136,2185,33,16,139,41,17,2048,3244,2064,2049,1193,169,37,169,3124,513]

theorem envBound51220 : H12AffineFastState.Bounded env51220 := by
  intro p hp
  have h : env51220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51219_51220 : H12AffineEnvironment.transform 13 3125 env51219 = env51220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env51219 == env51220) = true)

theorem identity51220 : scanCanonicalize (H12AffineFastState.compose env51220 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound51220 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51221 : List Nat := [2,4,8,16,32,17,128,36,512,53,2048,2200,161,2048,137,171,2201,2048,52,136,2185,33,16,139,41,17,2048,2201,2064,2049,156,169,37,169,2049,513]

theorem envBound51221 : H12AffineFastState.Bounded env51221 := by
  intro p hp
  have h : env51221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51220_51221 : H12AffineEnvironment.transform 9 53 env51220 = env51221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51220 == env51221) = true)

theorem identity51221 : scanCanonicalize (H12AffineFastState.compose env51221 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51221 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51222 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2065,40,2048,0,34,2064,2048,52,1,2048,33,16,2,41,17,2048,2064,2064,2049,21,32,37,32,2049,513]

theorem envBound51222 : H12AffineFastState.Bounded env51222 := by
  intro p hp
  have h : env51222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51221_51222 : H12AffineEnvironment.transform 6 9 env51221 = env51222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51221 == env51222) = true)

theorem identity51222 : scanCanonicalize (H12AffineFastState.compose env51222 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 565) := by decide +kernel

theorem selectedBound51222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51223 : List Nat := [2,4,8,16,32,17,9,36,512,53,565,548,40,565,0,34,549,565,52,1,565,33,16,2,41,17,565,549,549,564,21,32,37,32,564,513]

theorem envBound51223 : H12AffineFastState.Bounded env51223 := by
  intro p hp
  have h : env51223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51222_51223 : H12AffineEnvironment.transform 10 565 env51222 = env51223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 565 env51222 == env51223) = true)

theorem identity51223 : scanCanonicalize (H12AffineFastState.compose env51223 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound51223 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51224 : List Nat := [2,4,8,13,32,12,9,36,512,40,552,548,40,552,0,34,549,552,41,1,552,33,13,2,41,12,552,549,549,553,8,32,37,32,553,513]

theorem envBound51224 : H12AffineFastState.Bounded env51224 := by
  intro p hp
  have h : env51224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51223_51224 : H12AffineEnvironment.transform 3 13 env51223 = env51224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env51223 == env51224) = true)

theorem identity51224 : scanCanonicalize (H12AffineFastState.compose env51224 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound51224 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51225 : List Nat := [2,4,8,13,32,12,9,36,41,40,1,13,40,1,0,34,12,1,41,1,1,33,13,2,41,12,1,12,12,0,8,32,37,32,0,40]

theorem envBound51225 : H12AffineFastState.Bounded env51225 := by
  intro p hp
  have h : env51225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51224_51225 : H12AffineEnvironment.transform 8 41 env51224 = env51225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env51224 == env51225) = true)

theorem identity51225 : scanCanonicalize (H12AffineFastState.compose env51225 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound51225 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51226 : List Nat := [2,4,8,13,3,12,9,7,10,11,1,13,11,1,0,1,12,1,10,1,1,2,13,2,10,12,1,12,12,0,8,3,6,3,0,11]

theorem envBound51226 : H12AffineFastState.Bounded env51226 := by
  intro p hp
  have h : env51226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51225_51226 : H12AffineEnvironment.transform 4 3 env51225 = env51226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env51225 == env51226) = true)

theorem identity51226 : scanCanonicalize (H12AffineFastState.compose env51226 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound51226 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51227 : List Nat := [0,4,8,13,1,12,9,5,8,9,1,13,9,1,0,1,12,1,8,1,1,0,13,0,8,12,1,12,12,0,8,1,4,1,0,9]

theorem envBound51227 : H12AffineFastState.Bounded env51227 := by
  intro p hp
  have h : env51227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51226_51227 : H12AffineEnvironment.transform 0 0 env51226 = env51227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env51226 == env51227) = true)

def env51228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,2097152,272513,2101249,2114835,8328,17,121998,115103,17665,2404636,119042,329731,257,2199998,2191386,63108]

theorem envBound51228 : H12AffineFastState.Bounded env51228 := by
  intro p hp
  have h : env51228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51196_51228 : H12AffineEnvironment.transform 21 272513 env51196 = env51228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51196 == env51228) = true)

theorem identity51228 : scanCanonicalize (H12AffineFastState.compose env51228 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77850) := by decide +kernel

theorem selectedBound51228 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51229 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121998,115103,17665,360710,119042,329731,257,41380,16384,63108]

theorem envBound51229 : H12AffineFastState.Bounded env51229 := by
  intro p hp
  have h : env51229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51228_51229 : H12AffineEnvironment.transform 20 77850 env51228 = env51229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77850 env51228 == env51229) = true)

def env51230 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121998,115103,17665,360710,119042,329731,257,41348,16384,63108]

theorem envBound51230 : H12AffineFastState.Bounded env51230 := by
  intro p hp
  have h : env51230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51229_51230 : H12AffineEnvironment.transform 4 0 env51229 = env51230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51229 == env51230) = true)

theorem identity51230 : scanCanonicalize (H12AffineFastState.compose env51230 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 2308) := by decide +kernel

theorem selectedBound51230 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env51231 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,2308,1025,32769,77850,8581,73755,95497,8328,17,121998,115103,17665,100354,119042,65799,257,41348,16384,63108]

theorem envBound51231 : H12AffineFastState.Bounded env51231 := by
  intro p hp
  have h : env51231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51230_51231 : H12AffineEnvironment.transform 17 2308 env51230 = env51231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2308 env51230 == env51231) = true)

theorem identity51231 : scanCanonicalize (H12AffineFastState.compose env51231 (packedSelected [1,2,3,4,6,7,9,16,19,20,24,26,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51231 : packedSelected [1,2,3,4,6,7,9,16,19,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env51232 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,2308,1025,32769,77850,8461,73755,95497,8192,17,121862,114967,17665,100354,119042,65799,257,41228,16384,62988]

theorem envBound51232 : H12AffineFastState.Bounded env51232 := by
  intro p hp
  have h : env51232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51231_51232 : H12AffineEnvironment.transform 6 8 env51231 = env51232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51231 == env51232) = true)

theorem identity51232 : scanCanonicalize (H12AffineFastState.compose env51232 (packedSelected [1,2,4,6,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51232 : packedSelected [1,2,4,6,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env51233 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,24860,2308,1025,8460,77850,8461,73755,95497,8192,17,97547,90138,17665,76047,94223,65799,257,1,16384,22273]

theorem envBound51233 : H12AffineFastState.Bounded env51233 := by
  intro p hp
  have h : env51233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51232_51233 : H12AffineEnvironment.transform 14 8461 env51232 = env51233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env51232 == env51233) = true)

theorem identity51233 : scanCanonicalize (H12AffineFastState.compose env51233 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound51233 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env51234 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,16384,8461,21511,24860,2308,1025,8460,25629,8461,29724,8462,8192,17,10508,13341,17665,32008,9224,21760,257,1,16384,22273]

theorem envBound51234 : H12AffineFastState.Bounded env51234 := by
  intro p hp
  have h : env51234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51233_51234 : H12AffineEnvironment.transform 15 21511 env51233 = env51234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env51233 == env51234) = true)

theorem identity51234 : scanCanonicalize (H12AffineFastState.compose env51234 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51234 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51235 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,16384,1,21511,16400,2308,1025,0,17681,1,21776,2,268,17,2048,5393,17665,23556,1284,21760,257,1,16384,22273]

theorem envBound51235 : H12AffineFastState.Bounded env51235 := by
  intro p hp
  have h : env51235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51234_51235 : H12AffineEnvironment.transform 12 268 env51234 = env51235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51234 == env51235) = true)

theorem identity51235 : scanCanonicalize (H12AffineFastState.compose env51235 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound51235 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51236 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2308,1025,0,4113,1,16,2,268,17,2048,5393,4097,2308,1284,0,257,1,5376,513]

theorem envBound51236 : H12AffineFastState.Bounded env51236 := by
  intro p hp
  have h : env51236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51235_51236 : H12AffineEnvironment.transform 13 5376 env51235 = env51236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env51235 == env51236) = true)

theorem identity51236 : scanCanonicalize (H12AffineFastState.compose env51236 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51237 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,1,2,5141,2049,1025,0,4113,1,16,2,9,17,2048,5140,4097,2049,1025,0,4,1,5125,513]

theorem envBound51237 : H12AffineFastState.Bounded env51237 := by
  intro p hp
  have h : env51237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51236_51237 : H12AffineEnvironment.transform 7 5 env51236 = env51237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51236 == env51237) = true)

def env51238 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,1,2,1029,2049,1025,0,1,1,16,2,9,17,2048,1028,17,2049,1025,0,4,1,1045,513]

theorem envBound51238 : H12AffineFastState.Bounded env51238 := by
  intro p hp
  have h : env51238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51237_51238 : H12AffineEnvironment.transform 11 16 env51237 = env51238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51237 == env51238) = true)

theorem identity51238 : scanCanonicalize (H12AffineFastState.compose env51238 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51239 : List Nat := [2,4,8,16,0,17,8,5,17,1024,2048,16,9,1045,1,2,1029,2049,1025,0,1,1,16,2,9,17,2048,1028,17,2049,1025,0,4,1,1045,16]

theorem envBound51239 : H12AffineFastState.Bounded env51239 := by
  intro p hp
  have h : env51239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51238_51239 : H12AffineEnvironment.transform 8 17 env51238 = env51239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51238 == env51239) = true)

def env51240 : List Nat := [2,4,8,16,0,17,8,5,17,20,2048,16,9,1,1,2,17,2049,21,0,1,1,16,2,9,17,2048,16,17,2049,21,0,4,1,1,16]

theorem envBound51240 : H12AffineFastState.Bounded env51240 := by
  intro p hp
  have h : env51240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51239_51240 : H12AffineEnvironment.transform 9 20 env51239 = env51240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51239 == env51240) = true)

theorem identity51240 : scanCanonicalize (H12AffineFastState.compose env51240 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51241 : List Nat := [2,4,8,16,0,17,8,5,17,20,1,16,9,1,1,2,17,0,21,0,1,1,16,2,9,17,1,16,17,0,21,0,4,1,1,16]

theorem envBound51241 : H12AffineFastState.Bounded env51241 := by
  intro p hp
  have h : env51241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51240_51241 : H12AffineEnvironment.transform 10 1 env51240 = env51241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51240 == env51241) = true)

def leafEnv51241 : List Nat := [2,4,8,16,0,17,8,5,17,20,1,16,9,1,1,2,17,0,21,0,1,1,16,2,20,9,1,17,1,16,17,0,21,0,4,1,5,2,1,16,1,1,0]

def active51241 : List Nat := [0,1,2,3]

def tree51241 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51241 : H12WitnessSearch.Good tree51241 := H12GlobalWitnessIndex.good

theorem leafIdentity51241 : H12AffineFastState.composeSystem env51241 rootObs = leafEnv51241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51241 rootObs == leafEnv51241) = true)

theorem terminalChecked51241 : H12PackedTerminal.terminalCheckFast leafEnv51241 active51241 tree51241 = true := by decide +kernel

def env51242 : List Nat := [2,4,8,16,0,17,8,5,17,21,2048,16,9,0,1,2,16,2049,20,0,1,1,16,2,9,17,2048,17,17,2049,20,0,4,1,0,16]

theorem envBound51242 : H12AffineFastState.Bounded env51242 := by
  intro p hp
  have h : env51242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51239_51242 : H12AffineEnvironment.transform 9 21 env51239 = env51242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51239 == env51242) = true)

theorem identity51242 : scanCanonicalize (H12AffineFastState.compose env51242 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound51242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51243 : List Nat := [2,4,8,16,0,17,8,5,17,21,26,16,9,0,1,2,16,27,20,0,1,1,16,2,9,17,26,17,17,27,20,0,4,1,0,16]

theorem envBound51243 : H12AffineFastState.Bounded env51243 := by
  intro p hp
  have h : env51243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51242_51243 : H12AffineEnvironment.transform 10 26 env51242 = env51243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env51242 == env51243) = true)

def leafEnv51243 : List Nat := [2,4,8,16,0,17,8,5,17,21,26,16,9,0,1,2,16,27,20,0,1,1,16,2,21,9,1,17,26,17,17,27,20,0,4,1,5,2,0,16,1,1,0]

def active51243 : List Nat := [0,1,2,3]

def tree51243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51243 : H12WitnessSearch.Good tree51243 := H12GlobalWitnessIndex.good

theorem leafIdentity51243 : H12AffineFastState.composeSystem env51243 rootObs = leafEnv51243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51243 rootObs == leafEnv51243) = true)

theorem terminalChecked51243 : H12PackedTerminal.terminalCheckFast leafEnv51243 active51243 tree51243 = true := by decide +kernel

def env51244 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,1,2,1028,2049,1025,0,0,1,16,2,9,17,2048,1029,16,2049,1025,0,4,1,1044,513]

theorem envBound51244 : H12AffineFastState.Bounded env51244 := by
  intro p hp
  have h : env51244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51237_51244 : H12AffineEnvironment.transform 11 17 env51237 = env51244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51237 == env51244) = true)

theorem identity51244 : scanCanonicalize (H12AffineFastState.compose env51244 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound51244 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51245 : List Nat := [2,4,8,16,0,17,8,5,512,516,2048,17,9,528,1,2,512,2049,517,0,0,1,16,2,9,17,2048,513,16,2049,517,0,4,1,528,513]

theorem envBound51245 : H12AffineFastState.Bounded env51245 := by
  intro p hp
  have h : env51245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51244_51245 : H12AffineEnvironment.transform 9 516 env51244 = env51245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env51244 == env51245) = true)

def env51246 : List Nat := [2,4,8,16,0,17,8,5,16,20,2048,17,9,0,1,2,16,2049,21,0,0,1,16,2,9,17,2048,17,16,2049,21,0,4,1,0,17]

theorem envBound51246 : H12AffineFastState.Bounded env51246 := by
  intro p hp
  have h : env51246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51245_51246 : H12AffineEnvironment.transform 8 16 env51245 = env51246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51245 == env51246) = true)

theorem identity51246 : scanCanonicalize (H12AffineFastState.compose env51246 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51247 : List Nat := [2,4,8,16,0,17,8,5,16,20,0,17,9,0,1,2,16,1,21,0,0,1,16,2,9,17,0,17,16,1,21,0,4,1,0,17]

theorem envBound51247 : H12AffineFastState.Bounded env51247 := by
  intro p hp
  have h : env51247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51246_51247 : H12AffineEnvironment.transform 10 0 env51246 = env51247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51246 == env51247) = true)

def leafEnv51247 : List Nat := [2,4,8,16,0,17,8,5,16,20,0,17,9,0,1,2,16,1,21,0,0,1,16,2,20,9,1,17,0,17,16,1,21,0,4,1,5,2,0,17,1,0,0]

def active51247 : List Nat := [0,1,2,3]

def tree51247 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51247 : H12WitnessSearch.Good tree51247 := H12GlobalWitnessIndex.good

theorem leafIdentity51247 : H12AffineFastState.composeSystem env51247 rootObs = leafEnv51247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51247 rootObs == leafEnv51247) = true)

theorem terminalChecked51247 : H12PackedTerminal.terminalCheckFast leafEnv51247 active51247 tree51247 = true := by decide +kernel

def env51248 : List Nat := [2,4,8,16,0,17,8,5,17,21,2048,17,9,1,1,2,17,2049,20,0,0,1,16,2,9,17,2048,16,16,2049,20,0,4,1,1,16]

theorem envBound51248 : H12AffineFastState.Bounded env51248 := by
  intro p hp
  have h : env51248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51245_51248 : H12AffineEnvironment.transform 8 17 env51245 = env51248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51245 == env51248) = true)

theorem identity51248 : scanCanonicalize (H12AffineFastState.compose env51248 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound51248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51249 : List Nat := [2,4,8,16,0,17,8,5,17,21,26,17,9,1,1,2,17,27,20,0,0,1,16,2,9,17,26,16,16,27,20,0,4,1,1,16]

theorem envBound51249 : H12AffineFastState.Bounded env51249 := by
  intro p hp
  have h : env51249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51248_51249 : H12AffineEnvironment.transform 10 26 env51248 = env51249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env51248 == env51249) = true)

def leafEnv51249 : List Nat := [2,4,8,16,0,17,8,5,17,21,26,17,9,1,1,2,17,27,20,0,0,1,16,2,21,9,1,17,26,16,16,27,20,0,4,1,5,2,1,16,1,0,0]

def active51249 : List Nat := [0,1,2,3]

def tree51249 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51249 : H12WitnessSearch.Good tree51249 := H12GlobalWitnessIndex.good

theorem leafIdentity51249 : H12AffineFastState.composeSystem env51249 rootObs = leafEnv51249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51249 rootObs == leafEnv51249) = true)

theorem terminalChecked51249 : H12PackedTerminal.terminalCheckFast leafEnv51249 active51249 tree51249 = true := by decide +kernel

def env51250 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,262144,1025,32769,77850,272513,73755,95497,8328,17,121998,115103,17665,360710,119042,329731,257,41349,16384,63108]

theorem envBound51250 : H12AffineFastState.Bounded env51250 := by
  intro p hp
  have h : env51250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51229_51250 : H12AffineEnvironment.transform 4 1 env51229 = env51250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51229 == env51250) = true)

theorem identity51250 : scanCanonicalize (H12AffineFastState.compose env51250 (packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64896) := by decide +kernel

theorem selectedBound51250 : packedSelected [1,2,5,6,8,10,11,16,19,20,24,26,31,32] rootPS < 2^1333 := by decide +kernel

def env51251 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,24860,64896,1025,32769,77850,54529,73755,95497,8328,17,121998,115103,17665,97414,119042,128387,257,41349,16384,63108]

theorem envBound51251 : H12AffineFastState.Bounded env51251 := by
  intro p hp
  have h : env51251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51250_51251 : H12AffineEnvironment.transform 17 64896 env51250 = env51251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64896 env51250 == env51251) = true)

theorem identity51251 : scanCanonicalize (H12AffineFastState.compose env51251 (packedSelected [2,3,5,6,8,17,19,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51251 : packedSelected [2,3,5,6,8,17,19,26,28] rootPS < 2^1333 := by decide +kernel

def env51252 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,24860,64896,1025,32769,4113,54529,16,21762,8328,17,64645,57748,17665,23693,61705,54664,257,41349,16384,63108]

theorem envBound51252 : H12AffineFastState.Bounded env51252 := by
  intro p hp
  have h : env51252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51251_51252 : H12AffineEnvironment.transform 15 8203 env51251 = env51252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51251 == env51252) = true)

theorem identity51252 : scanCanonicalize (H12AffineFastState.compose env51252 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound51252 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env51253 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,16384,8461,8203,24860,23693,1025,8460,4113,29708,16,21762,8328,17,23944,16537,17665,23693,20484,29829,257,136,16384,22409]

theorem envBound51253 : H12AffineFastState.Bounded env51253 := by
  intro p hp
  have h : env51253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51252_51253 : H12AffineEnvironment.transform 14 8461 env51252 = env51253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env51252 == env51253) = true)

theorem identity51253 : scanCanonicalize (H12AffineFastState.compose env51253 (packedSelected [3,4,5,6,10,12,14,15,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound51253 : packedSelected [3,4,5,6,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env51254 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,8192,13324,8461,8203,5392,10369,1025,8460,4113,0,16,8462,8328,17,10628,13461,12557,10369,9224,137,257,136,13324,9093]

theorem envBound51254 : H12AffineFastState.Bounded env51254 := by
  intro p hp
  have h : env51254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51253_51254 : H12AffineEnvironment.transform 13 13324 env51253 = env51254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env51253 == env51254) = true)

theorem identity51254 : scanCanonicalize (H12AffineFastState.compose env51254 (packedSelected [0,1,4,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound51254 : packedSelected [0,1,4,8,12] rootPS < 2^1333 := by decide +kernel

def env51255 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,8192,13324,8461,8203,5392,10249,1025,8460,4113,0,16,8462,8192,17,10508,13341,12557,10249,9224,1,257,0,13324,8973]

theorem envBound51255 : H12AffineFastState.Bounded env51255 := by
  intro p hp
  have h : env51255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51254_51255 : H12AffineEnvironment.transform 6 8 env51254 = env51255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51254 == env51255) = true)

theorem identity51255 : scanCanonicalize (H12AffineFastState.compose env51255 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51255 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51256 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,268,5376,1,263,5392,2309,1025,0,4113,0,16,2,268,17,2048,5393,4097,2309,1284,1,257,0,5376,513]

theorem envBound51256 : H12AffineFastState.Bounded env51256 := by
  intro p hp
  have h : env51256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51255_51256 : H12AffineEnvironment.transform 12 268 env51255 = env51256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51255 == env51256) = true)

theorem identity51256 : scanCanonicalize (H12AffineFastState.compose env51256 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51257 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,8,5124,1,3,5140,2049,1025,0,4113,0,16,2,8,17,2048,5141,4097,2049,1024,1,5,0,5124,513]

theorem envBound51257 : H12AffineFastState.Bounded env51257 := by
  intro p hp
  have h : env51257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51256_51257 : H12AffineEnvironment.transform 7 4 env51256 = env51257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51256 == env51257) = true)

def env51258 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,16,8,1044,1,3,1028,2049,1025,0,1,0,16,2,8,17,2048,1029,17,2049,1024,1,5,0,1044,513]

theorem envBound51258 : H12AffineFastState.Bounded env51258 := by
  intro p hp
  have h : env51258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51257_51258 : H12AffineEnvironment.transform 11 16 env51257 = env51258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51257 == env51258) = true)

theorem identity51258 : scanCanonicalize (H12AffineFastState.compose env51258 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound51258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51259 : List Nat := [2,4,8,16,1,17,8,4,512,517,2048,16,8,529,1,3,513,2049,516,0,1,0,16,2,8,17,2048,512,17,2049,517,1,5,0,529,513]

theorem envBound51259 : H12AffineFastState.Bounded env51259 := by
  intro p hp
  have h : env51259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51258_51259 : H12AffineEnvironment.transform 9 517 env51258 = env51259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env51258 == env51259) = true)

def env51260 : List Nat := [2,4,8,16,1,17,8,4,16,21,2048,16,8,1,1,3,17,2049,20,0,1,0,16,2,8,17,2048,16,17,2049,21,1,5,0,1,17]

theorem envBound51260 : H12AffineFastState.Bounded env51260 := by
  intro p hp
  have h : env51260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51259_51260 : H12AffineEnvironment.transform 8 16 env51259 = env51260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51259 == env51260) = true)

theorem identity51260 : scanCanonicalize (H12AffineFastState.compose env51260 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound51260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51261 : List Nat := [2,4,8,16,1,17,8,4,16,21,1,16,8,1,1,3,17,0,20,0,1,0,16,2,8,17,1,16,17,0,21,1,5,0,1,17]

theorem envBound51261 : H12AffineFastState.Bounded env51261 := by
  intro p hp
  have h : env51261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51260_51261 : H12AffineEnvironment.transform 10 1 env51260 = env51261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env51260 == env51261) = true)

def leafEnv51261 : List Nat := [2,4,8,16,1,17,8,4,16,21,1,16,8,1,1,3,17,0,20,0,1,0,16,2,20,8,1,17,1,16,17,0,21,1,5,0,5,3,1,17,1,1,0]

def active51261 : List Nat := [0,1,2,3]

def tree51261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51261 : H12WitnessSearch.Good tree51261 := H12GlobalWitnessIndex.good

theorem leafIdentity51261 : H12AffineFastState.composeSystem env51261 rootObs = leafEnv51261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51261 rootObs == leafEnv51261) = true)

theorem terminalChecked51261 : H12PackedTerminal.terminalCheckFast leafEnv51261 active51261 tree51261 = true := by decide +kernel

def env51262 : List Nat := [2,4,8,16,1,17,8,4,17,20,2048,16,8,0,1,3,16,2049,21,0,1,0,16,2,8,17,2048,17,17,2049,20,1,5,0,0,16]

theorem envBound51262 : H12AffineFastState.Bounded env51262 := by
  intro p hp
  have h : env51262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51259_51262 : H12AffineEnvironment.transform 8 17 env51259 = env51262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51259 == env51262) = true)

theorem identity51262 : scanCanonicalize (H12AffineFastState.compose env51262 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound51262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51263 : List Nat := [2,4,8,16,1,17,8,4,17,20,26,16,8,0,1,3,16,27,21,0,1,0,16,2,8,17,26,17,17,27,20,1,5,0,0,16]

theorem envBound51263 : H12AffineFastState.Bounded env51263 := by
  intro p hp
  have h : env51263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51262_51263 : H12AffineEnvironment.transform 10 26 env51262 = env51263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env51262 == env51263) = true)

def leafEnv51263 : List Nat := [2,4,8,16,1,17,8,4,17,20,26,16,8,0,1,3,16,27,21,0,1,0,16,2,21,8,1,17,26,17,17,27,20,1,5,0,5,3,0,16,1,1,0]

def active51263 : List Nat := [0,1,2,3]

def tree51263 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51263 : H12WitnessSearch.Good tree51263 := H12GlobalWitnessIndex.good

theorem leafIdentity51263 : H12AffineFastState.composeSystem env51263 rootObs = leafEnv51263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51263 rootObs == leafEnv51263) = true)

theorem terminalChecked51263 : H12PackedTerminal.terminalCheckFast leafEnv51263 active51263 tree51263 = true := by decide +kernel

def env51264 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,17,8,1045,1,3,1029,2049,1025,0,0,0,16,2,8,17,2048,1028,16,2049,1024,1,5,0,1045,513]

theorem envBound51264 : H12AffineFastState.Bounded env51264 := by
  intro p hp
  have h : env51264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51257_51264 : H12AffineEnvironment.transform 11 17 env51257 = env51264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51257 == env51264) = true)

theorem identity51264 : scanCanonicalize (H12AffineFastState.compose env51264 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound51264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51265 : List Nat := [2,4,8,16,1,17,8,4,17,1024,2048,17,8,1045,1,3,1029,2049,1025,0,0,0,16,2,8,17,2048,1028,16,2049,1024,1,5,0,1045,16]

theorem envBound51265 : H12AffineFastState.Bounded env51265 := by
  intro p hp
  have h : env51265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51264_51265 : H12AffineEnvironment.transform 8 17 env51264 = env51265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51264 == env51265) = true)

def env51266 : List Nat := [2,4,8,16,1,17,8,4,17,20,2048,17,8,1,1,3,17,2049,21,0,0,0,16,2,8,17,2048,16,16,2049,20,1,5,0,1,16]

theorem envBound51266 : H12AffineFastState.Bounded env51266 := by
  intro p hp
  have h : env51266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51265_51266 : H12AffineEnvironment.transform 9 20 env51265 = env51266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51265 == env51266) = true)

theorem identity51266 : scanCanonicalize (H12AffineFastState.compose env51266 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound51266 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51267 : List Nat := [2,4,8,16,1,17,8,4,17,20,26,17,8,1,1,3,17,27,21,0,0,0,16,2,8,17,26,16,16,27,20,1,5,0,1,16]

theorem envBound51267 : H12AffineFastState.Bounded env51267 := by
  intro p hp
  have h : env51267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51266_51267 : H12AffineEnvironment.transform 10 26 env51266 = env51267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env51266 == env51267) = true)

def leafEnv51267 : List Nat := [2,4,8,16,1,17,8,4,17,20,26,17,8,1,1,3,17,27,21,0,0,0,16,2,21,8,1,17,26,16,16,27,20,1,5,0,5,3,1,16,1,0,0]

def active51267 : List Nat := [0,1,2,3]

def tree51267 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51267 : H12WitnessSearch.Good tree51267 := H12GlobalWitnessIndex.good

theorem leafIdentity51267 : H12AffineFastState.composeSystem env51267 rootObs = leafEnv51267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51267 rootObs == leafEnv51267) = true)

theorem terminalChecked51267 : H12PackedTerminal.terminalCheckFast leafEnv51267 active51267 tree51267 = true := by decide +kernel

def env51268 : List Nat := [2,4,8,16,1,17,8,4,17,21,2048,17,8,0,1,3,16,2049,20,0,0,0,16,2,8,17,2048,17,16,2049,21,1,5,0,0,16]

theorem envBound51268 : H12AffineFastState.Bounded env51268 := by
  intro p hp
  have h : env51268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51265_51268 : H12AffineEnvironment.transform 9 21 env51265 = env51268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env51265 == env51268) = true)

theorem identity51268 : scanCanonicalize (H12AffineFastState.compose env51268 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51268 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51269 : List Nat := [2,4,8,16,1,17,8,4,17,21,0,17,8,0,1,3,16,1,20,0,0,0,16,2,8,17,0,17,16,1,21,1,5,0,0,16]

theorem envBound51269 : H12AffineFastState.Bounded env51269 := by
  intro p hp
  have h : env51269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51268_51269 : H12AffineEnvironment.transform 10 0 env51268 = env51269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51268 == env51269) = true)

def leafEnv51269 : List Nat := [2,4,8,16,1,17,8,4,17,21,0,17,8,0,1,3,16,1,20,0,0,0,16,2,20,8,1,17,0,17,16,1,21,1,5,0,5,3,0,16,1,0,0]

def active51269 : List Nat := [0,1,2,3]

def tree51269 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51269 : H12WitnessSearch.Good tree51269 := H12GlobalWitnessIndex.good

theorem leafIdentity51269 : H12AffineFastState.composeSystem env51269 rootObs = leafEnv51269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51269 rootObs == leafEnv51269) = true)

theorem terminalChecked51269 : H12PackedTerminal.terminalCheckFast leafEnv51269 active51269 tree51269 = true := by decide +kernel

def env51270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound51270 : H12AffineFastState.Bounded env51270 := by
  intro p hp
  have h : env51270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50852_51270 : H12AffineEnvironment.transform 26 30393345 env50852 = env51270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env50852 == env51270) = true)

def env51271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound51271 : H12AffineFastState.Bounded env51271 := by
  intro p hp
  have h : env51271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51270_51271 : H12AffineEnvironment.transform 18 1024 env51270 = env51271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env51270 == env51271) = true)

theorem identity51271 : scanCanonicalize (H12AffineFastState.compose env51271 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8429903) := by decide +kernel

theorem selectedBound51271 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8328,64,4677966,10560962,10507601,8830977,75103,14795918,256,2188771,2196551,649]

theorem envBound51272 : H12AffineFastState.Bounded env51272 := by
  intro p hp
  have h : env51272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51271_51272 : H12AffineEnvironment.transform 23 8429903 env51271 = env51272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8429903 env51271 == env51272) = true)

def env51273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8192,64,4677966,10560842,10507601,8830977,75103,14795782,256,2188651,2196551,513]

theorem envBound51273 : H12AffineFastState.Bounded env51273 := by
  intro p hp
  have h : env51273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51272_51273 : H12AffineEnvironment.transform 6 8 env51272 = env51273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51272 == env51273) = true)

def env51274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8192,64,4677966,2172250,2118977,442385,75103,6407190,256,2188651,2196551,513]

theorem envBound51274 : H12AffineFastState.Bounded env51274 := by
  intro p hp
  have h : env51274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51273_51274 : H12AffineEnvironment.transform 22 16 env51273 = env51274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env51273 == env51274) = true)

def env51275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8192,64,4677966,115014,45405,442385,75103,4268042,256,98679,90203,513]

theorem envBound51275 : H12AffineFastState.Bounded env51275 := by
  intro p hp
  have h : env51275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51274_51275 : H12AffineEnvironment.transform 20 58396 env51274 = env51275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env51274 == env51275) = true)

def env51276 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8192,16,4677918,114966,45325,442385,75023,4268042,256,98599,90123,513]

theorem envBound51276 : H12AffineFastState.Bounded env51276 := by
  intro p hp
  have h : env51276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51275_51276 : H12AffineEnvironment.transform 5 16 env51275 = env51276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51275 == env51276) = true)

def env51277 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8192,16,4409654,114966,45325,190521,75023,4268042,256,98599,90123,513]

theorem envBound51277 : H12AffineFastState.Bounded env51277 := by
  intro p hp
  have h : env51277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51276_51277 : H12AffineEnvironment.transform 17 10280 env51276 = env51277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51276 == env51277) = true)

theorem identity51277 : scanCanonicalize (H12AffineFastState.compose env51277 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound51277 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env51278 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,65830,16,41231,8192,16,149520,114966,45325,190521,75023,8492,256,98599,90123,513]

theorem envBound51278 : H12AffineFastState.Bounded env51278 := by
  intro p hp
  have h : env51278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51277_51278 : H12AffineEnvironment.transform 21 65830 env51277 = env51278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env51277 == env51278) = true)

theorem identity51278 : scanCanonicalize (H12AffineFastState.compose env51278 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound51278 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env51279 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1024,32769,58396,65830,16,41231,8192,16,108555,114966,45325,67618,75023,8492,256,98599,90123,513]

theorem envBound51279 : H12AffineFastState.Bounded env51279 := by
  intro p hp
  have h : env51279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51278_51279 : H12AffineEnvironment.transform 16 122907 env51278 = env51279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env51278 == env51279) = true)

theorem identity51279 : scanCanonicalize (H12AffineFastState.compose env51279 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound51279 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env51280 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1024,32769,58396,41260,16,41231,8192,16,2049,24860,45325,43048,34053,8492,256,8493,49153,513]

theorem envBound51280 : H12AffineFastState.Bounded env51280 := by
  intro p hp
  have h : env51280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51279_51280 : H12AffineEnvironment.transform 15 40970 env51279 = env51280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env51279 == env51280) = true)

theorem identity51280 : scanCanonicalize (H12AffineFastState.compose env51280 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51280 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51281 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,8202,16401,10280,1024,1,25628,8492,16,8463,8192,16,2049,24860,12557,10280,1285,8492,256,8493,16385,513]

theorem envBound51281 : H12AffineFastState.Bounded env51281 := by
  intro p hp
  have h : env51281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51280_51281 : H12AffineEnvironment.transform 14 0 env51280 = env51281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51280 == env51281) = true)

def env51282 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8192,16,4409655,114966,45325,190520,75023,4268042,256,98599,90123,513]

theorem envBound51282 : H12AffineFastState.Bounded env51282 := by
  intro p hp
  have h : env51282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51276_51282 : H12AffineEnvironment.transform 17 10281 env51276 = env51282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env51276 == env51282) = true)

theorem identity51282 : scanCanonicalize (H12AffineFastState.compose env51282 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 199939) := by decide +kernel

theorem selectedBound51282 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env51283 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,199939,16,41231,8192,16,17460,114966,45325,190520,75023,142601,256,98599,90123,513]

theorem envBound51283 : H12AffineFastState.Bounded env51283 := by
  intro p hp
  have h : env51283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51282_51283 : H12AffineEnvironment.transform 21 199939 env51282 = env51283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 199939 env51282 == env51283) = true)

theorem identity51283 : scanCanonicalize (H12AffineFastState.compose env51283 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51283 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env51284 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,58396,27928,16,41231,8192,16,17460,114966,45325,100387,75023,85266,256,98599,90123,513]

theorem envBound51284 : H12AffineFastState.Bounded env51284 := by
  intro p hp
  have h : env51284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51283_51284 : H12AffineEnvironment.transform 16 90139 env51283 = env51284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51283 == env51284) = true)

theorem identity51284 : scanCanonicalize (H12AffineFastState.compose env51284 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound51284 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51285 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,32768,65536,84999,1077,1024,32769,51200,16644,16,36115,3100,16,17460,114966,40209,100387,67859,85266,256,98599,85015,513]

theorem envBound51285 : H12AffineFastState.Bounded env51285 := by
  intro p hp
  have h : env51285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51284_51285 : H12AffineEnvironment.transform 12 3100 env51284 = env51285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env51284 == env51285) = true)

theorem identity51285 : scanCanonicalize (H12AffineFastState.compose env51285 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 3094) := by decide +kernel

theorem selectedBound51285 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51286 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,16384,32768,3094,16401,1077,1024,32769,51200,16644,16,36115,3100,16,17460,52480,40209,33845,1285,16644,256,36145,16385,513]

theorem envBound51286 : H12AffineFastState.Bounded env51286 := by
  intro p hp
  have h : env51286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51285_51286 : H12AffineEnvironment.transform 15 3094 env51285 = env51286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3094 env51285 == env51286) = true)

theorem identity51286 : scanCanonicalize (H12AffineFastState.compose env51286 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound51286 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51287 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,3100,4113,32768,3094,4096,1077,1024,32769,38929,4373,16,36115,3100,16,5157,40209,40209,33845,1285,4373,256,36145,4112,513]

theorem envBound51287 : H12AffineFastState.Bounded env51287 := by
  intro p hp
  have h : env51287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51286_51287 : H12AffineEnvironment.transform 13 4113 env51286 = env51287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env51286 == env51287) = true)

theorem identity51287 : scanCanonicalize (H12AffineFastState.compose env51287 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound51287 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51288 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,4096,1052,4113,32768,1046,4096,1077,1024,32769,36881,4373,16,34067,1052,16,5157,38161,38161,33845,1285,4373,256,34097,4112,513]

theorem envBound51288 : H12AffineFastState.Bounded env51288 := by
  intro p hp
  have h : env51288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51287_51288 : H12AffineEnvironment.transform 10 0 env51287 = env51288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env51287 == env51288) = true)

theorem identity51288 : scanCanonicalize (H12AffineFastState.compose env51288 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound51288 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51289 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,16,1052,1,32768,1046,16,1077,1024,32769,32769,261,16,34067,1052,16,1077,34049,34049,33845,1285,261,256,34097,0,513]

theorem envBound51289 : H12AffineFastState.Bounded env51289 := by
  intro p hp
  have h : env51289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51288_51289 : H12AffineEnvironment.transform 11 16 env51288 = env51289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env51288 == env51289) = true)

theorem identity51289 : scanCanonicalize (H12AffineFastState.compose env51289 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 1588) := by decide +kernel

theorem selectedBound51289 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51290 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,16,1052,1,1588,1046,16,1077,1024,1589,1589,261,16,807,1052,16,1077,821,821,513,1285,261,256,773,0,513]

theorem envBound51290 : H12AffineFastState.Bounded env51290 := by
  intro p hp
  have h : env51290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51289_51290 : H12AffineEnvironment.transform 14 1588 env51289 = env51290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1588 env51289 == env51290) = true)

theorem identity51290 : scanCanonicalize (H12AffineFastState.compose env51290 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound51290 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env51291 : List Nat := [2,4,8,16,32,16,8,256,1,1024,0,16,1052,1,1077,1046,16,1077,1024,1076,1076,261,16,294,1052,16,1077,308,308,0,1285,261,256,260,0,0]

theorem envBound51291 : H12AffineFastState.Bounded env51291 := by
  intro p hp
  have h : env51291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51290_51291 : H12AffineEnvironment.transform 8 1 env51290 = env51291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env51290 == env51291) = true)

theorem identity51291 : scanCanonicalize (H12AffineFastState.compose env51291 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound51291 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env51292 : List Nat := [2,4,8,16,32,16,8,256,1,304,0,16,300,1,261,294,16,261,304,260,260,261,16,294,300,16,261,308,308,0,53,261,256,260,0,0]

theorem envBound51292 : H12AffineFastState.Bounded env51292 := by
  intro p hp
  have h : env51292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51291_51292 : H12AffineEnvironment.transform 9 304 env51291 = env51292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env51291 == env51292) = true)

theorem identity51292 : scanCanonicalize (H12AffineFastState.compose env51292 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51293 : List Nat := [2,4,8,16,0,16,8,256,1,272,0,16,268,1,261,262,16,261,272,260,260,261,16,262,268,16,261,276,276,0,21,261,256,260,0,0]

theorem envBound51293 : H12AffineFastState.Bounded env51293 := by
  intro p hp
  have h : env51293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51292_51293 : H12AffineEnvironment.transform 4 0 env51292 = env51293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51292 == env51293) = true)

theorem identity51293 : scanCanonicalize (H12AffineFastState.compose env51293 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51294 : List Nat := [2,4,8,1,0,1,8,256,1,257,0,1,268,1,261,262,1,261,257,260,260,261,1,262,268,1,261,261,261,0,4,261,256,260,0,0]

theorem envBound51294 : H12AffineFastState.Bounded env51294 := by
  intro p hp
  have h : env51294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51293_51294 : H12AffineEnvironment.transform 3 1 env51293 = env51294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51293 == env51294) = true)

def env51295 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8192,17,4677919,114967,45324,442385,75022,4268042,256,98598,90122,513]

theorem envBound51295 : H12AffineFastState.Bounded env51295 := by
  intro p hp
  have h : env51295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51275_51295 : H12AffineEnvironment.transform 5 17 env51275 = env51295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51275 == env51295) = true)

theorem identity51295 : scanCanonicalize (H12AffineFastState.compose env51295 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51295 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env51296 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41230,8192,17,4409655,114967,45324,190521,75022,4268042,256,98598,90122,513]

theorem envBound51296 : H12AffineFastState.Bounded env51296 := by
  intro p hp
  have h : env51296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51295_51296 : H12AffineEnvironment.transform 17 10280 env51295 = env51296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51295 == env51296) = true)

theorem identity51296 : scanCanonicalize (H12AffineFastState.compose env51296 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51296 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env51297 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,4194304,16,41230,8192,17,4204844,114967,45324,100386,75022,4268042,256,98598,90122,513]

theorem envBound51297 : H12AffineFastState.Bounded env51297 := by
  intro p hp
  have h : env51297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51296_51297 : H12AffineEnvironment.transform 16 90139 env51296 = env51297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51296 == env51297) = true)

theorem identity51297 : scanCanonicalize (H12AffineFastState.compose env51297 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound51297 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env51298 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,58396,32,16,41230,8192,17,10508,114967,45324,100386,75022,73770,256,98598,90122,513]

theorem envBound51298 : H12AffineFastState.Bounded env51298 := by
  intro p hp
  have h : env51298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51297_51298 : H12AffineEnvironment.transform 21 32 env51297 = env51298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51297 == env51298) = true)

theorem identity51298 : scanCanonicalize (H12AffineFastState.compose env51298 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51298 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env51299 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,90139,10280,1024,0,25629,32,16,8463,8192,17,10508,82198,12557,67619,75022,73770,256,65831,90122,513]

theorem envBound51299 : H12AffineFastState.Bounded env51299 := by
  intro p hp
  have h : env51299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51298_51299 : H12AffineEnvironment.transform 14 1 env51298 = env51299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51298 == env51299) = true)

theorem identity51299 : scanCanonicalize (H12AffineFastState.compose env51299 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound51299 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51300 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,8202,16401,10280,1024,0,25629,32,16,8463,8192,17,10508,24860,12557,10281,1284,32,256,8493,16384,513]

theorem envBound51300 : H12AffineFastState.Bounded env51300 := by
  intro p hp
  have h : env51300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51299_51300 : H12AffineEnvironment.transform 15 8202 env51299 = env51300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env51299 == env51300) = true)

theorem identity51300 : scanCanonicalize (H12AffineFastState.compose env51300 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound51300 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env51301 : List Nat := [2,4,8,16,32,17,8,256,512,1024,528,4096,8192,16384,1,8202,16401,8760,1024,0,25629,32,16,8463,8192,17,8988,24860,12557,8761,1284,32,256,8493,16384,513]

theorem envBound51301 : H12AffineFastState.Bounded env51301 := by
  intro p hp
  have h : env51301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51300_51301 : H12AffineEnvironment.transform 10 528 env51300 = env51301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env51300 == env51301) = true)

theorem identity51301 : scanCanonicalize (H12AffineFastState.compose env51301 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8460) := by decide +kernel

theorem selectedBound51301 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env51302 : List Nat := [2,4,8,16,32,17,8,256,512,1024,528,4096,8192,8460,1,8202,8477,8760,1024,0,1297,32,16,8463,8192,17,8988,16,12557,8761,1284,32,256,8493,8460,513]

theorem envBound51302 : H12AffineFastState.Bounded env51302 := by
  intro p hp
  have h : env51302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51301_51302 : H12AffineEnvironment.transform 13 8460 env51301 = env51302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8460 env51301 == env51302) = true)

theorem identity51302 : scanCanonicalize (H12AffineFastState.compose env51302 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound51302 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env51303 : List Nat := [2,4,8,16,32,17,8,256,512,36,528,4096,8192,8460,1,8202,8477,8760,36,0,309,32,16,8463,8192,17,8988,16,12557,8761,288,32,256,8493,8460,513]

theorem envBound51303 : H12AffineFastState.Bounded env51303 := by
  intro p hp
  have h : env51303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51302_51303 : H12AffineEnvironment.transform 9 36 env51302 = env51303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env51302 == env51303) = true)

theorem identity51303 : scanCanonicalize (H12AffineFastState.compose env51303 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound51303 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env51304 : List Nat := [2,4,8,16,32,17,8,256,512,36,528,4096,268,0,1,262,17,820,36,0,309,32,16,3,268,17,528,16,4097,821,288,32,256,33,0,513]

theorem envBound51304 : H12AffineFastState.Bounded env51304 := by
  intro p hp
  have h : env51304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51303_51304 : H12AffineEnvironment.transform 12 268 env51303 = env51304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env51303 == env51304) = true)

theorem identity51304 : scanCanonicalize (H12AffineFastState.compose env51304 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound51304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51305 : List Nat := [2,4,8,16,32,17,8,256,512,36,528,17,268,0,1,262,17,820,36,0,309,32,16,3,268,17,528,16,16,821,288,32,256,33,0,513]

theorem envBound51305 : H12AffineFastState.Bounded env51305 := by
  intro p hp
  have h : env51305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51304_51305 : H12AffineEnvironment.transform 11 17 env51304 = env51305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env51304 == env51305) = true)

theorem identity51305 : scanCanonicalize (H12AffineFastState.compose env51305 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound51305 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51306 : List Nat := [2,4,8,16,32,17,8,4,512,36,528,17,8,0,1,2,17,560,36,0,49,32,16,3,8,17,528,16,16,561,36,32,4,33,0,513]

theorem envBound51306 : H12AffineFastState.Bounded env51306 := by
  intro p hp
  have h : env51306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51305_51306 : H12AffineEnvironment.transform 7 4 env51305 = env51306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env51305 == env51306) = true)

theorem identity51306 : scanCanonicalize (H12AffineFastState.compose env51306 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound51306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51307 : List Nat := [2,4,8,16,32,17,8,4,49,36,33,17,8,0,1,2,17,1,36,0,49,32,16,3,8,17,33,16,16,0,36,32,4,33,0,48]

theorem envBound51307 : H12AffineFastState.Bounded env51307 := by
  intro p hp
  have h : env51307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51306_51307 : H12AffineEnvironment.transform 8 49 env51306 = env51307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env51306 == env51307) = true)

theorem identity51307 : scanCanonicalize (H12AffineFastState.compose env51307 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51307 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51308 : List Nat := [2,4,8,16,0,17,8,4,17,4,1,17,8,0,1,2,17,1,4,0,17,0,16,3,8,17,1,16,16,0,4,0,4,1,0,16]

theorem envBound51308 : H12AffineFastState.Bounded env51308 := by
  intro p hp
  have h : env51308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51307_51308 : H12AffineEnvironment.transform 4 0 env51307 = env51308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51307 == env51308) = true)

def env51309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677966,115015,45404,442385,75103,4268043,256,98678,90202,513]

theorem envBound51309 : H12AffineFastState.Bounded env51309 := by
  intro p hp
  have h : env51309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51274_51309 : H12AffineEnvironment.transform 20 58397 env51274 = env51309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env51274 == env51309) = true)

theorem identity51309 : scanCanonicalize (H12AffineFastState.compose env51309 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51309 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env51310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4604229,57676,45404,442385,1364,4194304,256,41341,16465,513]

theorem envBound51310 : H12AffineFastState.Bounded env51310 := by
  intro p hp
  have h : env51310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51309_51310 : H12AffineEnvironment.transform 15 8203 env51309 = env51310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51309 == env51310) = true)

theorem identity51310 : scanCanonicalize (H12AffineFastState.compose env51310 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound51310 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env51311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,419912,16,41311,8192,64,10509,57676,45404,442385,1364,419912,256,41341,16465,513]

theorem envBound51311 : H12AffineFastState.Bounded env51311 := by
  intro p hp
  have h : env51311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51310_51311 : H12AffineEnvironment.transform 21 419912 env51310 = env51311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env51310 == env51311) = true)

def env51312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58397,272392,16,41311,8192,64,10509,57676,45404,294993,1364,272392,256,41341,16465,513]

theorem envBound51312 : H12AffineFastState.Bounded env51312 := by
  intro p hp
  have h : env51312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51311_51312 : H12AffineEnvironment.transform 16 16448 env51311 = env51312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env51311 == env51312) = true)

def env51313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58397,272393,16,41311,8192,64,10509,57676,45404,294992,1364,272393,256,41341,16465,513]

theorem envBound51313 : H12AffineFastState.Bounded env51313 := by
  intro p hp
  have h : env51313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51311_51313 : H12AffineEnvironment.transform 16 16449 env51311 = env51313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env51311 == env51313) = true)

theorem identity51313 : scanCanonicalize (H12AffineFastState.compose env51313 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound51313 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16449,262144,1024,32769,50448,264452,16,32850,269,64,2048,49217,36945,294992,1364,264452,256,32880,16465,513]

theorem envBound51314 : H12AffineFastState.Bounded env51314 := by
  intro p hp
  have h : env51314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51313_51314 : H12AffineEnvironment.transform 12 269 env51313 = env51314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env51313 == env51314) = true)

theorem identity51314 : scanCanonicalize (H12AffineFastState.compose env51314 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound51314 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env51315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16449,35108,1024,32769,50448,32800,16,32850,269,64,2048,49217,36945,2420,1364,32800,256,32880,16465,513]

theorem envBound51315 : H12AffineFastState.Bounded env51315 := by
  intro p hp
  have h : env51315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51314_51315 : H12AffineEnvironment.transform 17 35108 env51314 = env51315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env51314 == env51315) = true)

theorem identity51315 : scanCanonicalize (H12AffineFastState.compose env51315 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51315 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env51316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,262,16449,2341,1024,0,17681,33,16,83,269,64,2048,16448,4176,2420,1364,33,256,113,16465,513]

theorem envBound51316 : H12AffineFastState.Bounded env51316 := by
  intro p hp
  have h : env51316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51315_51316 : H12AffineEnvironment.transform 14 1 env51315 = env51316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51315 == env51316) = true)

theorem identity51316 : scanCanonicalize (H12AffineFastState.compose env51316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound51316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51317 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16400,2341,1024,0,17681,33,16,2,269,17,2048,16401,4097,2341,1285,33,256,32,16384,513]

theorem envBound51317 : H12AffineFastState.Bounded env51317 := by
  intro p hp
  have h : env51317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51316_51317 : H12AffineEnvironment.transform 5 17 env51316 = env51317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env51316 == env51317) = true)

theorem identity51317 : scanCanonicalize (H12AffineFastState.compose env51317 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound51317 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51318 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,1,262,5172,2341,1024,0,4405,33,16,2,269,17,2048,5173,4097,2341,1285,33,256,32,5156,513]

theorem envBound51318 : H12AffineFastState.Bounded env51318 := by
  intro p hp
  have h : env51318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51317_51318 : H12AffineEnvironment.transform 13 5156 env51317 = env51318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env51317 == env51318) = true)

def env51319 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2836,1,262,2820,2341,1024,0,3589,33,16,2,269,17,2048,2821,3889,2341,1285,33,256,32,2836,513]

theorem envBound51319 : H12AffineFastState.Bounded env51319 := by
  intro p hp
  have h : env51319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51318_51319 : H12AffineEnvironment.transform 11 3888 env51318 = env51319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env51318 == env51319) = true)

def env51320 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1044,1,262,1028,1573,1024,0,261,33,16,2,269,17,1792,1029,49,1573,1285,33,256,32,1044,513]

theorem envBound51320 : H12AffineFastState.Bounded env51320 := by
  intro p hp
  have h : env51320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51319_51320 : H12AffineEnvironment.transform 10 1792 env51319 = env51320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env51319 == env51320) = true)

theorem identity51320 : scanCanonicalize (H12AffineFastState.compose env51320 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound51320 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51321 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1296,48,269,1044,1,262,1028,1077,1024,0,261,33,16,2,269,17,1296,1029,49,1077,1285,33,256,32,1044,17]

theorem envBound51321 : H12AffineFastState.Bounded env51321 := by
  intro p hp
  have h : env51321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51320_51321 : H12AffineEnvironment.transform 8 16 env51320 = env51321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51320 == env51321) = true)

def env51322 : List Nat := [2,4,8,16,32,17,8,256,16,52,292,48,269,32,1,262,48,1,52,0,261,33,16,2,269,17,292,49,49,1,305,33,256,32,32,17]

theorem envBound51322 : H12AffineFastState.Bounded env51322 := by
  intro p hp
  have h : env51322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51321_51322 : H12AffineEnvironment.transform 9 52 env51321 = env51322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51321 == env51322) = true)

theorem identity51322 : scanCanonicalize (H12AffineFastState.compose env51322 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51322 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51323 : List Nat := [2,4,8,16,32,17,8,5,16,52,33,48,8,32,1,3,48,1,52,0,0,33,16,2,8,17,33,49,49,1,52,33,5,32,32,17]

theorem envBound51323 : H12AffineFastState.Bounded env51323 := by
  intro p hp
  have h : env51323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51322_51323 : H12AffineEnvironment.transform 7 5 env51322 = env51323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51322 == env51323) = true)

def leafEnv51323 : List Nat := [2,4,8,16,32,17,8,5,16,52,33,48,8,32,1,3,48,1,52,0,0,33,16,2,52,8,1,17,33,49,49,1,52,33,5,32,4,3,32,17,1,0,0]

def active51323 : List Nat := [0,1,2,3,4]

def tree51323 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51323 : H12WitnessSearch.Good tree51323 := H12GlobalWitnessIndex.good

theorem leafIdentity51323 : H12AffineFastState.composeSystem env51323 rootObs = leafEnv51323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51323 rootObs == leafEnv51323) = true)

theorem terminalChecked51323 : H12PackedTerminal.terminalCheckFast leafEnv51323 active51323 tree51323 = true := by decide +kernel

def env51324 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,269,33,1,262,49,0,53,0,261,33,16,2,269,17,293,48,49,0,304,33,256,32,33,17]

theorem envBound51324 : H12AffineFastState.Bounded env51324 := by
  intro p hp
  have h : env51324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51321_51324 : H12AffineEnvironment.transform 9 53 env51321 = env51324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51321 == env51324) = true)

theorem identity51324 : scanCanonicalize (H12AffineFastState.compose env51324 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51325 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,269,33,1,262,43,0,47,0,261,33,10,2,269,11,293,42,43,0,298,33,256,32,33,11]

theorem envBound51325 : H12AffineFastState.Bounded env51325 := by
  intro p hp
  have h : env51325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51324_51325 : H12AffineEnvironment.transform 3 10 env51324 = env51325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51324 == env51325) = true)

def leafEnv51325 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,42,269,33,1,262,43,0,47,0,261,33,10,2,298,269,1,11,293,42,43,0,298,33,256,32,4,262,33,11,1,261,0]

def active51325 : List Nat := [0,1,2,4,7]

def tree51325 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51325 : H12WitnessSearch.Good tree51325 := H12GlobalWitnessIndex.good

theorem leafIdentity51325 : H12AffineFastState.composeSystem env51325 rootObs = leafEnv51325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51325 rootObs == leafEnv51325) = true)

theorem terminalChecked51325 : H12PackedTerminal.terminalCheckFast leafEnv51325 active51325 tree51325 = true := by decide +kernel

def env51326 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1045,1,262,1029,1572,1024,0,260,33,16,2,269,17,1793,1028,48,1572,1285,33,256,32,1045,513]

theorem envBound51326 : H12AffineFastState.Bounded env51326 := by
  intro p hp
  have h : env51326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51319_51326 : H12AffineEnvironment.transform 10 1793 env51319 = env51326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env51319 == env51326) = true)

theorem identity51326 : scanCanonicalize (H12AffineFastState.compose env51326 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound51326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51327 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,49,269,788,1,262,772,293,769,0,260,33,16,2,269,17,0,773,48,293,516,33,256,32,788,513]

theorem envBound51327 : H12AffineFastState.Bounded env51327 := by
  intro p hp
  have h : env51327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51326_51327 : H12AffineEnvironment.transform 9 769 env51326 = env51327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env51326 == env51327) = true)

def env51328 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,49,269,32,1,262,48,293,53,0,260,33,16,2,269,17,0,49,48,293,304,33,256,32,32,309]

theorem envBound51328 : H12AffineFastState.Bounded env51328 := by
  intro p hp
  have h : env51328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51327_51328 : H12AffineEnvironment.transform 8 308 env51327 = env51328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env51327 == env51328) = true)

theorem identity51328 : scanCanonicalize (H12AffineFastState.compose env51328 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51329 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,269,32,1,262,43,293,46,0,260,33,11,2,269,10,0,42,43,293,299,33,256,32,32,302]

theorem envBound51329 : H12AffineFastState.Bounded env51329 := by
  intro p hp
  have h : env51329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51328_51329 : H12AffineEnvironment.transform 3 11 env51328 = env51329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51328 == env51329) = true)

def leafEnv51329 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,269,32,1,262,43,293,46,0,260,33,11,2,299,269,1,10,0,42,43,293,299,33,256,32,4,262,32,302,1,260,0]

def active51329 : List Nat := [0,1,2,4,7]

def tree51329 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51329 : H12WitnessSearch.Good tree51329 := H12GlobalWitnessIndex.good

theorem leafIdentity51329 : H12AffineFastState.composeSystem env51329 rootObs = leafEnv51329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51329 rootObs == leafEnv51329) = true)

theorem terminalChecked51329 : H12PackedTerminal.terminalCheckFast leafEnv51329 active51329 tree51329 = true := by decide +kernel

def env51330 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,269,33,1,262,49,293,52,0,260,33,16,2,269,17,0,48,48,293,305,33,256,32,33,308]

theorem envBound51330 : H12AffineFastState.Bounded env51330 := by
  intro p hp
  have h : env51330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51327_51330 : H12AffineEnvironment.transform 8 309 env51327 = env51330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env51327 == env51330) = true)

theorem identity51330 : scanCanonicalize (H12AffineFastState.compose env51330 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51331 : List Nat := [2,4,8,16,0,17,8,256,277,20,0,17,269,1,1,262,17,261,20,0,260,1,16,2,269,17,0,16,16,261,273,1,256,0,1,276]

theorem envBound51331 : H12AffineFastState.Bounded env51331 := by
  intro p hp
  have h : env51331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51330_51331 : H12AffineEnvironment.transform 4 0 env51330 = env51331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51330 == env51331) = true)

def leafEnv51331 : List Nat := [2,4,8,16,0,17,8,256,277,20,0,17,269,1,1,262,17,261,20,0,260,1,16,2,273,269,1,17,0,16,16,261,273,1,256,0,4,262,1,276,1,260,0]

def active51331 : List Nat := [0,1,2,3,7]

def tree51331 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51331 : H12WitnessSearch.Good tree51331 := H12GlobalWitnessIndex.good

theorem leafIdentity51331 : H12AffineFastState.composeSystem env51331 rootObs = leafEnv51331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51331 rootObs == leafEnv51331) = true)

theorem terminalChecked51331 : H12PackedTerminal.terminalCheckFast leafEnv51331 active51331 tree51331 = true := by decide +kernel

def env51332 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2837,1,262,2821,2341,1024,0,3588,33,16,2,269,17,2048,2820,3888,2341,1285,33,256,32,2837,513]

theorem envBound51332 : H12AffineFastState.Bounded env51332 := by
  intro p hp
  have h : env51332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51318_51332 : H12AffineEnvironment.transform 11 3889 env51318 = env51332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env51318 == env51332) = true)

def env51333 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1045,1,262,1029,1573,1024,0,260,33,16,2,269,17,1792,1028,48,1573,1285,33,256,32,1045,513]

theorem envBound51333 : H12AffineFastState.Bounded env51333 := by
  intro p hp
  have h : env51333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51332_51333 : H12AffineEnvironment.transform 10 1792 env51332 = env51333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env51332 == env51333) = true)

theorem identity51333 : scanCanonicalize (H12AffineFastState.compose env51333 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound51333 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51334 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,49,269,560,1,262,544,0,549,0,260,33,16,2,269,17,293,545,48,0,800,33,256,32,560,513]

theorem envBound51334 : H12AffineFastState.Bounded env51334 := by
  intro p hp
  have h : env51334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51333_51334 : H12AffineEnvironment.transform 9 549 env51333 = env51334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env51333 == env51334) = true)

def env51335 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,49,269,32,1,262,48,0,53,0,260,33,16,2,269,17,293,49,48,0,304,33,256,32,32,17]

theorem envBound51335 : H12AffineFastState.Bounded env51335 := by
  intro p hp
  have h : env51335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51334_51335 : H12AffineEnvironment.transform 8 16 env51334 = env51335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env51334 == env51335) = true)

theorem identity51335 : scanCanonicalize (H12AffineFastState.compose env51335 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound51335 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51336 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,269,32,1,262,42,0,47,0,260,33,10,2,269,11,293,43,42,0,298,33,256,32,32,11]

theorem envBound51336 : H12AffineFastState.Bounded env51336 := by
  intro p hp
  have h : env51336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51335_51336 : H12AffineEnvironment.transform 3 10 env51335 = env51336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env51335 == env51336) = true)

def leafEnv51336 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,269,32,1,262,42,0,47,0,260,33,10,2,298,269,1,11,293,43,42,0,298,33,256,32,4,262,32,11,1,260,0]

def active51336 : List Nat := [0,1,2,4,7]

def tree51336 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51336 : H12WitnessSearch.Good tree51336 := H12GlobalWitnessIndex.good

theorem leafIdentity51336 : H12AffineFastState.composeSystem env51336 rootObs = leafEnv51336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51336 rootObs == leafEnv51336) = true)

theorem terminalChecked51336 : H12PackedTerminal.terminalCheckFast leafEnv51336 active51336 tree51336 = true := by decide +kernel

def env51337 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,269,33,1,262,49,0,52,0,260,33,16,2,269,17,293,48,48,0,305,33,256,32,33,16]

theorem envBound51337 : H12AffineFastState.Bounded env51337 := by
  intro p hp
  have h : env51337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51334_51337 : H12AffineEnvironment.transform 8 17 env51334 = env51337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env51334 == env51337) = true)

theorem identity51337 : scanCanonicalize (H12AffineFastState.compose env51337 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound51337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51338 : List Nat := [2,4,8,16,32,17,8,5,17,52,32,49,8,33,1,3,49,0,52,0,1,33,16,2,8,17,32,48,48,0,52,33,5,32,33,16]

theorem envBound51338 : H12AffineFastState.Bounded env51338 := by
  intro p hp
  have h : env51338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51337_51338 : H12AffineEnvironment.transform 7 5 env51337 = env51338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env51337 == env51338) = true)

def leafEnv51338 : List Nat := [2,4,8,16,32,17,8,5,17,52,32,49,8,33,1,3,49,0,52,0,1,33,16,2,52,8,1,17,32,48,48,0,52,33,5,32,4,3,33,16,1,1,0]

def active51338 : List Nat := [0,1,2,3,4]

def tree51338 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51338 : H12WitnessSearch.Good tree51338 := H12GlobalWitnessIndex.good

theorem leafIdentity51338 : H12AffineFastState.composeSystem env51338 rootObs = leafEnv51338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51338 rootObs == leafEnv51338) = true)

theorem terminalChecked51338 : H12PackedTerminal.terminalCheckFast leafEnv51338 active51338 tree51338 = true := by decide +kernel

def env51339 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1044,1,262,1028,1572,1024,0,261,33,16,2,269,17,1793,1029,49,1572,1285,33,256,32,1044,513]

theorem envBound51339 : H12AffineFastState.Bounded env51339 := by
  intro p hp
  have h : env51339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51332_51339 : H12AffineEnvironment.transform 10 1793 env51332 = env51339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env51332 == env51339) = true)

theorem identity51339 : scanCanonicalize (H12AffineFastState.compose env51339 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound51339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51340 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1077,48,269,1044,1,262,1028,1296,1024,0,261,33,16,2,269,17,1077,1029,49,1296,1285,33,256,32,1044,309]

theorem envBound51340 : H12AffineFastState.Bounded env51340 := by
  intro p hp
  have h : env51340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51339_51340 : H12AffineEnvironment.transform 8 308 env51339 = env51340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env51339 == env51340) = true)

def env51341 : List Nat := [2,4,8,16,32,17,8,256,308,52,1,48,269,32,1,262,48,292,52,0,261,33,16,2,269,17,1,49,49,292,305,33,256,32,32,309]

theorem envBound51341 : H12AffineFastState.Bounded env51341 := by
  intro p hp
  have h : env51341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51340_51341 : H12AffineEnvironment.transform 9 52 env51340 = env51341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env51340 == env51341) = true)

theorem identity51341 : scanCanonicalize (H12AffineFastState.compose env51341 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound51341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51342 : List Nat := [2,4,8,16,0,17,8,256,276,20,1,16,269,0,1,262,16,260,20,0,261,1,16,2,269,17,1,17,17,260,273,1,256,0,0,277]

theorem envBound51342 : H12AffineFastState.Bounded env51342 := by
  intro p hp
  have h : env51342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51341_51342 : H12AffineEnvironment.transform 4 0 env51341 = env51342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env51341 == env51342) = true)

def leafEnv51342 : List Nat := [2,4,8,16,0,17,8,256,276,20,1,16,269,0,1,262,16,260,20,0,261,1,16,2,273,269,1,17,1,17,17,260,273,1,256,0,4,262,0,277,1,261,0]

def active51342 : List Nat := [0,1,2,3,7]

def tree51342 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51342 : H12WitnessSearch.Good tree51342 := H12GlobalWitnessIndex.good

theorem leafIdentity51342 : H12AffineFastState.composeSystem env51342 rootObs = leafEnv51342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51342 rootObs == leafEnv51342) = true)

theorem terminalChecked51342 : H12PackedTerminal.terminalCheckFast leafEnv51342 active51342 tree51342 = true := by decide +kernel

def env51343 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,269,33,1,262,49,293,53,0,261,33,16,2,269,17,0,48,49,293,304,33,256,32,33,309]

theorem envBound51343 : H12AffineFastState.Bounded env51343 := by
  intro p hp
  have h : env51343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51340_51343 : H12AffineEnvironment.transform 9 53 env51340 = env51343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env51340 == env51343) = true)

theorem identity51343 : scanCanonicalize (H12AffineFastState.compose env51343 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound51343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51344 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,269,33,1,262,42,293,46,0,261,33,11,2,269,10,0,43,42,293,299,33,256,32,33,302]

theorem envBound51344 : H12AffineFastState.Bounded env51344 := by
  intro p hp
  have h : env51344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51343_51344 : H12AffineEnvironment.transform 3 11 env51343 = env51344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env51343 == env51344) = true)

def leafEnv51344 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,269,33,1,262,42,293,46,0,261,33,11,2,299,269,1,10,0,43,42,293,299,33,256,32,4,262,33,302,1,261,0]

def active51344 : List Nat := [0,1,2,4,7]

def tree51344 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood51344 : H12WitnessSearch.Good tree51344 := H12GlobalWitnessIndex.good

theorem leafIdentity51344 : H12AffineFastState.composeSystem env51344 rootObs = leafEnv51344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env51344 rootObs == leafEnv51344) = true)

theorem terminalChecked51344 : H12PackedTerminal.terminalCheckFast leafEnv51344 active51344 tree51344 = true := by decide +kernel

def env51345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41310,8192,64,4677966,2172251,2118976,442384,75103,6407191,256,2188651,2196551,513]

theorem envBound51345 : H12AffineFastState.Bounded env51345 := by
  intro p hp
  have h : env51345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51273_51345 : H12AffineEnvironment.transform 22 17 env51273 = env51345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env51273 == env51345) = true)

theorem identity51345 : scanCanonicalize (H12AffineFastState.compose env51345 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound51345 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env51346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2172251,2118976,368651,75103,6407191,256,2188651,2196551,513]

theorem envBound51346 : H12AffineFastState.Bounded env51346 := by
  intro p hp
  have h : env51346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51345_51346 : H12AffineEnvironment.transform 16 90139 env51345 = env51346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env51345 == env51346) = true)

theorem identity51346 : scanCanonicalize (H12AffineFastState.compose env51346 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound51346 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env51347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2139149,2118976,270685,41993,6309185,256,2155581,2098449,513]

theorem envBound51347 : H12AffineFastState.Bounded env51347 := by
  intro p hp
  have h : env51347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51346_51347 : H12AffineEnvironment.transform 15 33110 env51346 = env51347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env51346 == env51347) = true)

theorem identity51347 : scanCanonicalize (H12AffineFastState.compose env51347 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51347 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,2097152,4194304,17,41310,8192,64,4204925,2139149,2118976,2421,41993,6309185,256,2155581,2098449,513]

theorem envBound51348 : H12AffineFastState.Bounded env51348 := by
  intro p hp
  have h : env51348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51347_51348 : H12AffineEnvironment.transform 17 10280 env51347 = env51348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51347 == env51348) = true)

theorem identity51348 : scanCanonicalize (H12AffineFastState.compose env51348 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound51348 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env51349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,2097152,32,17,41310,8192,64,10589,2139149,2118976,2421,41993,2114913,256,2155581,2098449,513]

theorem envBound51349 : H12AffineFastState.Bounded env51349 := by
  intro p hp
  have h : env51349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51348_51349 : H12AffineEnvironment.transform 21 32 env51348 = env51349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env51348 == env51349) = true)

theorem identity51349 : scanCanonicalize (H12AffineFastState.compose env51349 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound51349 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,10280,1024,32769,25629,32,17,41310,8192,64,10589,49168,12637,2421,41993,8572,256,32800,24844,513]

theorem envBound51350 : H12AffineFastState.Bounded env51350 := by
  intro p hp
  have h : env51350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51349_51350 : H12AffineEnvironment.transform 20 25629 env51349 = env51350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env51349 == env51350) = true)

theorem identity51350 : scanCanonicalize (H12AffineFastState.compose env51350 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound51350 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env51351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,24909,10280,1024,1,25629,32,17,8542,8192,64,10589,16400,12637,2421,9225,8572,256,32,24844,513]

theorem envBound51351 : H12AffineFastState.Bounded env51351 := by
  intro p hp
  have h : env51351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51350_51351 : H12AffineEnvironment.transform 14 0 env51350 = env51351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env51350 == env51351) = true)

theorem identity51351 : scanCanonicalize (H12AffineFastState.compose env51351 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51351 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env51352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,16400,2421,1024,1,17728,32,17,3,349,64,2048,16400,4096,2421,1364,33,256,32,16465,513]

theorem envBound51352 : H12AffineFastState.Bounded env51352 := by
  intro p hp
  have h : env51352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51351_51352 : H12AffineEnvironment.transform 12 349 env51351 = env51352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51351 == env51352) = true)

theorem identity51352 : scanCanonicalize (H12AffineFastState.compose env51352 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5749) := by decide +kernel

theorem selectedBound51352 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5749,0,342,5733,2421,1024,1,4917,32,17,3,349,64,2048,5733,4096,2421,1364,33,256,32,5668,513]

theorem envBound51353 : H12AffineFastState.Bounded env51353 := by
  intro p hp
  have h : env51353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51352_51353 : H12AffineEnvironment.transform 13 5749 env51352 = env51353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5749 env51352 == env51353) = true)

def env51354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8429903,8193,64,4677966,10560843,10507601,8830977,75103,14795783,256,2188650,2196551,512]

theorem envBound51354 : H12AffineFastState.Bounded env51354 := by
  intro p hp
  have h : env51354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51272_51354 : H12AffineEnvironment.transform 6 9 env51272 = env51354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51272 == env51354) = true)

theorem identity51354 : scanCanonicalize (H12AffineFastState.compose env51354 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 4235628) := by decide +kernel

theorem selectedBound51354 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,4235628,4194339,8193,64,4677966,6390823,6353981,4612461,75103,2188651,256,2188650,2196551,512]

theorem envBound51355 : H12AffineFastState.Bounded env51355 := by
  intro p hp
  have h : env51355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51354_51355 : H12AffineEnvironment.transform 22 4235628 env51354 = env51355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235628 env51354 == env51355) = true)

theorem identity51355 : scanCanonicalize (H12AffineFastState.compose env51355 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(21+1) ^^^ 188781) := by decide +kernel

theorem selectedBound51355 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env51356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,188781,147457,188750,8193,64,360483,2319690,2233680,294912,75103,2188651,256,2188650,2196551,512]

theorem envBound51356 : H12AffineFastState.Bounded env51356 := by
  intro p hp
  have h : env51356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51355_51356 : H12AffineEnvironment.transform 21 188781 env51355 = env51356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188781 env51355 == env51356) = true)

theorem identity51356 : scanCanonicalize (H12AffineFastState.compose env51356 (packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound51356 : packedSelected [1,5,8,11,17,18,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env51357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,188781,147457,188750,8193,64,108555,2319690,2233680,43048,75103,2188651,256,2188650,2196551,512]

theorem envBound51357 : H12AffineFastState.Bounded env51357 := by
  intro p hp
  have h : env51357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51356_51357 : H12AffineEnvironment.transform 17 10280 env51356 = env51357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env51356 == env51357) = true)

theorem identity51357 : scanCanonicalize (H12AffineFastState.compose env51357 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound51357 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env51358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,33,41293,2,8193,64,108555,2196486,2159644,43048,75103,2188651,256,2188650,2196551,512]

theorem envBound51358 : H12AffineFastState.Bounded env51358 := by
  intro p hp
  have h : env51358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51357_51358 : H12AffineEnvironment.transform 16 57676 env51357 = env51358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env51357 == env51358) = true)

theorem identity51358 : scanCanonicalize (H12AffineFastState.compose env51358 (packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51358 : packedSelected [0,3,4,5,7,9,10,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env51359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49169,2421,1024,32769,2097152,33,32784,2,348,64,100694,2196486,2151745,35189,66562,2180150,256,2180151,2196551,512]

theorem envBound51359 : H12AffineFastState.Bounded env51359 := by
  intro p hp
  have h : env51359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51358_51359 : H12AffineEnvironment.transform 12 349 env51358 = env51359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51358 == env51359) = true)

theorem identity51359 : scanCanonicalize (H12AffineFastState.compose env51359 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound51359 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env51360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49169,2421,1024,32769,50449,33,32784,2,348,64,100694,82199,4176,35189,66562,98599,256,98598,82262,512]

theorem envBound51360 : H12AffineFastState.Bounded env51360 := by
  intro p hp
  have h : env51360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51359_51360 : H12AffineEnvironment.transform 20 50449 env51359 = env51360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env51359 == env51360) = true)

theorem identity51360 : scanCanonicalize (H12AffineFastState.compose env51360 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound51360 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env51361 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,21510,49169,2421,1024,32769,50449,33,32784,2,348,64,56656,5393,4176,35189,20484,54561,256,54560,5456,512]

theorem envBound51361 : H12AffineFastState.Bounded env51361 := by
  intro p hp
  have h : env51361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51360_51361 : H12AffineEnvironment.transform 15 21510 env51360 = env51361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env51360 == env51361) = true)

theorem identity51361 : scanCanonicalize (H12AffineFastState.compose env51361 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound51361 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env51362 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5205,32768,83,37956,2421,1024,32769,37188,33,32784,2,348,64,35077,5393,4176,35189,1105,33140,256,33141,5456,512]

theorem envBound51362 : H12AffineFastState.Bounded env51362 := by
  intro p hp
  have h : env51362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51361_51362 : H12AffineEnvironment.transform 13 5205 env51361 = env51362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env51361 == env51362) = true)

theorem identity51362 : scanCanonicalize (H12AffineFastState.compose env51362 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound51362 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env51363 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5205,32768,83,37956,2128,1024,32769,36961,33,32784,2,121,64,34848,5172,4176,34896,1105,32849,37,32848,5237,512]

theorem envBound51363 : H12AffineFastState.Bounded env51363 := by
  intro p hp
  have h : env51363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51362_51363 : H12AffineEnvironment.transform 7 37 env51362 = env51363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env51362 == env51363) = true)

theorem identity51363 : scanCanonicalize (H12AffineFastState.compose env51363 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound51363 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env51364 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,8,5157,32768,35,37940,2080,1024,32769,36881,33,32784,2,9,48,34848,5172,4128,34848,1057,32801,37,32800,5125,512]

theorem envBound51364 : H12AffineFastState.Bounded env51364 := by
  intro p hp
  have h : env51364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51363_51364 : H12AffineEnvironment.transform 5 48 env51363 = env51364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env51363 == env51364) = true)

theorem identity51364 : scanCanonicalize (H12AffineFastState.compose env51364 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound51364 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env51365 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,32768,2,37909,2049,1024,32769,36881,0,32784,2,9,17,34817,5141,4097,34817,1024,32768,4,32769,5125,512]

theorem envBound51365 : H12AffineFastState.Bounded env51365 := by
  intro p hp
  have h : env51365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51364_51365 : H12AffineEnvironment.transform 4 1 env51364 = env51365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env51364 == env51365) = true)

theorem identity51365 : scanCanonicalize (H12AffineFastState.compose env51365 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound51365 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env51366 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,1,2,5140,2049,1024,0,4112,0,17,2,9,17,2048,5141,4097,2048,1024,1,4,0,5125,512]

theorem envBound51366 : H12AffineFastState.Bounded env51366 := by
  intro p hp
  have h : env51366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51365_51366 : H12AffineEnvironment.transform 14 1 env51365 = env51366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env51365 == env51366) = true)

theorem identity51366 : scanCanonicalize (H12AffineFastState.compose env51366 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound51366 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51367 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,1028,8,0,1,2,16,2049,1024,0,1044,0,17,2,9,17,2048,17,1029,2048,1024,1,4,0,1,512]

theorem envBound51367 : H12AffineFastState.Bounded env51367 := by
  intro p hp
  have h : env51367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51366_51367 : H12AffineEnvironment.transform 11 1028 env51366 = env51367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env51366 == env51367) = true)

theorem identity51367 : scanCanonicalize (H12AffineFastState.compose env51367 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound51367 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51368 : List Nat := [2,4,8,16,1,17,9,4,512,1024,16,1028,8,0,1,2,16,17,1024,0,1044,0,17,2,9,17,16,17,1029,16,1024,1,4,0,1,512]

theorem envBound51368 : H12AffineFastState.Bounded env51368 := by
  intro p hp
  have h : env51368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51367_51368 : H12AffineEnvironment.transform 10 16 env51367 = env51368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env51367 == env51368) = true)

def env51369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound51369 : H12AffineFastState.Bounded env51369 := by
  intro p hp
  have h : env51369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51270_51369 : H12AffineEnvironment.transform 18 1025 env51270 = env51369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env51270 == env51369) = true)

theorem identity51369 : scanCanonicalize (H12AffineFastState.compose env51369 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound51369 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env51370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29655502,18973836,10507601,8749518,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound51370 : H12AffineFastState.Bounded env51370 := by
  intro p hp
  have h : env51370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51369_51370 : H12AffineEnvironment.transform 16 82382 env51369 = env51370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env51369 == env51370) = true)

def env51371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6623298,8393984,10507601,8749518,2102684,12645453,257,21793,46212,2175563]

theorem envBound51371 : H12AffineFastState.Bounded env51371 := by
  intro p hp
  have h : env51371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51370_51371 : H12AffineEnvironment.transform 23 10588556 env51370 = env51371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env51370 == env51371) = true)

def env51372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6623298,2098512,17665,2462110,2102684,6349853,257,21793,46212,2175563]

theorem envBound51372 : H12AffineFastState.Bounded env51372 := by
  intro p hp
  have h : env51372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51371_51372 : H12AffineEnvironment.transform 22 2101328 env51371 = env51372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env51371 == env51372) = true)

def env51373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2177218,2098512,17665,2462110,2102684,2411677,257,21793,46212,2175563]

theorem envBound51373 : H12AffineFastState.Bounded env51373 := by
  intro p hp
  have h : env51373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51372_51373 : H12AffineEnvironment.transform 21 272512 env51372 = env51373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51372 == env51373) = true)

theorem identity51373 : scanCanonicalize (H12AffineFastState.compose env51373 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound51373 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,77898,272512,73754,98780,8328,64,2184,79130,17665,303572,75222,392407,257,21793,46212,513]

theorem envBound51374 : H12AffineFastState.Bounded env51374 := by
  intro p hp
  have h : env51374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51373_51374 : H12AffineEnvironment.transform 20 77898 env51373 = env51374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env51373 == env51374) = true)

def env51375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272392,73754,98644,8192,64,2048,79130,17665,303452,75102,392287,257,21793,46092,513]

theorem envBound51375 : H12AffineFastState.Bounded env51375 := by
  intro p hp
  have h : env51375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51374_51375 : H12AffineEnvironment.transform 6 8 env51374 = env51375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env51374 == env51375) = true)

theorem identity51375 : scanCanonicalize (H12AffineFastState.compose env51375 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51375 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env51376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,262144,1025,32769,69911,264533,65863,98644,349,64,2048,70727,17665,294913,66563,384258,257,21793,38225,513]

theorem envBound51376 : H12AffineFastState.Bounded env51376 := by
  intro p hp
  have h : env51376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51375_51376 : H12AffineEnvironment.transform 12 349 env51375 = env51376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51375 == env51376) = true)

theorem identity51376 : scanCanonicalize (H12AffineFastState.compose env51376 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound51376 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env51377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,35188,1025,32769,69911,32801,65863,98644,349,64,2048,70727,17665,2421,66563,87158,257,21793,38225,513]

theorem envBound51377 : H12AffineFastState.Bounded env51377 := by
  intro p hp
  have h : env51377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51376_51377 : H12AffineEnvironment.transform 17 35188 env51376 = env51377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env51376 == env51377) = true)

theorem identity51377 : scanCanonicalize (H12AffineFastState.compose env51377 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound51377 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,65536,70727,35188,1025,32769,69911,32801,65863,98644,349,64,2048,70727,4096,2421,66563,65911,257,32,38225,513]

theorem envBound51378 : H12AffineFastState.Bounded env51378 := by
  intro p hp
  have h : env51378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51377_51378 : H12AffineEnvironment.transform 13 5377 env51377 = env51378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env51377 == env51378) = true)

theorem identity51378 : scanCanonicalize (H12AffineFastState.compose env51378 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound51378 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env51379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1297,65536,70727,3173,1025,1296,69911,1328,65863,66629,349,64,2048,70727,4096,2421,66563,65911,257,32,4160,513]

theorem envBound51379 : H12AffineFastState.Bounded env51379 := by
  intro p hp
  have h : env51379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51378_51379 : H12AffineEnvironment.transform 14 1297 env51378 = env51379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env51378 == env51379) = true)

theorem identity51379 : scanCanonicalize (H12AffineFastState.compose env51379 (packedSelected [12,15] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound51379 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env51380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1297,34,5221,3173,1025,1296,4405,1328,357,1127,349,64,2048,5221,4096,2421,1057,341,257,32,4160,513]

theorem envBound51380 : H12AffineFastState.Bounded env51380 := by
  intro p hp
  have h : env51380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51379_51380 : H12AffineEnvironment.transform 15 34 env51379 = env51380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env51379 == env51380) = true)

def env51381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,73754,98645,8193,64,2049,79130,17665,303453,75103,392286,257,21793,46093,513]

theorem envBound51381 : H12AffineFastState.Bounded env51381 := by
  intro p hp
  have h : env51381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51374_51381 : H12AffineEnvironment.transform 6 9 env51374 = env51381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51374 == env51381) = true)

theorem identity51381 : scanCanonicalize (H12AffineFastState.compose env51381 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound51381 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env51382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,67619,1025,32769,77898,73770,73754,98645,8193,64,2049,79130,17665,108926,75103,62589,257,21793,46093,513]

theorem envBound51382 : H12AffineFastState.Bounded env51382 := by
  intro p hp
  have h : env51382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51381_51382 : H12AffineEnvironment.transform 17 67619 env51381 = env51382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env51381 == env51382) = true)

theorem identity51382 : scanCanonicalize (H12AffineFastState.compose env51382 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound51382 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env51383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,79178,67619,1025,32769,77898,73770,73754,98645,8193,64,2049,79130,12556,108926,75103,32880,257,8492,46093,513]

theorem envBound51383 : H12AffineFastState.Bounded env51383 := by
  intro p hp
  have h : env51383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51382_51383 : H12AffineEnvironment.transform 13 13325 env51382 = env51383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env51382 == env51383) = true)

theorem identity51383 : scanCanonicalize (H12AffineFastState.compose env51383 (packedSelected [0,1,2,6,7,8,12,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound51383 : packedSelected [0,1,2,6,7,8,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env51384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,65536,70679,67619,1025,32769,69911,65911,65863,98645,348,64,2049,70727,4177,100387,66562,32880,257,113,38224,513]

theorem envBound51384 : H12AffineFastState.Bounded env51384 := by
  intro p hp
  have h : env51384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51383_51384 : H12AffineEnvironment.transform 12 349 env51383 = env51384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env51383 == env51384) = true)

theorem identity51384 : scanCanonicalize (H12AffineFastState.compose env51384 (packedSelected [1,2,6,8,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound51384 : packedSelected [1,2,6,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env51385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,99,5236,2112,1025,32769,4468,276,292,33078,348,64,2049,5156,4177,34880,1121,32880,257,113,38224,513]

theorem envBound51385 : H12AffineFastState.Bounded env51385 := by
  intro p hp
  have h : env51385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51384_51385 : H12AffineEnvironment.transform 15 99 env51384 = env51385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env51384 == env51385) = true)

theorem identity51385 : scanCanonicalize (H12AffineFastState.compose env51385 (packedSelected [0,1,3,4,5,7,8,9,15] rootPS)) = affineNative (2^(14+1) ^^^ 357) := by decide +kernel

theorem selectedBound51385 : packedSelected [0,1,3,4,5,7,8,9,15] rootPS < 2^1333 := by decide +kernel

def env51386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,357,99,5236,2112,1025,356,4468,276,292,83,348,64,2049,5156,4177,2341,1121,277,257,113,5173,513]

theorem envBound51386 : H12AffineFastState.Bounded env51386 := by
  intro p hp
  have h : env51386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51385_51386 : H12AffineEnvironment.transform 14 357 env51385 = env51386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 357 env51385 == env51386) = true)

theorem identity51386 : scanCanonicalize (H12AffineFastState.compose env51386 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound51386 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51387 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,4096,57,5172,1,99,5236,2112,1025,0,4112,112,64,83,56,64,2049,5156,4177,2113,1121,113,101,113,5173,513]

theorem envBound51387 : H12AffineFastState.Bounded env51387 := by
  intro p hp
  have h : env51387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51386_51387 : H12AffineEnvironment.transform 7 100 env51386 = env51387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env51386 == env51387) = true)

theorem identity51387 : scanCanonicalize (H12AffineFastState.compose env51387 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound51387 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env51388 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,3135,57,2059,1,99,2123,2112,1025,0,3119,112,64,83,56,64,2049,2075,3182,2113,1121,113,101,113,2058,513]

theorem envBound51388 : H12AffineFastState.Bounded env51388 := by
  intro p hp
  have h : env51388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51387_51388 : H12AffineEnvironment.transform 11 3135 env51387 = env51388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env51387 == env51388) = true)

theorem identity51388 : scanCanonicalize (H12AffineFastState.compose env51388 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1118) := by decide +kernel

theorem selectedBound51388 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env51389 : List Nat := [2,4,8,16,32,64,9,100,512,1024,1118,97,57,1109,1,99,1045,1054,1025,0,113,112,64,83,56,64,1119,1093,48,1055,1121,113,101,113,1108,513]

theorem envBound51389 : H12AffineFastState.Bounded env51389 := by
  intro p hp
  have h : env51389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51388_51389 : H12AffineEnvironment.transform 10 1118 env51388 = env51389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1118 env51388 == env51389) = true)

theorem identity51389 : scanCanonicalize (H12AffineFastState.compose env51389 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound51389 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env51390 : List Nat := [2,4,8,16,32,64,9,100,512,20,74,97,57,65,1,99,1,10,21,0,113,112,64,83,56,64,75,81,48,11,117,113,101,113,64,513]

theorem envBound51390 : H12AffineFastState.Bounded env51390 := by
  intro p hp
  have h : env51390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51389_51390 : H12AffineEnvironment.transform 9 20 env51389 = env51390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env51389 == env51390) = true)

theorem identity51390 : scanCanonicalize (H12AffineFastState.compose env51390 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound51390 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env51391 : List Nat := [2,4,8,16,32,32,9,4,512,20,42,1,57,33,1,3,1,10,21,0,17,16,32,51,56,32,43,49,48,11,21,17,5,17,32,513]

theorem envBound51391 : H12AffineFastState.Bounded env51391 := by
  intro p hp
  have h : env51391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51390_51391 : H12AffineEnvironment.transform 5 32 env51390 = env51391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env51390 == env51391) = true)

theorem identity51391 : scanCanonicalize (H12AffineFastState.compose env51391 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound51391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51392 : List Nat := [2,4,8,2,32,32,9,4,512,6,42,1,43,33,1,3,1,10,7,0,3,2,32,33,42,32,43,35,34,11,7,3,5,3,32,513]

theorem envBound51392 : H12AffineFastState.Bounded env51392 := by
  intro p hp
  have h : env51392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51391_51392 : H12AffineEnvironment.transform 3 2 env51391 = env51392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env51391 == env51392) = true)

theorem identity51392 : scanCanonicalize (H12AffineFastState.compose env51392 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound51392 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env51393 : List Nat := [2,4,8,2,3,3,9,4,512,6,9,1,8,2,1,3,1,10,7,0,3,2,3,2,9,3,8,0,1,11,7,3,5,3,3,513]

theorem envBound51393 : H12AffineFastState.Bounded env51393 := by
  intro p hp
  have h : env51393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51392_51393 : H12AffineEnvironment.transform 4 3 env51392 = env51393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env51392 == env51393) = true)

def env51394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2177219,2098512,17665,2462110,2102684,2411676,257,21793,46212,2175563]

theorem envBound51394 : H12AffineFastState.Bounded env51394 := by
  intro p hp
  have h : env51394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51372_51394 : H12AffineEnvironment.transform 21 272513 env51372 = env51394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env51372 == env51394) = true)

theorem identity51394 : scanCanonicalize (H12AffineFastState.compose env51394 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound51394 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25029,262144,1025,32769,2097152,272513,2101328,41431,8328,64,2103496,2098512,17665,2404757,2102684,2411676,257,21793,46212,2101824]

theorem envBound51395 : H12AffineFastState.Bounded env51395 := by
  intro p hp
  have h : env51395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51394_51395 : H12AffineEnvironment.transform 15 8203 env51394 = env51395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env51394 == env51395) = true)

theorem identity51395 : scanCanonicalize (H12AffineFastState.compose env51395 (packedSelected [3,10,16,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound51395 : packedSelected [3,10,16,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env51396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25029,262144,1025,8540,2097152,272513,2101328,138,8328,64,2103496,2098512,17665,2363592,2102684,2387393,257,21793,5593,2101824]

theorem envBound51396 : H12AffineFastState.Bounded env51396 := by
  intro p hp
  have h : env51396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51395_51396 : H12AffineEnvironment.transform 14 8541 env51395 = env51396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env51395 == env51396) = true)

theorem identity51396 : scanCanonicalize (H12AffineFastState.compose env51396 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound51396 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env51397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,262144,1025,8540,2097152,272392,2101328,3,8193,64,2103361,2098512,17665,2363457,2102549,2387272,257,21793,5456,2101824]

theorem envBound51397 : H12AffineFastState.Bounded env51397 := by
  intro p hp
  have h : env51397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51396_51397 : H12AffineEnvironment.transform 6 9 env51396 = env51397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env51396 == env51397) = true)

theorem identity51397 : scanCanonicalize (H12AffineFastState.compose env51397 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 31837) := by decide +kernel

theorem selectedBound51397 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env51398 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24908,31837,1025,8540,2097152,21589,2101328,3,8193,64,2103361,2098512,17665,2124828,2102549,2101525,257,21793,5456,2101824]

theorem envBound51398 : H12AffineFastState.Bounded env51398 := by
  intro p hp
  have h : env51398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51397_51398 : H12AffineEnvironment.transform 17 31837 env51397 = env51398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31837 env51397 == env51398) = true)

theorem identity51398 : scanCanonicalize (H12AffineFastState.compose env51398 (packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound51398 : packedSelected [0,1,2,3,4,5,7,8,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env51399 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,8203,24633,31837,1025,8233,2097152,21589,2101328,3,8193,64,2103361,2098213,17524,2124828,2102368,2101344,116,21588,5157,2101824]

theorem envBound51399 : H12AffineFastState.Bounded env51399 := by
  intro p hp
  have h : env51399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51398_51399 : H12AffineEnvironment.transform 7 117 env51398 = env51399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env51398 == env51399) = true)

theorem identity51399 : scanCanonicalize (H12AffineFastState.compose env51399 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound51399 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env51400 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8232,8203,13388,10280,1025,8233,2097152,32,2101328,3,8193,64,2103361,2098213,4097,2111593,2102368,2101344,116,33,5157,2101824]

theorem envBound51400 : H12AffineFastState.Bounded env51400 := by
  intro p hp
  have h : env51400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51399_51400 : H12AffineEnvironment.transform 13 5237 env51399 = env51400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env51399 == env51400) = true)

theorem identity51400 : scanCanonicalize (H12AffineFastState.compose env51400 (packedSelected [12,15] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound51400 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env51401 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,8232,8203,13388,10280,1025,8233,4161,32,17,3,8193,64,2048,5220,4097,10280,1057,33,116,33,5157,513]

theorem envBound51401 : H12AffineFastState.Bounded env51401 := by
  intro p hp
  have h : env51401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51400_51401 : H12AffineEnvironment.transform 20 4161 env51400 = env51401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env51400 == env51401) = true)

theorem identity51401 : scanCanonicalize (H12AffineFastState.compose env51401 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound51401 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env51402 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5237,0,35,5220,2048,1025,1,4161,32,17,3,41,64,2048,5220,4097,2048,1057,33,116,33,5157,513]

theorem envBound51402 : H12AffineFastState.Bounded env51402 := by
  intro p hp
  have h : env51402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51401_51402 : H12AffineEnvironment.transform 12 40 env51401 = env51402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env51401 == env51402) = true)

theorem identity51402 : scanCanonicalize (H12AffineFastState.compose env51402 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound51402 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env51403 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,4096,40,5237,0,35,5220,1135,1025,1,4161,32,17,3,41,64,1135,5220,4097,1135,1057,33,116,33,5157,513]

theorem envBound51403 : H12AffineFastState.Bounded env51403 := by
  intro p hp
  have h : env51403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51402_51403 : H12AffineEnvironment.transform 10 1135 env51402 = env51403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env51402 == env51403) = true)

theorem identity51403 : scanCanonicalize (H12AffineFastState.compose env51403 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound51403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env51404 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,0,40,1141,0,35,1124,1135,1025,1,65,32,17,3,41,64,1135,1124,1,1135,1057,33,116,33,1061,513]

theorem envBound51404 : H12AffineFastState.Bounded env51404 := by
  intro p hp
  have h : env51404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51403_51404 : H12AffineEnvironment.transform 11 0 env51403 = env51404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env51403 == env51404) = true)

theorem identity51404 : scanCanonicalize (H12AffineFastState.compose env51404 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound51404 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env51405 : List Nat := [2,4,8,16,32,64,9,117,512,111,0,0,40,26,0,35,11,0,110,1,65,32,17,3,41,64,0,11,1,0,78,33,116,33,74,513]

theorem envBound51405 : H12AffineFastState.Bounded env51405 := by
  intro p hp
  have h : env51405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51404_51405 : H12AffineEnvironment.transform 9 111 env51404 = env51405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env51404 == env51405) = true)

theorem identity51405 : scanCanonicalize (H12AffineFastState.compose env51405 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound51405 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env51406 : List Nat := [2,4,8,16,32,58,9,15,512,21,0,0,40,26,0,35,11,0,20,1,59,32,17,3,41,58,0,11,1,0,52,33,14,33,48,513]

theorem envBound51406 : H12AffineFastState.Bounded env51406 := by
  intro p hp
  have h : env51406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51405_51406 : H12AffineEnvironment.transform 5 58 env51405 = env51406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env51405 == env51406) = true)

theorem identity51406 : scanCanonicalize (H12AffineFastState.compose env51406 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound51406 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env51407 : List Nat := [2,4,8,16,10,16,9,15,512,21,0,0,2,26,0,9,11,0,20,1,17,10,17,3,3,16,0,11,1,0,30,11,14,11,26,513]

theorem envBound51407 : H12AffineFastState.Bounded env51407 := by
  intro p hp
  have h : env51407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51406_51407 : H12AffineEnvironment.transform 4 10 env51406 = env51407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env51406 == env51407) = true)

theorem identity51407 : scanCanonicalize (H12AffineFastState.compose env51407 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound51407 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env51408 : List Nat := [2,4,8,1,10,1,9,15,512,4,0,0,2,11,0,9,11,0,5,1,0,10,0,3,3,1,0,11,1,0,15,11,14,11,11,513]

theorem envBound51408 : H12AffineFastState.Bounded env51408 := by
  intro p hp
  have h : env51408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51407_51408 : H12AffineEnvironment.transform 3 1 env51407 = env51408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env51407 == env51408) = true)

theorem identity51408 : scanCanonicalize (H12AffineFastState.compose env51408 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound51408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env51409 : List Nat := [2,4,8,1,10,1,9,15,15,4,0,0,2,11,0,9,11,0,5,1,0,10,0,3,3,1,0,11,1,0,15,11,14,11,11,14]

theorem envBound51409 : H12AffineFastState.Bounded env51409 := by
  intro p hp
  have h : env51409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51408_51409 : H12AffineEnvironment.transform 8 15 env51408 = env51409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env51408 == env51409) = true)

theorem identity51409 : scanCanonicalize (H12AffineFastState.compose env51409 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound51409 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env51410 : List Nat := [2,4,3,1,1,1,2,4,4,4,0,0,2,0,0,2,0,0,5,1,0,1,0,3,3,1,0,0,1,0,4,0,5,0,0,5]

theorem envBound51410 : H12AffineFastState.Bounded env51410 := by
  intro p hp
  have h : env51410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51409_51410 : H12AffineEnvironment.transform 2 3 env51409 = env51410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env51409 == env51410) = true)

theorem identity51410 : scanCanonicalize (H12AffineFastState.compose env51410 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound51410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env51411 : List Nat := [1,4,0,1,1,1,1,4,4,4,0,0,1,0,0,1,0,0,5,1,0,1,0,0,0,1,0,0,1,0,4,0,5,0,0,5]

theorem envBound51411 : H12AffineFastState.Bounded env51411 := by
  intro p hp
  have h : env51411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51410_51411 : H12AffineEnvironment.transform 0 1 env51410 = env51411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env51410 == env51411) = true)

def env51412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6623298,2098513,17664,2462111,2102684,6349852,257,21793,46212,2175563]

theorem envBound51412 : H12AffineFastState.Bounded env51412 := by
  intro p hp
  have h : env51412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51371_51412 : H12AffineEnvironment.transform 22 2101329 env51371 = env51412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env51371 == env51412) = true)

def env51413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2177218,2098513,17664,2462111,2102684,2411676,257,21793,46212,2175563]

theorem envBound51413 : H12AffineFastState.Bounded env51413 := by
  intro p hp
  have h : env51413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51412_51413 : H12AffineEnvironment.transform 21 272512 env51412 = env51413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env51412 == env51413) = true)

theorem identity51413 : scanCanonicalize (H12AffineFastState.compose env51413 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound51413 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env51414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115870,272512,120015,98781,8328,64,64604,115151,17664,283905,119042,329730,257,21793,46212,63189]

theorem envBound51414 : H12AffineFastState.Bounded env51414 := by
  intro p hp
  have h : env51414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51413_51414 : H12AffineEnvironment.transform 20 115870 env51413 = env51414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env51413 == env51414) = true)

def env51415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115870,272512,119967,98701,8328,16,64524,115103,17664,283905,119042,329730,257,21793,46212,63109]

theorem envBound51415 : H12AffineFastState.Bounded env51415 := by
  intro p hp
  have h : env51415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51414_51415 : H12AffineEnvironment.transform 5 16 env51414 = env51415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env51414 == env51415) = true)

theorem identity51415 : scanCanonicalize (H12AffineFastState.compose env51415 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound51415 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env51416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,76078,1025,32769,115870,65966,119967,98701,8328,16,64524,115103,17664,97327,119042,8492,257,21793,46212,63109]

theorem envBound51416 : H12AffineFastState.Bounded env51416 := by
  intro p hp
  have h : env51416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51415_51416 : H12AffineEnvironment.transform 17 76078 env51415 = env51416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env51415 == env51416) = true)

theorem identity51416 : scanCanonicalize (H12AffineFastState.compose env51416 (packedSelected [0,1,4,7,11,19,22,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

end H12CloudChart1