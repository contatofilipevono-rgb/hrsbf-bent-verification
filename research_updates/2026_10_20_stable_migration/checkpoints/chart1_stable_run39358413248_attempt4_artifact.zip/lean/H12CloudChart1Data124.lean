import H12CloudChart1Data123

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env31460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,10281,1024,8660,4161,4194304,16,2,8328,65,4270243,79131,4097,10400,75222,4268162,256,73770,79194,513]

theorem envBound31460 : H12AffineFastState.Bounded env31460 := by
  intro p hp
  have h : env31460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31459_31460 : H12AffineEnvironment.transform 16 13389 env31459 = env31460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env31459 == env31460) = true)

theorem identity31460 : scanCanonicalize (H12AffineFastState.compose env31460 (packedSelected [2,6,7,14,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31460 : packedSelected [2,6,7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env31461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13389,10281,1024,8660,4161,4194304,16,2,8328,65,4196520,5392,4097,10400,1501,4194441,256,33,5457,513]

theorem envBound31461 : H12AffineFastState.Bounded env31461 := by
  intro p hp
  have h : env31461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31460_31461 : H12AffineEnvironment.transform 15 8203 env31460 = env31461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31460 == env31461) = true)

theorem identity31461 : scanCanonicalize (H12AffineFastState.compose env31461 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound31461 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8203,13389,10281,1024,8660,4161,8692,16,2,8328,65,10588,5392,4097,10400,1501,8573,256,33,5457,513]

theorem envBound31462 : H12AffineFastState.Bounded env31462 := by
  intro p hp
  have h : env31462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31461_31462 : H12AffineEnvironment.transform 21 8692 env31461 = env31462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env31461 == env31462) = true)

theorem identity31462 : scanCanonicalize (H12AffineFastState.compose env31462 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound31462 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,479,5529,2557,1024,0,4161,32,16,2,348,65,2184,5392,4097,2420,1501,169,256,33,5457,513]

theorem envBound31463 : H12AffineFastState.Bounded env31463 := by
  intro p hp
  have h : env31463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31462_31463 : H12AffineEnvironment.transform 12 468 env31462 = env31463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env31462 == env31463) = true)

theorem identity31463 : scanCanonicalize (H12AffineFastState.compose env31463 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31463 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,342,5392,2420,1024,0,4161,32,16,2,348,65,2049,5392,4097,2420,1364,32,256,33,5457,513]

theorem envBound31464 : H12AffineFastState.Bounded env31464 := by
  intro p hp
  have h : env31464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31463_31464 : H12AffineEnvironment.transform 6 9 env31463 = env31464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31463 == env31464) = true)

theorem identity31464 : scanCanonicalize (H12AffineFastState.compose env31464 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3419) := by decide +kernel

theorem selectedBound31464 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3419,349,2139,1,342,2123,2420,1024,0,3354,32,16,2,348,65,2049,2123,3418,2420,1364,32,256,33,2058,513]

theorem envBound31465 : H12AffineFastState.Bounded env31465 := by
  intro p hp
  have h : env31465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31464_31465 : H12AffineEnvironment.transform 11 3419 env31464 = env31465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3419 env31464 == env31465) = true)

theorem identity31465 : scanCanonicalize (H12AffineFastState.compose env31465 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 346) := by decide +kernel

theorem selectedBound31465 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31466 : List Nat := [2,4,8,16,32,64,9,256,512,346,2048,2049,349,2139,1,342,2123,2420,346,0,2112,32,16,2,348,65,2049,2123,2048,2420,14,32,256,33,2058,513]

theorem envBound31466 : H12AffineFastState.Bounded env31466 := by
  intro p hp
  have h : env31466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31465_31466 : H12AffineEnvironment.transform 9 346 env31465 = env31466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 346 env31465 == env31466) = true)

def env31467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,138340,1024,8661,4161,4194304,16,3,8328,65,4270242,79131,4096,10400,75222,4268162,256,73771,79195,513]

theorem envBound31467 : H12AffineFastState.Bounded env31467 := by
  intro p hp
  have h : env31467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31458_31467 : H12AffineEnvironment.transform 13 5377 env31458 = env31467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31458 == env31467) = true)

theorem identity31467 : scanCanonicalize (H12AffineFastState.compose env31467 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound31467 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13508,10400,1024,8661,4161,4194304,16,3,8328,65,4270242,79131,4096,10400,75222,4268162,256,73771,79195,513]

theorem envBound31468 : H12AffineFastState.Bounded env31468 := by
  intro p hp
  have h : env31468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31467_31468 : H12AffineEnvironment.transform 16 13508 env31467 = env31468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env31467 == env31468) = true)

theorem identity31468 : scanCanonicalize (H12AffineFastState.compose env31468 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound31468 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env31469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13508,10400,1024,8661,4161,4194304,16,3,8328,65,4196384,5529,4096,10400,1364,4194304,256,169,5593,513]

theorem envBound31469 : H12AffineFastState.Bounded env31469 := by
  intro p hp
  have h : env31469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31468_31469 : H12AffineEnvironment.transform 15 8322 env31468 = env31469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env31468 == env31469) = true)

theorem identity31469 : scanCanonicalize (H12AffineFastState.compose env31469 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31469 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5529,2557,1024,136,4161,4194304,16,3,469,65,4196384,5529,4096,2557,1364,4194304,256,169,5593,513]

theorem envBound31470 : H12AffineFastState.Bounded env31470 := by
  intro p hp
  have h : env31470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31469_31470 : H12AffineEnvironment.transform 12 349 env31469 = env31470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31469 == env31470) = true)

theorem identity31470 : scanCanonicalize (H12AffineFastState.compose env31470 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound31470 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,479,5529,2557,1024,136,4161,168,16,3,469,65,2184,5529,4096,2557,1364,168,256,169,5593,513]

theorem envBound31471 : H12AffineFastState.Bounded env31471 := by
  intro p hp
  have h : env31471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31470_31471 : H12AffineEnvironment.transform 21 168 env31470 = env31471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env31470 == env31471) = true)

theorem identity31471 : scanCanonicalize (H12AffineFastState.compose env31471 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound31471 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31472 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,301,5377,137,431,5529,2445,1024,136,4145,168,16,3,421,49,2184,5529,4096,2445,1316,168,256,169,5545,513]

theorem envBound31472 : H12AffineFastState.Bounded env31472 := by
  intro p hp
  have h : env31472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31471_31472 : H12AffineEnvironment.transform 5 48 env31471 = env31472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env31471 == env31472) = true)

theorem identity31472 : scanCanonicalize (H12AffineFastState.compose env31472 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound31472 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env31473 : List Nat := [2,4,8,16,32,48,40,256,512,1024,2048,4096,301,5377,33,263,5425,2341,1024,32,4145,0,16,3,269,49,2080,5425,4096,2341,1316,0,256,1,5377,513]

theorem envBound31473 : H12AffineFastState.Bounded env31473 := by
  intro p hp
  have h : env31473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31472_31473 : H12AffineEnvironment.transform 6 40 env31472 = env31473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env31472 == env31473) = true)

def env31474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound31474 : H12AffineFastState.Bounded env31474 := by
  intro p hp
  have h : env31474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31290_31474 : H12AffineEnvironment.transform 18 1025 env31290 = env31474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31290 == env31474) = true)

theorem identity31474 : scanCanonicalize (H12AffineFastState.compose env31474 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444659) := by decide +kernel

theorem selectedBound31474 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444659,16777216,8328,65,23235954,18973836,333859,2329971,19188066,23160257,257,17074654,17066106,19263156]

theorem envBound31475 : H12AffineFastState.Bounded env31475 := by
  intro p hp
  have h : env31475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31474_31475 : H12AffineEnvironment.transform 22 2444659 env31474 = env31475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444659 env31474 == env31475) = true)

def env31476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,16777216,8328,65,16959642,18973836,333859,2329971,19188066,16850985,257,17074654,17066106,19263156]

theorem envBound31476 : H12AffineFastState.Bounded env31476 := by
  intro p hp
  have h : env31476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31475_31476 : H12AffineEnvironment.transform 21 2115048 env31475 = env31476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env31475 == env31476) = true)

def env31477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431072,8328,65,2609402,302316,333859,2329971,119042,2373705,257,2199998,2191386,63188]

theorem envBound31477 : H12AffineFastState.Bounded env31477 := by
  intro p hp
  have h : env31477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31476_31477 : H12AffineEnvironment.transform 23 2431072 env31476 = env31477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env31476 == env31477) = true)

def env31478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329760,8328,65,508090,302316,333859,236851,119042,272393,257,98814,90202,63188]

theorem envBound31478 : H12AffineFastState.Bounded env31478 := by
  intro p hp
  have h : env31478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31477_31478 : H12AffineEnvironment.transform 20 4160 env31477 = env31478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31477 == env31478) = true)

theorem identity31478 : scanCanonicalize (H12AffineFastState.compose env31478 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound31478 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,21928,73754,95497,8328,65,245139,57797,91402,236851,119042,21792,257,98814,90202,63188]

theorem envBound31479 : H12AffineFastState.Bounded env31479 := by
  intro p hp
  have h : env31479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31478_31479 : H12AffineEnvironment.transform 17 32041 env31478 = env31479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env31478 == env31479) = true)

def env31480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10401,1025,32769,4160,32,73754,73857,8328,65,245139,46157,77954,236851,99466,168,257,98814,79314,41820]

theorem envBound31480 : H12AffineFastState.Bounded env31480 := by
  intro p hp
  have h : env31480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31479_31480 : H12AffineEnvironment.transform 13 5512 env31479 = env31480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env31479 == env31480) = true)

def env31481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4160,32,73754,73737,8192,65,245019,46157,77834,236851,99330,32,257,98678,79194,41820]

theorem envBound31481 : H12AffineFastState.Bounded env31481 := by
  intro p hp
  have h : env31481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31480_31481 : H12AffineEnvironment.transform 6 8 env31480 = env31481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31480 == env31481) = true)

theorem identity31481 : scanCanonicalize (H12AffineFastState.compose env31481 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,4160,32,73754,73737,8192,65,203846,5392,77834,212078,75103,32,257,73771,79194,513]

theorem envBound31482 : H12AffineFastState.Bounded env31482 := by
  intro p hp
  have h : env31482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31481_31482 : H12AffineEnvironment.transform 14 8541 env31481 = env31482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31481 == env31482) = true)

theorem identity31482 : scanCanonicalize (H12AffineFastState.compose env31482 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound31482 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env31483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8283,131072,10281,1025,8540,4160,32,65,82,8192,65,146461,5392,4177,138293,1284,32,257,112,5377,513]

theorem envBound31483 : H12AffineFastState.Bounded env31483 := by
  intro p hp
  have h : env31483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31482_31483 : H12AffineEnvironment.transform 15 8283 env31482 = env31483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env31482 == env31483) = true)

theorem identity31483 : scanCanonicalize (H12AffineFastState.compose env31483 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound31483 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env31484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8283,5440,10281,1025,8540,4160,32,65,82,8192,65,10589,5392,4177,2421,1284,32,257,112,5377,513]

theorem envBound31484 : H12AffineFastState.Bounded env31484 := by
  intro p hp
  have h : env31484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31483_31484 : H12AffineEnvironment.transform 16 5440 env31483 = env31484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env31483 == env31484) = true)

theorem identity31484 : scanCanonicalize (H12AffineFastState.compose env31484 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31484 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,343,5440,2341,1025,80,4160,32,65,82,268,65,2129,5392,4177,2421,1284,32,257,112,5377,513]

theorem envBound31485 : H12AffineFastState.Bounded env31485 := by
  intro p hp
  have h : env31485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31484_31485 : H12AffineEnvironment.transform 12 268 env31484 = env31485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31484 == env31485) = true)

theorem identity31485 : scanCanonicalize (H12AffineFastState.compose env31485 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2414) := by decide +kernel

theorem selectedBound31485 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2414,268,3182,81,343,3118,2341,1025,80,2350,32,65,82,268,65,2129,3198,2367,2421,1284,32,257,112,3183,513]

theorem envBound31486 : H12AffineFastState.Bounded env31486 := by
  intro p hp
  have h : env31486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31485_31486 : H12AffineEnvironment.transform 11 2414 env31485 = env31486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env31485 == env31486) = true)

def env31487 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4160,32,73754,73736,8193,65,245018,46157,77835,236851,99331,33,257,98679,79195,41820]

theorem envBound31487 : H12AffineFastState.Bounded env31487 := by
  intro p hp
  have h : env31487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31480_31487 : H12AffineEnvironment.transform 6 9 env31480 = env31487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31480 == env31487) = true)

theorem identity31487 : scanCanonicalize (H12AffineFastState.compose env31487 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound31487 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env31488 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,114,131072,10280,1025,32769,4160,32,8296,8314,8193,65,179560,46157,12409,171329,33905,33,257,33029,13609,41820]

theorem envBound31488 : H12AffineFastState.Bounded env31488 := by
  intro p hp
  have h : env31488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31487_31488 : H12AffineEnvironment.transform 15 114 env31487 = env31488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env31487 == env31488) = true)

theorem identity31488 : scanCanonicalize (H12AffineFastState.compose env31488 (packedSelected [0,2,6,7,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 9528) := by decide +kernel

theorem selectedBound31488 : packedSelected [0,2,6,7,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env31489 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9528,114,131072,10280,1025,9529,4160,32,8296,8314,8193,65,137296,4469,12409,145529,8521,33,257,9277,13609,1636]

theorem envBound31489 : H12AffineFastState.Bounded env31489 := by
  intro p hp
  have h : env31489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31488_31489 : H12AffineEnvironment.transform 14 9528 env31488 = env31489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9528 env31488 == env31489) = true)

theorem identity31489 : scanCanonicalize (H12AffineFastState.compose env31489 (packedSelected [0,2,4,5,6,7,8,9,10,14,16,19,20,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31489 : packedSelected [0,2,4,5,6,7,8,9,10,14,16,19,20,24,28] rootPS < 2^1333 := by decide +kernel

def env31490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1077,114,131072,2341,1025,1076,4160,32,357,375,268,65,137296,4469,4468,137588,68,33,257,1328,5156,1636]

theorem envBound31490 : H12AffineFastState.Bounded env31490 := by
  intro p hp
  have h : env31490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31489_31490 : H12AffineEnvironment.transform 12 269 env31489 = env31490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31489 == env31490) = true)

theorem identity31490 : scanCanonicalize (H12AffineFastState.compose env31490 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound31490 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env31491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1077,114,4096,2341,1025,1076,4160,32,357,375,268,65,2128,4469,4468,2420,68,33,257,1328,5156,1636]

theorem envBound31491 : H12AffineFastState.Bounded env31491 := by
  intro p hp
  have h : env31491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31490_31491 : H12AffineEnvironment.transform 16 4096 env31490 = env31491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env31490 == env31491) = true)

theorem identity31491 : scanCanonicalize (H12AffineFastState.compose env31491 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31491 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31492 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,269,4405,1,114,4096,2341,53,0,4160,32,357,375,268,65,2128,4469,4468,2420,68,33,257,260,4112,592]

theorem envBound31492 : H12AffineFastState.Bounded env31492 := by
  intro p hp
  have h : env31492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31491_31492 : H12AffineEnvironment.transform 9 52 env31491 = env31492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31491 == env31492) = true)

theorem identity31492 : scanCanonicalize (H12AffineFastState.compose env31492 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound31492 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env31493 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2415,269,2138,1,114,2415,2341,53,0,2351,32,357,375,268,65,2128,2074,2075,2420,68,33,257,260,2431,592]

theorem envBound31493 : H12AffineFastState.Bounded env31493 := by
  intro p hp
  have h : env31493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31492_31493 : H12AffineEnvironment.transform 11 2415 env31492 = env31493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env31492 == env31493) = true)

theorem identity31493 : scanCanonicalize (H12AffineFastState.compose env31493 (packedSelected [0,1,3,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31493 : packedSelected [0,1,3,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31494 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2366,269,2059,1,35,2366,2341,53,0,2351,32,308,294,268,16,2049,2074,2075,2341,21,33,257,260,2350,513]

theorem envBound31494 : H12AffineFastState.Bounded env31494 := by
  intro p hp
  have h : env31494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31493_31494 : H12AffineEnvironment.transform 5 17 env31493 = env31494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31493 == env31494) = true)

theorem identity31494 : scanCanonicalize (H12AffineFastState.compose env31494 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31494 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31495 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2074,41,2059,1,35,2074,2049,53,0,2059,32,16,2,40,16,2049,2074,2075,2049,21,33,37,32,2058,513]

theorem envBound31495 : H12AffineFastState.Bounded env31495 := by
  intro p hp
  have h : env31495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31494_31495 : H12AffineEnvironment.transform 7 36 env31494 = env31495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31494 == env31495) = true)

theorem identity31495 : scanCanonicalize (H12AffineFastState.compose env31495 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound31495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31496 : List Nat := [2,4,8,16,32,17,9,36,512,52,542,516,41,533,1,35,516,543,53,0,533,32,16,2,40,16,543,516,517,543,21,33,37,32,532,513]

theorem envBound31496 : H12AffineFastState.Bounded env31496 := by
  intro p hp
  have h : env31496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31495_31496 : H12AffineEnvironment.transform 10 542 env31495 = env31496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env31495 == env31496) = true)

theorem identity31496 : scanCanonicalize (H12AffineFastState.compose env31496 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31497 : List Nat := [2,4,8,6,32,7,9,36,512,34,520,516,41,515,1,35,516,521,35,0,515,32,6,2,40,6,521,516,517,521,3,33,37,32,514,513]

theorem envBound31497 : H12AffineFastState.Bounded env31497 := by
  intro p hp
  have h : env31497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31496_31497 : H12AffineEnvironment.transform 3 6 env31496 = env31497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31496 == env31497) = true)

theorem identity31497 : scanCanonicalize (H12AffineFastState.compose env31497 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31498 : List Nat := [2,3,8,1,32,0,9,35,512,34,520,515,41,515,1,35,515,521,35,0,515,32,1,2,40,1,521,515,514,521,3,33,34,32,514,513]

theorem envBound31498 : H12AffineFastState.Bounded env31498 := by
  intro p hp
  have h : env31498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31497_31498 : H12AffineEnvironment.transform 1 3 env31497 = env31498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31497 == env31498) = true)

theorem identity31498 : scanCanonicalize (H12AffineFastState.compose env31498 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31498 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31499 : List Nat := [2,3,8,1,0,0,9,3,512,2,520,515,9,515,1,3,515,521,3,0,515,0,1,2,8,1,521,515,514,521,3,1,2,0,514,513]

theorem envBound31499 : H12AffineFastState.Bounded env31499 := by
  intro p hp
  have h : env31499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31498_31499 : H12AffineEnvironment.transform 4 0 env31498 = env31499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31498 == env31499) = true)

theorem identity31499 : scanCanonicalize (H12AffineFastState.compose env31499 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31499 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31500 : List Nat := [2,3,2,1,0,0,3,3,512,2,514,515,3,515,1,3,515,515,3,0,515,0,1,2,2,1,515,515,514,515,3,1,2,0,514,513]

theorem envBound31500 : H12AffineFastState.Bounded env31500 := by
  intro p hp
  have h : env31500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31499_31500 : H12AffineEnvironment.transform 2 2 env31499 = env31500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31499 == env31500) = true)

def env31501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10400,1025,32769,4160,33,73754,73856,8328,65,245139,46156,77955,236851,99467,169,257,98814,79315,41821]

theorem envBound31501 : H12AffineFastState.Bounded env31501 := by
  intro p hp
  have h : env31501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31479_31501 : H12AffineEnvironment.transform 13 5513 env31479 = env31501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env31479 == env31501) = true)

theorem identity31501 : scanCanonicalize (H12AffineFastState.compose env31501 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound31501 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env31502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,5392,10400,1025,32769,4160,33,73754,73856,8328,65,108675,46156,77955,100387,99467,169,257,98814,79315,41821]

theorem envBound31502 : H12AffineFastState.Bounded env31502 := by
  intro p hp
  have h : env31502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31501_31502 : H12AffineEnvironment.transform 16 5392 env31501 = env31502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env31501 == env31502) = true)

theorem identity31502 : scanCanonicalize (H12AffineFastState.compose env31502 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound31502 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,40971,5392,10400,1025,32769,4160,33,32785,32907,8328,65,2184,46156,37000,10280,9344,169,257,8693,38360,41821]

theorem envBound31503 : H12AffineFastState.Bounded env31503 := by
  intro p hp
  have h : env31503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31502_31503 : H12AffineEnvironment.transform 15 40971 env31502 = env31503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env31502 == env31503) = true)

theorem identity31503 : scanCanonicalize (H12AffineFastState.compose env31503 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound31503 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env31504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,479,5392,10400,1025,8661,4160,33,8645,8543,8328,65,2184,5528,12636,10280,9344,169,257,8693,13324,649]

theorem envBound31504 : H12AffineFastState.Bounded env31504 := by
  intro p hp
  have h : env31504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31503_31504 : H12AffineEnvironment.transform 14 8660 env31503 = env31504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env31503 == env31504) = true)

theorem identity31504 : scanCanonicalize (H12AffineFastState.compose env31504 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31504 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,136,479,5392,2556,1025,137,4160,33,153,3,468,65,2184,5528,4096,2420,1500,169,257,169,5456,649]

theorem envBound31505 : H12AffineFastState.Bounded env31505 := by
  intro p hp
  have h : env31505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31504_31505 : H12AffineEnvironment.transform 12 348 env31504 = env31505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31504 == env31505) = true)

theorem identity31505 : scanCanonicalize (H12AffineFastState.compose env31505 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound31505 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31506 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,348,5409,32,375,5392,2388,1025,33,4160,33,49,3,380,65,2080,5424,4096,2420,1396,1,257,1,5456,545]

theorem envBound31506 : H12AffineFastState.Bounded env31506 := by
  intro p hp
  have h : env31506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31505_31506 : H12AffineEnvironment.transform 6 40 env31505 = env31506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env31505 == env31506) = true)

theorem identity31506 : scanCanonicalize (H12AffineFastState.compose env31506 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31506 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31507 : List Nat := [2,4,8,16,32,49,40,256,512,1024,2048,4096,301,5409,32,262,5392,2341,1025,33,4145,33,49,3,269,48,2080,5424,4096,2309,1285,1,257,1,5409,545]

theorem envBound31507 : H12AffineFastState.Bounded env31507 := by
  intro p hp
  have h : env31507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31506_31507 : H12AffineEnvironment.transform 5 49 env31506 = env31507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31506 == env31507) = true)

theorem identity31507 : scanCanonicalize (H12AffineFastState.compose env31507 (packedSelected [0,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound31507 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env31508 : List Nat := [2,4,8,16,32,49,40,256,512,1024,2048,1044,301,309,32,262,260,2341,1025,33,1061,33,49,3,269,48,2080,292,1044,2309,1285,1,257,1,309,545]

theorem envBound31508 : H12AffineFastState.Bounded env31508 := by
  intro p hp
  have h : env31508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31507_31508 : H12AffineEnvironment.transform 11 1044 env31507 = env31508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env31507 == env31508) = true)

theorem identity31508 : scanCanonicalize (H12AffineFastState.compose env31508 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31508 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31509 : List Nat := [2,4,8,16,32,49,40,256,512,52,2048,32,301,309,32,262,260,2341,53,33,17,33,49,3,269,48,2080,292,32,2309,305,1,257,1,309,545]

theorem envBound31509 : H12AffineFastState.Bounded env31509 := by
  intro p hp
  have h : env31509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31508_31509 : H12AffineEnvironment.transform 9 52 env31508 = env31509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31508 == env31509) = true)

theorem identity31509 : scanCanonicalize (H12AffineFastState.compose env31509 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31509 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31510 : List Nat := [2,4,8,16,32,49,40,4,512,52,2048,32,41,49,32,2,0,2081,53,33,17,33,49,3,9,48,2080,32,32,2049,53,1,5,1,49,545]

theorem envBound31510 : H12AffineFastState.Bounded env31510 := by
  intro p hp
  have h : env31510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31509_31510 : H12AffineEnvironment.transform 7 4 env31509 = env31510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31509 == env31510) = true)

theorem identity31510 : scanCanonicalize (H12AffineFastState.compose env31510 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound31510 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env31511 : List Nat := [2,4,8,16,32,49,40,4,512,52,33,32,41,49,32,2,0,0,53,33,17,33,49,3,9,48,1,32,32,32,53,1,5,1,49,545]

theorem envBound31511 : H12AffineFastState.Bounded env31511 := by
  intro p hp
  have h : env31511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31510_31511 : H12AffineEnvironment.transform 10 33 env31510 = env31511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env31510 == env31511) = true)

theorem identity31511 : scanCanonicalize (H12AffineFastState.compose env31511 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31511 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env31512 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,0,9,17,0,2,0,0,21,1,17,1,17,3,9,16,1,0,0,0,21,1,5,1,17,513]

theorem envBound31512 : H12AffineFastState.Bounded env31512 := by
  intro p hp
  have h : env31512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31511_31512 : H12AffineEnvironment.transform 4 0 env31511 = env31512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31511 == env31512) = true)

theorem identity31512 : scanCanonicalize (H12AffineFastState.compose env31512 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound31512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31513 : List Nat := [2,4,8,16,0,17,8,4,17,20,1,0,9,17,0,2,0,0,21,1,17,1,17,3,9,16,1,0,0,0,21,1,5,1,17,16]

theorem envBound31513 : H12AffineFastState.Bounded env31513 := by
  intro p hp
  have h : env31513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31512_31513 : H12AffineEnvironment.transform 8 17 env31512 = env31513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env31512 == env31513) = true)

def env31514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329761,8328,65,508091,302316,333859,236850,119042,272392,257,98815,90203,63188]

theorem envBound31514 : H12AffineFastState.Bounded env31514 := by
  intro p hp
  have h : env31514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31477_31514 : H12AffineEnvironment.transform 20 4161 env31477 = env31514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31477 == env31514) = true)

def env31515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,21929,95634,73857,8328,65,256027,46156,77955,236850,119042,168,257,98815,90203,63188]

theorem envBound31515 : H12AffineFastState.Bounded env31515 := by
  intro p hp
  have h : env31515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31514_31515 : H12AffineEnvironment.transform 17 10400 env31514 = env31515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env31514 == env31515) = true)

theorem identity31515 : scanCanonicalize (H12AffineFastState.compose env31515 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound31515 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30082,131072,10400,1025,32769,4161,21929,16,21763,8328,65,171417,46156,17665,190640,42112,168,257,62589,5593,63188]

theorem envBound31516 : H12AffineFastState.Bounded env31516 := by
  intro p hp
  have h : env31516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31515_31516 : H12AffineEnvironment.transform 15 30082 env31515 = env31516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env31515 == env31516) = true)

theorem identity31516 : scanCanonicalize (H12AffineFastState.compose env31516 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound31516 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env31517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,30082,131072,10400,1025,8353,4161,21929,16,21763,8328,65,146745,5356,17665,149520,1056,168,257,21725,5593,22132]

theorem envBound31517 : H12AffineFastState.Bounded env31517 := by
  intro p hp
  have h : env31517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31516_31517 : H12AffineEnvironment.transform 14 8352 env31516 = env31517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env31516 == env31517) = true)

theorem identity31517 : scanCanonicalize (H12AffineFastState.compose env31517 (packedSelected [4,6,7,16,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound31517 : packedSelected [4,6,7,16,20,22,27] rootPS < 2^1333 := by decide +kernel

def env31518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8352,8694,131072,10400,1025,8353,4161,477,16,375,8328,65,146745,5356,4469,138340,1056,168,257,169,5593,512]

theorem envBound31518 : H12AffineFastState.Bounded env31518 := by
  intro p hp
  have h : env31518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31517_31518 : H12AffineEnvironment.transform 13 5236 env31517 = env31518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env31517 == env31518) = true)

theorem identity31518 : scanCanonicalize (H12AffineFastState.compose env31518 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31518 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31519 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,5236,8352,8322,131072,10400,1025,8353,4161,169,16,3,8328,65,146509,5356,4097,138340,1056,168,117,169,5293,512]

theorem envBound31519 : H12AffineFastState.Bounded env31519 := by
  intro p hp
  have h : env31519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31518_31519 : H12AffineEnvironment.transform 7 116 env31518 = env31519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31518 == env31519) = true)

theorem identity31519 : scanCanonicalize (H12AffineFastState.compose env31519 (packedSelected [1,4,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31519 : packedSelected [1,4,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env31520 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,120,5236,216,250,131072,2264,1025,217,4161,169,16,3,240,65,138293,5356,4097,138340,1056,168,117,169,5293,512]

theorem envBound31520 : H12AffineFastState.Bounded env31520 := by
  intro p hp
  have h : env31520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31519_31520 : H12AffineEnvironment.transform 12 120 env31519 = env31520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31519 == env31520) = true)

theorem identity31520 : scanCanonicalize (H12AffineFastState.compose env31520 (packedSelected [0,4,6,10,14] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound31520 : packedSelected [0,4,6,10,14] rootPS < 2^1333 := by decide +kernel

def env31521 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,120,5236,216,250,5357,2264,1025,217,4161,169,16,3,240,65,2264,5356,4097,2185,1056,168,117,169,5293,512]

theorem envBound31521 : H12AffineFastState.Bounded env31521 := by
  intro p hp
  have h : env31521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31520_31521 : H12AffineEnvironment.transform 16 5357 env31520 = env31521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env31520 == env31521) = true)

theorem identity31521 : scanCanonicalize (H12AffineFastState.compose env31521 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31521 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31522 : List Nat := [2,4,8,16,0,64,128,84,512,1024,2048,4096,88,5204,216,218,5325,2264,1025,217,4161,137,16,3,208,65,2264,5324,4097,2185,1024,136,85,137,5261,512]

theorem envBound31522 : H12AffineFastState.Bounded env31522 := by
  intro p hp
  have h : env31522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31521_31522 : H12AffineEnvironment.transform 4 0 env31521 = env31522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31521 == env31522) = true)

theorem identity31522 : scanCanonicalize (H12AffineFastState.compose env31522 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound31522 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31523 : List Nat := [2,4,8,16,0,64,128,84,512,69,2048,4096,88,4113,216,218,4232,2264,68,217,4161,137,16,3,208,65,2264,4233,4097,2185,69,136,85,137,4296,512]

theorem envBound31523 : H12AffineFastState.Bounded env31523 := by
  intro p hp
  have h : env31523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31522_31523 : H12AffineEnvironment.transform 9 69 env31522 = env31523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env31522 == env31523) = true)

theorem identity31523 : scanCanonicalize (H12AffineFastState.compose env31523 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31523 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env31524 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,4096,88,4113,81,83,4097,2129,68,80,4161,0,16,3,89,65,2129,4096,4097,2048,69,1,85,0,4161,512]

theorem envBound31524 : H12AffineFastState.Bounded env31524 := by
  intro p hp
  have h : env31524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31523_31524 : H12AffineEnvironment.transform 6 9 env31523 = env31524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31523 == env31524) = true)

theorem identity31524 : scanCanonicalize (H12AffineFastState.compose env31524 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound31524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31525 : List Nat := [2,4,8,16,0,64,9,84,512,69,2048,81,88,64,81,83,80,2129,68,80,16,0,16,3,89,65,2129,81,80,2048,69,1,85,0,16,512]

theorem envBound31525 : H12AffineFastState.Bounded env31525 := by
  intro p hp
  have h : env31525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31524_31525 : H12AffineEnvironment.transform 11 81 env31524 = env31525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env31524 == env31525) = true)

theorem identity31525 : scanCanonicalize (H12AffineFastState.compose env31525 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound31525 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31526 : List Nat := [2,4,8,16,0,64,9,84,80,69,2048,81,88,64,81,83,80,2129,68,80,16,0,16,3,89,65,2129,81,80,2048,69,1,85,0,16,80]

theorem envBound31526 : H12AffineFastState.Bounded env31526 := by
  intro p hp
  have h : env31526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31525_31526 : H12AffineEnvironment.transform 8 80 env31525 = env31526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env31525 == env31526) = true)

theorem identity31526 : scanCanonicalize (H12AffineFastState.compose env31526 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 69) := by decide +kernel

theorem selectedBound31526 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31527 : List Nat := [2,4,8,16,0,64,9,84,80,69,69,81,88,64,81,83,80,20,68,80,16,0,16,3,89,65,20,81,80,69,69,1,85,0,16,80]

theorem envBound31527 : H12AffineFastState.Bounded env31527 := by
  intro p hp
  have h : env31527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31526_31527 : H12AffineEnvironment.transform 10 69 env31526 = env31527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 69 env31526 == env31527) = true)

theorem identity31527 : scanCanonicalize (H12AffineFastState.compose env31527 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31527 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31528 : List Nat := [2,4,8,16,0,16,9,4,0,21,21,1,8,16,1,3,0,20,20,0,16,0,16,3,9,17,20,1,0,21,21,1,5,0,16,0]

theorem envBound31528 : H12AffineFastState.Bounded env31528 := by
  intro p hp
  have h : env31528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31527_31528 : H12AffineEnvironment.transform 5 16 env31527 = env31528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31527 == env31528) = true)

theorem identity31528 : scanCanonicalize (H12AffineFastState.compose env31528 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound31528 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31529 : List Nat := [2,4,8,4,0,4,9,4,0,1,1,1,8,4,1,3,0,0,0,0,4,0,4,3,9,5,0,1,0,1,1,1,5,0,4,0]

theorem envBound31529 : H12AffineFastState.Bounded env31529 := by
  intro p hp
  have h : env31529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31528_31529 : H12AffineEnvironment.transform 3 4 env31528 = env31529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env31528 == env31529) = true)

def env31530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,21929,95635,73856,8328,65,256026,46157,77954,236850,119042,169,257,98815,90203,63188]

theorem envBound31530 : H12AffineFastState.Bounded env31530 := by
  intro p hp
  have h : env31530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31514_31530 : H12AffineEnvironment.transform 17 10401 env31514 = env31530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env31514 == env31530) = true)

theorem identity31530 : scanCanonicalize (H12AffineFastState.compose env31530 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31530 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env31531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1025,29908,4161,21929,95635,73856,8328,65,203983,16536,77954,223719,75223,169,257,95530,90203,513]

theorem envBound31531 : H12AffineFastState.Bounded env31531 := by
  intro p hp
  have h : env31531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31530_31531 : H12AffineEnvironment.transform 14 29909 env31530 = env31531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31530 == env31531) = true)

def env31532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10401,1025,8660,4161,169,73875,73856,8328,65,203983,5528,77954,212199,75223,169,257,73770,79195,513]

theorem envBound31532 : H12AffineFastState.Bounded env31532 := by
  intro p hp
  have h : env31532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31531_31532 : H12AffineEnvironment.transform 13 5376 env31531 = env31532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31531 == env31532) = true)

theorem identity31532 : scanCanonicalize (H12AffineFastState.compose env31532 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31532 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,4161,33,73755,73736,8192,65,203847,5392,77834,212079,75103,33,257,73770,79195,513]

theorem envBound31533 : H12AffineFastState.Bounded env31533 := by
  intro p hp
  have h : env31533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31532_31533 : H12AffineEnvironment.transform 6 8 env31532 = env31533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31532 == env31533) = true)

theorem identity31533 : scanCanonicalize (H12AffineFastState.compose env31533 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound31533 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env31534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8282,131072,10281,1025,8540,4161,33,65,82,8192,65,146461,5392,4176,138293,1285,33,257,112,5377,513]

theorem envBound31534 : H12AffineFastState.Bounded env31534 := by
  intro p hp
  have h : env31534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31533_31534 : H12AffineEnvironment.transform 15 8282 env31533 = env31534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env31533 == env31534) = true)

theorem identity31534 : scanCanonicalize (H12AffineFastState.compose env31534 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31534 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8282,13341,10281,1025,8540,4161,33,65,82,8192,65,2048,5392,4176,10280,1285,33,257,112,5377,513]

theorem envBound31535 : H12AffineFastState.Bounded env31535 := by
  intro p hp
  have h : env31535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31534_31535 : H12AffineEnvironment.transform 16 13341 env31534 = env31535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env31534 == env31535) = true)

theorem identity31535 : scanCanonicalize (H12AffineFastState.compose env31535 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31535 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31536 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13341,10281,1025,8460,4113,33,17,2,8192,17,2048,5392,4096,10280,1285,33,257,32,5377,513]

theorem envBound31536 : H12AffineFastState.Bounded env31536 := by
  intro p hp
  have h : env31536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31535_31536 : H12AffineEnvironment.transform 5 16 env31535 = env31536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31535 == env31536) = true)

def env31537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10401,1025,8661,4161,168,73874,73856,8328,65,203983,5529,77954,212198,75223,169,257,73771,79194,513]

theorem envBound31537 : H12AffineFastState.Bounded env31537 := by
  intro p hp
  have h : env31537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31531_31537 : H12AffineEnvironment.transform 13 5377 env31531 = env31537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31531 == env31537) = true)

theorem identity31537 : scanCanonicalize (H12AffineFastState.compose env31537 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound31537 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79131,10401,1025,8661,4161,168,73874,73856,8328,65,10708,5529,77954,2557,75223,169,257,73771,79194,513]

theorem envBound31538 : H12AffineFastState.Bounded env31538 := by
  intro p hp
  have h : env31538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31537_31538 : H12AffineEnvironment.transform 16 79131 env31537 = env31538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env31537 == env31538) = true)

theorem identity31538 : scanCanonicalize (H12AffineFastState.compose env31538 (packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31538 : packedSelected [0,1,2,6,7,8,10,11,14,15,18,23] rootPS < 2^1333 := by decide +kernel

def env31539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,65536,70727,2557,1025,137,4161,168,65998,66012,468,65,2184,5529,70110,2557,66699,169,257,65911,70662,513]

theorem envBound31539 : H12AffineFastState.Bounded env31539 := by
  intro p hp
  have h : env31539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31538_31539 : H12AffineEnvironment.transform 12 348 env31538 = env31539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31538 == env31539) = true)

theorem identity31539 : scanCanonicalize (H12AffineFastState.compose env31539 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound31539 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env31540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,342,5393,2557,1025,137,4161,168,152,138,468,65,2184,5529,4232,2557,1501,169,257,33,5456,513]

theorem envBound31540 : H12AffineFastState.Bounded env31540 := by
  intro p hp
  have h : env31540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31539_31540 : H12AffineEnvironment.transform 15 342 env31539 = env31540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env31539 == env31540) = true)

theorem identity31540 : scanCanonicalize (H12AffineFastState.compose env31540 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound31540 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31541 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,81,342,5393,2340,1025,80,4161,113,65,83,269,65,2129,5440,4177,2340,1284,112,257,33,5456,513]

theorem envBound31541 : H12AffineFastState.Bounded env31541 := by
  intro p hp
  have h : env31541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31540_31541 : H12AffineEnvironment.transform 6 89 env31540 = env31541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env31540 == env31541) = true)

theorem identity31541 : scanCanonicalize (H12AffineFastState.compose env31541 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31541 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31542 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1025,0,4113,33,17,3,269,17,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound31542 : H12AffineFastState.Bounded env31542 := by
  intro p hp
  have h : env31542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31541_31542 : H12AffineEnvironment.transform 5 16 env31541 = env31542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31541 == env31542) = true)

theorem identity31542 : scanCanonicalize (H12AffineFastState.compose env31542 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound31542 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31543 : List Nat := [2,4,8,16,32,16,9,256,512,289,2048,4096,268,4128,1,262,4144,2340,288,0,4113,33,17,3,269,17,2049,4145,4097,2340,37,32,257,33,4129,513]

theorem envBound31543 : H12AffineFastState.Bounded env31543 := by
  intro p hp
  have h : env31543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31542_31543 : H12AffineEnvironment.transform 9 289 env31542 = env31543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env31542 == env31543) = true)

theorem identity31543 : scanCanonicalize (H12AffineFastState.compose env31543 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound31543 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31544 : List Nat := [2,4,8,16,32,16,9,256,512,289,2048,821,268,789,1,262,773,2340,288,0,804,33,17,3,269,17,2049,772,820,2340,37,32,257,33,788,513]

theorem envBound31544 : H12AffineFastState.Bounded env31544 := by
  intro p hp
  have h : env31544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31543_31544 : H12AffineEnvironment.transform 11 821 env31543 = env31544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env31543 == env31544) = true)

theorem identity31544 : scanCanonicalize (H12AffineFastState.compose env31544 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31544 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31545 : List Nat := [2,4,8,16,32,16,9,4,512,37,2048,561,8,529,1,2,513,2080,36,0,544,33,17,3,9,17,2049,512,560,2080,37,32,5,33,528,513]

theorem envBound31545 : H12AffineFastState.Bounded env31545 := by
  intro p hp
  have h : env31545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31544_31545 : H12AffineEnvironment.transform 7 4 env31544 = env31545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31544 == env31545) = true)

theorem identity31545 : scanCanonicalize (H12AffineFastState.compose env31545 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31545 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31546 : List Nat := [2,4,8,16,32,16,9,4,512,37,513,561,8,529,1,2,513,545,36,0,544,33,17,3,9,17,512,512,560,545,37,32,5,33,528,513]

theorem envBound31546 : H12AffineFastState.Bounded env31546 := by
  intro p hp
  have h : env31546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31545_31546 : H12AffineEnvironment.transform 10 513 env31545 = env31546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31545 == env31546) = true)

theorem identity31546 : scanCanonicalize (H12AffineFastState.compose env31546 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31546 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env31547 : List Nat := [2,4,8,16,16,16,9,4,512,21,513,513,8,529,1,2,513,529,20,0,528,17,17,3,9,17,512,512,512,529,21,16,5,17,528,513]

theorem envBound31547 : H12AffineFastState.Bounded env31547 := by
  intro p hp
  have h : env31547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31546_31547 : H12AffineEnvironment.transform 4 16 env31546 = env31547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31546 == env31547) = true)

theorem identity31547 : scanCanonicalize (H12AffineFastState.compose env31547 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31548 : List Nat := [2,4,8,16,16,16,9,4,1,21,0,0,8,16,1,2,0,16,20,0,17,17,17,3,9,17,1,1,1,16,21,16,5,17,17,0]

theorem envBound31548 : H12AffineFastState.Bounded env31548 := by
  intro p hp
  have h : env31548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31547_31548 : H12AffineEnvironment.transform 8 1 env31547 = env31548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31547 == env31548) = true)

theorem identity31548 : scanCanonicalize (H12AffineFastState.compose env31548 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31548 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env31549 : List Nat := [2,4,8,1,1,1,9,4,1,4,0,0,8,1,1,2,0,1,5,0,0,0,0,3,9,0,1,1,1,1,4,1,5,0,0,0]

theorem envBound31549 : H12AffineFastState.Bounded env31549 := by
  intro p hp
  have h : env31549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31548_31549 : H12AffineEnvironment.transform 3 1 env31548 = env31549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31548 == env31549) = true)

def env31550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115048,2444659,2431073,8328,65,2609403,302317,333859,2329971,119043,2373704,257,2199999,2191387,63189]

theorem envBound31550 : H12AffineFastState.Bounded env31550 := by
  intro p hp
  have h : env31550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31476_31550 : H12AffineEnvironment.transform 23 2431073 env31476 = env31550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env31476 == env31550) = true)

def env31551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21928,351539,329761,8328,65,508091,302317,333859,236851,119043,272392,257,98815,90203,63189]

theorem envBound31551 : H12AffineFastState.Bounded env31551 := by
  intro p hp
  have h : env31551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31550_31551 : H12AffineEnvironment.transform 20 4160 env31550 = env31551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31550 == env31551) = true)

theorem identity31551 : scanCanonicalize (H12AffineFastState.compose env31551 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound31551 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,21928,351539,329761,8328,65,472175,288825,333859,223719,75223,272392,257,95531,90203,513]

theorem envBound31552 : H12AffineFastState.Bounded env31552 := by
  intro p hp
  have h : env31552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31551_31552 : H12AffineEnvironment.transform 14 29908 env31551 = env31552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env31551 == env31552) = true)

def env31553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,21792,351539,329761,8192,65,472175,288825,333859,223599,75103,272392,257,95531,90203,513]

theorem envBound31553 : H12AffineFastState.Bounded env31553 := by
  intro p hp
  have h : env31553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31552_31553 : H12AffineEnvironment.transform 6 8 env31552 = env31553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31552 == env31553) = true)

theorem identity31553 : scanCanonicalize (H12AffineFastState.compose env31553 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound31553 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env31554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13340,262144,1025,29789,4160,21792,351539,329761,8192,65,327795,288825,333859,89459,75103,272392,257,95531,90203,513]

theorem envBound31554 : H12AffineFastState.Bounded env31554 := by
  intro p hp
  have h : env31554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31553_31554 : H12AffineEnvironment.transform 16 13340 env31553 = env31554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env31553 == env31554) = true)

theorem identity31554 : scanCanonicalize (H12AffineFastState.compose env31554 (packedSelected [0,2,3,4,5,6,9,10,12,15,18,19,20,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31554 : packedSelected [0,2,3,4,5,6,9,10,12,15,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env31555 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13340,262144,1025,8541,4160,32,329779,329761,8192,65,327795,277817,333859,67699,75103,272392,257,73771,79195,513]

theorem envBound31555 : H12AffineFastState.Bounded env31555 := by
  intro p hp
  have h : env31555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31554_31555 : H12AffineEnvironment.transform 13 5376 env31554 = env31555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31554 == env31555) = true)

theorem identity31555 : scanCanonicalize (H12AffineFastState.compose env31555 (packedSelected [0,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound31555 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env31556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8282,13340,262144,1025,8541,4160,32,272489,272507,8192,65,270377,277817,276601,10281,1285,272392,257,113,5377,513]

theorem envBound31556 : H12AffineFastState.Bounded env31556 := by
  intro p hp
  have h : env31556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31555_31556 : H12AffineEnvironment.transform 15 8282 env31555 = env31556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env31555 == env31556) = true)

theorem identity31556 : scanCanonicalize (H12AffineFastState.compose env31556 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31556 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,342,5392,262144,1025,81,4160,32,264549,264567,268,65,262437,269365,268661,2341,1285,264452,257,113,5377,513]

theorem envBound31557 : H12AffineFastState.Bounded env31557 := by
  intro p hp
  have h : env31557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31556_31557 : H12AffineEnvironment.transform 12 268 env31556 = env31557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31556 == env31557) = true)

theorem identity31557 : scanCanonicalize (H12AffineFastState.compose env31557 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31557 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31558 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,262144,1025,1,4112,32,264501,264487,268,17,262437,269365,268581,2341,1285,264452,257,33,5377,513]

theorem envBound31558 : H12AffineFastState.Bounded env31558 := by
  intro p hp
  have h : env31558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31557_31558 : H12AffineEnvironment.transform 5 16 env31557 = env31558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31557 == env31558) = true)

theorem identity31558 : scanCanonicalize (H12AffineFastState.compose env31558 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound31558 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31559 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,4096,268,5376,0,262,5392,262144,1025,1,4112,32,262160,262146,268,17,262437,267536,266240,0,1285,262177,257,33,5377,513]

theorem envBound31559 : H12AffineFastState.Bounded env31559 := by
  intro p hp
  have h : env31559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31558_31559 : H12AffineEnvironment.transform 10 293 env31558 = env31559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env31558 == env31559) = true)

theorem identity31559 : scanCanonicalize (H12AffineFastState.compose env31559 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(17+1) ^^^ 4112) := by decide +kernel

theorem selectedBound31559 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31560 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,4096,268,5376,0,262,5392,4112,1025,1,4112,32,4096,4114,268,17,4405,1280,16,0,1285,4145,257,33,5377,513]

theorem envBound31560 : H12AffineFastState.Bounded env31560 := by
  intro p hp
  have h : env31560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31559_31560 : H12AffineEnvironment.transform 17 4112 env31559 = env31560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4112 env31559 == env31560) = true)

theorem identity31560 : scanCanonicalize (H12AffineFastState.compose env31560 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31560 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31561 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,4096,268,4405,0,262,4389,4112,52,1,4112,32,4096,4114,268,17,4405,309,16,0,304,4145,257,33,4404,513]

theorem envBound31561 : H12AffineFastState.Bounded env31561 := by
  intro p hp
  have h : env31561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31560_31561 : H12AffineEnvironment.transform 9 53 env31560 = env31561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31560 == env31561) = true)

theorem identity31561 : scanCanonicalize (H12AffineFastState.compose env31561 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound31561 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env31562 : List Nat := [2,4,8,16,32,16,8,256,512,53,293,308,268,1,0,262,17,292,52,1,292,32,308,294,268,17,1,309,16,0,304,261,257,33,0,513]

theorem envBound31562 : H12AffineFastState.Bounded env31562 := by
  intro p hp
  have h : env31562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31561_31562 : H12AffineEnvironment.transform 11 308 env31561 = env31562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env31561 == env31562) = true)

theorem identity31562 : scanCanonicalize (H12AffineFastState.compose env31562 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound31562 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env31563 : List Nat := [2,4,8,16,32,16,8,256,309,53,293,308,268,1,0,262,17,292,52,1,292,32,308,294,268,17,1,309,16,0,304,261,257,33,0,308]

theorem envBound31563 : H12AffineFastState.Bounded env31563 := by
  intro p hp
  have h : env31563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31562_31563 : H12AffineEnvironment.transform 8 309 env31562 = env31563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env31562 == env31563) = true)

theorem identity31563 : scanCanonicalize (H12AffineFastState.compose env31563 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31563 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env31564 : List Nat := [2,4,8,16,32,16,8,5,48,53,32,49,9,1,0,3,17,33,52,1,33,32,49,35,9,17,1,48,16,0,53,0,4,33,0,49]

theorem envBound31564 : H12AffineFastState.Bounded env31564 := by
  intro p hp
  have h : env31564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31563_31564 : H12AffineEnvironment.transform 7 5 env31563 = env31564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31563 == env31564) = true)

theorem identity31564 : scanCanonicalize (H12AffineFastState.compose env31564 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31565 : List Nat := [2,4,8,16,0,16,8,5,16,21,0,17,9,1,0,3,17,1,20,1,1,0,17,3,9,17,1,16,16,0,21,0,4,1,0,17]

theorem envBound31565 : H12AffineFastState.Bounded env31565 := by
  intro p hp
  have h : env31565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31564_31565 : H12AffineEnvironment.transform 4 0 env31564 = env31565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31564 == env31565) = true)

theorem identity31565 : scanCanonicalize (H12AffineFastState.compose env31565 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31565 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31566 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,0,9,1,0,3,0,1,5,1,1,0,0,3,9,0,1,1,1,0,4,0,4,1,0,0]

theorem envBound31566 : H12AffineFastState.Bounded env31566 := by
  intro p hp
  have h : env31566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31565_31566 : H12AffineEnvironment.transform 3 1 env31565 = env31566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31565 == env31566) = true)

def env31567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,21793,351539,329761,8193,65,472175,288825,333859,223598,75102,272392,257,95531,90203,513]

theorem envBound31567 : H12AffineFastState.Bounded env31567 := by
  intro p hp
  have h : env31567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31552_31567 : H12AffineEnvironment.transform 6 9 env31552 = env31567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31552 == env31567) = true)

theorem identity31567 : scanCanonicalize (H12AffineFastState.compose env31567 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31567 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env31568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,262144,1025,29788,4160,21793,351539,329761,8193,65,283765,288825,333859,2420,75102,272392,257,95531,90203,513]

theorem envBound31568 : H12AffineFastState.Bounded env31568 := by
  intro p hp
  have h : env31568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31567_31568 : H12AffineEnvironment.transform 16 90138 env31567 = env31568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31567 == env31568) = true)

theorem identity31568 : scanCanonicalize (H12AffineFastState.compose env31568 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound31568 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env31569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,20530,12328,262144,1025,29788,4160,21793,265473,284691,8193,65,283765,288825,280593,2420,30060,272392,257,9497,12393,513]

theorem envBound31569 : H12AffineFastState.Bounded env31569 := by
  intro p hp
  have h : env31569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31568_31569 : H12AffineEnvironment.transform 15 20530 env31568 = env31569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env31568 == env31569) = true)

theorem identity31569 : scanCanonicalize (H12AffineFastState.compose env31569 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound31569 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env31570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,1046,12328,262144,1025,8312,4160,261,265473,265271,8193,65,262225,277533,269365,2420,8520,272392,257,9497,12393,513]

theorem envBound31570 : H12AffineFastState.Bounded env31570 := by
  intro p hp
  have h : env31570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31569_31570 : H12AffineEnvironment.transform 13 5156 env31569 = env31570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env31569 == env31570) = true)

theorem identity31570 : scanCanonicalize (H12AffineFastState.compose env31570 (packedSelected [1,3,4,9,12,14,15,17,20,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound31570 : packedSelected [1,3,4,9,12,14,15,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env31571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,1046,12328,2340,1025,8312,4160,261,1061,1299,8193,65,2421,13625,5393,2420,8520,8492,257,9497,12393,513]

theorem envBound31571 : H12AffineFastState.Bounded env31571 := by
  intro p hp
  have h : env31571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31570_31571 : H12AffineEnvironment.transform 17 2340 env31570 = env31571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env31570 == env31571) = true)

theorem identity31571 : scanCanonicalize (H12AffineFastState.compose env31571 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31571 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env31572 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5156,8313,1046,12328,2048,1025,8312,4160,33,1061,1079,8193,65,2129,13341,5173,2128,8300,8200,37,9277,12393,513]

theorem envBound31572 : H12AffineFastState.Bounded env31572 := by
  intro p hp
  have h : env31572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31571_31572 : H12AffineEnvironment.transform 7 36 env31571 = env31572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31571 == env31572) = true)

theorem identity31572 : scanCanonicalize (H12AffineFastState.compose env31572 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31572 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31573 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,8192,4112,8313,34,12328,2048,53,8312,4160,33,17,3,8193,65,2129,12329,4097,2128,8300,8200,37,8201,12393,513]

theorem envBound31573 : H12AffineFastState.Bounded env31573 := by
  intro p hp
  have h : env31573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31572_31573 : H12AffineEnvironment.transform 9 52 env31572 = env31573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31572 == env31573) = true)

theorem identity31573 : scanCanonicalize (H12AffineFastState.compose env31573 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound31573 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env31574 : List Nat := [2,4,8,16,32,64,9,36,512,52,560,4096,8192,4112,8313,34,12328,560,53,8312,4160,33,17,3,8193,65,609,12329,4097,608,8300,8200,37,8201,12393,513]

theorem envBound31574 : H12AffineFastState.Bounded env31574 := by
  intro p hp
  have h : env31574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31573_31574 : H12AffineEnvironment.transform 10 560 env31573 = env31574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env31573 == env31574) = true)

theorem identity31574 : scanCanonicalize (H12AffineFastState.compose env31574 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31574 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env31575 : List Nat := [2,4,8,16,0,64,9,4,512,20,528,4096,8192,4112,8281,2,12296,528,21,8280,4160,1,17,3,8193,65,577,12297,4097,576,8268,8200,5,8201,12361,513]

theorem envBound31575 : H12AffineFastState.Bounded env31575 := by
  intro p hp
  have h : env31575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31574_31575 : H12AffineEnvironment.transform 4 0 env31574 = env31575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31574 == env31575) = true)

theorem identity31575 : scanCanonicalize (H12AffineFastState.compose env31575 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31575 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env31576 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,4096,8192,4112,8201,2,12296,528,21,8200,4112,1,17,3,8193,17,529,12297,4097,528,8220,8200,5,8201,12313,513]

theorem envBound31576 : H12AffineFastState.Bounded env31576 := by
  intro p hp
  have h : env31576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31575_31576 : H12AffineEnvironment.transform 5 16 env31575 = env31576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31575 == env31576) = true)

theorem identity31576 : scanCanonicalize (H12AffineFastState.compose env31576 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound31576 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31577 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,4096,537,4112,528,2,4625,528,21,529,4112,1,17,3,536,17,529,4624,4097,528,517,529,5,528,4608,513]

theorem envBound31577 : H12AffineFastState.Bounded env31577 := by
  intro p hp
  have h : env31577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31576_31577 : H12AffineEnvironment.transform 12 537 env31576 = env31577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env31576 == env31577) = true)

theorem identity31577 : scanCanonicalize (H12AffineFastState.compose env31577 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound31577 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env31578 : List Nat := [2,4,8,16,0,16,9,4,512,20,528,16,537,0,528,2,513,528,21,529,0,1,17,3,536,17,529,512,17,528,517,529,5,528,528,513]

theorem envBound31578 : H12AffineFastState.Bounded env31578 := by
  intro p hp
  have h : env31578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31577_31578 : H12AffineEnvironment.transform 11 16 env31577 = env31578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31577 == env31578) = true)

theorem identity31578 : scanCanonicalize (H12AffineFastState.compose env31578 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31578 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31579 : List Nat := [2,4,8,16,0,16,9,4,1,20,17,16,24,0,17,2,0,17,21,16,0,1,17,3,25,17,16,1,17,17,4,16,5,17,17,0]

theorem envBound31579 : H12AffineFastState.Bounded env31579 := by
  intro p hp
  have h : env31579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31578_31579 : H12AffineEnvironment.transform 8 1 env31578 = env31579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31578 == env31579) = true)

def env31580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329760,8328,65,508090,302317,333859,236850,119043,272393,257,98814,90202,63189]

theorem envBound31580 : H12AffineFastState.Bounded env31580 := by
  intro p hp
  have h : env31580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31550_31580 : H12AffineEnvironment.transform 20 4161 env31550 = env31580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31550 == env31580) = true)

theorem identity31580 : scanCanonicalize (H12AffineFastState.compose env31580 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound31580 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35324,1025,32769,4161,21929,120014,98780,8328,65,215366,5393,102879,236850,119043,41461,257,98814,90202,63189]

theorem envBound31581 : H12AffineFastState.Bounded env31581 := by
  intro p hp
  have h : env31581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31580_31581 : H12AffineEnvironment.transform 17 35324 env31580 = env31581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env31580 == env31581) = true)

def env31582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10400,1025,8541,4161,21929,95634,73856,8328,65,215366,5393,77955,212078,94303,169,257,73890,90202,22409]

theorem envBound31582 : H12AffineFastState.Bounded env31582 := by
  intro p hp
  have h : env31582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31581_31582 : H12AffineEnvironment.transform 14 8540 env31581 = env31582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31581 == env31582) = true)

theorem identity31582 : scanCanonicalize (H12AffineFastState.compose env31582 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound31582 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,131072,10400,1025,8541,4161,21929,21777,3,8328,65,158149,5393,4096,138477,20700,169,257,33,16601,22409]

theorem envBound31583 : H12AffineFastState.Bounded env31583 := by
  intro p hp
  have h : env31583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31582_31583 : H12AffineEnvironment.transform 15 8323 env31582 = env31583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env31582 == env31583) = true)

theorem identity31583 : scanCanonicalize (H12AffineFastState.compose env31583 (packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound31583 : packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,13340,10400,1025,8541,4161,21929,21777,3,8328,65,24025,5393,4096,10481,20700,169,257,33,16601,22409]

theorem envBound31584 : H12AffineFastState.Bounded env31584 := by
  intro p hp
  have h : env31584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31583_31584 : H12AffineEnvironment.transform 16 13340 env31583 = env31584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env31583 == env31584) = true)

theorem identity31584 : scanCanonicalize (H12AffineFastState.compose env31584 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31584 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS < 2^1333 := by decide +kernel

def env31585 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8312,8323,13340,10400,1025,8313,4161,21645,21557,3,8328,65,23805,5173,4096,10481,20700,169,37,33,16601,22189]

theorem envBound31585 : H12AffineFastState.Bounded env31585 := by
  intro p hp
  have h : env31585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31584_31585 : H12AffineEnvironment.transform 7 36 env31584 = env31585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31584 == env31585) = true)

theorem identity31585 : scanCanonicalize (H12AffineFastState.compose env31585 (packedSelected [1,2,3,4,5,6,8,10,11,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound31585 : packedSelected [1,2,3,4,5,6,8,10,11,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env31586 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,137,114,5357,2129,1025,136,4161,21645,21557,3,121,65,23805,5173,4096,2048,20700,169,37,33,16601,22189]

theorem envBound31586 : H12AffineFastState.Bounded env31586 := by
  intro p hp
  have h : env31586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31585_31586 : H12AffineEnvironment.transform 12 241 env31585 = env31586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env31585 == env31586) = true)

theorem identity31586 : scanCanonicalize (H12AffineFastState.compose env31586 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5373) := by decide +kernel

theorem selectedBound31586 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env31587 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5373,137,114,5357,2129,1025,136,4161,112,200,3,121,65,2048,5173,4096,2048,1057,169,37,33,5156,592]

theorem envBound31587 : H12AffineFastState.Bounded env31587 := by
  intro p hp
  have h : env31587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31586_31587 : H12AffineEnvironment.transform 13 5373 env31586 = env31587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5373 env31586 == env31587) = true)

theorem identity31587 : scanCanonicalize (H12AffineFastState.compose env31587 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31587 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31588 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,160,5292,137,35,5308,2048,1025,136,4112,33,153,3,40,16,2048,5173,4096,2048,1057,169,37,33,5156,513]

theorem envBound31588 : H12AffineFastState.Bounded env31588 := by
  intro p hp
  have h : env31588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31587_31588 : H12AffineEnvironment.transform 5 17 env31587 = env31588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31587 == env31588) = true)

theorem identity31588 : scanCanonicalize (H12AffineFastState.compose env31588 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31588 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31589 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4112,33,17,3,40,16,2048,5173,4096,2048,1057,33,37,33,5156,513]

theorem envBound31589 : H12AffineFastState.Bounded env31589 := by
  intro p hp
  have h : env31589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31588_31589 : H12AffineEnvironment.transform 6 8 env31588 = env31589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31588 == env31589) = true)

theorem identity31589 : scanCanonicalize (H12AffineFastState.compose env31589 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound31589 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31590 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,33,40,1029,1,35,1045,2048,1025,0,49,33,17,3,40,16,2048,1044,33,2048,1057,33,37,33,1029,513]

theorem envBound31590 : H12AffineFastState.Bounded env31590 := by
  intro p hp
  have h : env31590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31589_31590 : H12AffineEnvironment.transform 11 33 env31589 = env31590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env31589 == env31590) = true)

theorem identity31590 : scanCanonicalize (H12AffineFastState.compose env31590 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound31590 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31591 : List Nat := [2,4,8,16,32,17,8,36,512,1024,11,33,40,1029,1,35,1045,11,1025,0,49,33,17,3,40,16,11,1044,33,11,1057,33,37,33,1029,513]

theorem envBound31591 : H12AffineFastState.Bounded env31591 := by
  intro p hp
  have h : env31591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31590_31591 : H12AffineEnvironment.transform 10 11 env31590 = env31591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env31590 == env31591) = true)

theorem identity31591 : scanCanonicalize (H12AffineFastState.compose env31591 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound31591 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31592 : List Nat := [2,4,8,16,32,17,8,36,512,549,11,33,40,544,1,35,560,11,548,0,49,33,17,3,40,16,11,561,33,11,516,33,37,33,544,513]

theorem envBound31592 : H12AffineFastState.Bounded env31592 := by
  intro p hp
  have h : env31592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31591_31592 : H12AffineEnvironment.transform 9 549 env31591 = env31592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env31591 == env31592) = true)

theorem identity31592 : scanCanonicalize (H12AffineFastState.compose env31592 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31592 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31593 : List Nat := [2,4,2,16,32,17,2,36,512,549,1,33,34,544,1,35,560,1,548,0,49,33,17,3,34,16,1,561,33,1,516,33,37,33,544,513]

theorem envBound31593 : H12AffineFastState.Bounded env31593 := by
  intro p hp
  have h : env31593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31592_31593 : H12AffineEnvironment.transform 2 2 env31592 = env31593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31592 == env31593) = true)

theorem identity31593 : scanCanonicalize (H12AffineFastState.compose env31593 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31593 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31594 : List Nat := [2,4,2,16,0,17,2,4,512,517,1,1,2,512,1,3,528,1,516,0,17,1,17,3,2,16,1,529,1,1,516,1,5,1,512,513]

theorem envBound31594 : H12AffineFastState.Bounded env31594 := by
  intro p hp
  have h : env31594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31593_31594 : H12AffineEnvironment.transform 4 0 env31593 = env31594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31593 == env31594) = true)

theorem identity31594 : scanCanonicalize (H12AffineFastState.compose env31594 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31594 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31595 : List Nat := [2,2,2,16,0,17,2,2,512,515,1,1,2,512,1,3,528,1,514,0,17,1,17,3,2,16,1,529,1,1,514,1,3,1,512,513]

theorem envBound31595 : H12AffineFastState.Bounded env31595 := by
  intro p hp
  have h : env31595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31594_31595 : H12AffineEnvironment.transform 1 2 env31594 = env31595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31594 == env31595) = true)

theorem identity31595 : scanCanonicalize (H12AffineFastState.compose env31595 (packedSelected [0,8] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound31595 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env31596 : List Nat := [2,2,2,16,0,17,2,2,17,18,1,1,2,17,1,3,1,1,19,0,17,1,17,3,2,16,1,0,1,1,19,1,3,1,17,16]

theorem envBound31596 : H12AffineFastState.Bounded env31596 := by
  intro p hp
  have h : env31596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31595_31596 : H12AffineEnvironment.transform 8 17 env31595 = env31596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env31595 == env31596) = true)

theorem identity31596 : scanCanonicalize (H12AffineFastState.compose env31596 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound31596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31597 : List Nat := [2,2,2,2,0,3,2,2,3,0,1,1,2,3,1,3,1,1,1,0,3,1,3,3,2,2,1,0,1,1,1,1,3,1,3,2]

theorem envBound31597 : H12AffineFastState.Bounded env31597 := by
  intro p hp
  have h : env31597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31596_31597 : H12AffineEnvironment.transform 3 2 env31596 = env31597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env31596 == env31597) = true)

def env31598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1025,8540,4161,21929,95635,73857,8328,65,215366,5393,77954,212079,94302,168,257,73891,90202,22408]

theorem envBound31598 : H12AffineFastState.Bounded env31598 := by
  intro p hp
  have h : env31598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31581_31598 : H12AffineEnvironment.transform 14 8541 env31581 = env31598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31581 == env31598) = true)

theorem identity31598 : scanCanonicalize (H12AffineFastState.compose env31598 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound31598 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1025,8540,4161,32,73754,73857,8328,65,203983,5393,77954,212079,75223,168,257,73891,79315,513]

theorem envBound31599 : H12AffineFastState.Bounded env31599 := by
  intro p hp
  have h : env31599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31598_31599 : H12AffineEnvironment.transform 13 5513 env31598 = env31599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env31598 == env31599) = true)

theorem identity31599 : scanCanonicalize (H12AffineFastState.compose env31599 (packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31599 : packedSelected [1,2,3,4,5,6,8,9,10,11,12,14,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env31600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,65536,131072,2477,1025,80,4161,32,65814,65933,388,65,203983,5393,70030,204131,66779,168,257,65967,70879,513]

theorem envBound31600 : H12AffineFastState.Bounded env31600 := by
  intro p hp
  have h : env31600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31599_31600 : H12AffineEnvironment.transform 12 268 env31599 = env31600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31599 == env31600) = true)

theorem identity31600 : scanCanonicalize (H12AffineFastState.compose env31600 (packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound31600 : packedSelected [1,3,4,5,8,9,10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env31601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,65536,5392,2477,1025,80,4161,32,65814,65933,388,65,68063,5393,70030,67699,66779,168,257,65967,70879,513]

theorem envBound31601 : H12AffineFastState.Bounded env31601 := by
  intro p hp
  have h : env31601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31600_31601 : H12AffineEnvironment.transform 16 5392 env31600 = env31601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env31600 == env31601) = true)

theorem identity31601 : scanCanonicalize (H12AffineFastState.compose env31601 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound31601 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,81,262,5392,2477,1025,80,4161,32,16,139,388,65,2265,5393,4232,2421,1501,168,257,169,5593,513]

theorem envBound31602 : H12AffineFastState.Bounded env31602 := by
  intro p hp
  have h : env31602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31601_31602 : H12AffineEnvironment.transform 15 262 env31601 = env31602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env31601 == env31602) = true)

def env31603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,16777216,8328,65,16959643,18973836,333859,2329971,19188066,16850984,257,17074654,17066106,19263156]

theorem envBound31603 : H12AffineFastState.Bounded env31603 := by
  intro p hp
  have h : env31603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31475_31603 : H12AffineEnvironment.transform 21 2115049 env31475 = env31603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env31475 == env31603) = true)

def env31604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431072,8328,65,2609403,302316,333859,2329971,119042,2373704,257,2199998,2191386,63188]

theorem envBound31604 : H12AffineFastState.Bounded env31604 := by
  intro p hp
  have h : env31604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31603_31604 : H12AffineEnvironment.transform 23 2431072 env31603 = env31604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env31603 == env31604) = true)

def env31605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329760,8328,65,508091,302316,333859,236851,119042,272392,257,98814,90202,63188]

theorem envBound31605 : H12AffineFastState.Bounded env31605 := by
  intro p hp
  have h : env31605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31604_31605 : H12AffineEnvironment.transform 20 4160 env31604 = env31605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31604 == env31605) = true)

theorem identity31605 : scanCanonicalize (H12AffineFastState.compose env31605 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31605 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21929,294200,272427,8328,65,450736,302316,276520,179512,61705,272392,257,41461,16465,63188]

theorem envBound31606 : H12AffineFastState.Bounded env31606 := by
  intro p hp
  have h : env31606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31605_31606 : H12AffineEnvironment.transform 15 8203 env31605 = env31606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31605 == env31606) = true)

def env31607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21793,294200,272427,8192,65,450616,302180,276520,179512,61705,272392,257,41341,16465,63068]

theorem envBound31607 : H12AffineFastState.Bounded env31607 := by
  intro p hp
  have h : env31607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31606_31607 : H12AffineEnvironment.transform 6 8 env31606 = env31607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31606 == env31607) = true)

theorem identity31607 : scanCanonicalize (H12AffineFastState.compose env31607 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31607 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31608 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,262144,1025,29788,4160,21793,294200,272427,8192,65,398437,288825,276520,149861,1364,272392,257,21792,16465,513]

theorem envBound31608 : H12AffineFastState.Bounded env31608 := by
  intro p hp
  have h : env31608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31607_31608 : H12AffineEnvironment.transform 14 29789 env31607 = env31608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31607 == env31608) = true)

theorem identity31608 : scanCanonicalize (H12AffineFastState.compose env31608 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound31608 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32041,1025,29788,4160,21793,17,21762,8192,65,158028,5392,17665,149861,1364,21793,257,21792,16465,513]

theorem envBound31609 : H12AffineFastState.Bounded env31609 := by
  intro p hp
  have h : env31609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31608_31609 : H12AffineEnvironment.transform 17 32041 env31608 = env31609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env31608 == env31609) = true)

theorem identity31609 : scanCanonicalize (H12AffineFastState.compose env31609 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31609 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8203,131072,2340,1025,81,4160,8492,17,8463,8192,65,138561,5392,12556,146792,1364,8492,257,8493,13404,513]

theorem envBound31610 : H12AffineFastState.Bounded env31610 := by
  intro p hp
  have h : env31610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31609_31610 : H12AffineEnvironment.transform 13 13325 env31609 = env31610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env31609 == env31610) = true)

theorem identity31610 : scanCanonicalize (H12AffineFastState.compose env31610 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound31610 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env31611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8203,5393,2340,1025,81,4160,8492,17,8463,8192,65,2128,5392,12556,10361,1364,8492,257,8493,13404,513]

theorem envBound31611 : H12AffineFastState.Bounded env31611 := by
  intro p hp
  have h : env31611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31610_31611 : H12AffineEnvironment.transform 16 5393 env31610 = env31611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env31610 == env31611) = true)

theorem identity31611 : scanCanonicalize (H12AffineFastState.compose env31611 (packedSelected [1,2,3,5,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 7464) := by decide +kernel

theorem selectedBound31611 : packedSelected [1,2,3,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7464,2341,80,7459,5393,2340,1025,81,4160,7172,17,7207,7464,65,2128,5392,3108,5457,1364,7172,257,7173,2420,513]

theorem envBound31612 : H12AffineFastState.Bounded env31612 := by
  intro p hp
  have h : env31612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31611_31612 : H12AffineEnvironment.transform 12 7464 env31611 = env31612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7464 env31611 == env31612) = true)

theorem identity31612 : scanCanonicalize (H12AffineFastState.compose env31612 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound31612 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1337,2341,80,1330,3328,2340,1025,81,2129,1045,17,1078,1337,65,2128,3329,3108,3392,1364,1045,257,1044,2420,513]

theorem envBound31613 : H12AffineFastState.Bounded env31613 := by
  intro p hp
  have h : env31613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31612_31613 : H12AffineEnvironment.transform 11 2065 env31612 = env31613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env31612 == env31613) = true)

theorem identity31613 : scanCanonicalize (H12AffineFastState.compose env31613 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31613 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env31614 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2065,40,2341,80,35,2065,2340,272,81,2129,260,17,295,40,65,2128,2064,2357,2129,69,260,257,261,2420,513]

theorem envBound31614 : H12AffineFastState.Bounded env31614 := by
  intro p hp
  have h : env31614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31613_31614 : H12AffineEnvironment.transform 9 273 env31613 = env31614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31613 == env31614) = true)

theorem identity31614 : scanCanonicalize (H12AffineFastState.compose env31614 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31614 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env31615 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2065,40,2341,0,35,2065,2340,272,1,2049,260,17,295,40,17,2048,2064,2357,2049,21,260,257,261,2340,513]

theorem envBound31615 : H12AffineFastState.Bounded env31615 := by
  intro p hp
  have h : env31615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31614_31615 : H12AffineEnvironment.transform 5 16 env31614 = env31615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31614 == env31615) = true)

theorem identity31615 : scanCanonicalize (H12AffineFastState.compose env31615 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31615 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31616 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2065,40,2048,0,35,2065,2049,53,1,2049,33,17,2,40,17,2048,2064,2064,2049,21,33,36,32,2049,513]

theorem envBound31616 : H12AffineFastState.Bounded env31616 := by
  intro p hp
  have h : env31616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31615_31616 : H12AffineEnvironment.transform 7 37 env31615 = env31616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31615 == env31616) = true)

theorem identity31616 : scanCanonicalize (H12AffineFastState.compose env31616 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound31616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31617 : List Nat := [2,4,8,16,32,16,8,37,33,52,2048,2065,40,2048,0,35,2065,2049,53,1,2049,33,17,2,40,17,2048,2064,2064,2049,21,33,36,32,2049,32]

theorem envBound31617 : H12AffineFastState.Bounded env31617 := by
  intro p hp
  have h : env31617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31616_31617 : H12AffineEnvironment.transform 8 33 env31616 = env31617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env31616 == env31617) = true)

theorem identity31617 : scanCanonicalize (H12AffineFastState.compose env31617 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound31617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31618 : List Nat := [2,4,8,16,32,16,8,37,33,52,16,1,40,16,0,35,1,17,53,1,17,33,17,2,40,17,16,0,0,17,21,33,36,32,17,32]

theorem envBound31618 : H12AffineFastState.Bounded env31618 := by
  intro p hp
  have h : env31618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31617_31618 : H12AffineEnvironment.transform 10 16 env31617 = env31618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env31617 == env31618) = true)

def env31619 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,21792,294200,272427,8193,65,450617,302181,276520,179512,61705,272392,257,41340,16465,63069]

theorem envBound31619 : H12AffineFastState.Bounded env31619 := by
  intro p hp
  have h : env31619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31606_31619 : H12AffineEnvironment.transform 6 9 env31606 = env31619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31606 == env31619) = true)

theorem identity31619 : scanCanonicalize (H12AffineFastState.compose env31619 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31619 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,21792,294200,272427,8193,65,303144,302181,276520,64809,61705,272392,257,41340,16465,63069]

theorem envBound31620 : H12AffineFastState.Bounded env31620 := by
  intro p hp
  have h : env31620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31619_31620 : H12AffineEnvironment.transform 16 16401 env31619 = env31620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31619 == env31620) = true)

theorem identity31620 : scanCanonicalize (H12AffineFastState.compose env31620 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound31620 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16401,262144,1025,29789,4160,21792,294200,272427,8193,65,283764,288825,276520,2421,1365,272392,257,21792,16465,513]

theorem envBound31621 : H12AffineFastState.Bounded env31621 := by
  intro p hp
  have h : env31621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31620_31621 : H12AffineEnvironment.transform 14 29788 env31620 = env31621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env31620 == env31621) = true)

theorem identity31621 : scanCanonicalize (H12AffineFastState.compose env31621 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 11340) := by decide +kernel

theorem selectedBound31621 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env31622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16401,11340,1025,29789,4160,21792,20852,1127,8193,65,30776,17525,5220,2421,1365,1092,257,21792,16465,513]

theorem envBound31622 : H12AffineFastState.Bounded env31622 := by
  intro p hp
  have h : env31622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31621_31622 : H12AffineEnvironment.transform 17 11340 env31621 = env31622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11340 env31621 == env31622) = true)

theorem identity31622 : scanCanonicalize (H12AffineFastState.compose env31622 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31622 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env31623 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,16384,29004,8203,16401,10588,273,29005,4160,20528,20852,375,8193,65,30776,16741,4468,2421,69,340,257,20528,16465,513]

theorem envBound31623 : H12AffineFastState.Bounded env31623 := by
  intro p hp
  have h : env31623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31622_31623 : H12AffineEnvironment.transform 9 272 env31622 = env31623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31622 == env31623) = true)

theorem identity31623 : scanCanonicalize (H12AffineFastState.compose env31623 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31623 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env31624 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,8192,16384,28728,8203,16401,10280,101,28729,4160,20528,20480,3,8193,65,30776,16401,4096,2049,69,32,117,20528,16465,513]

theorem envBound31624 : H12AffineFastState.Bounded env31624 := by
  intro p hp
  have h : env31624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31623_31624 : H12AffineEnvironment.transform 7 116 env31623 = env31624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31623 == env31624) = true)

theorem identity31624 : scanCanonicalize (H12AffineFastState.compose env31624 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound31624 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31625 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,4096,8192,4113,8233,8203,4096,10280,101,8232,4160,33,17,3,8193,65,10281,4096,4096,2049,69,32,117,33,4160,513]

theorem envBound31625 : H12AffineFastState.Bounded env31625 := by
  intro p hp
  have h : env31625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31624_31625 : H12AffineEnvironment.transform 13 4113 env31624 = env31625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env31624 == env31625) = true)

theorem identity31625 : scanCanonicalize (H12AffineFastState.compose env31625 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31626 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,8192,4113,8233,8203,4096,10280,52,8232,4113,33,17,3,8193,16,10281,4096,4096,2049,20,32,36,33,4113,513]

theorem envBound31626 : H12AffineFastState.Bounded env31626 := by
  intro p hp
  have h : env31626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31625_31626 : H12AffineEnvironment.transform 5 17 env31625 = env31626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31625 == env31626) = true)

theorem identity31626 : scanCanonicalize (H12AffineFastState.compose env31626 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound31626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31627 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,4105,4113,4128,4098,4096,6177,52,4129,4113,33,17,3,4104,16,6176,4096,4096,2049,20,32,36,33,4113,513]

theorem envBound31627 : H12AffineFastState.Bounded env31627 := by
  intro p hp
  have h : env31627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31626_31627 : H12AffineEnvironment.transform 12 4105 env31626 = env31627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env31626 == env31627) = true)

theorem identity31627 : scanCanonicalize (H12AffineFastState.compose env31627 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound31627 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31628 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,528,537,513,560,530,528,2609,52,561,513,33,17,3,536,16,2608,528,528,2049,20,32,36,33,513,513]

theorem envBound31628 : H12AffineFastState.Bounded env31628 := by
  intro p hp
  have h : env31628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31627_31628 : H12AffineEnvironment.transform 11 528 env31627 = env31628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env31627 == env31628) = true)

def env31629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329761,8328,65,508090,302316,333859,236850,119042,272393,257,98815,90203,63188]

theorem envBound31629 : H12AffineFastState.Bounded env31629 := by
  intro p hp
  have h : env31629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31604_31629 : H12AffineEnvironment.transform 20 4161 env31604 = env31629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31604 == env31629) = true)

theorem identity31629 : scanCanonicalize (H12AffineFastState.compose env31629 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound31629 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,4161,21928,17,21762,8328,65,171417,115151,17664,236850,119042,95530,257,98815,90203,63188]

theorem envBound31630 : H12AffineFastState.Bounded env31630 := by
  intro p hp
  have h : env31630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31629_31630 : H12AffineEnvironment.transform 17 89379 env31629 = env31630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env31629 == env31630) = true)

theorem identity31630 : scanCanonicalize (H12AffineFastState.compose env31630 (packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound31630 : packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env31631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21928,17,21762,8328,65,35325,115151,17664,100694,119042,95530,257,98815,90203,63188]

theorem envBound31631 : H12AffineFastState.Bounded env31631 := by
  intro p hp
  have h : env31631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31630_31631 : H12AffineEnvironment.transform 16 5220 env31630 = env31631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env31630 == env31631) = true)

def env31632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21792,17,21762,8192,65,35189,115015,17664,100694,119042,95530,257,98679,90203,63068]

theorem envBound31632 : H12AffineFastState.Bounded env31632 := by
  intro p hp
  have h : env31632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31631_31632 : H12AffineEnvironment.transform 6 8 env31631 = env31632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31631 == env31632) = true)

theorem identity31632 : scanCanonicalize (H12AffineFastState.compose env31632 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound31632 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31633 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5220,89379,1025,29788,4161,21792,17,21762,8192,65,32040,79130,17664,97547,75103,95530,257,95530,90203,513]

theorem envBound31633 : H12AffineFastState.Bounded env31633 := by
  intro p hp
  have h : env31633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31632_31633 : H12AffineEnvironment.transform 14 29789 env31632 = env31633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env31632 == env31633) = true)

theorem identity31633 : scanCanonicalize (H12AffineFastState.compose env31633 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31633 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env31634 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,5220,32041,1025,29788,4161,21792,17,21762,8192,65,32040,5392,17664,23809,1365,21792,257,21792,16465,513]

theorem envBound31634 : H12AffineFastState.Bounded env31634 := by
  intro p hp
  have h : env31634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31633_31634 : H12AffineEnvironment.transform 15 8202 env31633 = env31634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31633 == env31634) = true)

theorem identity31634 : scanCanonicalize (H12AffineFastState.compose env31634 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31634 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,5220,2421,1025,0,4161,8572,17,8542,8192,65,2420,5392,12636,10589,1365,8572,257,8572,13325,513]

theorem envBound31635 : H12AffineFastState.Bounded env31635 := by
  intro p hp
  have h : env31635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31634_31635 : H12AffineEnvironment.transform 13 13404 env31634 = env31635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31634 == env31635) = true)

theorem identity31635 : scanCanonicalize (H12AffineFastState.compose env31635 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31635 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5220,2421,1025,0,4161,32,17,2,348,65,2420,5392,4096,2049,1365,32,257,32,5457,513]

theorem envBound31636 : H12AffineFastState.Bounded env31636 := by
  intro p hp
  have h : env31636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31635_31636 : H12AffineEnvironment.transform 12 348 env31635 = env31636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31635 == env31636) = true)

theorem identity31636 : scanCanonicalize (H12AffineFastState.compose env31636 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31636 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env31637 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,5237,1,35,5220,2048,1025,0,4161,32,17,2,41,65,2049,5221,4096,2049,1056,32,116,32,5156,513]

theorem envBound31637 : H12AffineFastState.Bounded env31637 := by
  intro p hp
  have h : env31637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31636_31637 : H12AffineEnvironment.transform 7 117 env31636 = env31637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31636 == env31637) = true)

theorem identity31637 : scanCanonicalize (H12AffineFastState.compose env31637 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound31637 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31638 : List Nat := [2,4,8,16,32,64,8,117,512,1024,602,4096,41,5237,1,35,5220,602,1025,0,4161,32,17,2,41,65,603,5221,4096,603,1056,32,116,32,5156,513]

theorem envBound31638 : H12AffineFastState.Bounded env31638 := by
  intro p hp
  have h : env31638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31637_31638 : H12AffineEnvironment.transform 10 602 env31637 = env31638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env31637 == env31638) = true)

theorem identity31638 : scanCanonicalize (H12AffineFastState.compose env31638 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31638 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31639 : List Nat := [2,4,8,16,32,64,8,117,512,101,602,4096,41,4112,1,35,4097,602,100,0,4161,32,17,2,41,65,603,4096,4096,603,69,32,116,32,4161,513]

theorem envBound31639 : H12AffineFastState.Bounded env31639 := by
  intro p hp
  have h : env31639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31638_31639 : H12AffineEnvironment.transform 9 101 env31638 = env31639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31638 == env31639) = true)

theorem identity31639 : scanCanonicalize (H12AffineFastState.compose env31639 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound31639 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31640 : List Nat := [2,4,8,16,32,64,8,117,512,101,602,64,41,80,1,35,65,602,100,0,1,32,17,2,41,65,603,64,64,603,69,32,116,32,1,513]

theorem envBound31640 : H12AffineFastState.Bounded env31640 := by
  intro p hp
  have h : env31640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31639_31640 : H12AffineEnvironment.transform 11 64 env31639 = env31640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env31639 == env31640) = true)

theorem identity31640 : scanCanonicalize (H12AffineFastState.compose env31640 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound31640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31641 : List Nat := [2,4,8,16,32,64,8,117,5,101,95,64,41,80,1,35,65,95,100,0,1,32,17,2,41,65,94,64,64,94,69,32,116,32,1,4]

theorem envBound31641 : H12AffineFastState.Bounded env31641 := by
  intro p hp
  have h : env31641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31640_31641 : H12AffineEnvironment.transform 8 5 env31640 = env31641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env31640 == env31641) = true)

theorem identity31641 : scanCanonicalize (H12AffineFastState.compose env31641 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 62) := by decide +kernel

theorem selectedBound31641 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31642 : List Nat := [2,4,8,16,32,62,8,11,5,27,33,62,41,46,1,35,63,33,26,0,1,32,17,2,41,63,32,62,62,32,59,32,10,32,1,4]

theorem envBound31642 : H12AffineFastState.Bounded env31642 := by
  intro p hp
  have h : env31642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31641_31642 : H12AffineEnvironment.transform 5 62 env31641 = env31642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 62 env31641 == env31642) = true)

theorem identity31642 : scanCanonicalize (H12AffineFastState.compose env31642 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31642 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31643 : List Nat := [1,4,8,16,32,61,8,8,5,24,33,61,41,45,1,32,60,33,25,0,1,32,17,1,41,60,32,61,61,32,56,32,9,32,1,4]

theorem envBound31643 : H12AffineFastState.Bounded env31643 := by
  intro p hp
  have h : env31643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31642_31643 : H12AffineEnvironment.transform 0 1 env31642 = env31643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31642 == env31643) = true)

theorem identity31643 : scanCanonicalize (H12AffineFastState.compose env31643 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31643 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env31644 : List Nat := [1,4,8,16,0,29,8,8,5,24,1,29,9,13,1,0,28,1,25,0,1,0,17,1,9,28,0,29,29,0,24,0,9,0,1,4]

theorem envBound31644 : H12AffineFastState.Bounded env31644 := by
  intro p hp
  have h : env31644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31643_31644 : H12AffineEnvironment.transform 4 0 env31643 = env31644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31643 == env31644) = true)

def env31645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,5220,89379,1025,32769,4161,21793,17,21762,8193,65,35188,115014,17664,100694,119042,95530,257,98678,90203,63069]

theorem envBound31645 : H12AffineFastState.Bounded env31645 := by
  intro p hp
  have h : env31645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31631_31645 : H12AffineEnvironment.transform 6 9 env31631 = env31645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31631 == env31645) = true)

theorem identity31645 : scanCanonicalize (H12AffineFastState.compose env31645 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31645 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5220,67618,1025,32769,4161,32,17,3,8193,65,35188,103495,4097,100694,99331,73771,257,98678,79194,41820]

theorem envBound31646 : H12AffineFastState.Bounded env31646 := by
  intro p hp
  have h : env31646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31645_31646 : H12AffineEnvironment.transform 13 5377 env31645 = env31646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31645 == env31646) = true)

theorem identity31646 : scanCanonicalize (H12AffineFastState.compose env31646 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound31646 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env31647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40971,5220,43049,1025,32769,4161,32,17,3,8193,65,35188,13388,4097,10589,9224,32800,257,8573,38225,41820]

theorem envBound31647 : H12AffineFastState.Bounded env31647 := by
  intro p hp
  have h : env31647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31646_31647 : H12AffineEnvironment.transform 15 40971 env31646 = env31647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env31646 == env31647) = true)

theorem identity31647 : scanCanonicalize (H12AffineFastState.compose env31647 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound31647 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env31648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,263,5220,2341,1025,8461,4161,32,17,3,8193,65,10360,13388,4097,10589,9224,8492,257,8573,13405,592]

theorem envBound31648 : H12AffineFastState.Bounded env31648 := by
  intro p hp
  have h : env31648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31647_31648 : H12AffineEnvironment.transform 14 8460 env31647 = env31648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env31647 == env31648) = true)

theorem identity31648 : scanCanonicalize (H12AffineFastState.compose env31648 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31648 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,0,263,5220,2341,1025,1,4161,32,17,3,269,65,2420,5440,4097,2129,1284,32,257,113,5457,592]

theorem envBound31649 : H12AffineFastState.Bounded env31649 := by
  intro p hp
  have h : env31649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31648_31649 : H12AffineEnvironment.transform 12 268 env31648 = env31649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31648 == env31649) = true)

theorem identity31649 : scanCanonicalize (H12AffineFastState.compose env31649 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound31649 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31650 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,0,114,5220,2128,1025,1,4161,32,17,3,120,65,2049,5173,4097,2129,1137,32,116,113,5156,592]

theorem envBound31650 : H12AffineFastState.Bounded env31650 := by
  intro p hp
  have h : env31650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31649_31650 : H12AffineEnvironment.transform 7 117 env31649 = env31650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31649 == env31650) = true)

theorem identity31650 : scanCanonicalize (H12AffineFastState.compose env31650 (packedSelected [3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31650 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env31651 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,8,5125,0,3,5141,2081,1025,1,4144,32,17,3,9,48,2049,5173,4097,2080,1024,32,5,0,5156,545]

theorem envBound31651 : H12AffineFastState.Bounded env31651 := by
  intro p hp
  have h : env31651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31650_31651 : H12AffineEnvironment.transform 5 49 env31650 = env31651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31650 == env31651) = true)

theorem identity31651 : scanCanonicalize (H12AffineFastState.compose env31651 (packedSelected [0,7,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31651 : packedSelected [0,7,14] rootPS < 2^1333 := by decide +kernel

def env31652 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5125,0,3,5141,2048,1025,1,4113,1,17,3,9,17,2049,5140,4097,2049,1024,1,5,0,5125,512]

theorem envBound31652 : H12AffineFastState.Bounded env31652 := by
  intro p hp
  have h : env31652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31651_31652 : H12AffineEnvironment.transform 4 1 env31651 = env31652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31651 == env31652) = true)

def env31653 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1045,0,3,1029,2048,1025,1,1,1,17,3,9,17,2049,1028,17,2049,1024,1,5,0,1045,512]

theorem envBound31653 : H12AffineFastState.Bounded env31653 := by
  intro p hp
  have h : env31653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31652_31653 : H12AffineEnvironment.transform 11 16 env31652 = env31653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31652 == env31653) = true)

def env31654 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,1,0,3,17,2048,21,1,1,1,17,3,9,17,2049,16,17,2049,20,1,5,0,1,512]

theorem envBound31654 : H12AffineFastState.Bounded env31654 := by
  intro p hp
  have h : env31654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31653_31654 : H12AffineEnvironment.transform 9 20 env31653 = env31654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31653 == env31654) = true)

theorem identity31654 : scanCanonicalize (H12AffineFastState.compose env31654 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound31654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31655 : List Nat := [2,4,8,16,1,16,9,4,512,20,542,16,8,1,0,3,17,542,21,1,1,1,17,3,9,17,543,16,17,543,20,1,5,0,1,512]

theorem envBound31655 : H12AffineFastState.Bounded env31655 := by
  intro p hp
  have h : env31655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31654_31655 : H12AffineEnvironment.transform 10 542 env31654 = env31655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env31654 == env31655) = true)

def leafEnv31655 : List Nat := [2,4,8,16,1,16,9,4,512,20,542,16,8,1,0,3,17,542,21,1,1,1,17,3,21,9,1,17,543,16,17,543,20,1,5,0,5,2,1,512,1,1,0]

def active31655 : List Nat := [0,1,2,3,8]

def tree31655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31655 : H12WitnessSearch.Good tree31655 := H12GlobalWitnessIndex.good

theorem leafIdentity31655 : H12AffineFastState.composeSystem env31655 rootObs = leafEnv31655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31655 rootObs == leafEnv31655) = true)

theorem terminalChecked31655 : H12PackedTerminal.terminalCheckFast leafEnv31655 active31655 tree31655 = true := by decide +kernel

def env31656 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,0,0,3,16,2048,20,1,1,1,17,3,9,17,2049,17,17,2049,21,1,5,0,0,512]

theorem envBound31656 : H12AffineFastState.Bounded env31656 := by
  intro p hp
  have h : env31656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31653_31656 : H12AffineEnvironment.transform 9 21 env31653 = env31656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env31653 == env31656) = true)

theorem identity31656 : scanCanonicalize (H12AffineFastState.compose env31656 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound31656 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31657 : List Nat := [2,4,8,16,1,16,9,4,512,21,20,16,8,0,0,3,16,20,20,1,1,1,17,3,9,17,21,17,17,21,21,1,5,0,0,512]

theorem envBound31657 : H12AffineFastState.Bounded env31657 := by
  intro p hp
  have h : env31657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31656_31657 : H12AffineEnvironment.transform 10 20 env31656 = env31657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env31656 == env31657) = true)

def leafEnv31657 : List Nat := [2,4,8,16,1,16,9,4,512,21,20,16,8,0,0,3,16,20,20,1,1,1,17,3,20,9,1,17,21,17,17,21,21,1,5,0,5,2,0,512,1,1,0]

def active31657 : List Nat := [0,1,2,3,8]

def tree31657 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31657 : H12WitnessSearch.Good tree31657 := H12GlobalWitnessIndex.good

theorem leafIdentity31657 : H12AffineFastState.composeSystem env31657 rootObs = leafEnv31657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31657 rootObs == leafEnv31657) = true)

theorem terminalChecked31657 : H12PackedTerminal.terminalCheckFast leafEnv31657 active31657 tree31657 = true := by decide +kernel

def env31658 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1044,0,3,1028,2048,1025,1,0,1,17,3,9,17,2049,1029,16,2049,1024,1,5,0,1044,512]

theorem envBound31658 : H12AffineFastState.Bounded env31658 := by
  intro p hp
  have h : env31658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31652_31658 : H12AffineEnvironment.transform 11 17 env31652 = env31658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31652 == env31658) = true)

theorem identity31658 : scanCanonicalize (H12AffineFastState.compose env31658 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound31658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31659 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,0,3,17,2048,20,1,0,1,17,3,9,17,2049,16,16,2049,21,1,5,0,1,512]

theorem envBound31659 : H12AffineFastState.Bounded env31659 := by
  intro p hp
  have h : env31659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31658_31659 : H12AffineEnvironment.transform 9 21 env31658 = env31659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env31658 == env31659) = true)

theorem identity31659 : scanCanonicalize (H12AffineFastState.compose env31659 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound31659 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31660 : List Nat := [2,4,8,16,1,16,9,4,512,21,21,17,8,1,0,3,17,21,20,1,0,1,17,3,9,17,20,16,16,20,21,1,5,0,1,512]

theorem envBound31660 : H12AffineFastState.Bounded env31660 := by
  intro p hp
  have h : env31660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31659_31660 : H12AffineEnvironment.transform 10 21 env31659 = env31660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env31659 == env31660) = true)

def leafEnv31660 : List Nat := [2,4,8,16,1,16,9,4,512,21,21,17,8,1,0,3,17,21,20,1,0,1,17,3,20,9,1,17,20,16,16,20,21,1,5,0,5,2,1,512,1,0,0]

def active31660 : List Nat := [0,1,2,3,8]

def tree31660 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31660 : H12WitnessSearch.Good tree31660 := H12GlobalWitnessIndex.good

theorem leafIdentity31660 : H12AffineFastState.composeSystem env31660 rootObs = leafEnv31660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31660 rootObs == leafEnv31660) = true)

theorem terminalChecked31660 : H12PackedTerminal.terminalCheckFast leafEnv31660 active31660 tree31660 = true := by decide +kernel

def env31661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431073,8328,65,2609402,302317,333859,2329971,119043,2373705,257,2199999,2191387,63189]

theorem envBound31661 : H12AffineFastState.Bounded env31661 := by
  intro p hp
  have h : env31661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31603_31661 : H12AffineEnvironment.transform 23 2431073 env31603 = env31661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env31603 == env31661) = true)

def env31662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329761,8328,65,508090,302317,333859,236851,119043,272393,257,98815,90203,63189]

theorem envBound31662 : H12AffineFastState.Bounded env31662 := by
  intro p hp
  have h : env31662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31661_31662 : H12AffineEnvironment.transform 20 4160 env31661 = env31662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31661 == env31662) = true)

theorem identity31662 : scanCanonicalize (H12AffineFastState.compose env31662 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109046) := by decide +kernel

theorem selectedBound31662 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109046,1025,32769,4160,21929,62661,41431,8328,65,158028,79131,45525,236851,119043,98815,257,98815,90203,63189]

theorem envBound31663 : H12AffineFastState.Bounded env31663 := by
  intro p hp
  have h : env31663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31662_31663 : H12AffineEnvironment.transform 17 109046 env31662 = env31663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109046 env31662 == env31663) = true)

theorem identity31663 : scanCanonicalize (H12AffineFastState.compose env31663 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound31663 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,89378,1025,29909,4160,21929,17,21763,8328,65,158028,79131,17665,223719,75223,95531,257,95531,90203,513]

theorem envBound31664 : H12AffineFastState.Bounded env31664 := by
  intro p hp
  have h : env31664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31663_31664 : H12AffineEnvironment.transform 14 29908 env31663 = env31664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env31663 == env31664) = true)

theorem identity31664 : scanCanonicalize (H12AffineFastState.compose env31664 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31664 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env31665 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29908,65536,131072,89174,1025,29909,4160,21725,17,21623,8328,65,157752,78959,17525,223379,74915,95327,117,95327,90203,513]

theorem envBound31665 : H12AffineFastState.Bounded env31665 := by
  intro p hp
  have h : env31665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31664_31665 : H12AffineEnvironment.transform 7 116 env31664 = env31665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31664 == env31665) = true)

theorem identity31665 : scanCanonicalize (H12AffineFastState.compose env31665 (packedSelected [0,1,5,6,8,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound31665 : packedSelected [0,1,5,6,8,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31666 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29908,65536,16537,89174,1025,29909,4160,21725,17,21623,8328,65,10401,78959,17525,75786,74915,95327,117,95327,90203,513]

theorem envBound31666 : H12AffineFastState.Bounded env31666 := by
  intro p hp
  have h : env31666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31665_31666 : H12AffineEnvironment.transform 16 16537 env31665 = env31666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env31665 == env31666) = true)

theorem identity31666 : scanCanonicalize (H12AffineFastState.compose env31666 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31666 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env31667 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13405,137,65536,13508,75787,1025,136,4160,8320,17,8234,8328,65,10401,78959,12328,75786,74915,65538,117,65538,70662,513]

theorem envBound31667 : H12AffineFastState.Bounded env31667 := by
  intro p hp
  have h : env31667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31666_31667 : H12AffineEnvironment.transform 13 13405 env31666 = env31667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31666 == env31667) = true)

theorem identity31667 : scanCanonicalize (H12AffineFastState.compose env31667 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound31667 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env31668 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,40,5237,137,65536,5356,67619,1025,136,4160,168,17,2,160,65,2185,70727,4096,67618,66699,65538,117,65538,70662,513]

theorem envBound31668 : H12AffineFastState.Bounded env31668 := by
  intro p hp
  have h : env31668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31667_31668 : H12AffineEnvironment.transform 12 40 env31667 = env31668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env31667 == env31668) = true)

theorem identity31668 : scanCanonicalize (H12AffineFastState.compose env31668 (packedSelected [0,1,6,7,8,10,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 3095) := by decide +kernel

theorem selectedBound31668 : packedSelected [0,1,6,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env31669 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,40,5237,137,3095,5356,1076,1025,136,4160,168,17,2,160,65,2185,6224,4096,1077,2204,3093,117,3093,6161,513]

theorem envBound31669 : H12AffineFastState.Bounded env31669 := by
  intro p hp
  have h : env31669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31668_31669 : H12AffineEnvironment.transform 15 3095 env31668 = env31669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3095 env31668 == env31669) = true)

theorem identity31669 : scanCanonicalize (H12AffineFastState.compose env31669 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31669 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31670 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,1,3095,5220,1076,1025,0,4160,32,17,2,40,65,2049,6224,4096,1077,2068,3093,117,3093,6161,513]

theorem envBound31670 : H12AffineFastState.Bounded env31670 := by
  intro p hp
  have h : env31670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31669_31670 : H12AffineEnvironment.transform 6 8 env31669 = env31670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31669 == env31670) = true)

theorem identity31670 : scanCanonicalize (H12AffineFastState.compose env31670 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound31670 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31671 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,40,4113,1,2163,4096,80,101,0,4160,32,17,2,40,65,2049,6224,4096,81,2068,2161,117,2161,6161,513]

theorem envBound31671 : H12AffineFastState.Bounded env31671 := by
  intro p hp
  have h : env31671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31670_31671 : H12AffineEnvironment.transform 9 100 env31670 = env31671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env31670 == env31671) = true)

def env31672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329760,8328,65,508091,302317,333859,236850,119043,272392,257,98814,90202,63189]

theorem envBound31672 : H12AffineFastState.Bounded env31672 := by
  intro p hp
  have h : env31672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31661_31672 : H12AffineEnvironment.transform 20 4161 env31661 = env31672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31661 == env31672) = true)

theorem identity31672 : scanCanonicalize (H12AffineFastState.compose env31672 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound31672 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,21928,297453,318719,8328,65,398436,302317,314620,149997,1500,272392,257,21793,46213,63189]

theorem envBound31673 : H12AffineFastState.Bounded env31673 := by
  intro p hp
  have h : env31673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31672_31673 : H12AffineEnvironment.transform 15 54495 env31672 = env31673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env31672 == env31673) = true)

def env31674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10280,1025,32769,4161,21928,41413,62679,8328,65,146508,46277,58580,149997,1500,32,257,21793,46213,63189]

theorem envBound31674 : H12AffineFastState.Bounded env31674 := by
  intro p hp
  have h : env31674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31673_31674 : H12AffineEnvironment.transform 17 10280 env31673 = env31674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env31673 == env31674) = true)

theorem identity31674 : scanCanonicalize (H12AffineFastState.compose env31674 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31674 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,131072,10280,1025,32769,4161,168,41413,41431,8328,65,146508,46277,45524,138477,1500,32,257,33,46213,41941]

theorem envBound31675 : H12AffineFastState.Bounded env31675 := by
  intro p hp
  have h : env31675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31674_31675 : H12AffineEnvironment.transform 13 5376 env31674 = env31675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31674 == env31675) = true)

theorem identity31675 : scanCanonicalize (H12AffineFastState.compose env31675 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound31675 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env31676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,131072,10280,1025,8661,4161,168,17,3,8328,65,146508,5393,4096,138477,1500,32,257,33,5457,513]

theorem envBound31676 : H12AffineFastState.Bounded env31676 := by
  intro p hp
  have h : env31676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31675_31676 : H12AffineEnvironment.transform 14 8660 env31675 = env31676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env31675 == env31676) = true)

theorem identity31676 : scanCanonicalize (H12AffineFastState.compose env31676 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13745) := by decide +kernel

theorem selectedBound31676 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13745,10280,1025,8661,4161,168,17,3,8328,65,2557,5393,4096,10588,1500,32,257,33,5457,513]

theorem envBound31677 : H12AffineFastState.Bounded env31677 := by
  intro p hp
  have h : env31677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31676_31677 : H12AffineEnvironment.transform 16 13745 env31676 = env31677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13745 env31676 == env31677) = true)

def env31678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,10281,1025,32769,4161,21928,41412,62678,8328,65,146509,46276,58581,149997,1500,33,257,21793,46213,63189]

theorem envBound31678 : H12AffineFastState.Bounded env31678 := by
  intro p hp
  have h : env31678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31673_31678 : H12AffineEnvironment.transform 17 10281 env31673 = env31678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env31673 == env31678) = true)

theorem identity31678 : scanCanonicalize (H12AffineFastState.compose env31678 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound31678 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8323,131072,10281,1025,29789,4161,21928,21912,138,8328,65,146509,16536,4233,149997,1500,33,257,21793,16601,649]

theorem envBound31679 : H12AffineFastState.Bounded env31679 := by
  intro p hp
  have h : env31679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31678_31679 : H12AffineEnvironment.transform 14 29788 env31678 = env31679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env31678 == env31679) = true)

theorem identity31679 : scanCanonicalize (H12AffineFastState.compose env31679 (packedSelected [0,1,2,6,7,8,9,10,15,18,22] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound31679 : packedSelected [0,1,2,6,7,8,9,10,15,18,22] rootPS < 2^1333 := by decide +kernel

def env31680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8323,13508,10281,1025,29789,4161,21928,21912,138,8328,65,2185,16536,4233,32041,1500,33,257,21793,16601,649]

theorem envBound31680 : H12AffineFastState.Bounded env31680 := by
  intro p hp
  have h : env31680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31679_31680 : H12AffineEnvironment.transform 16 13508 env31679 = env31680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env31679 == env31680) = true)

theorem identity31680 : scanCanonicalize (H12AffineFastState.compose env31680 (packedSelected [0,4,7,9,11,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31680 : packedSelected [0,4,7,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29708,8323,13460,10281,1025,29709,4113,21928,21912,138,8328,17,2185,16536,4233,32041,1420,33,257,21793,16521,649]

theorem envBound31681 : H12AffineFastState.Bounded env31681 := by
  intro p hp
  have h : env31681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31680_31681 : H12AffineEnvironment.transform 5 16 env31680 = env31681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31680 == env31681) = true)

theorem identity31681 : scanCanonicalize (H12AffineFastState.compose env31681 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound31681 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,137,8323,13460,10281,1025,136,4113,8493,8477,138,8328,17,2185,13341,4233,2476,1420,33,257,8612,13324,649]

theorem envBound31682 : H12AffineFastState.Bounded env31682 := by
  intro p hp
  have h : env31682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31681_31682 : H12AffineEnvironment.transform 13 13445 env31681 = env31682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env31681 == env31682) = true)

theorem identity31682 : scanCanonicalize (H12AffineFastState.compose env31682 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31682 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31683 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,137,399,5528,2341,1025,136,4113,33,17,138,388,17,2185,5393,4233,2476,1420,33,257,168,5376,649]

theorem envBound31683 : H12AffineFastState.Bounded env31683 := by
  intro p hp
  have h : env31683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31682_31683 : H12AffineEnvironment.transform 12 268 env31682 = env31683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31682 == env31683) = true)

theorem identity31683 : scanCanonicalize (H12AffineFastState.compose env31683 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31683 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env31684 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,41,5292,137,170,5309,2048,1025,136,4113,33,17,138,161,17,2185,5172,4233,2185,1193,33,36,168,5157,649]

theorem envBound31684 : H12AffineFastState.Bounded env31684 := by
  intro p hp
  have h : env31684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31683_31684 : H12AffineEnvironment.transform 7 37 env31683 = env31684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31683 == env31684) = true)

theorem identity31684 : scanCanonicalize (H12AffineFastState.compose env31684 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31684 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31685 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,34,5173,2048,1025,0,4113,33,17,2,41,17,2049,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound31685 : H12AffineFastState.Bounded env31685 := by
  intro p hp
  have h : env31685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31684_31685 : H12AffineEnvironment.transform 6 8 env31684 = env31685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31684 == env31685) = true)

theorem identity31685 : scanCanonicalize (H12AffineFastState.compose env31685 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound31685 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31686 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,1,34,4096,2048,52,0,4113,33,17,2,41,17,2049,4097,4097,2049,20,33,36,32,4112,513]

theorem envBound31686 : H12AffineFastState.Bounded env31686 := by
  intro p hp
  have h : env31686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31685_31686 : H12AffineEnvironment.transform 9 53 env31685 = env31686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env31685 == env31686) = true)

theorem identity31686 : scanCanonicalize (H12AffineFastState.compose env31686 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound31686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31687 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,4096,41,4113,1,34,4096,2048,52,0,4113,33,17,2,41,17,2049,4097,4097,2049,20,33,36,32,4112,49]

theorem envBound31687 : H12AffineFastState.Bounded env31687 := by
  intro p hp
  have h : env31687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31686_31687 : H12AffineEnvironment.transform 8 48 env31686 = env31687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env31686 == env31687) = true)

theorem identity31687 : scanCanonicalize (H12AffineFastState.compose env31687 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound31687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31688 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,33,41,48,1,34,33,2048,52,0,48,33,17,2,41,17,2049,32,32,2049,20,33,36,32,49,49]

theorem envBound31688 : H12AffineFastState.Bounded env31688 := by
  intro p hp
  have h : env31688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31687_31688 : H12AffineEnvironment.transform 11 33 env31687 = env31688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env31687 == env31688) = true)

theorem identity31688 : scanCanonicalize (H12AffineFastState.compose env31688 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31688 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31689 : List Nat := [2,4,8,16,32,16,8,37,48,53,49,33,41,48,1,34,33,49,52,0,48,33,17,2,41,17,48,32,32,48,20,33,36,32,49,49]

theorem envBound31689 : H12AffineFastState.Bounded env31689 := by
  intro p hp
  have h : env31689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31688_31689 : H12AffineEnvironment.transform 10 49 env31688 = env31689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31688 == env31689) = true)

def env31690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound31690 : H12AffineFastState.Bounded env31690 := by
  intro p hp
  have h : env31690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31289_31690 : H12AffineEnvironment.transform 26 30393345 env31289 = env31690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env31289 == env31690) = true)

def env31691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound31691 : H12AffineFastState.Bounded env31691 := by
  intro p hp
  have h : env31691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31690_31691 : H12AffineEnvironment.transform 18 1024 env31690 = env31691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31690 == env31691) = true)

theorem identity31691 : scanCanonicalize (H12AffineFastState.compose env31691 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound31691 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362227,18973837,10507600,8456242,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound31692 : H12AffineFastState.Bounded env31692 := by
  intro p hp
  have h : env31692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31691_31692 : H12AffineEnvironment.transform 17 247858 env31691 = env31692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env31691 == env31692) = true)

def env31693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784943,5393,10507600,8456242,10491277,4256860,256,8410417,8434837,10564186]

theorem envBound31693 : H12AffineFastState.Bounded env31693 := by
  intro p hp
  have h : env31693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31692_31693 : H12AffineEnvironment.transform 23 2199964 env31692 = env31693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env31692 == env31693) = true)

def env31694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,8388608,98780,8328,65,12683759,5393,8406288,8456242,8390093,4256860,256,8410417,8434837,8462874]

theorem envBound31694 : H12AffineFastState.Bounded env31694 := by
  intro p hp
  have h : env31694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31693_31694 : H12AffineEnvironment.transform 20 4160 env31693 = env31694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31693 == env31694) = true)

def env31695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98780,8328,65,4295167,5393,17664,67618,1501,4256860,256,21793,46213,74250]

theorem envBound31695 : H12AffineFastState.Bounded env31695 := by
  intro p hp
  have h : env31695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31694_31695 : H12AffineEnvironment.transform 22 16 env31694 = env31695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31694 == env31695) = true)

theorem identity31695 : scanCanonicalize (H12AffineFastState.compose env31695 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound31695 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138477,1024,32769,4160,4194304,16,21763,8328,65,4218144,5393,17664,56573,1501,4256860,256,21793,46213,63189]

theorem envBound31696 : H12AffineFastState.Bounded env31696 := by
  intro p hp
  have h : env31696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31695_31696 : H12AffineEnvironment.transform 15 54495 env31695 = env31696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env31695 == env31696) = true)

def env31697 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,138341,1024,32769,4160,4194304,16,21763,8192,65,4218144,5393,17664,56437,1365,4256860,256,21793,46093,63069]

theorem envBound31697 : H12AffineFastState.Bounded env31697 := by
  intro p hp
  have h : env31697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31696_31697 : H12AffineEnvironment.transform 6 8 env31696 = env31697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31696 == env31697) = true)

theorem identity31697 : scanCanonicalize (H12AffineFastState.compose env31697 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound31697 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31698 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,56437,1024,32769,4160,4194304,16,21763,8192,65,4218144,5393,17664,56437,1365,4256860,256,21793,46093,63069]

theorem envBound31698 : H12AffineFastState.Bounded env31698 := by
  intro p hp
  have h : env31698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31697_31698 : H12AffineEnvironment.transform 16 49168 env31697 = env31698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env31697 == env31698) = true)

theorem identity31698 : scanCanonicalize (H12AffineFastState.compose env31698 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 54640) := by decide +kernel

theorem selectedBound31698 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49168,56437,1024,32769,4160,54640,16,21763,8192,65,34896,5393,17664,56437,1365,8492,256,21793,46093,63069]

theorem envBound31699 : H12AffineFastState.Bounded env31699 := by
  intro p hp
  have h : env31699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31698_31699 : H12AffineEnvironment.transform 21 54640 env31698 = env31699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54640 env31698 == env31699) = true)

theorem identity31699 : scanCanonicalize (H12AffineFastState.compose env31699 (packedSelected [0,7,10,11,12,14,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound31699 : packedSelected [0,7,10,11,12,14,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30042,24861,32120,1024,8460,4160,29821,16,21763,8192,65,10589,5393,17664,32120,1365,8492,256,21793,5376,22352]

theorem envBound31700 : H12AffineFastState.Bounded env31700 := by
  intro p hp
  have h : env31700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31699_31700 : H12AffineEnvironment.transform 14 8461 env31699 = env31700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env31699 == env31700) = true)

theorem identity31700 : scanCanonicalize (H12AffineFastState.compose env31700 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound31700 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env31701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8461,263,5440,2341,1024,8460,4160,32,16,8542,8192,65,10589,5393,12637,2341,1365,8492,256,8572,5376,8973]

theorem envBound31701 : H12AffineFastState.Bounded env31701 := by
  intro p hp
  have h : env31701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31700_31701 : H12AffineEnvironment.transform 13 13405 env31700 = env31701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env31700 == env31701) = true)

theorem identity31701 : scanCanonicalize (H12AffineFastState.compose env31701 (packedSelected [1,2,4,7,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 624) := by decide +kernel

theorem selectedBound31701 : packedSelected [1,2,4,7,8,15] rootPS < 2^1333 := by decide +kernel

def env31702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,624,8192,9773,8461,263,1840,2341,1024,8460,560,32,16,8542,8192,65,10589,1889,9005,2341,1365,8492,256,8572,1904,8973]

theorem envBound31702 : H12AffineFastState.Bounded env31702 := by
  intro p hp
  have h : env31702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31701_31702 : H12AffineEnvironment.transform 11 624 env31701 = env31702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 624 env31701 == env31702) = true)

theorem identity31702 : scanCanonicalize (H12AffineFastState.compose env31702 (packedSelected [0,2,9,10,11,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31702 : packedSelected [0,2,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env31703 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,545,8192,9773,8461,263,1840,2341,1024,8460,560,32,16,8463,8192,16,10508,1840,9005,2341,1284,8492,256,8493,1825,8973]

theorem envBound31703 : H12AffineFastState.Bounded env31703 := by
  intro p hp
  have h : env31703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31702_31703 : H12AffineEnvironment.transform 5 17 env31702 = env31703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31702 == env31703) = true)

theorem identity31703 : scanCanonicalize (H12AffineFastState.compose env31703 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31703 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env31704 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,513,8192,9741,8461,263,1808,2309,1024,8460,528,0,16,8463,8192,16,10508,1808,8973,2309,1284,8460,256,8461,1793,8973]

theorem envBound31704 : H12AffineFastState.Bounded env31704 := by
  intro p hp
  have h : env31704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31703_31704 : H12AffineEnvironment.transform 4 0 env31703 = env31704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31703 == env31704) = true)

def env31705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138340,1024,32769,4160,4194304,16,21763,8193,65,4218144,5393,17664,56436,1364,4256860,256,21793,46092,63068]

theorem envBound31705 : H12AffineFastState.Bounded env31705 := by
  intro p hp
  have h : env31705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31696_31705 : H12AffineEnvironment.transform 6 9 env31696 = env31705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31696 == env31705) = true)

theorem identity31705 : scanCanonicalize (H12AffineFastState.compose env31705 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound31705 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,32041,1024,32769,4160,4194304,16,21763,8193,65,4218144,5393,17664,56436,1364,4256860,256,21793,46092,63068]

theorem envBound31706 : H12AffineFastState.Bounded env31706 := by
  intro p hp
  have h : env31706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31705_31706 : H12AffineEnvironment.transform 16 24909 env31705 = env31706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env31705 == env31706) = true)

theorem identity31706 : scanCanonicalize (H12AffineFastState.compose env31706 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31706 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,32041,1024,32769,4160,32,16,21763,8193,65,23808,5393,17664,56436,1364,62588,256,21793,46092,63068]

theorem envBound31707 : H12AffineFastState.Bounded env31707 := by
  intro p hp
  have h : env31707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31706_31707 : H12AffineEnvironment.transform 21 32 env31706 = env31707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31706 == env31707) = true)

theorem identity31707 : scanCanonicalize (H12AffineFastState.compose env31707 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound31707 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env31708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,343,24909,32041,1024,21760,4160,32,16,21763,8193,65,23808,5393,17664,2421,1364,8573,256,21793,24845,9053]

theorem envBound31708 : H12AffineFastState.Bounded env31708 := by
  intro p hp
  have h : env31708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31707_31708 : H12AffineEnvironment.transform 14 21761 env31707 = env31708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env31707 == env31708) = true)

theorem identity31708 : scanCanonicalize (H12AffineFastState.compose env31708 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound31708 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,343,16401,23669,1024,21760,4160,32,16,21763,349,65,23808,5393,17664,2421,1364,33,256,21793,16465,513]

theorem envBound31709 : H12AffineFastState.Bounded env31709 := by
  intro p hp
  have h : env31709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31708_31709 : H12AffineEnvironment.transform 12 348 env31708 = env31709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env31708 == env31709) = true)

theorem identity31709 : scanCanonicalize (H12AffineFastState.compose env31709 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31709 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31710 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,262,16401,23588,1024,21760,4113,32,16,21763,268,16,23808,5393,17664,2340,1285,33,256,21793,16384,513]

theorem envBound31710 : H12AffineFastState.Bounded env31710 := by
  intro p hp
  have h : env31710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31709_31710 : H12AffineEnvironment.transform 5 17 env31709 = env31710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31709 == env31710) = true)

theorem identity31710 : scanCanonicalize (H12AffineFastState.compose env31710 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound31710 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env31711 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,512,269,16384,18177,262,16401,20004,1024,18176,529,32,16,18179,268,16,20224,1809,17664,2340,1285,33,256,18209,16384,513]

theorem envBound31711 : H12AffineFastState.Bounded env31711 := by
  intro p hp
  have h : env31711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31710_31711 : H12AffineEnvironment.transform 11 512 env31710 = env31711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env31710 == env31711) = true)

def env31712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,17,98780,8328,65,4295166,5393,17665,67619,1500,4256860,256,21792,46212,74251]

theorem envBound31712 : H12AffineFastState.Bounded env31712 := by
  intro p hp
  have h : env31712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31694_31712 : H12AffineEnvironment.transform 22 17 env31694 = env31712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31694 == env31712) = true)

theorem identity31712 : scanCanonicalize (H12AffineFastState.compose env31712 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201831) := by decide +kernel

theorem selectedBound31712 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,201831,17,98780,8328,65,171417,5393,17665,67619,1500,254011,256,21792,46212,74251]

theorem envBound31713 : H12AffineFastState.Bounded env31713 := by
  intro p hp
  have h : env31713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31712_31713 : H12AffineEnvironment.transform 21 201831 env31712 = env31713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201831 env31712 == env31713) = true)

def env31714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,201831,17,98644,8192,65,171281,5393,17665,67619,1364,254011,256,21792,46092,74251]

theorem envBound31714 : H12AffineFastState.Bounded env31714 := by
  intro p hp
  have h : env31714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31713_31714 : H12AffineEnvironment.transform 6 8 env31713 = env31714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31713 == env31714) = true)

theorem identity31714 : scanCanonicalize (H12AffineFastState.compose env31714 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31714 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,144493,17,41310,8192,65,171281,5393,17665,10281,1364,180273,256,21792,46092,513]

end H12CloudChart1