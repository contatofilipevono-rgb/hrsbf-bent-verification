import H12CloudChart1Data220

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans55959_55960 : H12AffineEnvironment.transform 6 89 env55959 = env55960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55959 == env55960) = true)

theorem identity55960 : scanCanonicalize (H12AffineFastState.compose env55960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55961 : List Nat := [2,4,8,16,32,64,89,116,512,52,2048,4096,41,4113,81,35,4096,2049,53,80,4160,112,64,83,120,64,2049,4096,4096,2048,69,33,117,113,4113,513]

theorem envBound55961 : H12AffineFastState.Bounded env55961 := by
  intro p hp
  have h : env55961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55960_55961 : H12AffineEnvironment.transform 7 116 env55960 = env55961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55960 == env55961) = true)

theorem identity55961 : scanCanonicalize (H12AffineFastState.compose env55961 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55961 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55962 : List Nat := [2,4,8,16,32,64,89,116,512,52,0,4096,41,4113,81,35,4096,1,53,80,4160,112,64,83,120,64,1,4096,4096,0,69,33,117,113,4113,513]

theorem envBound55962 : H12AffineFastState.Bounded env55962 := by
  intro p hp
  have h : env55962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55961_55962 : H12AffineEnvironment.transform 10 0 env55961 = env55962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55961 == env55962) = true)

theorem identity55962 : scanCanonicalize (H12AffineFastState.compose env55962 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound55962 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55963 : List Nat := [2,4,8,16,32,64,89,116,512,52,0,17,41,0,81,35,17,1,53,80,81,112,64,83,120,64,1,17,17,0,69,33,117,113,0,513]

theorem envBound55963 : H12AffineFastState.Bounded env55963 := by
  intro p hp
  have h : env55963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55962_55963 : H12AffineEnvironment.transform 11 17 env55962 = env55963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env55962 == env55963) = true)

theorem identity55963 : scanCanonicalize (H12AffineFastState.compose env55963 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55963 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55964 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,17,41,0,1,35,17,1,53,0,1,32,16,3,40,16,1,17,17,0,21,33,37,33,0,513]

theorem envBound55964 : H12AffineFastState.Bounded env55964 := by
  intro p hp
  have h : env55964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55963_55964 : H12AffineEnvironment.transform 5 16 env55963 = env55964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55963 == env55964) = true)

theorem identity55964 : scanCanonicalize (H12AffineFastState.compose env55964 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55965 : List Nat := [2,4,8,16,32,16,9,36,17,52,0,17,41,0,1,35,17,1,53,0,1,32,16,3,40,16,1,17,17,0,21,33,37,33,0,16]

theorem envBound55965 : H12AffineFastState.Bounded env55965 := by
  intro p hp
  have h : env55965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55964_55965 : H12AffineEnvironment.transform 8 17 env55964 = env55965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55964 == env55965) = true)

theorem identity55965 : scanCanonicalize (H12AffineFastState.compose env55965 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound55965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55966 : List Nat := [2,4,8,16,27,16,9,31,17,15,0,17,18,0,1,24,17,1,14,0,1,27,16,3,19,16,1,17,17,0,21,26,30,26,0,16]

theorem envBound55966 : H12AffineFastState.Bounded env55966 := by
  intro p hp
  have h : env55966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55965_55966 : H12AffineEnvironment.transform 4 27 env55965 = env55966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env55965 == env55966) = true)

def env55967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,168,62660,21762,8328,64,121942,115150,45525,35325,75222,73770,257,95530,103566,513]

theorem envBound55967 : H12AffineFastState.Bounded env55967 := by
  intro p hp
  have h : env55967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55953_55967 : H12AffineEnvironment.transform 17 10281 env55953 = env55967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55953 == env55967) = true)

theorem identity55967 : scanCanonicalize (H12AffineFastState.compose env55967 (packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound55967 : packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env55968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,32768,65536,38161,10281,1025,32769,4160,168,41245,219,8328,64,100751,103447,45525,35325,75222,73770,257,73971,103566,513]

theorem envBound55968 : H12AffineFastState.Bounded env55968 := by
  intro p hp
  have h : env55968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55967_55968 : H12AffineEnvironment.transform 13 5593 env55967 = env55968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env55967 == env55968) = true)

theorem identity55968 : scanCanonicalize (H12AffineFastState.compose env55968 (packedSelected [0,2,4,5,6,9,11,17,19,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound55968 : packedSelected [0,2,4,5,6,9,11,17,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env55969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,32768,65536,38161,2477,1025,32769,4160,168,32921,219,268,64,100751,103447,36945,35325,66642,65966,257,65911,103566,513]

theorem envBound55969 : H12AffineFastState.Bounded env55969 := by
  intro p hp
  have h : env55969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55968_55969 : H12AffineEnvironment.transform 12 388 env55968 = env55969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env55968 == env55969) = true)

theorem identity55969 : scanCanonicalize (H12AffineFastState.compose env55969 (packedSelected [3,4,5,9,10,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55969 : packedSelected [3,4,5,9,10,14,17,20] rootPS < 2^1333 := by decide +kernel

def env55970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5593,32768,263,38161,2477,1025,32769,4160,168,32921,219,268,64,34952,38160,36945,35325,1365,169,257,112,38281,513]

theorem envBound55970 : H12AffineFastState.Bounded env55970 := by
  intro p hp
  have h : env55970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55969_55970 : H12AffineEnvironment.transform 15 263 env55969 = env55970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55969 == env55970) = true)

def env55971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,21763,8328,64,215367,115150,140485,303572,241862,498963,257,254011,197023,169745]

theorem envBound55971 : H12AffineFastState.Bounded env55971 := by
  intro p hp
  have h : env55971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55951_55971 : H12AffineEnvironment.transform 20 4161 env55951 = env55971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55951 == env55971) = true)

def env55972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169401,156117,21763,8328,64,215367,115150,140485,35324,241862,243003,257,254011,197023,169745]

theorem envBound55972 : H12AffineFastState.Bounded env55972 := by
  intro p hp
  have h : env55972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55971_55972 : H12AffineEnvironment.transform 17 10280 env55971 = env55972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55971 == env55972) = true)

def env55973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21929,41413,21763,8328,64,100695,115150,58581,35324,94422,95531,257,73771,115087,22273]

theorem envBound55973 : H12AffineFastState.Bounded env55973 := by
  intro p hp
  have h : env55973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55972_55973 : H12AffineEnvironment.transform 16 49168 env55972 = env55973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55972 == env55973) = true)

theorem identity55973 : scanCanonicalize (H12AffineFastState.compose env55973 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1025,8541,4161,21929,153,21763,8328,64,75787,90258,17801,10400,94422,95531,257,73771,90323,22273]

theorem envBound55974 : H12AffineFastState.Bounded env55974 := by
  intro p hp
  have h : env55974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55973_55974 : H12AffineEnvironment.transform 14 8540 env55973 = env55974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55973 == env55974) = true)

theorem identity55974 : scanCanonicalize (H12AffineFastState.compose env55974 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21875) := by decide +kernel

theorem selectedBound55974 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,21875,24908,10280,1025,8541,4161,21929,153,21763,8328,64,32120,13793,17801,10400,9637,8280,257,30040,13728,22273]

theorem envBound55975 : H12AffineFastState.Bounded env55975 := by
  intro p hp
  have h : env55975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55974_55975 : H12AffineEnvironment.transform 15 21875 env55974 = env55975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21875 env55974 == env55975) = true)

theorem identity55975 : scanCanonicalize (H12AffineFastState.compose env55975 (packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,16,20,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound55975 : packedSelected [1,2,3,4,5,6,7,8,10,11,12,14,15,16,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env55976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,16384,1297,21875,17665,3173,1025,1296,4161,21929,153,21763,1221,64,22837,4524,17801,3309,488,1045,257,20757,4589,22273]

theorem envBound55976 : H12AffineFastState.Bounded env55976 := by
  intro p hp
  have h : env55976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55975_55976 : H12AffineEnvironment.transform 12 1101 env55975 = env55976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env55975 == env55976) = true)

theorem identity55976 : scanCanonicalize (H12AffineFastState.compose env55976 (packedSelected [1,2,6,8,9,14,18,19,22,23] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound55976 : packedSelected [1,2,6,8,9,14,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env55977 : List Nat := [2,4,8,16,32,64,128,256,512,456,2048,4096,389,16384,217,20667,16585,2477,457,216,4161,20577,153,20683,269,64,22837,4524,16449,2341,488,477,257,20757,4589,21193]

theorem envBound55977 : H12AffineFastState.Bounded env55977 := by
  intro p hp
  have h : env55977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55976_55977 : H12AffineEnvironment.transform 9 456 env55976 = env55977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env55976 == env55977) = true)

theorem identity55977 : scanCanonicalize (H12AffineFastState.compose env55977 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55977 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55978 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,4096,160,16384,217,20667,16585,2184,236,216,4161,20577,153,20683,40,64,22544,4233,16449,2048,205,248,36,20528,4296,21193]

theorem envBound55978 : H12AffineFastState.Bounded env55978 := by
  intro p hp
  have h : env55978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55977_55978 : H12AffineEnvironment.transform 7 37 env55977 = env55978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55977 == env55978) = true)

theorem identity55978 : scanCanonicalize (H12AffineFastState.compose env55978 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound55978 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55979 : List Nat := [2,4,8,16,32,64,128,37,512,237,2048,4096,160,4161,217,250,4232,2184,236,216,4161,32,153,138,40,64,2129,4233,4096,2048,205,248,36,113,4296,648]

theorem envBound55979 : H12AffineFastState.Bounded env55979 := by
  intro p hp
  have h : env55979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55978_55979 : H12AffineEnvironment.transform 13 4161 env55978 = env55979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env55978 == env55979) = true)

theorem identity55979 : scanCanonicalize (H12AffineFastState.compose env55979 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55979 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55980 : List Nat := [2,4,8,16,32,17,128,37,512,188,2048,4096,160,4112,136,171,4232,2184,189,137,4112,32,153,138,40,17,2048,4233,4096,2048,156,169,36,32,4249,648]

theorem envBound55980 : H12AffineFastState.Bounded env55980 := by
  intro p hp
  have h : env55980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55979_55980 : H12AffineEnvironment.transform 5 17 env55979 = env55980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55979 == env55980) = true)

theorem identity55980 : scanCanonicalize (H12AffineFastState.compose env55980 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55980 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55981 : List Nat := [2,4,8,16,11,17,128,14,512,151,2048,4096,139,4112,136,128,4232,2184,150,137,4112,11,153,138,3,17,2048,4233,4096,2048,156,130,15,11,4249,648]

theorem envBound55981 : H12AffineFastState.Bounded env55981 := by
  intro p hp
  have h : env55981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55980_55981 : H12AffineEnvironment.transform 4 11 env55980 = env55981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55980 == env55981) = true)

theorem identity55981 : scanCanonicalize (H12AffineFastState.compose env55981 (packedSelected [3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 28) := by decide +kernel

theorem selectedBound55981 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env55982 : List Nat := [2,4,8,16,11,17,28,14,512,11,2048,4096,23,4112,20,28,4116,2068,10,21,4112,11,5,22,3,17,2048,4117,4096,2048,0,30,15,11,4101,532]

theorem envBound55982 : H12AffineFastState.Bounded env55982 := by
  intro p hp
  have h : env55982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55981_55982 : H12AffineEnvironment.transform 6 28 env55981 = env55982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 28 env55981 == env55982) = true)

theorem identity55982 : scanCanonicalize (H12AffineFastState.compose env55982 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 534) := by decide +kernel

theorem selectedBound55982 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55983 : List Nat := [2,4,8,16,11,17,28,14,512,11,2048,534,23,518,20,28,514,2068,10,21,518,11,5,22,3,17,2048,515,534,2048,0,30,15,11,531,532]

theorem envBound55983 : H12AffineFastState.Bounded env55983 := by
  intro p hp
  have h : env55983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55982_55983 : H12AffineEnvironment.transform 11 534 env55982 = env55983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 534 env55982 == env55983) = true)

theorem identity55983 : scanCanonicalize (H12AffineFastState.compose env55983 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55983 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env55984 : List Nat := [2,4,6,16,5,17,18,0,512,5,2048,534,23,518,20,18,514,2068,4,21,518,5,5,22,3,17,2048,515,534,2048,0,16,1,5,531,532]

theorem envBound55984 : H12AffineFastState.Bounded env55984 := by
  intro p hp
  have h : env55984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55983_55984 : H12AffineEnvironment.transform 2 6 env55983 = env55984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55983 == env55984) = true)

theorem identity55984 : scanCanonicalize (H12AffineFastState.compose env55984 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound55984 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env55985 : List Nat := [2,4,6,16,5,17,18,0,512,5,16,534,23,518,20,18,514,4,4,21,518,5,5,22,3,17,16,515,534,16,0,16,1,5,531,532]

theorem envBound55985 : H12AffineFastState.Bounded env55985 := by
  intro p hp
  have h : env55985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55984_55985 : H12AffineEnvironment.transform 10 16 env55984 = env55985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env55984 == env55985) = true)

theorem identity55985 : scanCanonicalize (H12AffineFastState.compose env55985 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound55985 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55986 : List Nat := [2,4,6,16,5,17,18,0,18,5,16,4,23,20,20,18,16,4,4,21,20,5,5,22,3,17,16,17,4,16,0,16,1,5,1,6]

theorem envBound55986 : H12AffineFastState.Bounded env55986 := by
  intro p hp
  have h : env55986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55985_55986 : H12AffineEnvironment.transform 8 18 env55985 = env55986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env55985 == env55986) = true)

theorem identity55986 : scanCanonicalize (H12AffineFastState.compose env55986 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55986 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55987 : List Nat := [2,4,6,0,5,1,2,0,2,5,0,4,7,4,4,2,0,4,4,5,4,5,5,6,3,1,0,1,4,0,0,0,1,5,1,6]

theorem envBound55987 : H12AffineFastState.Bounded env55987 := by
  intro p hp
  have h : env55987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55986_55987 : H12AffineEnvironment.transform 3 0 env55986 = env55987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55986 == env55987) = true)

theorem identity55987 : scanCanonicalize (H12AffineFastState.compose env55987 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55988 : List Nat := [2,1,3,0,0,1,2,0,2,0,0,1,2,1,1,2,0,1,1,0,1,0,0,3,3,1,0,1,1,0,0,0,1,0,1,3]

theorem envBound55988 : H12AffineFastState.Bounded env55988 := by
  intro p hp
  have h : env55988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55987_55988 : H12AffineEnvironment.transform 1 1 env55987 = env55988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55987 == env55988) = true)

theorem identity55988 : scanCanonicalize (H12AffineFastState.compose env55988 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55988 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55989 : List Nat := [0,1,1,0,0,1,0,0,0,0,0,1,0,1,1,0,0,1,1,0,1,0,0,1,1,1,0,1,1,0,0,0,1,0,1,1]

theorem envBound55989 : H12AffineFastState.Bounded env55989 := by
  intro p hp
  have h : env55989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55988_55989 : H12AffineEnvironment.transform 0 0 env55988 = env55989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55988 == env55989) = true)

def env55990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21928,41412,21763,8328,64,100694,115150,58580,35324,94423,95530,257,73770,115086,22272]

theorem envBound55990 : H12AffineFastState.Bounded env55990 := by
  intro p hp
  have h : env55990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55972_55990 : H12AffineEnvironment.transform 16 49169 env55972 = env55990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55972 == env55990) = true)

theorem identity55990 : scanCanonicalize (H12AffineFastState.compose env55990 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound55990 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1025,8661,4161,21928,16,21763,8328,64,75906,90138,17664,10280,94423,95530,257,73770,90202,22272]

theorem envBound55991 : H12AffineFastState.Bounded env55991 := by
  intro p hp
  have h : env55991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55990_55991 : H12AffineEnvironment.transform 14 8660 env55990 = env55991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env55990 == env55991) = true)

theorem identity55991 : scanCanonicalize (H12AffineFastState.compose env55991 (packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29943) := by decide +kernel

theorem selectedBound55991 : packedSelected [2,3,5,6,7,8,9,11,16,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env55992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29943,25029,10280,1025,8661,4161,21928,16,21763,8328,64,23669,5357,17664,10280,1056,477,257,21725,5293,22272]

theorem envBound55992 : H12AffineFastState.Bounded env55992 := by
  intro p hp
  have h : env55992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55991_55992 : H12AffineEnvironment.transform 15 29943 env55991 = env55992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29943 env55991 == env55992) = true)

theorem identity55992 : scanCanonicalize (H12AffineFastState.compose env55992 (packedSelected [0,1,2,3,6,8,10,11,12,14,15,16,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound55992 : packedSelected [0,1,2,3,6,8,10,11,12,14,15,16,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env55993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5293,8660,8282,13672,10280,1025,8661,4161,261,16,430,8328,64,2264,5357,4525,10280,1056,477,257,112,5293,941]

theorem envBound55993 : H12AffineFastState.Bounded env55993 := by
  intro p hp
  have h : env55993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55992_55993 : H12AffineEnvironment.transform 13 5293 env55992 = env55993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env55992 == env55993) = true)

theorem identity55993 : scanCanonicalize (H12AffineFastState.compose env55993 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound55993 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env55994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5293,1077,1467,4233,3529,1025,1076,4161,261,16,430,1385,64,2264,5357,4525,3529,1056,477,257,112,5293,941]

theorem envBound55994 : H12AffineFastState.Bounded env55994 := by
  intro p hp
  have h : env55994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55993_55994 : H12AffineEnvironment.transform 12 1505 env55993 = env55994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env55993 == env55994) = true)

theorem identity55994 : scanCanonicalize (H12AffineFastState.compose env55994 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55994 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env55995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5157,1077,1331,4097,3393,1025,1076,4161,261,16,294,1385,64,2128,5221,4389,3393,1056,341,257,112,5157,805]

theorem envBound55995 : H12AffineFastState.Bounded env55995 := by
  intro p hp
  have h : env55995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55994_55995 : H12AffineEnvironment.transform 6 8 env55994 = env55995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55994 == env55995) = true)

theorem identity55995 : scanCanonicalize (H12AffineFastState.compose env55995 (packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55995 : packedSelected [0,1,2,6,7,8,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55996 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1052,5157,1077,1094,4097,3124,1025,1076,4161,112,16,83,1052,64,2128,5221,4176,3124,1056,32,116,112,5157,592]

theorem envBound55996 : H12AffineFastState.Bounded env55996 := by
  intro p hp
  have h : env55996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55995_55996 : H12AffineEnvironment.transform 7 117 env55995 = env55996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55995 == env55996) = true)

theorem identity55996 : scanCanonicalize (H12AffineFastState.compose env55996 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound55996 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env55997 : List Nat := [2,4,8,16,32,64,8,117,512,68,2048,4096,88,4193,113,2,4097,2160,69,112,4161,112,16,83,88,64,2128,4129,4176,2160,100,32,116,112,4193,592]

theorem envBound55997 : H12AffineFastState.Bounded env55997 := by
  intro p hp
  have h : env55997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55996_55997 : H12AffineEnvironment.transform 9 68 env55996 = env55997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env55996 == env55997) = true)

theorem identity55997 : scanCanonicalize (H12AffineFastState.compose env55997 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound55997 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55998 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,4096,41,4112,0,2,4097,2049,52,1,4144,1,16,34,41,49,2081,4129,4129,2049,21,32,5,1,4112,545]

theorem envBound55998 : H12AffineFastState.Bounded env55998 := by
  intro p hp
  have h : env55998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55997_55998 : H12AffineEnvironment.transform 5 49 env55997 = env55998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env55997 == env55998) = true)

theorem identity55998 : scanCanonicalize (H12AffineFastState.compose env55998 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound55998 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55999 : List Nat := [2,4,8,16,32,49,8,4,512,53,2048,513,41,529,0,2,512,2049,52,1,561,1,16,34,41,49,2081,544,544,2049,21,32,5,1,529,545]

theorem envBound55999 : H12AffineFastState.Bounded env55999 := by
  intro p hp
  have h : env55999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55998_55999 : H12AffineEnvironment.transform 11 513 env55998 = env55999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env55998 == env55999) = true)

theorem identity55999 : scanCanonicalize (H12AffineFastState.compose env55999 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound55999 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56000 : List Nat := [2,4,8,16,32,49,8,4,512,53,522,513,41,529,0,2,512,523,52,1,561,1,16,34,41,49,555,544,544,523,21,32,5,1,529,545]

theorem envBound56000 : H12AffineFastState.Bounded env56000 := by
  intro p hp
  have h : env56000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55999_56000 : H12AffineEnvironment.transform 10 522 env55999 = env56000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env55999 == env56000) = true)

theorem identity56000 : scanCanonicalize (H12AffineFastState.compose env56000 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound56000 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env56001 : List Nat := [2,4,8,16,32,49,8,4,15,53,5,14,41,30,0,2,15,4,52,1,62,1,16,34,41,49,36,47,47,4,21,32,5,1,30,46]

theorem envBound56001 : H12AffineFastState.Bounded env56001 := by
  intro p hp
  have h : env56001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56000_56001 : H12AffineEnvironment.transform 8 15 env56000 = env56001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env56000 == env56001) = true)

theorem identity56001 : scanCanonicalize (H12AffineFastState.compose env56001 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound56001 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56002 : List Nat := [2,4,8,16,9,24,8,4,15,28,5,14,0,30,0,2,15,4,29,1,23,1,16,11,0,24,13,6,6,4,21,9,5,1,30,7]

theorem envBound56002 : H12AffineFastState.Bounded env56002 := by
  intro p hp
  have h : env56002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56001_56002 : H12AffineEnvironment.transform 4 9 env56001 = env56002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env56001 == env56002) = true)

theorem identity56002 : scanCanonicalize (H12AffineFastState.compose env56002 (packedSelected [0,4,11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56002 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env56003 : List Nat := [2,4,8,1,9,9,8,4,15,13,5,14,0,15,0,2,15,4,12,1,6,1,1,11,0,9,13,6,6,4,4,9,5,1,15,7]

theorem envBound56003 : H12AffineFastState.Bounded env56003 := by
  intro p hp
  have h : env56003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56002_56003 : H12AffineEnvironment.transform 3 1 env56002 = env56003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56002 == env56003) = true)

theorem identity56003 : scanCanonicalize (H12AffineFastState.compose env56003 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound56003 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56004 : List Nat := [2,4,7,1,6,6,7,4,0,2,5,1,0,0,0,2,0,4,3,1,6,1,1,4,0,6,2,6,6,4,4,6,5,1,0,7]

theorem envBound56004 : H12AffineFastState.Bounded env56004 := by
  intro p hp
  have h : env56004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56003_56004 : H12AffineEnvironment.transform 2 7 env56003 = env56004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env56003 == env56004) = true)

theorem identity56004 : scanCanonicalize (H12AffineFastState.compose env56004 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56005 : List Nat := [2,0,3,1,2,2,3,0,0,2,1,1,0,0,0,2,0,0,3,1,2,1,1,0,0,2,2,2,2,0,0,2,1,1,0,3]

theorem envBound56005 : H12AffineFastState.Bounded env56005 := by
  intro p hp
  have h : env56005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56004_56005 : H12AffineEnvironment.transform 1 0 env56004 = env56005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56004 == env56005) = true)

def env56006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169400,156117,21763,8328,64,215367,115150,140485,35325,241862,243002,257,254011,197023,169745]

theorem envBound56006 : H12AffineFastState.Bounded env56006 := by
  intro p hp
  have h : env56006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55971_56006 : H12AffineEnvironment.transform 17 10281 env55971 = env56006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55971 == env56006) = true)

def env56007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21928,41413,21763,8328,64,100695,115150,58581,35325,94422,95530,257,73771,115087,22273]

theorem envBound56007 : H12AffineFastState.Bounded env56007 := by
  intro p hp
  have h : env56007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56006_56007 : H12AffineEnvironment.transform 16 49168 env56006 = env56007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env56006 == env56007) = true)

theorem identity56007 : scanCanonicalize (H12AffineFastState.compose env56007 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56007 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21793,41292,21763,8193,64,100695,115015,58460,35188,94303,95530,257,73771,114950,22273]

theorem envBound56008 : H12AffineFastState.Bounded env56008 := by
  intro p hp
  have h : env56008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56007_56008 : H12AffineEnvironment.transform 6 9 env56007 = env56008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56007 == env56008) = true)

theorem identity56008 : scanCanonicalize (H12AffineFastState.compose env56008 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound56008 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,65536,5440,10281,1025,21841,4161,21793,29724,21763,8193,64,89095,70679,12556,23588,94303,95530,257,73771,70742,22273]

theorem envBound56009 : H12AffineFastState.Bounded env56009 := by
  intro p hp
  have h : env56009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56008_56009 : H12AffineEnvironment.transform 14 21840 env56008 = env56009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env56008 == env56009) = true)

theorem identity56009 : scanCanonicalize (H12AffineFastState.compose env56009 (packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound56009 : packedSelected [0,2,3,6,7,10,11,16,18,19,24] rootPS < 2^1333 := by decide +kernel

def env56010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,263,5440,10281,1025,21841,4161,21793,29724,21763,8193,64,23808,5392,12556,23588,29016,29741,257,8492,5457,22273]

theorem envBound56010 : H12AffineFastState.Bounded env56010 := by
  intro p hp
  have h : env56010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56009_56010 : H12AffineEnvironment.transform 15 263 env56009 = env56010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env56009 == env56010) = true)

theorem identity56010 : scanCanonicalize (H12AffineFastState.compose env56010 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound56010 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8461,263,5440,10281,1025,8460,4161,8572,65,8542,8193,64,10589,5392,12556,10361,1285,112,257,8492,5457,9052]

theorem envBound56011 : H12AffineFastState.Bounded env56011 := by
  intro p hp
  have h : env56011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56010_56011 : H12AffineEnvironment.transform 13 13405 env56010 = env56011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env56010 == env56011) = true)

theorem identity56011 : scanCanonicalize (H12AffineFastState.compose env56011 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56011 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,0,263,5440,2340,1025,1,4161,113,65,83,268,64,2128,5392,4097,2420,1285,112,257,33,5457,593]

theorem envBound56012 : H12AffineFastState.Bounded env56012 := by
  intro p hp
  have h : env56012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56011_56012 : H12AffineEnvironment.transform 12 269 env56011 = env56012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56011 == env56012) = true)

theorem identity56012 : scanCanonicalize (H12AffineFastState.compose env56012 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56012 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56013 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5157,0,114,5173,2129,1025,1,4161,113,65,83,121,64,2128,5221,4097,2049,1136,112,116,33,5156,593]

theorem envBound56013 : H12AffineFastState.Bounded env56013 := by
  intro p hp
  have h : env56013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56012_56013 : H12AffineEnvironment.transform 7 117 env56012 = env56013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56012 == env56013) = true)

def env56014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21929,41412,21763,8328,64,100694,115150,58580,35325,94423,95531,257,73770,115086,22272]

theorem envBound56014 : H12AffineFastState.Bounded env56014 := by
  intro p hp
  have h : env56014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56006_56014 : H12AffineEnvironment.transform 16 49169 env56006 = env56014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env56006 == env56014) = true)

theorem identity56014 : scanCanonicalize (H12AffineFastState.compose env56014 (packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound56014 : packedSelected [0,1,2,3,5,6,7,11,14,15,18,20,26,28,35,38] rootPS < 2^1333 := by decide +kernel

def env56015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21727,49169,10281,1025,32769,4161,21929,41412,21763,8328,64,56713,38161,58580,35325,9224,8692,257,29941,38225,22272]

theorem envBound56015 : H12AffineFastState.Bounded env56015 := by
  intro p hp
  have h : env56015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56014_56015 : H12AffineEnvironment.transform 15 21727 env56014 = env56015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env56014 == env56015) = true)

theorem identity56015 : scanCanonicalize (H12AffineFastState.compose env56015 (packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56015 : packedSelected [2,5,6,7,9,20,22,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env56016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,478,38160,10281,1025,32769,4161,168,41412,2,8328,64,34952,38161,45525,35325,9224,8692,257,8692,38225,513]

theorem envBound56016 : H12AffineFastState.Bounded env56016 := by
  intro p hp
  have h : env56016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56015_56016 : H12AffineEnvironment.transform 13 5377 env56015 = env56016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56015 == env56016) = true)

theorem identity56016 : scanCanonicalize (H12AffineFastState.compose env56016 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound56016 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env56017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,136,478,5528,10281,1025,137,4161,168,8524,2,8328,64,2048,5529,12637,2421,9224,8692,257,8692,5593,513]

theorem envBound56017 : H12AffineFastState.Bounded env56017 := by
  intro p hp
  have h : env56017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56016_56017 : H12AffineEnvironment.transform 14 136 env56016 = env56017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env56016 == env56017) = true)

theorem identity56017 : scanCanonicalize (H12AffineFastState.compose env56017 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56017 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,343,5393,10281,1025,0,4161,33,8524,2,8193,64,2048,5392,12637,2421,9224,8573,257,8573,5456,513]

theorem envBound56018 : H12AffineFastState.Bounded env56018 := by
  intro p hp
  have h : env56018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56017_56018 : H12AffineEnvironment.transform 6 9 env56017 = env56018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56017 == env56018) = true)

theorem identity56018 : scanCanonicalize (H12AffineFastState.compose env56018 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56018 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,1,343,5393,2341,1025,0,4161,33,64,2,269,64,2048,5392,4177,2421,1284,113,257,113,5456,513]

theorem envBound56019 : H12AffineFastState.Bounded env56019 := by
  intro p hp
  have h : env56019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56018_56019 : H12AffineEnvironment.transform 12 268 env56018 = env56019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56018 == env56019) = true)

theorem identity56019 : scanCanonicalize (H12AffineFastState.compose env56019 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound56019 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env56020 : List Nat := [2,4,8,16,32,64,9,256,512,353,2048,4096,268,4192,1,343,4208,2341,352,0,4161,33,64,2,269,64,2048,4209,4177,2421,101,113,257,113,4145,513]

theorem envBound56020 : H12AffineFastState.Bounded env56020 := by
  intro p hp
  have h : env56020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56019_56020 : H12AffineEnvironment.transform 9 353 env56019 = env56020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env56019 == env56020) = true)

theorem identity56020 : scanCanonicalize (H12AffineFastState.compose env56020 (packedSelected [2,3,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56020 : packedSelected [2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env56021 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,4096,268,4145,1,262,4129,2341,305,0,4112,33,17,2,269,17,2048,4128,4096,2340,52,32,257,32,4145,513]

theorem envBound56021 : H12AffineFastState.Bounded env56021 := by
  intro p hp
  have h : env56021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56020_56021 : H12AffineEnvironment.transform 5 17 env56020 = env56021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56020 == env56021) = true)

theorem identity56021 : scanCanonicalize (H12AffineFastState.compose env56021 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2846) := by decide +kernel

theorem selectedBound56021 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56022 : List Nat := [2,4,8,16,32,17,9,256,512,304,2048,2846,268,2863,1,262,2879,2341,305,0,2830,33,17,2,269,17,2048,2878,2846,2340,52,32,257,32,2863,513]

theorem envBound56022 : H12AffineFastState.Bounded env56022 := by
  intro p hp
  have h : env56022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56021_56022 : H12AffineEnvironment.transform 11 2846 env56021 = env56022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2846 env56021 == env56022) = true)

theorem identity56022 : scanCanonicalize (H12AffineFastState.compose env56022 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound56022 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56023 : List Nat := [2,4,8,16,32,17,9,256,11,304,2048,2325,268,2340,1,262,2356,2341,305,0,2309,33,17,2,269,17,2048,2357,2325,2340,52,32,257,32,2340,10]

theorem envBound56023 : H12AffineFastState.Bounded env56023 := by
  intro p hp
  have h : env56023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56022_56023 : H12AffineEnvironment.transform 8 11 env56022 = env56023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env56022 == env56023) = true)

theorem identity56023 : scanCanonicalize (H12AffineFastState.compose env56023 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound56023 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56024 : List Nat := [2,4,8,16,32,17,9,256,11,304,33,308,268,261,1,262,277,260,305,0,292,33,17,2,269,17,33,276,308,261,52,32,257,32,261,10]

theorem envBound56024 : H12AffineFastState.Bounded env56024 := by
  intro p hp
  have h : env56024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56023_56024 : H12AffineEnvironment.transform 10 33 env56023 = env56024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env56023 == env56024) = true)

theorem identity56024 : scanCanonicalize (H12AffineFastState.compose env56024 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56024 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56025 : List Nat := [2,4,8,16,32,17,9,37,11,21,33,17,41,32,1,35,48,33,20,0,1,33,17,2,40,17,33,49,17,32,52,32,36,32,32,10]

theorem envBound56025 : H12AffineFastState.Bounded env56025 := by
  intro p hp
  have h : env56025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56024_56025 : H12AffineEnvironment.transform 7 37 env56024 = env56025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56024 == env56025) = true)

theorem identity56025 : scanCanonicalize (H12AffineFastState.compose env56025 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound56025 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56026 : List Nat := [2,4,7,16,32,17,6,37,4,21,33,17,38,32,1,35,48,33,20,0,1,33,17,2,39,17,33,49,17,32,52,32,36,32,32,5]

theorem envBound56026 : H12AffineFastState.Bounded env56026 := by
  intro p hp
  have h : env56026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56025_56026 : H12AffineEnvironment.transform 2 7 env56025 = env56026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env56025 == env56026) = true)

theorem identity56026 : scanCanonicalize (H12AffineFastState.compose env56026 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound56026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56027 : List Nat := [2,4,7,16,3,17,6,6,4,21,2,17,5,3,1,0,19,2,20,0,1,2,17,2,4,17,2,18,17,3,23,3,7,3,3,5]

theorem envBound56027 : H12AffineFastState.Bounded env56027 := by
  intro p hp
  have h : env56027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56026_56027 : H12AffineEnvironment.transform 4 3 env56026 = env56027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env56026 == env56027) = true)

def env56028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156117,2114882,8328,64,215366,115150,2241668,303572,2334855,2592083,257,254011,197023,2262864]

theorem envBound56028 : H12AffineFastState.Bounded env56028 := by
  intro p hp
  have h : env56028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55950_56028 : H12AffineEnvironment.transform 21 2534865 env55950 = env56028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env55950 == env56028) = true)

def env56029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,21762,8328,64,215366,115150,140484,303572,241863,498963,257,254011,197023,169744]

theorem envBound56029 : H12AffineFastState.Bounded env56029 := by
  intro p hp
  have h : env56029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56028_56029 : H12AffineEnvironment.transform 20 4160 env56028 = env56029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56028 == env56029) = true)

theorem identity56029 : scanCanonicalize (H12AffineFastState.compose env56029 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound56029 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,411972,156117,21762,8328,64,215366,79131,140484,283905,214034,485830,257,201966,197023,156613]

theorem envBound56030 : H12AffineFastState.Bounded env56030 := by
  intro p hp
  have h : env56030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56029_56030 : H12AffineEnvironment.transform 14 29909 env56029 = env56030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env56029 == env56030) = true)

def env56031 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,411924,156037,21762,8328,16,215318,79131,140436,283905,214034,485782,257,201918,197023,156565]

theorem envBound56031 : H12AffineFastState.Bounded env56031 := by
  intro p hp
  have h : env56031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56030_56031 : H12AffineEnvironment.transform 5 16 env56030 = env56031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56030 == env56031) = true)

theorem identity56031 : scanCanonicalize (H12AffineFastState.compose env56031 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound56031 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env56032 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24861,262144,1025,29828,4112,272393,152,21762,8328,16,75787,79131,17801,283905,75023,329867,257,95651,90242,648]

theorem envBound56032 : H12AffineFastState.Bounded env56032 := by
  intro p hp
  have h : env56032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56031_56032 : H12AffineEnvironment.transform 16 24861 env56031 = env56032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env56031 == env56032) = true)

theorem identity56032 : scanCanonicalize (H12AffineFastState.compose env56032 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56032 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env56033 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,65536,13340,262144,1025,8581,4112,272393,152,3,8328,16,75787,79131,4232,262144,75023,329867,257,73890,79235,648]

theorem envBound56033 : H12AffineFastState.Bounded env56033 := by
  intro p hp
  have h : env56033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56032_56033 : H12AffineEnvironment.transform 13 5377 env56032 = env56033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56032 == env56033) = true)

theorem identity56033 : scanCanonicalize (H12AffineFastState.compose env56033 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6558) := by decide +kernel

theorem selectedBound56033 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env56034 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,6558,13340,262144,1025,8581,4112,272393,152,3,8328,16,12693,11397,4232,262144,15505,266517,257,14652,11293,648]

theorem envBound56034 : H12AffineFastState.Bounded env56034 := by
  intro p hp
  have h : env56034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56033_56034 : H12AffineEnvironment.transform 15 6558 env56033 = env56034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6558 env56033 == env56034) = true)

theorem identity56034 : scanCanonicalize (H12AffineFastState.compose env56034 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound56034 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env56035 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,6558,13340,10400,1025,8581,4112,169,152,3,8328,16,12693,11397,4232,10400,15505,14773,257,14652,11293,648]

theorem envBound56035 : H12AffineFastState.Bounded env56035 := by
  intro p hp
  have h : env56035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56034_56035 : H12AffineEnvironment.transform 17 10400 env56034 = env56035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env56034 == env56035) = true)

theorem identity56035 : scanCanonicalize (H12AffineFastState.compose env56035 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56035 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env56036 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,6422,13340,10280,1025,8461,4112,33,16,3,8192,16,12573,11277,4096,10280,15385,14653,257,14652,11293,512]

theorem envBound56036 : H12AffineFastState.Bounded env56036 := by
  intro p hp
  have h : env56036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56035_56036 : H12AffineEnvironment.transform 6 8 env56035 = env56036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56035 == env56036) = true)

theorem identity56036 : scanCanonicalize (H12AffineFastState.compose env56036 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 6460) := by decide +kernel

theorem selectedBound56036 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56037 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,6460,5377,6192,6422,3360,4372,1025,6193,4112,33,16,3,6460,16,2081,5425,4096,4372,1317,1,257,0,5409,512]

theorem envBound56037 : H12AffineFastState.Bounded env56037 := by
  intro p hp
  have h : env56037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56036_56037 : H12AffineEnvironment.transform 12 6460 env56036 = env56037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6460 env56036 == env56037) = true)

theorem identity56037 : scanCanonicalize (H12AffineFastState.compose env56037 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56037 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56038 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,6200,5125,6192,6162,3108,4112,1025,6193,4112,33,16,3,6200,16,2081,5173,4096,4112,1057,1,5,0,5157,512]

theorem envBound56038 : H12AffineFastState.Bounded env56038 := by
  intro p hp
  have h : env56038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56037_56038 : H12AffineEnvironment.transform 7 4 env56037 = env56038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56037 == env56038) = true)

theorem identity56038 : scanCanonicalize (H12AffineFastState.compose env56038 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound56038 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env56039 : List Nat := [2,4,8,16,32,16,8,4,512,1024,33,4096,4121,5125,4113,4147,1029,4112,1025,4112,4112,33,16,3,4121,16,0,5173,4096,4112,1057,1,5,0,5157,512]

theorem envBound56039 : H12AffineFastState.Bounded env56039 := by
  intro p hp
  have h : env56039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56038_56039 : H12AffineEnvironment.transform 10 33 env56038 = env56039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env56038 == env56039) = true)

theorem identity56039 : scanCanonicalize (H12AffineFastState.compose env56039 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound56039 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env56040 : List Nat := [2,4,8,16,32,16,8,4,512,1024,33,48,41,1077,33,3,1029,32,1025,32,32,33,16,3,41,16,0,1029,48,32,1057,1,5,0,1045,512]

theorem envBound56040 : H12AffineFastState.Bounded env56040 := by
  intro p hp
  have h : env56040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56039_56040 : H12AffineEnvironment.transform 11 48 env56039 = env56040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env56039 == env56040) = true)

theorem identity56040 : scanCanonicalize (H12AffineFastState.compose env56040 (packedSelected [2,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56040 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env56041 : List Nat := [2,4,8,16,32,16,8,4,512,20,33,48,41,33,33,3,17,32,21,32,32,33,16,3,41,16,0,17,48,32,53,1,5,0,1,512]

theorem envBound56041 : H12AffineFastState.Bounded env56041 := by
  intro p hp
  have h : env56041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56040_56041 : H12AffineEnvironment.transform 9 20 env56040 = env56041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56040 == env56041) = true)

theorem identity56041 : scanCanonicalize (H12AffineFastState.compose env56041 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56041 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env56042 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,9,1,1,3,17,0,21,0,0,1,16,3,9,16,0,17,16,0,21,1,5,0,1,512]

theorem envBound56042 : H12AffineFastState.Bounded env56042 := by
  intro p hp
  have h : env56042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56041_56042 : H12AffineEnvironment.transform 4 0 env56041 = env56042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56041 == env56042) = true)

def env56043 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,411925,156036,21762,8328,17,215319,79131,140437,283905,214034,485783,257,201919,197023,156564]

theorem envBound56043 : H12AffineFastState.Bounded env56043 := by
  intro p hp
  have h : env56043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56030_56043 : H12AffineEnvironment.transform 5 17 env56030 = env56043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56030 == env56043) = true)

theorem identity56043 : scanCanonicalize (H12AffineFastState.compose env56043 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 149813) := by decide +kernel

theorem selectedBound56043 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env56044 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149813,1025,29829,4113,32,156036,21762,8328,17,215319,79131,140437,138292,214034,73890,257,201919,197023,156564]

theorem envBound56044 : H12AffineFastState.Bounded env56044 := by
  intro p hp
  have h : env56044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56043_56044 : H12AffineEnvironment.transform 17 149813 env56043 = env56044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149813 env56043 == env56044) = true)

theorem identity56044 : scanCanonicalize (H12AffineFastState.compose env56044 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound56044 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env56045 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8323,131072,149813,1025,29829,4113,32,156036,21762,8328,17,158100,5528,140437,138292,156817,33,257,144444,139548,156564]

theorem envBound56045 : H12AffineFastState.Bounded env56045 := by
  intro p hp
  have h : env56045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56044_56045 : H12AffineEnvironment.transform 15 8323 env56044 = env56045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env56044 == env56045) = true)

def env56046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,21763,8328,64,215366,115150,140485,303572,241862,498962,257,254011,197023,169745]

theorem envBound56046 : H12AffineFastState.Bounded env56046 := by
  intro p hp
  have h : env56046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56028_56046 : H12AffineEnvironment.transform 20 4161 env56028 = env56046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56028 == env56046) = true)

theorem identity56046 : scanCanonicalize (H12AffineFastState.compose env56046 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound56046 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,318548,17,21763,8328,64,75906,115150,17665,303572,119042,392406,257,98815,90203,63189]

theorem envBound56047 : H12AffineFastState.Bounded env56047 := by
  intro p hp
  have h : env56047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56046_56047 : H12AffineEnvironment.transform 16 25028 env56046 = env56047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env56046 == env56047) = true)

def env56048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,318548,17,21763,8192,64,75786,115014,17665,303452,119042,392286,257,98679,90203,63069]

theorem envBound56048 : H12AffineFastState.Bounded env56048 := by
  intro p hp
  have h : env56048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56047_56048 : H12AffineEnvironment.transform 6 8 env56047 = env56048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56047 == env56048) = true)

theorem identity56048 : scanCanonicalize (H12AffineFastState.compose env56048 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound56048 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4161,21792,17,21763,8192,64,75786,115014,17665,10280,119042,95530,257,98679,90203,63069]

theorem envBound56049 : H12AffineFastState.Bounded env56049 := by
  intro p hp
  have h : env56049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56048_56049 : H12AffineEnvironment.transform 17 35188 env56048 = env56049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env56048 == env56049) = true)

theorem identity56049 : scanCanonicalize (H12AffineFastState.compose env56049 (packedSelected [1,3,18,19,23,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound56049 : packedSelected [1,3,18,19,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env56050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,24908,35188,1025,32769,4161,21792,17,21763,8192,64,31836,38160,17665,10280,34132,8572,257,54561,13325,63069]

theorem envBound56050 : H12AffineFastState.Bounded env56050 := by
  intro p hp
  have h : env56050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56049_56050 : H12AffineEnvironment.transform 15 21590 env56049 = env56050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env56049 == env56050) = true)

theorem identity56050 : scanCanonicalize (H12AffineFastState.compose env56050 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56050 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21590,24908,10281,1025,8540,4161,21792,17,21763,8192,64,31836,13389,17665,10280,9225,8572,257,29820,13325,22272]

theorem envBound56051 : H12AffineFastState.Bounded env56051 := by
  intro p hp
  have h : env56051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56050_56051 : H12AffineEnvironment.transform 14 8541 env56050 = env56051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56050 == env56051) = true)

theorem identity56051 : scanCanonicalize (H12AffineFastState.compose env56051 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56051 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56052 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,21590,24633,10281,1025,8233,4161,21589,17,21622,8192,64,31836,13389,17524,10280,9225,8201,116,29820,13325,22133]

theorem envBound56052 : H12AffineFastState.Bounded env56052 := by
  intro p hp
  have h : env56052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56051_56052 : H12AffineEnvironment.transform 7 117 env56051 = env56052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56051 == env56052) = true)

theorem identity56052 : scanCanonicalize (H12AffineFastState.compose env56052 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound56052 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56053 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8232,34,13389,10281,1025,8233,4161,33,17,2,8192,64,10280,13389,4096,10280,9225,8201,116,8200,13325,513]

theorem envBound56053 : H12AffineFastState.Bounded env56053 := by
  intro p hp
  have h : env56053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56052_56053 : H12AffineEnvironment.transform 13 5236 env56052 = env56053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env56052 == env56053) = true)

theorem identity56053 : scanCanonicalize (H12AffineFastState.compose env56053 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound56053 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env56054 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1141,8192,1,8232,34,8248,10281,1025,8233,1076,33,17,2,8192,64,10280,8248,1141,10280,9225,8201,116,8200,8312,513]

theorem envBound56054 : H12AffineFastState.Bounded env56054 := by
  intro p hp
  have h : env56054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56053_56054 : H12AffineEnvironment.transform 11 1141 env56053 = env56054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env56053 == env56054) = true)

theorem identity56054 : scanCanonicalize (H12AffineFastState.compose env56054 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound56054 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env56055 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,1141,8192,1,8232,34,8248,8313,1025,8233,1076,33,17,2,8192,64,8312,8248,1141,8312,9225,8201,116,8200,8312,513]

theorem envBound56055 : H12AffineFastState.Bounded env56055 := by
  intro p hp
  have h : env56055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56054_56055 : H12AffineEnvironment.transform 10 80 env56054 = env56055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env56054 == env56055) = true)

theorem identity56055 : scanCanonicalize (H12AffineFastState.compose env56055 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound56055 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env56056 : List Nat := [2,4,8,16,32,64,8,117,512,1024,80,1141,120,1,80,34,64,1,1025,81,1076,33,17,2,120,64,0,64,1141,0,1137,113,116,112,0,513]

theorem envBound56056 : H12AffineFastState.Bounded env56056 := by
  intro p hp
  have h : env56056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56055_56056 : H12AffineEnvironment.transform 12 120 env56055 = env56056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env56055 == env56056) = true)

theorem identity56056 : scanCanonicalize (H12AffineFastState.compose env56056 (packedSelected [3,5,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound56056 : packedSelected [3,5,14] rootPS < 2^1333 := by decide +kernel

def env56057 : List Nat := [2,4,8,16,32,64,8,117,512,101,80,16,120,1,80,34,64,1,100,81,81,33,17,2,120,64,0,64,16,0,20,113,116,112,0,513]

theorem envBound56057 : H12AffineFastState.Bounded env56057 := by
  intro p hp
  have h : env56057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56056_56057 : H12AffineEnvironment.transform 9 101 env56056 = env56057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env56056 == env56057) = true)

theorem identity56057 : scanCanonicalize (H12AffineFastState.compose env56057 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56057 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56058 : List Nat := [2,4,8,16,32,64,8,117,1,101,80,16,120,1,80,34,64,1,100,81,81,33,17,2,120,64,0,64,16,0,20,113,116,112,0,0]

theorem envBound56058 : H12AffineFastState.Bounded env56058 := by
  intro p hp
  have h : env56058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56057_56058 : H12AffineEnvironment.transform 8 1 env56057 = env56058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56057 == env56058) = true)

theorem identity56058 : scanCanonicalize (H12AffineFastState.compose env56058 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56058 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56059 : List Nat := [2,4,8,16,32,17,8,36,1,52,1,16,41,1,1,34,17,1,53,0,0,33,17,2,41,17,0,17,16,0,20,32,37,33,0,0]

theorem envBound56059 : H12AffineFastState.Bounded env56059 := by
  intro p hp
  have h : env56059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56058_56059 : H12AffineEnvironment.transform 5 17 env56058 = env56059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56058 == env56059) = true)

def env56060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318548,17,21763,8193,64,75787,115015,17665,303453,119042,392287,257,98678,90203,63068]

theorem envBound56060 : H12AffineFastState.Bounded env56060 := by
  intro p hp
  have h : env56060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56047_56060 : H12AffineEnvironment.transform 6 9 env56047 = env56060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56047 == env56060) = true)

theorem identity56060 : scanCanonicalize (H12AffineFastState.compose env56060 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56060 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,4161,62589,17,21763,8193,64,75787,115015,17665,35188,119042,119926,257,98678,90203,63068]

theorem envBound56061 : H12AffineFastState.Bounded env56061 := by
  intro p hp
  have h : env56061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56060_56061 : H12AffineEnvironment.transform 17 10281 env56060 = env56061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56060 == env56061) = true)

theorem identity56061 : scanCanonicalize (H12AffineFastState.compose env56061 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56061 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,13389,10281,1025,32769,4161,41341,17,3,8193,64,75787,103495,4097,35188,99330,98678,257,98678,79195,41820]

theorem envBound56062 : H12AffineFastState.Bounded env56062 := by
  intro p hp
  have h : env56062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56061_56062 : H12AffineEnvironment.transform 13 5376 env56061 = env56062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56061 == env56062) = true)

theorem identity56062 : scanCanonicalize (H12AffineFastState.compose env56062 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56062 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,16,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env56063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,5393,2421,1025,32769,4161,32801,17,3,349,64,67927,103495,4097,35188,99330,98678,257,98678,70663,33280]

theorem envBound56063 : H12AffineFastState.Bounded env56063 := by
  intro p hp
  have h : env56063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56062_56063 : H12AffineEnvironment.transform 12 348 env56062 = env56063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56062 == env56063) = true)

theorem identity56063 : scanCanonicalize (H12AffineFastState.compose env56063 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound56063 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,5393,2421,1025,32769,4161,32801,17,3,349,64,2049,38161,4097,35188,34132,32800,257,32800,5457,33280]

theorem envBound56064 : H12AffineFastState.Bounded env56064 := by
  intro p hp
  have h : env56064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56063_56064 : H12AffineEnvironment.transform 15 342 env56063 = env56064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env56063 == env56064) = true)

theorem identity56064 : scanCanonicalize (H12AffineFastState.compose env56064 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound56064 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56065 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,32768,2,5189,2081,1025,32769,4161,32801,17,3,9,64,2049,37957,4097,34848,33792,32800,85,32800,5125,33280]

theorem envBound56065 : H12AffineFastState.Bounded env56065 := by
  intro p hp
  have h : env56065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56064_56065 : H12AffineEnvironment.transform 7 84 env56064 = env56065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env56064 == env56065) = true)

theorem identity56065 : scanCanonicalize (H12AffineFastState.compose env56065 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound56065 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env56066 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,81,2,5189,2081,1025,80,4161,112,17,3,9,64,2049,5140,4097,2161,1105,113,85,113,5125,593]

theorem envBound56066 : H12AffineFastState.Bounded env56066 := by
  intro p hp
  have h : env56066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56065_56066 : H12AffineEnvironment.transform 14 81 env56065 = env56066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env56065 == env56066) = true)

theorem identity56066 : scanCanonicalize (H12AffineFastState.compose env56066 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound56066 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env56067 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,2096,8,3172,81,2,3189,2081,1025,80,2161,112,17,3,9,64,2049,3108,2097,2161,1105,113,85,113,3125,593]

theorem envBound56067 : H12AffineFastState.Bounded env56067 := by
  intro p hp
  have h : env56067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56066_56067 : H12AffineEnvironment.transform 11 2096 env56066 = env56067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env56066 == env56067) = true)

theorem identity56067 : scanCanonicalize (H12AffineFastState.compose env56067 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound56067 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56068 : List Nat := [2,4,8,16,32,64,9,84,512,1024,113,65,8,1045,81,2,1028,80,1025,80,0,112,17,3,9,64,112,1109,64,0,1105,113,85,113,1092,593]

theorem envBound56068 : H12AffineFastState.Bounded env56068 := by
  intro p hp
  have h : env56068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56067_56068 : H12AffineEnvironment.transform 10 113 env56067 = env56068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env56067 == env56068) = true)

theorem identity56068 : scanCanonicalize (H12AffineFastState.compose env56068 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound56068 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env56069 : List Nat := [2,4,8,16,32,48,9,36,512,1024,1,49,8,1045,33,2,1028,32,1025,32,0,0,17,3,9,48,0,1061,48,0,1057,1,37,1,1076,545]

theorem envBound56069 : H12AffineFastState.Bounded env56069 := by
  intro p hp
  have h : env56069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56068_56069 : H12AffineEnvironment.transform 5 48 env56068 = env56069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56068 == env56069) = true)

theorem identity56069 : scanCanonicalize (H12AffineFastState.compose env56069 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56070 : List Nat := [2,4,8,16,0,16,9,4,512,1024,1,17,8,1045,1,2,1028,0,1025,0,0,0,17,3,9,16,0,1029,16,0,1025,1,5,1,1044,513]

theorem envBound56070 : H12AffineFastState.Bounded env56070 := by
  intro p hp
  have h : env56070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56069_56070 : H12AffineEnvironment.transform 4 0 env56069 = env56070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56069 == env56070) = true)

theorem identity56070 : scanCanonicalize (H12AffineFastState.compose env56070 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56070 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56071 : List Nat := [2,4,8,16,0,16,9,4,1,1024,1,17,8,1045,1,2,1028,0,1025,0,0,0,17,3,9,16,0,1029,16,0,1025,1,5,1,1044,0]

theorem envBound56071 : H12AffineFastState.Bounded env56071 := by
  intro p hp
  have h : env56071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56070_56071 : H12AffineEnvironment.transform 8 1 env56070 = env56071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56070 == env56071) = true)

theorem identity56071 : scanCanonicalize (H12AffineFastState.compose env56071 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56072 : List Nat := [2,4,8,0,0,0,9,4,1,1024,1,1,8,1029,1,2,1028,0,1025,0,0,0,1,3,9,0,0,1029,0,0,1025,1,5,1,1028,0]

theorem envBound56072 : H12AffineFastState.Bounded env56072 := by
  intro p hp
  have h : env56072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56071_56072 : H12AffineEnvironment.transform 3 0 env56071 = env56072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56071 == env56072) = true)

def env56073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound56073 : H12AffineFastState.Bounded env56073 := by
  intro p hp
  have h : env56073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55308_56073 : H12AffineEnvironment.transform 25 65 env55308 = env56073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env55308 == env56073) = true)

def env56074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound56074 : H12AffineFastState.Bounded env56074 := by
  intro p hp
  have h : env56074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56073_56074 : H12AffineEnvironment.transform 26 30393344 env56073 = env56074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env56073 == env56074) = true)

def env56075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound56075 : H12AffineFastState.Bounded env56075 := by
  intro p hp
  have h : env56075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56074_56075 : H12AffineEnvironment.transform 18 1024 env56074 = env56075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env56074 == env56075) = true)

theorem identity56075 : scanCanonicalize (H12AffineFastState.compose env56075 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 485878) := by decide +kernel

theorem selectedBound56075 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,485878,16777216,8328,65,21015030,18973837,2571430,109047,17231335,23160257,256,19311962,19287294,17287728]

theorem envBound56076 : H12AffineFastState.Bounded env56076 := by
  intro p hp
  have h : env56076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56075_56076 : H12AffineEnvironment.transform 22 485878 env56075 = env56076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 485878 env56075 == env56076) = true)

def env56077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156012,485878,16777216,8328,65,16959642,18973837,2571430,109047,17231335,19072173,256,19311962,19287294,17287728]

theorem envBound56077 : H12AffineFastState.Bounded env56077 := by
  intro p hp
  have h : env56077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56076_56077 : H12AffineEnvironment.transform 21 156012 env56076 = env56077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env56076 == env56077) = true)

def env56078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485878,16777216,8328,65,16959642,17246709,102878,109047,17231335,17148373,256,16777250,16834950,17287728]

theorem envBound56078 : H12AffineFastState.Bounded env56078 := by
  intro p hp
  have h : env56078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56077_56078 : H12AffineEnvironment.transform 20 437624 env56077 = env56078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env56077 == env56078) = true)

def env56079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485878,510000,8328,65,327850,57797,102878,109047,75223,156133,256,509970,469430,512]

theorem envBound56079 : H12AffineFastState.Bounded env56079 := by
  intro p hp
  have h : env56079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56078_56079 : H12AffineEnvironment.transform 23 510000 env56078 = env56079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510000 env56078 == env56079) = true)

theorem identity56079 : scanCanonicalize (H12AffineFastState.compose env56079 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound56079 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,156012,120015,95497,8328,65,245139,57797,102878,109047,75223,156133,256,95531,103567,512]

theorem envBound56080 : H12AffineFastState.Bounded env56080 := by
  intro p hp
  have h : env56080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56079_56080 : H12AffineEnvironment.transform 17 179513 env56079 = env56080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env56079 == env56080) = true)

theorem identity56080 : scanCanonicalize (H12AffineFastState.compose env56080 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound56080 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env56081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103631,76278,1024,32769,4161,128419,120015,95497,8328,65,10588,57797,102878,109047,75223,128298,256,95531,103567,512]

theorem envBound56081 : H12AffineFastState.Bounded env56081 := by
  intro p hp
  have h : env56081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56080_56081 : H12AffineEnvironment.transform 16 103631 env56080 = env56081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env56080 == env56081) = true)

theorem identity56081 : scanCanonicalize (H12AffineFastState.compose env56081 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound56081 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env56082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16401,64808,1024,32769,4161,8573,17,41431,8328,65,10588,57797,17664,32041,61705,8692,256,41461,16465,512]

theorem envBound56082 : H12AffineFastState.Bounded env56082 := by
  intro p hp
  have h : env56082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56081_56082 : H12AffineEnvironment.transform 15 54494 env56081 = env56082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env56081 == env56082) = true)

theorem identity56082 : scanCanonicalize (H12AffineFastState.compose env56082 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound56082 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,54494,16401,56576,1024,32769,4161,341,17,33279,160,65,2420,49645,17664,23809,53537,476,256,33245,16465,512]

theorem envBound56083 : H12AffineFastState.Bounded env56083 := by
  intro p hp
  have h : env56083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56082_56083 : H12AffineEnvironment.transform 12 40 env56082 = env56083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env56082 == env56083) = true)

theorem identity56083 : scanCanonicalize (H12AffineFastState.compose env56083 (packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound56083 : packedSelected [2,4,5,12,14,15,17,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env56084 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,16384,32768,54494,16401,56404,1024,32769,4161,1,17,32939,160,65,2080,49337,17492,23637,53365,136,84,32905,16465,512]

theorem envBound56084 : H12AffineFastState.Bounded env56084 := by
  intro p hp
  have h : env56084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56083_56084 : H12AffineEnvironment.transform 7 84 env56083 = env56084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env56083 == env56084) = true)

theorem identity56084 : scanCanonicalize (H12AffineFastState.compose env56084 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound56084 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env56085 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,40,16384,169,21623,16401,23805,1024,168,4161,1,17,2,160,65,2080,16400,17492,23637,20700,136,84,32,16465,512]

theorem envBound56085 : H12AffineFastState.Bounded env56085 := by
  intro p hp
  have h : env56085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56084_56085 : H12AffineEnvironment.transform 14 169 env56084 = env56085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env56084 == env56085) = true)

theorem identity56085 : scanCanonicalize (H12AffineFastState.compose env56085 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56085 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56086 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,40,16384,32,21623,16401,23668,1024,33,4161,1,17,2,41,65,2080,16400,17492,23637,20565,1,84,32,16465,512]

theorem envBound56086 : H12AffineFastState.Bounded env56086 := by
  intro p hp
  have h : env56086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56085_56086 : H12AffineEnvironment.transform 6 9 env56085 = env56086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56085 == env56086) = true)

theorem identity56086 : scanCanonicalize (H12AffineFastState.compose env56086 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56086 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56087 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,16384,32,21542,16401,23589,1024,33,4112,1,17,2,41,16,2080,16400,17413,23556,20484,1,5,32,16384,512]

theorem envBound56087 : H12AffineFastState.Bounded env56087 := by
  intro p hp
  have h : env56087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56086_56087 : H12AffineEnvironment.transform 5 17 env56086 = env56087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56086 == env56087) = true)

theorem identity56087 : scanCanonicalize (H12AffineFastState.compose env56087 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound56087 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56088 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,4096,40,5125,32,35,5140,2080,1024,33,4112,1,17,2,41,16,2080,5141,4096,2049,1025,1,5,32,5125,512]

theorem envBound56088 : H12AffineFastState.Bounded env56088 := by
  intro p hp
  have h : env56088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56087_56088 : H12AffineEnvironment.transform 13 5125 env56087 = env56088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env56087 == env56088) = true)

theorem identity56088 : scanCanonicalize (H12AffineFastState.compose env56088 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound56088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56089 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,1061,40,32,32,35,49,2080,1024,33,1077,1,17,2,41,16,2080,48,1061,2049,1025,1,5,32,32,512]

theorem envBound56089 : H12AffineFastState.Bounded env56089 := by
  intro p hp
  have h : env56089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56088_56089 : H12AffineEnvironment.transform 11 1061 env56088 = env56089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env56088 == env56089) = true)

theorem identity56089 : scanCanonicalize (H12AffineFastState.compose env56089 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 46) := by decide +kernel

theorem selectedBound56089 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env56090 : List Nat := [2,4,8,16,32,17,9,5,512,1024,46,1061,40,32,32,35,49,14,1024,33,1077,1,17,2,41,16,14,48,1061,47,1025,1,5,32,32,512]

theorem envBound56090 : H12AffineFastState.Bounded env56090 := by
  intro p hp
  have h : env56090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56089_56090 : H12AffineEnvironment.transform 10 46 env56089 = env56090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 46 env56089 == env56090) = true)

theorem identity56090 : scanCanonicalize (H12AffineFastState.compose env56090 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound56090 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56091 : List Nat := [2,4,8,16,32,17,9,5,36,1024,46,1061,40,32,32,35,49,14,1024,33,1077,1,17,2,41,16,14,48,1061,47,1025,1,5,32,32,36]

theorem envBound56091 : H12AffineFastState.Bounded env56091 := by
  intro p hp
  have h : env56091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56090_56091 : H12AffineEnvironment.transform 8 36 env56090 = env56091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env56090 == env56091) = true)

theorem identity56091 : scanCanonicalize (H12AffineFastState.compose env56091 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound56091 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56092 : List Nat := [2,4,8,16,14,17,9,5,10,1024,0,1035,6,14,14,13,31,14,1024,15,1051,1,17,2,7,16,14,30,1035,1,1025,1,5,14,14,10]

theorem envBound56092 : H12AffineFastState.Bounded env56092 := by
  intro p hp
  have h : env56092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56091_56092 : H12AffineEnvironment.transform 4 14 env56091 = env56092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env56091 == env56092) = true)

theorem identity56092 : scanCanonicalize (H12AffineFastState.compose env56092 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 13) := by decide +kernel

theorem selectedBound56092 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56093 : List Nat := [2,4,8,16,14,17,9,5,10,13,0,6,6,14,14,13,31,14,13,15,22,1,17,2,7,16,14,30,6,1,12,1,5,14,14,10]

theorem envBound56093 : H12AffineFastState.Bounded env56093 := by
  intro p hp
  have h : env56093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56092_56093 : H12AffineEnvironment.transform 9 13 env56092 = env56093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 13 env56092 == env56093) = true)

theorem identity56093 : scanCanonicalize (H12AffineFastState.compose env56093 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound56093 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env56094 : List Nat := [2,4,8,8,14,9,9,5,10,13,0,6,6,14,14,13,7,14,13,15,14,1,9,2,7,8,14,6,6,1,12,1,5,14,14,10]

theorem envBound56094 : H12AffineFastState.Bounded env56094 := by
  intro p hp
  have h : env56094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56093_56094 : H12AffineEnvironment.transform 3 8 env56093 = env56094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env56093 == env56094) = true)

theorem identity56094 : scanCanonicalize (H12AffineFastState.compose env56094 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound56094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56095 : List Nat := [2,4,7,7,1,6,6,5,5,2,0,6,6,1,1,2,7,1,2,0,1,1,6,2,7,7,1,6,6,1,3,1,5,1,1,5]

theorem envBound56095 : H12AffineFastState.Bounded env56095 := by
  intro p hp
  have h : env56095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56094_56095 : H12AffineEnvironment.transform 2 7 env56094 = env56095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env56094 == env56095) = true)

def env56096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485878,510001,8328,65,327851,57796,102878,109047,75222,156132,256,509971,469431,513]

theorem envBound56096 : H12AffineFastState.Bounded env56096 := by
  intro p hp
  have h : env56096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56078_56096 : H12AffineEnvironment.transform 23 510001 env56078 = env56096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env56078 == env56096) = true)

def env56097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485758,510001,8192,65,327715,57676,102742,108927,75102,156012,256,509971,469311,513]

theorem envBound56097 : H12AffineFastState.Bounded env56097 := by
  intro p hp
  have h : env56097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56096_56097 : H12AffineEnvironment.transform 6 8 env56096 = env56097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56096 == env56097) = true)

theorem identity56097 : scanCanonicalize (H12AffineFastState.compose env56097 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56097 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1024,32769,380258,65910,264548,305195,8192,65,327715,57676,102742,108927,75102,65910,256,305161,280869,513]

theorem envBound56098 : H12AffineFastState.Bounded env56098 := by
  intro p hp
  have h : env56098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56097_56098 : H12AffineEnvironment.transform 16 90138 env56097 = env56098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56097 == env56098) = true)

theorem identity56098 : scanCanonicalize (H12AffineFastState.compose env56098 (packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 4161) := by decide +kernel

theorem selectedBound56098 : packedSelected [0,1,4,5,8,9,11,15,17,18,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env56099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77915,262144,1024,32769,367907,65910,264548,305195,8192,65,327715,45325,102742,108927,75102,65910,256,305161,268644,513]

theorem envBound56099 : H12AffineFastState.Bounded env56099 := by
  intro p hp
  have h : env56099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56098_56099 : H12AffineEnvironment.transform 13 4161 env56098 = env56099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4161 env56098 == env56099) = true)

theorem identity56099 : scanCanonicalize (H12AffineFastState.compose env56099 (packedSelected [0,7,8,10,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound56099 : packedSelected [0,7,8,10,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env56100 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,65536,77915,67699,1024,32769,38224,65910,65815,106584,8192,65,2128,45325,102742,108927,75102,65910,256,106618,69911,513]

theorem envBound56100 : H12AffineFastState.Bounded env56100 := by
  intro p hp
  have h : env56100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56099_56100 : H12AffineEnvironment.transform 17 67699 env56099 = env56100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env56099 == env56100) = true)

theorem identity56100 : scanCanonicalize (H12AffineFastState.compose env56100 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound56100 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env56101 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,32768,33031,45404,35188,1024,32769,38224,32881,32784,8543,8192,65,2128,45325,4177,10360,42073,32881,256,8573,36880,513]

theorem envBound56101 : H12AffineFastState.Bounded env56101 := by
  intro p hp
  have h : env56101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56100_56101 : H12AffineEnvironment.transform 15 33031 env56100 = env56101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env56100 == env56101) = true)

theorem identity56101 : scanCanonicalize (H12AffineFastState.compose env56101 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56101 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env56102 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4161,1,262,12637,2421,1024,0,5457,112,17,8543,8192,65,2128,12556,4177,10360,9304,112,256,8573,4113,513]

theorem envBound56102 : H12AffineFastState.Bounded env56102 := by
  intro p hp
  have h : env56102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56101_56102 : H12AffineEnvironment.transform 14 1 env56101 = env56102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56101 == env56102) = true)

theorem identity56102 : scanCanonicalize (H12AffineFastState.compose env56102 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56102 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56103 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4161,1,262,4096,2421,1024,0,5457,112,17,2,349,65,2128,4177,4177,2341,1285,112,256,32,4113,513]

theorem envBound56103 : H12AffineFastState.Bounded env56103 := by
  intro p hp
  have h : env56103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56102_56103 : H12AffineEnvironment.transform 12 349 env56102 = env56103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56102 == env56103) = true)

theorem identity56103 : scanCanonicalize (H12AffineFastState.compose env56103 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56103 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56104 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4112,1,262,4096,2340,1024,0,5376,33,17,2,268,16,2049,4096,4096,2341,1285,33,256,32,4113,513]

theorem envBound56104 : H12AffineFastState.Bounded env56104 := by
  intro p hp
  have h : env56104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56103_56104 : H12AffineEnvironment.transform 5 17 env56103 = env56104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56103 == env56104) = true)

theorem identity56104 : scanCanonicalize (H12AffineFastState.compose env56104 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56105 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,1,262,4096,2340,272,0,4112,33,17,2,268,16,2049,4096,4096,2341,21,33,256,32,4113,513]

theorem envBound56105 : H12AffineFastState.Bounded env56105 := by
  intro p hp
  have h : env56105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56104_56105 : H12AffineEnvironment.transform 9 272 env56104 = env56105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56104 == env56105) = true)

def env56106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156012,485759,510001,8193,65,327714,57677,102743,108926,75103,156013,256,509971,469310,513]

theorem envBound56106 : H12AffineFastState.Bounded env56106 := by
  intro p hp
  have h : env56106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56096_56106 : H12AffineEnvironment.transform 6 9 env56096 = env56106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56096 == env56106) = true)

theorem identity56106 : scanCanonicalize (H12AffineFastState.compose env56106 (packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56106 : packedSelected [0,3,10,11,14,15,16,17,18,19,20,23,24,27,32,38] rootPS < 2^1333 := by decide +kernel

def env56107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,396324,156012,485759,485741,8193,65,327714,16401,77835,67618,75103,156013,256,485711,469310,513]

theorem envBound56107 : H12AffineFastState.Bounded env56107 := by
  intro p hp
  have h : env56107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56106_56107 : H12AffineEnvironment.transform 14 8540 env56106 = env56107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56106 == env56107) = true)

theorem identity56107 : scanCanonicalize (H12AffineFastState.compose env56107 (packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound56107 : packedSelected [1,3,7,14,16,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,215091,1024,8541,82967,156012,8524,8542,8193,65,149521,16401,77835,67618,75103,156013,256,8572,24845,513]

theorem envBound56108 : H12AffineFastState.Bounded env56108 := by
  intro p hp
  have h : env56108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56107_56108 : H12AffineEnvironment.transform 17 215091 env56107 = env56108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env56107 == env56108) = true)

theorem identity56108 : scanCanonicalize (H12AffineFastState.compose env56108 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56108 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env56109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90138,10281,1024,8541,82967,65910,8524,8542,8193,65,75787,16401,77835,67618,75103,65911,256,8572,24845,513]

theorem envBound56109 : H12AffineFastState.Bounded env56109 := by
  intro p hp
  have h : env56109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56108_56109 : H12AffineEnvironment.transform 16 90138 env56108 = env56109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56108 == env56109) = true)

theorem identity56109 : scanCanonicalize (H12AffineFastState.compose env56109 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56109 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56110 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,65536,82246,2421,1024,1,82967,65910,16,2,349,65,67927,16401,69975,67618,66563,65911,256,32,16465,513]

theorem envBound56110 : H12AffineFastState.Bounded env56110 := by
  intro p hp
  have h : env56110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56109_56110 : H12AffineEnvironment.transform 12 348 env56109 = env56110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56109 == env56110) = true)

def env56111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485878,16777216,8328,65,16959642,17246708,102879,109047,17231335,17148372,256,16777251,16834951,17287728]

theorem envBound56111 : H12AffineFastState.Bounded env56111 := by
  intro p hp
  have h : env56111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56077_56111 : H12AffineEnvironment.transform 20 437625 env56077 = env56111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env56077 == env56111) = true)

theorem identity56111 : scanCanonicalize (H12AffineFastState.compose env56111 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound56111 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env56112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156012,485878,188870,8328,65,10588,378930,102879,109047,265249,477202,256,188901,131137,338934]

theorem envBound56112 : H12AffineFastState.Bounded env56112 := by
  intro p hp
  have h : env56112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56111_56112 : H12AffineEnvironment.transform 23 188870 env56111 = env56112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env56111 == env56112) = true)

def env56113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,156012,120014,188870,8328,65,10588,226570,102879,109047,176409,128298,256,188901,131137,235214]

theorem envBound56113 : H12AffineFastState.Bounded env56113 := by
  intro p hp
  have h : env56113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56112_56113 : H12AffineEnvironment.transform 17 179512 env56112 = env56113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env56112 == env56113) = true)

theorem identity56113 : scanCanonicalize (H12AffineFastState.compose env56113 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56113 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4161,65910,120014,98780,8328,65,10588,5392,102879,109047,119043,128298,256,98815,90203,63188]

theorem envBound56114 : H12AffineFastState.Bounded env56114 := by
  intro p hp
  have h : env56114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56113_56114 : H12AffineEnvironment.transform 16 90138 env56113 = env56114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56113 == env56114) = true)

def env56115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4161,65910,119878,98644,8192,65,10588,5392,102743,108927,119043,128298,256,98679,90203,63068]

theorem envBound56115 : H12AffineFastState.Bounded env56115 := by
  intro p hp
  have h : env56115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56114_56115 : H12AffineEnvironment.transform 6 8 env56114 = env56115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56114 == env56115) = true)

theorem identity56115 : scanCanonicalize (H12AffineFastState.compose env56115 (packedSelected [4,5,9,12,15,16,19,24,35] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound56115 : packedSelected [4,5,9,12,15,16,19,24,35] rootPS < 2^1333 := by decide +kernel

def env56116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,71011,108635,1024,32769,4161,65910,106815,98644,8192,65,10588,5392,102743,108927,107642,98387,256,98679,70946,33573]

theorem envBound56116 : H12AffineFastState.Bounded env56116 := by
  intro p hp
  have h : env56116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56115_56116 : H12AffineEnvironment.transform 13 13689 env56115 = env56116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env56115 == env56116) = true)

theorem identity56116 : scanCanonicalize (H12AffineFastState.compose env56116 (packedSelected [5,11,12,15,16,17,19,20,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound56116 : packedSelected [5,11,12,15,16,17,19,20,24,32] rootPS < 2^1333 := by decide +kernel

def env56117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8460,65536,71011,67927,1024,8461,4161,65910,65587,73816,8192,65,10588,5392,77915,67699,66934,74079,256,73851,70946,8745]

theorem envBound56117 : H12AffineFastState.Bounded env56117 := by
  intro p hp
  have h : env56117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56116_56117 : H12AffineEnvironment.transform 14 8460 env56116 = env56117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env56116 == env56117) = true)

theorem identity56117 : scanCanonicalize (H12AffineFastState.compose env56117 (packedSelected [3,5,10,12,15,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56117 : packedSelected [3,5,10,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env56118 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,8460,8202,13673,10589,1024,8461,4161,8572,8249,82,8192,65,10588,5392,4177,10361,9596,341,256,113,13608,8745]

theorem envBound56118 : H12AffineFastState.Bounded env56118 := by
  intro p hp
  have h : env56118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56117_56118 : H12AffineEnvironment.transform 15 8202 env56117 = env56118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56117 == env56118) = true)

theorem identity56118 : scanCanonicalize (H12AffineFastState.compose env56118 (packedSelected [0,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound56118 : packedSelected [0,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56119 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4160,1077,1331,4176,3172,1024,1076,4161,1093,1280,82,1337,65,3173,5392,4177,3392,69,341,256,113,4113,1808]

theorem envBound56119 : H12AffineFastState.Bounded env56119 := by
  intro p hp
  have h : env56119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56118_56119 : H12AffineEnvironment.transform 12 1337 env56118 = env56119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env56118 == env56119) = true)

theorem identity56119 : scanCanonicalize (H12AffineFastState.compose env56119 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56119 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56120 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,269,4160,1,263,4176,2128,52,0,4161,113,308,82,269,65,2129,4388,4177,2420,69,341,256,113,4113,804]

theorem envBound56120 : H12AffineFastState.Bounded env56120 := by
  intro p hp
  have h : env56120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56119_56120 : H12AffineEnvironment.transform 9 52 env56119 = env56120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56119 == env56120) = true)

theorem identity56120 : scanCanonicalize (H12AffineFastState.compose env56120 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56121 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,121,4160,1,115,4176,2128,52,0,4161,113,64,82,121,65,2129,4176,4177,2048,69,33,116,113,4113,592]

theorem envBound56121 : H12AffineFastState.Bounded env56121 := by
  intro p hp
  have h : env56121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56120_56121 : H12AffineEnvironment.transform 7 116 env56120 = env56121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56120 == env56121) = true)

theorem identity56121 : scanCanonicalize (H12AffineFastState.compose env56121 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound56121 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56122 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,4096,121,4160,1,115,4176,0,52,0,4161,113,64,82,121,65,1,4176,4177,80,69,33,116,113,4113,592]

theorem envBound56122 : H12AffineFastState.Bounded env56122 := by
  intro p hp
  have h : env56122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56121_56122 : H12AffineEnvironment.transform 10 80 env56121 = env56122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env56121 == env56122) = true)

theorem identity56122 : scanCanonicalize (H12AffineFastState.compose env56122 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound56122 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56123 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,65,121,1,1,115,17,0,52,0,0,113,64,82,121,65,1,17,16,80,69,33,116,113,80,592]

theorem envBound56123 : H12AffineFastState.Bounded env56123 := by
  intro p hp
  have h : env56123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56122_56123 : H12AffineEnvironment.transform 11 65 env56122 = env56123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env56122 == env56123) = true)

theorem identity56123 : scanCanonicalize (H12AffineFastState.compose env56123 (packedSelected [6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56123 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env56124 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,17,41,1,1,35,17,0,52,0,0,33,16,2,41,17,1,17,16,0,21,33,36,33,0,512]

theorem envBound56124 : H12AffineFastState.Bounded env56124 := by
  intro p hp
  have h : env56124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56123_56124 : H12AffineEnvironment.transform 5 16 env56123 = env56124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56123 == env56124) = true)

theorem identity56124 : scanCanonicalize (H12AffineFastState.compose env56124 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound56124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56125 : List Nat := [2,4,8,16,32,16,8,36,52,52,0,17,41,1,1,35,17,0,52,0,0,33,16,2,41,17,1,17,16,0,21,33,36,33,0,52]

theorem envBound56125 : H12AffineFastState.Bounded env56125 := by
  intro p hp
  have h : env56125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56124_56125 : H12AffineEnvironment.transform 8 52 env56124 = env56125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env56124 == env56125) = true)

theorem identity56125 : scanCanonicalize (H12AffineFastState.compose env56125 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound56125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56126 : List Nat := [2,4,8,12,32,12,8,36,40,40,0,13,41,1,1,35,13,0,40,0,0,33,12,2,41,13,1,13,12,0,9,33,36,33,0,40]

theorem envBound56126 : H12AffineFastState.Bounded env56126 := by
  intro p hp
  have h : env56126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56125_56126 : H12AffineEnvironment.transform 3 12 env56125 = env56126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env56125 == env56126) = true)

theorem identity56126 : scanCanonicalize (H12AffineFastState.compose env56126 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56126 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56127 : List Nat := [0,4,8,12,32,12,8,36,40,40,0,13,41,1,1,33,13,0,40,0,0,33,12,0,41,13,1,13,12,0,9,33,36,33,0,40]

theorem envBound56127 : H12AffineFastState.Bounded env56127 := by
  intro p hp
  have h : env56127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56126_56127 : H12AffineEnvironment.transform 0 0 env56126 = env56127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56126 == env56127) = true)

theorem identity56127 : scanCanonicalize (H12AffineFastState.compose env56127 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound56127 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56128 : List Nat := [0,4,8,12,8,12,8,12,0,0,0,13,1,1,1,9,13,0,0,0,0,9,12,0,1,13,1,13,12,0,9,9,12,9,0,0]

theorem envBound56128 : H12AffineFastState.Bounded env56128 := by
  intro p hp
  have h : env56128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56127_56128 : H12AffineEnvironment.transform 4 8 env56127 = env56128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env56127 == env56128) = true)

theorem identity56128 : scanCanonicalize (H12AffineFastState.compose env56128 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56128 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56129 : List Nat := [0,0,8,8,8,8,8,8,0,0,0,9,1,1,1,9,9,0,0,0,0,9,8,0,1,9,1,9,8,0,9,9,8,9,0,0]

theorem envBound56129 : H12AffineFastState.Bounded env56129 := by
  intro p hp
  have h : env56129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56128_56129 : H12AffineEnvironment.transform 1 0 env56128 = env56129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56128 == env56129) = true)

theorem identity56129 : scanCanonicalize (H12AffineFastState.compose env56129 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound56129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56130 : List Nat := [0,0,1,1,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0,0,0,1,0,0,0]

theorem envBound56130 : H12AffineFastState.Bounded env56130 := by
  intro p hp
  have h : env56130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56129_56130 : H12AffineEnvironment.transform 2 1 env56129 = env56130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env56129 == env56130) = true)

def env56131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122146,1024,32769,4161,65910,119879,98645,8193,65,10588,5392,102742,108926,119043,128298,256,98678,90203,63069]

theorem envBound56131 : H12AffineFastState.Bounded env56131 := by
  intro p hp
  have h : env56131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56114_56131 : H12AffineEnvironment.transform 6 9 env56114 = env56131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56114 == env56131) = true)

theorem identity56131 : scanCanonicalize (H12AffineFastState.compose env56131 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound56131 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env56132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,76158,1024,29789,4161,65910,73755,95497,8193,65,10588,5392,91402,89378,75103,65910,256,95530,90203,513]

theorem envBound56132 : H12AffineFastState.Bounded env56132 := by
  intro p hp
  have h : env56132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56131_56132 : H12AffineEnvironment.transform 14 29788 env56131 = env56132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env56131 == env56132) = true)

theorem identity56132 : scanCanonicalize (H12AffineFastState.compose env56132 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56132 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env56133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,65536,82247,67619,1024,21760,4161,65910,65862,87124,348,65,2049,5392,83031,89378,66562,65910,256,87159,82182,513]

theorem envBound56133 : H12AffineFastState.Bounded env56133 := by
  intro p hp
  have h : env56133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56132_56133 : H12AffineEnvironment.transform 12 349 env56132 = env56133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56132 == env56133) = true)

theorem identity56133 : scanCanonicalize (H12AffineFastState.compose env56133 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound56133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56134 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16401,2421,1024,21760,4161,32,16,21762,348,65,2049,5392,17665,23668,1364,32,256,21793,16464,513]

theorem envBound56134 : H12AffineFastState.Bounded env56134 := by
  intro p hp
  have h : env56134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56133_56134 : H12AffineEnvironment.transform 15 342 env56133 = env56134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env56133 == env56134) = true)

theorem identity56134 : scanCanonicalize (H12AffineFastState.compose env56134 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound56134 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56135 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,349,16384,20496,342,16401,2421,273,20497,4161,32,16,20499,348,65,2049,4097,16400,22885,69,32,256,20528,16464,513]

theorem envBound56135 : H12AffineFastState.Bounded env56135 := by
  intro p hp
  have h : env56135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56134_56135 : H12AffineEnvironment.transform 9 273 env56134 = env56135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env56134 == env56135) = true)

theorem identity56135 : scanCanonicalize (H12AffineFastState.compose env56135 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound56135 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env56136 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,2356,349,16384,18724,342,16401,2421,273,18725,2421,32,16,18727,348,65,2049,2357,16400,16465,69,32,256,18692,16464,513]

theorem envBound56136 : H12AffineFastState.Bounded env56136 := by
  intro p hp
  have h : env56136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56135_56136 : H12AffineEnvironment.transform 11 2356 env56135 = env56136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env56135 == env56136) = true)

theorem identity56136 : scanCanonicalize (H12AffineFastState.compose env56136 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound56136 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env56137 : List Nat := [2,4,8,16,32,64,9,256,96,273,2048,2356,349,16384,18724,342,16401,2421,273,18725,2421,32,16,18727,348,65,2049,2357,16400,16465,69,32,256,18692,16464,97]

theorem envBound56137 : H12AffineFastState.Bounded env56137 := by
  intro p hp
  have h : env56137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56136_56137 : H12AffineEnvironment.transform 8 96 env56136 = env56137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env56136 == env56137) = true)

theorem identity56137 : scanCanonicalize (H12AffineFastState.compose env56137 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 373) := by decide +kernel

theorem selectedBound56137 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56138 : List Nat := [2,4,8,16,32,64,9,256,96,273,2048,2356,349,373,2129,342,356,2421,273,2128,2421,32,16,2130,348,65,2049,2357,357,292,69,32,256,2161,293,97]

theorem envBound56138 : H12AffineFastState.Bounded env56138 := by
  intro p hp
  have h : env56138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56137_56138 : H12AffineEnvironment.transform 13 373 env56137 = env56138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 373 env56137 == env56138) = true)

theorem identity56138 : scanCanonicalize (H12AffineFastState.compose env56138 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56138 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56139 : List Nat := [2,4,8,16,32,16,9,256,48,273,2048,2356,269,293,2049,262,308,2341,273,2048,2341,32,16,2050,268,17,2049,2357,309,292,21,32,256,2081,293,49]

theorem envBound56139 : H12AffineFastState.Bounded env56139 := by
  intro p hp
  have h : env56139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56138_56139 : H12AffineEnvironment.transform 5 16 env56138 = env56139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56138 == env56139) = true)

theorem identity56139 : scanCanonicalize (H12AffineFastState.compose env56139 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound56139 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56140 : List Nat := [2,4,8,16,32,16,9,256,48,273,309,1,269,293,308,262,308,16,273,309,16,32,16,311,268,17,308,0,309,292,21,32,256,276,293,49]

theorem envBound56140 : H12AffineFastState.Bounded env56140 := by
  intro p hp
  have h : env56140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56139_56140 : H12AffineEnvironment.transform 10 309 env56139 = env56140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env56139 == env56140) = true)

theorem identity56140 : scanCanonicalize (H12AffineFastState.compose env56140 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56140 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56141 : List Nat := [2,4,8,16,32,16,9,4,48,21,49,1,9,33,48,2,48,16,21,49,16,32,16,51,8,17,48,0,49,32,21,32,4,16,33,49]

theorem envBound56141 : H12AffineFastState.Bounded env56141 := by
  intro p hp
  have h : env56141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56140_56141 : H12AffineEnvironment.transform 7 4 env56140 = env56141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56140 == env56141) = true)

theorem identity56141 : scanCanonicalize (H12AffineFastState.compose env56141 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56142 : List Nat := [2,4,8,16,17,16,9,4,1,21,0,1,9,16,1,2,1,16,21,0,16,17,16,2,8,17,1,0,0,17,21,17,4,16,16,0]

theorem envBound56142 : H12AffineFastState.Bounded env56142 := by
  intro p hp
  have h : env56142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56141_56142 : H12AffineEnvironment.transform 4 17 env56141 = env56142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56141 == env56142) = true)

def env56143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,156012,120015,188870,8328,65,10588,226571,102879,109047,176408,128299,256,188901,131137,235215]

theorem envBound56143 : H12AffineFastState.Bounded env56143 := by
  intro p hp
  have h : env56143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56112_56143 : H12AffineEnvironment.transform 17 179513 env56112 = env56143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env56112 == env56143) = true)

theorem identity56143 : scanCanonicalize (H12AffineFastState.compose env56143 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound56143 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149997,1024,29909,4160,156012,73755,136466,8328,65,10588,226571,91403,89379,148940,66047,256,136497,131137,221723]

theorem envBound56144 : H12AffineFastState.Bounded env56144 := by
  intro p hp
  have h : env56144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56143_56144 : H12AffineEnvironment.transform 14 29908 env56143 = env56144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env56143 == env56144) = true)

def env56145 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,149949,1024,29829,4112,155964,73755,136466,8328,17,10508,226571,91403,89379,148892,65967,256,136497,131089,221723]

theorem envBound56145 : H12AffineFastState.Bounded env56145 := by
  intro p hp
  have h : env56145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56144_56145 : H12AffineEnvironment.transform 5 16 env56144 = env56145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56144 == env56145) = true)

theorem identity56145 : scanCanonicalize (H12AffineFastState.compose env56145 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound56145 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env56146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,97447,1024,29829,4112,87078,73755,73736,8328,17,10508,16401,91403,89379,94342,65967,256,73771,79115,22273]

theorem envBound56146 : H12AffineFastState.Bounded env56146 := by
  intro p hp
  have h : env56146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56145_56146 : H12AffineEnvironment.transform 16 79130 env56145 = env56146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env56145 == env56146) = true)

theorem identity56146 : scanCanonicalize (H12AffineFastState.compose env56146 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound56146 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env56147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,23589,1024,29829,4112,29860,153,138,8328,17,10508,16401,17801,32161,20484,8493,256,169,5513,22273]

theorem envBound56147 : H12AffineFastState.Bounded env56147 := by
  intro p hp
  have h : env56147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56146_56147 : H12AffineEnvironment.transform 15 8322 env56146 = env56147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env56146 == env56147) = true)

theorem identity56147 : scanCanonicalize (H12AffineFastState.compose env56147 (packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound56147 : packedSelected [3,4,8,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56148 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1172,16384,20496,1046,5528,23589,1024,20497,4112,20528,153,138,1052,17,3480,16401,17801,22837,20484,1465,256,169,5513,22273]

theorem envBound56148 : H12AffineFastState.Bounded env56148 := by
  intro p hp
  have h : env56148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56147_56148 : H12AffineEnvironment.transform 12 1172 env56147 = env56148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env56147 == env56148) = true)

theorem identity56148 : scanCanonicalize (H12AffineFastState.compose env56148 (packedSelected [0,1,2,5,6,7,10,14,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56148 : packedSelected [0,1,2,5,6,7,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env56149 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,16384,20496,262,4232,22837,272,20497,4112,20528,153,138,268,17,2184,16401,16537,22837,20484,169,256,169,4249,21009]

theorem envBound56149 : H12AffineFastState.Bounded env56149 := by
  intro p hp
  have h : env56149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56148_56149 : H12AffineEnvironment.transform 9 272 env56148 = env56149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56148 == env56149) = true)

theorem identity56149 : scanCanonicalize (H12AffineFastState.compose env56149 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound56149 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56150 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,4541,429,262,4232,2184,272,428,4112,397,153,138,268,17,2184,4524,4388,2184,441,169,256,169,4249,940]

theorem envBound56150 : H12AffineFastState.Bounded env56150 := by
  intro p hp
  have h : env56150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56149_56150 : H12AffineEnvironment.transform 13 4541 env56149 = env56150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env56149 == env56150) = true)

theorem identity56150 : scanCanonicalize (H12AffineFastState.compose env56150 (packedSelected [0,1,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound56150 : packedSelected [0,1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56151 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,429,388,16,429,262,293,2184,272,428,445,397,153,138,268,17,2184,1,137,2184,441,169,256,169,308,940]

theorem envBound56151 : H12AffineFastState.Bounded env56151 := by
  intro p hp
  have h : env56151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56150_56151 : H12AffineEnvironment.transform 11 429 env56150 = env56151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env56150 == env56151) = true)

def env56152 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149948,1024,29828,4113,155965,73755,136466,8328,16,10509,226571,91403,89379,148893,65966,256,136497,131088,221723]

theorem envBound56152 : H12AffineFastState.Bounded env56152 := by
  intro p hp
  have h : env56152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56144_56152 : H12AffineEnvironment.transform 5 17 env56144 = env56152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56144 == env56152) = true)

theorem identity56152 : scanCanonicalize (H12AffineFastState.compose env56152 (packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56152 : packedSelected [0,4,5,7,8,10,11,17,18,19,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env56153 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,131072,149812,1024,29708,4113,155965,73755,136466,8192,16,10509,226571,91403,89379,148757,65830,256,136497,131088,221723]

theorem envBound56153 : H12AffineFastState.Bounded env56153 := by
  intro p hp
  have h : env56153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56152_56153 : H12AffineEnvironment.transform 6 8 env56152 = env56153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56152 == env56153) = true)

theorem identity56153 : scanCanonicalize (H12AffineFastState.compose env56153 (packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound56153 : packedSelected [0,1,7,8,9,12,14,15,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env56154 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,65536,13624,31756,1024,29708,4113,21509,73755,8234,8192,16,10509,81971,91403,89379,28717,65830,256,8201,13608,87843]

theorem envBound56154 : H12AffineFastState.Bounded env56154 := by
  intro p hp
  have h : env56154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56153_56154 : H12AffineEnvironment.transform 16 13624 env56153 = env56154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env56153 == env56154) = true)

theorem identity56154 : scanCanonicalize (H12AffineFastState.compose env56154 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,18,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound56154 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,17,18,20,24] rootPS < 2^1333 := by decide +kernel

def env56155 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,29963,13624,31756,1024,29708,4113,21509,21776,8234,8192,16,10509,13624,4096,10280,28717,29741,256,8201,13608,8744]

theorem envBound56155 : H12AffineFastState.Bounded env56155 := by
  intro p hp
  have h : env56155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56154_56155 : H12AffineEnvironment.transform 15 29963 env56154 = env56155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env56154 == env56155) = true)

theorem identity56155 : scanCanonicalize (H12AffineFastState.compose env56155 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound56155 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56156 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,16384,21540,21794,5393,23589,1024,21541,4113,21509,21776,3,41,16,2340,5393,4096,2049,20484,21508,256,32,5377,513]

theorem envBound56156 : H12AffineFastState.Bounded env56156 := by
  intro p hp
  have h : env56156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56155_56156 : H12AffineEnvironment.transform 12 41 env56155 = env56156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env56155 == env56156) = true)

theorem identity56156 : scanCanonicalize (H12AffineFastState.compose env56156 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56157 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,16384,21540,21510,5173,23589,1024,21541,4113,21509,21556,3,41,16,2048,5173,4096,2049,20484,21508,36,32,5157,513]

theorem envBound56157 : H12AffineFastState.Bounded env56157 := by
  intro p hp
  have h : env56157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56156_56157 : H12AffineEnvironment.transform 7 36 env56156 = env56157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56156 == env56157) = true)

theorem identity56157 : scanCanonicalize (H12AffineFastState.compose env56157 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound56157 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env56158 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,3124,6160,6194,5173,4113,1024,6161,4113,6193,6144,3,41,16,2048,5173,4096,2049,7216,6192,36,32,5157,513]

theorem envBound56158 : H12AffineFastState.Bounded env56158 := by
  intro p hp
  have h : env56158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56157_56158 : H12AffineEnvironment.transform 13 3124 env56157 = env56158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env56157 == env56158) = true)

theorem identity56158 : scanCanonicalize (H12AffineFastState.compose env56158 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56158 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env56159 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,2049,6160,6194,4096,4113,53,6161,4113,6193,6144,3,41,16,2048,4096,4096,2049,6149,6192,36,32,4112,513]

theorem envBound56159 : H12AffineFastState.Bounded env56159 := by
  intro p hp
  have h : env56159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56158_56159 : H12AffineEnvironment.transform 9 53 env56158 = env56159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56158 == env56159) = true)

theorem identity56159 : scanCanonicalize (H12AffineFastState.compose env56159 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56159 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env56160 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,4096,41,0,4113,4147,4096,4113,53,4112,4113,4144,4097,3,41,16,1,4096,4096,0,4100,4145,36,32,4112,513]

theorem envBound56160 : H12AffineFastState.Bounded env56160 := by
  intro p hp
  have h : env56160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56159_56160 : H12AffineEnvironment.transform 10 1 env56159 = env56160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56159 == env56160) = true)

theorem identity56160 : scanCanonicalize (H12AffineFastState.compose env56160 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound56160 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56161 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,16,41,0,1,35,16,1,53,0,1,32,17,3,41,16,1,16,16,0,20,33,36,32,0,513]

theorem envBound56161 : H12AffineFastState.Bounded env56161 := by
  intro p hp
  have h : env56161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56160_56161 : H12AffineEnvironment.transform 11 16 env56160 = env56161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env56160 == env56161) = true)

def env56162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,156013,485878,16777216,8328,65,16959643,18973837,2571430,109047,17231335,19072172,256,19311962,19287294,17287728]

theorem envBound56162 : H12AffineFastState.Bounded env56162 := by
  intro p hp
  have h : env56162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56076_56162 : H12AffineEnvironment.transform 21 156013 env56076 = env56162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156013 env56076 == env56162) = true)

def env56163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437624,156013,485878,16777216,8328,65,16959643,17246709,102878,109047,17231335,17148372,256,16777250,16834950,17287728]

theorem envBound56163 : H12AffineFastState.Bounded env56163 := by
  intro p hp
  have h : env56163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56162_56163 : H12AffineEnvironment.transform 20 437624 env56162 = env56163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437624 env56162 == env56163) = true)

theorem identity56163 : scanCanonicalize (H12AffineFastState.compose env56163 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound56163 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env56164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115870,156013,16,16777216,8328,65,16959643,16793619,102878,109047,16876545,16957490,256,16777250,16834950,16819158]

theorem envBound56164 : H12AffineFastState.Bounded env56164 := by
  intro p hp
  have h : env56164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56163_56164 : H12AffineEnvironment.transform 17 223718 env56163 = env56164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env56163 == env56164) = true)

def env56165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115870,156013,16,95496,8328,65,245139,79131,102878,109047,61705,243002,256,95530,103566,120542]

theorem envBound56165 : H12AffineFastState.Bounded env56165 := by
  intro p hp
  have h : env56165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56164_56165 : H12AffineEnvironment.transform 23 95496 env56164 = env56165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env56164 == env56165) = true)

theorem identity56165 : scanCanonicalize (H12AffineFastState.compose env56165 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound56165 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179513,1024,32769,4161,156013,16,41431,8328,65,158028,57796,17665,32040,61705,156133,256,41461,16465,513]

theorem envBound56166 : H12AffineFastState.Bounded env56166 := by
  intro p hp
  have h : env56166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56165_56166 : H12AffineEnvironment.transform 15 54495 env56165 = env56166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env56165 == env56166) = true)

def env56167 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179513,1024,32769,4161,156013,16,41311,8192,65,158028,57676,17665,32040,61705,156013,256,41341,16465,513]

theorem envBound56167 : H12AffineFastState.Bounded env56167 := by
  intro p hp
  have h : env56167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56166_56167 : H12AffineEnvironment.transform 6 8 env56166 = env56167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56166 == env56167) = true)

theorem identity56167 : scanCanonicalize (H12AffineFastState.compose env56167 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound56167 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,13389,35188,1024,32769,4161,21792,16,41311,8192,65,23809,57676,17665,32040,61705,21792,256,41341,16465,513]

theorem envBound56168 : H12AffineFastState.Bounded env56168 := by
  intro p hp
  have h : env56168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56167_56168 : H12AffineEnvironment.transform 16 13389 env56167 = env56168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env56167 == env56168) = true)

theorem identity56168 : scanCanonicalize (H12AffineFastState.compose env56168 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound56168 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env56169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,28698,13389,11577,1024,9292,4161,21792,16,1298,8192,65,23809,17665,17665,32040,21828,21792,256,1328,16465,513]

theorem envBound56169 : H12AffineFastState.Bounded env56169 := by
  intro p hp
  have h : env56169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56168_56169 : H12AffineEnvironment.transform 14 9293 env56168 = env56169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env56168 == env56169) = true)

theorem identity56169 : scanCanonicalize (H12AffineFastState.compose env56169 (packedSelected [3,5,9,10,14,22] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound56169 : packedSelected [3,5,9,10,14,22] rootPS < 2^1333 := by decide +kernel

def env56170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,16384,0,21591,4096,2420,1024,1,4161,21792,16,1298,1101,65,23809,17665,17665,22885,21828,21792,256,1328,16465,513]

theorem envBound56170 : H12AffineFastState.Bounded env56170 := by
  intro p hp
  have h : env56170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56169_56170 : H12AffineEnvironment.transform 12 1101 env56169 = env56170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env56169 == env56170) = true)

theorem identity56170 : scanCanonicalize (H12AffineFastState.compose env56170 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound56170 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56171 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4112,0,1095,4096,2420,1024,1,4161,1328,16,1298,1101,65,3345,5393,5393,2421,1364,1328,256,1328,4161,513]

theorem envBound56171 : H12AffineFastState.Bounded env56171 := by
  intro p hp
  have h : env56171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56170_56171 : H12AffineEnvironment.transform 13 4112 env56170 = env56171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env56170 == env56171) = true)

theorem identity56171 : scanCanonicalize (H12AffineFastState.compose env56171 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound56171 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56172 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,268,4112,0,262,4096,2420,321,1,4161,113,16,83,268,65,2128,4176,4176,2421,21,113,256,113,4161,513]

theorem envBound56172 : H12AffineFastState.Bounded env56172 := by
  intro p hp
  have h : env56172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56171_56172 : H12AffineEnvironment.transform 9 321 env56171 = env56172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56171 == env56172) = true)

theorem identity56172 : scanCanonicalize (H12AffineFastState.compose env56172 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2852) := by decide +kernel

theorem selectedBound56172 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env56173 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2852,268,2868,0,262,2852,2420,321,1,2917,113,16,83,268,65,2128,2932,2932,2421,21,113,256,113,2917,513]

theorem envBound56173 : H12AffineFastState.Bounded env56173 := by
  intro p hp
  have h : env56173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56172_56173 : H12AffineEnvironment.transform 11 2852 env56172 = env56173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2852 env56172 == env56173) = true)

theorem identity56173 : scanCanonicalize (H12AffineFastState.compose env56173 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound56173 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env56174 : List Nat := [2,4,8,16,32,64,8,256,512,321,16,820,268,804,0,262,820,356,321,1,885,113,16,83,268,65,64,868,868,357,21,113,256,113,885,513]

theorem envBound56174 : H12AffineFastState.Bounded env56174 := by
  intro p hp
  have h : env56174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56173_56174 : H12AffineEnvironment.transform 10 16 env56173 = env56174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env56173 == env56174) = true)

theorem identity56174 : scanCanonicalize (H12AffineFastState.compose env56174 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound56174 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56175 : List Nat := [2,4,8,16,32,64,8,256,81,321,16,357,268,373,0,262,357,356,321,1,292,113,16,83,268,65,64,309,309,357,21,113,256,113,292,80]

theorem envBound56175 : H12AffineFastState.Bounded env56175 := by
  intro p hp
  have h : env56175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56174_56175 : H12AffineEnvironment.transform 8 81 env56174 = env56175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env56174 == env56175) = true)

theorem identity56175 : scanCanonicalize (H12AffineFastState.compose env56175 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56176 : List Nat := [2,4,8,16,32,16,8,256,1,273,16,309,268,293,0,262,309,308,273,1,292,33,16,3,268,17,16,309,309,309,21,33,256,33,292,0]

theorem envBound56176 : H12AffineFastState.Bounded env56176 := by
  intro p hp
  have h : env56176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56175_56176 : H12AffineEnvironment.transform 5 16 env56175 = env56176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56175 == env56176) = true)

theorem identity56176 : scanCanonicalize (H12AffineFastState.compose env56176 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound56176 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56177 : List Nat := [2,4,8,16,32,16,8,53,1,36,16,0,57,16,0,51,0,1,36,1,17,33,16,3,57,17,16,0,0,0,21,33,53,33,17,0]

theorem envBound56177 : H12AffineFastState.Bounded env56177 := by
  intro p hp
  have h : env56177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56176_56177 : H12AffineEnvironment.transform 7 53 env56176 = env56177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env56176 == env56177) = true)

theorem identity56177 : scanCanonicalize (H12AffineFastState.compose env56177 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56177 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56178 : List Nat := [2,4,8,16,0,16,8,21,1,4,16,0,25,16,0,19,0,1,4,1,17,1,16,3,25,17,16,0,0,0,21,1,21,1,17,0]

theorem envBound56178 : H12AffineFastState.Bounded env56178 := by
  intro p hp
  have h : env56178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56177_56178 : H12AffineEnvironment.transform 4 0 env56177 = env56178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56177 == env56178) = true)

theorem identity56178 : scanCanonicalize (H12AffineFastState.compose env56178 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56179 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,0,9,0,0,3,0,1,4,1,1,1,0,3,9,1,0,0,0,0,5,1,5,1,1,0]

theorem envBound56179 : H12AffineFastState.Bounded env56179 := by
  intro p hp
  have h : env56179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56178_56179 : H12AffineEnvironment.transform 3 0 env56178 = env56179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56178 == env56179) = true)

def env56180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4161,156013,16,41310,8193,65,158028,57677,17665,32040,61705,156012,256,41340,16465,513]

theorem envBound56180 : H12AffineFastState.Bounded env56180 := by
  intro p hp
  have h : env56180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56166_56180 : H12AffineEnvironment.transform 6 9 env56166 = env56180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56166 == env56180) = true)

theorem identity56180 : scanCanonicalize (H12AffineFastState.compose env56180 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound56180 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10281,1024,32769,4161,62589,16,41310,8193,65,64604,57677,17665,32040,61705,62588,256,41340,16465,513]

theorem envBound56181 : H12AffineFastState.Bounded env56181 := by
  intro p hp
  have h : env56181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56180_56181 : H12AffineEnvironment.transform 16 38160 env56180 = env56181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env56180 == env56181) = true)

theorem identity56181 : scanCanonicalize (H12AffineFastState.compose env56181 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56181 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env56182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33110,38160,10281,1024,32769,4161,41341,16,41310,8193,65,43356,46157,4097,10280,41993,41340,256,41340,5457,513]

theorem envBound56182 : H12AffineFastState.Bounded env56182 := by
  intro p hp
  have h : env56182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56181_56182 : H12AffineEnvironment.transform 13 5376 env56181 = env56182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56181 == env56182) = true)

theorem identity56182 : scanCanonicalize (H12AffineFastState.compose env56182 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound56182 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8232,8574,13624,10281,1024,8233,4161,341,16,374,8193,65,2420,5221,4097,10280,1057,340,256,340,5457,513]

theorem envBound56183 : H12AffineFastState.Bounded env56183 := by
  intro p hp
  have h : env56183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56182_56183 : H12AffineEnvironment.transform 14 8232 env56182 = env56183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env56182 == env56183) = true)

theorem identity56183 : scanCanonicalize (H12AffineFastState.compose env56183 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound56183 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env56184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,80,262,5440,2129,1024,81,4161,341,16,374,121,65,2420,5221,4097,2128,1057,340,256,340,5457,513]

theorem envBound56184 : H12AffineFastState.Bounded env56184 := by
  intro p hp
  have h : env56184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56183_56184 : H12AffineEnvironment.transform 12 120 env56183 = env56184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env56183 == env56184) = true)

theorem identity56184 : scanCanonicalize (H12AffineFastState.compose env56184 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56184 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env56185 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,115,5173,2129,1024,81,4161,32,16,3,121,65,2049,5221,4097,2128,1057,33,117,33,5156,513]

theorem envBound56185 : H12AffineFastState.Bounded env56185 := by
  intro p hp
  have h : env56185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56184_56185 : H12AffineEnvironment.transform 7 117 env56184 = env56185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56184 == env56185) = true)

theorem identity56185 : scanCanonicalize (H12AffineFastState.compose env56185 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound56185 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env56186 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,120,81,80,115,17,2129,1024,81,1125,32,16,3,121,65,2049,65,1061,2128,1057,33,117,33,0,513]

theorem envBound56186 : H12AffineFastState.Bounded env56186 := by
  intro p hp
  have h : env56186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56185_56186 : H12AffineEnvironment.transform 11 1060 env56185 = env56186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env56185 == env56186) = true)

theorem identity56186 : scanCanonicalize (H12AffineFastState.compose env56186 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56186 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56187 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,1060,40,1,0,35,17,2049,1024,1,1077,32,16,3,41,17,2049,17,1061,2048,1057,33,37,33,0,513]

theorem envBound56187 : H12AffineFastState.Bounded env56187 := by
  intro p hp
  have h : env56187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56186_56187 : H12AffineEnvironment.transform 5 16 env56186 = env56187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56186 == env56187) = true)

theorem identity56187 : scanCanonicalize (H12AffineFastState.compose env56187 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound56187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56188 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,0,40,1,0,35,17,2049,36,1,17,32,16,3,41,17,2049,17,1,2048,5,33,37,33,0,513]

theorem envBound56188 : H12AffineFastState.Bounded env56188 := by
  intro p hp
  have h : env56188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56187_56188 : H12AffineEnvironment.transform 9 36 env56187 = env56188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env56187 == env56188) = true)

theorem identity56188 : scanCanonicalize (H12AffineFastState.compose env56188 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound56188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56189 : List Nat := [2,4,8,16,32,16,9,37,512,36,11,0,40,1,0,35,17,10,36,1,17,32,16,3,41,17,10,17,1,11,5,33,37,33,0,513]

theorem envBound56189 : H12AffineFastState.Bounded env56189 := by
  intro p hp
  have h : env56189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56188_56189 : H12AffineEnvironment.transform 10 11 env56188 = env56189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env56188 == env56189) = true)

theorem identity56189 : scanCanonicalize (H12AffineFastState.compose env56189 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound56189 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56190 : List Nat := [2,4,8,16,27,16,9,30,512,31,11,0,19,1,0,24,17,10,31,1,17,27,16,3,18,17,10,17,1,11,5,26,30,26,0,513]

theorem envBound56190 : H12AffineFastState.Bounded env56190 := by
  intro p hp
  have h : env56190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56189_56190 : H12AffineEnvironment.transform 4 27 env56189 = env56190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env56189 == env56190) = true)

def env56191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,115870,156013,16,95497,8328,65,245138,79130,102878,109047,61704,243003,256,95531,103567,120543]

theorem envBound56191 : H12AffineFastState.Bounded env56191 := by
  intro p hp
  have h : env56191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56164_56191 : H12AffineEnvironment.transform 23 95497 env56164 = env56191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env56164 == env56191) = true)

def env56192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,115734,156013,16,95497,8192,65,245018,79130,102742,108927,61704,243003,256,95531,103431,120407]

theorem envBound56192 : H12AffineFastState.Bounded env56192 := by
  intro p hp
  have h : env56192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56191_56192 : H12AffineEnvironment.transform 6 8 env56191 = env56192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56191 == env56192) = true)

theorem identity56192 : scanCanonicalize (H12AffineFastState.compose env56192 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound56192 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35188,1024,32769,115734,98679,16,95497,8192,65,23808,79130,102742,108927,61704,21793,256,95531,103431,120407]

theorem envBound56193 : H12AffineFastState.Bounded env56193 := by
  intro p hp
  have h : env56193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56192_56193 : H12AffineEnvironment.transform 16 122906 env56192 = env56193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env56192 == env56193) = true)

theorem identity56193 : scanCanonicalize (H12AffineFastState.compose env56193 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound56193 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env56194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,46156,35188,1024,32769,36928,54561,16,8543,8192,65,23808,24908,50432,64809,61704,21793,256,8573,49233,33281]

theorem envBound56194 : H12AffineFastState.Bounded env56194 := by
  intro p hp
  have h : env56194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56193_56194 : H12AffineEnvironment.transform 15 21590 env56193 = env56194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env56193 == env56194) = true)

theorem identity56194 : scanCanonicalize (H12AffineFastState.compose env56194 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56194 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env56195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46156,35188,1024,32769,36928,41341,16,8543,8192,65,10588,5392,45404,35189,34132,8573,256,8573,46093,33281]

theorem envBound56195 : H12AffineFastState.Bounded env56195 := by
  intro p hp
  have h : env56195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56194_56195 : H12AffineEnvironment.transform 13 13404 env56194 = env56195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56194 == env56195) = true)

theorem identity56195 : scanCanonicalize (H12AffineFastState.compose env56195 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56195 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env56196 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13404,32768,8202,46156,34817,1024,32769,36928,40968,16,8234,8192,65,10281,5221,45097,34816,33825,8200,117,8200,46093,33281]

theorem envBound56196 : H12AffineFastState.Bounded env56196 := by
  intro p hp
  have h : env56196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56195_56196 : H12AffineEnvironment.transform 7 117 env56195 = env56196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56195 == env56196) = true)

theorem identity56196 : scanCanonicalize (H12AffineFastState.compose env56196 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound56196 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56197 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13404,80,8202,13340,2129,1024,81,4112,8280,16,8234,8192,65,10281,5221,12409,2128,1137,8200,117,8200,13405,593]

theorem envBound56197 : H12AffineFastState.Bounded env56197 := by
  intro p hp
  have h : env56197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56196_56197 : H12AffineEnvironment.transform 14 80 env56196 = env56197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env56196 == env56197) = true)

theorem identity56197 : scanCanonicalize (H12AffineFastState.compose env56197 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1637) := by decide +kernel

theorem selectedBound56197 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env56198 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1637,8192,8761,80,8202,8825,2129,1024,81,1653,8280,16,8234,8192,65,10281,512,9756,2128,1137,8200,117,8200,8760,593]

theorem envBound56198 : H12AffineFastState.Bounded env56198 := by
  intro p hp
  have h : env56198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56197_56198 : H12AffineEnvironment.transform 11 1637 env56197 = env56198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1637 env56197 == env56198) = true)

theorem identity56198 : scanCanonicalize (H12AffineFastState.compose env56198 (packedSelected [0,1,4,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1637) := by decide +kernel

theorem selectedBound56198 : packedSelected [0,1,4,5,12] rootPS < 2^1333 := by decide +kernel

def env56199 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1637,1637,8192,8761,80,8202,8825,1588,1024,81,1653,8280,16,8234,8192,65,9804,512,9756,1589,1137,8200,117,8200,8760,593]

theorem envBound56199 : H12AffineFastState.Bounded env56199 := by
  intro p hp
  have h : env56199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56198_56199 : H12AffineEnvironment.transform 10 1637 env56198 = env56199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1637 env56198 == env56199) = true)

theorem identity56199 : scanCanonicalize (H12AffineFastState.compose env56199 (packedSelected [0,1,4,5,11,14] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound56199 : packedSelected [0,1,4,5,11,14] rootPS < 2^1333 := by decide +kernel

def env56200 : List Nat := [2,4,8,16,32,64,8,117,64,1024,1061,1061,8192,8313,80,8202,8249,1140,1024,81,1077,8280,16,8234,8192,65,9228,64,9308,1141,1137,8200,117,8200,8312,17]

theorem envBound56200 : H12AffineFastState.Bounded env56200 := by
  intro p hp
  have h : env56200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56199_56200 : H12AffineEnvironment.transform 8 64 env56199 = env56200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env56199 == env56200) = true)

theorem identity56200 : scanCanonicalize (H12AffineFastState.compose env56200 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound56200 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env56201 : List Nat := [2,4,8,16,32,64,8,117,64,117,80,80,8192,8313,80,8202,8249,1,117,81,64,8280,16,8234,8192,65,8313,64,8233,0,4,8200,117,8200,8312,17]

theorem envBound56201 : H12AffineFastState.Bounded env56201 := by
  intro p hp
  have h : env56201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56200_56201 : H12AffineEnvironment.transform 9 117 env56200 = env56201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env56200 == env56201) = true)

theorem identity56201 : scanCanonicalize (H12AffineFastState.compose env56201 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound56201 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env56202 : List Nat := [2,4,8,16,32,64,8,117,64,117,80,80,120,1,80,114,65,1,117,81,64,32,16,82,120,65,1,64,81,0,4,112,117,112,0,17]

theorem envBound56202 : H12AffineFastState.Bounded env56202 := by
  intro p hp
  have h : env56202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56201_56202 : H12AffineEnvironment.transform 12 120 env56201 = env56202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env56201 == env56202) = true)

def env56203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,115735,156013,16,95497,8193,65,245019,79130,102743,108926,61704,243003,256,95531,103430,120406]

theorem envBound56203 : H12AffineFastState.Bounded env56203 := by
  intro p hp
  have h : env56203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56191_56203 : H12AffineEnvironment.transform 6 9 env56191 = env56203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56191 == env56203) = true)

theorem identity56203 : scanCanonicalize (H12AffineFastState.compose env56203 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound56203 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1024,32769,115735,73771,16,95497,8193,65,64605,79130,102743,108926,61704,62589,256,95531,103430,120406]

theorem envBound56204 : H12AffineFastState.Bounded env56204 := by
  intro p hp
  have h : env56204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56203_56204 : H12AffineEnvironment.transform 16 82246 env56203 = env56204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env56203 == env56204) = true)

theorem identity56204 : scanCanonicalize (H12AffineFastState.compose env56204 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound56204 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env56205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,82246,2420,1024,32769,115735,65910,16,87124,348,65,56576,70727,102743,100387,53333,54560,256,87158,103430,120406]

theorem envBound56205 : H12AffineFastState.Bounded env56205 := by
  intro p hp
  have h : env56205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56204_56205 : H12AffineEnvironment.transform 12 349 env56204 = env56205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env56204 == env56205) = true)

theorem identity56205 : scanCanonicalize (H12AffineFastState.compose env56205 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound56205 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env56206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,65536,82246,2420,1024,21761,69911,65910,16,87124,348,65,2048,70727,83031,89379,1365,32,256,87158,82182,66390]

theorem envBound56206 : H12AffineFastState.Bounded env56206 := by
  intro p hp
  have h : env56206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56205_56206 : H12AffineEnvironment.transform 14 21760 env56205 = env56206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env56205 == env56206) = true)

theorem identity56206 : scanCanonicalize (H12AffineFastState.compose env56206 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound56206 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env56207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,65536,70678,2420,1024,81,69911,65910,16,65796,348,65,2048,70727,69895,67699,1365,32,256,65830,70742,66390]

theorem envBound56207 : H12AffineFastState.Bounded env56207 := by
  intro p hp
  have h : env56207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56206_56207 : H12AffineEnvironment.transform 13 5456 env56206 = env56207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env56206 == env56207) = true)

theorem identity56207 : scanCanonicalize (H12AffineFastState.compose env56207 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56207 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env56208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,80,115,5221,2420,1024,81,4452,261,16,375,348,65,2048,5172,4468,2048,1365,32,256,341,5157,805]

theorem envBound56208 : H12AffineFastState.Bounded env56208 := by
  intro p hp
  have h : env56208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56207_56208 : H12AffineEnvironment.transform 15 115 env56207 = env56208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56207 == env56208) = true)

theorem identity56208 : scanCanonicalize (H12AffineFastState.compose env56208 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56208 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env56209 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5156,80,115,5221,2048,1024,81,4112,113,16,3,40,65,2048,5172,4096,2048,1057,32,116,33,5157,593]

theorem envBound56209 : H12AffineFastState.Bounded env56209 := by
  intro p hp
  have h : env56209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56208_56209 : H12AffineEnvironment.transform 7 116 env56208 = env56209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56208 == env56209) = true)

theorem identity56209 : scanCanonicalize (H12AffineFastState.compose env56209 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56209 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env56210 : List Nat := [2,4,8,16,0,64,9,84,512,1024,2048,4096,9,5124,80,83,5189,2048,1024,81,4112,81,16,3,8,65,2048,5140,4096,2048,1025,0,84,1,5125,593]

theorem envBound56210 : H12AffineFastState.Bounded env56210 := by
  intro p hp
  have h : env56210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56209_56210 : H12AffineEnvironment.transform 4 0 env56209 = env56210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56209 == env56210) = true)

def env56211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485878,16777216,8328,65,16959643,17246708,102879,109047,17231335,17148373,256,16777251,16834951,17287728]

theorem envBound56211 : H12AffineFastState.Bounded env56211 := by
  intro p hp
  have h : env56211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56162_56211 : H12AffineEnvironment.transform 20 437625 env56162 = env56211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437625 env56162 == env56211) = true)

theorem identity56211 : scanCanonicalize (H12AffineFastState.compose env56211 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 362528) := by decide +kernel

theorem selectedBound56211 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env56212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437625,156013,485878,362528,8328,65,475323,172500,102879,109047,222663,8693,256,362499,354727,147984]

theorem envBound56212 : H12AffineFastState.Bounded env56212 := by
  intro p hp
  have h : env56212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56211_56212 : H12AffineEnvironment.transform 23 362528 env56211 = env56212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 362528 env56211 == env56212) = true)

def env56213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,322921,8573,338406,362528,8328,65,327851,57796,102879,109047,75223,8693,256,362499,354727,512]

theorem envBound56213 : H12AffineFastState.Bounded env56213 := by
  intro p hp
  have h : env56213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56212_56213 : H12AffineEnvironment.transform 16 16400 env56212 = env56213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env56212 == env56213) = true)

theorem identity56213 : scanCanonicalize (H12AffineFastState.compose env56213 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 122146) := by decide +kernel

theorem selectedBound56213 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,122146,1024,32769,77899,8573,62660,21762,8328,65,56713,57796,102879,109047,75223,8693,256,21793,46213,512]

theorem envBound56214 : H12AffineFastState.Bounded env56214 := by
  intro p hp
  have h : env56214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56213_56214 : H12AffineEnvironment.transform 17 122146 env56213 = env56214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122146 env56213 == env56214) = true)

theorem identity56214 : scanCanonicalize (H12AffineFastState.compose env56214 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound56214 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env56215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,16400,76278,1024,29909,77899,8573,16,21762,8328,65,10589,5392,91403,89379,75223,8693,256,21793,16465,512]

theorem envBound56215 : H12AffineFastState.Bounded env56215 := by
  intro p hp
  have h : env56215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56214_56215 : H12AffineEnvironment.transform 14 29908 env56214 = env56215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env56214 == env56215) = true)

theorem identity56215 : scanCanonicalize (H12AffineFastState.compose env56215 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound56215 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,34,16400,10708,1024,29909,12393,8573,16,21762,8328,65,10589,5392,25897,23809,9717,8693,256,21793,16465,512]

theorem envBound56216 : H12AffineFastState.Bounded env56216 := by
  intro p hp
  have h : env56216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56215_56216 : H12AffineEnvironment.transform 15 34 env56215 = env56216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env56215 == env56216) = true)

theorem identity56216 : scanCanonicalize (H12AffineFastState.compose env56216 (packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13556) := by decide +kernel

end H12CloudChart1