import H12CloudChart1Data027

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env6936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,5357,262144,524288,8540,17597,32,8388608,8914075,8328,525757,262281,8917249,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6936 : H12AffineFastState.Bounded env6936 := by
  intro p hp
  have h : env6936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6935_6936 : H12AffineEnvironment.transform 16 5357 env6935 = env6936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env6935 == env6936) = true)

theorem identity6936 : scanCanonicalize (H12AffineFastState.compose env6936 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound6936 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,34,5357,262144,524288,1,17597,32,8388608,8914075,469,525757,262281,8917249,8918508,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6937 : H12AffineFastState.Bounded env6937 := by
  intro p hp
  have h : env6937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6936_6937 : H12AffineEnvironment.transform 12 349 env6936 = env6937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env6936 == env6937) = true)

theorem identity6937 : scanCanonicalize (H12AffineFastState.compose env6937 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 525805) := by decide +kernel

theorem selectedBound6937 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env6938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,34,5357,262144,524288,1,17597,32,525805,374,469,525757,262281,5356,4097,2184,1364,341,525568,169,34359738368,512]

theorem envBound6938 : H12AffineFastState.Bounded env6938 := by
  intro p hp
  have h : env6938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6937_6938 : H12AffineEnvironment.transform 22 525805 env6937 = env6938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525805 env6937 == env6938) = true)

theorem identity6938 : scanCanonicalize (H12AffineFastState.compose env6938 (packedSelected [2,6] rootPS)) = affineNative (2^(18+1) ^^^ 1452) := by decide +kernel

theorem selectedBound6938 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,34,5357,262144,1452,1,17597,32,65,374,469,17,262281,5356,4097,2184,1364,341,172,169,34359738368,512]

theorem envBound6939 : H12AffineFastState.Bounded env6939 := by
  intro p hp
  have h : env6939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6938_6939 : H12AffineEnvironment.transform 18 1452 env6938 = env6939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1452 env6938 == env6939) = true)

theorem identity6939 : scanCanonicalize (H12AffineFastState.compose env6939 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6939 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env6940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,34,5357,2184,1452,1,17597,32,65,374,469,17,2049,5356,4097,2184,1364,341,172,169,34359738368,512]

theorem envBound6940 : H12AffineFastState.Bounded env6940 := by
  intro p hp
  have h : env6940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6939_6940 : H12AffineEnvironment.transform 17 2184 env6939 = env6940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6939 == env6940) = true)

theorem identity6940 : scanCanonicalize (H12AffineFastState.compose env6940 (packedSelected [4,9,11] rootPS)) = affineNative (2^(34+1) ^^^ 16893) := by decide +kernel

theorem selectedBound6940 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env6941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,34,5357,2184,1452,1,17597,32,65,374,469,17,2049,5356,4097,2184,1364,341,172,169,16893,512]

theorem envBound6941 : H12AffineFastState.Bounded env6941 := by
  intro p hp
  have h : env6941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6940_6941 : H12AffineEnvironment.transform 34 16893 env6940 = env6941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 16893 env6940 == env6941) = true)

def env6942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,131072,262144,524288,8540,151633,32,8388608,8914075,8328,525757,262281,9045485,8918509,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6942 : H12AffineFastState.Bounded env6942 := by
  intro p hp
  have h : env6942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6934_6942 : H12AffineEnvironment.transform 20 151633 env6934 = env6942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env6934 == env6942) = true)

theorem identity6942 : scanCanonicalize (H12AffineFastState.compose env6942 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound6942 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,5393,262144,524288,8540,17728,32,8388608,8914075,8328,525757,262281,8917244,8918509,8916325,1364,341,525568,8914244,34359738368,512]

theorem envBound6943 : H12AffineFastState.Bounded env6943 := by
  intro p hp
  have h : env6943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6942_6943 : H12AffineEnvironment.transform 16 5393 env6942 = env6943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env6942 == env6943) = true)

theorem identity6943 : scanCanonicalize (H12AffineFastState.compose env6943 (packedSelected [0,7,20] rootPS)) = affineNative (2^(22+1) ^^^ 533837) := by decide +kernel

theorem selectedBound6943 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8575,5393,262144,524288,8540,17728,32,533837,8662,8328,525757,262281,13745,12448,10280,1364,341,525568,8201,34359738368,512]

theorem envBound6944 : H12AffineFastState.Bounded env6944 := by
  intro p hp
  have h : env6944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6943_6944 : H12AffineEnvironment.transform 22 533837 env6943 = env6944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 533837 env6943 == env6944) = true)

def env6945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,508,479,5393,262144,524288,508,17728,32,525805,374,40,525757,262281,5393,4096,2184,1364,341,525568,169,34359738368,512]

theorem envBound6945 : H12AffineFastState.Bounded env6945 := by
  intro p hp
  have h : env6945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6944_6945 : H12AffineEnvironment.transform 12 160 env6944 = env6945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env6944 == env6945) = true)

theorem identity6945 : scanCanonicalize (H12AffineFastState.compose env6945 (packedSelected [2,6] rootPS)) = affineNative (2^(18+1) ^^^ 1453) := by decide +kernel

theorem selectedBound6945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env6946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,508,479,5393,262144,1453,508,17728,32,64,374,40,16,262281,5393,4096,2184,1364,341,173,169,34359738368,512]

theorem envBound6946 : H12AffineFastState.Bounded env6946 := by
  intro p hp
  have h : env6946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6945_6946 : H12AffineEnvironment.transform 18 1453 env6945 = env6946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1453 env6945 == env6946) = true)

theorem identity6946 : scanCanonicalize (H12AffineFastState.compose env6946 (packedSelected [1,3,4,5,8,9,11,12,13] rootPS)) = affineNative (2^(34+1) ^^^ 280949) := by decide +kernel

theorem selectedBound6946 : packedSelected [1,3,4,5,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,16384,508,479,5393,262144,1453,508,17728,32,64,374,40,16,262281,5393,4096,2184,1364,341,173,169,280949,512]

theorem envBound6947 : H12AffineFastState.Bounded env6947 := by
  intro p hp
  have h : env6947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6946_6947 : H12AffineEnvironment.transform 34 280949 env6946 = env6947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280949 env6946 == env6947) = true)

theorem identity6947 : scanCanonicalize (H12AffineFastState.compose env6947 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound6947 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env6948 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5357,262144,1105,0,17596,32,64,138,40,16,262281,5357,4096,2184,1192,169,173,169,280713,512]

theorem envBound6948 : H12AffineFastState.Bounded env6948 := by
  intro p hp
  have h : env6948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6947_6948 : H12AffineEnvironment.transform 7 252 env6947 = env6948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env6947 == env6948) = true)

theorem identity6948 : scanCanonicalize (H12AffineFastState.compose env6948 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 22618) := by decide +kernel

theorem selectedBound6948 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6949 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,0,35,5357,22618,1105,0,17596,32,64,138,40,16,22739,5357,4096,2184,1192,169,173,169,4307,512]

theorem envBound6949 : H12AffineFastState.Bounded env6949 := by
  intro p hp
  have h : env6949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6948_6949 : H12AffineEnvironment.transform 17 22618 env6948 = env6949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22618 env6948 == env6949) = true)

theorem identity6949 : scanCanonicalize (H12AffineFastState.compose env6949 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound6949 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env6950 : List Nat := [2,4,8,16,32,64,128,252,512,166,2048,4096,160,16384,0,35,4171,22618,247,0,16410,32,64,138,40,16,22739,4171,4096,2184,14,169,173,169,4307,512]

theorem envBound6950 : H12AffineFastState.Bounded env6950 := by
  intro p hp
  have h : env6950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6949_6950 : H12AffineEnvironment.transform 9 166 env6949 = env6950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env6949 == env6950) = true)

theorem identity6950 : scanCanonicalize (H12AffineFastState.compose env6950 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound6950 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6951 : List Nat := [2,4,8,16,32,64,88,36,512,126,2048,4096,120,16384,0,35,4171,22618,47,0,16410,32,64,82,40,16,22539,4171,4096,2128,14,113,117,113,4107,512]

theorem envBound6951 : H12AffineFastState.Bounded env6951 := by
  intro p hp
  have h : env6951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6950_6951 : H12AffineEnvironment.transform 6 88 env6950 = env6951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env6950 == env6951) = true)

theorem identity6951 : scanCanonicalize (H12AffineFastState.compose env6951 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound6951 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env6952 : List Nat := [2,4,8,16,32,64,88,36,512,126,523,4096,120,16384,0,35,4171,21073,47,0,16410,32,64,82,40,16,20992,4171,4096,603,14,113,117,113,4107,512]

theorem envBound6952 : H12AffineFastState.Bounded env6952 := by
  intro p hp
  have h : env6952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6951_6952 : H12AffineEnvironment.transform 10 523 env6951 = env6952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env6951 == env6952) = true)

def env6953 : List Nat := [2,4,8,16,32,16,8,36,512,46,523,4096,40,16384,0,35,4123,20993,47,0,16410,32,16,2,40,16,20992,4123,4096,523,14,33,37,33,4107,512]

theorem envBound6953 : H12AffineFastState.Bounded env6953 := by
  intro p hp
  have h : env6953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6952_6953 : H12AffineEnvironment.transform 5 16 env6952 = env6953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6952 == env6953) = true)

theorem identity6953 : scanCanonicalize (H12AffineFastState.compose env6953 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6954 : List Nat := [2,4,8,16,16,16,8,20,512,30,523,4096,24,16384,0,19,4123,20993,31,0,16410,16,16,2,24,16,20992,4123,4096,523,14,17,21,17,4107,512]

theorem envBound6954 : H12AffineFastState.Bounded env6954 := by
  intro p hp
  have h : env6954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6953_6954 : H12AffineEnvironment.transform 4 16 env6953 = env6954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6953 == env6954) = true)

def env6955 : List Nat := [2,4,8,16,16,16,8,20,512,30,523,0,24,16384,0,19,27,16897,31,0,16410,16,16,2,24,16,16896,27,0,523,14,17,21,17,11,512]

theorem envBound6955 : H12AffineFastState.Bounded env6955 := by
  intro p hp
  have h : env6955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6954_6955 : H12AffineEnvironment.transform 11 0 env6954 = env6955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env6954 == env6955) = true)

theorem identity6955 : scanCanonicalize (H12AffineFastState.compose env6955 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound6955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6956 : List Nat := [1,4,8,16,16,16,8,20,512,29,520,0,24,16384,0,16,24,16897,28,0,16409,16,16,1,24,16,16896,24,0,520,13,17,21,17,8,512]

theorem envBound6956 : H12AffineFastState.Bounded env6956 := by
  intro p hp
  have h : env6956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6955_6956 : H12AffineEnvironment.transform 0 1 env6955 = env6956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env6955 == env6956) = true)

def env6957 : List Nat := [1,4,8,16,16,16,8,20,512,29,520,0,24,528,0,16,24,17,28,0,521,16,16,1,24,16,16,24,0,520,13,17,21,17,8,512]

theorem envBound6957 : H12AffineFastState.Bounded env6957 := by
  intro p hp
  have h : env6957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6956_6957 : H12AffineEnvironment.transform 13 528 env6956 = env6957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 528 env6956 == env6957) = true)

theorem identity6957 : scanCanonicalize (H12AffineFastState.compose env6957 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound6957 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6958 : List Nat := [1,4,8,16,16,16,8,20,24,29,16,0,24,8,0,16,24,17,28,0,17,16,16,1,24,16,16,24,0,16,13,17,21,17,8,24]

theorem envBound6958 : H12AffineFastState.Bounded env6958 := by
  intro p hp
  have h : env6958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6957_6958 : H12AffineEnvironment.transform 8 24 env6957 = env6958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env6957 == env6958) = true)

theorem identity6958 : scanCanonicalize (H12AffineFastState.compose env6958 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound6958 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6959 : List Nat := [1,4,8,13,13,13,8,9,5,0,13,0,5,8,0,13,5,12,1,0,12,13,13,1,5,13,13,5,0,13,13,12,8,12,8,5]

theorem envBound6959 : H12AffineFastState.Bounded env6959 := by
  intro p hp
  have h : env6959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6958_6959 : H12AffineEnvironment.transform 3 13 env6958 = env6959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env6958 == env6959) = true)

theorem identity6959 : scanCanonicalize (H12AffineFastState.compose env6959 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6959 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6960 : List Nat := [1,1,8,8,8,8,8,9,0,0,8,0,0,8,0,8,0,9,1,0,9,8,8,1,0,8,8,0,0,8,8,9,8,9,8,0]

theorem envBound6960 : H12AffineFastState.Bounded env6960 := by
  intro p hp
  have h : env6960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6959_6960 : H12AffineEnvironment.transform 1 1 env6959 = env6960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6959 == env6960) = true)

def leafEnv6960 : List Nat := [1,1,8,8,8,8,8,9,0,0,8,0,0,8,0,8,0,9,1,0,9,8,8,1,9,0,1,8,8,0,0,8,8,9,8,9,0,8,8,0,1,8,0]

def active6960 : List Nat := [2]

def tree6960 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6960 : H12WitnessSearch.Good tree6960 := H12GlobalWitnessIndex.good

theorem leafIdentity6960 : H12AffineFastState.composeSystem env6960 rootObs = leafEnv6960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6960 rootObs == leafEnv6960) = true)

theorem terminalChecked6960 : H12PackedTerminal.terminalCheckFast leafEnv6960 active6960 tree6960 = true := by decide +kernel

def env6961 : List Nat := [1,4,8,16,16,16,8,20,512,29,520,0,24,529,0,16,24,16,28,0,520,16,16,1,24,16,17,24,0,520,13,17,21,17,8,512]

theorem envBound6961 : H12AffineFastState.Bounded env6961 := by
  intro p hp
  have h : env6961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6956_6961 : H12AffineEnvironment.transform 13 529 env6956 = env6961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 529 env6956 == env6961) = true)

def env6962 : List Nat := [1,4,8,16,16,16,8,20,16,29,24,0,24,1,0,16,24,16,28,0,24,16,16,1,24,16,17,24,0,24,13,17,21,17,8,16]

theorem envBound6962 : H12AffineFastState.Bounded env6962 := by
  intro p hp
  have h : env6962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6961_6962 : H12AffineEnvironment.transform 8 16 env6961 = env6962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env6961 == env6962) = true)

theorem identity6962 : scanCanonicalize (H12AffineFastState.compose env6962 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6963 : List Nat := [1,1,8,16,16,16,8,17,16,24,24,0,24,1,0,16,24,16,25,0,24,16,16,1,24,16,17,24,0,24,8,17,16,17,8,16]

theorem envBound6963 : H12AffineFastState.Bounded env6963 := by
  intro p hp
  have h : env6963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6962_6963 : H12AffineEnvironment.transform 1 1 env6962 = env6963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6962 == env6963) = true)

def env6964 : List Nat := [1,1,8,0,0,0,8,1,0,8,8,0,8,1,0,0,8,0,9,0,8,0,0,1,8,0,1,8,0,8,8,1,0,1,8,0]

theorem envBound6964 : H12AffineFastState.Bounded env6964 := by
  intro p hp
  have h : env6964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6963_6964 : H12AffineEnvironment.transform 3 0 env6963 = env6964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6963 == env6964) = true)

def leafEnv6964 : List Nat := [1,1,8,0,0,0,8,1,0,8,8,0,8,1,0,0,8,0,9,0,8,0,0,1,9,8,1,0,1,8,0,8,8,1,0,1,0,0,8,0,1,0,0]

def active6964 : List Nat := [2]

def tree6964 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6964 : H12WitnessSearch.Good tree6964 := H12GlobalWitnessIndex.good

theorem leafIdentity6964 : H12AffineFastState.composeSystem env6964 rootObs = leafEnv6964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6964 rootObs == leafEnv6964) = true)

theorem terminalChecked6964 : H12PackedTerminal.terminalCheckFast leafEnv6964 active6964 tree6964 = true := by decide +kernel

def env6965 : List Nat := [1,1,8,1,1,1,8,0,1,9,9,0,9,1,0,1,9,1,8,0,9,1,1,1,9,1,0,9,0,9,8,0,1,0,8,1]

theorem envBound6965 : H12AffineFastState.Bounded env6965 := by
  intro p hp
  have h : env6965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6963_6965 : H12AffineEnvironment.transform 3 1 env6963 = env6965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6963 == env6965) = true)

theorem identity6965 : scanCanonicalize (H12AffineFastState.compose env6965 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound6965 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6966 : List Nat := [1,1,0,1,1,1,0,0,1,1,1,0,1,1,0,1,1,1,0,0,1,1,1,1,1,1,0,1,0,1,0,0,1,0,0,1]

theorem envBound6966 : H12AffineFastState.Bounded env6966 := by
  intro p hp
  have h : env6966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6965_6966 : H12AffineEnvironment.transform 2 0 env6965 = env6966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env6965 == env6966) = true)

def leafEnv6966 : List Nat := [1,1,0,1,1,1,0,0,1,1,1,0,1,1,0,1,1,1,0,0,1,1,1,1,1,1,1,1,0,1,0,1,0,0,1,0,0,1,0,1,1,1,0]

def active6966 : List Nat := []

def tree6966 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6966 : H12WitnessSearch.Good tree6966 := H12GlobalWitnessIndex.good

theorem leafIdentity6966 : H12AffineFastState.composeSystem env6966 rootObs = leafEnv6966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6966 rootObs == leafEnv6966) = true)

theorem terminalChecked6966 : H12PackedTerminal.terminalCheckFast leafEnv6966 active6966 tree6966 = true := by decide +kernel

def env6967 : List Nat := [1,4,8,16,16,16,8,20,17,29,25,0,24,0,0,16,24,16,28,0,25,16,16,1,24,16,17,24,0,25,13,17,21,17,8,17]

theorem envBound6967 : H12AffineFastState.Bounded env6967 := by
  intro p hp
  have h : env6967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6961_6967 : H12AffineEnvironment.transform 8 17 env6961 = env6967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env6961 == env6967) = true)

theorem identity6967 : scanCanonicalize (H12AffineFastState.compose env6967 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound6967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6968 : List Nat := [1,4,5,16,16,16,5,20,17,16,20,0,21,0,0,16,21,16,17,0,20,16,16,1,21,16,17,21,0,20,0,17,21,17,5,17]

theorem envBound6968 : H12AffineFastState.Bounded env6968 := by
  intro p hp
  have h : env6968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6967_6968 : H12AffineEnvironment.transform 2 5 env6967 = env6968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env6967 == env6968) = true)

def env6969 : List Nat := [1,4,5,0,0,0,5,4,1,0,4,0,5,0,0,0,5,0,1,0,4,0,0,1,5,0,1,5,0,4,0,1,5,1,5,1]

theorem envBound6969 : H12AffineFastState.Bounded env6969 := by
  intro p hp
  have h : env6969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6968_6969 : H12AffineEnvironment.transform 3 0 env6968 = env6969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6968 == env6969) = true)

theorem identity6969 : scanCanonicalize (H12AffineFastState.compose env6969 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6969 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6970 : List Nat := [1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,0,1,1,0,1,1,0,0,0,1,1,1,1,1]

theorem envBound6970 : H12AffineFastState.Bounded env6970 := by
  intro p hp
  have h : env6970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6969_6970 : H12AffineEnvironment.transform 1 0 env6969 = env6970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6969 == env6970) = true)

def leafEnv6970 : List Nat := [1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,1,1,1,1,0,1,1,1,0,0]

def active6970 : List Nat := []

def tree6970 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6970 : H12WitnessSearch.Good tree6970 := H12GlobalWitnessIndex.good

theorem leafIdentity6970 : H12AffineFastState.composeSystem env6970 rootObs = leafEnv6970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6970 rootObs == leafEnv6970) = true)

theorem terminalChecked6970 : H12PackedTerminal.terminalCheckFast leafEnv6970 active6970 tree6970 = true := by decide +kernel

def env6971 : List Nat := [1,4,5,1,1,1,5,5,0,1,5,0,4,0,0,1,4,1,0,0,5,1,1,1,4,1,0,4,0,5,0,0,4,0,5,0]

theorem envBound6971 : H12AffineFastState.Bounded env6971 := by
  intro p hp
  have h : env6971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6968_6971 : H12AffineEnvironment.transform 3 1 env6968 = env6971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6968 == env6971) = true)

def leafEnv6971 : List Nat := [1,4,5,1,1,1,5,5,0,1,5,0,4,0,0,1,4,1,0,0,5,1,1,1,1,4,1,1,0,4,0,5,0,0,4,0,5,1,5,0,1,1,0]

def active6971 : List Nat := [1]

def tree6971 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6971 : H12WitnessSearch.Good tree6971 := H12GlobalWitnessIndex.good

theorem leafIdentity6971 : H12AffineFastState.composeSystem env6971 rootObs = leafEnv6971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6971 rootObs == leafEnv6971) = true)

theorem terminalChecked6971 : H12PackedTerminal.terminalCheckFast leafEnv6971 active6971 tree6971 = true := by decide +kernel

def env6972 : List Nat := [2,4,8,16,16,16,8,20,512,30,523,1,24,16384,0,19,26,16896,31,0,16410,16,16,2,24,16,16897,26,1,523,14,17,21,17,10,512]

theorem envBound6972 : H12AffineFastState.Bounded env6972 := by
  intro p hp
  have h : env6972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6954_6972 : H12AffineEnvironment.transform 11 1 env6954 = env6972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env6954 == env6972) = true)

theorem identity6972 : scanCanonicalize (H12AffineFastState.compose env6972 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound6972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6973 : List Nat := [2,4,8,9,9,9,8,13,512,7,523,1,1,16384,0,10,3,16896,6,0,16387,9,9,2,1,9,16897,3,1,523,14,8,12,8,10,512]

theorem envBound6973 : H12AffineFastState.Bounded env6973 := by
  intro p hp
  have h : env6973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6972_6973 : H12AffineEnvironment.transform 3 9 env6972 = env6973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env6972 == env6973) = true)

def env6974 : List Nat := [2,4,8,9,9,9,8,13,512,7,523,1,1,520,0,10,3,8,6,0,523,9,9,2,1,9,9,3,1,523,14,8,12,8,10,512]

theorem envBound6974 : H12AffineFastState.Bounded env6974 := by
  intro p hp
  have h : env6974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6973_6974 : H12AffineEnvironment.transform 13 520 env6973 = env6974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 520 env6973 == env6974) = true)

def env6975 : List Nat := [2,4,8,9,9,9,8,13,8,7,3,1,1,0,0,10,3,8,6,0,3,9,9,2,1,9,9,3,1,3,14,8,12,8,10,8]

theorem envBound6975 : H12AffineFastState.Bounded env6975 := by
  intro p hp
  have h : env6975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6974_6975 : H12AffineEnvironment.transform 8 8 env6974 = env6975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env6974 == env6975) = true)

theorem identity6975 : scanCanonicalize (H12AffineFastState.compose env6975 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound6975 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6976 : List Nat := [2,3,8,9,9,9,8,10,8,0,3,1,1,0,0,10,3,8,1,0,3,9,9,2,1,9,9,3,1,3,9,8,11,8,10,8]

theorem envBound6976 : H12AffineFastState.Bounded env6976 := by
  intro p hp
  have h : env6976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6975_6976 : H12AffineEnvironment.transform 1 3 env6975 = env6976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env6975 == env6976) = true)

def env6977 : List Nat := [2,3,0,1,1,1,0,2,0,0,3,1,1,0,0,2,3,0,1,0,3,1,1,2,1,1,1,3,1,3,1,0,3,0,2,0]

theorem envBound6977 : H12AffineFastState.Bounded env6977 := by
  intro p hp
  have h : env6977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6976_6977 : H12AffineEnvironment.transform 2 0 env6976 = env6977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env6976 == env6977) = true)

theorem identity6977 : scanCanonicalize (H12AffineFastState.compose env6977 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound6977 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6978 : List Nat := [1,0,0,1,1,1,0,1,0,0,0,1,1,0,0,1,0,0,1,0,0,1,1,1,1,1,1,0,1,0,1,0,0,0,1,0]

theorem envBound6978 : H12AffineFastState.Bounded env6978 := by
  intro p hp
  have h : env6978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6977_6978 : H12AffineEnvironment.transform 0 1 env6977 = env6978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env6977 == env6978) = true)

def leafEnv6978 : List Nat := [1,0,0,1,1,1,0,1,0,0,0,1,1,0,0,1,0,0,1,0,0,1,1,1,0,1,1,1,1,0,1,0,1,0,0,0,1,1,1,0,1,0,0]

def active6978 : List Nat := []

def tree6978 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6978 : H12WitnessSearch.Good tree6978 := H12GlobalWitnessIndex.good

theorem leafIdentity6978 : H12AffineFastState.composeSystem env6978 rootObs = leafEnv6978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6978 rootObs == leafEnv6978) = true)

theorem terminalChecked6978 : H12PackedTerminal.terminalCheckFast leafEnv6978 active6978 tree6978 = true := by decide +kernel

def env6979 : List Nat := [2,3,1,0,0,0,1,3,1,0,3,1,1,0,0,3,3,1,1,0,3,0,0,2,1,0,0,3,1,3,0,1,2,1,3,1]

theorem envBound6979 : H12AffineFastState.Bounded env6979 := by
  intro p hp
  have h : env6979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6976_6979 : H12AffineEnvironment.transform 2 1 env6976 = env6979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env6976 == env6979) = true)

def leafEnv6979 : List Nat := [2,3,1,0,0,0,1,3,1,0,3,1,1,0,0,3,3,1,1,0,3,0,0,2,1,1,1,0,0,3,1,3,0,1,2,1,2,3,3,1,1,1,0]

def active6979 : List Nat := [0]

def tree6979 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6979 : H12WitnessSearch.Good tree6979 := H12GlobalWitnessIndex.good

theorem leafIdentity6979 : H12AffineFastState.composeSystem env6979 rootObs = leafEnv6979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6979 rootObs == leafEnv6979) = true)

theorem terminalChecked6979 : H12PackedTerminal.terminalCheckFast leafEnv6979 active6979 tree6979 = true := by decide +kernel

def env6980 : List Nat := [2,4,8,9,9,9,8,13,9,7,2,1,1,1,0,10,3,8,6,0,2,9,9,2,1,9,9,3,1,2,14,8,12,8,10,9]

theorem envBound6980 : H12AffineFastState.Bounded env6980 := by
  intro p hp
  have h : env6980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6974_6980 : H12AffineEnvironment.transform 8 9 env6974 = env6980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env6974 == env6980) = true)

theorem identity6980 : scanCanonicalize (H12AffineFastState.compose env6980 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound6980 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6981 : List Nat := [2,4,4,5,5,5,4,1,5,7,2,1,1,1,0,6,3,4,6,0,2,5,5,2,1,5,5,3,1,2,2,4,0,4,6,5]

theorem envBound6981 : H12AffineFastState.Bounded env6981 := by
  intro p hp
  have h : env6981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6980_6981 : H12AffineEnvironment.transform 2 4 env6980 = env6981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env6980 == env6981) = true)

def env6982 : List Nat := [2,0,0,1,1,1,0,1,1,3,2,1,1,1,0,2,3,0,2,0,2,1,1,2,1,1,1,3,1,2,2,0,0,0,2,1]

theorem envBound6982 : H12AffineFastState.Bounded env6982 := by
  intro p hp
  have h : env6982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6981_6982 : H12AffineEnvironment.transform 1 0 env6981 = env6982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6981 == env6982) = true)

def leafEnv6982 : List Nat := [2,0,0,1,1,1,0,1,1,3,2,1,1,1,0,2,3,0,2,0,2,1,1,2,3,1,1,1,1,3,1,2,2,0,0,0,1,2,2,1,1,0,0]

def active6982 : List Nat := [0]

def tree6982 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6982 : H12WitnessSearch.Good tree6982 := H12GlobalWitnessIndex.good

theorem leafIdentity6982 : H12AffineFastState.composeSystem env6982 rootObs = leafEnv6982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6982 rootObs == leafEnv6982) = true)

theorem terminalChecked6982 : H12PackedTerminal.terminalCheckFast leafEnv6982 active6982 tree6982 = true := by decide +kernel

def env6983 : List Nat := [2,1,1,0,0,0,1,1,0,2,2,1,1,1,0,3,3,1,3,0,2,0,0,2,1,0,0,3,1,2,2,1,0,1,3,0]

theorem envBound6983 : H12AffineFastState.Bounded env6983 := by
  intro p hp
  have h : env6983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6981_6983 : H12AffineEnvironment.transform 1 1 env6981 = env6983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6981 == env6983) = true)

theorem identity6983 : scanCanonicalize (H12AffineFastState.compose env6983 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound6983 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6984 : List Nat := [1,1,1,0,0,0,1,1,0,1,1,1,1,1,0,0,0,1,0,0,1,0,0,1,1,0,0,0,1,1,1,1,0,1,0,0]

theorem envBound6984 : H12AffineFastState.Bounded env6984 := by
  intro p hp
  have h : env6984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6983_6984 : H12AffineEnvironment.transform 0 1 env6983 = env6984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env6983 == env6984) = true)

def leafEnv6984 : List Nat := [1,1,1,0,0,0,1,1,0,1,1,1,1,1,0,0,0,1,0,0,1,0,0,1,0,1,1,0,0,0,1,1,1,1,0,1,0,0,0,0,1,1,0]

def active6984 : List Nat := []

def tree6984 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6984 : H12WitnessSearch.Good tree6984 := H12GlobalWitnessIndex.good

theorem leafIdentity6984 : H12AffineFastState.composeSystem env6984 rootObs = leafEnv6984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6984 rootObs == leafEnv6984) = true)

theorem terminalChecked6984 : H12PackedTerminal.terminalCheckFast leafEnv6984 active6984 tree6984 = true := by decide +kernel

def env6985 : List Nat := [2,4,8,9,9,9,8,13,512,7,523,1,1,521,0,10,3,9,6,0,522,9,9,2,1,9,8,3,1,523,14,8,12,8,10,512]

theorem envBound6985 : H12AffineFastState.Bounded env6985 := by
  intro p hp
  have h : env6985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6973_6985 : H12AffineEnvironment.transform 13 521 env6973 = env6985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 521 env6973 == env6985) = true)

theorem identity6985 : scanCanonicalize (H12AffineFastState.compose env6985 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound6985 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6986 : List Nat := [2,4,8,9,9,9,8,13,3,7,8,1,1,10,0,10,3,9,6,0,9,9,9,2,1,9,8,3,1,8,14,8,12,8,10,3]

theorem envBound6986 : H12AffineFastState.Bounded env6986 := by
  intro p hp
  have h : env6986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6985_6986 : H12AffineEnvironment.transform 8 3 env6985 = env6986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env6985 == env6986) = true)

theorem identity6986 : scanCanonicalize (H12AffineFastState.compose env6986 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6987 : List Nat := [2,1,8,9,9,9,8,8,3,2,8,1,1,10,0,10,3,9,3,0,9,9,9,2,1,9,8,3,1,8,11,8,9,8,10,3]

theorem envBound6987 : H12AffineFastState.Bounded env6987 := by
  intro p hp
  have h : env6987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6986_6987 : H12AffineEnvironment.transform 1 1 env6986 = env6987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6986 == env6987) = true)

theorem identity6987 : scanCanonicalize (H12AffineFastState.compose env6987 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound6987 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6988 : List Nat := [0,1,8,9,9,9,8,8,1,0,8,1,1,8,0,8,1,9,1,0,9,9,9,0,1,9,8,1,1,8,9,8,9,8,8,1]

theorem envBound6988 : H12AffineFastState.Bounded env6988 := by
  intro p hp
  have h : env6988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6987_6988 : H12AffineEnvironment.transform 0 0 env6987 = env6988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env6987 == env6988) = true)

def leafEnv6988 : List Nat := [0,1,8,9,9,9,8,8,1,0,8,1,1,8,0,8,1,9,1,0,9,9,9,0,8,1,1,9,8,1,1,8,9,8,9,8,0,8,8,1,1,8,0]

def active6988 : List Nat := [2]

def tree6988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6988 : H12WitnessSearch.Good tree6988 := H12GlobalWitnessIndex.good

theorem leafIdentity6988 : H12AffineFastState.composeSystem env6988 rootObs = leafEnv6988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6988 rootObs == leafEnv6988) = true)

theorem terminalChecked6988 : H12PackedTerminal.terminalCheckFast leafEnv6988 active6988 tree6988 = true := by decide +kernel

def env6989 : List Nat := [2,4,8,16,32,17,9,36,512,47,523,4096,41,16384,0,35,4122,20992,47,0,16410,32,17,3,40,16,20992,4122,4096,522,14,32,36,32,4107,512]

theorem envBound6989 : H12AffineFastState.Bounded env6989 := by
  intro p hp
  have h : env6989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6952_6989 : H12AffineEnvironment.transform 5 17 env6952 = env6989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6952 == env6989) = true)

theorem identity6989 : scanCanonicalize (H12AffineFastState.compose env6989 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4154) := by decide +kernel

theorem selectedBound6989 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6990 : List Nat := [2,4,8,16,32,17,9,36,512,47,523,4096,41,4154,0,35,4122,570,47,0,4128,32,17,3,40,16,570,4122,4096,522,14,32,36,32,4107,512]

theorem envBound6990 : H12AffineFastState.Bounded env6990 := by
  intro p hp
  have h : env6990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6989_6990 : H12AffineEnvironment.transform 13 4154 env6989 = env6990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4154 env6989 == env6990) = true)

def env6991 : List Nat := [2,4,8,16,32,17,9,36,512,47,523,48,41,10,0,35,42,570,47,0,16,32,17,3,40,16,570,42,48,522,14,32,36,32,59,512]

theorem envBound6991 : H12AffineFastState.Bounded env6991 := by
  intro p hp
  have h : env6991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6990_6991 : H12AffineEnvironment.transform 11 48 env6990 = env6991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env6990 == env6991) = true)

theorem identity6991 : scanCanonicalize (H12AffineFastState.compose env6991 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound6991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6992 : List Nat := [2,4,8,16,32,17,9,36,25,47,18,48,41,10,0,35,42,35,47,0,16,32,17,3,40,16,35,42,48,19,14,32,36,32,59,25]

theorem envBound6992 : H12AffineFastState.Bounded env6992 := by
  intro p hp
  have h : env6992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6991_6992 : H12AffineEnvironment.transform 8 25 env6991 = env6992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env6991 == env6992) = true)

def env6993 : List Nat := [2,4,8,16,16,17,9,20,25,31,18,0,25,10,0,19,26,19,31,0,16,16,17,3,24,16,19,26,0,19,14,16,20,16,11,25]

theorem envBound6993 : H12AffineFastState.Bounded env6993 := by
  intro p hp
  have h : env6993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6992_6993 : H12AffineEnvironment.transform 4 16 env6992 = env6993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6992 == env6993) = true)

theorem identity6993 : scanCanonicalize (H12AffineFastState.compose env6993 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound6993 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6994 : List Nat := [0,4,8,16,16,17,9,20,25,29,16,0,25,8,0,17,24,17,29,0,16,16,17,1,24,16,17,24,0,17,12,16,20,16,9,25]

theorem envBound6994 : H12AffineFastState.Bounded env6994 := by
  intro p hp
  have h : env6994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6993_6994 : H12AffineEnvironment.transform 0 0 env6993 = env6994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env6993 == env6994) = true)

theorem identity6994 : scanCanonicalize (H12AffineFastState.compose env6994 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound6994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6995 : List Nat := [0,4,8,5,5,4,9,1,12,8,5,0,12,8,0,4,13,4,8,0,5,5,4,1,13,5,4,13,0,4,12,5,1,5,9,12]

theorem envBound6995 : H12AffineFastState.Bounded env6995 := by
  intro p hp
  have h : env6995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6994_6995 : H12AffineEnvironment.transform 3 5 env6994 = env6995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6994 == env6995) = true)

def leafEnv6995 : List Nat := [0,4,8,5,5,4,9,1,12,8,5,0,12,8,0,4,13,4,8,0,5,5,4,1,12,13,1,5,4,13,0,4,12,5,1,5,4,5,9,12,1,5,0]

def active6995 : List Nat := [1,2]

def tree6995 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6995 : H12WitnessSearch.Good tree6995 := H12GlobalWitnessIndex.good

theorem leafIdentity6995 : H12AffineFastState.composeSystem env6995 rootObs = leafEnv6995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6995 rootObs == leafEnv6995) = true)

theorem terminalChecked6995 : H12PackedTerminal.terminalCheckFast leafEnv6995 active6995 tree6995 = true := by decide +kernel

def env6996 : List Nat := [2,4,8,16,17,17,9,21,25,30,18,1,24,10,0,18,27,18,30,0,16,17,17,3,25,16,18,27,1,19,14,17,21,17,10,25]

theorem envBound6996 : H12AffineFastState.Bounded env6996 := by
  intro p hp
  have h : env6996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6992_6996 : H12AffineEnvironment.transform 4 17 env6992 = env6996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6992 == env6996) = true)

theorem identity6996 : scanCanonicalize (H12AffineFastState.compose env6996 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound6996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6997 : List Nat := [2,4,8,9,8,8,9,12,0,7,11,1,1,10,0,11,2,11,7,0,9,8,8,3,0,9,11,2,1,10,14,8,12,8,10,0]

theorem envBound6997 : H12AffineFastState.Bounded env6997 := by
  intro p hp
  have h : env6997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6996_6997 : H12AffineEnvironment.transform 3 9 env6996 = env6997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env6996 == env6997) = true)

theorem identity6997 : scanCanonicalize (H12AffineFastState.compose env6997 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6998 : List Nat := [2,1,8,9,8,8,9,9,0,2,11,1,1,10,0,11,2,11,2,0,9,8,8,3,0,9,11,2,1,10,11,8,9,8,10,0]

theorem envBound6998 : H12AffineFastState.Bounded env6998 := by
  intro p hp
  have h : env6998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6997_6998 : H12AffineEnvironment.transform 1 1 env6997 = env6998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6997 == env6998) = true)

def leafEnv6998 : List Nat := [2,1,8,9,8,8,9,9,0,2,11,1,1,10,0,11,2,11,2,0,9,8,8,3,11,0,1,9,11,2,1,10,11,8,9,8,1,10,10,0,1,8,0]

def active6998 : List Nat := [0,2]

def tree6998 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6998 : H12WitnessSearch.Good tree6998 := H12GlobalWitnessIndex.good

theorem leafIdentity6998 : H12AffineFastState.composeSystem env6998 rootObs = leafEnv6998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6998 rootObs == leafEnv6998) = true)

theorem terminalChecked6998 : H12PackedTerminal.terminalCheckFast leafEnv6998 active6998 tree6998 = true := by decide +kernel

def env6999 : List Nat := [2,4,8,16,32,17,9,36,512,47,523,49,41,11,0,35,43,570,47,0,17,32,17,3,40,16,570,43,49,522,14,32,36,32,58,512]

theorem envBound6999 : H12AffineFastState.Bounded env6999 := by
  intro p hp
  have h : env6999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6990_6999 : H12AffineEnvironment.transform 11 49 env6990 = env6999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env6990 == env6999) = true)

theorem identity6999 : scanCanonicalize (H12AffineFastState.compose env6999 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound6999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7000 : List Nat := [2,4,8,16,32,17,9,36,3,47,8,49,41,11,0,35,43,57,47,0,17,32,17,3,40,16,57,43,49,9,14,32,36,32,58,3]

theorem envBound7000 : H12AffineFastState.Bounded env7000 := by
  intro p hp
  have h : env7000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6999_7000 : H12AffineEnvironment.transform 8 3 env6999 = env7000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env6999 == env7000) = true)

def env7001 : List Nat := [2,4,8,16,16,17,9,20,3,31,8,1,25,11,0,19,27,9,31,0,17,16,17,3,24,16,9,27,1,9,14,16,20,16,10,3]

theorem envBound7001 : H12AffineFastState.Bounded env7001 := by
  intro p hp
  have h : env7001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7000_7001 : H12AffineEnvironment.transform 4 16 env7000 = env7001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env7000 == env7001) = true)

theorem identity7001 : scanCanonicalize (H12AffineFastState.compose env7001 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound7001 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7002 : List Nat := [2,4,8,9,9,8,9,13,3,6,8,1,0,11,0,10,2,9,6,0,8,9,8,3,1,9,9,2,1,9,14,9,13,9,10,3]

theorem envBound7002 : H12AffineFastState.Bounded env7002 := by
  intro p hp
  have h : env7002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7001_7002 : H12AffineEnvironment.transform 3 9 env7001 = env7002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env7001 == env7002) = true)

theorem identity7002 : scanCanonicalize (H12AffineFastState.compose env7002 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound7002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7003 : List Nat := [2,4,7,6,6,7,6,2,3,6,7,1,0,4,0,5,2,6,6,0,7,6,7,3,1,6,6,2,1,6,1,6,2,6,5,3]

theorem envBound7003 : H12AffineFastState.Bounded env7003 := by
  intro p hp
  have h : env7003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7002_7003 : H12AffineEnvironment.transform 2 7 env7002 = env7003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env7002 == env7003) = true)

def leafEnv7003 : List Nat := [2,4,7,6,6,7,6,2,3,6,7,1,0,4,0,5,2,6,6,0,7,6,7,3,1,1,1,6,6,2,1,6,1,6,2,6,4,4,5,3,1,7,0]

def active7003 : List Nat := [0,1]

def tree7003 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7003 : H12WitnessSearch.Good tree7003 := H12GlobalWitnessIndex.good

theorem leafIdentity7003 : H12AffineFastState.composeSystem env7003 rootObs = leafEnv7003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7003 rootObs == leafEnv7003) = true)

theorem terminalChecked7003 : H12PackedTerminal.terminalCheckFast leafEnv7003 active7003 tree7003 = true := by decide +kernel

def env7004 : List Nat := [2,4,8,16,17,17,9,21,3,30,8,0,24,11,0,18,26,8,30,0,17,17,17,3,25,16,8,26,0,9,14,17,21,17,11,3]

theorem envBound7004 : H12AffineFastState.Bounded env7004 := by
  intro p hp
  have h : env7004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7000_7004 : H12AffineEnvironment.transform 4 17 env7000 = env7004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env7000 == env7004) = true)

theorem identity7004 : scanCanonicalize (H12AffineFastState.compose env7004 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound7004 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7005 : List Nat := [0,4,8,16,17,17,9,21,1,28,8,0,24,9,0,16,24,8,28,0,17,17,17,1,25,16,8,24,0,9,12,17,21,17,9,1]

theorem envBound7005 : H12AffineFastState.Bounded env7005 := by
  intro p hp
  have h : env7005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7004_7005 : H12AffineEnvironment.transform 0 0 env7004 = env7005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env7004 == env7005) = true)

theorem identity7005 : scanCanonicalize (H12AffineFastState.compose env7005 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound7005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7006 : List Nat := [0,4,8,13,12,12,9,8,1,1,8,0,5,9,0,13,5,8,1,0,12,12,12,1,4,13,8,5,0,9,12,12,8,12,9,1]

theorem envBound7006 : H12AffineFastState.Bounded env7006 := by
  intro p hp
  have h : env7006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7005_7006 : H12AffineEnvironment.transform 3 13 env7005 = env7006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env7005 == env7006) = true)

def leafEnv7006 : List Nat := [0,4,8,13,12,12,9,8,1,1,8,0,5,9,0,13,5,8,1,0,12,12,12,1,12,4,1,13,8,5,0,9,12,12,8,12,4,12,9,1,1,13,0]

def active7006 : List Nat := [1,2]

def tree7006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7006 : H12WitnessSearch.Good tree7006 := H12GlobalWitnessIndex.good

theorem leafIdentity7006 : H12AffineFastState.composeSystem env7006 rootObs = leafEnv7006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7006 rootObs == leafEnv7006) = true)

theorem terminalChecked7006 : H12PackedTerminal.terminalCheckFast leafEnv7006 active7006 tree7006 = true := by decide +kernel

def env7007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,16384,509,478,5393,262144,524288,509,17728,32,525804,375,41,525757,262281,5392,4097,2185,1364,341,525568,168,34359738368,512]

theorem envBound7007 : H12AffineFastState.Bounded env7007 := by
  intro p hp
  have h : env7007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6944_7007 : H12AffineEnvironment.transform 12 161 env6944 = env7007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env6944 == env7007) = true)

def env7008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,524288,8541,2097152,33,8388608,8988132,8328,599234,336375,11105475,11232451,8989722,74794,73770,525568,8987707,34359738368,74622]

theorem envBound7008 : H12AffineFastState.Bounded env7008 := by
  intro p hp
  have h : env7008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6932_7008 : H12AffineEnvironment.transform 14 8541 env6932 = env7008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env6932 == env7008) = true)

def env7009 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,33,8388608,8987672,8328,599234,335883,11105475,11232451,8989722,74794,73770,525564,8987707,34359738368,74370]

theorem envBound7009 : H12AffineFastState.Bounded env7009 := by
  intro p hp
  have h : env7009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7008_7009 : H12AffineEnvironment.transform 7 252 env7008 = env7009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7008 == env7009) = true)

theorem identity7009 : scanCanonicalize (H12AffineFastState.compose env7009 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound7009 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7010 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262281,11031617,11158593,8916120,1192,168,525564,8914105,34359738368,512]

theorem envBound7010 : H12AffineFastState.Bounded env7010 := by
  intro p hp
  have h : env7010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7009_7010 : H12AffineEnvironment.transform 15 8322 env7009 = env7010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env7009 == env7010) = true)

theorem identity7010 : scanCanonicalize (H12AffineFastState.compose env7010 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound7010 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7011 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,5357,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262281,11031617,11030700,8916120,1192,168,525564,8914105,34359738368,512]

theorem envBound7011 : H12AffineFastState.Bounded env7011 := by
  intro p hp
  have h : env7011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7010_7011 : H12AffineEnvironment.transform 16 5357 env7010 = env7011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env7010 == env7011) = true)

theorem identity7011 : scanCanonicalize (H12AffineFastState.compose env7011 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 24736) := by decide +kernel

theorem selectedBound7011 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env7012 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8322,5357,262144,524288,8353,2097152,33,8388608,8914074,8328,525376,262281,11031617,11030700,8916120,1192,168,525564,8914105,24736,512]

theorem envBound7012 : H12AffineFastState.Bounded env7012 := by
  intro p hp
  have h : env7012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7011_7012 : H12AffineEnvironment.transform 34 24736 env7011 = env7012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 24736 env7011 == env7012) = true)

theorem identity7012 : scanCanonicalize (H12AffineFastState.compose env7012 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound7012 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env7013 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,34,5357,262144,524288,1,2097152,33,8388608,8914074,40,525376,262281,11031617,11030700,8916120,1192,168,525564,8914105,16384,512]

theorem envBound7013 : H12AffineFastState.Bounded env7013 := by
  intro p hp
  have h : env7013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7012_7013 : H12AffineEnvironment.transform 12 160 env7012 = env7013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7012 == env7013) = true)

def env7014 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,33,8388608,8987673,8328,599234,335882,11105475,11232451,8989722,74794,73770,525565,8987707,34359738368,74371]

theorem envBound7014 : H12AffineFastState.Bounded env7014 := by
  intro p hp
  have h : env7014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7008_7014 : H12AffineEnvironment.transform 7 253 env7008 = env7014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7008 == env7014) = true)

def env7015 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,2097152,33,8388608,8987673,8192,599114,335882,11105355,11232331,8989722,74794,73770,525429,8987707,34359738368,74251]

theorem envBound7015 : H12AffineFastState.Bounded env7015 := by
  intro p hp
  have h : env7015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7014_7015 : H12AffineEnvironment.transform 6 8 env7014 = env7015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env7014 == env7015) = true)

theorem identity7015 : scanCanonicalize (H12AffineFastState.compose env7015 (packedSelected [0,2,6,11,12,14,23,27,38] rootPS)) = affineNative (2^(34+1) ^^^ 10885136) := by decide +kernel

theorem selectedBound7015 : packedSelected [0,2,6,11,12,14,23,27,38] rootPS < 2^1333 := by decide +kernel

def env7016 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,2097152,33,8388608,8987673,8192,599114,335882,11105355,11232331,8989722,74794,73770,525429,8987707,10885136,74251]

theorem envBound7016 : H12AffineFastState.Bounded env7016 := by
  intro p hp
  have h : env7016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7015_7016 : H12AffineEnvironment.transform 34 10885136 env7015 = env7016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 10885136 env7015 == env7016) = true)

def env7017 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927756,33,8388608,8987673,8192,599114,335882,8870983,8735815,8989722,74794,73770,525429,8987707,8925212,74251]

theorem envBound7017 : H12AffineFastState.Bounded env7017 := by
  intro p hp
  have h : env7017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7016_7017 : H12AffineEnvironment.transform 20 927756 env7016 = env7017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 927756 env7016 == env7017) = true)

def env7018 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927756,33,525328,73737,8192,599114,335882,1005655,870487,75786,74794,73770,525429,73771,13324,74251]

theorem envBound7018 : H12AffineFastState.Bounded env7018 := by
  intro p hp
  have h : env7018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7017_7018 : H12AffineEnvironment.transform 22 525328 env7017 = env7018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env7017 == env7018) = true)

theorem identity7018 : scanCanonicalize (H12AffineFastState.compose env7018 (packedSelected [13] rootPS)) = affineNative (2^(18+1) ^^^ 284788) := by decide +kernel

theorem selectedBound7018 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7019 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,284788,8232,159864,33,285796,73737,8192,359486,335882,196643,69667,75786,74794,73770,285697,73771,13324,74251]

theorem envBound7019 : H12AffineFastState.Bounded env7019 := by
  intro p hp
  have h : env7019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7018_7019 : H12AffineEnvironment.transform 18 284788 env7018 = env7019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 284788 env7018 == env7019) = true)

theorem identity7019 : scanCanonicalize (H12AffineFastState.compose env7019 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound7019 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env7020 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,2048,20596,8232,159864,33,21604,73737,8192,95294,75786,196643,69667,75786,74794,73770,21505,73771,13324,74251]

theorem envBound7020 : H12AffineFastState.Bounded env7020 := by
  intro p hp
  have h : env7020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7019_7020 : H12AffineEnvironment.transform 17 2048 env7019 = env7020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env7019 == env7020) = true)

theorem identity7020 : scanCanonicalize (H12AffineFastState.compose env7020 (packedSelected [1,2,3,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound7020 : packedSelected [1,2,3,11,14,18] rootPS < 2^1333 := by decide +kernel

def env7021 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,8202,131072,2048,20596,8232,159864,33,21604,3,8192,21556,2048,139305,12329,2048,1056,32,21505,33,13324,513]

theorem envBound7021 : H12AffineFastState.Bounded env7021 := by
  intro p hp
  have h : env7021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7020_7021 : H12AffineEnvironment.transform 15 8202 env7020 = env7021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env7020 == env7021) = true)

def env7022 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927756,33,525329,73736,8192,599114,335882,1005654,870486,75787,74794,73770,525429,73770,13325,74251]

theorem envBound7022 : H12AffineFastState.Bounded env7022 := by
  intro p hp
  have h : env7022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7017_7022 : H12AffineEnvironment.transform 22 525329 env7017 = env7022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env7017 == env7022) = true)

theorem identity7022 : scanCanonicalize (H12AffineFastState.compose env7022 (packedSelected [13] rootPS)) = affineNative (2^(18+1) ^^^ 420921) := by decide +kernel

theorem selectedBound7022 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7023 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,420921,8232,17461,33,419880,73736,8192,477299,335882,78959,205935,75787,74794,73770,419916,73770,13325,74251]

theorem envBound7023 : H12AffineFastState.Bounded env7023 := by
  intro p hp
  have h : env7023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7022_7023 : H12AffineEnvironment.transform 18 420921 env7022 = env7023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 420921 env7022 == env7023) = true)

theorem identity7023 : scanCanonicalize (H12AffineFastState.compose env7023 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound7023 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env7024 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,5220,262144,292957,8232,17461,33,293964,73736,8192,351255,335882,78959,77835,75787,74794,73770,293928,73770,13325,74251]

theorem envBound7024 : H12AffineFastState.Bounded env7024 := by
  intro p hp
  have h : env7024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7023_7024 : H12AffineEnvironment.transform 16 5220 env7023 = env7024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env7023 == env7024) = true)

theorem identity7024 : scanCanonicalize (H12AffineFastState.compose env7024 (packedSelected [3,5,10,12,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound7024 : packedSelected [3,5,10,12,15,21] rootPS < 2^1333 := by decide +kernel

def env7025 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,5220,97327,66674,8232,17461,33,65635,73736,8192,8248,23589,78959,77835,75787,74794,73770,65543,73770,13325,74251]

theorem envBound7025 : H12AffineFastState.Bounded env7025 := by
  intro p hp
  have h : env7025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7024_7025 : H12AffineEnvironment.transform 17 97327 env7024 = env7025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env7024 == env7025) = true)

theorem identity7025 : scanCanonicalize (H12AffineFastState.compose env7025 (packedSelected [0,1,4,5,7,9,10,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound7025 : packedSelected [0,1,4,5,7,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env7026 : List Nat := [2,4,8,16,32,64,8,117,512,1024,545,4096,8192,16384,8232,65536,5220,95758,66674,8232,17461,33,65635,73736,8192,8248,22020,78959,77835,74282,74794,73770,65543,73770,13325,74251]

theorem envBound7026 : H12AffineFastState.Bounded env7026 := by
  intro p hp
  have h : env7026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7025_7026 : H12AffineEnvironment.transform 10 545 env7025 = env7026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env7025 == env7026) = true)

theorem identity7026 : scanCanonicalize (H12AffineFastState.compose env7026 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound7026 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env7027 : List Nat := [2,4,8,16,32,64,8,117,512,1024,545,4096,8192,16384,8232,35,5220,30253,1105,8232,17461,33,64,8235,8192,8248,22020,13388,12328,8713,9225,8201,36,8201,13325,8744]

theorem envBound7027 : H12AffineFastState.Bounded env7027 := by
  intro p hp
  have h : env7027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7026_7027 : H12AffineEnvironment.transform 15 35 env7026 = env7027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env7026 == env7027) = true)

theorem identity7027 : scanCanonicalize (H12AffineFastState.compose env7027 (packedSelected [0,4,6,7,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12313) := by decide +kernel

theorem selectedBound7027 : packedSelected [0,4,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env7028 : List Nat := [2,4,8,16,32,64,8,117,512,1024,545,4096,8192,12313,8232,35,5220,1588,1105,8232,13356,33,64,8235,8192,8248,9757,13388,12328,8713,9225,8201,36,8201,13325,8744]

theorem envBound7028 : H12AffineFastState.Bounded env7028 := by
  intro p hp
  have h : env7028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7027_7028 : H12AffineEnvironment.transform 13 12313 env7027 = env7028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12313 env7027 == env7028) = true)

theorem identity7028 : scanCanonicalize (H12AffineFastState.compose env7028 (packedSelected [1,2,3,6,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7028 : packedSelected [1,2,3,6,11] rootPS < 2^1333 := by decide +kernel

def env7029 : List Nat := [2,4,8,16,1,64,8,84,512,1024,512,4096,8192,12313,8201,2,5189,1557,1105,8201,13325,0,64,8202,8192,8217,9757,13388,12297,8713,9225,8201,5,8201,13325,8713]

theorem envBound7029 : H12AffineFastState.Bounded env7029 := by
  intro p hp
  have h : env7029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7028_7029 : H12AffineEnvironment.transform 4 1 env7028 = env7029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7028 == env7029) = true)

theorem identity7029 : scanCanonicalize (H12AffineFastState.compose env7029 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound7029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7030 : List Nat := [2,4,8,16,1,64,8,84,512,1024,512,529,8192,8712,8201,2,1620,1557,1105,8201,9756,0,64,8202,8192,8217,9757,9821,8728,8713,9225,8201,5,8201,9756,8713]

theorem envBound7030 : H12AffineFastState.Bounded env7030 := by
  intro p hp
  have h : env7030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7029_7030 : H12AffineEnvironment.transform 11 529 env7029 = env7030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env7029 == env7030) = true)

theorem identity7030 : scanCanonicalize (H12AffineFastState.compose env7030 (packedSelected [0,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound7030 : packedSelected [0,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env7031 : List Nat := [2,4,8,16,1,64,8,84,512,1024,512,529,1053,1557,1044,2,1620,1557,1105,1044,513,0,64,1047,1053,1028,512,576,1541,1556,20,1044,5,1044,513,1556]

theorem envBound7031 : H12AffineFastState.Bounded env7031 := by
  intro p hp
  have h : env7031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7030_7031 : H12AffineEnvironment.transform 12 1053 env7030 = env7031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env7030 == env7031) = true)

theorem identity7031 : scanCanonicalize (H12AffineFastState.compose env7031 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound7031 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env7032 : List Nat := [2,4,8,16,1,18,8,6,512,1024,512,529,1053,1557,1044,2,1542,1557,1027,1044,513,0,18,1047,1053,1028,512,530,1541,1556,20,1044,5,1044,513,1556]

theorem envBound7032 : H12AffineFastState.Bounded env7032 := by
  intro p hp
  have h : env7032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7031_7032 : H12AffineEnvironment.transform 5 18 env7031 = env7032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env7031 == env7032) = true)

theorem identity7032 : scanCanonicalize (H12AffineFastState.compose env7032 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound7032 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env7033 : List Nat := [2,4,8,16,1,18,8,6,24,1024,24,9,1053,1037,1044,2,1054,1037,1027,1044,25,0,18,1047,1053,1028,24,10,1053,1036,20,1044,5,1044,25,1036]

theorem envBound7033 : H12AffineFastState.Bounded env7033 := by
  intro p hp
  have h : env7033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7032_7033 : H12AffineEnvironment.transform 8 24 env7032 = env7033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env7032 == env7033) = true)

theorem identity7033 : scanCanonicalize (H12AffineFastState.compose env7033 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound7033 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7034 : List Nat := [2,4,8,16,1,18,8,6,24,5,24,9,24,8,17,2,27,8,6,17,25,0,18,18,24,1,24,10,24,9,20,17,5,17,25,9]

theorem envBound7034 : H12AffineFastState.Bounded env7034 := by
  intro p hp
  have h : env7034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7033_7034 : H12AffineEnvironment.transform 9 5 env7033 = env7034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env7033 == env7034) = true)

theorem identity7034 : scanCanonicalize (H12AffineFastState.compose env7034 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound7034 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env7035 : List Nat := [2,4,1,16,1,18,1,6,17,5,17,0,17,1,17,2,18,1,6,17,16,0,18,18,17,1,17,3,17,0,20,17,5,17,16,0]

theorem envBound7035 : H12AffineFastState.Bounded env7035 := by
  intro p hp
  have h : env7035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7034_7035 : H12AffineEnvironment.transform 2 1 env7034 = env7035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env7034 == env7035) = true)

theorem identity7035 : scanCanonicalize (H12AffineFastState.compose env7035 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound7035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7036 : List Nat := [2,4,1,0,1,2,1,6,1,5,1,0,1,1,1,2,2,1,6,1,0,0,2,2,1,1,1,3,1,0,4,1,5,1,0,0]

theorem envBound7036 : H12AffineFastState.Bounded env7036 := by
  intro p hp
  have h : env7036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7035_7036 : H12AffineEnvironment.transform 3 0 env7035 = env7036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env7035 == env7036) = true)

theorem identity7036 : scanCanonicalize (H12AffineFastState.compose env7036 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound7036 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env7037 : List Nat := [0,4,1,0,1,0,1,4,1,5,1,0,1,1,1,0,0,1,4,1,0,0,0,0,1,1,1,1,1,0,4,1,5,1,0,0]

theorem envBound7037 : H12AffineFastState.Bounded env7037 := by
  intro p hp
  have h : env7037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7036_7037 : H12AffineEnvironment.transform 0 0 env7036 = env7037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env7036 == env7037) = true)

def env7038 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927757,33,8388608,8987673,8192,599114,335882,8870982,8735814,8989722,74794,73770,525429,8987707,8925213,74251]

theorem envBound7038 : H12AffineFastState.Bounded env7038 := by
  intro p hp
  have h : env7038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7016_7038 : H12AffineEnvironment.transform 20 927757 env7016 = env7038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 927757 env7016 == env7038) = true)

def env7039 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927757,33,525328,73737,8192,599114,335882,1005654,870486,75786,74794,73770,525429,73771,13325,74251]

theorem envBound7039 : H12AffineFastState.Bounded env7039 := by
  intro p hp
  have h : env7039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7038_7039 : H12AffineEnvironment.transform 22 525328 env7038 = env7039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env7038 == env7039) = true)

theorem identity7039 : scanCanonicalize (H12AffineFastState.compose env7039 (packedSelected [13] rootPS)) = affineNative (2^(18+1) ^^^ 358526) := by decide +kernel

theorem selectedBound7039 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7040 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,358526,8232,217203,33,359534,73737,8192,285748,335882,139304,12328,75786,74794,73770,359435,73771,13325,74251]

theorem envBound7040 : H12AffineFastState.Bounded env7040 := by
  intro p hp
  have h : env7040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7039_7040 : H12AffineEnvironment.transform 18 358526 env7039 = env7040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 358526 env7039 == env7040) = true)

theorem identity7040 : scanCanonicalize (H12AffineFastState.compose env7040 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound7040 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env7041 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,2048,94334,8232,217203,33,95342,73737,8192,21556,75786,139304,12328,75786,74794,73770,95243,73771,13325,74251]

theorem envBound7041 : H12AffineFastState.Bounded env7041 := by
  intro p hp
  have h : env7041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7040_7041 : H12AffineEnvironment.transform 17 2048 env7040 = env7041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env7040 == env7041) = true)

theorem identity7041 : scanCanonicalize (H12AffineFastState.compose env7041 (packedSelected [1,2,3,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound7041 : packedSelected [1,2,3,11,14,18] rootPS < 2^1333 := by decide +kernel

def env7042 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,8202,131072,2048,20596,8232,159865,33,21604,3,8192,21556,2048,139304,12328,2048,1056,32,21505,33,13325,513]

theorem envBound7042 : H12AffineFastState.Bounded env7042 := by
  intro p hp
  have h : env7042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7041_7042 : H12AffineEnvironment.transform 15 8202 env7041 = env7042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env7041 == env7042) = true)

def env7043 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,524288,8232,927757,33,525329,73736,8192,599114,335882,1005655,870487,75787,74794,73770,525429,73770,13324,74251]

theorem envBound7043 : H12AffineFastState.Bounded env7043 := by
  intro p hp
  have h : env7043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7038_7043 : H12AffineEnvironment.transform 22 525329 env7038 = env7043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env7038 == env7043) = true)

theorem identity7043 : scanCanonicalize (H12AffineFastState.compose env7043 (packedSelected [13] rootPS)) = affineNative (2^(18+1) ^^^ 478259) := by decide +kernel

theorem selectedBound7043 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7044 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,131072,262144,478259,8232,91198,33,477218,73736,8192,419961,335882,5220,132196,75787,74794,73770,477254,73770,13324,74251]

theorem envBound7044 : H12AffineFastState.Bounded env7044 := by
  intro p hp
  have h : env7044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7043_7044 : H12AffineEnvironment.transform 18 478259 env7043 = env7044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 478259 env7043 == env7044) = true)

theorem identity7044 : scanCanonicalize (H12AffineFastState.compose env7044 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound7044 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env7045 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,78959,262144,292956,8232,91198,33,293965,73736,8192,351254,335882,5220,77835,75787,74794,73770,293929,73770,13324,74251]

theorem envBound7045 : H12AffineFastState.Bounded env7045 := by
  intro p hp
  have h : env7045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7044_7045 : H12AffineEnvironment.transform 16 78959 env7044 = env7045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env7044 == env7045) = true)

theorem identity7045 : scanCanonicalize (H12AffineFastState.compose env7045 (packedSelected [3,5,10,12,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound7045 : packedSelected [3,5,10,12,15,21] rootPS < 2^1333 := by decide +kernel

def env7046 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,65536,78959,97326,66674,8232,91198,33,65635,73736,8192,8248,23588,5220,77835,75787,74794,73770,65543,73770,13324,74251]

theorem envBound7046 : H12AffineFastState.Bounded env7046 := by
  intro p hp
  have h : env7046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7045_7046 : H12AffineEnvironment.transform 17 97326 env7045 = env7046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env7045 == env7046) = true)

theorem identity7046 : scanCanonicalize (H12AffineFastState.compose env7046 (packedSelected [0,1,3,4,7,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 10794) := by decide +kernel

theorem selectedBound7046 : packedSelected [0,1,3,4,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env7047 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,10794,7749,22020,11864,8232,19988,33,10825,2594,8192,8248,23588,5220,6689,545,3584,2560,10797,2560,13324,2081]

theorem envBound7047 : H12AffineFastState.Bounded env7047 := by
  intro p hp
  have h : env7047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7046_7047 : H12AffineEnvironment.transform 15 10794 env7046 = env7047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10794 env7046 == env7047) = true)

theorem identity7047 : scanCanonicalize (H12AffineFastState.compose env7047 (packedSelected [1,2,3,6,11,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound7047 : packedSelected [1,2,3,6,11,12,18] rootPS < 2^1333 := by decide +kernel

def env7048 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,0,2562,7749,22020,3696,0,19988,33,2657,2594,40,16,23588,5220,6689,545,3584,2560,2565,2560,5156,2081]

theorem envBound7048 : H12AffineFastState.Bounded env7048 := by
  intro p hp
  have h : env7048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7047_7048 : H12AffineEnvironment.transform 12 40 env7047 = env7048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env7047 == env7048) = true)

theorem identity7048 : scanCanonicalize (H12AffineFastState.compose env7048 (packedSelected [0,1,2,3,4,7,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 6673) := by decide +kernel

theorem selectedBound7048 : packedSelected [0,1,2,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env7049 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,6673,0,2562,7749,3093,3696,0,5125,33,2657,2594,40,16,1589,5220,6689,545,3584,2560,2565,2560,5156,2081]

theorem envBound7049 : H12AffineFastState.Bounded env7049 := by
  intro p hp
  have h : env7049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7048_7049 : H12AffineEnvironment.transform 13 6673 env7048 = env7049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6673 env7048 == env7049) = true)

theorem identity7049 : scanCanonicalize (H12AffineFastState.compose env7049 (packedSelected [0,1,2,4,5,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound7049 : packedSelected [0,1,2,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env7050 : List Nat := [2,4,8,16,0,64,8,85,512,1024,2048,4096,8,6673,0,2562,7749,3093,3664,0,5125,1,2625,2562,8,16,1557,5188,6657,513,3584,2560,2565,2560,5124,2049]

theorem envBound7050 : H12AffineFastState.Bounded env7050 := by
  intro p hp
  have h : env7050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7049_7050 : H12AffineEnvironment.transform 4 0 env7049 = env7050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env7049 == env7050) = true)

def env7051 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,65536,131072,262144,524288,8233,2097152,33,8388608,8987673,8193,599115,335882,11105354,11232330,8989722,74794,73770,525428,8987707,34359738368,74250]

theorem envBound7051 : H12AffineFastState.Bounded env7051 := by
  intro p hp
  have h : env7051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7014_7051 : H12AffineEnvironment.transform 6 9 env7014 = env7051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env7014 == env7051) = true)

theorem identity7051 : scanCanonicalize (H12AffineFastState.compose env7051 (packedSelected [0,2,6,11,12,14,23,27,38] rootPS)) = affineNative (2^(34+1) ^^^ 10958875) := by decide +kernel

theorem selectedBound7051 : packedSelected [0,2,6,11,12,14,23,27,38] rootPS < 2^1333 := by decide +kernel

def env7052 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,65536,131072,262144,524288,8233,2097152,33,8388608,8987673,8193,599115,335882,11105354,11232330,8989722,74794,73770,525428,8987707,10958875,74250]

theorem envBound7052 : H12AffineFastState.Bounded env7052 := by
  intro p hp
  have h : env7052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7051_7052 : H12AffineEnvironment.transform 34 10958875 env7051 = env7052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 10958875 env7051 == env7052) = true)

theorem identity7052 : scanCanonicalize (H12AffineFastState.compose env7052 (packedSelected [1,2,3,6,7,9,11,12,15,20,22,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound7052 : packedSelected [1,2,3,6,7,9,11,12,15,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env7053 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8202,131072,262144,524288,8233,2097152,33,8388608,8913939,8193,525377,262144,11031616,11158592,8915984,1056,32,525428,8913969,10885137,512]

theorem envBound7053 : H12AffineFastState.Bounded env7053 := by
  intro p hp
  have h : env7053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7052_7053 : H12AffineEnvironment.transform 15 8202 env7052 = env7053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env7052 == env7053) = true)

theorem identity7053 : scanCanonicalize (H12AffineFastState.compose env7053 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound7053 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7054 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8202,131072,262144,524288,8233,17460,33,8388608,8913939,8193,525377,262144,8917108,9044084,8915984,1056,32,525428,8913969,8805413,512]

theorem envBound7054 : H12AffineFastState.Bounded env7054 := by
  intro p hp
  have h : env7054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7053_7054 : H12AffineEnvironment.transform 20 17460 env7053 = env7054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env7053 == env7054) = true)

theorem identity7054 : scanCanonicalize (H12AffineFastState.compose env7054 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(22+1) ^^^ 525328) := by decide +kernel

theorem selectedBound7054 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env7055 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8202,131072,262144,524288,8233,17460,33,525328,3,8193,525377,262144,5220,132196,2048,1056,32,525428,33,940085,512]

theorem envBound7055 : H12AffineFastState.Bounded env7055 := by
  intro p hp
  have h : env7055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7054_7055 : H12AffineEnvironment.transform 22 525328 env7054 = env7055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env7054 == env7055) = true)

theorem identity7055 : scanCanonicalize (H12AffineFastState.compose env7055 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound7055 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7056 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,8202,5221,262144,524288,8233,17460,33,525328,3,8193,525377,262144,5220,4097,2048,1056,32,525428,33,805968,512]

theorem envBound7056 : H12AffineFastState.Bounded env7056 := by
  intro p hp
  have h : env7056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7055_7056 : H12AffineEnvironment.transform 16 5221 env7055 = env7056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env7055 == env7056) = true)

theorem identity7056 : scanCanonicalize (H12AffineFastState.compose env7056 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3180) := by decide +kernel

theorem selectedBound7056 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env7057 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3180,16384,3141,3174,5221,262144,524288,3141,17460,33,525328,3,3181,525377,262144,5220,4097,2048,1056,32,525428,33,805968,512]

theorem envBound7057 : H12AffineFastState.Bounded env7057 := by
  intro p hp
  have h : env7057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7056_7057 : H12AffineEnvironment.transform 12 3180 env7056 = env7057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3180 env7056 == env7057) = true)

theorem identity7057 : scanCanonicalize (H12AffineFastState.compose env7057 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 1124) := by decide +kernel

theorem selectedBound7057 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7058 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,3180,16384,3141,3174,5221,1124,524288,3141,17460,33,525328,3,3181,525377,1124,5220,4097,2048,1056,32,525428,33,542772,512]

theorem envBound7058 : H12AffineFastState.Bounded env7058 := by
  intro p hp
  have h : env7058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7057_7058 : H12AffineEnvironment.transform 17 1124 env7057 = env7058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1124 env7057 == env7058) = true)

theorem identity7058 : scanCanonicalize (H12AffineFastState.compose env7058 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound7058 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7059 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1092,4096,40,16384,1,34,5221,1124,524288,1,17460,33,525328,3,41,525377,1124,5220,4097,1092,1056,32,525428,33,541808,512]

theorem envBound7059 : H12AffineFastState.Bounded env7059 := by
  intro p hp
  have h : env7059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7058_7059 : H12AffineEnvironment.transform 10 1092 env7058 = env7059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env7058 == env7059) = true)

theorem identity7059 : scanCanonicalize (H12AffineFastState.compose env7059 (packedSelected [0,1,2,3,7,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7059 : packedSelected [0,1,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env7060 : List Nat := [2,4,8,16,1,64,9,85,512,1024,1092,4096,9,16384,1,3,5188,1093,524288,1,17429,0,525328,3,8,525377,1093,5189,4097,1092,1025,1,525397,0,541777,512]

theorem envBound7060 : H12AffineFastState.Bounded env7060 := by
  intro p hp
  have h : env7060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7059_7060 : H12AffineEnvironment.transform 4 1 env7059 = env7060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7059 == env7060) = true)

def env7061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41341,8388608,8988132,8328,599234,360618,11105475,11232451,8989723,99703,73770,525568,8987706,34359738368,98851]

theorem envBound7061 : H12AffineFastState.Bounded env7061 := by
  intro p hp
  have h : env7061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6931_7061 : H12AffineEnvironment.transform 21 41341 env6931 = env7061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env6931 == env7061) = true)

theorem identity7061 : scanCanonicalize (H12AffineFastState.compose env7061 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound7061 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,524288,32768,2097152,41341,8388608,8954938,8328,566556,262516,11072797,11199773,8957381,1193,41460,525568,8955364,34359738368,1021]

theorem envBound7062 : H12AffineFastState.Bounded env7062 := by
  intro p hp
  have h : env7062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7061_7062 : H12AffineEnvironment.transform 15 33246 env7061 = env7062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env7061 == env7062) = true)

theorem identity7062 : scanCanonicalize (H12AffineFastState.compose env7062 (packedSelected [11,13,17,18,23,32] rootPS)) = affineNative (2^(22+1) ^^^ 525329) := by decide +kernel

theorem selectedBound7062 : packedSelected [11,13,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env7063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,524288,32768,2097152,41341,525329,41003,8328,566556,262516,2158860,2285836,43476,1193,41460,525568,41461,34359738368,1021]

theorem envBound7063 : H12AffineFastState.Bounded env7063 := by
  intro p hp
  have h : env7063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7062_7063 : H12AffineEnvironment.transform 22 525329 env7062 = env7063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env7062 == env7063) = true)

theorem identity7063 : scanCanonicalize (H12AffineFastState.compose env7063 (packedSelected [2,11,13,14,17,18] rootPS)) = affineNative (2^(34+1) ^^^ 2798941) := by decide +kernel

theorem selectedBound7063 : packedSelected [2,11,13,14,17,18] rootPS < 2^1333 := by decide +kernel

def env7064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,131072,262144,524288,32768,2097152,41341,525329,41003,8328,566556,262516,2158860,2285836,43476,1193,41460,525568,41461,2798941,1021]

theorem envBound7064 : H12AffineFastState.Bounded env7064 := by
  intro p hp
  have h : env7064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7063_7064 : H12AffineEnvironment.transform 34 2798941 env7063 = env7064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2798941 env7063 == env7064) = true)

theorem identity7064 : scanCanonicalize (H12AffineFastState.compose env7064 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7064 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7065 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,524288,32768,2097152,41089,525329,41003,8328,566496,262280,2158832,2285808,43048,1193,40968,525564,40969,2798753,513]

theorem envBound7065 : H12AffineFastState.Bounded env7065 := by
  intro p hp
  have h : env7065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7064_7065 : H12AffineEnvironment.transform 7 252 env7064 = env7065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7064 == env7065) = true)

theorem identity7065 : scanCanonicalize (H12AffineFastState.compose env7065 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 61532) := by decide +kernel

theorem selectedBound7065 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7066 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,61532,32768,2097152,41089,62541,41003,8328,21692,262280,2158832,2285808,43048,1193,40968,62624,40969,2245885,513]

theorem envBound7066 : H12AffineFastState.Bounded env7066 := by
  intro p hp
  have h : env7066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7065_7066 : H12AffineEnvironment.transform 18 61532 env7065 = env7066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 61532 env7065 == env7066) = true)

theorem identity7066 : scanCanonicalize (H12AffineFastState.compose env7066 (packedSelected [2,13,14] rootPS)) = affineNative (2^(20+1) ^^^ 301208) := by decide +kernel

theorem selectedBound7066 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7067 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,61532,32768,301208,41089,62541,41003,8328,21692,262280,288872,424040,43048,1193,40968,62624,40969,449637,513]

theorem envBound7067 : H12AffineFastState.Bounded env7067 := by
  intro p hp
  have h : env7067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7066_7067 : H12AffineEnvironment.transform 20 301208 env7066 = env7067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301208 env7066 == env7067) = true)

theorem identity7067 : scanCanonicalize (H12AffineFastState.compose env7067 (packedSelected [0,4,6,7,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound7067 : packedSelected [0,4,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env7068 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,16384,32768,32802,131072,262144,53501,32768,301208,32800,54508,32906,41,21692,262280,280777,415945,34953,1193,32937,54273,32936,449637,513]

theorem envBound7068 : H12AffineFastState.Bounded env7068 := by
  intro p hp
  have h : env7068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7067_7068 : H12AffineEnvironment.transform 12 161 env7067 = env7068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7067 == env7068) = true)

theorem identity7068 : scanCanonicalize (H12AffineFastState.compose env7068 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 23692) := by decide +kernel

theorem selectedBound7068 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env7069 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,161,16384,32768,32802,131072,23692,53501,32768,50196,32800,54508,32906,41,21692,23556,5189,132165,34953,1193,32937,54273,32936,164073,513]

theorem envBound7069 : H12AffineFastState.Bounded env7069 := by
  intro p hp
  have h : env7069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7068_7069 : H12AffineEnvironment.transform 17 23692 env7068 = env7069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23692 env7068 == env7069) = true)

def env7070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360619,268435456,268570624,1073741824,67674548,1086893388,525568,1073743905,34359738368,98850]

theorem envBound7070 : H12AffineFastState.Bounded env7070 := by
  intro p hp
  have h : env7070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6706_7070 : H12AffineEnvironment.transform 23 8988133 env6706 = env7070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988133 env6706 == env7070) = true)

theorem identity7070 : scanCanonicalize (H12AffineFastState.compose env7070 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13110596) := by decide +kernel

theorem selectedBound7070 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env7071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360619,268435456,268570624,13110596,67674548,40968,525568,13108581,34359738368,98850]

theorem envBound7071 : H12AffineFastState.Bounded env7071 := by
  intro p hp
  have h : env7071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7070_7071 : H12AffineEnvironment.transform 29 13110596 env7070 = env7071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13110596 env7070 == env7071) = true)

def env7072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360619,77615104,77742080,13110596,67674548,40968,525568,13108581,34359738368,98850]

theorem envBound7072 : H12AffineFastState.Bounded env7072 := by
  intro p hp
  have h : env7072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7071_7072 : H12AffineEnvironment.transform 27 77615104 env7071 = env7072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env7071 == env7072) = true)

theorem identity7072 : scanCanonicalize (H12AffineFastState.compose env7072 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566496) := by decide +kernel

theorem selectedBound7072 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,566496,360619,11072736,11199712,13110596,1364,40968,525568,13108581,34359738368,98850]

theorem envBound7073 : H12AffineFastState.Bounded env7073 := by
  intro p hp
  have h : env7073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7072_7073 : H12AffineEnvironment.transform 25 566496 env7072 = env7073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566496 env7072 == env7073) = true)

def env7074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8988133,8328,566496,360619,11072736,11199712,8957380,1364,40968,525568,8955365,34359738368,98850]

theorem envBound7074 : H12AffineFastState.Bounded env7074 := by
  intro p hp
  have h : env7074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7073_7074 : H12AffineEnvironment.transform 21 41088 env7073 = env7074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env7073 == env7074) = true)

theorem identity7074 : scanCanonicalize (H12AffineFastState.compose env7074 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7074 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7075 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8987672,8328,566496,360619,11072736,11199712,8956985,1193,40968,525565,8954904,34359738368,98850]

theorem envBound7075 : H12AffineFastState.Bounded env7075 := by
  intro p hp
  have h : env7075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7074_7075 : H12AffineEnvironment.transform 7 253 env7074 = env7075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7074 == env7075) = true)

theorem identity7075 : scanCanonicalize (H12AffineFastState.compose env7075 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound7075 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7076 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,524288,32768,2097152,41088,8388608,8954938,8328,566496,262281,11072736,11199712,8956985,1193,40968,525565,8954904,34359738368,512]

theorem envBound7076 : H12AffineFastState.Bounded env7076 := by
  intro p hp
  have h : env7076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7075_7076 : H12AffineEnvironment.transform 15 32802 env7075 = env7076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env7075 == env7076) = true)

theorem identity7076 : scanCanonicalize (H12AffineFastState.compose env7076 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound7076 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7077 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,524288,32768,17597,41088,8388608,8954938,8328,566496,262281,8958045,9085021,8956985,1193,40968,525565,8954904,34359738368,512]

theorem envBound7077 : H12AffineFastState.Bounded env7077 := by
  intro p hp
  have h : env7077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7076_7077 : H12AffineEnvironment.transform 20 17597 env7076 = env7077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env7076 == env7077) = true)

def env7078 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,524288,32768,17597,32800,8388608,8946842,40,558144,262281,8950013,9076989,8948889,1193,32936,525565,8946872,34359738368,512]

theorem envBound7078 : H12AffineFastState.Bounded env7078 := by
  intro p hp
  have h : env7078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7077_7078 : H12AffineEnvironment.transform 12 160 env7077 = env7078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7077 == env7078) = true)

theorem identity7078 : scanCanonicalize (H12AffineFastState.compose env7078 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 433189) := by decide +kernel

theorem selectedBound7078 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7079 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,524288,32768,17597,32800,433189,923839,40,558144,262281,920792,793816,921788,1193,32936,525565,923805,34359738368,512]

theorem envBound7079 : H12AffineFastState.Bounded env7079 := by
  intro p hp
  have h : env7079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7078_7079 : H12AffineEnvironment.transform 22 433189 env7078 = env7079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 433189 env7078 == env7079) = true)

theorem identity7079 : scanCanonicalize (H12AffineFastState.compose env7079 (packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS)) = affineNative (2^(18+1) ^^^ 432180) := by decide +kernel

theorem selectedBound7079 : packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env7080 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,432180,32768,17597,32800,433189,32907,40,400500,262281,38124,165100,34952,1193,32936,433353,32937,34359738368,512]

theorem envBound7080 : H12AffineFastState.Bounded env7080 := by
  intro p hp
  have h : env7080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7079_7080 : H12AffineEnvironment.transform 18 432180 env7079 = env7080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432180 env7079 == env7080) = true)

theorem identity7080 : scanCanonicalize (H12AffineFastState.compose env7080 (packedSelected [2,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 182369) := by decide +kernel

theorem selectedBound7080 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7081 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,182369,20565,32768,17597,32800,21572,32907,40,54293,182504,38124,165100,34952,1193,32936,21672,32937,34359738368,512]

theorem envBound7081 : H12AffineFastState.Bounded env7081 := by
  intro p hp
  have h : env7081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7080_7081 : H12AffineEnvironment.transform 17 182369 env7080 = env7081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182369 env7080 == env7081) = true)

theorem identity7081 : scanCanonicalize (H12AffineFastState.compose env7081 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 38125) := by decide +kernel

theorem selectedBound7081 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7082 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,38125,23692,20565,32768,17597,32800,21572,32907,40,54293,23557,38124,4097,34952,1193,32936,21672,32937,34359738368,512]

theorem envBound7082 : H12AffineFastState.Bounded env7082 := by
  intro p hp
  have h : env7082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7081_7082 : H12AffineEnvironment.transform 16 38125 env7081 = env7082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38125 env7081 == env7082) = true)

def env7083 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,524288,32768,17597,32801,8388608,8946843,41,558145,262281,8950012,9076988,8948888,1193,32937,525565,8946873,34359738368,512]

theorem envBound7083 : H12AffineFastState.Bounded env7083 := by
  intro p hp
  have h : env7083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7077_7083 : H12AffineEnvironment.transform 12 161 env7077 = env7083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7077 == env7083) = true)

theorem identity7083 : scanCanonicalize (H12AffineFastState.compose env7083 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 432181) := by decide +kernel

theorem selectedBound7083 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7084 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432181,32768,17597,32801,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32937,433352,8789132,34359738368,512]

theorem envBound7084 : H12AffineFastState.Bounded env7084 := by
  intro p hp
  have h : env7084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7083_7084 : H12AffineEnvironment.transform 18 432181 env7083 = env7084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432181 env7083 == env7084) = true)

def env7085 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432181,32768,17597,32801,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32937,433352,8789132,8702152,512]

theorem envBound7085 : H12AffineFastState.Bounded env7085 := by
  intro p hp
  have h : env7085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7084_7085 : H12AffineEnvironment.transform 34 8702152 env7084 = env7085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702152 env7084 == env7085) = true)

theorem identity7085 : scanCanonicalize (H12AffineFastState.compose env7085 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound7085 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7086 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,2185,168124,32768,17597,32801,8388608,8524839,41,136445,2048,8519744,8392768,8526884,1193,32937,169025,8524805,8437825,512]

theorem envBound7086 : H12AffineFastState.Bounded env7086 := by
  intro p hp
  have h : env7086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7085_7086 : H12AffineEnvironment.transform 17 2185 env7085 = env7086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env7085 == env7086) = true)

theorem identity7086 : scanCanonicalize (H12AffineFastState.compose env7086 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 64) := by decide +kernel

theorem selectedBound7086 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env7087 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,2185,168124,32768,17597,32801,64,136295,41,136445,2048,131072,4096,138340,1193,32937,169025,136261,49153,512]

theorem envBound7087 : H12AffineFastState.Bounded env7087 := by
  intro p hp
  have h : env7087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7086_7087 : H12AffineEnvironment.transform 22 64 env7086 = env7087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env7086 == env7087) = true)

theorem identity7087 : scanCanonicalize (H12AffineFastState.compose env7087 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound7087 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7088 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5357,2185,33873,32768,17597,32801,64,138,41,16,2048,5357,4096,2185,1193,32937,32940,168,49153,512]

theorem envBound7088 : H12AffineFastState.Bounded env7088 := by
  intro p hp
  have h : env7088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7087_7088 : H12AffineEnvironment.transform 16 5357 env7087 = env7088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env7087 == env7088) = true)

theorem identity7088 : scanCanonicalize (H12AffineFastState.compose env7088 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound7088 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7089 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,35,5357,2185,1104,1,17597,32,64,138,41,16,2048,5357,4096,2185,1193,168,173,168,16384,512]

theorem envBound7089 : H12AffineFastState.Bounded env7089 := by
  intro p hp
  have h : env7089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7088_7089 : H12AffineEnvironment.transform 14 1 env7088 = env7089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env7088 == env7089) = true)

theorem identity7089 : scanCanonicalize (H12AffineFastState.compose env7089 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound7089 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7090 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,88,16384,1,35,5140,2160,1104,1,17476,32,64,115,41,16,2048,5140,4096,2160,1104,81,84,81,16384,512]

theorem envBound7090 : H12AffineFastState.Bounded env7090 := by
  intro p hp
  have h : env7090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7089_7090 : H12AffineEnvironment.transform 6 121 env7089 = env7090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env7089 == env7090) = true)

theorem identity7090 : scanCanonicalize (H12AffineFastState.compose env7090 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7090 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7091 : List Nat := [2,4,8,16,32,59,2,4,512,1024,2048,4096,35,16384,1,35,5140,2059,1067,1,17471,32,59,8,41,16,2048,5140,4096,2059,1067,42,47,42,16384,512]

theorem envBound7091 : H12AffineFastState.Bounded env7091 := by
  intro p hp
  have h : env7091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7090_7091 : H12AffineEnvironment.transform 5 59 env7090 = env7091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7090 == env7091) = true)

theorem identity7091 : scanCanonicalize (H12AffineFastState.compose env7091 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound7091 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7092 : List Nat := [2,4,8,16,32,59,2,4,512,47,2048,4096,35,16384,1,35,4155,2059,4,1,16400,32,59,8,41,16,2048,4155,4096,2059,4,42,47,42,16384,512]

theorem envBound7092 : H12AffineFastState.Bounded env7092 := by
  intro p hp
  have h : env7092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7091_7092 : H12AffineEnvironment.transform 9 47 env7091 = env7092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env7091 == env7092) = true)

theorem identity7092 : scanCanonicalize (H12AffineFastState.compose env7092 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7092 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7093 : List Nat := [2,4,8,16,1,26,2,4,512,14,2048,4096,2,16384,1,2,4122,2059,4,1,16400,1,26,8,8,16,2048,4122,4096,2059,4,11,14,11,16384,512]

theorem envBound7093 : H12AffineFastState.Bounded env7093 := by
  intro p hp
  have h : env7093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7092_7093 : H12AffineEnvironment.transform 4 1 env7092 = env7093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7092 == env7093) = true)

theorem identity7093 : scanCanonicalize (H12AffineFastState.compose env7093 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7093 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env7094 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,4096,2,16384,1,2,4112,2049,4,1,16400,1,16,2,2,16,2048,4112,4096,2049,4,1,4,1,16384,512]

theorem envBound7094 : H12AffineFastState.Bounded env7094 := by
  intro p hp
  have h : env7094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7093_7094 : H12AffineEnvironment.transform 2 2 env7093 = env7094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7093 == env7094) = true)

def env7095 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,16384,1,2,16,2049,4,1,16400,1,16,2,2,16,2048,16,0,2049,4,1,4,1,16384,512]

theorem envBound7095 : H12AffineFastState.Bounded env7095 := by
  intro p hp
  have h : env7095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7094_7095 : H12AffineEnvironment.transform 11 0 env7094 = env7095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env7094 == env7095) = true)

theorem identity7095 : scanCanonicalize (H12AffineFastState.compose env7095 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 530) := by decide +kernel

theorem selectedBound7095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7096 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,530,1,2,16,2049,4,1,514,1,16,2,2,16,2048,16,0,2049,4,1,4,1,530,512]

theorem envBound7096 : H12AffineFastState.Bounded env7096 := by
  intro p hp
  have h : env7096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7095_7096 : H12AffineEnvironment.transform 13 530 env7095 = env7096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 530 env7095 == env7096) = true)

def env7097 : List Nat := [2,4,2,16,1,16,2,4,0,4,2048,0,2,18,1,2,16,2049,4,1,2,1,16,2,2,16,2048,16,0,2049,4,1,4,1,18,0]

theorem envBound7097 : H12AffineFastState.Bounded env7097 := by
  intro p hp
  have h : env7097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7096_7097 : H12AffineEnvironment.transform 8 0 env7096 = env7097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env7096 == env7097) = true)

theorem identity7097 : scanCanonicalize (H12AffineFastState.compose env7097 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7098 : List Nat := [2,2,2,16,1,16,2,2,0,2,2048,0,2,18,1,2,16,2049,2,1,2,1,16,2,2,16,2048,16,0,2049,2,1,2,1,18,0]

theorem envBound7098 : H12AffineFastState.Bounded env7098 := by
  intro p hp
  have h : env7098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7097_7098 : H12AffineEnvironment.transform 1 2 env7097 = env7098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7097 == env7098) = true)

def leafEnv7098 : List Nat := [2,2,2,16,1,16,2,2,0,2,2048,0,2,18,1,2,16,2049,2,1,2,1,16,2,2,2,1,16,2048,16,0,2049,2,1,2,1,2,2,18,0,1,2,0]

def active7098 : List Nat := [0,3,10]

def tree7098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7098 : H12WitnessSearch.Good tree7098 := H12GlobalWitnessIndex.good

theorem leafIdentity7098 : H12AffineFastState.composeSystem env7098 rootObs = leafEnv7098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7098 rootObs == leafEnv7098) = true)

theorem terminalChecked7098 : H12PackedTerminal.terminalCheckFast leafEnv7098 active7098 tree7098 = true := by decide +kernel

def env7099 : List Nat := [2,4,2,16,1,16,2,4,1,4,2048,0,2,19,1,2,16,2049,4,1,3,1,16,2,2,16,2048,16,0,2049,4,1,4,1,19,1]

theorem envBound7099 : H12AffineFastState.Bounded env7099 := by
  intro p hp
  have h : env7099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7096_7099 : H12AffineEnvironment.transform 8 1 env7096 = env7099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env7096 == env7099) = true)

theorem identity7099 : scanCanonicalize (H12AffineFastState.compose env7099 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound7099 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7100 : List Nat := [2,4,2,7,1,7,2,4,1,4,2048,0,2,4,1,2,7,2049,4,1,3,1,7,2,2,7,2048,7,0,2049,4,1,4,1,4,1]

theorem envBound7100 : H12AffineFastState.Bounded env7100 := by
  intro p hp
  have h : env7100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7099_7100 : H12AffineEnvironment.transform 3 7 env7099 = env7100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env7099 == env7100) = true)

def leafEnv7100 : List Nat := [2,4,2,7,1,7,2,4,1,4,2048,0,2,4,1,2,7,2049,4,1,3,1,7,2,4,2,1,7,2048,7,0,2049,4,1,4,1,4,2,4,1,1,3,0]

def active7100 : List Nat := [0,1,10]

def tree7100 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7100 : H12WitnessSearch.Good tree7100 := H12GlobalWitnessIndex.good

theorem leafIdentity7100 : H12AffineFastState.composeSystem env7100 rootObs = leafEnv7100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7100 rootObs == leafEnv7100) = true)

theorem terminalChecked7100 : H12PackedTerminal.terminalCheckFast leafEnv7100 active7100 tree7100 = true := by decide +kernel

def env7101 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,16384,1,2,17,2049,4,1,16400,1,16,2,2,16,2048,17,1,2049,4,1,4,1,16384,512]

theorem envBound7101 : H12AffineFastState.Bounded env7101 := by
  intro p hp
  have h : env7101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7094_7101 : H12AffineEnvironment.transform 11 1 env7094 = env7101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env7094 == env7101) = true)

theorem identity7101 : scanCanonicalize (H12AffineFastState.compose env7101 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 514) := by decide +kernel

theorem selectedBound7101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7102 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,514,1,2,17,2049,4,1,530,1,16,2,2,16,2048,17,1,2049,4,1,4,1,514,512]

theorem envBound7102 : H12AffineFastState.Bounded env7102 := by
  intro p hp
  have h : env7102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7101_7102 : H12AffineEnvironment.transform 13 514 env7101 = env7102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 514 env7101 == env7102) = true)

def env7103 : List Nat := [2,4,2,16,1,16,2,4,0,4,2048,1,2,2,1,2,17,2049,4,1,18,1,16,2,2,16,2048,17,1,2049,4,1,4,1,2,0]

theorem envBound7103 : H12AffineFastState.Bounded env7103 := by
  intro p hp
  have h : env7103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7102_7103 : H12AffineEnvironment.transform 8 0 env7102 = env7103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env7102 == env7103) = true)

theorem identity7103 : scanCanonicalize (H12AffineFastState.compose env7103 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound7103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7104 : List Nat := [2,4,2,7,1,7,2,4,0,4,2048,1,2,2,1,2,6,2049,4,1,5,1,7,2,2,7,2048,6,1,2049,4,1,4,1,2,0]

theorem envBound7104 : H12AffineFastState.Bounded env7104 := by
  intro p hp
  have h : env7104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7103_7104 : H12AffineEnvironment.transform 3 7 env7103 = env7104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env7103 == env7104) = true)

def leafEnv7104 : List Nat := [2,4,2,7,1,7,2,4,0,4,2048,1,2,2,1,2,6,2049,4,1,5,1,7,2,4,2,1,7,2048,6,1,2049,4,1,4,1,4,2,2,0,1,5,0]

def active7104 : List Nat := [0,1,10]

def tree7104 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7104 : H12WitnessSearch.Good tree7104 := H12GlobalWitnessIndex.good

theorem leafIdentity7104 : H12AffineFastState.composeSystem env7104 rootObs = leafEnv7104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7104 rootObs == leafEnv7104) = true)

theorem terminalChecked7104 : H12PackedTerminal.terminalCheckFast leafEnv7104 active7104 tree7104 = true := by decide +kernel

def env7105 : List Nat := [2,4,2,16,1,16,2,4,1,4,2048,1,2,3,1,2,17,2049,4,1,19,1,16,2,2,16,2048,17,1,2049,4,1,4,1,3,1]

theorem envBound7105 : H12AffineFastState.Bounded env7105 := by
  intro p hp
  have h : env7105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7102_7105 : H12AffineEnvironment.transform 8 1 env7102 = env7105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env7102 == env7105) = true)

theorem identity7105 : scanCanonicalize (H12AffineFastState.compose env7105 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound7105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7106 : List Nat := [2,2,2,16,1,16,2,2,1,2,2048,1,2,3,1,2,17,2049,2,1,19,1,16,2,2,16,2048,17,1,2049,2,1,2,1,3,1]

theorem envBound7106 : H12AffineFastState.Bounded env7106 := by
  intro p hp
  have h : env7106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7105_7106 : H12AffineEnvironment.transform 1 2 env7105 = env7106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env7105 == env7106) = true)

def leafEnv7106 : List Nat := [2,2,2,16,1,16,2,2,1,2,2048,1,2,3,1,2,17,2049,2,1,19,1,16,2,2,2,1,16,2048,17,1,2049,2,1,2,1,2,2,3,1,1,19,0]

def active7106 : List Nat := [0,3,10]

def tree7106 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7106 : H12WitnessSearch.Good tree7106 := H12GlobalWitnessIndex.good

theorem leafIdentity7106 : H12AffineFastState.composeSystem env7106 rootObs = leafEnv7106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7106 rootObs == leafEnv7106) = true)

theorem terminalChecked7106 : H12PackedTerminal.terminalCheckFast leafEnv7106 active7106 tree7106 = true := by decide +kernel

def env7107 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432181,32768,17597,32801,8388608,8789166,41,400500,262281,8784073,8657097,8787117,1193,32937,433352,8789132,8702153,512]

theorem envBound7107 : H12AffineFastState.Bounded env7107 := by
  intro p hp
  have h : env7107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7084_7107 : H12AffineEnvironment.transform 34 8702153 env7084 = env7107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702153 env7084 == env7107) = true)

theorem identity7107 : scanCanonicalize (H12AffineFastState.compose env7107 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound7107 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7108 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5357,262144,298200,32768,17597,32801,8388608,8652867,41,264345,262281,8657956,8657097,8650816,1193,32937,296997,8652897,8702153,512]

theorem envBound7108 : H12AffineFastState.Bounded env7108 := by
  intro p hp
  have h : env7108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7107_7108 : H12AffineEnvironment.transform 16 5357 env7107 = env7108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env7107 == env7108) = true)

theorem identity7108 : scanCanonicalize (H12AffineFastState.compose env7108 (packedSelected [4,9,11] rootPS)) = affineNative (2^(22+1) ^^^ 297160) := by decide +kernel

theorem selectedBound7108 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env7109 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5357,262144,298200,32768,17597,32801,297160,32907,41,264345,262281,38124,36865,34952,1193,32937,296997,32937,16385,512]

theorem envBound7109 : H12AffineFastState.Bounded env7109 := by
  intro p hp
  have h : env7109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7108_7109 : H12AffineEnvironment.transform 22 297160 env7108 = env7109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297160 env7108 == env7109) = true)

theorem identity7109 : scanCanonicalize (H12AffineFastState.compose env7109 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound7109 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7110 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5357,2080,34040,32768,17597,32801,33000,32907,41,185,2217,38124,36865,34952,1193,32937,32773,32937,16385,512]

theorem envBound7110 : H12AffineFastState.Bounded env7110 := by
  intro p hp
  have h : env7110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7109_7110 : H12AffineEnvironment.transform 17 2080 env7109 = env7110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env7109 == env7110) = true)

theorem identity7110 : scanCanonicalize (H12AffineFastState.compose env7110 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound7110 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7111 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,32768,32802,5188,2080,33873,32768,17428,32801,32833,32802,41,16,2048,37957,36865,34849,1024,32768,32773,32768,16385,512]

theorem envBound7111 : H12AffineFastState.Bounded env7111 := by
  intro p hp
  have h : env7111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7110_7111 : H12AffineEnvironment.transform 6 41 env7110 = env7111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env7110 == env7111) = true)

theorem identity7111 : scanCanonicalize (H12AffineFastState.compose env7111 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2107) := by decide +kernel

theorem selectedBound7111 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env7112 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,2107,32768,32802,5188,2080,33873,32768,3119,32801,32833,32802,41,16,2048,37957,36865,34849,1024,32768,32773,32768,2106,512]

theorem envBound7112 : H12AffineFastState.Bounded env7112 := by
  intro p hp
  have h : env7112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7111_7112 : H12AffineEnvironment.transform 13 2107 env7111 = env7112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2107 env7111 == env7112) = true)

theorem identity7112 : scanCanonicalize (H12AffineFastState.compose env7112 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 1092) := by decide +kernel

theorem selectedBound7112 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env7113 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,2107,1092,1126,5188,2080,21,1092,3119,1125,1029,1126,41,16,2048,4097,5189,3173,1024,1092,1089,1092,2106,512]

theorem envBound7113 : H12AffineFastState.Bounded env7113 := by
  intro p hp
  have h : env7113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7112_7113 : H12AffineEnvironment.transform 14 1092 env7112 = env7113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1092 env7112 == env7113) = true)

theorem identity7113 : scanCanonicalize (H12AffineFastState.compose env7113 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound7113 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7114 : List Nat := [2,4,8,16,32,64,41,84,512,69,2048,4096,8,2107,1,35,4097,2080,21,1,2154,32,64,35,41,16,2048,4097,4096,2080,69,1,4,1,2106,512]

theorem envBound7114 : H12AffineFastState.Bounded env7114 := by
  intro p hp
  have h : env7114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7113_7114 : H12AffineEnvironment.transform 9 69 env7113 = env7114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env7113 == env7114) = true)

theorem identity7114 : scanCanonicalize (H12AffineFastState.compose env7114 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound7114 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env7115 : List Nat := [2,4,8,16,32,16,41,4,512,21,2048,4096,8,2107,1,35,4097,2080,21,1,2106,32,16,35,41,16,2048,4097,4096,2080,21,1,4,1,2106,512]

theorem envBound7115 : H12AffineFastState.Bounded env7115 := by
  intro p hp
  have h : env7115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7114_7115 : H12AffineEnvironment.transform 5 16 env7114 = env7115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env7114 == env7115) = true)

theorem identity7115 : scanCanonicalize (H12AffineFastState.compose env7115 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound7115 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7116 : List Nat := [2,4,8,16,32,16,41,4,512,21,17,4096,8,42,1,35,4097,49,21,1,43,32,16,35,41,16,17,4097,4096,49,21,1,4,1,43,512]

theorem envBound7116 : H12AffineFastState.Bounded env7116 := by
  intro p hp
  have h : env7116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7115_7116 : H12AffineEnvironment.transform 10 17 env7115 = env7116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env7115 == env7116) = true)

theorem identity7116 : scanCanonicalize (H12AffineFastState.compose env7116 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound7116 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7117 : List Nat := [2,4,8,16,0,16,9,4,512,21,17,4096,8,10,1,3,4097,17,21,1,11,0,16,3,9,16,17,4097,4096,17,21,1,4,1,11,512]

theorem envBound7117 : H12AffineFastState.Bounded env7117 := by
  intro p hp
  have h : env7117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7116_7117 : H12AffineEnvironment.transform 4 0 env7116 = env7117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env7116 == env7117) = true)

theorem identity7117 : scanCanonicalize (H12AffineFastState.compose env7117 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 521) := by decide +kernel

theorem selectedBound7117 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7118 : List Nat := [2,4,8,16,0,16,9,4,512,21,17,521,8,10,1,3,520,17,21,1,11,0,16,3,9,16,17,520,521,17,21,1,4,1,11,512]

theorem envBound7118 : H12AffineFastState.Bounded env7118 := by
  intro p hp
  have h : env7118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7117_7118 : H12AffineEnvironment.transform 11 521 env7117 = env7118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 521 env7117 == env7118) = true)

theorem identity7118 : scanCanonicalize (H12AffineFastState.compose env7118 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound7118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7119 : List Nat := [2,4,8,16,0,16,9,4,6,21,17,15,8,10,1,3,14,17,21,1,11,0,16,3,9,16,17,14,15,17,21,1,4,1,11,6]

theorem envBound7119 : H12AffineFastState.Bounded env7119 := by
  intro p hp
  have h : env7119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7118_7119 : H12AffineEnvironment.transform 8 6 env7118 = env7119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env7118 == env7119) = true)

def env7120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8988133,8328,566496,360619,11072736,11199712,8957381,1364,40968,525568,8955364,34359738368,98850]

theorem envBound7120 : H12AffineFastState.Bounded env7120 := by
  intro p hp
  have h : env7120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7073_7120 : H12AffineEnvironment.transform 21 41089 env7073 = env7120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env7073 == env7120) = true)

def env7121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62640,32768,2097152,41089,8388608,8507733,8328,20560,360619,10485840,10621008,8411509,1364,40968,61872,8409428,34359738368,98850]

theorem envBound7121 : H12AffineFastState.Bounded env7121 := by
  intro p hp
  have h : env7121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7120_7121 : H12AffineEnvironment.transform 18 62640 env7120 = env7121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62640 env7120 == env7121) = true)

theorem identity7121 : scanCanonicalize (H12AffineFastState.compose env7121 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound7121 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62640,32768,2097152,41089,8388608,8507733,8328,20560,360619,10485840,10487104,8411509,1364,40968,61872,8409428,34359738368,98850]

theorem envBound7122 : H12AffineFastState.Bounded env7122 := by
  intro p hp
  have h : env7122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7121_7122 : H12AffineEnvironment.transform 16 5392 env7121 = env7122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env7121 == env7122) = true)

def env7123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62640,32768,2097152,41089,61600,74229,8328,20560,360619,2158832,2160096,43477,1364,40968,61872,41460,34359738368,98850]

theorem envBound7123 : H12AffineFastState.Bounded env7123 := by
  intro p hp
  have h : env7123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7122_7123 : H12AffineEnvironment.transform 22 61600 env7122 = env7123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env7122 == env7123) = true)

theorem identity7123 : scanCanonicalize (H12AffineFastState.compose env7123 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound7123 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32802,5392,262144,62640,32768,2097152,41089,61600,41431,8328,20560,262281,2158832,2160096,43477,1364,40968,61872,41460,34359738368,512]

theorem envBound7124 : H12AffineFastState.Bounded env7124 := by
  intro p hp
  have h : env7124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7123_7124 : H12AffineEnvironment.transform 15 32802 env7123 = env7124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env7123 == env7124) = true)

theorem identity7124 : scanCanonicalize (H12AffineFastState.compose env7124 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7124 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7125 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,5356,262144,62640,32768,2097152,41089,61600,41003,8328,20560,262281,2158832,2159644,43049,1192,40968,61516,40968,34359738368,512]

theorem envBound7125 : H12AffineFastState.Bounded env7125 := by
  intro p hp
  have h : env7125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7124_7125 : H12AffineEnvironment.transform 7 252 env7124 = env7125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7124 == env7125) = true)

def env7126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,262144,62640,32768,2097152,41089,61601,74228,8328,20560,360619,2158833,2160097,43476,1364,40968,61872,41461,34359738368,98850]

theorem envBound7126 : H12AffineFastState.Bounded env7126 := by
  intro p hp
  have h : env7126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7122_7126 : H12AffineEnvironment.transform 22 61601 env7122 = env7126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env7122 == env7126) = true)

theorem identity7126 : scanCanonicalize (H12AffineFastState.compose env7126 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound7126 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,5392,262144,62640,32768,2097152,41089,61601,41002,8328,20560,262517,2158833,2160097,43476,1364,40968,61872,41461,34359738368,1020]

theorem envBound7127 : H12AffineFastState.Bounded env7127 := by
  intro p hp
  have h : env7127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7126_7127 : H12AffineEnvironment.transform 15 33246 env7126 = env7127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env7126 == env7127) = true)

theorem identity7127 : scanCanonicalize (H12AffineFastState.compose env7127 (packedSelected [11,18,21] rootPS)) = affineNative (2^(20+1) ^^^ 310568) := by decide +kernel

theorem selectedBound7127 : packedSelected [11,18,21] rootPS < 2^1333 := by decide +kernel

def env7128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,5392,262144,62640,32768,310568,41089,61601,41002,8328,20560,262517,282073,280777,43476,1364,40968,61872,41461,34359738368,1020]

theorem envBound7128 : H12AffineFastState.Bounded env7128 := by
  intro p hp
  have h : env7128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7127_7128 : H12AffineEnvironment.transform 20 310568 env7127 = env7128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310568 env7127 == env7128) = true)

def env7129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62641,32768,2097152,41089,8388608,8507732,8328,20561,360619,10485841,10621009,8411508,1364,40968,61873,8409429,34359738368,98850]

theorem envBound7129 : H12AffineFastState.Bounded env7129 := by
  intro p hp
  have h : env7129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7120_7129 : H12AffineEnvironment.transform 18 62641 env7120 = env7129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62641 env7120 == env7129) = true)

theorem identity7129 : scanCanonicalize (H12AffineFastState.compose env7129 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103730) := by decide +kernel

theorem selectedBound7129 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41089,8388608,8507732,8328,20561,360619,10485841,10585443,8411508,1364,40968,61873,8409429,34359738368,98850]

theorem envBound7130 : H12AffineFastState.Bounded env7130 := by
  intro p hp
  have h : env7130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7129_7130 : H12AffineEnvironment.transform 16 103730 env7129 = env7130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103730 env7129 == env7130) = true)

def env7131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41089,61600,74228,8328,20561,360619,2158833,2192835,43476,1364,40968,61873,41461,34359738368,98850]

theorem envBound7131 : H12AffineFastState.Bounded env7131 := by
  intro p hp
  have h : env7131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7130_7131 : H12AffineEnvironment.transform 22 61600 env7130 = env7131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env7130 == env7131) = true)

theorem identity7131 : scanCanonicalize (H12AffineFastState.compose env7131 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound7131 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,5356,262144,62641,32768,2097152,41089,61600,41002,8328,20561,262517,2158833,2159645,43476,1364,40968,61873,41461,34359738368,1020]

theorem envBound7132 : H12AffineFastState.Bounded env7132 := by
  intro p hp
  have h : env7132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7131_7132 : H12AffineEnvironment.transform 15 33246 env7131 = env7132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env7131 == env7132) = true)

theorem identity7132 : scanCanonicalize (H12AffineFastState.compose env7132 (packedSelected [11,18,21] rootPS)) = affineNative (2^(20+1) ^^^ 310485) := by decide +kernel

theorem selectedBound7132 : packedSelected [11,18,21] rootPS < 2^1333 := by decide +kernel

def env7133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33246,5356,262144,62641,32768,310485,41089,61600,41002,8328,20561,262517,281636,280776,43476,1364,40968,61873,41461,34359738368,1020]

theorem envBound7133 : H12AffineFastState.Bounded env7133 := by
  intro p hp
  have h : env7133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7132_7133 : H12AffineEnvironment.transform 20 310485 env7132 = env7133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 310485 env7132 == env7133) = true)

def env7134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103730,262144,62641,32768,2097152,41089,61601,74229,8328,20561,360619,2158832,2192834,43477,1364,40968,61873,41460,34359738368,98850]

theorem envBound7134 : H12AffineFastState.Bounded env7134 := by
  intro p hp
  have h : env7134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7130_7134 : H12AffineEnvironment.transform 22 61601 env7130 = env7134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env7130 == env7134) = true)

theorem identity7134 : scanCanonicalize (H12AffineFastState.compose env7134 (packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound7134 : packedSelected [0,7,9,11,13,14,17,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env7135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32802,5392,262144,62641,32768,2097152,41089,61601,41431,8328,20561,262281,2158832,2160096,43477,1364,40968,61873,41460,34359738368,512]

theorem envBound7135 : H12AffineFastState.Bounded env7135 := by
  intro p hp
  have h : env7135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7134_7135 : H12AffineEnvironment.transform 15 32802 env7134 = env7135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env7134 == env7135) = true)

theorem identity7135 : scanCanonicalize (H12AffineFastState.compose env7135 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound7135 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env7136 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32802,5356,262144,62641,32768,2097152,41089,61601,41003,8328,20561,262281,2158832,2159644,43049,1192,40968,61517,40968,34359738368,512]

theorem envBound7136 : H12AffineFastState.Bounded env7136 := by
  intro p hp
  have h : env7136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7135_7136 : H12AffineEnvironment.transform 7 252 env7135 = env7136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env7135 == env7136) = true)

def env7137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,360619,77615105,77742081,13110596,67674548,40968,525568,13108581,34359738368,98850]

theorem envBound7137 : H12AffineFastState.Bounded env7137 := by
  intro p hp
  have h : env7137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7071_7137 : H12AffineEnvironment.transform 27 77615105 env7071 = env7137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615105 env7071 == env7137) = true)

theorem identity7137 : scanCanonicalize (H12AffineFastState.compose env7137 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 599234) := by decide +kernel

theorem selectedBound7137 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env7138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,599234,360619,11105475,11232451,13110596,99702,40968,525568,13108581,34359738368,98850]

theorem envBound7138 : H12AffineFastState.Bounded env7138 := by
  intro p hp
  have h : env7138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7137_7138 : H12AffineEnvironment.transform 25 599234 env7137 = env7138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 599234 env7137 == env7138) = true)

def env7139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8988133,8328,599234,360619,11105475,11232451,8957380,99702,40968,525568,8955365,34359738368,98850]

theorem envBound7139 : H12AffineFastState.Bounded env7139 := by
  intro p hp
  have h : env7139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7138_7139 : H12AffineEnvironment.transform 21 41088 env7138 = env7139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env7138 == env7139) = true)

theorem identity7139 : scanCanonicalize (H12AffineFastState.compose env7139 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound7139 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env7140 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41088,8388608,8987672,8328,599234,360619,11105475,11232451,8956985,99467,40968,525565,8954904,34359738368,98850]

theorem envBound7140 : H12AffineFastState.Bounded env7140 := by
  intro p hp
  have h : env7140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7139_7140 : H12AffineEnvironment.transform 7 253 env7139 = env7140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env7139 == env7140) = true)

theorem identity7140 : scanCanonicalize (H12AffineFastState.compose env7140 (packedSelected [0,7,9,13,14,17,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound7140 : packedSelected [0,7,9,13,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env7141 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,524288,32768,2097152,41088,8388608,8954938,8328,566496,262281,11072737,11199713,8956985,1193,40968,525565,8954904,34359738368,512]

theorem envBound7141 : H12AffineFastState.Bounded env7141 := by
  intro p hp
  have h : env7141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7140_7141 : H12AffineEnvironment.transform 15 32802 env7140 = env7141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env7140 == env7141) = true)

theorem identity7141 : scanCanonicalize (H12AffineFastState.compose env7141 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17597) := by decide +kernel

theorem selectedBound7141 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7142 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,32802,131072,262144,524288,32768,17597,41088,8388608,8954938,8328,566496,262281,8958044,9085020,8956985,1193,40968,525565,8954904,34359738368,512]

theorem envBound7142 : H12AffineFastState.Bounded env7142 := by
  intro p hp
  have h : env7142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7141_7142 : H12AffineEnvironment.transform 20 17597 env7141 = env7142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17597 env7141 == env7142) = true)

def env7143 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,524288,32768,17597,32800,8388608,8946842,40,558144,262281,8950012,9076988,8948889,1193,32936,525565,8946872,34359738368,512]

theorem envBound7143 : H12AffineFastState.Bounded env7143 := by
  intro p hp
  have h : env7143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7142_7143 : H12AffineEnvironment.transform 12 160 env7142 = env7143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env7142 == env7143) = true)

theorem identity7143 : scanCanonicalize (H12AffineFastState.compose env7143 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(22+1) ^^^ 433188) := by decide +kernel

theorem selectedBound7143 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7144 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,524288,32768,17597,32800,433188,923838,40,558144,262281,920792,793816,921789,1193,32936,525565,923804,34359738368,512]

theorem envBound7144 : H12AffineFastState.Bounded env7144 := by
  intro p hp
  have h : env7144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7143_7144 : H12AffineEnvironment.transform 22 433188 env7143 = env7144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 433188 env7143 == env7144) = true)

theorem identity7144 : scanCanonicalize (H12AffineFastState.compose env7144 (packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS)) = affineNative (2^(18+1) ^^^ 432181) := by decide +kernel

theorem selectedBound7144 : packedSelected [1,2,3,4,6,9,11,14,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env7145 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,432181,32768,17597,32800,433188,32907,40,400501,262281,38125,165101,34952,1193,32936,433352,32937,34359738368,512]

theorem envBound7145 : H12AffineFastState.Bounded env7145 := by
  intro p hp
  have h : env7145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7144_7145 : H12AffineEnvironment.transform 18 432181 env7144 = env7145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432181 env7144 == env7145) = true)

theorem identity7145 : scanCanonicalize (H12AffineFastState.compose env7145 (packedSelected [2,13,14] rootPS)) = affineNative (2^(34+1) ^^^ 164072) := by decide +kernel

theorem selectedBound7145 : packedSelected [2,13,14] rootPS < 2^1333 := by decide +kernel

def env7146 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,131072,262144,432181,32768,17597,32800,433188,32907,40,400501,262281,38125,165101,34952,1193,32936,433352,32937,164072,512]

theorem envBound7146 : H12AffineFastState.Bounded env7146 := by
  intro p hp
  have h : env7146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7145_7146 : H12AffineEnvironment.transform 34 164072 env7145 = env7146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 164072 env7145 == env7146) = true)

theorem identity7146 : scanCanonicalize (H12AffineFastState.compose env7146 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 38124) := by decide +kernel

theorem selectedBound7146 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env7147 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,160,16384,32768,32802,38124,262144,265433,32768,17597,32800,264392,32907,40,297113,262281,38125,4097,34952,1193,32936,264228,32937,5124,512]

theorem envBound7147 : H12AffineFastState.Bounded env7147 := by
  intro p hp
  have h : env7147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7146_7147 : H12AffineEnvironment.transform 16 38124 env7146 = env7147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38124 env7146 == env7147) = true)

def env7148 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,524288,32768,17597,32801,8388608,8946843,41,558145,262281,8950013,9076989,8948888,1193,32937,525565,8946873,34359738368,512]

theorem envBound7148 : H12AffineFastState.Bounded env7148 := by
  intro p hp
  have h : env7148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7142_7148 : H12AffineEnvironment.transform 12 161 env7142 = env7148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env7142 == env7148) = true)

theorem identity7148 : scanCanonicalize (H12AffineFastState.compose env7148 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(18+1) ^^^ 432180) := by decide +kernel

theorem selectedBound7148 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env7149 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432180,32768,17597,32801,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32937,433353,8789133,34359738368,512]

theorem envBound7149 : H12AffineFastState.Bounded env7149 := by
  intro p hp
  have h : env7149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7148_7149 : H12AffineEnvironment.transform 18 432180 env7148 = env7149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 432180 env7148 == env7149) = true)

def env7150 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432180,32768,17597,32801,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32937,433353,8789133,8702152,512]

theorem envBound7150 : H12AffineFastState.Bounded env7150 := by
  intro p hp
  have h : env7150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7149_7150 : H12AffineEnvironment.transform 34 8702152 env7149 = env7150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702152 env7149 == env7150) = true)

theorem identity7150 : scanCanonicalize (H12AffineFastState.compose env7150 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound7150 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7151 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,2185,168125,32768,17597,32801,8388608,8524838,41,136444,2048,8519744,8392768,8526885,1193,32937,169024,8524804,8437825,512]

theorem envBound7151 : H12AffineFastState.Bounded env7151 := by
  intro p hp
  have h : env7151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7150_7151 : H12AffineEnvironment.transform 17 2185 env7150 = env7151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env7150 == env7151) = true)

theorem identity7151 : scanCanonicalize (H12AffineFastState.compose env7151 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 64) := by decide +kernel

theorem selectedBound7151 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env7152 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,2185,168125,32768,17597,32801,64,136294,41,136444,2048,131072,4096,138341,1193,32937,169024,136260,49153,512]

theorem envBound7152 : H12AffineFastState.Bounded env7152 := by
  intro p hp
  have h : env7152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7151_7152 : H12AffineEnvironment.transform 22 64 env7151 = env7152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 64 env7151 == env7152) = true)

theorem identity7152 : scanCanonicalize (H12AffineFastState.compose env7152 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound7152 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env7153 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5356,2185,33873,32768,17597,32801,64,138,41,16,2048,5356,4096,2185,1193,32937,32940,168,49153,512]

theorem envBound7153 : H12AffineFastState.Bounded env7153 := by
  intro p hp
  have h : env7153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7152_7153 : H12AffineEnvironment.transform 16 5356 env7152 = env7153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env7152 == env7153) = true)

theorem identity7153 : scanCanonicalize (H12AffineFastState.compose env7153 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound7153 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env7154 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,1,35,5356,2185,1104,1,17597,32,64,138,41,16,2048,5356,4096,2185,1193,168,173,168,16384,512]

theorem envBound7154 : H12AffineFastState.Bounded env7154 := by
  intro p hp
  have h : env7154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7153_7154 : H12AffineEnvironment.transform 14 1 env7153 = env7154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env7153 == env7154) = true)

theorem identity7154 : scanCanonicalize (H12AffineFastState.compose env7154 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound7154 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env7155 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,88,16384,1,35,5141,2160,1104,1,17476,32,64,115,41,16,2048,5141,4096,2160,1104,81,84,81,16384,512]

theorem envBound7155 : H12AffineFastState.Bounded env7155 := by
  intro p hp
  have h : env7155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7154_7155 : H12AffineEnvironment.transform 6 121 env7154 = env7155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env7154 == env7155) = true)

theorem identity7155 : scanCanonicalize (H12AffineFastState.compose env7155 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound7155 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env7156 : List Nat := [2,4,8,16,32,59,2,4,512,1024,2048,4096,35,16384,1,35,5141,2059,1067,1,17471,32,59,8,41,16,2048,5141,4096,2059,1067,42,47,42,16384,512]

theorem envBound7156 : H12AffineFastState.Bounded env7156 := by
  intro p hp
  have h : env7156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7155_7156 : H12AffineEnvironment.transform 5 59 env7155 = env7156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env7155 == env7156) = true)

theorem identity7156 : scanCanonicalize (H12AffineFastState.compose env7156 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound7156 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env7157 : List Nat := [2,4,8,16,32,59,2,4,512,47,2048,4096,35,16384,1,35,4154,2059,4,1,16400,32,59,8,41,16,2048,4154,4096,2059,4,42,47,42,16384,512]

theorem envBound7157 : H12AffineFastState.Bounded env7157 := by
  intro p hp
  have h : env7157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7156_7157 : H12AffineEnvironment.transform 9 47 env7156 = env7157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env7156 == env7157) = true)

theorem identity7157 : scanCanonicalize (H12AffineFastState.compose env7157 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound7157 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env7158 : List Nat := [2,4,8,16,1,26,2,4,512,14,2048,4096,2,16384,1,2,4123,2059,4,1,16400,1,26,8,8,16,2048,4123,4096,2059,4,11,14,11,16384,512]

theorem envBound7158 : H12AffineFastState.Bounded env7158 := by
  intro p hp
  have h : env7158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7157_7158 : H12AffineEnvironment.transform 4 1 env7157 = env7158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env7157 == env7158) = true)

theorem identity7158 : scanCanonicalize (H12AffineFastState.compose env7158 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound7158 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env7159 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,4096,2,16384,1,2,4113,2049,4,1,16400,1,16,2,2,16,2048,4113,4096,2049,4,1,4,1,16384,512]

theorem envBound7159 : H12AffineFastState.Bounded env7159 := by
  intro p hp
  have h : env7159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7158_7159 : H12AffineEnvironment.transform 2 2 env7158 = env7159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env7158 == env7159) = true)

def env7160 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,0,2,16384,1,2,17,2049,4,1,16400,1,16,2,2,16,2048,17,0,2049,4,1,4,1,16384,512]

theorem envBound7160 : H12AffineFastState.Bounded env7160 := by
  intro p hp
  have h : env7160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7159_7160 : H12AffineEnvironment.transform 11 0 env7159 = env7160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env7159 == env7160) = true)

theorem identity7160 : scanCanonicalize (H12AffineFastState.compose env7160 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 18) := by decide +kernel

theorem selectedBound7160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7161 : List Nat := [2,4,2,16,1,16,2,4,18,4,2048,0,2,16384,1,2,17,2049,4,1,16400,1,16,2,2,16,2048,17,0,2049,4,1,4,1,16384,18]

theorem envBound7161 : H12AffineFastState.Bounded env7161 := by
  intro p hp
  have h : env7161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7160_7161 : H12AffineEnvironment.transform 8 18 env7160 = env7161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 18 env7160 == env7161) = true)

def env7162 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,0,2,16384,1,2,1,2049,4,1,16384,1,0,2,2,0,2048,1,0,2049,4,1,4,1,16384,2]

theorem envBound7162 : H12AffineFastState.Bounded env7162 := by
  intro p hp
  have h : env7162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7161_7162 : H12AffineEnvironment.transform 3 0 env7161 = env7162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env7161 == env7162) = true)

theorem identity7162 : scanCanonicalize (H12AffineFastState.compose env7162 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2052) := by decide +kernel

theorem selectedBound7162 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7163 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,0,2,2052,1,2,1,2049,4,1,2052,1,0,2,2,0,2048,1,0,2049,4,1,4,1,2052,2]

theorem envBound7163 : H12AffineFastState.Bounded env7163 := by
  intro p hp
  have h : env7163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7162_7163 : H12AffineEnvironment.transform 13 2052 env7162 = env7163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2052 env7162 == env7163) = true)

def leafEnv7163 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,0,2,2052,1,2,1,2049,4,1,2052,1,0,2,4,2,1,0,2048,1,0,2049,4,1,4,1,4,2,2052,2,1,2052,0]

def active7163 : List Nat := [0,1,10]

def tree7163 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7163 : H12WitnessSearch.Good tree7163 := H12GlobalWitnessIndex.good

theorem leafIdentity7163 : H12AffineFastState.composeSystem env7163 rootObs = leafEnv7163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7163 rootObs == leafEnv7163) = true)

theorem terminalChecked7163 : H12PackedTerminal.terminalCheckFast leafEnv7163 active7163 tree7163 = true := by decide +kernel

def env7164 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,0,2,16384,1,2,0,2049,4,1,16385,1,1,2,2,1,2048,0,0,2049,4,1,4,1,16384,3]

theorem envBound7164 : H12AffineFastState.Bounded env7164 := by
  intro p hp
  have h : env7164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7161_7164 : H12AffineEnvironment.transform 3 1 env7161 = env7164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env7161 == env7164) = true)

theorem identity7164 : scanCanonicalize (H12AffineFastState.compose env7164 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2054) := by decide +kernel

theorem selectedBound7164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7165 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,0,2,2054,1,2,0,2049,4,1,2055,1,1,2,2,1,2048,0,0,2049,4,1,4,1,2054,3]

theorem envBound7165 : H12AffineFastState.Bounded env7165 := by
  intro p hp
  have h : env7165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7164_7165 : H12AffineEnvironment.transform 13 2054 env7164 = env7165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2054 env7164 == env7165) = true)

def leafEnv7165 : List Nat := [2,4,2,1,1,1,2,4,3,4,2048,0,2,2054,1,2,0,2049,4,1,2055,1,1,2,4,2,1,1,2048,0,0,2049,4,1,4,1,4,2,2054,3,1,2055,0]

def active7165 : List Nat := [0,1,10]

def tree7165 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7165 : H12WitnessSearch.Good tree7165 := H12GlobalWitnessIndex.good

theorem leafIdentity7165 : H12AffineFastState.composeSystem env7165 rootObs = leafEnv7165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7165 rootObs == leafEnv7165) = true)

theorem terminalChecked7165 : H12PackedTerminal.terminalCheckFast leafEnv7165 active7165 tree7165 = true := by decide +kernel

def env7166 : List Nat := [2,4,2,16,1,16,2,4,512,4,2048,1,2,16384,1,2,16,2049,4,1,16400,1,16,2,2,16,2048,16,1,2049,4,1,4,1,16384,512]

theorem envBound7166 : H12AffineFastState.Bounded env7166 := by
  intro p hp
  have h : env7166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7159_7166 : H12AffineEnvironment.transform 11 1 env7159 = env7166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env7159 == env7166) = true)

theorem identity7166 : scanCanonicalize (H12AffineFastState.compose env7166 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound7166 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env7167 : List Nat := [2,4,2,16,1,16,2,4,2,4,2048,1,2,16384,1,2,16,2049,4,1,16400,1,16,2,2,16,2048,16,1,2049,4,1,4,1,16384,2]

theorem envBound7167 : H12AffineFastState.Bounded env7167 := by
  intro p hp
  have h : env7167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7166_7167 : H12AffineEnvironment.transform 8 2 env7166 = env7167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env7166 == env7167) = true)

def env7168 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,1,2,16384,1,2,0,2049,4,1,16384,1,0,2,2,0,2048,0,1,2049,4,1,4,1,16384,2]

theorem envBound7168 : H12AffineFastState.Bounded env7168 := by
  intro p hp
  have h : env7168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7167_7168 : H12AffineEnvironment.transform 3 0 env7167 = env7168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env7167 == env7168) = true)

theorem identity7168 : scanCanonicalize (H12AffineFastState.compose env7168 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2053) := by decide +kernel

theorem selectedBound7168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7169 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,1,2,2053,1,2,0,2049,4,1,2053,1,0,2,2,0,2048,0,1,2049,4,1,4,1,2053,2]

theorem envBound7169 : H12AffineFastState.Bounded env7169 := by
  intro p hp
  have h : env7169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7168_7169 : H12AffineEnvironment.transform 13 2053 env7168 = env7169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2053 env7168 == env7169) = true)

def leafEnv7169 : List Nat := [2,4,2,0,1,0,2,4,2,4,2048,1,2,2053,1,2,0,2049,4,1,2053,1,0,2,4,2,1,0,2048,0,1,2049,4,1,4,1,4,2,2053,2,1,2053,0]

def active7169 : List Nat := [0,1,10]

def tree7169 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7169 : H12WitnessSearch.Good tree7169 := H12GlobalWitnessIndex.good

theorem leafIdentity7169 : H12AffineFastState.composeSystem env7169 rootObs = leafEnv7169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7169 rootObs == leafEnv7169) = true)

theorem terminalChecked7169 : H12PackedTerminal.terminalCheckFast leafEnv7169 active7169 tree7169 = true := by decide +kernel

def env7170 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,1,2,16384,1,2,1,2049,4,1,16385,1,1,2,2,1,2048,1,1,2049,4,1,4,1,16384,2]

theorem envBound7170 : H12AffineFastState.Bounded env7170 := by
  intro p hp
  have h : env7170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7167_7170 : H12AffineEnvironment.transform 3 1 env7167 = env7170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env7167 == env7170) = true)

theorem identity7170 : scanCanonicalize (H12AffineFastState.compose env7170 (packedSelected [1] rootPS)) = affineNative (2^(13+1) ^^^ 2054) := by decide +kernel

theorem selectedBound7170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env7171 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,1,2,2054,1,2,1,2049,4,1,2055,1,1,2,2,1,2048,1,1,2049,4,1,4,1,2054,2]

theorem envBound7171 : H12AffineFastState.Bounded env7171 := by
  intro p hp
  have h : env7171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7170_7171 : H12AffineEnvironment.transform 13 2054 env7170 = env7171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2054 env7170 == env7171) = true)

def leafEnv7171 : List Nat := [2,4,2,1,1,1,2,4,2,4,2048,1,2,2054,1,2,1,2049,4,1,2055,1,1,2,4,2,1,1,2048,1,1,2049,4,1,4,1,4,2,2054,2,1,2055,0]

def active7171 : List Nat := [0,1,10]

def tree7171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood7171 : H12WitnessSearch.Good tree7171 := H12GlobalWitnessIndex.good

theorem leafIdentity7171 : H12AffineFastState.composeSystem env7171 rootObs = leafEnv7171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env7171 rootObs == leafEnv7171) = true)

theorem terminalChecked7171 : H12PackedTerminal.terminalCheckFast leafEnv7171 active7171 tree7171 = true := by decide +kernel

def env7172 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,131072,262144,432180,32768,17597,32801,8388608,8789167,41,400501,262281,8784073,8657097,8787116,1193,32937,433353,8789133,8702153,512]

theorem envBound7172 : H12AffineFastState.Bounded env7172 := by
  intro p hp
  have h : env7172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7149_7172 : H12AffineEnvironment.transform 34 8702153 env7149 = env7172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 8702153 env7149 == env7172) = true)

theorem identity7172 : scanCanonicalize (H12AffineFastState.compose env7172 (packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound7172 : packedSelected [0,1,3,5,7,8,11,12,13,14] rootPS < 2^1333 := by decide +kernel

def env7173 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5356,262144,298200,32768,17597,32801,8388608,8652867,41,264345,262281,8657957,8657097,8650816,1193,32937,296997,8652897,8702153,512]

theorem envBound7173 : H12AffineFastState.Bounded env7173 := by
  intro p hp
  have h : env7173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7172_7173 : H12AffineEnvironment.transform 16 5356 env7172 = env7173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env7172 == env7173) = true)

theorem identity7173 : scanCanonicalize (H12AffineFastState.compose env7173 (packedSelected [4,9,11] rootPS)) = affineNative (2^(22+1) ^^^ 297160) := by decide +kernel

theorem selectedBound7173 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env7174 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,161,16384,32768,32802,5356,262144,298200,32768,17597,32801,297160,32907,41,264345,262281,38125,36865,34952,1193,32937,296997,32937,16385,512]

theorem envBound7174 : H12AffineFastState.Bounded env7174 := by
  intro p hp
  have h : env7174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7173_7174 : H12AffineEnvironment.transform 22 297160 env7173 = env7174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297160 env7173 == env7174) = true)

theorem identity7174 : scanCanonicalize (H12AffineFastState.compose env7174 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound7174 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env7175 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,32768,32802,5188,262144,298096,32768,17429,32801,297056,32803,41,264241,262177,37957,36865,34848,1025,32769,296997,32769,16385,512]

theorem envBound7175 : H12AffineFastState.Bounded env7175 := by
  intro p hp
  have h : env7175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7174_7175 : H12AffineEnvironment.transform 6 40 env7174 = env7175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env7174 == env7175) = true)

theorem identity7175 : scanCanonicalize (H12AffineFastState.compose env7175 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound7175 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env7176 : List Nat := [2,4,8,16,32,64,40,85,512,1024,2048,4096,9,16384,32768,32802,5188,2081,33873,32768,17429,32801,32833,32803,41,16,2048,37957,36865,34848,1025,32769,32772,32769,16385,512]

theorem envBound7176 : H12AffineFastState.Bounded env7176 := by
  intro p hp
  have h : env7176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7175_7176 : H12AffineEnvironment.transform 17 2081 env7175 = env7176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env7175 == env7176) = true)

def env7177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,41089,8388608,8988133,8328,599234,360619,11105475,11232451,8957381,99702,40968,525568,8955364,34359738368,98850]

theorem envBound7177 : H12AffineFastState.Bounded env7177 := by
  intro p hp
  have h : env7177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7138_7177 : H12AffineEnvironment.transform 21 41089 env7138 = env7177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env7138 == env7177) = true)

def env7178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,62640,32768,2097152,41089,8388608,8507733,8328,118898,360619,10584179,10719347,8411509,99702,40968,61872,8409428,34359738368,98850]

theorem envBound7178 : H12AffineFastState.Bounded env7178 := by
  intro p hp
  have h : env7178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7177_7178 : H12AffineEnvironment.transform 18 62640 env7177 = env7178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62640 env7177 == env7178) = true)

theorem identity7178 : scanCanonicalize (H12AffineFastState.compose env7178 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 103731) := by decide +kernel

theorem selectedBound7178 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env7179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103731,262144,62640,32768,2097152,41089,8388608,8507733,8328,118898,360619,10584179,10487104,8411509,99702,40968,61872,8409428,34359738368,98850]

theorem envBound7179 : H12AffineFastState.Bounded env7179 := by
  intro p hp
  have h : env7179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7178_7179 : H12AffineEnvironment.transform 16 103731 env7178 = env7179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103731 env7178 == env7179) = true)

end H12CloudChart1