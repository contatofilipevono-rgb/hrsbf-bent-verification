import H12CloudChart1Data020

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env5192 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,1044,8192,1588,8200,8714,1044,2081,1025,8200,1044,32,17,35,8225,16,2592,1589,1588,2560,1569,544,5,545,1044,512]

theorem envBound5192 : H12AffineFastState.Bounded env5192 := by
  intro p hp
  have h : env5192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5191_5192 : H12AffineEnvironment.transform 7 4 env5191 = env5192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5191 == env5192) = true)

theorem identity5192 : scanCanonicalize (H12AffineFastState.compose env5192 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5192 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5193 : List Nat := [2,4,8,16,32,17,40,4,0,1024,2048,1044,8192,1076,8200,8202,1044,2081,1025,8200,1044,32,17,35,8225,16,2080,1077,1076,2048,1057,32,5,33,1044,0]

theorem envBound5193 : H12AffineFastState.Bounded env5193 := by
  intro p hp
  have h : env5193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5192_5193 : H12AffineEnvironment.transform 8 0 env5192 = env5193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5192 == env5193) = true)

theorem identity5193 : scanCanonicalize (H12AffineFastState.compose env5193 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3111) := by decide +kernel

theorem selectedBound5193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5194 : List Nat := [2,4,8,16,32,17,40,4,0,1024,2048,1044,3111,1076,3119,3117,1044,2081,1025,3119,1044,32,17,35,3078,16,2080,1077,1076,2048,1057,32,5,33,1044,0]

theorem envBound5194 : H12AffineFastState.Bounded env5194 := by
  intro p hp
  have h : env5194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5193_5194 : H12AffineEnvironment.transform 12 3111 env5193 = env5194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3111 env5193 == env5194) = true)

theorem identity5194 : scanCanonicalize (H12AffineFastState.compose env5194 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound5194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5195 : List Nat := [2,4,8,16,32,17,40,4,0,46,2048,58,2057,26,2049,2051,58,2081,47,2049,58,32,17,35,2088,16,2080,27,26,2048,15,32,5,33,58,0]

theorem envBound5195 : H12AffineFastState.Bounded env5195 := by
  intro p hp
  have h : env5195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5194_5195 : H12AffineEnvironment.transform 9 46 env5194 = env5195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env5194 == env5195) = true)

def env5196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849104,16385,16893,547953,598058,12644668,525568,545872,4239489,8914925]

theorem envBound5196 : H12AffineFastState.Bounded env5196 := by
  intro p hp
  have h : env5196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5075_5196 : H12AffineEnvironment.transform 20 4097 env5075 = env5196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5075 == env5196) = true)

def env5197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323792,16385,16893,22641,74794,12644668,256,20560,4239489,8389613]

theorem envBound5197 : H12AffineFastState.Bounded env5197 := by
  intro p hp
  have h : env5197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5196_5197 : H12AffineEnvironment.transform 18 1024 env5196 = env5197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5196 == env5197) = true)

theorem identity5197 : scanCanonicalize (H12AffineFastState.compose env5197 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4255800) := by decide +kernel

theorem selectedBound5197 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4255800,41003,8329,4255849,323792,16385,16893,22641,74794,260,256,20560,4239489,4256725]

theorem envBound5198 : H12AffineFastState.Bounded env5198 := by
  intro p hp
  have h : env5198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5197_5198 : H12AffineEnvironment.transform 22 4255800 env5197 = env5198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4255800 env5197 == env5198) = true)

def env5199 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4255800,41003,8329,4255801,323712,16385,16813,22561,74794,260,256,20480,4239489,4256645]

theorem envBound5199 : H12AffineFastState.Bounded env5199 := by
  intro p hp
  have h : env5199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5198_5199 : H12AffineEnvironment.transform 5 16 env5198 = env5199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5198 == env5199) = true)

def env5200 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,136,61616,41003,8329,61617,323712,16385,16813,22561,74794,260,256,20480,45065,62221]

theorem envBound5200 : H12AffineFastState.Bounded env5200 := by
  intro p hp
  have h : env5200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5199_5200 : H12AffineEnvironment.transform 21 136 env5199 = env5200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env5199 == env5200) = true)

theorem identity5200 : scanCanonicalize (H12AffineFastState.compose env5200 (packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 93759) := by decide +kernel

theorem selectedBound5200 : packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5201 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,93759,1024,32768,4097,136,61616,41003,8329,61617,106175,16385,16813,22561,74794,260,256,20480,45065,62221]

theorem envBound5201 : H12AffineFastState.Bounded env5201 := by
  intro p hp
  have h : env5201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5200_5201 : H12AffineEnvironment.transform 17 93759 env5200 = env5201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 93759 env5200 == env5201) = true)

def env5202 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4373,93759,1024,32768,4097,48,61448,41003,8241,61449,105991,16385,16661,22561,74794,260,256,20480,45065,62221]

theorem envBound5202 : H12AffineFastState.Bounded env5202 := by
  intro p hp
  have h : env5202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5201_5202 : H12AffineEnvironment.transform 6 56 env5201 = env5202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5201 == env5202) = true)

theorem identity5202 : scanCanonicalize (H12AffineFastState.compose env5202 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound5202 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5203 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,65536,4373,93759,1024,28681,4097,48,1,20514,8241,0,93710,16385,16661,22561,74794,260,256,20480,16384,772]

theorem envBound5203 : H12AffineFastState.Bounded env5203 := by
  intro p hp
  have h : env5203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5202_5203 : H12AffineEnvironment.transform 14 28681 env5202 = env5203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env5202 == env5203) = true)

theorem identity5203 : scanCanonicalize (H12AffineFastState.compose env5203 (packedSelected [3,5,9,10,17,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound5203 : packedSelected [3,5,9,10,17,21,22] rootPS < 2^1333 := by decide +kernel

def env5204 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,8251,4373,19972,1024,28681,4097,48,1,20514,8241,0,20021,16385,16661,22561,1041,260,256,20480,16384,772]

theorem envBound5204 : H12AffineFastState.Bounded env5204 := by
  intro p hp
  have h : env5204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5203_5204 : H12AffineEnvironment.transform 15 8251 env5203 = env5204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env5203 == env5204) = true)

theorem identity5204 : scanCanonicalize (H12AffineFastState.compose env5204 (packedSelected [1,3,8,10,13,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1825) := by decide +kernel

theorem selectedBound5204 : packedSelected [1,3,8,10,13,21,24] rootPS < 2^1333 := by decide +kernel

def env5205 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,1825,14120,8251,4373,2341,1024,14120,4097,48,1,5891,8241,0,2324,1824,1588,7936,1041,260,256,5921,1825,772]

theorem envBound5205 : H12AffineFastState.Bounded env5205 := by
  intro p hp
  have h : env5205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5204_5205 : H12AffineEnvironment.transform 13 1825 env5204 = env5205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1825 env5204 == env5205) = true)

theorem identity5205 : scanCanonicalize (H12AffineFastState.compose env5205 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound5205 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5206 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,1824,8192,1825,8200,8251,1589,2341,1024,8200,1825,48,1,35,8241,0,2324,1824,1588,2080,1041,260,256,1,1825,772]

theorem envBound5206 : H12AffineFastState.Bounded env5206 := by
  intro p hp
  have h : env5206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5205_5206 : H12AffineEnvironment.transform 11 1824 env5205 = env5206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env5205 == env5206) = true)

theorem identity5206 : scanCanonicalize (H12AffineFastState.compose env5206 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5206 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5207 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1572,8192,1573,8200,8251,1589,2081,1024,8200,1573,48,1,35,8241,0,2064,1572,1588,2080,1041,0,4,1,1573,512]

theorem envBound5207 : H12AffineFastState.Bounded env5207 := by
  intro p hp
  have h : env5207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5206_5207 : H12AffineEnvironment.transform 7 4 env5206 = env5207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5206 == env5207) = true)

theorem identity5207 : scanCanonicalize (H12AffineFastState.compose env5207 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound5207 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5208 : List Nat := [2,4,8,16,16,16,8,4,512,1024,2048,1556,8192,1557,8200,8203,1541,2065,1024,8200,1557,0,1,19,8193,0,2064,1556,1540,2064,1041,0,4,1,1557,512]

theorem envBound5208 : H12AffineFastState.Bounded env5208 := by
  intro p hp
  have h : env5208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5207_5208 : H12AffineEnvironment.transform 4 16 env5207 = env5208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env5207 == env5208) = true)

theorem identity5208 : scanCanonicalize (H12AffineFastState.compose env5208 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound5208 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5209 : List Nat := [2,4,8,16,16,16,8,4,512,1024,538,1556,8192,1557,8200,8203,1541,523,1024,8200,1557,0,1,19,8193,0,522,1556,1540,522,1041,0,4,1,1557,512]

theorem envBound5209 : H12AffineFastState.Bounded env5209 := by
  intro p hp
  have h : env5209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5208_5209 : H12AffineEnvironment.transform 10 538 env5208 = env5209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env5208 == env5209) = true)

theorem identity5209 : scanCanonicalize (H12AffineFastState.compose env5209 (packedSelected [2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5209 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env5210 : List Nat := [2,4,8,16,16,16,8,4,0,1024,26,1044,8192,1045,8200,8203,1029,11,1024,8200,1045,0,1,19,8193,0,10,1044,1028,10,1041,0,4,1,1045,0]

theorem envBound5210 : H12AffineFastState.Bounded env5210 := by
  intro p hp
  have h : env5210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5209_5210 : H12AffineEnvironment.transform 8 0 env5209 = env5210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5209 == env5210) = true)

theorem identity5210 : scanCanonicalize (H12AffineFastState.compose env5210 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5210 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env5211 : List Nat := [2,4,2,16,16,16,2,4,0,1024,16,1044,8192,1045,8194,8193,1029,1,1024,8194,1045,0,1,19,8193,0,0,1044,1028,0,1041,0,4,1,1045,0]

theorem envBound5211 : H12AffineFastState.Bounded env5211 := by
  intro p hp
  have h : env5211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5210_5211 : H12AffineEnvironment.transform 2 2 env5210 = env5211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5210 == env5211) = true)

theorem identity5211 : scanCanonicalize (H12AffineFastState.compose env5211 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound5211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5212 : List Nat := [2,4,2,16,16,16,2,4,0,1024,16,1044,19,1045,17,18,1029,1,1024,17,1045,0,1,19,18,0,0,1044,1028,0,1041,0,4,1,1045,0]

theorem envBound5212 : H12AffineFastState.Bounded env5212 := by
  intro p hp
  have h : env5212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5211_5212 : H12AffineEnvironment.transform 12 19 env5211 = env5212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env5211 == env5212) = true)

theorem identity5212 : scanCanonicalize (H12AffineFastState.compose env5212 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5212 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env5213 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,3,1029,1,2,1029,1,1024,1,1029,0,1,3,2,0,0,1028,1028,0,1025,0,4,1,1029,0]

theorem envBound5213 : H12AffineFastState.Bounded env5213 := by
  intro p hp
  have h : env5213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5212_5213 : H12AffineEnvironment.transform 3 0 env5212 = env5213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5212 == env5213) = true)

def leafEnv5213 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,3,1029,1,2,1029,1,1024,1,1029,0,1,3,1025,2,1,0,0,1028,1028,0,1025,0,4,1,4,2,1029,0,1,1028,0]

def active5213 : List Nat := [0,1,9]

def tree5213 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5213 : H12WitnessSearch.Good tree5213 := H12GlobalWitnessIndex.good

theorem leafIdentity5213 : H12AffineFastState.composeSystem env5213 rootObs = leafEnv5213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5213 rootObs == leafEnv5213) = true)

theorem terminalChecked5213 : H12PackedTerminal.terminalCheckFast leafEnv5213 active5213 tree5213 = true := by decide +kernel

def env5214 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4372,93759,1024,32768,4097,49,61449,41003,8240,61448,105990,16385,16660,22561,74794,260,256,20480,45065,62221]

theorem envBound5214 : H12AffineFastState.Bounded env5214 := by
  intro p hp
  have h : env5214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5201_5214 : H12AffineEnvironment.transform 6 57 env5201 = env5214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5201 == env5214) = true)

theorem identity5214 : scanCanonicalize (H12AffineFastState.compose env5214 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53543) := by decide +kernel

theorem selectedBound5214 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5215 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,53543,4372,48920,1024,32768,4097,49,61449,41003,8240,61448,20257,16385,16660,22561,62733,260,256,20480,45065,62221]

theorem envBound5215 : H12AffineFastState.Bounded env5215 := by
  intro p hp
  have h : env5215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5214_5215 : H12AffineEnvironment.transform 15 53543 env5214 = env5215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53543 env5214 == env5215) = true)

theorem identity5215 : scanCanonicalize (H12AffineFastState.compose env5215 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound5215 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5216 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,8494,4372,20241,1024,28681,4097,49,0,20514,8240,1,20257,16385,16660,22561,1284,260,256,20480,16384,772]

theorem envBound5216 : H12AffineFastState.Bounded env5216 := by
  intro p hp
  have h : env5216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5215_5216 : H12AffineEnvironment.transform 14 28681 env5215 = env5216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env5215 == env5216) = true)

theorem identity5216 : scanCanonicalize (H12AffineFastState.compose env5216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5217 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,16384,28681,8494,4356,20225,1024,28681,4097,33,0,20514,8224,1,20257,16385,16644,22561,1284,260,256,20480,16384,772]

theorem envBound5217 : H12AffineFastState.Bounded env5217 := by
  intro p hp
  have h : env5217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5216_5217 : H12AffineEnvironment.transform 3 0 env5216 = env5217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5216 == env5217) = true)

theorem identity5217 : scanCanonicalize (H12AffineFastState.compose env5217 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15117) := by decide +kernel

theorem selectedBound5217 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5218 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,8192,15117,2820,8494,4356,13324,1024,2820,4097,33,0,11055,8224,1,13356,15116,14857,9004,1284,260,256,11021,15117,772]

theorem envBound5218 : H12AffineFastState.Bounded env5218 := by
  intro p hp
  have h : env5218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5217_5218 : H12AffineEnvironment.transform 13 15117 env5217 = env5218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15117 env5217 == env5218) = true)

theorem identity5218 : scanCanonicalize (H12AffineFastState.compose env5218 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5218 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5219 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,4096,1030,7947,2820,1320,4356,4106,1024,2820,4097,33,0,3881,1062,1,4138,7946,7695,1834,1284,260,256,3851,7947,772]

theorem envBound5219 : H12AffineFastState.Bounded env5219 := by
  intro p hp
  have h : env5219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5218_5219 : H12AffineEnvironment.transform 12 1030 env5218 = env5219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5218 == env5219) = true)

theorem identity5219 : scanCanonicalize (H12AffineFastState.compose env5219 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5219 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5220 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1573,1030,2350,2820,1320,1825,1583,1024,2820,1572,33,0,3881,1062,1,1551,2351,2090,1834,1284,260,256,3851,2350,772]

theorem envBound5220 : H12AffineFastState.Bounded env5220 := by
  intro p hp
  have h : env5220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5219_5220 : H12AffineEnvironment.transform 11 1573 env5219 = env5220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env5219 == env5220) = true)

theorem identity5220 : scanCanonicalize (H12AffineFastState.compose env5220 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound5220 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env5221 : List Nat := [2,4,8,0,32,0,41,256,512,1024,1802,1573,1030,1572,1038,1320,1825,1583,1024,1038,1572,33,0,35,1062,1,1551,1573,1824,1834,1284,260,256,1,1572,772]

theorem envBound5221 : H12AffineFastState.Bounded env5221 := by
  intro p hp
  have h : env5221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5220_5221 : H12AffineEnvironment.transform 10 1802 env5220 = env5221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env5220 == env5221) = true)

theorem identity5221 : scanCanonicalize (H12AffineFastState.compose env5221 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound5221 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5222 : List Nat := [2,4,8,0,32,0,41,15,512,1024,1541,1573,1030,1572,1038,1063,1582,1583,1024,1038,1572,33,0,35,1062,1,1551,1573,1583,1573,1035,11,15,1,1572,523]

theorem envBound5222 : H12AffineFastState.Bounded env5222 := by
  intro p hp
  have h : env5222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5221_5222 : H12AffineEnvironment.transform 7 15 env5221 = env5222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env5221 == env5222) = true)

theorem identity5222 : scanCanonicalize (H12AffineFastState.compose env5222 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5222 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5223 : List Nat := [2,4,2,0,32,0,35,5,512,1024,1541,1573,1030,1572,1028,1063,1572,1573,1024,1028,1572,33,0,35,1062,1,1541,1573,1573,1573,1025,1,5,1,1572,513]

theorem envBound5223 : H12AffineFastState.Bounded env5223 := by
  intro p hp
  have h : env5223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5222_5223 : H12AffineEnvironment.transform 2 2 env5222 = env5223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5222 == env5223) = true)

theorem identity5223 : scanCanonicalize (H12AffineFastState.compose env5223 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound5223 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5224 : List Nat := [2,4,2,0,32,0,35,5,5,1024,1024,1056,1030,1057,1028,1063,1057,1056,1024,1028,1057,33,0,35,1062,1,1024,1056,1056,1056,1025,1,5,1,1057,4]

theorem envBound5224 : H12AffineFastState.Bounded env5224 := by
  intro p hp
  have h : env5224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5223_5224 : H12AffineEnvironment.transform 8 5 env5223 = env5224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env5223 == env5224) = true)

theorem identity5224 : scanCanonicalize (H12AffineFastState.compose env5224 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5224 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5225 : List Nat := [2,1,2,0,32,0,35,0,0,1024,1024,1056,1027,1057,1025,1058,1057,1056,1024,1025,1057,33,0,35,1059,1,1024,1056,1056,1056,1025,1,0,1,1057,1]

theorem envBound5225 : H12AffineFastState.Bounded env5225 := by
  intro p hp
  have h : env5225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5224_5225 : H12AffineEnvironment.transform 1 1 env5224 = env5225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5224 == env5225) = true)

theorem identity5225 : scanCanonicalize (H12AffineFastState.compose env5225 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 33) := by decide +kernel

theorem selectedBound5225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5226 : List Nat := [2,1,2,0,32,0,35,0,0,33,33,1,34,0,32,3,0,1,33,32,0,33,0,35,2,1,33,1,1,1,32,1,0,1,0,1]

theorem envBound5226 : H12AffineFastState.Bounded env5226 := by
  intro p hp
  have h : env5226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5225_5226 : H12AffineEnvironment.transform 9 33 env5225 = env5226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env5225 == env5226) = true)

def leafEnv5226 : List Nat := [2,1,2,0,32,0,35,0,0,33,33,1,34,0,32,3,0,1,33,32,0,33,0,35,32,2,1,1,33,1,1,1,32,1,0,1,1,35,0,1,1,0,0]

def active5226 : List Nat := [0,4]

def tree5226 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5226 : H12WitnessSearch.Good tree5226 := H12GlobalWitnessIndex.good

theorem leafIdentity5226 : H12AffineFastState.composeSystem env5226 rootObs = leafEnv5226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5226 rootObs == leafEnv5226) = true)

theorem terminalChecked5226 : H12PackedTerminal.terminalCheckFast leafEnv5226 active5226 tree5226 = true := by decide +kernel

def env5227 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,137,61617,41003,8329,61616,323712,16385,16813,22561,74794,260,256,20480,45064,62220]

theorem envBound5227 : H12AffineFastState.Bounded env5227 := by
  intro p hp
  have h : env5227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5199_5227 : H12AffineEnvironment.transform 21 137 env5199 = env5227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env5199 == env5227) = true)

theorem identity5227 : scanCanonicalize (H12AffineFastState.compose env5227 (packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 94099) := by decide +kernel

theorem selectedBound5227 : packedSelected [0,3,5,7,8,10,17,20,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5228 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,94099,1024,32768,4097,137,61617,41003,8329,61616,106259,16385,16813,22561,74794,260,256,20480,45064,62220]

theorem envBound5228 : H12AffineFastState.Bounded env5228 := by
  intro p hp
  have h : env5228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5227_5228 : H12AffineEnvironment.transform 17 94099 env5227 = env5228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94099 env5227 == env5228) = true)

def env5229 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,65536,4373,93995,1024,32768,4097,49,61449,41003,8241,61448,106259,16385,16661,22561,74794,260,256,20480,45064,62220]

theorem envBound5229 : H12AffineFastState.Bounded env5229 := by
  intro p hp
  have h : env5229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5228_5229 : H12AffineEnvironment.transform 6 56 env5228 = env5229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5228 == env5229) = true)

theorem identity5229 : scanCanonicalize (H12AffineFastState.compose env5229 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53543) := by decide +kernel

theorem selectedBound5229 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5230 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,32768,53543,4373,48652,1024,32768,4097,49,61449,41003,8241,61448,20020,16385,16661,22561,62733,260,256,20480,45064,62220]

theorem envBound5230 : H12AffineFastState.Bounded env5230 := by
  intro p hp
  have h : env5230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5229_5230 : H12AffineEnvironment.transform 15 53543 env5229 = env5230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53543 env5229 == env5230) = true)

theorem identity5230 : scanCanonicalize (H12AffineFastState.compose env5230 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound5230 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5231 : List Nat := [2,4,8,16,32,16,56,256,512,1024,2048,4096,8192,16384,28681,8494,4373,19973,1024,28681,4097,49,0,20514,8241,1,20020,16385,16661,22561,1284,260,256,20480,16385,773]

theorem envBound5231 : H12AffineFastState.Bounded env5231 := by
  intro p hp
  have h : env5231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5230_5231 : H12AffineEnvironment.transform 14 28681 env5230 = env5231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env5230 == env5231) = true)

theorem identity5231 : scanCanonicalize (H12AffineFastState.compose env5231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5232 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,16384,28681,8494,4357,19973,1024,28681,4097,33,0,20514,8225,1,20004,16385,16645,22561,1284,260,256,20480,16385,773]

theorem envBound5232 : H12AffineFastState.Bounded env5232 := by
  intro p hp
  have h : env5232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5231_5232 : H12AffineEnvironment.transform 3 0 env5231 = env5232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5231 == env5232) = true)

theorem identity5232 : scanCanonicalize (H12AffineFastState.compose env5232 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15148) := by decide +kernel

theorem selectedBound5232 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5233 : List Nat := [2,4,8,0,32,0,40,256,512,1024,2048,4096,8192,15148,2853,8494,4357,13609,1024,2853,4097,33,0,11022,8225,1,13576,15149,14889,8973,1284,260,256,11052,15149,773]

theorem envBound5233 : H12AffineFastState.Bounded env5233 := by
  intro p hp
  have h : env5233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5232_5233 : H12AffineEnvironment.transform 13 15148 env5232 = env5233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15148 env5232 == env5233) = true)

theorem identity5233 : scanCanonicalize (H12AffineFastState.compose env5233 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5233 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5234 : List Nat := [2,4,8,0,32,0,40,256,512,1024,1550,4096,8192,13602,1323,8494,4357,13609,1024,1323,4097,33,0,9472,8225,1,13576,13603,13351,8973,1284,260,256,9506,13603,773]

theorem envBound5234 : H12AffineFastState.Bounded env5234 := by
  intro p hp
  have h : env5234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5233_5234 : H12AffineEnvironment.transform 10 1550 env5233 = env5234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env5233 == env5234) = true)

theorem identity5234 : scanCanonicalize (H12AffineFastState.compose env5234 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound5234 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5235 : List Nat := [2,4,8,0,32,0,40,256,512,1024,1550,1825,8192,8707,1323,8494,1572,8712,1024,1323,1824,33,0,9472,8225,1,8745,8706,8966,8973,1284,260,256,9506,8706,773]

theorem envBound5235 : H12AffineFastState.Bounded env5235 := by
  intro p hp
  have h : env5235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5234_5235 : H12AffineEnvironment.transform 11 1825 env5234 = env5235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env5234 == env5235) = true)

theorem identity5235 : scanCanonicalize (H12AffineFastState.compose env5235 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5235 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5236 : List Nat := [2,4,8,0,32,0,40,5,512,1024,1550,1572,8192,8707,1070,8235,1572,8712,1024,1070,1573,33,0,9221,8225,1,8745,8706,8707,8712,1025,1,5,9255,8706,512]

theorem envBound5236 : H12AffineFastState.Bounded env5236 := by
  intro p hp
  have h : env5236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5235_5236 : H12AffineEnvironment.transform 7 5 env5235 = env5236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5235 == env5236) = true)

theorem identity5236 : scanCanonicalize (H12AffineFastState.compose env5236 (packedSelected [1,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 547) := by decide +kernel

theorem selectedBound5236 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env5237 : List Nat := [2,4,8,0,32,0,40,5,512,1024,1550,1572,547,32,1070,520,1572,43,1024,1070,1573,33,0,1574,514,1,10,33,32,43,1025,1,5,1540,33,512]

theorem envBound5237 : H12AffineFastState.Bounded env5237 := by
  intro p hp
  have h : env5237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5236_5237 : H12AffineEnvironment.transform 12 547 env5236 = env5237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 547 env5236 == env5237) = true)

theorem identity5237 : scanCanonicalize (H12AffineFastState.compose env5237 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5237 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5238 : List Nat := [2,4,8,0,32,0,40,5,512,14,512,554,547,32,32,520,554,43,14,32,555,33,0,552,514,1,10,33,32,43,15,1,5,522,33,512]

theorem envBound5238 : H12AffineFastState.Bounded env5238 := by
  intro p hp
  have h : env5238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5237_5238 : H12AffineEnvironment.transform 9 14 env5237 = env5238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5237 == env5238) = true)

theorem identity5238 : scanCanonicalize (H12AffineFastState.compose env5238 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound5238 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5239 : List Nat := [2,4,8,0,32,0,40,5,43,14,43,1,8,32,32,35,1,43,14,32,0,33,0,3,41,1,10,33,32,43,15,1,5,33,33,43]

theorem envBound5239 : H12AffineFastState.Bounded env5239 := by
  intro p hp
  have h : env5239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5238_5239 : H12AffineEnvironment.transform 8 43 env5238 = env5239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env5238 == env5239) = true)

theorem identity5239 : scanCanonicalize (H12AffineFastState.compose env5239 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5239 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5240 : List Nat := [2,4,2,0,32,0,34,5,33,4,33,1,2,32,32,35,1,33,4,32,0,33,0,3,35,1,0,33,32,33,5,1,5,33,33,33]

theorem envBound5240 : H12AffineFastState.Bounded env5240 := by
  intro p hp
  have h : env5240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5239_5240 : H12AffineEnvironment.transform 2 2 env5239 = env5240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5239 == env5240) = true)

theorem identity5240 : scanCanonicalize (H12AffineFastState.compose env5240 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5241 : List Nat := [2,4,2,0,1,0,3,5,0,4,0,1,2,1,1,2,1,0,4,1,0,0,0,3,2,1,0,0,1,0,5,1,5,0,0,0]

theorem envBound5241 : H12AffineFastState.Bounded env5241 := by
  intro p hp
  have h : env5241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5240_5241 : H12AffineEnvironment.transform 4 1 env5240 = env5241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5240 == env5241) = true)

def env5242 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,32768,65536,4372,93994,1024,32768,4097,48,61448,41003,8240,61449,106259,16385,16660,22561,74794,260,256,20480,45064,62220]

theorem envBound5242 : H12AffineFastState.Bounded env5242 := by
  intro p hp
  have h : env5242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5228_5242 : H12AffineEnvironment.transform 6 57 env5228 = env5242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env5228 == env5242) = true)

theorem identity5242 : scanCanonicalize (H12AffineFastState.compose env5242 (packedSelected [0,2,7,13,17,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound5242 : packedSelected [0,2,7,13,17,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5243 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,65536,4372,93994,1024,28681,4097,48,1,20514,8240,0,93978,16385,16660,22561,74794,260,256,20480,16385,773]

theorem envBound5243 : H12AffineFastState.Bounded env5243 := by
  intro p hp
  have h : env5243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5242_5243 : H12AffineEnvironment.transform 14 28681 env5242 = env5243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env5242 == env5243) = true)

theorem identity5243 : scanCanonicalize (H12AffineFastState.compose env5243 (packedSelected [3,5,9,10,17,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound5243 : packedSelected [3,5,9,10,17,21,22] rootPS < 2^1333 := by decide +kernel

def env5244 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,16384,28681,8250,4372,20240,1024,28681,4097,48,1,20514,8240,0,20256,16385,16660,22561,1040,260,256,20480,16385,773]

theorem envBound5244 : H12AffineFastState.Bounded env5244 := by
  intro p hp
  have h : env5244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5243_5244 : H12AffineEnvironment.transform 15 8250 env5243 = env5244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env5243 == env5244) = true)

theorem identity5244 : scanCanonicalize (H12AffineFastState.compose env5244 (packedSelected [1,3,8,10,13,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound5244 : packedSelected [1,3,8,10,13,21,24] rootPS < 2^1333 := by decide +kernel

def env5245 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,4096,8192,4097,8200,8250,4372,7953,1024,8200,4097,48,1,35,8240,0,7969,4096,4373,2080,1040,260,256,1,4096,773]

theorem envBound5245 : H12AffineFastState.Bounded env5245 := by
  intro p hp
  have h : env5245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5244_5245 : H12AffineEnvironment.transform 13 4097 env5244 = env5245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5244 == env5245) = true)

theorem identity5245 : scanCanonicalize (H12AffineFastState.compose env5245 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1824) := by decide +kernel

theorem selectedBound5245 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5246 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,1824,8192,1825,8200,8250,1588,2097,1024,8200,1825,48,1,35,8240,0,2049,1824,1589,2080,1040,260,256,1,1824,773]

theorem envBound5246 : H12AffineFastState.Bounded env5246 := by
  intro p hp
  have h : env5246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5245_5246 : H12AffineEnvironment.transform 11 1824 env5245 = env5246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1824 env5245 == env5246) = true)

def env5247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4255800,41003,8329,4255800,323713,16385,16812,22560,74794,260,256,20481,4239489,4256644]

theorem envBound5247 : H12AffineFastState.Bounded env5247 := by
  intro p hp
  have h : env5247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5198_5247 : H12AffineEnvironment.transform 5 17 env5198 = env5247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5198 == env5247) = true)

theorem identity5247 : scanCanonicalize (H12AffineFastState.compose env5247 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 61828) := by decide +kernel

theorem selectedBound5247 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5248 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61828,444,41003,8329,444,323713,16385,16812,22560,74794,260,256,20481,16645,512]

theorem envBound5248 : H12AffineFastState.Bounded env5248 := by
  intro p hp
  have h : env5248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5247_5248 : H12AffineEnvironment.transform 21 61828 env5247 = env5248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61828 env5247 == env5248) = true)

theorem identity5248 : scanCanonicalize (H12AffineFastState.compose env5248 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound5248 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5249 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1024,32768,4097,41348,444,41003,8329,444,303233,4097,4524,2080,74794,260,256,1,4357,512]

theorem envBound5249 : H12AffineFastState.Bounded env5249 := by
  intro p hp
  have h : env5249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5248_5249 : H12AffineEnvironment.transform 13 4096 env5248 = env5249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5248 == env5249) = true)

theorem identity5249 : scanCanonicalize (H12AffineFastState.compose env5249 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound5249 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5250 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,65536,4524,262144,1024,13972,4097,5904,444,5823,8329,444,267797,4097,4524,2080,74794,260,256,1,4357,512]

theorem envBound5250 : H12AffineFastState.Bounded env5250 := by
  intro p hp
  have h : env5250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5249_5250 : H12AffineEnvironment.transform 14 13972 env5249 = env5250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env5249 == env5250) = true)

theorem identity5250 : scanCanonicalize (H12AffineFastState.compose env5250 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound5250 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5251 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,262144,1024,13972,4097,5904,444,5823,8329,444,267797,4097,4524,2080,1192,260,256,1,4357,512]

theorem envBound5251 : H12AffineFastState.Bounded env5251 := by
  intro p hp
  have h : env5251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5250_5251 : H12AffineEnvironment.transform 15 8322 env5250 = env5251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env5250 == env5251) = true)

theorem identity5251 : scanCanonicalize (H12AffineFastState.compose env5251 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5251 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5252 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,2080,1024,13972,4097,5904,444,5823,8329,444,7733,4097,4524,2080,1192,260,256,1,4357,512]

theorem envBound5252 : H12AffineFastState.Bounded env5252 := by
  intro p hp
  have h : env5252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5251_5252 : H12AffineEnvironment.transform 17 2080 env5251 = env5252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5251 == env5252) = true)

theorem identity5252 : scanCanonicalize (H12AffineFastState.compose env5252 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound5252 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5253 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1693,8192,1693,8201,8322,1841,2080,1024,8201,1692,397,444,34,8329,444,2216,1692,1841,2080,1192,260,256,1,1944,512]

theorem envBound5253 : H12AffineFastState.Bounded env5253 := by
  intro p hp
  have h : env5253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5252_5253 : H12AffineEnvironment.transform 11 1693 env5252 = env5253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env5252 == env5253) = true)

theorem identity5253 : scanCanonicalize (H12AffineFastState.compose env5253 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5253 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5254 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1693,8192,1693,8201,8322,1692,2080,1024,8201,1692,32,17,34,8329,17,2216,1692,1692,2080,1192,169,173,1,1589,512]

theorem envBound5254 : H12AffineFastState.Bounded env5254 := by
  intro p hp
  have h : env5254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5253_5254 : H12AffineEnvironment.transform 7 173 env5253 = env5254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5253 == env5254) = true)

theorem identity5254 : scanCanonicalize (H12AffineFastState.compose env5254 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound5254 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5255 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,8192,1693,8201,8322,1692,643,1024,8201,1692,32,17,34,8329,17,523,1692,1692,643,1192,169,173,1,1589,512]

theorem envBound5255 : H12AffineFastState.Bounded env5255 := by
  intro p hp
  have h : env5255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5254_5255 : H12AffineEnvironment.transform 10 675 env5254 = env5255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env5254 == env5255) = true)

theorem identity5255 : scanCanonicalize (H12AffineFastState.compose env5255 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound5255 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5256 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,35,1693,42,161,1692,643,1024,42,1692,32,17,34,170,17,523,1692,1692,643,1192,169,173,1,1589,512]

theorem envBound5256 : H12AffineFastState.Bounded env5256 := by
  intro p hp
  have h : env5256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5255_5256 : H12AffineEnvironment.transform 12 35 env5255 = env5256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env5255 == env5256) = true)

theorem identity5256 : scanCanonicalize (H12AffineFastState.compose env5256 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound5256 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5257 : List Nat := [2,4,8,16,32,17,25,52,512,1024,570,1540,35,1540,42,56,1541,538,1024,42,1541,32,17,34,51,17,523,1541,1541,538,1073,48,52,1,1589,512]

theorem envBound5257 : H12AffineFastState.Bounded env5257 := by
  intro p hp
  have h : env5257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5256_5257 : H12AffineEnvironment.transform 6 25 env5256 = env5257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env5256 == env5257) = true)

theorem identity5257 : scanCanonicalize (H12AffineFastState.compose env5257 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5257 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5258 : List Nat := [2,4,3,16,32,17,18,52,512,1024,561,1540,35,1540,33,51,1541,529,1024,33,1541,32,17,34,51,17,512,1541,1541,529,1073,48,52,1,1589,512]

theorem envBound5258 : H12AffineFastState.Bounded env5258 := by
  intro p hp
  have h : env5258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5257_5258 : H12AffineEnvironment.transform 2 3 env5257 = env5258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5257 == env5258) = true)

theorem identity5258 : scanCanonicalize (H12AffineFastState.compose env5258 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5258 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5259 : List Nat := [2,4,3,16,0,17,18,20,512,1024,529,1540,3,1540,1,19,1541,529,1024,1,1541,0,17,2,19,17,512,1541,1541,529,1041,16,20,1,1557,512]

theorem envBound5259 : H12AffineFastState.Bounded env5259 := by
  intro p hp
  have h : env5259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5258_5259 : H12AffineEnvironment.transform 4 0 env5258 = env5259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5258 == env5259) = true)

theorem identity5259 : scanCanonicalize (H12AffineFastState.compose env5259 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5259 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5260 : List Nat := [2,4,3,16,0,17,18,20,0,1024,17,1028,3,1028,1,19,1029,17,1024,1,1029,0,17,2,19,17,0,1029,1029,17,1041,16,20,1,1045,0]

theorem envBound5260 : H12AffineFastState.Bounded env5260 := by
  intro p hp
  have h : env5260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5259_5260 : H12AffineEnvironment.transform 8 0 env5259 = env5260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5259 == env5260) = true)

theorem identity5260 : scanCanonicalize (H12AffineFastState.compose env5260 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5261 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,3,1028,1,3,1029,1,1024,1,1029,0,1,2,3,1,0,1029,1029,1,1025,0,4,1,1029,0]

theorem envBound5261 : H12AffineFastState.Bounded env5261 := by
  intro p hp
  have h : env5261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5260_5261 : H12AffineEnvironment.transform 3 0 env5260 = env5261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5260 == env5261) = true)

def leafEnv5261 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,3,1028,1,3,1029,1,1024,1,1029,0,1,2,1025,3,1,1,0,1029,1029,1,1025,0,4,1,4,2,1029,0,1,1029,0]

def active5261 : List Nat := [0,1,9]

def tree5261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5261 : H12WitnessSearch.Good tree5261 := H12GlobalWitnessIndex.good

theorem leafIdentity5261 : H12AffineFastState.composeSystem env5261 rootObs = leafEnv5261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5261 rootObs == leafEnv5261) = true)

theorem terminalChecked5261 : H12PackedTerminal.terminalCheckFast leafEnv5261 active5261 tree5261 = true := by decide +kernel

def env5262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,12644668,257,20561,4239489,8389612]

theorem envBound5262 : H12AffineFastState.Bounded env5262 := by
  intro p hp
  have h : env5262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5196_5262 : H12AffineEnvironment.transform 18 1025 env5196 = env5262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5196 == env5262) = true)

theorem identity5262 : scanCanonicalize (H12AffineFastState.compose env5262 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 46392) := by decide +kernel

theorem selectedBound5262 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,46392,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,8406020,257,20561,1465,8389612]

theorem envBound5263 : H12AffineFastState.Bounded env5263 := by
  intro p hp
  have h : env5263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5262_5263 : H12AffineEnvironment.transform 21 46392 env5262 = env5263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env5262 == env5263) = true)

def env5264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46392,8388608,41003,8329,8388608,323713,16385,16813,22560,74795,8406020,257,20481,1465,8389564]

theorem envBound5264 : H12AffineFastState.Bounded env5264 := by
  intro p hp
  have h : env5264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5263_5264 : H12AffineEnvironment.transform 5 16 env5263 = env5264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5263 == env5264) = true)

theorem identity5264 : scanCanonicalize (H12AffineFastState.compose env5264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5265 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,46392,444,41003,8329,444,323713,16385,16813,22560,74795,17848,257,20481,1465,512]

theorem envBound5265 : H12AffineFastState.Bounded env5265 := by
  intro p hp
  have h : env5265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5264_5265 : H12AffineEnvironment.transform 22 444 env5264 = env5265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5264 == env5265) = true)

theorem identity5265 : scanCanonicalize (H12AffineFastState.compose env5265 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5265 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1025,32768,1212,41349,444,41003,8329,444,320572,16385,16813,19613,74795,17848,257,17596,1465,512]

theorem envBound5266 : H12AffineFastState.Bounded env5266 := by
  intro p hp
  have h : env5266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5265_5266 : H12AffineEnvironment.transform 11 1213 env5265 = env5266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5265 == env5266) = true)

theorem identity5266 : scanCanonicalize (H12AffineFastState.compose env5266 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5266 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5267 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1025,26261,1212,18192,444,18110,8329,444,262825,16385,16813,19613,74795,17848,257,17596,1465,512]

theorem envBound5267 : H12AffineFastState.Bounded env5267 := by
  intro p hp
  have h : env5267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5266_5267 : H12AffineEnvironment.transform 14 26261 env5266 = env5267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5266 == env5267) = true)

theorem identity5267 : scanCanonicalize (H12AffineFastState.compose env5267 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound5267 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25663,1296,262144,1025,26261,1212,18192,444,18110,8329,444,262825,16385,16813,19613,16404,17848,257,17596,1465,512]

theorem envBound5268 : H12AffineFastState.Bounded env5268 := by
  intro p hp
  have h : env5268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5267_5268 : H12AffineEnvironment.transform 15 25663 env5267 = env5268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env5267 == env5268) = true)

theorem identity5268 : scanCanonicalize (H12AffineFastState.compose env5268 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5268 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5269 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1045,8192,16384,26173,25663,1296,262144,1025,26173,1044,18192,276,17942,8225,276,262657,16385,16645,19509,16404,17680,257,17428,1297,512]

theorem envBound5269 : H12AffineFastState.Bounded env5269 := by
  intro p hp
  have h : env5269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5268_5269 : H12AffineEnvironment.transform 6 40 env5268 = env5269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5268 == env5269) = true)

def env5270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,46392,8388608,41003,8329,8388609,323712,16385,16812,22561,74795,8406020,257,20480,1465,8389565]

theorem envBound5270 : H12AffineFastState.Bounded env5270 := by
  intro p hp
  have h : env5270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5263_5270 : H12AffineEnvironment.transform 5 17 env5263 = env5270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5263 == env5270) = true)

def env5271 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46212,8388608,41003,8329,8388609,323712,16385,16400,22561,74795,8406020,189,20480,1029,8389121]

theorem envBound5271 : H12AffineFastState.Bounded env5271 := by
  intro p hp
  have h : env5271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5270_5271 : H12AffineEnvironment.transform 7 188 env5270 = env5271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5270 == env5271) = true)

theorem identity5271 : scanCanonicalize (H12AffineFastState.compose env5271 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 46261) := by decide +kernel

theorem selectedBound5271 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5272 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,4096,8192,16384,32768,65536,4112,262144,1025,32768,4097,46212,46261,41003,8329,46260,323712,16385,16400,22561,74795,61617,189,20480,1029,46772]

theorem envBound5272 : H12AffineFastState.Bounded env5272 := by
  intro p hp
  have h : env5272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5271_5272 : H12AffineEnvironment.transform 22 46261 env5271 = env5272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 46261 env5271 == env5272) = true)

def env5273 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,1025,32768,4097,46212,46245,41003,8329,46244,323712,16385,16384,22561,74795,61601,173,20480,1029,46756]

theorem envBound5273 : H12AffineFastState.Bounded env5273 := by
  intro p hp
  have h : env5273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5272_5273 : H12AffineEnvironment.transform 3 0 env5272 = env5273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5272 == env5273) = true)

theorem identity5273 : scanCanonicalize (H12AffineFastState.compose env5273 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound5273 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5274 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,262144,1025,32768,4097,46212,46245,41003,8329,46244,323712,16385,16384,22561,62472,61601,173,20480,1029,46756]

theorem envBound5274 : H12AffineFastState.Bounded env5274 := by
  intro p hp
  have h : env5274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5273_5274 : H12AffineEnvironment.transform 15 53283 env5273 = env5274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env5273 == env5274) = true)

theorem identity5274 : scanCanonicalize (H12AffineFastState.compose env5274 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 63529) := by decide +kernel

theorem selectedBound5274 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env5275 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,63529,1025,32768,4097,46212,46245,41003,8329,46244,2217,16385,16384,22561,62472,61601,173,20480,1029,46756]

theorem envBound5275 : H12AffineFastState.Bounded env5275 := by
  intro p hp
  have h : env5275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5274_5275 : H12AffineEnvironment.transform 17 63529 env5274 = env5275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63529 env5274 == env5275) = true)

theorem identity5275 : scanCanonicalize (H12AffineFastState.compose env5275 (packedSelected [0,3,5,7,10,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound5275 : packedSelected [0,3,5,7,10,18,20,23] rootPS < 2^1333 := by decide +kernel

def env5276 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,29313,8866,4096,2728,1025,29313,4097,17925,17956,21162,8329,17957,2217,16385,16384,22561,1673,544,173,20480,1029,17445]

theorem envBound5276 : H12AffineFastState.Bounded env5276 := by
  intro p hp
  have h : env5276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5275_5276 : H12AffineEnvironment.transform 14 29313 env5275 = env5276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env5275 == env5276) = true)

theorem identity5276 : scanCanonicalize (H12AffineFastState.compose env5276 (packedSelected [1,2,3,4,9,11,12,15,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 4641) := by decide +kernel

theorem selectedBound5276 : packedSelected [1,2,3,4,9,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env5277 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,4641,8352,8866,4096,2728,1025,8352,4097,5156,5125,139,8329,5124,2217,4640,4641,2560,1673,544,173,545,1029,5636]

theorem envBound5277 : H12AffineFastState.Bounded env5277 := by
  intro p hp
  have h : env5277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5276_5277 : H12AffineEnvironment.transform 13 4641 env5276 = env5277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4641 env5276 == env5277) = true)

theorem identity5277 : scanCanonicalize (H12AffineFastState.compose env5277 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound5277 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5278 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1676,8192,1197,8352,8866,1676,2728,1025,8352,1677,680,649,139,8329,648,2217,1196,1197,2560,1673,544,173,545,1029,136]

theorem envBound5278 : H12AffineFastState.Bounded env5278 := by
  intro p hp
  have h : env5278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5277_5278 : H12AffineEnvironment.transform 11 1676 env5277 = env5278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env5277 == env5278) = true)

theorem identity5278 : scanCanonicalize (H12AffineFastState.compose env5278 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound5278 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5279 : List Nat := [2,4,8,0,32,1,128,172,136,1024,2048,1028,8192,1197,8352,8234,1028,2080,1025,8352,1029,32,1,139,8329,0,2217,1196,1197,2184,1025,168,173,169,1029,136]

theorem envBound5279 : H12AffineFastState.Bounded env5279 := by
  intro p hp
  have h : env5279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5278_5279 : H12AffineEnvironment.transform 8 136 env5278 = env5279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env5278 == env5279) = true)

theorem identity5279 : scanCanonicalize (H12AffineFastState.compose env5279 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound5279 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5280 : List Nat := [2,4,8,0,32,1,8,36,0,1024,2048,1028,8192,1061,8232,8234,1028,2080,1025,8232,1029,32,1,3,8193,0,2081,1060,1061,2048,1025,32,37,33,1029,0]

theorem envBound5280 : H12AffineFastState.Bounded env5280 := by
  intro p hp
  have h : env5280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5279_5280 : H12AffineEnvironment.transform 6 8 env5279 = env5280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env5279 == env5280) = true)

theorem identity5280 : scanCanonicalize (H12AffineFastState.compose env5280 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3110) := by decide +kernel

theorem selectedBound5280 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5281 : List Nat := [2,4,8,0,32,1,8,36,0,1024,2048,1028,3110,1061,3086,3084,1028,2080,1025,3086,1029,32,1,3,3111,0,2081,1060,1061,2048,1025,32,37,33,1029,0]

theorem envBound5281 : H12AffineFastState.Bounded env5281 := by
  intro p hp
  have h : env5281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5280_5281 : H12AffineEnvironment.transform 12 3110 env5280 = env5281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3110 env5280 == env5281) = true)

theorem identity5281 : scanCanonicalize (H12AffineFastState.compose env5281 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound5281 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5282 : List Nat := [2,4,8,0,32,1,8,36,0,1024,1,1028,1063,1061,1039,1037,1028,33,1025,1039,1029,32,1,3,1062,0,32,1060,1061,1,1025,32,37,33,1029,0]

theorem envBound5282 : H12AffineFastState.Bounded env5282 := by
  intro p hp
  have h : env5282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5281_5282 : H12AffineEnvironment.transform 10 1 env5281 = env5282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env5281 == env5282) = true)

theorem identity5282 : scanCanonicalize (H12AffineFastState.compose env5282 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5282 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env5283 : List Nat := [2,4,8,0,10,1,8,14,0,1024,1,1028,1037,1039,1039,1037,1028,11,1025,1039,1029,10,1,3,1036,0,10,1038,1039,1,1025,10,15,11,1029,0]

theorem envBound5283 : H12AffineFastState.Bounded env5283 := by
  intro p hp
  have h : env5283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5282_5283 : H12AffineEnvironment.transform 4 10 env5282 = env5283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5282 == env5283) = true)

theorem identity5283 : scanCanonicalize (H12AffineFastState.compose env5283 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5283 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env5284 : List Nat := [2,4,3,0,1,1,3,5,0,1024,1,1028,1030,1028,1028,1030,1028,0,1025,1028,1029,1,1,3,1031,0,1,1029,1028,1,1025,1,4,0,1029,0]

theorem envBound5284 : H12AffineFastState.Bounded env5284 := by
  intro p hp
  have h : env5284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5283_5284 : H12AffineEnvironment.transform 2 3 env5283 = env5284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5283 == env5284) = true)

def env5285 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1025,32768,4097,46212,46244,41003,8329,46245,323712,16385,16385,22561,74795,61600,172,20480,1029,46757]

theorem envBound5285 : H12AffineFastState.Bounded env5285 := by
  intro p hp
  have h : env5285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5272_5285 : H12AffineEnvironment.transform 3 1 env5272 = env5285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5272 == env5285) = true)

theorem identity5285 : scanCanonicalize (H12AffineFastState.compose env5285 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5285 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5286 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8200,65536,4097,262144,1025,8200,4097,5260,5292,35,8329,5293,282760,16385,16385,22561,74795,20648,172,20480,1029,5805]

theorem envBound5286 : H12AffineFastState.Bounded env5286 := by
  intro p hp
  have h : env5286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5285_5286 : H12AffineEnvironment.transform 14 8200 env5285 = env5286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5285 == env5286) = true)

theorem identity5286 : scanCanonicalize (H12AffineFastState.compose env5286 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 13359) := by decide +kernel

theorem selectedBound5286 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5287 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8200,13359,4097,262144,1025,8200,4097,5260,5292,35,8329,5293,282760,16385,16385,22561,4100,20648,172,20480,1029,5805]

theorem envBound5287 : H12AffineFastState.Bounded env5287 := by
  intro p hp
  have h : env5287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5286_5287 : H12AffineEnvironment.transform 15 13359 env5286 = env5287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13359 env5286 == env5287) = true)

theorem identity5287 : scanCanonicalize (H12AffineFastState.compose env5287 (packedSelected [0,2,7,11,13,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 23041) := by decide +kernel

theorem selectedBound5287 : packedSelected [0,2,7,11,13,18,20,21] rootPS < 2^1333 := by decide +kernel

def env5288 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,4096,8192,16384,8200,13359,4097,23041,1025,8200,4097,5260,5292,35,8329,5293,2697,16385,16385,22561,4100,20648,172,20480,1029,5805]

theorem envBound5288 : H12AffineFastState.Bounded env5288 := by
  intro p hp
  have h : env5288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5287_5288 : H12AffineEnvironment.transform 17 23041 env5287 = env5288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23041 env5287 == env5288) = true)

theorem identity5288 : scanCanonicalize (H12AffineFastState.compose env5288 (packedSelected [0,1,2,3,7,11,12,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound5288 : packedSelected [0,1,2,3,7,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env5289 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1572,8192,16384,8200,8715,1573,19493,1025,8200,1573,680,648,35,8329,649,2697,16385,16385,19973,1568,18060,172,17956,1029,137]

theorem envBound5289 : H12AffineFastState.Bounded env5289 := by
  intro p hp
  have h : env5289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5288_5289 : H12AffineEnvironment.transform 11 1572 env5288 = env5289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env5288 == env5289) = true)

theorem identity5289 : scanCanonicalize (H12AffineFastState.compose env5289 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5289 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5290 : List Nat := [2,4,8,1,32,0,41,4,512,1024,2048,1572,8192,16384,8200,8715,1573,19493,1025,8200,1573,513,545,35,8224,544,2592,16385,16385,19973,1568,17957,5,17956,1029,32]

theorem envBound5290 : H12AffineFastState.Bounded env5290 := by
  intro p hp
  have h : env5290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5289_5290 : H12AffineEnvironment.transform 6 41 env5289 = env5290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5289 == env5290) = true)

theorem identity5290 : scanCanonicalize (H12AffineFastState.compose env5290 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound5290 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env5291 : List Nat := [2,4,8,1,32,0,41,4,43,1024,2048,1039,8192,16384,8200,8224,1038,19493,1025,8200,1038,42,10,35,8224,11,2059,16385,16385,19502,1035,17422,5,17423,1029,32]

theorem envBound5291 : H12AffineFastState.Bounded env5291 := by
  intro p hp
  have h : env5291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5290_5291 : H12AffineEnvironment.transform 8 43 env5290 = env5291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env5290 == env5291) = true)

theorem identity5291 : scanCanonicalize (H12AffineFastState.compose env5291 (packedSelected [0,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 11277) := by decide +kernel

theorem selectedBound5291 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env5292 : List Nat := [2,4,8,1,32,0,41,4,43,1024,2048,1039,8192,11277,8200,8224,1038,8232,1025,8200,1038,42,10,35,8224,11,2059,11276,11276,8227,1035,10243,5,10242,1029,32]

theorem envBound5292 : H12AffineFastState.Bounded env5292 := by
  intro p hp
  have h : env5292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5291_5292 : H12AffineEnvironment.transform 13 11277 env5291 = env5292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11277 env5291 == env5292) = true)

theorem identity5292 : scanCanonicalize (H12AffineFastState.compose env5292 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5292 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5293 : List Nat := [2,4,8,1,32,0,41,4,43,1024,2048,1039,1062,2091,1070,1030,1038,1038,1025,1070,1038,42,10,35,1030,11,2059,2090,2090,1029,1035,3109,5,3108,1029,32]

theorem envBound5293 : H12AffineFastState.Bounded env5293 := by
  intro p hp
  have h : env5293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5292_5293 : H12AffineEnvironment.transform 12 1062 env5292 = env5293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5292 == env5293) = true)

theorem identity5293 : scanCanonicalize (H12AffineFastState.compose env5293 (packedSelected [1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound5293 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env5294 : List Nat := [2,4,8,1,32,0,41,4,43,46,2048,33,8,2091,0,40,32,32,47,0,32,42,10,35,40,11,2059,2090,2090,43,37,2059,5,2058,43,32]

theorem envBound5294 : H12AffineFastState.Bounded env5294 := by
  intro p hp
  have h : env5294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5293_5294 : H12AffineEnvironment.transform 9 46 env5293 = env5294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env5293 == env5294) = true)

def env5295 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,65536,4113,262144,1025,32768,4097,46213,8388608,41003,8329,8388609,323712,16385,16401,22561,74795,8406020,188,20480,1028,8389120]

theorem envBound5295 : H12AffineFastState.Bounded env5295 := by
  intro p hp
  have h : env5295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5270_5295 : H12AffineEnvironment.transform 7 189 env5270 = env5295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5270 == env5295) = true)

theorem identity5295 : scanCanonicalize (H12AffineFastState.compose env5295 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 53402) := by decide +kernel

theorem selectedBound5295 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5296 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,32768,53402,4113,262144,1025,32768,4097,46213,8388608,41003,8329,8388609,323712,16385,16401,22561,62641,8406020,188,20480,1028,8389120]

theorem envBound5296 : H12AffineFastState.Bounded env5296 := by
  intro p hp
  have h : env5296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5295_5296 : H12AffineEnvironment.transform 15 53402 env5295 = env5296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53402 env5295 == env5296) = true)

def env5297 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,46213,8388608,41003,8329,8388609,323712,16385,16385,22561,62625,8406020,172,20480,1028,8389120]

theorem envBound5297 : H12AffineFastState.Bounded env5297 := by
  intro p hp
  have h : env5297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5296_5297 : H12AffineEnvironment.transform 3 0 env5296 = env5297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5296 == env5297) = true)

theorem identity5297 : scanCanonicalize (H12AffineFastState.compose env5297 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(22+1) ^^^ 5124) := by decide +kernel

theorem selectedBound5297 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5298 : List Nat := [2,4,8,0,32,1,128,173,512,1024,2048,4096,8192,16384,32768,53386,4097,262144,1025,32768,4097,46213,5124,41003,8329,5125,323712,16385,16385,22561,62625,20480,172,20480,1028,5636]

theorem envBound5298 : H12AffineFastState.Bounded env5298 := by
  intro p hp
  have h : env5298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5297_5298 : H12AffineEnvironment.transform 22 5124 env5297 = env5298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5124 env5297 == env5298) = true)

theorem identity5298 : scanCanonicalize (H12AffineFastState.compose env5298 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5298 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5299 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,53283,4097,262144,1025,32768,4097,46124,5124,41003,8224,5125,323625,16385,16385,22561,62472,20480,5,20480,1028,5636]

theorem envBound5299 : H12AffineFastState.Bounded env5299 := by
  intro p hp
  have h : env5299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5298_5299 : H12AffineEnvironment.transform 6 41 env5298 = env5299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5298 == env5299) = true)

theorem identity5299 : scanCanonicalize (H12AffineFastState.compose env5299 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5299 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5300 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,8200,28715,4097,262144,1025,8200,4097,5156,5124,35,8224,5125,282657,16385,16385,22561,21504,20480,5,20480,1028,5636]

theorem envBound5300 : H12AffineFastState.Bounded env5300 := by
  intro p hp
  have h : env5300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5299_5300 : H12AffineEnvironment.transform 14 8200 env5299 = env5300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5299 == env5300) = true)

theorem identity5300 : scanCanonicalize (H12AffineFastState.compose env5300 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 8712) := by decide +kernel

theorem selectedBound5300 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5301 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,8200,28715,4097,8712,1025,8200,4097,5156,5124,35,8224,5125,29225,16385,16385,22561,21504,20480,5,20480,1028,5636]

theorem envBound5301 : H12AffineFastState.Bounded env5301 := by
  intro p hp
  have h : env5301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5300_5301 : H12AffineEnvironment.transform 17 8712 env5300 = env5301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8712 env5300 == env5301) = true)

theorem identity5301 : scanCanonicalize (H12AffineFastState.compose env5301 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 3599) := by decide +kernel

theorem selectedBound5301 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5302 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,3599,8200,15908,4097,8712,1025,8200,4097,5156,5124,35,8224,5125,15398,3598,3598,5678,6671,7695,5,7695,1028,5636]

theorem envBound5302 : H12AffineFastState.Bounded env5302 := by
  intro p hp
  have h : env5302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5301_5302 : H12AffineEnvironment.transform 13 3599 env5301 = env5302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3599 env5301 == env5302) = true)

theorem identity5302 : scanCanonicalize (H12AffineFastState.compose env5302 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound5302 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5303 : List Nat := [2,4,8,0,32,1,41,4,512,1024,522,4096,8192,1029,8200,13358,4097,8712,1025,8200,4097,5156,5124,35,8224,5125,13868,1028,1028,5678,4101,5125,5,5125,1028,5636]

theorem envBound5303 : H12AffineFastState.Bounded env5303 := by
  intro p hp
  have h : env5303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5302_5303 : H12AffineEnvironment.transform 10 522 env5302 = env5303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env5302 == env5303) = true)

theorem identity5303 : scanCanonicalize (H12AffineFastState.compose env5303 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound5303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5304 : List Nat := [2,4,8,0,32,1,41,4,512,559,522,4096,8192,554,8200,12801,4097,8712,558,8200,4097,4619,4651,35,8224,4650,12291,555,555,4097,4101,4650,5,4650,555,4139]

theorem envBound5304 : H12AffineFastState.Bounded env5304 := by
  intro p hp
  have h : env5304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5303_5304 : H12AffineEnvironment.transform 9 559 env5303 = env5304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env5303 == env5304) = true)

theorem identity5304 : scanCanonicalize (H12AffineFastState.compose env5304 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound5304 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5305 : List Nat := [2,4,8,0,32,1,41,4,512,559,522,4096,4136,554,4128,553,4097,4640,558,4128,4097,4619,4651,35,4104,4650,43,555,555,4097,4101,4650,5,4650,555,4139]

theorem envBound5305 : H12AffineFastState.Bounded env5305 := by
  intro p hp
  have h : env5305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5304_5305 : H12AffineEnvironment.transform 12 4136 env5304 = env5305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env5304 == env5305) = true)

theorem identity5305 : scanCanonicalize (H12AffineFastState.compose env5305 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound5305 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5306 : List Nat := [2,4,8,0,32,1,41,4,10,37,0,4096,4136,32,4128,35,4097,4138,36,4128,4097,4097,4129,35,4104,4128,43,33,33,4097,4101,4128,5,4128,33,4139]

theorem envBound5306 : H12AffineFastState.Bounded env5306 := by
  intro p hp
  have h : env5306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5305_5306 : H12AffineEnvironment.transform 8 10 env5305 = env5306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env5305 == env5306) = true)

theorem identity5306 : scanCanonicalize (H12AffineFastState.compose env5306 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound5306 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5307 : List Nat := [2,4,8,0,32,1,41,4,10,37,0,11,35,32,43,35,10,33,36,43,10,10,42,35,3,43,43,33,33,10,14,43,5,43,33,32]

theorem envBound5307 : H12AffineFastState.Bounded env5307 := by
  intro p hp
  have h : env5307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5306_5307 : H12AffineEnvironment.transform 11 11 env5306 = env5307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env5306 == env5307) = true)

def env5308 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,32768,53387,4096,262144,1025,32768,4097,46213,8388608,41003,8329,8388609,323712,16385,16384,22561,62624,8406020,173,20480,1028,8389120]

theorem envBound5308 : H12AffineFastState.Bounded env5308 := by
  intro p hp
  have h : env5308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5296_5308 : H12AffineEnvironment.transform 3 1 env5296 = env5308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5296 == env5308) = true)

def env5309 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28715,4096,262144,1025,8352,4097,5157,8388608,139,8329,8388609,282656,16385,16384,22561,21504,8406020,173,20480,1028,8389120]

theorem envBound5309 : H12AffineFastState.Bounded env5309 := by
  intro p hp
  have h : env5309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5308_5309 : H12AffineEnvironment.transform 14 8352 env5308 = env5309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5308 == env5309) = true)

theorem identity5309 : scanCanonicalize (H12AffineFastState.compose env5309 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 7309) := by decide +kernel

theorem selectedBound5309 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5310 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28715,4096,7309,1025,8352,4097,5157,8388608,139,8329,8388609,19629,16385,16384,22561,21504,8406020,173,20480,1028,8389120]

theorem envBound5310 : H12AffineFastState.Bounded env5310 := by
  intro p hp
  have h : env5310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5309_5310 : H12AffineEnvironment.transform 17 7309 env5309 = env5310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7309 env5309 == env5310) = true)

theorem identity5310 : scanCanonicalize (H12AffineFastState.compose env5310 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(22+1) ^^^ 6306) := by decide +kernel

theorem selectedBound5310 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5311 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8352,28715,4096,7309,1025,8352,4097,5157,6306,139,8329,6307,19629,16385,16384,22561,21504,23718,173,20480,1028,6818]

theorem envBound5311 : H12AffineFastState.Bounded env5311 := by
  intro p hp
  have h : env5311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5310_5311 : H12AffineEnvironment.transform 22 6306 env5310 = env5311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6306 env5310 == env5311) = true)

theorem identity5311 : scanCanonicalize (H12AffineFastState.compose env5311 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 7815) := by decide +kernel

theorem selectedBound5311 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env5312 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,7815,8352,11948,4096,7309,1025,8352,4097,5157,6306,139,8329,6307,4650,7814,7815,1702,2695,545,173,3719,1028,6818]

theorem envBound5312 : H12AffineFastState.Bounded env5312 := by
  intro p hp
  have h : env5312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5311_5312 : H12AffineEnvironment.transform 13 7815 env5311 = env5312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7815 env5311 == env5312) = true)

theorem identity5312 : scanCanonicalize (H12AffineFastState.compose env5312 (packedSelected [0,1,2,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound5312 : packedSelected [0,1,2,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env5313 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,2603,8352,11948,1196,2081,1025,8352,1197,137,3086,139,8329,3087,1670,2602,2603,1702,2695,545,173,3719,1028,3598]

theorem envBound5313 : H12AffineFastState.Bounded env5313 := by
  intro p hp
  have h : env5313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5312_5313 : H12AffineEnvironment.transform 11 1196 env5312 = env5313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env5312 == env5313) = true)

def env5314 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28714,4096,262144,1025,8353,4097,5156,8388608,138,8329,8388609,282657,16385,16384,22561,21505,8406020,173,20480,1028,8389120]

theorem envBound5314 : H12AffineFastState.Bounded env5314 := by
  intro p hp
  have h : env5314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5308_5314 : H12AffineEnvironment.transform 14 8353 env5308 = env5314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5308 == env5314) = true)

theorem identity5314 : scanCanonicalize (H12AffineFastState.compose env5314 (packedSelected [17,21] rootPS)) = affineNative (2^(22+1) ^^^ 284704) := by decide +kernel

theorem selectedBound5314 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5315 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,16384,8353,28714,4096,262144,1025,8353,4097,5156,284704,138,8329,284705,282657,16385,16384,22561,21505,269348,173,20480,1028,285216]

theorem envBound5315 : H12AffineFastState.Bounded env5315 := by
  intro p hp
  have h : env5315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5314_5315 : H12AffineEnvironment.transform 22 284704 env5314 = env5315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284704 env5314 == env5315) = true)

theorem identity5315 : scanCanonicalize (H12AffineFastState.compose env5315 (packedSelected [2,3,5,9,10,13,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 681) := by decide +kernel

theorem selectedBound5315 : packedSelected [2,3,5,9,10,13,20,22] rootPS < 2^1333 := by decide +kernel

def env5316 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,681,8353,12931,4096,262144,1025,8353,4097,5156,268937,138,8329,268936,266888,680,681,6792,5800,269348,173,4777,1028,268425]

theorem envBound5316 : H12AffineFastState.Bounded env5316 := by
  intro p hp
  have h : env5316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5315_5316 : H12AffineEnvironment.transform 13 681 env5315 = env5316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 681 env5315 == env5316) = true)

theorem identity5316 : scanCanonicalize (H12AffineFastState.compose env5316 (packedSelected [6,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 13350) := by decide +kernel

theorem selectedBound5316 : packedSelected [6,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5317 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,8192,681,8353,12931,4096,13350,1025,8353,4097,5156,11951,138,8329,11950,9902,680,681,6792,5800,10242,173,4777,1028,11439]

theorem envBound5317 : H12AffineFastState.Bounded env5317 := by
  intro p hp
  have h : env5317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5316_5317 : H12AffineEnvironment.transform 17 13350 env5316 = env5317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13350 env5316 == env5317) = true)

theorem identity5317 : scanCanonicalize (H12AffineFastState.compose env5317 (packedSelected [0,1,2,3,7,8,10,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 7342) := by decide +kernel

theorem selectedBound5317 : packedSelected [0,1,2,3,7,8,10,17,24] rootPS < 2^1333 := by decide +kernel

def env5318 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,4096,7342,681,7183,3629,4096,2184,1025,7183,4097,5156,4609,138,7207,4608,6656,680,681,6792,5800,5292,173,4777,1028,4097]

theorem envBound5318 : H12AffineFastState.Bounded env5318 := by
  intro p hp
  have h : env5318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5317_5318 : H12AffineEnvironment.transform 12 7342 env5317 = env5318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7342 env5317 == env5318) = true)

theorem identity5318 : scanCanonicalize (H12AffineFastState.compose env5318 (packedSelected [2,6,13] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound5318 : packedSelected [2,6,13] rootPS < 2^1333 := by decide +kernel

def env5319 : List Nat := [2,4,8,1,32,0,128,172,512,517,2048,4096,6827,681,6666,2088,4096,2184,516,6666,4097,4641,4609,138,6690,4608,6656,680,681,6792,4269,4777,173,4777,513,4097]

theorem envBound5319 : H12AffineFastState.Bounded env5319 := by
  intro p hp
  have h : env5319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5318_5319 : H12AffineEnvironment.transform 9 517 env5318 = env5319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env5318 == env5319) = true)

theorem identity5319 : scanCanonicalize (H12AffineFastState.compose env5319 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound5319 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5320 : List Nat := [2,4,8,1,32,0,128,172,512,517,2048,42,2689,681,2592,2088,42,2184,516,2592,43,523,555,138,2568,554,2602,680,681,2722,135,643,173,643,513,43]

theorem envBound5320 : H12AffineFastState.Bounded env5320 := by
  intro p hp
  have h : env5320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5319_5320 : H12AffineEnvironment.transform 11 42 env5319 = env5320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env5319 == env5320) = true)

theorem identity5320 : scanCanonicalize (H12AffineFastState.compose env5320 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound5320 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5321 : List Nat := [2,4,8,1,32,0,128,172,512,517,555,42,170,681,11,515,42,675,516,11,43,523,555,138,35,554,1,680,681,137,135,643,173,643,513,43]

theorem envBound5321 : H12AffineFastState.Bounded env5321 := by
  intro p hp
  have h : env5321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5320_5321 : H12AffineEnvironment.transform 10 555 env5320 = env5321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env5320 == env5321) = true)

theorem identity5321 : scanCanonicalize (H12AffineFastState.compose env5321 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound5321 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5322 : List Nat := [2,4,8,1,32,0,128,172,11,14,32,42,170,162,11,8,42,168,15,11,43,0,32,138,35,33,1,163,162,137,135,136,173,136,10,43]

theorem envBound5322 : H12AffineFastState.Bounded env5322 := by
  intro p hp
  have h : env5322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5321_5322 : H12AffineEnvironment.transform 8 11 env5321 = env5322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env5321 == env5322) = true)

def env5323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,77914241,76039248,76039596,77613088,75572347,73983341,525568,77611009,82355409,8914925]

theorem envBound5323 : H12AffineFastState.Bounded env5323 := by
  intro p hp
  have h : env5323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4842_5323 : H12AffineEnvironment.transform 26 77914241 env4842 = env5323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914241 env4842 == env5323) = true)

def env5324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914000,2942161,16384,16892,2641008,598059,14737725,525568,2638929,6332545,8914925]

theorem envBound5324 : H12AffineFastState.Bounded env5324 := by
  intro p hp
  have h : env5324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5323_5324 : H12AffineEnvironment.transform 25 8914000 env5323 = env5324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env5323 == env5324) = true)

def env5325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849105,16384,16892,547952,598059,12644669,525568,545873,4239489,8914925]

theorem envBound5325 : H12AffineFastState.Bounded env5325 := by
  intro p hp
  have h : env5325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5324_5325 : H12AffineEnvironment.transform 20 4096 env5324 = env5325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5324 == env5325) = true)

def env5326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,12644669,256,20561,4239489,8389613]

theorem envBound5326 : H12AffineFastState.Bounded env5326 := by
  intro p hp
  have h : env5326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5325_5326 : H12AffineEnvironment.transform 18 1024 env5325 = env5326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5325 == env5326) = true)

theorem identity5326 : scanCanonicalize (H12AffineFastState.compose env5326 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound5326 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1213,8192,16384,32768,65536,1344,262144,1024,32768,1213,4194304,8388608,41003,8329,8388688,320620,16384,16892,19661,74795,12641664,256,17644,4236348,8389613]

theorem envBound5327 : H12AffineFastState.Bounded env5327 := by
  intro p hp
  have h : env5327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5326_5327 : H12AffineEnvironment.transform 11 1213 env5326 = env5327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env5326 == env5327) = true)

def env5328 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,8388608,41003,8329,8388608,320572,16384,16812,19613,74795,12641664,256,17596,4236348,8389565]

theorem envBound5328 : H12AffineFastState.Bounded env5328 := by
  intro p hp
  have h : env5328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5327_5328 : H12AffineEnvironment.transform 5 16 env5327 = env5328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5327 == env5328) = true)

theorem identity5328 : scanCanonicalize (H12AffineFastState.compose env5328 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5328 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5329 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,4194304,445,41003,8329,445,320572,16384,16812,19613,74795,4252733,256,17596,4236348,512]

theorem envBound5329 : H12AffineFastState.Bounded env5329 := by
  intro p hp
  have h : env5329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5328_5329 : H12AffineEnvironment.transform 22 445 env5328 = env5329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5328 == env5329) = true)

theorem identity5329 : scanCanonicalize (H12AffineFastState.compose env5329 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5329 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5330 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,32768,65536,1296,262144,1024,32768,1213,41348,445,41003,8329,445,320572,16384,16812,19613,74795,17849,256,17596,1464,512]

theorem envBound5330 : H12AffineFastState.Bounded env5330 := by
  intro p hp
  have h : env5330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5329_5330 : H12AffineEnvironment.transform 21 41348 env5329 = env5330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5329 == env5330) = true)

theorem identity5330 : scanCanonicalize (H12AffineFastState.compose env5330 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound5330 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5331 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,65536,1296,262144,1024,26261,1213,18193,445,18110,8329,445,262825,16384,16812,19613,74795,17849,256,17596,1464,512]

theorem envBound5331 : H12AffineFastState.Bounded env5331 := by
  intro p hp
  have h : env5331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5330_5331 : H12AffineEnvironment.transform 14 26261 env5330 = env5331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env5330 == env5331) = true)

theorem identity5331 : scanCanonicalize (H12AffineFastState.compose env5331 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25662) := by decide +kernel

theorem selectedBound5331 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5332 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,16384,26261,25662,1296,262144,1024,26261,1213,18193,445,18110,8329,445,262825,16384,16812,19613,16405,17849,256,17596,1464,512]

theorem envBound5332 : H12AffineFastState.Bounded env5332 := by
  intro p hp
  have h : env5332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5331_5332 : H12AffineEnvironment.transform 15 25662 env5331 = env5332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25662 env5331 == env5332) = true)

theorem identity5332 : scanCanonicalize (H12AffineFastState.compose env5332 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5332 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5333 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1213,8192,1841,8612,8975,1296,262144,1024,8612,1213,32,445,399,8329,445,262825,1841,1693,2988,1828,648,256,909,1464,512]

theorem envBound5333 : H12AffineFastState.Bounded env5333 := by
  intro p hp
  have h : env5333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5332_5333 : H12AffineEnvironment.transform 13 1841 env5332 = env5333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5332 == env5333) = true)

theorem identity5333 : scanCanonicalize (H12AffineFastState.compose env5333 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5333 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5334 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8201,8866,1213,262144,1024,8201,1213,32,16,34,8329,16,262825,1692,1693,2561,1673,648,173,544,1045,512]

theorem envBound5334 : H12AffineFastState.Bounded env5334 := by
  intro p hp
  have h : env5334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5333_5334 : H12AffineEnvironment.transform 7 173 env5333 = env5334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5333 == env5334) = true)

theorem identity5334 : scanCanonicalize (H12AffineFastState.compose env5334 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5334 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5335 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1692,8201,8866,1213,1582,1024,8201,1213,32,16,34,8329,16,1159,1692,1693,2561,1673,648,173,544,1045,512]

theorem envBound5335 : H12AffineFastState.Bounded env5335 := by
  intro p hp
  have h : env5335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5334_5335 : H12AffineEnvironment.transform 17 1582 env5334 = env5335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1582 env5334 == env5335) = true)

def env5336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,32768,65536,1297,262144,1024,32768,1213,4194304,8388608,41003,8329,8388609,320573,16384,16813,19612,74795,12641664,256,17597,4236348,8389564]

theorem envBound5336 : H12AffineFastState.Bounded env5336 := by
  intro p hp
  have h : env5336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5327_5336 : H12AffineEnvironment.transform 5 17 env5327 = env5336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5327 == env5336) = true)

def env5337 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1213,8192,16384,32768,65536,1197,262144,1024,32768,1213,4194304,8388608,41003,8329,8388609,320573,16384,16401,19612,74795,12641340,188,17597,4236348,8389120]

theorem envBound5337 : H12AffineFastState.Bounded env5337 := by
  intro p hp
  have h : env5337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5336_5337 : H12AffineEnvironment.transform 7 188 env5336 = env5337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5336 == env5337) = true)

theorem identity5337 : scanCanonicalize (H12AffineFastState.compose env5337 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound5337 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5338 : List Nat := [2,4,8,16,32,17,128,188,512,1024,2048,1213,8192,16384,32768,65536,1197,262144,1024,32768,1213,4194304,4194352,41003,8329,4194353,320573,16384,16401,19612,74795,58380,188,17597,4236348,4194864]

theorem envBound5338 : H12AffineFastState.Bounded env5338 := by
  intro p hp
  have h : env5338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5337_5338 : H12AffineEnvironment.transform 22 4194352 env5337 = env5338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env5337 == env5338) = true)

def env5339 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1197,8192,16384,32768,65536,1197,262144,1024,32768,1197,4194304,4194336,41003,8329,4194337,320557,16384,16385,19596,74795,58380,172,17581,4236332,4194848]

theorem envBound5339 : H12AffineFastState.Bounded env5339 := by
  intro p hp
  have h : env5339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5338_5339 : H12AffineEnvironment.transform 3 0 env5338 = env5339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5338 == env5339) = true)

theorem identity5339 : scanCanonicalize (H12AffineFastState.compose env5339 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5339 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5340 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,65536,1029,262144,1024,32768,1029,4194304,4194336,41003,8225,4194337,320557,16384,16385,19492,74795,58380,4,17413,4236332,4194848]

theorem envBound5340 : H12AffineFastState.Bounded env5340 := by
  intro p hp
  have h : env5340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5339_5340 : H12AffineEnvironment.transform 6 40 env5339 = env5340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5339 == env5340) = true)

theorem identity5340 : scanCanonicalize (H12AffineFastState.compose env5340 (packedSelected [2,3,5,7,10,11,18,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 117767) := by decide +kernel

theorem selectedBound5340 : packedSelected [2,3,5,7,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env5341 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,65536,1029,117767,1024,32768,1029,4194304,4194336,41003,8225,4194337,75818,16384,16385,19492,74795,58380,4,17413,4236332,4194848]

theorem envBound5341 : H12AffineFastState.Bounded env5341 := by
  intro p hp
  have h : env5341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5340_5341 : H12AffineEnvironment.transform 17 117767 env5340 = env5341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 117767 env5340 == env5341) = true)

theorem identity5341 : scanCanonicalize (H12AffineFastState.compose env5341 (packedSelected [0,4,7,9,11,12,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 19463) := by decide +kernel

theorem selectedBound5341 : packedSelected [0,4,7,9,11,12,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5342 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,19463,1029,32768,1024,32768,1029,4194304,4194336,41003,8225,4194337,25645,16384,16385,19492,26668,58380,4,17413,4236332,4194848]

theorem envBound5342 : H12AffineFastState.Bounded env5342 := by
  intro p hp
  have h : env5342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5341_5342 : H12AffineEnvironment.transform 15 19463 env5341 = env5342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19463 env5341 == env5342) = true)

theorem identity5342 : scanCanonicalize (H12AffineFastState.compose env5342 (packedSelected [0,1,2,3,5,7,8,10,12,15,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 17413) := by decide +kernel

theorem selectedBound5342 : packedSelected [0,1,2,3,5,7,8,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env5343 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,32768,19463,1029,32768,1024,32768,1029,17413,17445,41003,8225,17444,25645,16384,16385,19492,26668,58380,4,17413,57385,17957]

theorem envBound5343 : H12AffineFastState.Bounded env5343 := by
  intro p hp
  have h : env5343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5342_5343 : H12AffineEnvironment.transform 21 17413 env5342 = env5343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17413 env5342 == env5343) = true)

theorem identity5343 : scanCanonicalize (H12AffineFastState.compose env5343 (packedSelected [2,3,5,11,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 11789) := by decide +kernel

theorem selectedBound5343 : packedSelected [2,3,5,11,12,13] rootPS < 2^1333 := by decide +kernel

def env5344 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,16384,11789,19463,1029,11789,1024,11789,1029,17413,17445,3622,8225,17444,25645,16384,16385,19492,26668,18945,4,17413,20004,17957]

theorem envBound5344 : H12AffineFastState.Bounded env5344 := by
  intro p hp
  have h : env5344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5343_5344 : H12AffineEnvironment.transform 14 11789 env5343 = env5344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11789 env5343 == env5344) = true)

theorem identity5344 : scanCanonicalize (H12AffineFastState.compose env5344 (packedSelected [1,3,4,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 1071) := by decide +kernel

theorem selectedBound5344 : packedSelected [1,3,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env5345 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1029,8192,1071,11789,2088,1029,11789,1024,11789,1029,42,10,3622,8225,11,8194,1071,1070,2059,11267,3630,4,42,2571,522]

theorem envBound5345 : H12AffineFastState.Bounded env5345 := by
  intro p hp
  have h : env5345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5344_5345 : H12AffineEnvironment.transform 13 1071 env5344 = env5345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1071 env5344 == env5345) = true)

theorem identity5345 : scanCanonicalize (H12AffineFastState.compose env5345 (packedSelected [1,8,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5345 : packedSelected [1,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env5346 : List Nat := [2,4,8,0,32,1,40,4,512,1024,1540,1029,8192,1071,8201,1580,1029,8201,1024,8201,1029,42,10,34,8225,11,8194,1071,1070,1551,8711,42,4,42,1039,522]

theorem envBound5346 : H12AffineFastState.Bounded env5346 := by
  intro p hp
  have h : env5346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5345_5346 : H12AffineEnvironment.transform 10 1540 env5345 = env5346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env5345 == env5346) = true)

theorem identity5346 : scanCanonicalize (H12AffineFastState.compose env5346 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5346 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env5347 : List Nat := [2,4,8,0,32,1,40,4,512,36,544,33,8192,11,8201,520,33,8201,36,8201,33,42,10,34,8225,11,8194,11,10,555,8711,42,4,42,43,522]

theorem envBound5347 : H12AffineFastState.Bounded env5347 := by
  intro p hp
  have h : env5347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5346_5347 : H12AffineEnvironment.transform 9 36 env5346 = env5347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5346 == env5347) = true)

theorem identity5347 : scanCanonicalize (H12AffineFastState.compose env5347 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound5347 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5348 : List Nat := [2,4,8,0,32,1,40,4,512,36,544,33,8,11,1,520,33,1,36,1,33,42,10,34,41,11,10,11,10,555,527,42,4,42,43,522]

theorem envBound5348 : H12AffineFastState.Bounded env5348 := by
  intro p hp
  have h : env5348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5347_5348 : H12AffineEnvironment.transform 12 8 env5347 = env5348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env5347 == env5348) = true)

theorem identity5348 : scanCanonicalize (H12AffineFastState.compose env5348 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5348 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env5349 : List Nat := [2,4,8,0,32,1,40,4,32,36,0,33,8,11,1,40,33,1,36,1,33,42,10,34,41,11,10,11,10,11,47,42,4,42,43,42]

theorem envBound5349 : H12AffineFastState.Bounded env5349 := by
  intro p hp
  have h : env5349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5348_5349 : H12AffineEnvironment.transform 8 32 env5348 = env5349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5348 == env5349) = true)

theorem identity5349 : scanCanonicalize (H12AffineFastState.compose env5349 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5349 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5350 : List Nat := [2,4,8,0,10,1,2,4,10,14,0,11,8,11,1,2,11,1,14,1,11,0,10,8,3,11,10,11,10,11,5,0,4,0,1,0]

theorem envBound5350 : H12AffineFastState.Bounded env5350 := by
  intro p hp
  have h : env5350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5349_5350 : H12AffineEnvironment.transform 4 10 env5349 = env5350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5349 == env5350) = true)

theorem identity5350 : scanCanonicalize (H12AffineFastState.compose env5350 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5351 : List Nat := [2,4,2,0,0,1,2,4,0,4,0,1,2,1,1,2,1,1,4,1,1,0,0,2,3,1,0,1,0,1,5,0,4,0,1,0]

theorem envBound5351 : H12AffineFastState.Bounded env5351 := by
  intro p hp
  have h : env5351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5350_5351 : H12AffineEnvironment.transform 2 2 env5350 = env5351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5350 == env5351) = true)

def env5352 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,65536,1197,262144,1024,32768,1196,4194304,4194337,41003,8329,4194336,320556,16384,16384,19597,74795,58380,173,17580,4236333,4194849]

theorem envBound5352 : H12AffineFastState.Bounded env5352 := by
  intro p hp
  have h : env5352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5338_5352 : H12AffineEnvironment.transform 3 1 env5338 = env5352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5338 == env5352) = true)

theorem identity5352 : scanCanonicalize (H12AffineFastState.compose env5352 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25646) := by decide +kernel

theorem selectedBound5352 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5353 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,262144,1024,32768,1196,4194304,4194337,41003,8329,4194336,320556,16384,16384,19597,16389,58380,173,17580,4236333,4194849]

theorem envBound5353 : H12AffineFastState.Bounded env5353 := by
  intro p hp
  have h : env5353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5352_5353 : H12AffineEnvironment.transform 15 25646 env5352 = env5353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25646 env5352 == env5353) = true)

theorem identity5353 : scanCanonicalize (H12AffineFastState.compose env5353 (packedSelected [1,5,8,13,18,21,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5353 : packedSelected [1,5,8,13,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env5354 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,2081,1024,32768,1196,4194304,4194337,41003,8329,4194336,60429,16384,16384,19597,16389,58380,173,17580,4236333,4194849]

theorem envBound5354 : H12AffineFastState.Bounded env5354 := by
  intro p hp
  have h : env5354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5353_5354 : H12AffineEnvironment.transform 17 2081 env5353 = env5354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5353 == env5354) = true)

theorem identity5354 : scanCanonicalize (H12AffineFastState.compose env5354 (packedSelected [1,2,6,8,11,17,21] rootPS)) = affineNative (2^(21+1) ^^^ 34351) := by decide +kernel

theorem selectedBound5354 : packedSelected [1,2,6,8,11,17,21] rootPS < 2^1333 := by decide +kernel

def env5355 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,8192,16384,32768,25646,1197,2081,1024,32768,1196,34351,34318,41003,8329,34319,60429,16384,16384,19597,16389,58380,173,17580,8706,33806]

theorem envBound5355 : H12AffineFastState.Bounded env5355 := by
  intro p hp
  have h : env5355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5354_5355 : H12AffineEnvironment.transform 21 34351 env5354 = env5355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34351 env5354 == env5355) = true)

theorem identity5355 : scanCanonicalize (H12AffineFastState.compose env5355 (packedSelected [3,4,5,7,9,10,13,17,27] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound5355 : packedSelected [3,4,5,7,9,10,13,17,27] rootPS < 2^1333 := by decide +kernel

def env5356 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,1543,16384,32768,16937,1197,2081,1024,32768,1196,34351,34318,34348,1678,34319,51722,16384,16384,19597,16389,49675,173,17580,1029,33806]

theorem envBound5356 : H12AffineFastState.Bounded env5356 := by
  intro p hp
  have h : env5356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5355_5356 : H12AffineEnvironment.transform 12 1543 env5355 = env5356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env5355 == env5356) = true)

theorem identity5356 : scanCanonicalize (H12AffineFastState.compose env5356 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound5356 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env5357 : List Nat := [2,4,8,1,32,0,128,173,512,1024,2048,1196,1543,16384,1071,16937,1197,2081,1024,1071,1196,512,545,515,1678,544,20005,16384,16384,19597,16389,17956,173,17580,1029,33]

theorem envBound5357 : H12AffineFastState.Bounded env5357 := by
  intro p hp
  have h : env5357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5356_5357 : H12AffineEnvironment.transform 14 1071 env5356 = env5357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env5356 == env5357) = true)

theorem identity5357 : scanCanonicalize (H12AffineFastState.compose env5357 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5357 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5358 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1196,1063,16384,1071,16393,1197,2081,1024,1071,1196,32,1,35,1198,0,19461,16384,16384,19597,16389,17412,173,17580,1029,33]

theorem envBound5358 : H12AffineFastState.Bounded env5358 := by
  intro p hp
  have h : env5358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5357_5358 : H12AffineEnvironment.transform 8 32 env5357 = env5358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5357 == env5358) = true)

theorem identity5358 : scanCanonicalize (H12AffineFastState.compose env5358 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound5358 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5359 : List Nat := [2,4,8,1,32,0,128,173,32,1024,2048,1196,1063,2090,1071,2083,1197,2081,1024,1071,1196,32,1,35,1198,0,1071,2090,2090,1191,2095,3118,173,3206,1029,33]

theorem envBound5359 : H12AffineFastState.Bounded env5359 := by
  intro p hp
  have h : env5359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5358_5359 : H12AffineEnvironment.transform 13 2090 env5358 = env5359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env5358 == env5359) = true)

theorem identity5359 : scanCanonicalize (H12AffineFastState.compose env5359 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound5359 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5360 : List Nat := [2,4,8,1,32,0,7,42,32,1024,2048,1067,1063,2090,1071,2083,1066,2081,1024,1071,1067,32,1,35,1065,0,1071,2090,2090,1056,2095,3118,42,3073,1029,33]

theorem envBound5360 : H12AffineFastState.Bounded env5360 := by
  intro p hp
  have h : env5360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5359_5360 : H12AffineEnvironment.transform 6 7 env5359 = env5360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env5359 == env5360) = true)

theorem identity5360 : scanCanonicalize (H12AffineFastState.compose env5360 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound5360 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env5361 : List Nat := [2,4,8,1,32,0,7,42,32,1024,1039,1067,1063,1061,1071,1068,1066,1070,1024,1071,1067,32,1,35,1065,0,1071,1061,1061,1056,1056,33,42,14,1029,33]

theorem envBound5361 : H12AffineFastState.Bounded env5361 := by
  intro p hp
  have h : env5361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5360_5361 : H12AffineEnvironment.transform 10 1039 env5360 = env5361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env5360 == env5361) = true)

theorem identity5361 : scanCanonicalize (H12AffineFastState.compose env5361 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5361 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env5362 : List Nat := [2,4,8,1,32,0,7,42,32,36,43,15,3,1,11,8,14,10,36,11,15,32,1,35,13,0,11,1,1,4,4,33,42,14,33,33]

theorem envBound5362 : H12AffineFastState.Bounded env5362 := by
  intro p hp
  have h : env5362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5361_5362 : H12AffineEnvironment.transform 9 36 env5361 = env5362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5361 == env5362) = true)

theorem identity5362 : scanCanonicalize (H12AffineFastState.compose env5362 (packedSelected [0,1,5] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound5362 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env5363 : List Nat := [2,4,8,1,15,0,7,5,15,11,4,15,3,1,11,8,14,10,11,11,15,15,1,12,13,0,11,1,1,4,4,14,5,14,14,14]

theorem envBound5363 : H12AffineFastState.Bounded env5363 := by
  intro p hp
  have h : env5363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5362_5363 : H12AffineEnvironment.transform 4 15 env5362 = env5363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env5362 == env5363) = true)

theorem identity5363 : scanCanonicalize (H12AffineFastState.compose env5363 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5364 : List Nat := [2,4,3,1,4,0,7,5,4,0,4,4,3,1,0,3,5,1,0,0,4,4,1,7,6,0,0,1,1,4,4,5,5,5,5,5]

theorem envBound5364 : H12AffineFastState.Bounded env5364 := by
  intro p hp
  have h : env5364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5363_5364 : H12AffineEnvironment.transform 2 3 env5363 = env5364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5363 == env5364) = true)

def leafEnv5364 : List Nat := [2,4,3,1,4,0,7,5,4,0,4,4,3,1,0,3,5,1,0,0,4,4,1,7,5,6,1,0,0,1,1,4,4,5,5,5,5,7,5,5,1,1,0]

def active5364 : List Nat := [0,1]

def tree5364 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5364 : H12WitnessSearch.Good tree5364 := H12GlobalWitnessIndex.good

theorem leafIdentity5364 : H12AffineFastState.composeSystem env5364 rootObs = leafEnv5364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5364 rootObs == leafEnv5364) = true)

theorem terminalChecked5364 : H12PackedTerminal.terminalCheckFast leafEnv5364 active5364 tree5364 = true := by decide +kernel

def env5365 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,65536,1196,262144,1024,32768,1213,4194304,8388608,41003,8329,8388609,320573,16384,16400,19612,74795,12641341,189,17597,4236348,8389121]

theorem envBound5365 : H12AffineFastState.Bounded env5365 := by
  intro p hp
  have h : env5365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5336_5365 : H12AffineEnvironment.transform 7 189 env5336 = env5365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5336 == env5365) = true)

theorem identity5365 : scanCanonicalize (H12AffineFastState.compose env5365 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50215) := by decide +kernel

theorem selectedBound5365 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5366 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50215,1196,262144,1024,32768,1213,4194304,8388608,41003,8329,8388609,320573,16384,16400,19612,57356,12641341,189,17597,4236348,8389121]

theorem envBound5366 : H12AffineFastState.Bounded env5366 := by
  intro p hp
  have h : env5366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5365_5366 : H12AffineEnvironment.transform 15 50215 env5365 = env5366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50215 env5365 == env5366) = true)

def env5367 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50215,1196,262144,1024,32768,1213,4194304,4235392,41003,8329,4235393,320573,16384,16400,19612,57356,17597,189,17597,4236348,4235905]

theorem envBound5367 : H12AffineFastState.Bounded env5367 := by
  intro p hp
  have h : env5367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5366_5367 : H12AffineEnvironment.transform 22 4235392 env5366 = env5367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env5366 == env5367) = true)

theorem identity5367 : scanCanonicalize (H12AffineFastState.compose env5367 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound5367 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5368 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1029,8192,16384,32768,50215,1044,262144,1024,32768,1029,4194304,4235320,41003,8241,4235321,320573,16384,16400,19492,57356,17413,5,17413,4236348,4235833]

theorem envBound5368 : H12AffineFastState.Bounded env5368 := by
  intro p hp
  have h : env5368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5367_5368 : H12AffineEnvironment.transform 6 56 env5367 = env5368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5367 == env5368) = true)

theorem identity5368 : scanCanonicalize (H12AffineFastState.compose env5368 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound5368 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5369 : List Nat := [2,4,8,16,32,17,56,5,512,1024,2048,1029,8192,16384,8217,25662,1044,262144,1024,8217,1029,4194304,4194337,50,8241,4194336,279588,16384,16400,19492,16405,17413,5,17413,4195365,4194848]

theorem envBound5369 : H12AffineFastState.Bounded env5369 := by
  intro p hp
  have h : env5369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5368_5369 : H12AffineEnvironment.transform 14 8217 env5368 = env5369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env5368 == env5369) = true)

theorem identity5369 : scanCanonicalize (H12AffineFastState.compose env5369 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5369 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5370 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8200,25647,1029,262144,1024,8200,1029,4194304,4194337,35,8224,4194336,279588,16384,16385,19492,16388,17413,5,17413,4195365,4194848]

theorem envBound5370 : H12AffineFastState.Bounded env5370 := by
  intro p hp
  have h : env5370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5369_5370 : H12AffineEnvironment.transform 3 1 env5369 = env5370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5369 == env5370) = true)

theorem identity5370 : scanCanonicalize (H12AffineFastState.compose env5370 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 281605) := by decide +kernel

theorem selectedBound5370 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5371 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8200,25647,1029,262144,1024,8200,1029,281605,281636,35,8224,281637,279588,16384,16385,19492,16388,17413,5,17413,280608,282149]

theorem envBound5371 : H12AffineFastState.Bounded env5371 := by
  intro p hp
  have h : env5371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5370_5371 : H12AffineEnvironment.transform 21 281605 env5370 = env5371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 281605 env5370 == env5371) = true)

theorem identity5371 : scanCanonicalize (H12AffineFastState.compose env5371 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(17+1) ^^^ 25638) := by decide +kernel

theorem selectedBound5371 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env5372 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,16384,8200,25647,1029,25638,1024,8200,1029,10275,10242,35,8224,10243,8194,16384,16385,19492,16388,17413,5,17413,11270,10755]

theorem envBound5372 : H12AffineFastState.Bounded env5372 := by
  intro p hp
  have h : env5372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5371_5372 : H12AffineEnvironment.transform 17 25638 env5371 = env5372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 25638 env5371 == env5372) = true)

theorem identity5372 : scanCanonicalize (H12AffineFastState.compose env5372 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(13+1) ^^^ 10754) := by decide +kernel

theorem selectedBound5372 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env5373 : List Nat := [2,4,8,1,32,0,41,5,512,1024,2048,1029,8192,10754,8200,3629,1029,3620,1024,8200,1029,10275,10242,35,8224,10243,8194,10754,10755,9766,10758,11783,5,11783,11270,10755]

theorem envBound5373 : H12AffineFastState.Bounded env5373 := by
  intro p hp
  have h : env5373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5372_5373 : H12AffineEnvironment.transform 13 10754 env5372 = env5373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10754 env5372 == env5373) = true)

theorem identity5373 : scanCanonicalize (H12AffineFastState.compose env5373 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound5373 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env5374 : List Nat := [2,4,8,1,32,0,41,5,512,1024,10,1029,8192,8712,8200,1575,1029,1582,1024,8200,1029,8233,8200,35,8224,8201,8194,8712,8713,9766,8716,9741,5,9741,9228,8713]

theorem envBound5374 : H12AffineFastState.Bounded env5374 := by
  intro p hp
  have h : env5374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5373_5374 : H12AffineEnvironment.transform 10 10 env5373 = env5374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env5373 == env5374) = true)

theorem identity5374 : scanCanonicalize (H12AffineFastState.compose env5374 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound5374 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5375 : List Nat := [2,4,8,1,32,0,41,5,512,516,10,513,8192,8712,8200,35,513,42,516,8200,513,8233,8200,35,8224,8201,8194,8712,8713,8226,8716,8201,5,8201,8712,8713]

theorem envBound5375 : H12AffineFastState.Bounded env5375 := by
  intro p hp
  have h : env5375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5374_5375 : H12AffineEnvironment.transform 9 516 env5374 = env5375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env5374 == env5375) = true)

theorem identity5375 : scanCanonicalize (H12AffineFastState.compose env5375 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5376 : List Nat := [2,4,8,1,11,0,2,5,512,516,10,513,8192,8712,8200,8,513,1,516,8200,513,8194,8200,8,8203,8201,8194,8712,8713,8201,8716,8201,5,8201,8712,8713]

theorem envBound5376 : H12AffineFastState.Bounded env5376 := by
  intro p hp
  have h : env5376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5375_5376 : H12AffineEnvironment.transform 4 11 env5375 = env5376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5375 == env5376) = true)

theorem identity5376 : scanCanonicalize (H12AffineFastState.compose env5376 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 514) := by decide +kernel

theorem selectedBound5376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5377 : List Nat := [2,4,8,1,11,0,2,5,512,516,10,513,514,10,522,8,513,1,516,522,513,512,522,8,521,523,512,10,11,523,14,523,5,523,10,11]

theorem envBound5377 : H12AffineFastState.Bounded env5377 := by
  intro p hp
  have h : env5377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5376_5377 : H12AffineEnvironment.transform 12 514 env5376 = env5377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 514 env5376 == env5377) = true)

theorem identity5377 : scanCanonicalize (H12AffineFastState.compose env5377 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5377 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5378 : List Nat := [2,4,3,1,0,0,2,5,512,516,1,513,514,1,513,3,513,1,516,513,513,512,513,3,514,512,512,1,0,512,5,512,5,512,1,0]

theorem envBound5378 : H12AffineFastState.Bounded env5378 := by
  intro p hp
  have h : env5378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5377_5378 : H12AffineEnvironment.transform 2 3 env5377 = env5378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5377 == env5378) = true)

theorem identity5378 : scanCanonicalize (H12AffineFastState.compose env5378 (packedSelected [13] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5378 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env5379 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,1,2,1,1,3,1,1,4,1,1,0,1,3,2,0,0,1,0,0,5,0,5,0,1,0]

theorem envBound5379 : H12AffineFastState.Bounded env5379 := by
  intro p hp
  have h : env5379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5378_5379 : H12AffineEnvironment.transform 8 0 env5378 = env5379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5378 == env5379) = true)

def env5380 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,1213,8192,16384,32768,50215,1196,262144,1024,32768,1213,4194304,4235393,41003,8329,4235392,320573,16384,16400,19612,57356,17596,189,17597,4236348,4235904]

theorem envBound5380 : H12AffineFastState.Bounded env5380 := by
  intro p hp
  have h : env5380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5366_5380 : H12AffineEnvironment.transform 22 4235393 env5366 = env5380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env5366 == env5380) = true)

theorem identity5380 : scanCanonicalize (H12AffineFastState.compose env5380 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5380 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5381 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50215,1196,262144,1024,32768,1196,4194304,4235393,41003,8329,4235392,320556,16384,16385,19597,57356,17581,172,17580,4236333,4235904]

theorem envBound5381 : H12AffineFastState.Bounded env5381 := by
  intro p hp
  have h : env5381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5380_5381 : H12AffineEnvironment.transform 3 1 env5380 = env5381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5380 == env5381) = true)

theorem identity5381 : scanCanonicalize (H12AffineFastState.compose env5381 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound5381 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5382 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,16384,32768,50215,1196,262144,1024,32768,1196,41000,169,41003,8329,168,320556,16384,16385,19597,57356,17581,172,17580,1029,680]

theorem envBound5382 : H12AffineFastState.Bounded env5382 := by
  intro p hp
  have h : env5382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5381_5382 : H12AffineEnvironment.transform 21 41000 env5381 = env5382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env5381 == env5382) = true)

theorem identity5382 : scanCanonicalize (H12AffineFastState.compose env5382 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound5382 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5383 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1677,32768,33450,1196,262144,1024,32768,1196,41000,169,41003,8329,168,303777,1677,1676,2560,42625,544,172,545,1029,680]

theorem envBound5383 : H12AffineFastState.Bounded env5383 := by
  intro p hp
  have h : env5383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5382_5383 : H12AffineEnvironment.transform 13 1677 env5382 = env5383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env5382 == env5383) = true)

theorem identity5383 : scanCanonicalize (H12AffineFastState.compose env5383 (packedSelected [1,3,4,9,11,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 43561) := by decide +kernel

theorem selectedBound5383 : packedSelected [1,3,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env5384 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1677,32768,33450,1196,43561,1024,32768,1196,41000,169,41003,8329,168,2184,1677,1676,2560,42625,544,172,545,1029,680]

theorem envBound5384 : H12AffineFastState.Bounded env5384 := by
  intro p hp
  have h : env5384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5383_5384 : H12AffineEnvironment.transform 17 43561 env5383 = env5384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43561 env5383 == env5384) = true)

theorem identity5384 : scanCanonicalize (H12AffineFastState.compose env5384 (packedSelected [0,2,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 1159) := by decide +kernel

theorem selectedBound5384 : packedSelected [0,2,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5385 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,8192,1677,1159,1581,1196,11950,1024,1159,1196,9391,169,9388,8329,168,2184,1677,1676,2560,8710,544,172,545,1029,680]

theorem envBound5385 : H12AffineFastState.Bounded env5385 := by
  intro p hp
  have h : env5385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5384_5385 : H12AffineEnvironment.transform 14 1159 env5384 = env5385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1159 env5384 == env5385) = true)

theorem identity5385 : scanCanonicalize (H12AffineFastState.compose env5385 (packedSelected [2,5,6,8,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound5385 : packedSelected [2,5,6,8,9,11,17] rootPS < 2^1333 := by decide +kernel

def env5386 : List Nat := [2,4,8,1,32,0,128,172,512,1024,2048,1196,160,1677,1159,1581,1196,3598,1024,1159,1196,1039,169,1036,41,168,2184,1677,1676,2560,678,544,172,545,1029,680]

theorem envBound5386 : H12AffineFastState.Bounded env5386 := by
  intro p hp
  have h : env5386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5385_5386 : H12AffineEnvironment.transform 12 160 env5385 = env5386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env5385 == env5386) = true)

theorem identity5386 : scanCanonicalize (H12AffineFastState.compose env5386 (packedSelected [1,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound5386 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env5387 : List Nat := [2,4,8,1,32,0,128,172,168,1024,2048,1196,160,1061,1159,1157,1196,3238,1024,1159,1196,1039,169,1036,41,168,2184,1061,1060,2216,14,136,172,137,1029,0]

theorem envBound5387 : H12AffineFastState.Bounded env5387 := by
  intro p hp
  have h : env5387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5386_5387 : H12AffineEnvironment.transform 8 168 env5386 = env5387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env5386 == env5387) = true)

theorem identity5387 : scanCanonicalize (H12AffineFastState.compose env5387 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound5387 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5388 : List Nat := [2,4,8,1,32,0,128,172,168,134,2048,42,160,163,1,3,42,2080,134,1,42,137,169,138,41,168,2184,163,162,2216,14,136,172,137,131,0]

theorem envBound5388 : H12AffineFastState.Bounded env5388 := by
  intro p hp
  have h : env5388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5387_5388 : H12AffineEnvironment.transform 9 134 env5387 = env5388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env5387 == env5388) = true)

theorem identity5388 : scanCanonicalize (H12AffineFastState.compose env5388 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound5388 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5389 : List Nat := [2,4,8,1,32,0,128,172,168,134,136,42,160,163,1,3,42,168,134,1,42,137,169,138,41,168,0,163,162,32,14,136,172,137,131,0]

theorem envBound5389 : H12AffineFastState.Bounded env5389 := by
  intro p hp
  have h : env5389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5388_5389 : H12AffineEnvironment.transform 10 136 env5388 = env5389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env5388 == env5389) = true)

theorem identity5389 : scanCanonicalize (H12AffineFastState.compose env5389 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound5389 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5390 : List Nat := [2,4,8,1,0,0,128,140,136,134,136,10,128,131,1,3,10,136,134,1,10,137,137,138,9,136,0,131,130,0,14,136,140,137,131,0]

theorem envBound5390 : H12AffineFastState.Bounded env5390 := by
  intro p hp
  have h : env5390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5389_5390 : H12AffineEnvironment.transform 4 0 env5389 = env5390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5389 == env5390) = true)

theorem identity5390 : scanCanonicalize (H12AffineFastState.compose env5390 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5391 : List Nat := [2,4,8,1,0,0,3,15,11,5,11,10,3,0,1,3,10,11,5,1,10,10,10,9,9,11,0,0,1,0,14,11,15,10,0,0]

theorem envBound5391 : H12AffineFastState.Bounded env5391 := by
  intro p hp
  have h : env5391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5390_5391 : H12AffineEnvironment.transform 6 3 env5390 = env5391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5390 == env5391) = true)

theorem identity5391 : scanCanonicalize (H12AffineFastState.compose env5391 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5391 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5392 : List Nat := [2,4,3,1,0,0,3,4,0,5,0,1,3,0,1,3,1,0,5,1,1,1,1,2,2,0,0,0,1,0,5,0,4,1,0,0]

theorem envBound5392 : H12AffineFastState.Bounded env5392 := by
  intro p hp
  have h : env5392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5391_5392 : H12AffineEnvironment.transform 2 3 env5391 = env5392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5391 == env5392) = true)

def env5393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388689,323792,16384,16892,22641,74794,12644669,257,20560,4239489,8389612]

theorem envBound5393 : H12AffineFastState.Bounded env5393 := by
  intro p hp
  have h : env5393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5325_5393 : H12AffineEnvironment.transform 18 1025 env5325 = env5393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5325 == env5393) = true)

theorem identity5393 : scanCanonicalize (H12AffineFastState.compose env5393 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20924) := by decide +kernel

theorem selectedBound5393 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,20924,41003,8329,20973,323792,16384,16892,22641,74794,4235393,257,20560,4239489,21072]

theorem envBound5394 : H12AffineFastState.Bounded env5394 := by
  intro p hp
  have h : env5394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5393_5394 : H12AffineEnvironment.transform 22 20924 env5393 = env5394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20924 env5393 == env5394) = true)

def env5395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4605,262144,1025,32768,4096,4194304,444,41003,8329,493,303312,4096,4604,2161,74794,4235393,257,80,4239489,592]

theorem envBound5395 : H12AffineFastState.Bounded env5395 := by
  intro p hp
  have h : env5395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5394_5395 : H12AffineEnvironment.transform 13 4096 env5394 = env5395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5394 == env5395) = true)

theorem identity5395 : scanCanonicalize (H12AffineFastState.compose env5395 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound5395 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,4194304,444,41003,8329,445,303232,4096,4524,2081,74794,4235393,257,0,4239489,512]

theorem envBound5396 : H12AffineFastState.Bounded env5396 := by
  intro p hp
  have h : env5396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5395_5396 : H12AffineEnvironment.transform 5 16 env5395 = env5396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5395 == env5396) = true)

theorem identity5396 : scanCanonicalize (H12AffineFastState.compose env5396 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5396 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5397 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4525,262144,1025,32768,4096,41349,444,41003,8329,445,303232,4096,4524,2081,74794,260,257,0,4356,512]

theorem envBound5397 : H12AffineFastState.Bounded env5397 := by
  intro p hp
  have h : env5397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5396_5397 : H12AffineEnvironment.transform 21 41349 env5396 = env5397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5396 == env5397) = true)

theorem identity5397 : scanCanonicalize (H12AffineFastState.compose env5397 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound5397 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13973,65536,4525,262144,1025,13973,4096,5904,444,5822,8329,445,267797,4096,4524,2081,74794,260,257,0,4356,512]

theorem envBound5398 : H12AffineFastState.Bounded env5398 := by
  intro p hp
  have h : env5398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5397_5398 : H12AffineEnvironment.transform 14 13973 env5397 = env5398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env5397 == env5398) = true)

theorem identity5398 : scanCanonicalize (H12AffineFastState.compose env5398 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound5398 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13973,8323,4525,262144,1025,13973,4096,5904,444,5822,8329,445,267797,4096,4524,2081,1193,260,257,0,4356,512]

theorem envBound5399 : H12AffineFastState.Bounded env5399 := by
  intro p hp
  have h : env5399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5398_5399 : H12AffineEnvironment.transform 15 8323 env5398 = env5399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env5398 == env5399) = true)

theorem identity5399 : scanCanonicalize (H12AffineFastState.compose env5399 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5399 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5400 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,4096,13973,8323,4096,262144,1025,13973,4096,5821,17,5822,8329,16,267797,4096,4097,2081,1193,169,172,0,4265,512]

theorem envBound5400 : H12AffineFastState.Bounded env5400 := by
  intro p hp
  have h : env5400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5399_5400 : H12AffineEnvironment.transform 7 173 env5399 = env5400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5399 == env5400) = true)

def env5401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,4194304,445,41003,8329,492,303313,4097,4605,2160,74794,4235393,257,81,4239489,593]

theorem envBound5401 : H12AffineFastState.Bounded env5401 := by
  intro p hp
  have h : env5401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5394_5401 : H12AffineEnvironment.transform 13 4097 env5394 = env5401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env5394 == env5401) = true)

def env5402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,41088,445,41003,8329,492,303313,4097,4605,2160,74794,1,257,81,4097,593]

theorem envBound5402 : H12AffineFastState.Bounded env5402 := by
  intro p hp
  have h : env5402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5401_5402 : H12AffineEnvironment.transform 21 41088 env5401 = env5402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env5401 == env5402) = true)

theorem identity5402 : scanCanonicalize (H12AffineFastState.compose env5402 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound5402 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5403 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4265,262144,1025,32768,4096,41088,233,41003,8329,184,303313,4097,4265,2160,74794,1,85,81,4097,593]

theorem envBound5403 : H12AffineFastState.Bounded env5403 := by
  intro p hp
  have h : env5403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5402_5403 : H12AffineEnvironment.transform 7 84 env5402 = env5403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env5402 == env5403) = true)

theorem identity5403 : scanCanonicalize (H12AffineFastState.compose env5403 (packedSelected [0,1,3,7,10,11,13,17,18,20,23,24,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound5403 : packedSelected [0,1,3,7,10,11,13,17,18,20,23,24,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5404 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,4096,8192,4097,32768,65536,4265,7869,1025,32768,4096,41088,233,41003,8329,184,48748,4097,4265,2160,74794,1,85,81,4097,593]

theorem envBound5404 : H12AffineFastState.Bounded env5404 := by
  intro p hp
  have h : env5404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5403_5404 : H12AffineEnvironment.transform 17 7869 env5403 = env5404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env5403 == env5404) = true)

def env5405 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,32768,65536,4097,7701,1025,32768,4096,41000,65,41003,8225,16,48748,4097,4097,2160,74794,1,85,81,4097,593]

theorem envBound5405 : H12AffineFastState.Bounded env5405 := by
  intro p hp
  have h : env5405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5404_5405 : H12AffineEnvironment.transform 6 40 env5404 = env5405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5404 == env5405) = true)

theorem identity5405 : scanCanonicalize (H12AffineFastState.compose env5405 (packedSelected [0,1,5,7,8,17,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 13932) := by decide +kernel

theorem selectedBound5405 : packedSelected [0,1,5,7,8,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env5406 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13932,65536,4097,7701,1025,13932,4096,5700,65,5703,8225,16,2048,4097,4097,2160,74794,1,85,81,4097,593]

theorem envBound5406 : H12AffineFastState.Bounded env5406 := by
  intro p hp
  have h : env5406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5405_5406 : H12AffineEnvironment.transform 14 13932 env5405 = env5406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13932 env5405 == env5406) = true)

theorem identity5406 : scanCanonicalize (H12AffineFastState.compose env5406 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 13854) := by decide +kernel

theorem selectedBound5406 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5407 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8192,4097,13932,13854,4097,7701,1025,13932,4096,5700,65,5703,8225,16,2048,4097,4097,2160,4660,1,85,81,4097,593]

theorem envBound5407 : H12AffineFastState.Bounded env5407 := by
  intro p hp
  have h : env5407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5406_5407 : H12AffineEnvironment.transform 15 13854 env5406 = env5407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13854 env5406 == env5407) = true)

theorem identity5407 : scanCanonicalize (H12AffineFastState.compose env5407 (packedSelected [1,2,6,8,10,11,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2115) := by decide +kernel

theorem selectedBound5407 : packedSelected [1,2,6,8,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env5408 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,2115,4097,7727,7773,4097,7701,1025,7727,4096,5700,65,5703,2146,16,2048,4097,4097,2160,4660,1,85,81,4097,593]

theorem envBound5408 : H12AffineFastState.Bounded env5408 := by
  intro p hp
  have h : env5408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5407_5408 : H12AffineEnvironment.transform 12 2115 env5407 = env5408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2115 env5407 == env5408) = true)

theorem identity5408 : scanCanonicalize (H12AffineFastState.compose env5408 (packedSelected [0,1,7,8,10,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound5408 : packedSelected [0,1,7,8,10,12,18] rootPS < 2^1333 := by decide +kernel

def env5409 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,1589,2115,1588,2074,2152,1588,2080,1025,2074,1589,113,65,114,2146,16,2048,1588,1588,2160,1025,1,85,81,1588,593]

theorem envBound5409 : H12AffineFastState.Bounded env5409 := by
  intro p hp
  have h : env5409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5408_5409 : H12AffineEnvironment.transform 11 1589 env5408 = env5409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env5408 == env5409) = true)

theorem identity5409 : scanCanonicalize (H12AffineFastState.compose env5409 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1630) := by decide +kernel

theorem selectedBound5409 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5410 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1630,1589,1565,1588,1604,1590,1588,1662,1025,1604,1589,113,65,114,1596,16,1630,1588,1588,1582,1025,1,85,81,1588,593]

theorem envBound5410 : H12AffineFastState.Bounded env5410 := by
  intro p hp
  have h : env5410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5409_5410 : H12AffineEnvironment.transform 10 1630 env5409 = env5410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1630 env5409 == env5410) = true)

theorem identity5410 : scanCanonicalize (H12AffineFastState.compose env5410 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5410 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env5411 : List Nat := [2,4,8,16,26,64,18,84,512,1024,1630,1551,1565,1550,1604,1548,1550,1604,1025,1604,1551,75,65,72,1542,16,1630,1550,1550,1556,1025,1,85,81,1550,593]

theorem envBound5411 : H12AffineFastState.Bounded env5411 := by
  intro p hp
  have h : env5411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5410_5411 : H12AffineEnvironment.transform 4 26 env5410 = env5411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5410 == env5411) = true)

theorem identity5411 : scanCanonicalize (H12AffineFastState.compose env5411 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound5411 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5412 : List Nat := [2,4,8,16,26,64,18,84,512,526,80,1,19,0,74,2,0,74,527,74,1,75,65,72,8,16,80,0,0,26,527,1,85,81,0,593]

theorem envBound5412 : H12AffineFastState.Bounded env5412 := by
  intro p hp
  have h : env5412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5411_5412 : H12AffineEnvironment.transform 9 526 env5411 = env5412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env5411 == env5412) = true)

theorem identity5412 : scanCanonicalize (H12AffineFastState.compose env5412 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5412 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env5413 : List Nat := [2,4,8,16,26,64,18,84,0,14,80,1,19,0,74,2,0,74,15,74,1,75,65,72,8,16,80,0,0,26,15,1,85,81,0,81]

theorem envBound5413 : H12AffineFastState.Bounded env5413 := by
  intro p hp
  have h : env5413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5412_5413 : H12AffineEnvironment.transform 8 0 env5412 = env5413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5412 == env5413) = true)

theorem identity5413 : scanCanonicalize (H12AffineFastState.compose env5413 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound5413 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5414 : List Nat := [2,4,8,16,26,16,18,4,0,14,0,1,19,0,26,2,0,26,15,26,1,27,17,24,8,16,0,0,0,26,15,1,5,1,0,1]

theorem envBound5414 : H12AffineFastState.Bounded env5414 := by
  intro p hp
  have h : env5414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5413_5414 : H12AffineEnvironment.transform 5 16 env5413 = env5414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5413 == env5414) = true)

theorem identity5414 : scanCanonicalize (H12AffineFastState.compose env5414 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound5414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5415 : List Nat := [2,4,8,5,15,5,7,4,0,14,0,1,6,0,15,2,0,15,15,15,1,14,4,13,8,5,0,0,0,15,15,1,5,1,0,1]

theorem envBound5415 : H12AffineFastState.Bounded env5415 := by
  intro p hp
  have h : env5415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5414_5415 : H12AffineEnvironment.transform 3 5 env5414 = env5415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env5414 == env5415) = true)

theorem identity5415 : scanCanonicalize (H12AffineFastState.compose env5415 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5415 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5416 : List Nat := [2,1,8,0,10,0,2,1,0,11,0,1,3,0,10,2,0,10,10,10,1,11,1,8,8,0,0,0,0,10,10,1,0,1,0,1]

theorem envBound5416 : H12AffineFastState.Bounded env5416 := by
  intro p hp
  have h : env5416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5415_5416 : H12AffineEnvironment.transform 1 1 env5415 = env5416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5415 == env5416) = true)

def leafEnv5416 : List Nat := [2,1,8,0,10,0,2,1,0,11,0,1,3,0,10,2,0,10,10,10,1,11,1,8,11,8,1,0,0,0,0,10,10,1,0,1,0,9,0,1,1,1,0]

def active5416 : List Nat := [0,2]

def tree5416 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5416 : H12WitnessSearch.Good tree5416 := H12GlobalWitnessIndex.good

theorem leafIdentity5416 : H12AffineFastState.composeSystem env5416 rootObs = leafEnv5416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5416 rootObs == leafEnv5416) = true)

theorem terminalChecked5416 : H12PackedTerminal.terminalCheckFast leafEnv5416 active5416 tree5416 = true := by decide +kernel

def env5417 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8192,4097,32768,65536,4096,7700,1025,32768,4096,41001,64,41003,8224,17,48748,4097,4096,2160,74794,1,85,81,4097,593]

theorem envBound5417 : H12AffineFastState.Bounded env5417 := by
  intro p hp
  have h : env5417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5404_5417 : H12AffineEnvironment.transform 6 41 env5404 = env5417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5404 == env5417) = true)

theorem identity5417 : scanCanonicalize (H12AffineFastState.compose env5417 (packedSelected [0,1,5,7,8,17,20,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound5417 : packedSelected [0,1,5,7,8,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env5418 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,8192,1637,32768,65536,1636,2160,1025,32768,1636,41001,64,41003,8224,17,43016,1637,1636,2160,74794,1,85,81,1637,593]

theorem envBound5418 : H12AffineFastState.Bounded env5418 := by
  intro p hp
  have h : env5418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5417_5418 : H12AffineEnvironment.transform 11 1636 env5417 = env5418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env5417 == env5418) = true)

theorem identity5418 : scanCanonicalize (H12AffineFastState.compose env5418 (packedSelected [3,5,8,13,21,28] rootPS)) = affineNative (2^(14+1) ^^^ 8280) := by decide +kernel

theorem selectedBound5418 : packedSelected [3,5,8,13,21,28] rootPS < 2^1333 := by decide +kernel

def env5419 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,8192,1637,8280,65536,1636,2160,1025,8280,1636,113,64,115,8224,17,2128,1637,1636,2160,74794,1,85,81,1637,593]

theorem envBound5419 : H12AffineFastState.Bounded env5419 := by
  intro p hp
  have h : env5419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5418_5419 : H12AffineEnvironment.transform 14 8280 env5418 = env5419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8280 env5418 == env5419) = true)

theorem identity5419 : scanCanonicalize (H12AffineFastState.compose env5419 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5419 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5420 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,8192,1637,8280,8235,1636,2160,1025,8280,1636,113,64,115,8224,17,2128,1637,1636,2160,1025,1,85,81,1637,593]

theorem envBound5420 : H12AffineFastState.Bounded env5420 := by
  intro p hp
  have h : env5420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5419_5420 : H12AffineEnvironment.transform 15 8235 env5419 = env5420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5419 == env5420) = true)

theorem identity5420 : scanCanonicalize (H12AffineFastState.compose env5420 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound5420 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5421 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,1636,1101,1637,1045,1126,1636,2160,1025,1045,1636,113,64,115,1133,17,2128,1637,1636,2160,1025,1,85,81,1637,593]

theorem envBound5421 : H12AffineFastState.Bounded env5421 := by
  intro p hp
  have h : env5421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5420_5421 : H12AffineEnvironment.transform 12 1101 env5420 = env5421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env5420 == env5421) = true)

theorem identity5421 : scanCanonicalize (H12AffineFastState.compose env5421 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1631) := by decide +kernel

theorem selectedBound5421 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5422 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1631,1636,1101,1637,1045,1126,1636,1583,1025,1045,1636,113,64,115,1133,17,1551,1637,1636,1583,1025,1,85,81,1637,593]

theorem envBound5422 : H12AffineFastState.Bounded env5422 := by
  intro p hp
  have h : env5422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5421_5422 : H12AffineEnvironment.transform 10 1631 env5421 = env5422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1631 env5421 == env5422) = true)

theorem identity5422 : scanCanonicalize (H12AffineFastState.compose env5422 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound5422 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env5423 : List Nat := [2,4,8,16,32,10,41,30,512,1024,1557,1582,1031,1583,1045,1068,1582,1583,1025,1045,1582,59,10,57,1063,17,1551,1583,1582,1583,1025,1,31,27,1583,539]

theorem envBound5423 : H12AffineFastState.Bounded env5423 := by
  intro p hp
  have h : env5423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5422_5423 : H12AffineEnvironment.transform 5 10 env5422 = env5423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env5422 == env5423) = true)

theorem identity5423 : scanCanonicalize (H12AffineFastState.compose env5423 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5423 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5424 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1551,1582,1031,1583,1039,1068,1582,1583,1025,1039,1582,33,10,35,1063,11,1551,1583,1582,1583,1025,1,5,1,1583,513]

theorem envBound5424 : H12AffineFastState.Bounded env5424 := by
  intro p hp
  have h : env5424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5423_5424 : H12AffineEnvironment.transform 3 10 env5423 = env5424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5423 == env5424) = true)

theorem identity5424 : scanCanonicalize (H12AffineFastState.compose env5424 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound5424 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5425 : List Nat := [2,4,8,10,32,10,41,4,47,1024,1056,1025,1031,1024,1039,1068,1025,1024,1025,1039,1025,33,10,35,1063,11,1056,1024,1025,1024,1025,1,5,1,1024,46]

theorem envBound5425 : H12AffineFastState.Bounded env5425 := by
  intro p hp
  have h : env5425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5424_5425 : H12AffineEnvironment.transform 8 47 env5424 = env5425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env5424 == env5425) = true)

def env5426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4605,262144,1025,32768,4096,41089,445,41003,8329,492,303313,4097,4605,2160,74794,0,257,81,4096,593]

theorem envBound5426 : H12AffineFastState.Bounded env5426 := by
  intro p hp
  have h : env5426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5401_5426 : H12AffineEnvironment.transform 21 41089 env5401 = env5426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env5401 == env5426) = true)

theorem identity5426 : scanCanonicalize (H12AffineFastState.compose env5426 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5426 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5427 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,32768,65536,4345,262144,1025,32768,4096,41089,185,41003,8329,232,303313,4097,4345,2160,74794,0,5,81,4096,593]

theorem envBound5427 : H12AffineFastState.Bounded env5427 := by
  intro p hp
  have h : env5427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5426_5427 : H12AffineEnvironment.transform 7 4 env5426 = env5427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5426 == env5427) = true)

theorem identity5427 : scanCanonicalize (H12AffineFastState.compose env5427 (packedSelected [0,7,11,13,17,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 14020) := by decide +kernel

theorem selectedBound5427 : packedSelected [0,7,11,13,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env5428 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,8192,4097,14020,65536,4345,262144,1025,14020,4096,5701,185,5871,8329,232,267797,4097,4345,2160,74794,0,5,81,4096,593]

theorem envBound5428 : H12AffineFastState.Bounded env5428 := by
  intro p hp
  have h : env5428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5427_5428 : H12AffineEnvironment.transform 14 14020 env5427 = env5428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14020 env5427 == env5428) = true)

def env5429 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,65536,4097,262144,1025,13884,4096,5701,65,5655,8305,16,267797,4097,4097,2160,74794,0,5,81,4096,593]

theorem envBound5429 : H12AffineFastState.Bounded env5429 := by
  intro p hp
  have h : env5429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5428_5429 : H12AffineEnvironment.transform 6 120 env5428 = env5429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env5428 == env5429) = true)

theorem identity5429 : scanCanonicalize (H12AffineFastState.compose env5429 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 75787) := by decide +kernel

theorem selectedBound5429 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5430 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,65536,4097,75787,1025,13884,4096,5701,65,5655,8305,16,81438,4097,4097,2160,74794,0,5,81,4096,593]

theorem envBound5430 : H12AffineFastState.Bounded env5430 := by
  intro p hp
  have h : env5430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5429_5430 : H12AffineEnvironment.transform 17 75787 env5429 = env5430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75787 env5429 == env5430) = true)

theorem identity5430 : scanCanonicalize (H12AffineFastState.compose env5430 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 13903) := by decide +kernel

theorem selectedBound5430 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5431 : List Nat := [2,4,8,16,32,64,120,4,512,1024,2048,4096,8192,4097,13884,13903,4097,7748,1025,13884,4096,5701,65,5655,8305,16,2129,4097,4097,2160,4709,0,5,81,4096,593]

theorem envBound5431 : H12AffineFastState.Bounded env5431 := by
  intro p hp
  have h : env5431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5430_5431 : H12AffineEnvironment.transform 15 13903 env5430 = env5431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13903 env5430 == env5431) = true)

theorem identity5431 : scanCanonicalize (H12AffineFastState.compose env5431 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound5431 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5432 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,4096,8192,4097,13884,13854,4097,7701,1025,13884,4096,5652,16,5655,8224,16,2048,4097,4097,2081,4660,0,5,0,4096,512]

theorem envBound5432 : H12AffineFastState.Bounded env5432 := by
  intro p hp
  have h : env5432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5431_5432 : H12AffineEnvironment.transform 5 17 env5431 = env5432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5431 == env5432) = true)

theorem identity5432 : scanCanonicalize (H12AffineFastState.compose env5432 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5432 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env5433 : List Nat := [2,4,8,10,32,11,41,4,512,1024,2048,4096,8192,4097,13862,13828,4097,7695,1025,13862,4096,5646,10,5645,8224,10,2048,4097,4097,2081,4654,0,5,0,4096,512]

theorem envBound5433 : H12AffineFastState.Bounded env5433 := by
  intro p hp
  have h : env5433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5432_5433 : H12AffineEnvironment.transform 3 10 env5432 = env5433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5432 == env5433) = true)

theorem identity5433 : scanCanonicalize (H12AffineFastState.compose env5433 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound5433 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env5434 : List Nat := [2,4,8,10,32,11,41,4,512,1024,2048,1582,8192,1583,8200,8234,1583,2081,1025,8200,1582,32,10,35,8224,10,2048,1583,1583,2081,1024,0,5,0,1582,512]

theorem envBound5434 : H12AffineFastState.Bounded env5434 := by
  intro p hp
  have h : env5434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5433_5434 : H12AffineEnvironment.transform 11 1582 env5433 = env5434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env5433 == env5434) = true)

theorem identity5434 : scanCanonicalize (H12AffineFastState.compose env5434 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound5434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5435 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1551,1582,8192,1583,8200,8234,1583,1582,1025,8200,1582,32,10,35,8224,10,1551,1583,1583,1582,1024,0,5,0,1582,512]

theorem envBound5435 : H12AffineFastState.Bounded env5435 := by
  intro p hp
  have h : env5435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5434_5435 : H12AffineEnvironment.transform 10 1551 env5434 = env5435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env5434 == env5435) = true)

def env5436 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,65536,4096,262144,1025,13885,4096,5701,64,5654,8304,17,267797,4097,4096,2160,74794,0,5,81,4096,593]

theorem envBound5436 : H12AffineFastState.Bounded env5436 := by
  intro p hp
  have h : env5436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5428_5436 : H12AffineEnvironment.transform 6 121 env5428 = env5436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env5428 == env5436) = true)

theorem identity5436 : scanCanonicalize (H12AffineFastState.compose env5436 (packedSelected [1,5,8,17,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 81471) := by decide +kernel

theorem selectedBound5436 : packedSelected [1,5,8,17,21,24] rootPS < 2^1333 := by decide +kernel

def env5437 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,65536,4096,81471,1025,13885,4096,5701,64,5654,8304,17,75818,4097,4096,2160,74794,0,5,81,4096,593]

theorem envBound5437 : H12AffineFastState.Bounded env5437 := by
  intro p hp
  have h : env5437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5436_5437 : H12AffineEnvironment.transform 17 81471 env5436 = env5437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81471 env5436 == env5437) = true)

theorem identity5437 : scanCanonicalize (H12AffineFastState.compose env5437 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 13903) := by decide +kernel

theorem selectedBound5437 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5438 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,4096,8192,4097,13885,13903,4096,2160,1025,13885,4096,5701,64,5654,8304,17,7781,4097,4096,2160,4709,0,5,81,4096,593]

theorem envBound5438 : H12AffineFastState.Bounded env5438 := by
  intro p hp
  have h : env5438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5437_5438 : H12AffineEnvironment.transform 15 13903 env5437 = env5438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13903 env5437 == env5438) = true)

theorem identity5438 : scanCanonicalize (H12AffineFastState.compose env5438 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5438 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5439 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1588,8192,1589,8201,8315,1588,2160,1025,8201,1588,113,64,34,8304,17,2129,1589,1588,2160,1105,0,5,81,1588,593]

theorem envBound5439 : H12AffineFastState.Bounded env5439 := by
  intro p hp
  have h : env5439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5438_5439 : H12AffineEnvironment.transform 11 1588 env5438 = env5439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5438 == env5439) = true)

theorem identity5439 : scanCanonicalize (H12AffineFastState.compose env5439 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1630) := by decide +kernel

theorem selectedBound5439 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5440 : List Nat := [2,4,8,16,32,64,121,4,512,1024,1630,1588,8192,1589,8201,8315,1588,1582,1025,8201,1588,113,64,34,8304,17,1551,1589,1588,1582,1105,0,5,81,1588,593]

theorem envBound5440 : H12AffineFastState.Bounded env5440 := by
  intro p hp
  have h : env5440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5439_5440 : H12AffineEnvironment.transform 10 1630 env5439 = env5440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1630 env5439 == env5440) = true)

def env5441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914000,849104,16384,16892,547953,598059,12644668,525568,545872,4239488,8914925]

theorem envBound5441 : H12AffineFastState.Bounded env5441 := by
  intro p hp
  have h : env5441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5324_5441 : H12AffineEnvironment.transform 20 4097 env5324 = env5441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5324 == env5441) = true)

def env5442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388688,323792,16384,16892,22641,74795,12644668,256,20560,4239488,8389613]

theorem envBound5442 : H12AffineFastState.Bounded env5442 := by
  intro p hp
  have h : env5442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5441_5442 : H12AffineEnvironment.transform 18 1024 env5441 = env5442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5441 == env5442) = true)

theorem identity5442 : scanCanonicalize (H12AffineFastState.compose env5442 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4240429) := by decide +kernel

theorem selectedBound5442 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4240429,41003,8329,4240509,323792,16384,16892,22641,74795,17681,256,20560,4239488,4241344]

theorem envBound5443 : H12AffineFastState.Bounded env5443 := by
  intro p hp
  have h : env5443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5442_5443 : H12AffineEnvironment.transform 22 4240429 env5442 = env5443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240429 env5442 == env5443) = true)

end H12CloudChart1