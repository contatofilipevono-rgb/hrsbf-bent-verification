import H12CloudChart1Data070

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity17903 : scanCanonicalize (H12AffineFastState.compose env17903 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17903 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env17904 : List Nat := [2,4,8,16,32,17,9,256,17,52,261,17,57,0,308,50,16,276,53,309,276,32,16,3,56,16,48,33,32,32,304,16,257,16,49,16]

theorem envBound17904 : H12AffineFastState.Bounded env17904 := by
  intro p hp
  have h : env17904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17903_17904 : H12AffineEnvironment.transform 9 52 env17903 = env17904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17903 == env17904) = true)

theorem identity17904 : scanCanonicalize (H12AffineFastState.compose env17904 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17904 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env17905 : List Nat := [2,4,8,16,32,17,9,37,17,52,32,17,57,0,17,50,16,49,53,16,49,32,16,3,56,16,48,33,32,32,21,16,36,16,49,16]

theorem envBound17905 : H12AffineFastState.Bounded env17905 := by
  intro p hp
  have h : env17905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17904_17905 : H12AffineEnvironment.transform 7 37 env17904 = env17905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17904 == env17905) = true)

theorem identity17905 : scanCanonicalize (H12AffineFastState.compose env17905 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17906 : List Nat := [2,4,8,1,32,0,9,37,0,37,32,0,40,0,0,35,1,32,36,1,32,32,1,3,41,1,33,33,32,32,4,1,36,1,32,1]

theorem envBound17906 : H12AffineFastState.Bounded env17906 := by
  intro p hp
  have h : env17906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17905_17906 : H12AffineEnvironment.transform 3 1 env17905 = env17906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17905 == env17906) = true)

def env17907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,17,41310,8193,65,4302891,2172250,2118977,2420,75102,6407191,257,2188650,2196550,513]

theorem envBound17907 : H12AffineFastState.Bounded env17907 := by
  intro p hp
  have h : env17907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17892_17907 : H12AffineEnvironment.transform 16 16401 env17892 = env17907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17892 == env17907) = true)

theorem identity17907 : scanCanonicalize (H12AffineFastState.compose env17907 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound17907 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env17908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,115734,4194304,17,41310,8193,65,4302891,57676,102743,2420,75102,4194305,257,41340,16464,513]

theorem envBound17908 : H12AffineFastState.Bounded env17908 := by
  intro p hp
  have h : env17908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17907_17908 : H12AffineEnvironment.transform 20 115734 env17907 = env17908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env17907 == env17908) = true)

def env17909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91198,4194304,17,374,8193,65,4261891,16740,78207,2420,75102,4194305,257,340,16464,513]

theorem envBound17909 : H12AffineFastState.Bounded env17909 := by
  intro p hp
  have h : env17909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17908_17909 : H12AffineEnvironment.transform 14 8232 env17908 = env17909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env17908 == env17909) = true)

theorem identity17909 : scanCanonicalize (H12AffineFastState.compose env17909 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound17909 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env17910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10588,1025,8233,91198,65538,17,374,8193,65,2049,16740,78207,2420,75102,65539,257,340,16464,513]

theorem envBound17910 : H12AffineFastState.Bounded env17910 := by
  intro p hp
  have h : env17910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17909_17910 : H12AffineEnvironment.transform 21 65538 env17909 = env17910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env17909 == env17910) = true)

theorem identity17910 : scanCanonicalize (H12AffineFastState.compose env17910 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound17910 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,34,16401,10588,1025,8233,25628,32,17,374,8193,65,2049,16740,12637,2420,9596,33,257,340,16464,513]

theorem envBound17911 : H12AffineFastState.Bounded env17911 := by
  intro p hp
  have h : env17911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17910_17911 : H12AffineEnvironment.transform 15 34 env17910 = env17911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env17910 == env17911) = true)

theorem identity17911 : scanCanonicalize (H12AffineFastState.compose env17911 (packedSelected [11,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17911 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env17912 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,34,16401,10281,1025,8233,25628,32,17,3,8193,65,2049,16401,12328,2049,9225,33,116,33,16464,513]

theorem envBound17912 : H12AffineFastState.Bounded env17912 := by
  intro p hp
  have h : env17912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17911_17912 : H12AffineEnvironment.transform 7 117 env17911 = env17912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17911 == env17912) = true)

theorem identity17912 : scanCanonicalize (H12AffineFastState.compose env17912 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound17912 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17913 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,16384,80,34,16401,2129,1025,81,17508,32,17,3,121,65,2049,16401,4176,2049,1137,33,116,33,16464,513]

theorem envBound17913 : H12AffineFastState.Bounded env17913 := by
  intro p hp
  have h : env17913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17912_17913 : H12AffineEnvironment.transform 12 120 env17912 = env17913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env17912 == env17913) = true)

theorem identity17913 : scanCanonicalize (H12AffineFastState.compose env17913 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17913 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17914 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,16384,1,34,16401,2048,1025,0,17461,32,17,3,40,16,2049,16401,4097,2049,1056,33,37,33,16385,513]

theorem envBound17914 : H12AffineFastState.Bounded env17914 := by
  intro p hp
  have h : env17914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17913_17914 : H12AffineEnvironment.transform 5 17 env17913 = env17914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17913 == env17914) = true)

theorem identity17914 : scanCanonicalize (H12AffineFastState.compose env17914 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound17914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17915 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,1,1,34,16,2048,1025,0,1076,32,17,3,40,16,2049,16,4097,2049,1056,33,37,33,0,513]

theorem envBound17915 : H12AffineFastState.Bounded env17915 := by
  intro p hp
  have h : env17915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17914_17915 : H12AffineEnvironment.transform 13 1 env17914 = env17915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env17914 == env17915) = true)

theorem identity17915 : scanCanonicalize (H12AffineFastState.compose env17915 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound17915 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17916 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,41,1,1,34,16,523,1025,0,1076,32,17,3,40,16,522,16,4097,522,1056,33,37,33,0,513]

theorem envBound17916 : H12AffineFastState.Bounded env17916 := by
  intro p hp
  have h : env17916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17915_17916 : H12AffineEnvironment.transform 10 523 env17915 = env17916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env17915 == env17916) = true)

theorem identity17916 : scanCanonicalize (H12AffineFastState.compose env17916 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound17916 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17917 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,1551,41,1,1,34,16,523,1025,0,1076,32,17,3,40,16,522,16,1550,522,1056,33,37,33,0,513]

theorem envBound17917 : H12AffineFastState.Bounded env17917 := by
  intro p hp
  have h : env17917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17916_17917 : H12AffineEnvironment.transform 11 1551 env17916 = env17917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env17916 == env17917) = true)

theorem identity17917 : scanCanonicalize (H12AffineFastState.compose env17917 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17917 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17918 : List Nat := [2,4,8,16,32,17,9,36,512,52,523,571,41,1,1,34,16,523,53,0,0,32,17,3,40,16,522,16,570,522,20,33,37,33,0,513]

theorem envBound17918 : H12AffineFastState.Bounded env17918 := by
  intro p hp
  have h : env17918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17917_17918 : H12AffineEnvironment.transform 9 52 env17917 = env17918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17917 == env17918) = true)

theorem identity17918 : scanCanonicalize (H12AffineFastState.compose env17918 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound17918 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17919 : List Nat := [2,4,8,16,32,17,9,36,42,52,33,17,41,1,1,34,16,33,53,0,0,32,17,3,40,16,32,16,16,32,20,33,37,33,0,43]

theorem envBound17919 : H12AffineFastState.Bounded env17919 := by
  intro p hp
  have h : env17919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17918_17919 : H12AffineEnvironment.transform 8 42 env17918 = env17919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env17918 == env17919) = true)

theorem identity17919 : scanCanonicalize (H12AffineFastState.compose env17919 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound17919 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17920 : List Nat := [2,1,8,16,32,17,9,33,42,49,33,17,41,1,1,34,16,33,48,0,0,32,17,3,40,16,32,16,16,32,17,33,32,33,0,43]

theorem envBound17920 : H12AffineFastState.Bounded env17920 := by
  intro p hp
  have h : env17920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17919_17920 : H12AffineEnvironment.transform 1 1 env17919 = env17920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env17919 == env17920) = true)

theorem identity17920 : scanCanonicalize (H12AffineFastState.compose env17920 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound17920 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17921 : List Nat := [2,1,8,16,18,17,9,19,24,3,19,17,27,1,1,16,16,19,2,0,0,18,17,3,26,16,18,16,16,18,17,19,18,19,0,25]

theorem envBound17921 : H12AffineFastState.Bounded env17921 := by
  intro p hp
  have h : env17921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17920_17921 : H12AffineEnvironment.transform 4 18 env17920 = env17921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env17920 == env17921) = true)

theorem identity17921 : scanCanonicalize (H12AffineFastState.compose env17921 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound17921 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env17922 : List Nat := [2,1,8,3,1,2,9,0,11,3,0,2,8,1,1,3,3,0,2,0,0,1,2,3,9,3,1,3,3,1,2,0,1,0,0,10]

theorem envBound17922 : H12AffineFastState.Bounded env17922 := by
  intro p hp
  have h : env17922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17921_17922 : H12AffineEnvironment.transform 3 3 env17921 = env17922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env17921 == env17922) = true)

def env17923 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91199,4194304,17,375,8193,65,4261890,16741,78206,2420,75102,4194305,257,341,16464,513]

theorem envBound17923 : H12AffineFastState.Bounded env17923 := by
  intro p hp
  have h : env17923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17908_17923 : H12AffineEnvironment.transform 14 8233 env17908 = env17923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17908 == env17923) = true)

theorem identity17923 : scanCanonicalize (H12AffineFastState.compose env17923 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound17923 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env17924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10589,1025,8232,91199,65911,17,375,8193,65,2421,16741,78206,2420,75102,65910,257,341,16464,513]

theorem envBound17924 : H12AffineFastState.Bounded env17924 := by
  intro p hp
  have h : env17924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17923_17924 : H12AffineEnvironment.transform 21 65911 env17923 = env17924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env17923 == env17924) = true)

theorem identity17924 : scanCanonicalize (H12AffineFastState.compose env17924 (packedSelected [0,2,6,11,14,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17924 : packedSelected [0,2,6,11,14,18,27] rootPS < 2^1333 := by decide +kernel

def env17925 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,343,16401,10589,1025,8232,25960,32,17,375,8193,65,2421,16741,12329,2420,9225,33,257,341,16464,513]

theorem envBound17925 : H12AffineFastState.Bounded env17925 := by
  intro p hp
  have h : env17925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17924_17925 : H12AffineEnvironment.transform 15 343 env17924 = env17925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17924 == env17925) = true)

theorem identity17925 : scanCanonicalize (H12AffineFastState.compose env17925 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17925 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env17926 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,35,16401,10281,1025,8232,25628,32,17,3,8193,65,2049,16401,12329,2048,9225,33,117,33,16464,513]

theorem envBound17926 : H12AffineFastState.Bounded env17926 := by
  intro p hp
  have h : env17926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17925_17926 : H12AffineEnvironment.transform 7 116 env17925 = env17926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17925 == env17926) = true)

theorem identity17926 : scanCanonicalize (H12AffineFastState.compose env17926 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound17926 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17927 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,80,35,16401,2128,1025,81,17509,32,17,3,120,65,2049,16401,4176,2048,1136,33,117,33,16464,513]

theorem envBound17927 : H12AffineFastState.Bounded env17927 := by
  intro p hp
  have h : env17927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17926_17927 : H12AffineEnvironment.transform 12 121 env17926 = env17927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env17926 == env17927) = true)

theorem identity17927 : scanCanonicalize (H12AffineFastState.compose env17927 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17927 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17928 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,16384,1,35,16401,2049,1025,0,17460,32,17,3,41,16,2049,16401,4097,2048,1057,33,36,33,16385,513]

theorem envBound17928 : H12AffineFastState.Bounded env17928 := by
  intro p hp
  have h : env17928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17927_17928 : H12AffineEnvironment.transform 5 17 env17927 = env17928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17927 == env17928) = true)

theorem identity17928 : scanCanonicalize (H12AffineFastState.compose env17928 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound17928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17929 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,1,1,35,16,2049,1025,0,1077,32,17,3,41,16,2049,16,4097,2048,1057,33,36,33,0,513]

theorem envBound17929 : H12AffineFastState.Bounded env17929 := by
  intro p hp
  have h : env17929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17928_17929 : H12AffineEnvironment.transform 13 1 env17928 = env17929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env17928 == env17929) = true)

theorem identity17929 : scanCanonicalize (H12AffineFastState.compose env17929 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound17929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17930 : List Nat := [2,4,8,16,32,17,9,37,512,1024,522,4096,40,1,1,35,16,523,1025,0,1077,32,17,3,41,16,523,16,4097,522,1057,33,36,33,0,513]

theorem envBound17930 : H12AffineFastState.Bounded env17930 := by
  intro p hp
  have h : env17930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17929_17930 : H12AffineEnvironment.transform 10 522 env17929 = env17930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env17929 == env17930) = true)

theorem identity17930 : scanCanonicalize (H12AffineFastState.compose env17930 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1551) := by decide +kernel

theorem selectedBound17930 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17931 : List Nat := [2,4,8,16,32,17,9,37,512,1024,522,1551,40,1,1,35,16,523,1025,0,1077,32,17,3,41,16,523,16,1550,522,1057,33,36,33,0,513]

theorem envBound17931 : H12AffineFastState.Bounded env17931 := by
  intro p hp
  have h : env17931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17930_17931 : H12AffineEnvironment.transform 11 1551 env17930 = env17931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1551 env17930 == env17931) = true)

theorem identity17931 : scanCanonicalize (H12AffineFastState.compose env17931 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17931 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17932 : List Nat := [2,4,8,16,32,17,9,37,512,52,522,571,40,1,1,35,16,523,53,0,1,32,17,3,41,16,523,16,570,522,21,33,36,33,0,513]

theorem envBound17932 : H12AffineFastState.Bounded env17932 := by
  intro p hp
  have h : env17932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17931_17932 : H12AffineEnvironment.transform 9 52 env17931 = env17932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17931 == env17932) = true)

theorem identity17932 : scanCanonicalize (H12AffineFastState.compose env17932 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound17932 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17933 : List Nat := [2,4,8,16,32,17,9,37,42,52,32,17,40,1,1,35,16,33,53,0,1,32,17,3,41,16,33,16,16,32,21,33,36,33,0,43]

theorem envBound17933 : H12AffineFastState.Bounded env17933 := by
  intro p hp
  have h : env17933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17932_17933 : H12AffineEnvironment.transform 8 42 env17932 = env17933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env17932 == env17933) = true)

theorem identity17933 : scanCanonicalize (H12AffineFastState.compose env17933 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound17933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17934 : List Nat := [2,4,8,14,32,15,9,37,42,42,32,15,40,1,1,35,14,33,43,0,1,32,15,3,41,14,33,14,14,32,11,33,36,33,0,43]

theorem envBound17934 : H12AffineFastState.Bounded env17934 := by
  intro p hp
  have h : env17934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17933_17934 : H12AffineEnvironment.transform 3 14 env17933 = env17934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env17933 == env17934) = true)

theorem identity17934 : scanCanonicalize (H12AffineFastState.compose env17934 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound17934 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17935 : List Nat := [2,4,8,14,9,15,9,12,3,3,9,15,1,1,1,10,14,8,2,0,1,9,15,3,0,14,8,14,14,9,11,8,13,8,0,2]

theorem envBound17935 : H12AffineFastState.Bounded env17935 := by
  intro p hp
  have h : env17935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17934_17935 : H12AffineEnvironment.transform 4 9 env17934 = env17935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env17934 == env17935) = true)

theorem identity17935 : scanCanonicalize (H12AffineFastState.compose env17935 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound17935 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env17936 : List Nat := [2,4,1,7,0,6,0,5,3,3,0,6,1,1,1,3,7,1,2,0,1,0,6,3,0,7,1,7,7,0,2,1,4,1,0,2]

theorem envBound17936 : H12AffineFastState.Bounded env17936 := by
  intro p hp
  have h : env17936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17935_17936 : H12AffineEnvironment.transform 2 1 env17935 = env17936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env17935 == env17936) = true)

def env17937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147457,16777216,8193,65,21039476,18973700,2233681,2421,17024016,23160137,257,19104804,19096840,16966479]

theorem envBound17937 : H12AffineFastState.Bounded env17937 := by
  intro p hp
  have h : env17937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17890_17937 : H12AffineEnvironment.transform 22 147457 env17890 = env17937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env17890 == env17937) = true)

def env17938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,16777216,8193,65,21039476,18973700,2118977,2421,16876544,23160137,257,18990132,18949400,16819039]

theorem envBound17938 : H12AffineFastState.Bounded env17938 := by
  intro p hp
  have h : env17938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17937_17938 : H12AffineEnvironment.transform 16 16400 env17937 = env17938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17937 == env17938) = true)

theorem identity17938 : scanCanonicalize (H12AffineFastState.compose env17938 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound17938 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,17,41310,8193,65,4302890,2172250,2118977,2421,75102,6407191,257,2188650,2196550,513]

theorem envBound17939 : H12AffineFastState.Bounded env17939 := by
  intro p hp
  have h : env17939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17938_17939 : H12AffineEnvironment.transform 23 41310 env17938 = env17939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env17938 == env17939) = true)

theorem identity17939 : scanCanonicalize (H12AffineFastState.compose env17939 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound17939 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env17940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,115734,4194304,17,41310,8193,65,4302890,57676,102743,2421,75102,4194305,257,41340,16464,513]

theorem envBound17940 : H12AffineFastState.Bounded env17940 := by
  intro p hp
  have h : env17940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17939_17940 : H12AffineEnvironment.transform 20 115734 env17939 = env17940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env17939 == env17940) = true)

theorem identity17940 : scanCanonicalize (H12AffineFastState.compose env17940 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound17940 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env17941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,91467,4194304,17,3,8193,65,4262263,16401,77834,2421,75102,4194305,257,33,16464,513]

theorem envBound17941 : H12AffineFastState.Bounded env17941 := by
  intro p hp
  have h : env17941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17940_17941 : H12AffineEnvironment.transform 14 8541 env17940 = env17941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env17940 == env17941) = true)

theorem identity17941 : scanCanonicalize (H12AffineFastState.compose env17941 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound17941 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,91467,8572,17,3,8193,65,75787,16401,77834,2421,75102,8573,257,33,16464,513]

theorem envBound17942 : H12AffineFastState.Bounded env17942 := by
  intro p hp
  have h : env17942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17941_17942 : H12AffineEnvironment.transform 21 8572 env17941 = env17942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env17941 == env17942) = true)

def env17943 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,16777216,8193,65,21039476,18973700,2118976,2421,16876545,23160137,257,18990133,18949401,16819038]

theorem envBound17943 : H12AffineFastState.Bounded env17943 := by
  intro p hp
  have h : env17943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17937_17943 : H12AffineEnvironment.transform 16 16401 env17937 = env17943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17937 == env17943) = true)

theorem identity17943 : scanCanonicalize (H12AffineFastState.compose env17943 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound17943 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,2,8193,65,4262262,2196486,2118976,2421,99331,6382923,257,2212919,2172187,41820]

theorem envBound17944 : H12AffineFastState.Bounded env17944 := by
  intro p hp
  have h : env17944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17943_17944 : H12AffineEnvironment.transform 23 2 env17943 = env17944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env17943 == env17944) = true)

def env17945 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35108,1025,32769,2097152,4194304,16,2,8193,17,4262182,2196486,2118928,2341,99331,6382875,257,2212919,2172187,41740]

theorem envBound17945 : H12AffineFastState.Bounded env17945 := by
  intro p hp
  have h : env17945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17944_17945 : H12AffineEnvironment.transform 5 16 env17944 = env17945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17944 == env17945) = true)

theorem identity17945 : scanCanonicalize (H12AffineFastState.compose env17945 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound17945 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17946 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33030,16401,35108,1025,32769,2097152,4194304,16,2,8193,17,4229152,2098432,2118928,2341,1285,6349853,257,2114865,2139165,41740]

theorem envBound17946 : H12AffineFastState.Bounded env17946 := by
  intro p hp
  have h : env17946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17945_17946 : H12AffineEnvironment.transform 15 33030 env17945 = env17946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env17945 == env17946) = true)

theorem identity17946 : scanCanonicalize (H12AffineFastState.compose env17946 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound17946 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env17947 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33030,16401,35108,1025,32769,50448,4194304,16,2,8193,17,4229152,49168,36864,2341,1285,4202765,257,32801,24845,41740]

theorem envBound17947 : H12AffineFastState.Bounded env17947 := by
  intro p hp
  have h : env17947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17946_17947 : H12AffineEnvironment.transform 20 50448 env17946 = env17947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env17946 == env17947) = true)

def env17948 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35109,1025,32769,2097152,4194304,16,2,8193,16,4262183,2196486,2118929,2340,99331,6382874,257,2212919,2172187,41741]

theorem envBound17948 : H12AffineFastState.Bounded env17948 := by
  intro p hp
  have h : env17948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17944_17948 : H12AffineEnvironment.transform 5 17 env17944 = env17948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17944 == env17948) = true)

theorem identity17948 : scanCanonicalize (H12AffineFastState.compose env17948 (packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound17948 : packedSelected [0,2,3,6,10,12,14,15,16,17,18,20,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17949 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35109,1025,32769,2097152,73771,16,2,8193,16,10508,2196486,2118929,2340,99331,2114865,257,2212919,2172187,41741]

theorem envBound17949 : H12AffineFastState.Bounded env17949 := by
  intro p hp
  have h : env17949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17948_17949 : H12AffineEnvironment.transform 21 73771 env17948 = env17949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env17948 == env17949) = true)

theorem identity17949 : scanCanonicalize (H12AffineFastState.compose env17949 (packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17949 : packedSelected [0,1,3,5,7,8,11,12,14,16,20] rootPS < 2^1333 := by decide +kernel

def env17950 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16401,35109,1025,32769,2097152,65831,16,2,269,16,2048,2196486,2118929,2340,99331,2114865,257,2212919,2163735,33281]

theorem envBound17950 : H12AffineFastState.Bounded env17950 := by
  intro p hp
  have h : env17950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17949_17950 : H12AffineEnvironment.transform 12 268 env17949 = env17950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17949 == env17950) = true)

theorem identity17950 : scanCanonicalize (H12AffineFastState.compose env17950 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound17950 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17951 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16401,35109,1025,32769,82967,65831,16,2,269,16,2048,49169,69894,2340,99331,65830,257,32800,16384,33281]

theorem envBound17951 : H12AffineFastState.Bounded env17951 := by
  intro p hp
  have h : env17951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17950_17951 : H12AffineEnvironment.transform 20 82967 env17950 = env17951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env17950 == env17951) = true)

theorem identity17951 : scanCanonicalize (H12AffineFastState.compose env17951 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound17951 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17952 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,33030,16401,35109,1025,32769,50449,32801,16,2,269,16,2048,49169,36864,2340,1285,32800,257,32800,16384,33281]

theorem envBound17952 : H12AffineFastState.Bounded env17952 := by
  intro p hp
  have h : env17952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17951_17952 : H12AffineEnvironment.transform 15 33030 env17951 = env17952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env17951 == env17952) = true)

theorem identity17952 : scanCanonicalize (H12AffineFastState.compose env17952 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 3620) := by decide +kernel

theorem selectedBound17952 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env17953 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,3620,32768,33030,3637,35109,1025,32769,35637,32801,16,2,269,16,2048,36405,36864,2340,1285,32800,257,32800,3620,33281]

theorem envBound17953 : H12AffineFastState.Bounded env17953 := by
  intro p hp
  have h : env17953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17952_17953 : H12AffineEnvironment.transform 13 3620 env17952 = env17953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3620 env17952 == env17953) = true)

theorem identity17953 : scanCanonicalize (H12AffineFastState.compose env17953 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound17953 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env17954 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,268,3620,32768,33030,3637,35109,1025,32769,35637,32801,16,2,269,16,2048,36405,35876,2340,1285,32800,257,32800,3620,33281]

theorem envBound17954 : H12AffineFastState.Bounded env17954 := by
  intro p hp
  have h : env17954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17953_17954 : H12AffineEnvironment.transform 11 3108 env17953 = env17954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env17953 == env17954) = true)

theorem identity17954 : scanCanonicalize (H12AffineFastState.compose env17954 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound17954 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env17955 : List Nat := [2,4,8,16,32,17,9,53,512,1024,2048,3108,57,3620,32768,32819,3637,34832,1025,32769,35328,32801,16,2,56,16,2048,36405,35876,2065,1072,32800,52,32800,3620,33281]

theorem envBound17955 : H12AffineFastState.Bounded env17955 := by
  intro p hp
  have h : env17955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17954_17955 : H12AffineEnvironment.transform 7 53 env17954 = env17955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env17954 == env17955) = true)

theorem identity17955 : scanCanonicalize (H12AffineFastState.compose env17955 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound17955 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17956 : List Nat := [2,4,8,16,32,17,9,53,512,1024,2048,3108,57,3620,512,563,3637,2576,1025,513,2048,545,16,2,56,16,2048,3125,3620,2065,1072,544,52,544,3620,1]

theorem envBound17956 : H12AffineFastState.Bounded env17956 := by
  intro p hp
  have h : env17956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17955_17956 : H12AffineEnvironment.transform 14 512 env17955 = env17956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env17955 == env17956) = true)

theorem identity17956 : scanCanonicalize (H12AffineFastState.compose env17956 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound17956 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env17957 : List Nat := [2,4,8,16,32,17,9,53,512,1024,1077,17,57,529,512,563,512,1573,1025,513,1077,545,16,2,56,16,1077,0,529,1060,1072,544,52,544,529,1]

theorem envBound17957 : H12AffineFastState.Bounded env17957 := by
  intro p hp
  have h : env17957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17956_17957 : H12AffineEnvironment.transform 10 1077 env17956 = env17957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env17956 == env17957) = true)

theorem identity17957 : scanCanonicalize (H12AffineFastState.compose env17957 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound17957 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env17958 : List Nat := [2,4,8,16,32,17,9,53,512,565,512,17,57,529,512,563,512,16,564,513,512,545,16,2,56,16,512,0,529,529,517,544,52,544,529,1]

theorem envBound17958 : H12AffineFastState.Bounded env17958 := by
  intro p hp
  have h : env17958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17957_17958 : H12AffineEnvironment.transform 9 565 env17957 = env17958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env17957 == env17958) = true)

theorem identity17958 : scanCanonicalize (H12AffineFastState.compose env17958 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17958 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17959 : List Nat := [2,4,8,16,32,17,9,53,17,36,17,17,57,0,17,34,17,16,37,16,17,48,16,2,56,16,17,0,0,0,20,49,52,49,0,1]

theorem envBound17959 : H12AffineFastState.Bounded env17959 := by
  intro p hp
  have h : env17959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17958_17959 : H12AffineEnvironment.transform 8 17 env17958 = env17959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17958 == env17959) = true)

theorem identity17959 : scanCanonicalize (H12AffineFastState.compose env17959 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17960 : List Nat := [2,4,8,0,32,1,9,37,1,36,1,1,41,0,1,34,1,0,37,0,1,32,0,2,40,0,1,0,0,0,4,33,36,33,0,1]

theorem envBound17960 : H12AffineFastState.Bounded env17960 := by
  intro p hp
  have h : env17960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17959_17960 : H12AffineEnvironment.transform 3 0 env17959 = env17960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17959 == env17960) = true)

theorem identity17960 : scanCanonicalize (H12AffineFastState.compose env17960 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound17960 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17961 : List Nat := [2,4,8,0,14,1,9,11,1,10,1,1,7,0,1,12,1,0,11,0,1,14,0,2,6,0,1,0,0,0,4,15,10,15,0,1]

theorem envBound17961 : H12AffineFastState.Bounded env17961 := by
  intro p hp
  have h : env17961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17960_17961 : H12AffineEnvironment.transform 4 14 env17960 = env17961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env17960 == env17961) = true)

theorem identity17961 : scanCanonicalize (H12AffineFastState.compose env17961 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound17961 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17962 : List Nat := [2,4,6,0,0,1,7,5,1,4,1,1,7,0,1,2,1,0,5,0,1,0,0,2,6,0,1,0,0,0,4,1,4,1,0,1]

theorem envBound17962 : H12AffineFastState.Bounded env17962 := by
  intro p hp
  have h : env17962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17961_17962 : H12AffineEnvironment.transform 2 6 env17961 = env17962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env17961 == env17962) = true)

def env17963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507600,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound17963 : H12AffineFastState.Bounded env17963 := by
  intro p hp
  have h : env17963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17692_17963 : H12AffineEnvironment.transform 26 30393345 env17692 = env17963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env17692 == env17963) = true)

def env17964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound17964 : H12AffineFastState.Bounded env17964 := by
  intro p hp
  have h : env17964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17963_17964 : H12AffineEnvironment.transform 18 1024 env17963 = env17964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17963 == env17964) = true)

theorem identity17964 : scanCanonicalize (H12AffineFastState.compose env17964 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493492) := by decide +kernel

theorem selectedBound17964 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,16777216,8328,65,23186485,18973836,416100,2149428,19367973,23160257,256,17287320,17246525,19312626]

theorem envBound17965 : H12AffineFastState.Bounded env17965 := by
  intro p hp
  have h : env17965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17964_17965 : H12AffineEnvironment.transform 22 2493492 env17964 = env17965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493492 env17964 == env17965) = true)

def env17966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,499128,8328,65,6705549,2496820,416100,2149428,2102685,6748281,256,21792,46213,2175562]

theorem envBound17966 : H12AffineFastState.Bounded env17966 := by
  intro p hp
  have h : env17966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17965_17966 : H12AffineEnvironment.transform 23 499128 env17965 = env17966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env17965 == env17966) = true)

def env17967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493492,499128,8328,65,2396605,2496820,416100,2149428,2102685,2373705,256,21792,46213,2175562]

theorem envBound17967 : H12AffineFastState.Bounded env17967 := by
  intro p hp
  have h : env17967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17966_17967 : H12AffineEnvironment.transform 21 180272 env17966 = env17967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env17966 == env17967) = true)

def env17968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400500,499128,8328,65,295421,395636,416100,56436,1501,272393,256,21792,46213,74250]

theorem envBound17968 : H12AffineFastState.Bounded env17968 := by
  intro p hp
  have h : env17968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17967_17968 : H12AffineEnvironment.transform 20 4160 env17967 = env17968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17967 == env17968) = true)

theorem identity17968 : scanCanonicalize (H12AffineFastState.compose env17968 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound17968 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4160,180272,73755,41431,8328,65,245138,79131,91403,56436,1501,201830,256,21792,46213,74250]

theorem envBound17969 : H12AffineFastState.Bounded env17969 := by
  intro p hp
  have h : env17969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17968_17969 : H12AffineEnvironment.transform 17 212079 env17968 = env17969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env17968 == env17969) = true)

def env17970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212031,1024,32769,4112,180272,73755,41351,8328,17,245138,79131,91403,56356,1421,201782,256,21792,46213,74250]

theorem envBound17970 : H12AffineFastState.Bounded env17970 := by
  intro p hp
  have h : env17970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17969_17970 : H12AffineEnvironment.transform 5 16 env17969 = env17970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17969 == env17970) = true)

theorem identity17970 : scanCanonicalize (H12AffineFastState.compose env17970 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound17970 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env17971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,108967,1024,32769,4112,21928,73755,41351,8328,17,75786,79131,91403,56356,1421,98734,256,21792,46213,74250]

theorem envBound17971 : H12AffineFastState.Bounded env17971 := by
  intro p hp
  have h : env17971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17970_17971 : H12AffineEnvironment.transform 16 38296 env17970 = env17971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env17970 == env17971) = true)

theorem identity17971 : scanCanonicalize (H12AffineFastState.compose env17971 (packedSelected [10,17,18,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound17971 : packedSelected [10,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env17972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40970,38296,2477,1024,32769,4112,21928,32785,41351,8328,17,34816,38161,50433,56356,1421,8612,256,21792,46213,33280]

theorem envBound17972 : H12AffineFastState.Bounded env17972 := by
  intro p hp
  have h : env17972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17971_17972 : H12AffineEnvironment.transform 15 40970 env17971 = env17972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env17971 == env17972) = true)

theorem identity17972 : scanCanonicalize (H12AffineFastState.compose env17972 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound17972 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env17973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21897,30083,16401,2477,1024,21896,4112,21928,21912,29710,8328,17,23945,16536,4232,2477,1421,8612,256,21792,24844,22409]

theorem envBound17973 : H12AffineFastState.Bounded env17973 := by
  intro p hp
  have h : env17973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17972_17973 : H12AffineEnvironment.transform 14 21897 env17972 = env17973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env17972 == env17973) = true)

theorem identity17973 : scanCanonicalize (H12AffineFastState.compose env17973 (packedSelected [0,2,4,5,6,7,8,9,11,14,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 11690) := by decide +kernel

theorem selectedBound17973 : packedSelected [0,2,4,5,6,7,8,9,11,14,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,11690,14371,6185,11707,2477,1024,14370,4112,14338,14386,6564,8328,17,12323,11570,4232,2477,1421,8612,256,14474,3238,14883]

theorem envBound17974 : H12AffineFastState.Bounded env17974 := by
  intro p hp
  have h : env17974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17973_17974 : H12AffineEnvironment.transform 13 11690 env17973 = env17974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11690 env17973 == env17974) = true)

theorem identity17974 : scanCanonicalize (H12AffineFastState.compose env17974 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound17974 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env17975 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,3118,6567,6185,3135,2477,1024,6566,4112,6534,6582,6564,268,17,4519,3254,4232,2477,1421,32,256,6414,3238,7079]

theorem envBound17975 : H12AffineFastState.Bounded env17975 := by
  intro p hp
  have h : env17975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17974_17975 : H12AffineEnvironment.transform 12 388 env17974 = env17975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env17974 == env17975) = true)

theorem identity17975 : scanCanonicalize (H12AffineFastState.compose env17975 (packedSelected [4,5,8,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17975 : packedSelected [4,5,8,9,14] rootPS < 2^1333 := by decide +kernel

def env17976 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,3118,6446,6185,3135,2340,1024,6447,4112,6415,6463,6445,268,17,4398,3135,4097,2340,1284,32,256,6414,3119,6958]

theorem envBound17976 : H12AffineFastState.Bounded env17976 := by
  intro p hp
  have h : env17976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17975_17976 : H12AffineEnvironment.transform 6 9 env17975 = env17976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17975 == env17976) = true)

theorem identity17976 : scanCanonicalize (H12AffineFastState.compose env17976 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound17976 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env17977 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,269,3118,1291,1036,3135,2340,1024,1290,3125,1322,1306,1288,268,17,3339,3135,3108,2340,1284,32,256,1323,3119,1803]

theorem envBound17977 : H12AffineFastState.Bounded env17977 := by
  intro p hp
  have h : env17977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17976_17977 : H12AffineEnvironment.transform 11 3109 env17976 = env17977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env17976 == env17977) = true)

theorem identity17977 : scanCanonicalize (H12AffineFastState.compose env17977 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound17977 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env17978 : List Nat := [2,4,8,16,32,16,9,256,512,314,2048,2335,269,2324,49,310,2309,2340,314,48,2319,16,32,50,268,17,2097,2309,2334,2340,62,32,256,17,2325,561]

theorem envBound17978 : H12AffineFastState.Bounded env17978 := by
  intro p hp
  have h : env17978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17977_17978 : H12AffineEnvironment.transform 9 314 env17977 = env17978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env17977 == env17978) = true)

theorem identity17978 : scanCanonicalize (H12AffineFastState.compose env17978 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17978 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17979 : List Nat := [2,4,8,16,16,16,9,256,512,266,2048,2335,269,2324,1,262,2309,2324,266,0,2319,16,16,2,268,17,2049,2309,2334,2324,14,16,256,17,2325,513]

theorem envBound17979 : H12AffineFastState.Bounded env17979 := by
  intro p hp
  have h : env17979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17978_17979 : H12AffineEnvironment.transform 4 16 env17978 = env17979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17978 == env17979) = true)

theorem identity17979 : scanCanonicalize (H12AffineFastState.compose env17979 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound17979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17980 : List Nat := [2,4,8,16,16,16,9,30,512,20,2048,2049,19,2058,1,24,2075,2058,20,0,2065,16,16,2,18,17,2049,2075,2048,2058,14,16,30,17,2059,513]

theorem envBound17980 : H12AffineFastState.Bounded env17980 := by
  intro p hp
  have h : env17980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17979_17980 : H12AffineEnvironment.transform 7 30 env17979 = env17980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env17979 == env17980) = true)

def env17981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212030,1024,32769,4113,180272,73755,41350,8328,16,245138,79131,91403,56357,1420,201783,256,21792,46213,74250]

theorem envBound17981 : H12AffineFastState.Bounded env17981 := by
  intro p hp
  have h : env17981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17969_17981 : H12AffineEnvironment.transform 5 17 env17969 = env17981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17969 == env17981) = true)

theorem identity17981 : scanCanonicalize (H12AffineFastState.compose env17981 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound17981 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env17982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13341,67619,1024,32769,4113,62509,73755,41350,8328,16,100751,79131,91403,56357,1420,73770,256,21792,46213,74250]

theorem envBound17982 : H12AffineFastState.Bounded env17982 := by
  intro p hp
  have h : env17982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17981_17982 : H12AffineEnvironment.transform 16 13341 env17981 = env17982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env17981 == env17982) = true)

theorem identity17982 : scanCanonicalize (H12AffineFastState.compose env17982 (packedSelected [0,1,2,3,4,6,7,9,10,11,14,17,18,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 41383) := by decide +kernel

theorem selectedBound17982 : packedSelected [0,1,2,3,4,6,7,9,10,11,14,17,18,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,41383,13341,43396,1024,32769,4113,62509,33212,41350,8328,16,10280,38076,50348,56357,1420,33165,256,21792,46213,33709]

theorem envBound17983 : H12AffineFastState.Bounded env17983 := by
  intro p hp
  have h : env17983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17982_17983 : H12AffineEnvironment.transform 15 41383 env17982 = env17983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41383 env17982 == env17983) = true)

theorem identity17983 : scanCanonicalize (H12AffineFastState.compose env17983 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17983 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,17,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env17984 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,16384,32768,41090,13341,43169,1024,32769,4113,62509,32921,41123,8328,16,10280,38076,50348,56357,1193,32936,37,21509,46213,33416]

theorem envBound17984 : H12AffineFastState.Bounded env17984 := by
  intro p hp
  have h : env17984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17983_17984 : H12AffineEnvironment.transform 7 37 env17983 = env17984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17983 == env17984) = true)

theorem identity17984 : scanCanonicalize (H12AffineFastState.compose env17984 (packedSelected [0,1,4,7,8,12,15,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound17984 : packedSelected [0,1,4,7,8,12,15,19,22] rootPS < 2^1333 := by decide +kernel

def env17985 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,8192,16384,136,8202,13341,10281,1024,137,4113,29861,17,8235,8328,16,10280,5172,17444,23725,1193,32,37,21509,13325,512]

theorem envBound17985 : H12AffineFastState.Bounded env17985 := by
  intro p hp
  have h : env17985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17984_17985 : H12AffineEnvironment.transform 14 136 env17984 = env17985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env17984 == env17985) = true)

theorem identity17985 : scanCanonicalize (H12AffineFastState.compose env17985 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound17985 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17986 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,16384,136,171,5308,2184,1024,137,4113,21508,17,138,41,16,2185,5172,17444,23725,1193,32,37,21509,5292,512]

theorem envBound17986 : H12AffineFastState.Bounded env17986 := by
  intro p hp
  have h : env17986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17985_17986 : H12AffineEnvironment.transform 12 161 env17985 = env17986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env17985 == env17986) = true)

theorem identity17986 : scanCanonicalize (H12AffineFastState.compose env17986 (packedSelected [0,3,5,6,7,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound17986 : packedSelected [0,3,5,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env17987 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,5157,136,171,5308,2184,1024,137,4113,33,17,138,41,16,2185,5172,4097,2184,1193,32,37,32,5292,512]

theorem envBound17987 : H12AffineFastState.Bounded env17987 := by
  intro p hp
  have h : env17987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17986_17987 : H12AffineEnvironment.transform 13 5157 env17986 = env17987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env17986 == env17987) = true)

theorem identity17987 : scanCanonicalize (H12AffineFastState.compose env17987 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17987 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17988 : List Nat := [2,4,8,16,1,17,128,4,512,1024,2048,4096,128,5124,136,138,5277,2184,1024,137,4113,0,17,138,8,16,2185,5141,4097,2184,1160,1,4,1,5261,512]

theorem envBound17988 : H12AffineFastState.Bounded env17988 := by
  intro p hp
  have h : env17988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17987_17988 : H12AffineEnvironment.transform 4 1 env17987 = env17988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17987 == env17988) = true)

theorem identity17988 : scanCanonicalize (H12AffineFastState.compose env17988 (packedSelected [1,2,8] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound17988 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env17989 : List Nat := [2,4,8,16,1,17,128,4,512,1024,2048,1029,128,1,136,138,152,2184,1024,137,1044,0,17,138,8,16,2185,16,1028,2184,1160,1,4,1,136,512]

theorem envBound17989 : H12AffineFastState.Bounded env17989 := by
  intro p hp
  have h : env17989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17988_17989 : H12AffineEnvironment.transform 11 1029 env17988 = env17989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env17988 == env17989) = true)

def env17990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400501,499128,8328,65,295420,395637,416100,56437,1500,272392,256,21792,46213,74251]

theorem envBound17990 : H12AffineFastState.Bounded env17990 := by
  intro p hp
  have h : env17990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17967_17990 : H12AffineEnvironment.transform 20 4161 env17967 = env17990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17967 == env17990) = true)

theorem identity17990 : scanCanonicalize (H12AffineFastState.compose env17990 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound17990 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,180272,400501,412007,8328,65,295420,395637,416100,56437,1500,272392,256,21792,46213,63188]

theorem envBound17991 : H12AffineFastState.Bounded env17991 := by
  intro p hp
  have h : env17991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17990_17991 : H12AffineEnvironment.transform 15 54495 env17990 = env17991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env17990 == env17991) = true)

def env17992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180272,400501,412007,8192,65,295284,395637,416100,56437,1364,272392,256,21792,46093,63068]

theorem envBound17992 : H12AffineFastState.Bounded env17992 := by
  intro p hp
  have h : env17992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17991_17992 : H12AffineEnvironment.transform 6 8 env17991 = env17992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17991 == env17992) = true)

theorem identity17992 : scanCanonicalize (H12AffineFastState.compose env17992 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 2128) := by decide +kernel

theorem selectedBound17992 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env17993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,2128,1024,32769,4161,180272,136229,147767,8192,65,35108,131365,151860,56437,1364,8280,256,21792,46093,63068]

theorem envBound17993 : H12AffineFastState.Bounded env17993 := by
  intro p hp
  have h : env17993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17992_17993 : H12AffineEnvironment.transform 17 2128 env17992 = env17993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2128 env17992 == env17993) = true)

theorem identity17993 : scanCanonicalize (H12AffineFastState.compose env17993 (packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound17993 : packedSelected [0,3,4,7,10,11,16,20,22,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,114,131072,2128,1024,21540,4161,136213,136229,147767,8192,65,23809,131365,151860,2128,1364,8280,256,21792,24616,8825]

theorem envBound17994 : H12AffineFastState.Bounded env17994 := by
  intro p hp
  have h : env17994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17993_17994 : H12AffineEnvironment.transform 14 21541 env17993 = env17994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env17993 == env17994) = true)

theorem identity17994 : scanCanonicalize (H12AffineFastState.compose env17994 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13672) := by decide +kernel

theorem selectedBound17994 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env17995 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21541,114,13672,2128,1024,21540,4161,8573,8525,29791,8192,65,23809,13389,25692,2128,1364,8280,256,21792,24616,8825]

theorem envBound17995 : H12AffineFastState.Bounded env17995 := by
  intro p hp
  have h : env17995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17994_17995 : H12AffineEnvironment.transform 16 13672 env17994 = env17995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13672 env17994 == env17995) = true)

theorem identity17995 : scanCanonicalize (H12AffineFastState.compose env17995 (packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17995 : packedSelected [1,2,6,8,10,14,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env17996 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,16384,21541,114,5440,2128,1024,21540,4161,341,357,21623,40,65,23809,5221,17524,2128,1364,112,256,21792,16384,593]

theorem envBound17996 : H12AffineFastState.Bounded env17996 := by
  intro p hp
  have h : env17996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17995_17996 : H12AffineEnvironment.transform 12 40 env17995 = env17996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17995 == env17996) = true)

theorem identity17996 : scanCanonicalize (H12AffineFastState.compose env17996 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17996 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17997 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,16384,21541,35,5393,2049,1024,21540,4112,260,308,21542,40,16,23809,5172,17445,2049,1285,33,256,21792,16384,512]

theorem envBound17997 : H12AffineFastState.Bounded env17997 := by
  intro p hp
  have h : env17997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17996_17997 : H12AffineEnvironment.transform 5 17 env17996 = env17997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17996 == env17997) = true)

theorem identity17997 : scanCanonicalize (H12AffineFastState.compose env17997 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17997 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17998 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,16384,21541,35,5140,2049,1024,21540,4112,1,49,21542,40,16,23556,5172,17445,2049,1024,33,5,21541,16384,512]

theorem envBound17998 : H12AffineFastState.Bounded env17998 := by
  intro p hp
  have h : env17998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17997_17998 : H12AffineEnvironment.transform 7 5 env17997 = env17998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17997 == env17998) = true)

theorem identity17998 : scanCanonicalize (H12AffineFastState.compose env17998 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound17998 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17999 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,40,5125,32,35,5140,2049,1024,33,4112,1,49,35,40,16,2049,5172,4128,2049,1024,33,5,32,5125,512]

theorem envBound17999 : H12AffineFastState.Bounded env17999 := by
  intro p hp
  have h : env17999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17998_17999 : H12AffineEnvironment.transform 13 5125 env17998 = env17999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env17998 == env17999) = true)

theorem identity17999 : scanCanonicalize (H12AffineFastState.compose env17999 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound17999 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env18000 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,1556,40,529,32,35,512,2049,1024,33,1540,1,49,35,40,16,2049,544,1588,2049,1024,33,5,32,529,512]

theorem envBound18000 : H12AffineFastState.Bounded env18000 := by
  intro p hp
  have h : env18000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17999_18000 : H12AffineEnvironment.transform 11 1556 env17999 = env18000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env17999 == env18000) = true)

theorem identity18000 : scanCanonicalize (H12AffineFastState.compose env18000 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound18000 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env18001 : List Nat := [2,4,8,16,32,17,8,5,512,1024,49,1556,40,529,32,35,512,48,1024,33,1540,1,49,35,40,16,48,544,1588,48,1024,33,5,32,529,512]

theorem envBound18001 : H12AffineFastState.Bounded env18001 := by
  intro p hp
  have h : env18001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18000_18001 : H12AffineEnvironment.transform 10 49 env18000 = env18001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env18000 == env18001) = true)

theorem identity18001 : scanCanonicalize (H12AffineFastState.compose env18001 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound18001 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env18002 : List Nat := [2,4,8,16,32,17,8,5,512,565,49,33,40,529,32,35,512,48,565,33,49,1,49,35,40,16,48,544,1,48,565,33,5,32,529,512]

theorem envBound18002 : H12AffineFastState.Bounded env18002 := by
  intro p hp
  have h : env18002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18001_18002 : H12AffineEnvironment.transform 9 565 env18001 = env18002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env18001 == env18002) = true)

theorem identity18002 : scanCanonicalize (H12AffineFastState.compose env18002 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound18002 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18003 : List Nat := [2,4,8,16,17,17,8,5,512,516,0,16,25,529,17,18,512,1,516,16,0,1,0,18,25,16,1,529,1,1,516,16,5,17,529,512]

theorem envBound18003 : H12AffineFastState.Bounded env18003 := by
  intro p hp
  have h : env18003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18002_18003 : H12AffineEnvironment.transform 4 17 env18002 = env18003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env18002 == env18003) = true)

theorem identity18003 : scanCanonicalize (H12AffineFastState.compose env18003 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound18003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18004 : List Nat := [2,4,8,16,17,17,8,5,16,20,0,16,25,1,17,18,16,1,20,16,0,1,0,18,25,16,1,1,1,1,20,16,5,17,1,16]

theorem envBound18004 : H12AffineFastState.Bounded env18004 := by
  intro p hp
  have h : env18004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18003_18004 : H12AffineEnvironment.transform 8 16 env18003 = env18004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env18003 == env18004) = true)

theorem identity18004 : scanCanonicalize (H12AffineFastState.compose env18004 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18004 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18005 : List Nat := [2,4,8,1,0,0,8,5,1,5,0,1,8,1,0,3,1,1,5,1,0,1,0,3,8,1,1,1,1,1,5,1,5,0,1,1]

theorem envBound18005 : H12AffineFastState.Bounded env18005 := by
  intro p hp
  have h : env18005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18004_18005 : H12AffineEnvironment.transform 3 1 env18004 = env18005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18004 == env18005) = true)

theorem identity18005 : scanCanonicalize (H12AffineFastState.compose env18005 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound18005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18006 : List Nat := [2,4,6,1,0,0,6,5,1,5,0,1,6,1,0,3,1,1,5,1,0,1,0,3,6,1,1,1,1,1,5,1,5,0,1,1]

theorem envBound18006 : H12AffineFastState.Bounded env18006 := by
  intro p hp
  have h : env18006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18005_18006 : H12AffineEnvironment.transform 2 6 env18005 = env18006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env18005 == env18006) = true)

def env18007 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180272,400501,412007,8193,65,295285,395637,416100,56437,1365,272392,256,21792,46092,63069]

theorem envBound18007 : H12AffineFastState.Bounded env18007 := by
  intro p hp
  have h : env18007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17991_18007 : H12AffineEnvironment.transform 6 9 env17991 = env18007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17991 == env18007) = true)

theorem identity18007 : scanCanonicalize (H12AffineFastState.compose env18007 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound18007 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env18008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,23588,1024,32769,4161,180272,147537,136515,8193,65,56657,152913,132416,56437,1365,29740,256,21792,46092,63069]

theorem envBound18008 : H12AffineFastState.Bounded env18008 := by
  intro p hp
  have h : env18008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18007_18008 : H12AffineEnvironment.transform 17 23588 env18007 = env18008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env18007 == env18008) = true)

theorem identity18008 : scanCanonicalize (H12AffineFastState.compose env18008 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound18008 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env18009 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,57676,23588,1024,32769,4161,8572,41245,62479,8193,65,56657,46109,58380,56437,1365,29740,256,21792,46092,63069]

theorem envBound18009 : H12AffineFastState.Bounded env18009 := by
  intro p hp
  have h : env18009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18008_18009 : H12AffineEnvironment.transform 16 57676 env18008 = env18009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env18008 == env18009) = true)

theorem identity18009 : scanCanonicalize (H12AffineFastState.compose env18009 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18009 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env18010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,40970,38160,10360,1024,32769,4161,8572,41245,32851,8193,65,43277,46109,36944,43049,1365,112,256,8572,46092,33281]

theorem envBound18010 : H12AffineFastState.Bounded env18010 := by
  intro p hp
  have h : env18010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18009_18010 : H12AffineEnvironment.transform 13 13404 env18009 = env18010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18009 == env18010) = true)

theorem identity18010 : scanCanonicalize (H12AffineFastState.compose env18010 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18010 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env18011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8203,5393,10360,1024,0,4161,8572,8476,82,8193,65,10508,13340,4177,10280,1365,112,256,8572,13325,512]

theorem envBound18011 : H12AffineFastState.Bounded env18011 := by
  intro p hp
  have h : env18011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18010_18011 : H12AffineEnvironment.transform 14 1 env18010 = env18011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18010 == env18011) = true)

theorem identity18011 : scanCanonicalize (H12AffineFastState.compose env18011 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18011 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18012 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,13357,1,8203,5393,10249,1024,0,4144,8461,8476,35,8193,48,10508,13340,4128,10280,1316,1,256,8461,13325,512]

theorem envBound18012 : H12AffineFastState.Bounded env18012 := by
  intro p hp
  have h : env18012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18011_18012 : H12AffineEnvironment.transform 5 49 env18011 = env18012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18011 == env18012) = true)

theorem identity18012 : scanCanonicalize (H12AffineFastState.compose env18012 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound18012 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18013 : List Nat := [2,4,8,16,32,49,9,256,512,20,2048,4096,8192,12345,1,8203,4357,10249,20,0,4144,8461,8476,35,8193,48,10508,12296,4128,10280,304,1,256,8461,12313,512]

theorem envBound18013 : H12AffineFastState.Bounded env18013 := by
  intro p hp
  have h : env18013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18012_18013 : H12AffineEnvironment.transform 9 20 env18012 = env18013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env18012 == env18013) = true)

theorem identity18013 : scanCanonicalize (H12AffineFastState.compose env18013 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18013 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env18014 : List Nat := [2,4,8,16,1,16,9,256,512,20,2048,4096,8192,12312,1,8203,4357,10249,20,0,4113,8461,8476,2,8193,17,10508,12296,4097,10249,273,1,256,8461,12313,512]

theorem envBound18014 : H12AffineFastState.Bounded env18014 := by
  intro p hp
  have h : env18014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18013_18014 : H12AffineEnvironment.transform 4 1 env18013 = env18014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18013 == env18014) = true)

theorem identity18014 : scanCanonicalize (H12AffineFastState.compose env18014 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound18014 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18015 : List Nat := [2,4,8,16,1,16,9,256,512,20,2048,16,8192,8200,1,8203,277,10249,20,0,1,8461,8476,2,8193,17,10508,8216,17,10249,273,1,256,8461,8201,512]

theorem envBound18015 : H12AffineFastState.Bounded env18015 := by
  intro p hp
  have h : env18015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18014_18015 : H12AffineEnvironment.transform 11 16 env18014 = env18015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env18014 == env18015) = true)

theorem identity18015 : scanCanonicalize (H12AffineFastState.compose env18015 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound18015 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18016 : List Nat := [2,4,8,16,1,16,9,256,512,20,261,16,8192,8200,1,8203,277,8460,20,0,1,8461,8476,2,8193,17,8201,8216,17,8460,273,1,256,8461,8201,512]

theorem envBound18016 : H12AffineFastState.Bounded env18016 := by
  intro p hp
  have h : env18016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18015_18016 : H12AffineEnvironment.transform 10 261 env18015 = env18016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env18015 == env18016) = true)

def env18017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493492,499128,8328,65,2396604,2496820,416100,2149428,2102685,2373704,256,21792,46213,2175562]

theorem envBound18017 : H12AffineFastState.Bounded env18017 := by
  intro p hp
  have h : env18017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17966_18017 : H12AffineEnvironment.transform 21 180273 env17966 = env18017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env17966 == env18017) = true)

def env18018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400500,499128,8328,65,295420,395636,416100,56436,1501,272392,256,21792,46213,74250]

theorem envBound18018 : H12AffineFastState.Bounded env18018 := by
  intro p hp
  have h : env18018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18017_18018 : H12AffineEnvironment.transform 20 4160 env18017 = env18018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18017 == env18018) = true)

theorem identity18018 : scanCanonicalize (H12AffineFastState.compose env18018 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound18018 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,180273,400500,441779,8328,65,295420,395636,416100,56436,1501,272392,256,21792,46213,513]

theorem envBound18019 : H12AffineFastState.Bounded env18019 := by
  intro p hp
  have h : env18019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18018_18019 : H12AffineEnvironment.transform 15 8203 env18018 = env18019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env18018 == env18019) = true)

def env18020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,32801,285796,327075,8328,65,295420,280932,268660,56436,1501,272392,256,21792,46213,513]

theorem envBound18020 : H12AffineFastState.Bounded env18020 := by
  intro p hp
  have h : env18020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18019_18020 : H12AffineEnvironment.transform 16 16400 env18019 = env18020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env18019 == env18020) = true)

def env18021 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4112,32801,285748,327075,8328,17,295340,280884,268580,56356,1421,272392,256,21792,46213,513]

theorem envBound18021 : H12AffineFastState.Bounded env18021 := by
  intro p hp
  have h : env18021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18020_18021 : H12AffineEnvironment.transform 5 16 env18020 = env18021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18020 == env18021) = true)

theorem identity18021 : scanCanonicalize (H12AffineFastState.compose env18021 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound18021 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env18022 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,4112,32801,29844,54531,8328,17,43276,24980,12676,56356,1421,168,256,21792,46213,513]

theorem envBound18022 : H12AffineFastState.Bounded env18022 := by
  intro p hp
  have h : env18022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18021_18022 : H12AffineEnvironment.transform 17 10400 env18021 = env18022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env18021 == env18022) = true)

theorem identity18022 : scanCanonicalize (H12AffineFastState.compose env18022 (packedSelected [1,3,4,5,8,9,12,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound18022 : packedSelected [1,3,4,5,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env18023 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8203,16400,10400,1024,29829,4112,29861,29844,8583,8328,17,23944,24980,12676,10400,1421,168,256,21792,16385,513]

theorem envBound18023 : H12AffineFastState.Bounded env18023 := by
  intro p hp
  have h : env18023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18022_18023 : H12AffineEnvironment.transform 14 29828 env18022 = env18023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env18022 == env18023) = true)

theorem identity18023 : scanCanonicalize (H12AffineFastState.compose env18023 (packedSelected [3,7,8,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound18023 : packedSelected [3,7,8,9,10,14] rootPS < 2^1333 := by decide +kernel

def env18024 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2577,8192,16384,28309,8203,16400,10400,1024,28308,2561,28340,28293,8583,8328,17,18329,24980,11157,10400,1421,168,256,20273,16385,513]

theorem envBound18024 : H12AffineFastState.Bounded env18024 := by
  intro p hp
  have h : env18024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18023_18024 : H12AffineEnvironment.transform 11 2577 env18023 = env18024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env18023 == env18024) = true)

theorem identity18024 : scanCanonicalize (H12AffineFastState.compose env18024 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 3993) := by decide +kernel

theorem selectedBound18024 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env18025 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2577,8192,3993,8460,8203,3977,10400,1024,8461,2561,8493,8476,8583,8328,17,2048,11789,11157,10400,1421,168,256,168,3992,513]

theorem envBound18025 : H12AffineFastState.Bounded env18025 := by
  intro p hp
  have h : env18025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18024_18025 : H12AffineEnvironment.transform 13 3993 env18024 = env18025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3993 env18024 == env18025) = true)

theorem identity18025 : scanCanonicalize (H12AffineFastState.compose env18025 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound18025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18026 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2577,268,3993,0,263,3977,2476,1024,1,2561,33,16,139,388,17,2048,3841,2713,2476,1421,168,256,168,3992,513]

theorem envBound18026 : H12AffineFastState.Bounded env18026 := by
  intro p hp
  have h : env18026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18025_18026 : H12AffineEnvironment.transform 12 268 env18025 = env18026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env18025 == env18026) = true)

theorem identity18026 : scanCanonicalize (H12AffineFastState.compose env18026 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound18026 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env18027 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1076,1573,268,941,0,263,957,1432,1024,1,1589,33,16,139,388,17,1076,821,1709,1432,1421,168,256,168,940,513]

theorem envBound18027 : H12AffineFastState.Bounded env18027 := by
  intro p hp
  have h : env18027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18026_18027 : H12AffineEnvironment.transform 10 1076 env18026 = env18027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env18026 == env18027) = true)

theorem identity18027 : scanCanonicalize (H12AffineFastState.compose env18027 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound18027 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18028 : List Nat := [2,4,8,16,32,16,128,256,512,769,821,292,268,941,0,263,957,665,769,1,308,33,16,139,388,17,821,821,428,665,652,168,256,168,940,513]

theorem envBound18028 : H12AffineFastState.Bounded env18028 := by
  intro p hp
  have h : env18028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18027_18028 : H12AffineEnvironment.transform 9 769 env18027 = env18028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env18027 == env18028) = true)

theorem identity18028 : scanCanonicalize (H12AffineFastState.compose env18028 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18028 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18029 : List Nat := [2,4,8,16,32,16,128,37,512,548,528,1,41,648,0,34,664,665,548,1,17,33,16,139,161,17,528,528,137,665,652,168,37,168,649,513]

theorem envBound18029 : H12AffineFastState.Bounded env18029 := by
  intro p hp
  have h : env18029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18028_18029 : H12AffineEnvironment.transform 7 37 env18028 = env18029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18028 == env18029) = true)

theorem identity18029 : scanCanonicalize (H12AffineFastState.compose env18029 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound18029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18030 : List Nat := [2,4,8,16,32,16,128,37,33,5,49,1,41,169,0,34,185,184,5,1,17,33,16,139,161,17,49,49,137,184,173,168,37,168,168,32]

theorem envBound18030 : H12AffineFastState.Bounded env18030 := by
  intro p hp
  have h : env18030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18029_18030 : H12AffineEnvironment.transform 8 33 env18029 = env18030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env18029 == env18030) = true)

theorem identity18030 : scanCanonicalize (H12AffineFastState.compose env18030 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18030 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env18031 : List Nat := [2,4,8,16,1,16,128,4,0,5,16,1,8,136,0,3,152,153,5,1,17,0,16,139,128,17,16,16,137,153,140,137,4,137,137,1]

theorem envBound18031 : H12AffineFastState.Bounded env18031 := by
  intro p hp
  have h : env18031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18030_18031 : H12AffineEnvironment.transform 4 1 env18030 = env18031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18030 == env18031) = true)

theorem identity18031 : scanCanonicalize (H12AffineFastState.compose env18031 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound18031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18032 : List Nat := [2,4,8,16,1,16,25,4,0,5,16,1,8,17,0,3,1,0,5,1,17,0,16,18,25,17,16,16,16,0,21,16,4,16,16,1]

theorem envBound18032 : H12AffineFastState.Bounded env18032 := by
  intro p hp
  have h : env18032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18031_18032 : H12AffineEnvironment.transform 6 25 env18031 = env18032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env18031 == env18032) = true)

theorem identity18032 : scanCanonicalize (H12AffineFastState.compose env18032 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound18032 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18033 : List Nat := [2,4,8,1,1,1,8,4,0,5,1,1,8,0,0,3,1,0,5,1,0,0,1,3,8,0,1,1,1,0,4,1,4,1,1,1]

theorem envBound18033 : H12AffineFastState.Bounded env18033 := by
  intro p hp
  have h : env18033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18032_18033 : H12AffineEnvironment.transform 3 1 env18032 = env18033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env18032 == env18033) = true)

def env18034 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4113,32801,285749,327075,8328,16,295341,280885,268581,56357,1420,272392,256,21792,46213,513]

theorem envBound18034 : H12AffineFastState.Bounded env18034 := by
  intro p hp
  have h : env18034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18020_18034 : H12AffineEnvironment.transform 5 17 env18020 = env18034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18020 == env18034) = true)

theorem identity18034 : scanCanonicalize (H12AffineFastState.compose env18034 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound18034 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env18035 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8203,16400,262144,1024,8581,4113,8613,285749,285735,8328,16,270377,280885,268581,32161,1420,272392,256,21792,5377,513]

theorem envBound18035 : H12AffineFastState.Bounded env18035 := by
  intro p hp
  have h : env18035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18034_18035 : H12AffineEnvironment.transform 14 8580 env18034 = env18035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env18034 == env18035) = true)

theorem identity18035 : scanCanonicalize (H12AffineFastState.compose env18035 (packedSelected [1,4,5,8,9,14,17,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound18035 : packedSelected [1,4,5,8,9,14,17,20,24] rootPS < 2^1333 := by decide +kernel

def env18036 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8203,16400,10280,1024,8581,4113,8613,29725,29711,8328,16,2049,24861,12557,32161,1420,32,256,21792,5377,513]

theorem envBound18036 : H12AffineFastState.Bounded env18036 := by
  intro p hp
  have h : env18036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18035_18036 : H12AffineEnvironment.transform 17 10280 env18035 = env18036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18035 == env18036) = true)

theorem identity18036 : scanCanonicalize (H12AffineFastState.compose env18036 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound18036 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env18037 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13608,8580,8203,13624,10280,1024,8581,4113,8613,309,295,8328,16,2049,5173,12557,2185,1420,32,256,8200,5377,513]

theorem envBound18037 : H12AffineFastState.Bounded env18037 := by
  intro p hp
  have h : env18037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18036_18037 : H12AffineEnvironment.transform 13 13608 env18036 = env18037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env18036 == env18037) = true)

theorem identity18037 : scanCanonicalize (H12AffineFastState.compose env18037 (packedSelected [2,6,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound18037 : packedSelected [2,6,12,15,17] rootPS < 2^1333 := by decide +kernel

def env18038 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1337,4113,1213,1330,4097,3345,1024,1212,4113,1180,309,295,1457,16,2049,5173,5172,2185,1420,32,256,1329,5377,513]

theorem envBound18038 : H12AffineFastState.Bounded env18038 := by
  intro p hp
  have h : env18038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18037_18038 : H12AffineEnvironment.transform 12 1337 env18037 = env18038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env18037 == env18038) = true)

theorem identity18038 : scanCanonicalize (H12AffineFastState.compose env18038 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18038 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env18039 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1053,4113,1213,1046,4097,3125,1024,1212,4113,1180,17,3,1173,16,2049,5173,5172,2185,1192,32,36,1045,5157,513]

theorem envBound18039 : H12AffineFastState.Bounded env18039 := by
  intro p hp
  have h : env18039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18038_18039 : H12AffineEnvironment.transform 7 36 env18038 = env18039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18038 == env18039) = true)

theorem identity18039 : scanCanonicalize (H12AffineFastState.compose env18039 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1725) := by decide +kernel

theorem selectedBound18039 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18040 : List Nat := [2,4,8,16,32,17,128,36,512,1024,1725,4096,1053,4113,1213,1046,4097,648,1024,1212,4113,1180,17,3,1173,16,1724,5173,5172,1588,1192,32,36,1045,5157,513]

theorem envBound18040 : H12AffineFastState.Bounded env18040 := by
  intro p hp
  have h : env18040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18039_18040 : H12AffineEnvironment.transform 10 1725 env18039 = env18040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1725 env18039 == env18040) = true)

theorem identity18040 : scanCanonicalize (H12AffineFastState.compose env18040 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound18040 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18041 : List Nat := [2,4,8,16,32,17,128,36,512,173,528,4096,176,4113,16,187,4097,648,173,17,4113,49,17,3,56,16,529,4248,4249,665,5,32,36,184,4232,513]

theorem envBound18041 : H12AffineFastState.Bounded env18041 := by
  intro p hp
  have h : env18041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18040_18041 : H12AffineEnvironment.transform 9 173 env18040 = env18041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env18040 == env18041) = true)

theorem identity18041 : scanCanonicalize (H12AffineFastState.compose env18041 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18041 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env18042 : List Nat := [2,4,8,16,32,17,9,36,512,36,528,4096,57,4113,16,50,4097,513,36,17,4113,49,17,3,56,16,529,4113,4112,528,5,32,36,49,4097,513]

theorem envBound18042 : H12AffineFastState.Bounded env18042 := by
  intro p hp
  have h : env18042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18041_18042 : H12AffineEnvironment.transform 6 9 env18041 = env18042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18041 == env18042) = true)

def env18043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4160,32800,285797,327074,8328,65,295420,280933,268661,56436,1501,272392,256,21792,46213,513]

theorem envBound18043 : H12AffineFastState.Bounded env18043 := by
  intro p hp
  have h : env18043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18019_18043 : H12AffineEnvironment.transform 16 16401 env18019 = env18043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env18019 == env18043) = true)

theorem identity18043 : scanCanonicalize (H12AffineFastState.compose env18043 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound18043 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env18044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,23669,1024,32769,4160,32800,16,41431,8328,65,56713,5392,17664,56436,1501,29821,256,21792,46213,513]

theorem envBound18044 : H12AffineFastState.Bounded env18044 := by
  intro p hp
  have h : env18044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18043_18044 : H12AffineEnvironment.transform 17 23669 env18043 = env18044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env18043 == env18044) = true)

theorem identity18044 : scanCanonicalize (H12AffineFastState.compose env18044 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound18044 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env18045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8203,16401,23669,1024,136,4160,169,16,8542,8328,65,23808,5392,17664,23805,1501,29821,256,21792,13324,513]

theorem envBound18045 : H12AffineFastState.Bounded env18045 := by
  intro p hp
  have h : env18045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18044_18045 : H12AffineEnvironment.transform 14 137 env18044 = env18045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env18044 == env18045) = true)

theorem identity18045 : scanCanonicalize (H12AffineFastState.compose env18045 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound18045 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env18046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,479,16401,23669,1024,136,4160,169,16,138,348,65,23808,5392,17664,23805,1501,21929,256,21792,5592,513]

theorem envBound18046 : H12AffineFastState.Bounded env18046 := by
  intro p hp
  have h : env18046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18045_18046 : H12AffineEnvironment.transform 12 468 env18045 = env18046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env18045 == env18046) = true)

theorem identity18046 : scanCanonicalize (H12AffineFastState.compose env18046 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound18046 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,479,5529,2557,1024,136,4160,169,16,138,348,65,2184,5392,4232,2421,1501,33,256,168,5592,513]

theorem envBound18047 : H12AffineFastState.Bounded env18047 := by
  intro p hp
  have h : env18047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18046_18047 : H12AffineEnvironment.transform 13 5512 env18046 = env18047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env18046 == env18047) = true)

theorem identity18047 : scanCanonicalize (H12AffineFastState.compose env18047 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound18047 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env18048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1125,468,493,137,479,508,2557,1024,136,1061,169,16,138,348,65,2184,373,1261,2421,1501,33,256,168,445,513]

theorem envBound18048 : H12AffineFastState.Bounded env18048 := by
  intro p hp
  have h : env18048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18047_18048 : H12AffineEnvironment.transform 11 1125 env18047 = env18048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env18047 == env18048) = true)

theorem identity18048 : scanCanonicalize (H12AffineFastState.compose env18048 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound18048 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env18049 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1125,41,16,137,34,1,2048,1024,136,1061,169,16,138,161,65,2184,136,1261,2184,1056,33,253,168,64,513]

theorem envBound18049 : H12AffineFastState.Bounded env18049 := by
  intro p hp
  have h : env18049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18048_18049 : H12AffineEnvironment.transform 7 253 env18048 = env18049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env18048 == env18049) = true)

theorem identity18049 : scanCanonicalize (H12AffineFastState.compose env18049 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18049 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18050 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,1125,41,16,1,34,1,2048,1024,0,1061,33,16,2,41,65,2048,0,1125,2048,1056,33,117,32,64,513]

theorem envBound18050 : H12AffineFastState.Bounded env18050 := by
  intro p hp
  have h : env18050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18049_18050 : H12AffineEnvironment.transform 6 8 env18049 = env18050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18049 == env18050) = true)

theorem identity18050 : scanCanonicalize (H12AffineFastState.compose env18050 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound18050 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18051 : List Nat := [2,4,8,16,32,64,8,117,512,1024,10,1125,41,16,1,34,1,10,1024,0,1061,33,16,2,41,65,10,0,1125,10,1056,33,117,32,64,513]

theorem envBound18051 : H12AffineFastState.Bounded env18051 := by
  intro p hp
  have h : env18051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18050_18051 : H12AffineEnvironment.transform 10 10 env18050 = env18051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env18050 == env18051) = true)

theorem identity18051 : scanCanonicalize (H12AffineFastState.compose env18051 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound18051 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env18052 : List Nat := [2,4,2,16,32,64,2,117,512,1024,0,1125,35,16,1,34,1,0,1024,0,1061,33,16,2,35,65,0,0,1125,0,1056,33,117,32,64,513]

theorem envBound18052 : H12AffineFastState.Bounded env18052 := by
  intro p hp
  have h : env18052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18051_18052 : H12AffineEnvironment.transform 2 2 env18051 = env18052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env18051 == env18052) = true)

theorem identity18052 : scanCanonicalize (H12AffineFastState.compose env18052 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound18052 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env18053 : List Nat := [2,4,2,16,32,49,2,4,512,1024,0,1044,35,16,1,34,1,0,1024,0,1061,33,16,2,35,48,0,0,1044,0,1056,33,4,32,49,513]

theorem envBound18053 : H12AffineFastState.Bounded env18053 := by
  intro p hp
  have h : env18053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18052_18053 : H12AffineEnvironment.transform 5 49 env18052 = env18053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env18052 == env18053) = true)

theorem identity18053 : scanCanonicalize (H12AffineFastState.compose env18053 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound18053 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env18054 : List Nat := [2,4,2,16,16,1,2,4,512,1024,0,1044,19,16,1,18,1,0,1024,0,1045,17,16,2,19,0,0,0,1044,0,1040,17,4,16,1,513]

theorem envBound18054 : H12AffineFastState.Bounded env18054 := by
  intro p hp
  have h : env18054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18053_18054 : H12AffineEnvironment.transform 4 16 env18053 = env18054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env18053 == env18054) = true)

theorem identity18054 : scanCanonicalize (H12AffineFastState.compose env18054 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound18054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18055 : List Nat := [2,1,2,16,16,1,2,1,512,1024,0,1041,19,16,1,18,1,0,1024,0,1040,17,16,2,19,0,0,0,1041,0,1040,17,1,16,1,513]

theorem envBound18055 : H12AffineFastState.Bounded env18055 := by
  intro p hp
  have h : env18055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18054_18055 : H12AffineEnvironment.transform 1 1 env18054 = env18055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env18054 == env18055) = true)

theorem identity18055 : scanCanonicalize (H12AffineFastState.compose env18055 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound18055 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18056 : List Nat := [2,1,2,16,16,1,2,1,512,17,0,0,19,16,1,18,1,0,17,0,1,17,16,2,19,0,0,0,0,0,1,17,1,16,1,513]

theorem envBound18056 : H12AffineFastState.Bounded env18056 := by
  intro p hp
  have h : env18056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18055_18056 : H12AffineEnvironment.transform 9 17 env18055 = env18056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env18055 == env18056) = true)

theorem identity18056 : scanCanonicalize (H12AffineFastState.compose env18056 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound18056 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18057 : List Nat := [2,1,2,16,16,1,2,1,2,17,0,0,19,16,1,18,1,0,17,0,1,17,16,2,19,0,0,0,0,0,1,17,1,16,1,3]

theorem envBound18057 : H12AffineFastState.Bounded env18057 := by
  intro p hp
  have h : env18057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18056_18057 : H12AffineEnvironment.transform 8 2 env18056 = env18057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env18056 == env18057) = true)

def env18058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400501,499128,8328,65,295421,395637,416100,56437,1500,272393,256,21792,46213,74251]

theorem envBound18058 : H12AffineFastState.Bounded env18058 := by
  intro p hp
  have h : env18058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18017_18058 : H12AffineEnvironment.transform 20 4161 env18017 = env18058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18017 == env18058) = true)

theorem identity18058 : scanCanonicalize (H12AffineFastState.compose env18058 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound18058 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,180273,120015,21762,8328,65,215367,115151,102878,56437,1500,254131,256,21792,46213,74251]

theorem envBound18059 : H12AffineFastState.Bounded env18059 := by
  intro p hp
  have h : env18059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18058_18059 : H12AffineEnvironment.transform 17 247994 env18058 = env18059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env18058 == env18059) = true)

def env18060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130174,1024,32769,4161,62709,120015,21762,8328,65,97667,115151,102878,56437,1500,119927,256,21792,46213,74251]

theorem envBound18060 : H12AffineFastState.Bounded env18060 := by
  intro p hp
  have h : env18060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18059_18060 : H12AffineEnvironment.transform 16 13508 env18059 = env18060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env18059 == env18060) = true)

def env18061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4161,62589,119879,21762,8192,65,97547,115015,102742,56437,1364,119927,256,21792,46093,74251]

theorem envBound18061 : H12AffineFastState.Bounded env18061 := by
  intro p hp
  have h : env18061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18060_18061 : H12AffineEnvironment.transform 6 8 env18060 = env18061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18060 == env18061) = true)

theorem identity18061 : scanCanonicalize (H12AffineFastState.compose env18061 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18061 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13388,108926,1024,32769,4161,41341,98631,2,8192,65,75787,103495,102742,35189,1364,98679,256,32,46093,74251]

theorem envBound18062 : H12AffineFastState.Bounded env18062 := by
  intro p hp
  have h : env18062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18061_18062 : H12AffineEnvironment.transform 13 5376 env18061 = env18062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18061 == env18062) = true)

theorem identity18062 : scanCanonicalize (H12AffineFastState.compose env18062 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound18062 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env18063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,41051,13388,2341,1024,32769,4161,41341,8476,2,8192,65,34896,13340,12557,35189,1364,8492,256,32,46093,33360]

theorem envBound18063 : H12AffineFastState.Bounded env18063 := by
  intro p hp
  have h : env18063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18062_18063 : H12AffineEnvironment.transform 15 41051 env18062 = env18063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env18062 == env18063) = true)

theorem identity18063 : scanCanonicalize (H12AffineFastState.compose env18063 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound18063 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env18064 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,32768,41051,13388,2129,1024,32769,4161,40969,8296,2,8192,65,34896,13340,12409,34817,1056,8280,116,32,46093,33360]

theorem envBound18064 : H12AffineFastState.Bounded env18064 := by
  intro p hp
  have h : env18064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18063_18064 : H12AffineEnvironment.transform 7 116 env18063 = env18064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env18063 == env18064) = true)

theorem identity18064 : scanCanonicalize (H12AffineFastState.compose env18064 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound18064 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env18065 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,8312,35,13388,2129,1024,8313,4161,113,8296,2,8192,65,10280,13340,12409,10361,1056,8280,116,32,5237,8744]

theorem envBound18065 : H12AffineFastState.Bounded env18065 := by
  intro p hp
  have h : env18065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18064_18065 : H12AffineEnvironment.transform 14 8312 env18064 = env18065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env18064 == env18065) = true)

theorem identity18065 : scanCanonicalize (H12AffineFastState.compose env18065 (packedSelected [2,3,4,5,6,7,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound18065 : packedSelected [2,3,4,5,6,7,10,14] rootPS < 2^1333 := by decide +kernel

def env18066 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,6200,5236,6208,35,3188,2129,1024,6209,4161,113,6224,2,6200,65,4112,3108,2113,4161,1056,6240,116,32,5237,6672]

theorem envBound18066 : H12AffineFastState.Bounded env18066 := by
  intro p hp
  have h : env18066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18065_18066 : H12AffineEnvironment.transform 12 6200 env18065 = env18066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env18065 == env18066) = true)

theorem identity18066 : scanCanonicalize (H12AffineFastState.compose env18066 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18066 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env18067 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,6200,5156,6160,35,3108,2049,1024,6161,4113,33,6144,2,6200,17,4112,3108,2065,4113,1056,6192,36,32,5157,6672]

theorem envBound18067 : H12AffineFastState.Bounded env18067 := by
  intro p hp
  have h : env18067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18066_18067 : H12AffineEnvironment.transform 5 16 env18066 = env18067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18066 == env18067) = true)

theorem identity18067 : scanCanonicalize (H12AffineFastState.compose env18067 (packedSelected [4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound18067 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env18068 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,41,3125,1,35,3108,2049,1024,0,2048,33,17,2,41,17,2049,3108,2065,2048,1056,33,36,32,3124,513]

theorem envBound18068 : H12AffineFastState.Bounded env18068 := by
  intro p hp
  have h : env18068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18067_18068 : H12AffineEnvironment.transform 11 2065 env18067 = env18068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env18067 == env18068) = true)

theorem identity18068 : scanCanonicalize (H12AffineFastState.compose env18068 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound18068 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18069 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2048,1,35,2065,2049,53,0,2048,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2049,513]

theorem envBound18069 : H12AffineFastState.Bounded env18069 := by
  intro p hp
  have h : env18069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18068_18069 : H12AffineEnvironment.transform 9 53 env18068 = env18069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env18068 == env18069) = true)

theorem identity18069 : scanCanonicalize (H12AffineFastState.compose env18069 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound18069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18070 : List Nat := [2,4,8,16,32,16,8,36,27,53,2048,2065,41,2048,1,35,2065,2049,53,0,2048,33,17,2,41,17,2049,2065,2065,2048,21,33,36,32,2049,26]

theorem envBound18070 : H12AffineFastState.Bounded env18070 := by
  intro p hp
  have h : env18070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18069_18070 : H12AffineEnvironment.transform 8 27 env18069 = env18070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env18069 == env18070) = true)

def env18071 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4161,62588,119878,21762,8193,65,97546,115014,102743,56437,1365,119927,256,21792,46092,74251]

theorem envBound18071 : H12AffineFastState.Bounded env18071 := by
  intro p hp
  have h : env18071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18060_18071 : H12AffineEnvironment.transform 6 9 env18060 = env18071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18060 == env18071) = true)

theorem identity18071 : scanCanonicalize (H12AffineFastState.compose env18071 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound18071 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18072 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,67619,1024,29788,4161,33,73755,21762,8193,65,97546,79131,91402,10280,1365,73770,256,21792,16465,74251]

theorem envBound18072 : H12AffineFastState.Bounded env18072 := by
  intro p hp
  have h : env18072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18071_18072 : H12AffineEnvironment.transform 14 29789 env18071 = env18072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env18071 == env18072) = true)

theorem identity18072 : scanCanonicalize (H12AffineFastState.compose env18072 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound18072 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env18073 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29963,13389,32040,1024,29788,4161,33,21776,21762,8193,65,2049,16400,4097,10280,1365,21793,256,21792,16465,22272]

theorem envBound18073 : H12AffineFastState.Bounded env18073 := by
  intro p hp
  have h : env18073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18072_18073 : H12AffineEnvironment.transform 15 29963 env18072 = env18073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env18072 == env18073) = true)

def env18074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130175,1024,32769,4161,62708,120015,21762,8328,65,97666,115151,102878,56437,1500,119926,256,21792,46213,74251]

theorem envBound18074 : H12AffineFastState.Bounded env18074 := by
  intro p hp
  have h : env18074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18059_18074 : H12AffineEnvironment.transform 16 13509 env18059 = env18074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env18059 == env18074) = true)

def env18075 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4161,62588,119879,21762,8192,65,97546,115015,102742,56437,1364,119926,256,21792,46093,74251]

theorem envBound18075 : H12AffineFastState.Bounded env18075 := by
  intro p hp
  have h : env18075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18074_18075 : H12AffineEnvironment.transform 6 8 env18074 = env18075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18074 == env18075) = true)

theorem identity18075 : scanCanonicalize (H12AffineFastState.compose env18075 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound18075 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18076 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,13389,32041,1024,32769,4161,62588,21777,21762,8192,65,64604,16401,4096,56437,1364,21792,256,21792,46093,41821]

theorem envBound18076 : H12AffineFastState.Bounded env18076 := by
  intro p hp
  have h : env18076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18075_18076 : H12AffineEnvironment.transform 15 33110 env18075 = env18076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env18075 == env18076) = true)

theorem identity18076 : scanCanonicalize (H12AffineFastState.compose env18076 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound18076 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env18077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,32768,33110,13389,2048,1024,32769,4161,33109,8248,8235,8192,65,35189,13624,4096,43356,1364,8201,256,8201,46093,41821]

theorem envBound18077 : H12AffineFastState.Bounded env18077 := by
  intro p hp
  have h : env18077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18076_18077 : H12AffineEnvironment.transform 13 13609 env18076 = env18077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env18076 == env18077) = true)

theorem identity18077 : scanCanonicalize (H12AffineFastState.compose env18077 (packedSelected [0,3,4,5,6,7,9,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound18077 : packedSelected [0,3,4,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env18078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,2049,2391,13389,2048,1024,2048,4161,2388,8248,8235,8192,65,372,13624,4096,8541,1364,8201,256,8201,15372,11100]

theorem envBound18078 : H12AffineFastState.Bounded env18078 := by
  intro p hp
  have h : env18078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18077_18078 : H12AffineEnvironment.transform 14 2049 env18077 = env18078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env18077 == env18078) = true)

theorem identity18078 : scanCanonicalize (H12AffineFastState.compose env18078 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound18078 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env18079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2088,7425,2049,2391,7269,2048,1024,2048,4161,2388,2064,2051,2088,65,372,7440,4096,2421,1364,2081,256,2081,5156,884]

theorem envBound18079 : H12AffineFastState.Bounded env18079 := by
  intro p hp
  have h : env18079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18078_18079 : H12AffineEnvironment.transform 12 2088 env18078 = env18079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env18078 == env18079) = true)

def env18080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4161,62589,119878,21762,8193,65,97547,115014,102743,56437,1365,119926,256,21792,46092,74251]

theorem envBound18080 : H12AffineFastState.Bounded env18080 := by
  intro p hp
  have h : env18080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18074_18080 : H12AffineEnvironment.transform 6 9 env18074 = env18080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18074 == env18080) = true)

theorem identity18080 : scanCanonicalize (H12AffineFastState.compose env18080 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18080 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13388,56437,1024,32769,4161,62589,62540,21762,8193,65,23809,57676,45405,56437,1365,62588,256,21792,46092,513]

theorem envBound18081 : H12AffineFastState.Bounded env18081 := by
  intro p hp
  have h : env18081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18080_18081 : H12AffineEnvironment.transform 15 8202 env18080 = env18081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18080 == env18081) = true)

theorem identity18081 : scanCanonicalize (H12AffineFastState.compose env18081 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound18081 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env18082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,8202,13388,2341,1024,21841,4161,8493,8476,21762,8193,65,23809,13340,25613,2341,1365,8492,256,21792,24924,513]

theorem envBound18082 : H12AffineFastState.Bounded env18082 := by
  intro p hp
  have h : env18082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18081_18082 : H12AffineEnvironment.transform 14 21840 env18081 = env18082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env18081 == env18082) = true)

theorem identity18082 : scanCanonicalize (H12AffineFastState.compose env18082 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18082 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env18083 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,8202,13340,2341,1024,21761,4113,8493,8476,21762,8193,17,23809,13340,25613,2341,1285,8492,256,21792,24844,513]

theorem envBound18083 : H12AffineFastState.Bounded env18083 := by
  intro p hp
  have h : env18083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18082_18083 : H12AffineEnvironment.transform 5 16 env18082 = env18083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18082 == env18083) = true)

theorem identity18083 : scanCanonicalize (H12AffineFastState.compose env18083 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound18083 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18084 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,8202,13340,2341,1024,1,4113,8493,8476,2,8193,17,2049,13340,12557,2341,1285,8492,256,32,13324,513]

theorem envBound18084 : H12AffineFastState.Bounded env18084 := by
  intro p hp
  have h : env18084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18083_18084 : H12AffineEnvironment.transform 13 5376 env18083 = env18084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env18083 == env18084) = true)

theorem identity18084 : scanCanonicalize (H12AffineFastState.compose env18084 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18085 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,8192,4112,0,8202,12556,2341,272,1,4113,8493,8476,2,8193,17,2049,12556,12557,2341,21,8492,256,32,12572,513]

theorem envBound18085 : H12AffineFastState.Bounded env18085 := by
  intro p hp
  have h : env18085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18084_18085 : H12AffineEnvironment.transform 9 272 env18084 = env18085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18084 == env18085) = true)

theorem identity18085 : scanCanonicalize (H12AffineFastState.compose env18085 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound18085 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18086 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,4096,8192,4112,0,8202,12556,293,272,1,4113,8493,8476,2,8193,17,1,12556,12557,293,21,8492,256,32,12572,513]

theorem envBound18086 : H12AffineFastState.Bounded env18086 := by
  intro p hp
  have h : env18086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18085_18086 : H12AffineEnvironment.transform 10 0 env18085 = env18086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18085 == env18086) = true)

theorem identity18086 : scanCanonicalize (H12AffineFastState.compose env18086 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound18086 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env18087 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,17,8192,1,0,8202,8477,293,272,1,0,8493,8476,2,8193,17,1,8477,8476,293,21,8492,256,32,8461,513]

theorem envBound18087 : H12AffineFastState.Bounded env18087 := by
  intro p hp
  have h : env18087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18086_18087 : H12AffineEnvironment.transform 11 17 env18086 = env18087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env18086 == env18087) = true)

theorem identity18087 : scanCanonicalize (H12AffineFastState.compose env18087 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound18087 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env18088 : List Nat := [2,4,8,16,32,16,9,256,512,272,0,17,40,1,0,34,309,293,272,1,0,261,308,2,41,17,1,309,308,293,21,260,256,32,293,513]

theorem envBound18088 : H12AffineFastState.Bounded env18088 := by
  intro p hp
  have h : env18088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18087_18088 : H12AffineEnvironment.transform 12 40 env18087 = env18088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18087 == env18088) = true)

def env18089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493492,499129,8328,65,6705548,2496821,416100,2149428,2102684,6748280,256,21793,46212,2175563]

theorem envBound18089 : H12AffineFastState.Bounded env18089 := by
  intro p hp
  have h : env18089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17965_18089 : H12AffineEnvironment.transform 23 499129 env17965 = env18089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env17965 == env18089) = true)

def env18090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493492,499129,8328,65,2396604,2496821,416100,2149428,2102684,2373704,256,21793,46212,2175563]

theorem envBound18090 : H12AffineFastState.Bounded env18090 := by
  intro p hp
  have h : env18090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18089_18090 : H12AffineEnvironment.transform 21 180272 env18089 = env18090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env18089 == env18090) = true)

def env18091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400500,499129,8328,65,295420,395637,416100,56436,1500,272392,256,21793,46212,74251]

theorem envBound18091 : H12AffineFastState.Bounded env18091 := by
  intro p hp
  have h : env18091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18090_18091 : H12AffineEnvironment.transform 20 4160 env18090 = env18091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18090 == env18091) = true)

theorem identity18091 : scanCanonicalize (H12AffineFastState.compose env18091 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound18091 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,144612,400500,485741,8328,65,292136,395637,416100,10400,1500,272392,256,21793,16464,74251]

theorem envBound18092 : H12AffineFastState.Bounded env18092 := by
  intro p hp
  have h : env18092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18091_18092 : H12AffineEnvironment.transform 14 29908 env18091 = env18092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env18091 == env18092) = true)

def env18093 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144492,400500,485741,8192,65,292136,395637,416100,10280,1364,272392,256,21793,16464,74251]

theorem envBound18093 : H12AffineFastState.Bounded env18093 := by
  intro p hp
  have h : env18093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18092_18093 : H12AffineEnvironment.transform 6 8 env18092 = env18093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18092 == env18093) = true)

theorem identity18093 : scanCanonicalize (H12AffineFastState.compose env18093 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 215091) := by decide +kernel

theorem selectedBound18093 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env18094 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,215091,1024,29789,4160,144492,87111,8542,8192,65,212251,82246,69975,10280,1364,221243,256,21793,16464,74251]

theorem envBound18094 : H12AffineFastState.Bounded env18094 := by
  intro p hp
  have h : env18094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18093_18094 : H12AffineEnvironment.transform 17 215091 env18093 = env18094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215091 env18093 == env18094) = true)

theorem identity18094 : scanCanonicalize (H12AffineFastState.compose env18094 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound18094 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env18095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1024,29789,4160,87159,87111,8542,8192,65,23808,82246,69975,10280,1364,32,256,21793,16464,74251]

theorem envBound18095 : H12AffineFastState.Bounded env18095 := by
  intro p hp
  have h : env18095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18094_18095 : H12AffineEnvironment.transform 16 90139 env18094 = env18095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env18094 == env18095) = true)

theorem identity18095 : scanCanonicalize (H12AffineFastState.compose env18095 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound18095 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5393,10280,1024,29789,4160,8573,8525,8542,8192,65,23808,13388,25693,10280,1364,32,256,21793,16464,22273]

theorem envBound18096 : H12AffineFastState.Bounded env18096 := by
  intro p hp
  have h : env18096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18095_18096 : H12AffineEnvironment.transform 15 29962 env18095 = env18096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env18095 == env18096) = true)

theorem identity18096 : scanCanonicalize (H12AffineFastState.compose env18096 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound18096 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4113,9293,9499,5393,10280,1024,9292,4160,8573,8525,8542,8192,65,3345,13388,13388,10280,1364,32,256,1328,4161,1808]

theorem envBound18097 : H12AffineFastState.Bounded env18097 := by
  intro p hp
  have h : env18097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18096_18097 : H12AffineEnvironment.transform 13 4113 env18096 = env18097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env18096 == env18097) = true)

theorem identity18097 : scanCanonicalize (H12AffineFastState.compose env18097 (packedSelected [0,1,3,5,7,8,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound18097 : packedSelected [0,1,3,5,7,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env18098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4113,81,263,5393,3124,1024,80,4160,1377,1361,1346,1052,65,3345,4176,4176,3124,1364,32,256,1328,4161,1808]

theorem envBound18098 : H12AffineFastState.Bounded env18098 := by
  intro p hp
  have h : env18098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18097_18098 : H12AffineEnvironment.transform 12 1052 env18097 = env18098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env18097 == env18098) = true)

def env18099 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,400500,485741,8193,65,292136,395637,416100,10281,1365,272392,256,21793,16464,74251]

theorem envBound18099 : H12AffineFastState.Bounded env18099 := by
  intro p hp
  have h : env18099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18092_18099 : H12AffineEnvironment.transform 6 9 env18092 = env18099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18092 == env18099) = true)

theorem identity18099 : scanCanonicalize (H12AffineFastState.compose env18099 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound18099 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env18100 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5440,262144,1024,29788,4160,8493,264500,359469,8193,65,292136,269365,281636,10281,1365,272392,256,21793,16464,74251]

theorem envBound18100 : H12AffineFastState.Bounded env18100 := by
  intro p hp
  have h : env18100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18099_18100 : H12AffineEnvironment.transform 16 5440 env18099 = env18100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env18099 == env18100) = true)

theorem identity18100 : scanCanonicalize (H12AffineFastState.compose env18100 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound18100 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env18101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,5440,262144,1024,29788,4160,8493,264500,272507,8193,65,292136,269365,281636,10281,1365,272392,256,21793,16464,30301]

theorem envBound18101 : H12AffineFastState.Bounded env18101 := by
  intro p hp
  have h : env18101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18100_18101 : H12AffineEnvironment.transform 15 21590 env18100 = env18101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env18100 == env18101) = true)

theorem identity18101 : scanCanonicalize (H12AffineFastState.compose env18101 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound18101 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env18102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,5440,10360,1024,29788,4160,8493,8524,3,8193,65,23888,13389,25692,10281,1365,112,256,21793,16464,30301]

theorem envBound18102 : H12AffineFastState.Bounded env18102 := by
  intro p hp
  have h : env18102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18101_18102 : H12AffineEnvironment.transform 17 10360 env18101 = env18102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env18101 == env18102) = true)

theorem identity18102 : scanCanonicalize (H12AffineFastState.compose env18102 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound18102 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8282,5440,10360,1024,80,4160,8493,8524,3,8193,65,10588,13389,4176,10281,1365,112,256,8493,13404,593]

theorem envBound18103 : H12AffineFastState.Bounded env18103 := by
  intro p hp
  have h : env18103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18102_18103 : H12AffineEnvironment.transform 13 13324 env18102 = env18103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env18102 == env18103) = true)

theorem identity18103 : scanCanonicalize (H12AffineFastState.compose env18103 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound18103 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env18104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,3345,81,6471,5440,4453,1024,80,4160,6192,6225,3,6428,65,4161,3408,4176,4404,1365,112,256,6192,3393,593]

theorem envBound18104 : H12AffineFastState.Bounded env18104 := by
  intro p hp
  have h : env18104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18103_18104 : H12AffineEnvironment.transform 12 6429 env18103 = env18104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env18103 == env18104) = true)

theorem identity18104 : scanCanonicalize (H12AffineFastState.compose env18104 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound18104 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env18105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,5133,1,81,5207,5440,4453,1024,80,4160,5408,5441,3,5132,65,4161,64,4176,4404,1365,112,256,5408,81,593]

theorem envBound18105 : H12AffineFastState.Bounded env18105 := by
  intro p hp
  have h : env18105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18104_18105 : H12AffineEnvironment.transform 10 1296 env18104 = env18105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env18104 == env18105) = true)

theorem identity18105 : scanCanonicalize (H12AffineFastState.compose env18105 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound18105 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env18106 : List Nat := [2,4,8,16,32,64,9,256,512,273,1,4096,4380,1,81,4422,4177,4453,273,80,4160,4145,4176,3,4381,65,4161,64,4176,4404,68,112,256,4145,81,593]

theorem envBound18106 : H12AffineFastState.Bounded env18106 := by
  intro p hp
  have h : env18106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18105_18106 : H12AffineEnvironment.transform 9 273 env18105 = env18106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18105 == env18106) = true)

def env18107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400501,499129,8328,65,295421,395636,416100,56437,1501,272393,256,21793,46212,74250]

theorem envBound18107 : H12AffineFastState.Bounded env18107 := by
  intro p hp
  have h : env18107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18090_18107 : H12AffineEnvironment.transform 20 4161 env18090 = env18107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18090 == env18107) = true)

theorem identity18107 : scanCanonicalize (H12AffineFastState.compose env18107 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound18107 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180272,16,98780,8328,65,171416,5393,17665,56437,1501,144492,256,21793,46212,74250]

theorem envBound18108 : H12AffineFastState.Bounded env18108 := by
  intro p hp
  have h : env18108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18107_18108 : H12AffineEnvironment.transform 17 138341 env18107 = env18108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env18107 == env18108) = true)

def env18109 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180272,16,98644,8192,65,171280,5393,17665,56437,1365,144492,256,21793,46092,74250]

theorem envBound18109 : H12AffineFastState.Bounded env18109 := by
  intro p hp
  have h : env18109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18108_18109 : H12AffineEnvironment.transform 6 8 env18108 = env18109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18108 == env18109) = true)

theorem identity18109 : scanCanonicalize (H12AffineFastState.compose env18109 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound18109 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18110 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,108927,1024,32769,4161,95530,16,98644,8192,65,75786,5393,17665,56437,1365,98678,256,21793,46092,74250]

theorem envBound18110 : H12AffineFastState.Bounded env18110 := by
  intro p hp
  have h : env18110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18109_18110 : H12AffineEnvironment.transform 16 111898 env18109 = env18110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env18109 == env18110) = true)

theorem identity18110 : scanCanonicalize (H12AffineFastState.compose env18110 (packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound18110 : packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env18111 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90139,97406,1024,21760,4161,95530,16,87125,8192,65,75786,5393,17665,2420,1365,87159,256,21793,24845,74250]

theorem envBound18111 : H12AffineFastState.Bounded env18111 := by
  intro p hp
  have h : env18111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18110_18111 : H12AffineEnvironment.transform 14 21761 env18110 = env18111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env18110 == env18111) = true)

theorem identity18111 : scanCanonicalize (H12AffineFastState.compose env18111 (packedSelected [0,4,7,11,16,20,22,32] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound18111 : packedSelected [0,4,7,11,16,20,22,32] rootPS < 2^1333 := by decide +kernel

def env18112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,30042,5441,2340,1024,21760,4161,112,16,8463,8192,65,23888,5393,17665,2420,1365,8493,256,21793,24845,22352]

theorem envBound18112 : H12AffineFastState.Bounded env18112 := by
  intro p hp
  have h : env18112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18111_18112 : H12AffineEnvironment.transform 15 30042 env18111 = env18112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env18111 == env18112) = true)

theorem identity18112 : scanCanonicalize (H12AffineFastState.compose env18112 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound18112 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,21761,21794,5441,2340,1024,21760,4161,112,16,375,120,65,23888,5393,17665,2420,1365,341,256,21793,16757,22352]

theorem envBound18113 : H12AffineFastState.Bounded env18113 := by
  intro p hp
  have h : env18113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18112_18113 : H12AffineEnvironment.transform 12 120 env18112 = env18113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env18112 == env18113) = true)

theorem identity18113 : scanCanonicalize (H12AffineFastState.compose env18113 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound18113 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env18114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5236,373,342,5441,2340,1024,372,4161,112,16,375,120,65,2340,5393,4469,2420,1365,341,256,341,5377,804]

theorem envBound18114 : H12AffineFastState.Bounded env18114 := by
  intro p hp
  have h : env18114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18113_18114 : H12AffineEnvironment.transform 13 5236 env18113 = env18114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env18113 == env18114) = true)

theorem identity18114 : scanCanonicalize (H12AffineFastState.compose env18114 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound18114 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env18115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,120,5236,373,342,5441,1345,1024,372,4161,112,16,375,120,65,1345,5393,4469,1297,1365,341,256,341,5377,804]

theorem envBound18115 : H12AffineFastState.Bounded env18115 := by
  intro p hp
  have h : env18115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18114_18115 : H12AffineEnvironment.transform 10 1125 env18114 = env18115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env18114 == env18115) = true)

theorem identity18115 : scanCanonicalize (H12AffineFastState.compose env18115 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound18115 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env18116 : List Nat := [2,4,8,16,32,64,8,256,512,116,17,4096,120,4096,373,342,4405,309,116,372,4161,112,16,375,120,65,309,4453,4469,357,289,341,256,341,4469,804]

theorem envBound18116 : H12AffineFastState.Bounded env18116 := by
  intro p hp
  have h : env18116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18115_18116 : H12AffineEnvironment.transform 9 116 env18115 = env18116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env18115 == env18116) = true)

theorem identity18116 : scanCanonicalize (H12AffineFastState.compose env18116 (packedSelected [0,1,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound18116 : packedSelected [0,1,8,9,10] rootPS < 2^1333 := by decide +kernel

def env18117 : List Nat := [2,4,8,16,32,64,8,256,309,116,17,4096,120,4096,373,342,4405,309,116,372,4161,112,16,375,120,65,309,4453,4469,357,289,341,256,341,4469,17]

theorem envBound18117 : H12AffineFastState.Bounded env18117 := by
  intro p hp
  have h : env18117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18116_18117 : H12AffineEnvironment.transform 8 309 env18116 = env18117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env18116 == env18117) = true)

theorem identity18117 : scanCanonicalize (H12AffineFastState.compose env18117 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound18117 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env18118 : List Nat := [2,4,8,16,32,64,8,256,309,116,17,65,120,65,373,342,372,309,116,372,0,112,16,375,120,65,309,292,308,357,289,341,256,341,308,17]

theorem envBound18118 : H12AffineFastState.Bounded env18118 := by
  intro p hp
  have h : env18118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18117_18118 : H12AffineEnvironment.transform 11 65 env18117 = env18118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env18117 == env18118) = true)

theorem identity18118 : scanCanonicalize (H12AffineFastState.compose env18118 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound18118 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env18119 : List Nat := [2,4,8,16,32,64,8,85,96,116,17,65,120,65,32,3,33,96,116,33,0,112,16,34,120,65,96,113,97,48,116,0,85,0,97,17]

theorem envBound18119 : H12AffineFastState.Bounded env18119 := by
  intro p hp
  have h : env18119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18118_18119 : H12AffineEnvironment.transform 7 85 env18118 = env18119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env18118 == env18119) = true)

theorem identity18119 : scanCanonicalize (H12AffineFastState.compose env18119 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18119 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env18120 : List Nat := [2,4,8,16,32,16,8,5,48,36,17,17,40,17,32,3,33,48,36,33,0,32,16,34,40,17,48,33,49,48,36,0,5,0,49,17]

theorem envBound18120 : H12AffineFastState.Bounded env18120 := by
  intro p hp
  have h : env18120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18119_18120 : H12AffineEnvironment.transform 5 16 env18119 = env18120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18119 == env18120) = true)

theorem identity18120 : scanCanonicalize (H12AffineFastState.compose env18120 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound18120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18121 : List Nat := [2,4,8,0,32,0,8,5,32,36,1,1,40,1,32,3,33,32,36,33,0,32,0,34,40,1,32,33,33,32,36,0,5,0,33,1]

theorem envBound18121 : H12AffineFastState.Bounded env18121 := by
  intro p hp
  have h : env18121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18120_18121 : H12AffineEnvironment.transform 3 0 env18120 = env18121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env18120 == env18121) = true)

def env18122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180272,16,98645,8193,65,171281,5393,17665,56437,1364,144492,256,21793,46093,74250]

theorem envBound18122 : H12AffineFastState.Bounded env18122 := by
  intro p hp
  have h : env18122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18108_18122 : H12AffineEnvironment.transform 6 9 env18108 = env18122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18108 == env18122) = true)

theorem identity18122 : scanCanonicalize (H12AffineFastState.compose env18122 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound18122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67618,1024,32769,4161,119927,16,98645,8193,65,100694,5393,17665,56437,1364,73771,256,21793,46093,74250]

theorem envBound18123 : H12AffineFastState.Bounded env18123 := by
  intro p hp
  have h : env18123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18122_18123 : H12AffineEnvironment.transform 16 70727 env18122 = env18123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env18122 == env18123) = true)

theorem identity18123 : scanCanonicalize (H12AffineFastState.compose env18123 (packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18123 : packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,70727,67618,1024,32769,4161,106539,16,98645,8193,65,100694,5393,12637,43049,1364,73771,256,8573,46093,74250]

theorem envBound18124 : H12AffineFastState.Bounded env18124 := by
  intro p hp
  have h : env18124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18123_18124 : H12AffineEnvironment.transform 13 13404 env18123 = env18124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18123 == env18124) = true)

theorem identity18124 : scanCanonicalize (H12AffineFastState.compose env18124 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18124 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env18125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,65536,70727,67618,1024,32769,4161,98679,16,98645,349,65,100694,5393,4097,35189,1364,65911,256,33,38225,66390]

theorem envBound18125 : H12AffineFastState.Bounded env18125 := by
  intro p hp
  have h : env18125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18124_18125 : H12AffineEnvironment.transform 12 348 env18124 = env18125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18124 == env18125) = true)

theorem identity18125 : scanCanonicalize (H12AffineFastState.compose env18125 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound18125 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env18126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,65536,70727,67618,1024,0,4161,65910,16,65876,349,65,67927,5393,4097,2420,1364,65911,256,33,5456,66390]

theorem envBound18126 : H12AffineFastState.Bounded env18126 := by
  intro p hp
  have h : env18126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18125_18126 : H12AffineEnvironment.transform 14 1 env18125 = env18126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env18125 == env18126) = true)

theorem identity18126 : scanCanonicalize (H12AffineFastState.compose env18126 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound18126 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,375,5424,2389,1024,0,4161,1,16,35,349,65,2080,5393,4097,2420,1364,0,256,33,5456,545]

theorem envBound18127 : H12AffineFastState.Bounded env18127 := by
  intro p hp
  have h : env18127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18126_18127 : H12AffineEnvironment.transform 15 375 env18126 = env18127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env18126 == env18127) = true)

theorem identity18127 : scanCanonicalize (H12AffineFastState.compose env18127 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound18127 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env18128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1093,4096,348,5376,1,375,5424,1296,1024,0,4161,1,16,35,349,65,1125,5393,4097,1329,1364,0,256,33,5456,545]

theorem envBound18128 : H12AffineFastState.Bounded env18128 := by
  intro p hp
  have h : env18128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18127_18128 : H12AffineEnvironment.transform 10 1093 env18127 = env18128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env18127 == env18128) = true)

def env18129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493492,499129,8328,65,2396605,2496821,416100,2149428,2102684,2373705,256,21793,46212,2175563]

theorem envBound18129 : H12AffineFastState.Bounded env18129 := by
  intro p hp
  have h : env18129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18089_18129 : H12AffineEnvironment.transform 21 180273 env18089 = env18129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env18089 == env18129) = true)

def env18130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400500,499129,8328,65,295421,395637,416100,56436,1500,272393,256,21793,46212,74251]

theorem envBound18130 : H12AffineFastState.Bounded env18130 := by
  intro p hp
  have h : env18130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18129_18130 : H12AffineEnvironment.transform 20 4160 env18129 = env18130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env18129 == env18130) = true)

theorem identity18130 : scanCanonicalize (H12AffineFastState.compose env18130 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190640) := by decide +kernel

theorem selectedBound18130 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env18131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,180273,62660,95497,8328,65,158029,57797,45524,56436,1500,180409,256,21793,46212,74251]

theorem envBound18131 : H12AffineFastState.Bounded env18131 := by
  intro p hp
  have h : env18131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18130_18131 : H12AffineEnvironment.transform 17 190640 env18130 = env18131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env18130 == env18131) = true)

theorem identity18131 : scanCanonicalize (H12AffineFastState.compose env18131 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18131 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env18132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190640,1024,32769,4160,180273,62660,21763,8328,65,158029,57797,45524,56436,1500,180409,256,21793,46212,513]

theorem envBound18132 : H12AffineFastState.Bounded env18132 := by
  intro p hp
  have h : env18132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18131_18132 : H12AffineEnvironment.transform 15 8202 env18131 = env18132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18131 == env18132) = true)

theorem identity18132 : scanCanonicalize (H12AffineFastState.compose env18132 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18132 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env18133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,180273,62540,21763,8192,65,158029,57677,45404,56436,1364,180273,256,21793,46092,513]

theorem envBound18133 : H12AffineFastState.Bounded env18133 := by
  intro p hp
  have h : env18133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18132_18133 : H12AffineEnvironment.transform 6 8 env18132 = env18133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18132 == env18133) = true)

theorem identity18133 : scanCanonicalize (H12AffineFastState.compose env18133 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound18133 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env18134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32800,62540,21763,8192,65,10588,57677,45404,56436,1364,32800,256,21793,46092,513]

theorem envBound18134 : H12AffineFastState.Bounded env18134 := by
  intro p hp
  have h : env18134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18133_18134 : H12AffineEnvironment.transform 16 16401 env18133 = env18134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env18133 == env18134) = true)

theorem identity18134 : scanCanonicalize (H12AffineFastState.compose env18134 (packedSelected [0,4,7,9,14,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound18134 : packedSelected [0,4,7,9,14,17,18,23] rootPS < 2^1333 := by decide +kernel

def env18135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9292,8202,16401,3173,1024,9293,4160,9324,20480,21763,8192,65,10588,17665,5392,30776,1364,9324,256,21793,4160,513]

theorem envBound18135 : H12AffineFastState.Bounded env18135 := by
  intro p hp
  have h : env18135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18134_18135 : H12AffineEnvironment.transform 14 9292 env18134 = env18135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env18134 == env18135) = true)

theorem identity18135 : scanCanonicalize (H12AffineFastState.compose env18135 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound18135 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env18136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,9292,8202,13389,3173,1024,9293,4160,9324,9308,8543,8192,65,10588,12637,5392,3172,1364,9324,256,8573,4160,513]

theorem envBound18136 : H12AffineFastState.Bounded env18136 := by
  intro p hp
  have h : env18136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18135_18136 : H12AffineEnvironment.transform 13 13404 env18135 = env18136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env18135 == env18136) = true)

theorem identity18136 : scanCanonicalize (H12AffineFastState.compose env18136 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound18136 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env18137 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,8540,8202,12637,2421,272,8541,4160,8572,8524,8543,8192,65,10588,12637,4096,2420,68,8572,256,8573,4160,513]

theorem envBound18137 : H12AffineFastState.Bounded env18137 := by
  intro p hp
  have h : env18137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18136_18137 : H12AffineEnvironment.transform 9 272 env18136 = env18137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18136 == env18137) = true)

theorem identity18137 : scanCanonicalize (H12AffineFastState.compose env18137 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound18137 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env18138 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6429,2129,6209,6423,2112,2421,272,6208,4160,6241,6225,6210,6429,65,4161,2112,4096,2420,68,6241,256,6240,4160,513]

theorem envBound18138 : H12AffineFastState.Bounded env18138 := by
  intro p hp
  have h : env18138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18137_18138 : H12AffineEnvironment.transform 12 6429 env18137 = env18138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env18137 == env18138) = true)

theorem identity18138 : scanCanonicalize (H12AffineFastState.compose env18138 (packedSelected [0,1,3,5,6,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound18138 : packedSelected [0,1,3,5,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env18139 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2405,120,2129,292,114,2112,2421,272,293,2341,260,308,295,120,65,2340,2112,2405,2420,68,260,256,261,2341,513]

theorem envBound18139 : H12AffineFastState.Bounded env18139 := by
  intro p hp
  have h : env18139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18138_18139 : H12AffineEnvironment.transform 11 2405 env18138 = env18139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env18138 == env18139) = true)

theorem identity18139 : scanCanonicalize (H12AffineFastState.compose env18139 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18139 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env18140 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,2112,120,2129,1,114,2112,2128,53,0,2048,33,17,2,120,65,2049,2112,2112,2129,68,33,37,32,2048,513]

theorem envBound18140 : H12AffineFastState.Bounded env18140 := by
  intro p hp
  have h : env18140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18139_18140 : H12AffineEnvironment.transform 7 37 env18139 = env18140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18139 == env18140) = true)

theorem identity18140 : scanCanonicalize (H12AffineFastState.compose env18140 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18140 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18141 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2064,40,2049,1,34,2064,2048,53,0,2048,33,17,2,40,17,2049,2064,2064,2049,20,33,37,32,2048,513]

theorem envBound18141 : H12AffineFastState.Bounded env18141 := by
  intro p hp
  have h : env18141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18140_18141 : H12AffineEnvironment.transform 5 16 env18140 = env18141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18140 == env18141) = true)

theorem identity18141 : scanCanonicalize (H12AffineFastState.compose env18141 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound18141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18142 : List Nat := [2,4,8,16,32,16,8,37,512,53,529,513,40,528,1,34,513,529,53,0,529,33,17,2,40,17,528,513,513,528,20,33,37,32,529,513]

theorem envBound18142 : H12AffineFastState.Bounded env18142 := by
  intro p hp
  have h : env18142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18141_18142 : H12AffineEnvironment.transform 10 529 env18141 = env18142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env18141 == env18142) = true)

theorem identity18142 : scanCanonicalize (H12AffineFastState.compose env18142 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound18142 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18143 : List Nat := [2,4,8,16,32,16,8,37,27,53,10,26,40,11,1,34,26,10,53,0,10,33,17,2,40,17,11,26,26,11,20,33,37,32,10,26]

theorem envBound18143 : H12AffineFastState.Bounded env18143 := by
  intro p hp
  have h : env18143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18142_18143 : H12AffineEnvironment.transform 8 27 env18142 = env18143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env18142 == env18143) = true)

def env18144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400501,499129,8328,65,295420,395636,416100,56437,1501,272392,256,21793,46212,74250]

theorem envBound18144 : H12AffineFastState.Bounded env18144 := by
  intro p hp
  have h : env18144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18129_18144 : H12AffineEnvironment.transform 20 4161 env18129 = env18144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env18129 == env18144) = true)

def env18145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180273,144477,243089,8328,65,43476,139612,160076,56437,1501,32,256,21793,46212,74250]

theorem envBound18145 : H12AffineFastState.Bounded env18145 := by
  intro p hp
  have h : env18145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18144_18145 : H12AffineEnvironment.transform 17 10280 env18144 = env18145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env18144 == env18145) = true)

def env18146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,21793,41293,73857,8328,65,43476,46156,58460,56437,1501,32,256,21793,46212,74250]

theorem envBound18146 : H12AffineFastState.Bounded env18146 := by
  intro p hp
  have h : env18146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18145_18146 : H12AffineEnvironment.transform 16 38160 env18145 = env18146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env18145 == env18146) = true)

theorem identity18146 : scanCanonicalize (H12AffineFastState.compose env18146 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound18146 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,38160,10280,1024,32769,4161,21793,41293,41430,8328,65,43476,46156,58460,56437,1501,32,256,21793,46212,41821]

theorem envBound18147 : H12AffineFastState.Bounded env18147 := by
  intro p hp
  have h : env18147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18146_18147 : H12AffineEnvironment.transform 15 33111 env18146 = env18147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env18146 == env18147) = true)

theorem identity18147 : scanCanonicalize (H12AffineFastState.compose env18147 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound18147 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env18148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8694,13745,10280,1024,8352,4161,21793,492,375,8328,65,2421,5357,17661,31956,1501,32,256,21793,5157,1020]

theorem envBound18148 : H12AffineFastState.Bounded env18148 := by
  intro p hp
  have h : env18148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18147_18148 : H12AffineEnvironment.transform 14 8353 env18147 = env18148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env18147 == env18148) = true)

theorem identity18148 : scanCanonicalize (H12AffineFastState.compose env18148 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,18,20,22,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound18148 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,18,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env18149 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,16384,8353,8694,12756,10280,101,8352,4161,20804,492,375,8328,65,2421,4232,16536,30897,440,32,256,20804,4160,1020]

theorem envBound18149 : H12AffineFastState.Bounded env18149 := by
  intro p hp
  have h : env18149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18148_18149 : H12AffineEnvironment.transform 9 101 env18148 = env18149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env18148 == env18149) = true)

theorem identity18149 : scanCanonicalize (H12AffineFastState.compose env18149 (packedSelected [1,2,3,6,8,9,10,12,14,15,16,18,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound18149 : packedSelected [1,2,3,6,8,9,10,12,14,15,16,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env18150 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,8192,12393,8353,8694,12756,10280,101,8352,4161,8493,492,375,8328,65,2421,4232,12529,2264,440,32,256,8493,4160,1020]

theorem envBound18150 : H12AffineFastState.Bounded env18150 := by
  intro p hp
  have h : env18150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18149_18150 : H12AffineEnvironment.transform 13 12393 env18149 = env18150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env18149 == env18150) = true)

theorem identity18150 : scanCanonicalize (H12AffineFastState.compose env18150 (packedSelected [11,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18150 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env18151 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,8192,12345,8353,8614,12676,10280,53,8352,4113,8493,444,295,8328,17,2341,4232,12449,2184,440,32,256,8493,4112,940]

theorem envBound18151 : H12AffineFastState.Bounded env18151 := by
  intro p hp
  have h : env18151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18150_18151 : H12AffineEnvironment.transform 5 16 env18150 = env18151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18150 == env18151) = true)

def env18152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,21792,41292,73856,8328,65,43476,46157,58461,56437,1501,32,256,21793,46212,74250]

theorem envBound18152 : H12AffineFastState.Bounded env18152 := by
  intro p hp
  have h : env18152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18145_18152 : H12AffineEnvironment.transform 16 38161 env18145 = env18152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env18145 == env18152) = true)

theorem identity18152 : scanCanonicalize (H12AffineFastState.compose env18152 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound18152 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env18153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,38161,10280,1024,32769,4161,21792,41292,41311,8328,65,43476,46157,58461,56437,1501,32,256,21793,46212,41941]

theorem envBound18153 : H12AffineFastState.Bounded env18153 := by
  intro p hp
  have h : env18153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18152_18153 : H12AffineEnvironment.transform 15 33247 env18152 = env18153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env18152 == env18153) = true)

theorem identity18153 : scanCanonicalize (H12AffineFastState.compose env18153 (packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound18153 : packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env18154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,33247,38161,2420,1024,32769,4161,21792,32784,32771,468,65,34952,38161,50433,56437,1501,32,256,21793,38360,33417]

theorem envBound18154 : H12AffineFastState.Bounded env18154 := by
  intro p hp
  have h : env18154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18153_18154 : H12AffineEnvironment.transform 12 348 env18153 = env18154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env18153 == env18154) = true)

theorem identity18154 : scanCanonicalize (H12AffineFastState.compose env18154 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound18154 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env18155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,32768,33247,38161,2420,1024,32769,4161,1328,32784,32771,468,65,34952,38161,38161,35941,1501,32,256,1329,38360,33417]

theorem envBound18155 : H12AffineFastState.Bounded env18155 := by
  intro p hp
  have h : env18155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18154_18155 : H12AffineEnvironment.transform 13 4112 env18154 = env18155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env18154 == env18155) = true)

theorem identity18155 : scanCanonicalize (H12AffineFastState.compose env18155 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18155 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env18156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,4112,1344,1183,4177,2420,1024,1345,4161,1328,1360,1347,468,65,3528,4177,4177,2341,1501,32,256,1329,4248,1993]

theorem envBound18156 : H12AffineFastState.Bounded env18156 := by
  intro p hp
  have h : env18156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18155_18156 : H12AffineEnvironment.transform 14 1344 env18155 = env18156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env18155 == env18156) = true)

theorem identity18156 : scanCanonicalize (H12AffineFastState.compose env18156 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound18156 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env18157 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,4096,348,4112,509,34,4177,2420,189,508,4161,397,493,510,468,65,2421,4177,4177,2341,352,32,256,396,4248,884]

theorem envBound18157 : H12AffineFastState.Bounded env18157 := by
  intro p hp
  have h : env18157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18156_18157 : H12AffineEnvironment.transform 9 189 env18156 = env18157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env18156 == env18157) = true)

theorem identity18157 : scanCanonicalize (H12AffineFastState.compose env18157 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18157 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env18158 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,268,4112,429,34,4097,2340,189,428,4113,397,445,430,388,17,2341,4097,4097,2341,304,32,256,396,4248,804]

theorem envBound18158 : H12AffineFastState.Bounded env18158 := by
  intro p hp
  have h : env18158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18157_18158 : H12AffineEnvironment.transform 5 16 env18157 = env18158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18157 == env18158) = true)

theorem identity18158 : scanCanonicalize (H12AffineFastState.compose env18158 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound18158 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env18159 : List Nat := [2,4,8,16,32,16,128,36,512,189,2048,4096,40,4112,137,34,4097,2048,189,136,4113,169,153,138,160,17,2049,4097,4097,2049,20,32,36,168,4248,512]

theorem envBound18159 : H12AffineFastState.Bounded env18159 := by
  intro p hp
  have h : env18159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18158_18159 : H12AffineEnvironment.transform 7 36 env18158 = env18159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18158 == env18159) = true)

theorem identity18159 : scanCanonicalize (H12AffineFastState.compose env18159 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18159 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env18160 : List Nat := [2,4,8,16,1,16,128,5,512,156,2048,4096,9,4112,137,3,4097,2048,156,136,4113,136,153,138,129,17,2049,4097,4097,2049,20,1,5,137,4248,512]

theorem envBound18160 : H12AffineFastState.Bounded env18160 := by
  intro p hp
  have h : env18160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18159_18160 : H12AffineEnvironment.transform 4 1 env18159 = env18160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18159 == env18160) = true)

theorem identity18160 : scanCanonicalize (H12AffineFastState.compose env18160 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2711) := by decide +kernel

theorem selectedBound18160 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env18161 : List Nat := [2,4,8,16,1,16,128,5,512,156,2048,2711,9,2695,137,3,2710,2048,156,136,2694,136,153,138,129,17,2049,2710,2710,2049,20,1,5,137,2575,512]

theorem envBound18161 : H12AffineFastState.Bounded env18161 := by
  intro p hp
  have h : env18161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18160_18161 : H12AffineEnvironment.transform 11 2711 env18160 = env18161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2711 env18160 == env18161) = true)

end H12CloudChart1