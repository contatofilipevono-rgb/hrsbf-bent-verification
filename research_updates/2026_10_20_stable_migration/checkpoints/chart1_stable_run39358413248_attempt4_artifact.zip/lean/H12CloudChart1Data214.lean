import H12CloudChart1Data213

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54186 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,8203,13341,2477,1025,8581,4112,8492,16,2,8328,17,2048,5393,4096,2341,1421,8613,257,32,5377,512]

theorem envBound54186 : H12AffineFastState.Bounded env54186 := by
  intro p hp
  have h : env54186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54185_54186 : H12AffineEnvironment.transform 20 4112 env54185 = env54186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4112 env54185 == env54186) = true)

theorem identity54186 : scanCanonicalize (H12AffineFastState.compose env54186 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54186 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54187 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5376,429,34,5172,2477,1025,428,4112,261,16,2,161,17,2048,5393,4096,2341,1421,396,257,32,5377,512]

theorem envBound54187 : H12AffineFastState.Bounded env54187 := by
  intro p hp
  have h : env54187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54186_54187 : H12AffineEnvironment.transform 12 41 env54186 = env54187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54186 == env54187) = true)

theorem identity54187 : scanCanonicalize (H12AffineFastState.compose env54187 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound54187 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54188 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,4096,41,4541,429,34,4233,2477,188,428,4112,261,16,2,161,17,2048,4524,4096,2341,304,396,257,32,4540,512]

theorem envBound54188 : H12AffineFastState.Bounded env54188 := by
  intro p hp
  have h : env54188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54187_54188 : H12AffineEnvironment.transform 9 189 env54187 = env54188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env54187 == env54188) = true)

theorem identity54188 : scanCanonicalize (H12AffineFastState.compose env54188 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54188 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env54189 : List Nat := [2,4,8,16,1,17,128,256,512,156,2048,4096,8,4508,396,3,4233,2444,157,397,4112,261,16,2,128,17,2048,4493,4096,2308,273,396,257,1,4509,512]

theorem envBound54189 : H12AffineFastState.Bounded env54189 := by
  intro p hp
  have h : env54189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54188_54189 : H12AffineEnvironment.transform 4 1 env54188 = env54189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54188 == env54189) = true)

def env54190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound54190 : H12AffineFastState.Bounded env54190 := by
  intro p hp
  have h : env54190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53842_54190 : H12AffineEnvironment.transform 26 30393345 env53842 = env54190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env53842 == env54190) = true)

def env54191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound54191 : H12AffineFastState.Bounded env54191 := by
  intro p hp
  have h : env54191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54190_54191 : H12AffineEnvironment.transform 18 1024 env54190 = env54191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env54190 == env54191) = true)

theorem identity54191 : scanCanonicalize (H12AffineFastState.compose env54191 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2212871) := by decide +kernel

theorem selectedBound54191 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2212871,16777216,8328,64,23462918,18973837,102742,2556934,18890775,23160256,256,16777386,16834831,18966465]

theorem envBound54192 : H12AffineFastState.Bounded env54192 := by
  intro p hp
  have h : env54192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54191_54192 : H12AffineEnvironment.transform 22 2212871 env54191 = env54192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2212871 env54191 == env54192) = true)

def env54193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8328,64,17227834,18973837,102742,2556934,18890775,16876028,256,16777386,16834831,18966465]

theorem envBound54193 : H12AffineFastState.Bounded env54193 := by
  intro p hp
  have h : env54193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54192_54193 : H12AffineEnvironment.transform 21 2155580 env54192 = env54193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env54192 == env54193) = true)

def env54194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8192,64,17227834,18973701,102742,2556934,18890775,16875892,256,16777250,16834831,18966345]

theorem envBound54194 : H12AffineFastState.Bounded env54194 := by
  intro p hp
  have h : env54194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54193_54194 : H12AffineEnvironment.transform 6 8 env54193 = env54194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54193 == env54194) = true)

def env54195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62588,119879,16777216,8192,64,17227834,16880709,102742,463942,16797783,16875892,256,16777250,16834831,16873225]

theorem envBound54195 : H12AffineFastState.Bounded env54195 := by
  intro p hp
  have h : env54195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54194_54195 : H12AffineEnvironment.transform 20 4160 env54194 = env54195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54194 == env54195) = true)

def env54196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119879,16777216,8192,64,16959506,16880709,102742,212078,16797783,16875892,256,16777250,16834831,16873225]

theorem envBound54196 : H12AffineFastState.Bounded env54196 := by
  intro p hp
  have h : env54196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54195_54196 : H12AffineEnvironment.transform 17 10280 env54195 = env54196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54195 == env54196) = true)

def env54197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119879,95496,8192,64,245018,57677,102742,212078,75103,62588,256,95530,103431,513]

theorem envBound54197 : H12AffineFastState.Bounded env54197 := by
  intro p hp
  have h : env54197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54196_54197 : H12AffineEnvironment.transform 23 95496 env54196 = env54197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env54196 == env54197) = true)

theorem identity54197 : scanCanonicalize (H12AffineFastState.compose env54197 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54197 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env54198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,4160,21792,95515,95496,8192,64,203846,16401,77834,212078,75103,21792,256,95530,79195,513]

theorem envBound54198 : H12AffineFastState.Bounded env54198 := by
  intro p hp
  have h : env54198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54197_54198 : H12AffineEnvironment.transform 14 8540 env54197 = env54198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54197 == env54198) = true)

theorem identity54198 : scanCanonicalize (H12AffineFastState.compose env54198 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54198 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,65536,131072,10280,1024,8541,4160,113,73802,73817,8192,64,203846,5440,77834,212078,75103,113,256,73851,79195,513]

theorem envBound54199 : H12AffineFastState.Bounded env54199 := by
  intro p hp
  have h : env54199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54198_54199 : H12AffineEnvironment.transform 13 5457 env54198 = env54199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54198 == env54199) = true)

theorem identity54199 : scanCanonicalize (H12AffineFastState.compose env54199 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54199 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54200 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,65536,131072,10280,1024,8461,4112,33,73754,73737,8192,16,203798,5392,77834,212030,75023,33,256,73771,79115,513]

theorem envBound54200 : H12AffineFastState.Bounded env54200 := by
  intro p hp
  have h : env54200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54199_54200 : H12AffineEnvironment.transform 5 16 env54199 = env54200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54199 == env54200) = true)

theorem identity54200 : scanCanonicalize (H12AffineFastState.compose env54200 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound54200 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,65536,70679,10280,1024,8461,4112,33,73754,73737,8192,16,2049,5392,77834,10281,75023,33,256,73771,79115,513]

theorem envBound54201 : H12AffineFastState.Bounded env54201 := by
  intro p hp
  have h : env54201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54200_54201 : H12AffineEnvironment.transform 16 70679 env54200 = env54201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env54200 == env54201) = true)

theorem identity54201 : scanCanonicalize (H12AffineFastState.compose env54201 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54201 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8202,13341,10280,1024,8461,4112,33,16,3,8192,16,2049,5392,4096,10281,1285,33,256,33,5377,513]

theorem envBound54202 : H12AffineFastState.Bounded env54202 := by
  intro p hp
  have h : env54202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54201_54202 : H12AffineEnvironment.transform 15 8202 env54201 = env54202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54201 == env54202) = true)

def env54203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119879,95497,8192,64,245019,57676,102742,212078,75102,62589,256,95531,103430,512]

theorem envBound54203 : H12AffineFastState.Bounded env54203 := by
  intro p hp
  have h : env54203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54196_54203 : H12AffineEnvironment.transform 23 95497 env54196 = env54203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env54196 == env54203) = true)

theorem identity54203 : scanCanonicalize (H12AffineFastState.compose env54203 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound54203 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4160,62588,41292,2,8192,64,182288,57676,58461,149861,20565,62589,256,32,57613,512]

theorem envBound54204 : H12AffineFastState.Bounded env54204 := by
  intro p hp
  have h : env54204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54203_54204 : H12AffineEnvironment.transform 15 29963 env54203 = env54204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env54203 == env54204) = true)

theorem identity54204 : scanCanonicalize (H12AffineFastState.compose env54204 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58381) := by decide +kernel

theorem selectedBound54204 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,58381,10280,1024,32769,4160,62588,41292,2,8192,64,11293,57676,58461,44392,20565,62589,256,32,57613,512]

theorem envBound54205 : H12AffineFastState.Bounded env54205 := by
  intro p hp
  have h : env54205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54204_54205 : H12AffineEnvironment.transform 16 58381 env54204 = env54205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58381 env54204 == env54205) = true)

theorem identity54205 : scanCanonicalize (H12AffineFastState.compose env54205 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22804) := by decide +kernel

theorem selectedBound54205 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env54206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,22804,29963,15641,10280,1024,22805,4160,11624,30808,2,8192,64,11293,14424,15689,29820,20565,11625,256,32,14361,512]

theorem envBound54206 : H12AffineFastState.Bounded env54206 := by
  intro p hp
  have h : env54206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54205_54206 : H12AffineEnvironment.transform 14 22804 env54205 = env54206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22804 env54205 == env54206) = true)

theorem identity54206 : scanCanonicalize (H12AffineFastState.compose env54206 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound54206 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env54207 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,8192,16384,22804,28747,14425,10280,320,22805,4160,10280,30808,2,8192,64,10589,14424,14345,28988,20565,10281,256,32,14361,512]

theorem envBound54207 : H12AffineFastState.Bounded env54207 := by
  intro p hp
  have h : env54207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54206_54207 : H12AffineEnvironment.transform 9 320 env54206 = env54207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env54206 == env54207) = true)

theorem identity54207 : scanCanonicalize (H12AffineFastState.compose env54207 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound54207 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54208 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,17,8192,16384,18693,24666,10312,10280,320,18692,81,10280,26697,2,8192,64,10589,10313,10264,24877,16452,10281,256,32,10248,512]

theorem envBound54208 : H12AffineFastState.Bounded env54208 := by
  intro p hp
  have h : env54208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54207_54208 : H12AffineEnvironment.transform 11 17 env54207 = env54208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54207 == env54208) = true)

theorem identity54208 : scanCanonicalize (H12AffineFastState.compose env54208 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54208 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env54209 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,8192,16384,18693,24586,10264,10280,272,18692,1,10280,26649,2,8192,16,10509,10265,10264,24877,16404,10281,256,32,10248,512]

theorem envBound54209 : H12AffineFastState.Bounded env54209 := by
  intro p hp
  have h : env54209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54208_54209 : H12AffineEnvironment.transform 5 16 env54208 = env54209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54208 == env54209) = true)

theorem identity54209 : scanCanonicalize (H12AffineFastState.compose env54209 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound54209 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env54210 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,8192,10508,8201,2310,10264,10280,272,8200,1,10280,277,2,8192,16,10509,10265,10264,2081,10520,10281,256,32,10248,512]

theorem envBound54210 : H12AffineFastState.Bounded env54210 := by
  intro p hp
  have h : env54210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54209_54210 : H12AffineEnvironment.transform 13 10508 env54209 = env54210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env54209 == env54210) = true)

theorem identity54210 : scanCanonicalize (H12AffineFastState.compose env54210 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound54210 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env54211 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,9,2309,0,2310,2065,2081,272,1,1,2081,277,2,9,16,2308,2064,2065,2081,2321,2080,256,32,2049,512]

theorem envBound54211 : H12AffineFastState.Bounded env54211 := by
  intro p hp
  have h : env54211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54210_54211 : H12AffineEnvironment.transform 12 9 env54210 = env54211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env54210 == env54211) = true)

theorem identity54211 : scanCanonicalize (H12AffineFastState.compose env54211 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54211 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env54212 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,9,260,0,263,16,32,272,1,1,32,277,2,9,16,261,17,16,32,272,33,256,32,0,512]

theorem envBound54212 : H12AffineFastState.Bounded env54212 := by
  intro p hp
  have h : env54212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54211_54212 : H12AffineEnvironment.transform 10 1 env54211 = env54212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54211 == env54212) = true)

theorem identity54212 : scanCanonicalize (H12AffineFastState.compose env54212 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54212 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54213 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,17,9,33,0,34,16,32,53,1,1,32,48,2,9,16,32,17,16,32,53,33,37,32,0,512]

theorem envBound54213 : H12AffineFastState.Bounded env54213 := by
  intro p hp
  have h : env54213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54212_54213 : H12AffineEnvironment.transform 7 37 env54212 = env54213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54212 == env54213) = true)

def env54214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62588,119879,16777216,8192,64,16959507,16880709,102742,212079,16797783,16875892,256,16777250,16834831,16873225]

theorem envBound54214 : H12AffineFastState.Bounded env54214 := by
  intro p hp
  have h : env54214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54195_54214 : H12AffineEnvironment.transform 17 10281 env54195 = env54214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54195 == env54214) = true)

theorem identity54214 : scanCanonicalize (H12AffineFastState.compose env54214 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound54214 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4160,62588,16,16777216,8192,64,16959507,16793618,17665,190520,16797783,16799011,256,16777250,16834831,16819038]

theorem envBound54215 : H12AffineFastState.Bounded env54215 := by
  intro p hp
  have h : env54215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54214_54215 : H12AffineEnvironment.transform 15 54359 env54214 = env54215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env54214 == env54215) = true)

theorem identity54215 : scanCanonicalize (H12AffineFastState.compose env54215 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 136467) := by decide +kernel

theorem selectedBound54215 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4160,62588,16,136467,8192,64,56576,152833,17665,190520,148804,147504,256,136497,193564,177741]

theorem envBound54216 : H12AffineFastState.Bounded env54216 := by
  intro p hp
  have h : env54216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54215_54216 : H12AffineEnvironment.transform 23 136467 env54215 = env54216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136467 env54215 == env54216) = true)

theorem identity54216 : scanCanonicalize (H12AffineFastState.compose env54216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound54216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,4096,10281,1024,32769,4160,62588,16,1299,8192,64,56576,17665,17665,63544,21828,20528,256,1329,58396,42573]

theorem envBound54217 : H12AffineFastState.Bounded env54217 := by
  intro p hp
  have h : env54217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54216_54217 : H12AffineEnvironment.transform 16 4096 env54216 = env54217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env54216 == env54217) = true)

theorem identity54217 : scanCanonicalize (H12AffineFastState.compose env54217 (packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 28729) := by decide +kernel

theorem selectedBound54217 : packedSelected [1,2,6,7,8,9,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env54218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,28729,9326,4096,10281,1024,28728,4160,1093,16,1299,8192,64,11577,17665,17665,2049,21828,20528,256,1329,5157,22132]

theorem envBound54218 : H12AffineFastState.Bounded env54218 := by
  intro p hp
  have h : env54218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54217_54218 : H12AffineEnvironment.transform 14 28729 env54217 = env54218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28729 env54217 == env54218) = true)

theorem identity54218 : scanCanonicalize (H12AffineFastState.compose env54218 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound54218 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env54219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,9292,9326,4096,10281,1024,9293,4160,1093,16,1299,8192,64,11577,4468,4468,2049,305,1093,256,1329,5157,513]

theorem envBound54219 : H12AffineFastState.Bounded env54219 := by
  intro p hp
  have h : env54219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54218_54219 : H12AffineEnvironment.transform 13 5237 env54218 = env54219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env54218 == env54219) = true)

theorem identity54219 : scanCanonicalize (H12AffineFastState.compose env54219 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound54219 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5237,0,34,4096,3173,1024,1,4160,1093,16,1299,1100,64,2421,4468,4468,2049,305,1093,256,1329,5157,513]

theorem envBound54220 : H12AffineFastState.Bounded env54220 := by
  intro p hp
  have h : env54220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54219_54220 : H12AffineEnvironment.transform 12 1100 env54219 = env54220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env54219 == env54220) = true)

theorem identity54220 : scanCanonicalize (H12AffineFastState.compose env54220 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound54220 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,64,1100,1077,0,34,64,3173,1024,1,0,1093,16,1299,1100,64,2421,308,308,2049,305,1093,256,1329,1125,513]

theorem envBound54221 : H12AffineFastState.Bounded env54221 := by
  intro p hp
  have h : env54221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54220_54221 : H12AffineEnvironment.transform 11 64 env54220 = env54221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env54220 == env54221) = true)

theorem identity54221 : scanCanonicalize (H12AffineFastState.compose env54221 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound54221 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env54222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,64,1100,1077,0,34,64,1344,1024,1,0,1093,16,1299,1100,64,80,308,308,292,305,1093,256,1329,1125,513]

theorem envBound54222 : H12AffineFastState.Bounded env54222 := by
  intro p hp
  have h : env54222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54221_54222 : H12AffineEnvironment.transform 10 293 env54221 = env54222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env54221 == env54222) = true)

theorem identity54222 : scanCanonicalize (H12AffineFastState.compose env54222 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54222 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54223 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,64,41,80,0,34,64,293,101,1,0,32,16,374,41,64,80,308,308,292,305,32,256,340,0,513]

theorem envBound54223 : H12AffineFastState.Bounded env54223 := by
  intro p hp
  have h : env54223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54222_54223 : H12AffineEnvironment.transform 9 101 env54222 = env54223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54222 == env54223) = true)

theorem identity54223 : scanCanonicalize (H12AffineFastState.compose env54223 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54224 : List Nat := [2,4,8,16,32,64,8,37,512,101,0,64,41,80,0,34,64,0,101,1,0,32,16,83,41,64,80,17,17,1,20,32,37,113,0,513]

theorem envBound54224 : H12AffineFastState.Bounded env54224 := by
  intro p hp
  have h : env54224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54223_54224 : H12AffineEnvironment.transform 7 37 env54223 = env54224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54223 == env54224) = true)

theorem identity54224 : scanCanonicalize (H12AffineFastState.compose env54224 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54224 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54225 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,41,0,0,34,16,0,53,1,0,32,16,3,41,16,0,17,17,1,20,32,37,33,0,513]

theorem envBound54225 : H12AffineFastState.Bounded env54225 := by
  intro p hp
  have h : env54225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54224_54225 : H12AffineEnvironment.transform 5 16 env54224 = env54225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54224 == env54225) = true)

theorem identity54225 : scanCanonicalize (H12AffineFastState.compose env54225 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54226 : List Nat := [2,4,8,16,16,16,8,21,512,5,0,16,25,0,0,18,16,0,5,1,0,16,16,3,25,16,0,17,17,1,20,16,21,17,0,513]

theorem envBound54226 : H12AffineFastState.Bounded env54226 := by
  intro p hp
  have h : env54226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54225_54226 : H12AffineEnvironment.transform 4 16 env54225 = env54226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54225 == env54226) = true)

def env54227 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62589,119878,16777216,8192,64,17227834,16880708,102742,463943,16797782,16875892,256,16777250,16834831,16873224]

theorem envBound54227 : H12AffineFastState.Bounded env54227 := by
  intro p hp
  have h : env54227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54194_54227 : H12AffineEnvironment.transform 20 4161 env54194 = env54227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54194 == env54227) = true)

theorem identity54227 : scanCanonicalize (H12AffineFastState.compose env54227 (packedSelected [17] rootPS)) = affineNative (2^(23+1) ^^^ 95497) := by decide +kernel

theorem selectedBound54227 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62589,119878,95497,8192,64,496947,57677,102742,463943,75103,62589,256,95531,103430,513]

theorem envBound54228 : H12AffineFastState.Bounded env54228 := by
  intro p hp
  have h : env54228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54227_54228 : H12AffineEnvironment.transform 23 95497 env54227 = env54228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env54227 == env54228) = true)

def env54229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119878,95497,8192,64,245019,57677,102742,212079,75103,62589,256,95531,103430,513]

theorem envBound54229 : H12AffineFastState.Bounded env54229 := by
  intro p hp
  have h : env54229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54228_54229 : H12AffineEnvironment.transform 17 10280 env54228 = env54229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54228 == env54229) = true)

theorem identity54229 : scanCanonicalize (H12AffineFastState.compose env54229 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54229 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env54230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,4161,21793,95514,95497,8192,64,203847,16401,77834,212079,75103,21793,256,95531,79194,513]

theorem envBound54230 : H12AffineFastState.Bounded env54230 := by
  intro p hp
  have h : env54230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54229_54230 : H12AffineEnvironment.transform 14 8540 env54229 = env54230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54229 == env54230) = true)

theorem identity54230 : scanCanonicalize (H12AffineFastState.compose env54230 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54230 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8540,65536,131072,10280,1024,8541,4161,113,73802,73817,8192,64,203847,5441,77834,212079,75103,113,256,73851,79194,513]

theorem envBound54231 : H12AffineFastState.Bounded env54231 := by
  intro p hp
  have h : env54231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54230_54231 : H12AffineEnvironment.transform 13 5456 env54230 = env54231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54230 == env54231) = true)

theorem identity54231 : scanCanonicalize (H12AffineFastState.compose env54231 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54231 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54232 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,131072,10280,1024,8461,4113,33,73754,73737,8192,16,203799,5393,77834,212031,75023,33,256,73771,79114,513]

theorem envBound54232 : H12AffineFastState.Bounded env54232 := by
  intro p hp
  have h : env54232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54231_54232 : H12AffineEnvironment.transform 5 16 env54231 = env54232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54231 == env54232) = true)

theorem identity54232 : scanCanonicalize (H12AffineFastState.compose env54232 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70678) := by decide +kernel

theorem selectedBound54232 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env54233 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,70678,10280,1024,8461,4113,33,73754,73737,8192,16,2049,5393,77834,10281,75023,33,256,73771,79114,513]

theorem envBound54233 : H12AffineFastState.Bounded env54233 := by
  intro p hp
  have h : env54233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54232_54233 : H12AffineEnvironment.transform 16 70678 env54232 = env54233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70678 env54232 == env54233) = true)

theorem identity54233 : scanCanonicalize (H12AffineFastState.compose env54233 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54233 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54234 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,13340,10280,1024,8461,4113,33,16,3,8192,16,2049,5393,4096,10281,1285,33,256,33,5376,513]

theorem envBound54234 : H12AffineFastState.Bounded env54234 := by
  intro p hp
  have h : env54234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54233_54234 : H12AffineEnvironment.transform 15 8202 env54233 = env54234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54233 == env54234) = true)

def env54235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62589,119878,95497,8192,64,245018,57677,102742,212078,75103,62589,256,95531,103430,513]

theorem envBound54235 : H12AffineFastState.Bounded env54235 := by
  intro p hp
  have h : env54235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54228_54235 : H12AffineEnvironment.transform 17 10281 env54228 = env54235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54228 == env54235) = true)

theorem identity54235 : scanCanonicalize (H12AffineFastState.compose env54235 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54235 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,4161,62589,119878,95497,8192,64,56577,57677,102742,23669,75103,62589,256,95531,103430,513]

theorem envBound54236 : H12AffineFastState.Bounded env54236 := by
  intro p hp
  have h : env54236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54235_54236 : H12AffineEnvironment.transform 16 90139 env54235 = env54236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54235 == env54236) = true)

theorem identity54236 : scanCanonicalize (H12AffineFastState.compose env54236 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound54236 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,65536,90139,10281,1024,9292,4161,20528,94219,95497,8192,64,31052,17664,79131,23669,75103,20528,256,95531,77899,513]

theorem envBound54237 : H12AffineFastState.Bounded env54237 := by
  intro p hp
  have h : env54237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54236_54237 : H12AffineEnvironment.transform 14 9293 env54236 = env54237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env54236 == env54237) = true)

theorem identity54237 : scanCanonicalize (H12AffineFastState.compose env54237 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound54237 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,9293,28699,4096,10281,1024,9292,4161,20528,16,1298,8192,64,31052,17664,17664,23669,21828,20528,256,1328,16464,513]

theorem envBound54238 : H12AffineFastState.Bounded env54238 := by
  intro p hp
  have h : env54238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54237_54238 : H12AffineEnvironment.transform 15 28699 env54237 = env54238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env54237 == env54238) = true)

theorem identity54238 : scanCanonicalize (H12AffineFastState.compose env54238 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5132) := by decide +kernel

theorem selectedBound54238 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,5132,16384,4161,17431,4096,7205,1024,4160,4161,20528,16,1298,5132,64,19776,17664,17664,23669,21828,20528,256,1328,16464,513]

theorem envBound54239 : H12AffineFastState.Bounded env54239 := by
  intro p hp
  have h : env54239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54238_54239 : H12AffineEnvironment.transform 12 5132 env54238 = env54239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5132 env54238 == env54239) = true)

theorem identity54239 : scanCanonicalize (H12AffineFastState.compose env54239 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound54239 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env54240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1061,41,16384,1124,17431,1061,2048,1024,1125,1124,17429,16,1298,41,64,19776,17664,17664,18512,16737,17429,256,1328,16464,513]

theorem envBound54240 : H12AffineFastState.Bounded env54240 := by
  intro p hp
  have h : env54240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54239_54240 : H12AffineEnvironment.transform 11 1061 env54239 = env54240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env54239 == env54240) = true)

theorem identity54240 : scanCanonicalize (H12AffineFastState.compose env54240 (packedSelected [0,1,2,3,5,7,8,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound54240 : packedSelected [0,1,2,3,5,7,8,15,18] rootPS < 2^1333 := by decide +kernel

def env54241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,16384,1124,17431,1061,373,1024,1125,1124,17429,16,1298,41,64,17461,17664,17664,16677,16737,17429,256,1328,16464,513]

theorem envBound54241 : H12AffineFastState.Bounded env54241 := by
  intro p hp
  have h : env54241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54240_54241 : H12AffineEnvironment.transform 10 373 env54240 = env54241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env54240 == env54241) = true)

theorem identity54241 : scanCanonicalize (H12AffineFastState.compose env54241 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound54241 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env54242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,1061,41,1345,1124,342,1061,373,1024,1125,1124,340,16,1298,41,64,372,65,65,1124,1056,340,256,1328,1297,513]

theorem envBound54242 : H12AffineFastState.Bounded env54242 := by
  intro p hp
  have h : env54242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54241_54242 : H12AffineEnvironment.transform 13 1345 env54241 = env54242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env54241 == env54242) = true)

theorem identity54242 : scanCanonicalize (H12AffineFastState.compose env54242 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54242 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54243 : List Nat := [2,4,8,16,32,17,8,256,512,1024,292,1061,41,1296,1077,263,1061,292,1024,1076,1077,261,16,1298,41,17,293,16,16,1077,1056,261,256,1328,1297,513]

theorem envBound54243 : H12AffineFastState.Bounded env54243 := by
  intro p hp
  have h : env54243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54242_54243 : H12AffineEnvironment.transform 5 17 env54242 = env54243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54242 == env54243) = true)

def env54244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,16777216,8193,64,17227834,18973700,102742,2556934,18890775,16875893,256,16777251,16834831,18966344]

theorem envBound54244 : H12AffineFastState.Bounded env54244 := by
  intro p hp
  have h : env54244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54193_54244 : H12AffineEnvironment.transform 6 9 env54193 = env54244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54193 == env54244) = true)

theorem identity54244 : scanCanonicalize (H12AffineFastState.compose env54244 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147475) := by decide +kernel

theorem selectedBound54244 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env54245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155580,2212871,147475,8193,64,303145,2343959,102742,2556934,2228228,246118,256,147504,172316,2303835]

theorem envBound54245 : H12AffineFastState.Bounded env54245 := by
  intro p hp
  have h : env54245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54244_54245 : H12AffineEnvironment.transform 23 147475 env54244 = env54245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147475 env54244 == env54245) = true)

def env54246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,62588,119879,147475,8193,64,303145,250967,102742,463942,135236,246118,256,147504,172316,210715]

theorem envBound54246 : H12AffineFastState.Bounded env54246 := by
  intro p hp
  have h : env54246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54245_54246 : H12AffineEnvironment.transform 20 4160 env54245 = env54246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54245 == env54246) = true)

theorem identity54246 : scanCanonicalize (H12AffineFastState.compose env54246 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound54246 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,4160,62588,119879,73736,8193,64,303145,46156,102742,291933,94303,41341,256,73771,114951,22272]

theorem envBound54247 : H12AffineFastState.Bounded env54247 := by
  intro p hp
  have h : env54247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54246_54247 : H12AffineEnvironment.transform 16 90139 env54246 = env54247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env54246 == env54247) = true)

theorem identity54247 : scanCanonicalize (H12AffineFastState.compose env54247 (packedSelected [1,3,5,8,10,11,12,15,18,19,21,23,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54247 : packedSelected [1,3,5,8,10,11,12,15,18,19,21,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env54248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90139,262144,1024,8540,4160,21793,95514,73736,8193,64,262516,5393,77835,291933,94303,32,256,73771,90202,22272]

theorem envBound54248 : H12AffineFastState.Bounded env54248 := by
  intro p hp
  have h : env54248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54247_54248 : H12AffineEnvironment.transform 14 8541 env54247 = env54248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54247 == env54248) = true)

theorem identity54248 : scanCanonicalize (H12AffineFastState.compose env54248 (packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound54248 : packedSelected [1,3,5,8,10,11,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env54249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90139,89378,1024,8540,4160,21793,95514,73736,8193,64,89174,5393,77835,76159,94303,32,256,73771,90202,22272]

theorem envBound54249 : H12AffineFastState.Bounded env54249 := by
  intro p hp
  have h : env54249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54248_54249 : H12AffineEnvironment.transform 17 89378 env54248 = env54249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env54248 == env54249) = true)

theorem identity54249 : scanCanonicalize (H12AffineFastState.compose env54249 (packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54249 : packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env54250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,263,24860,23589,1024,8540,4160,21793,29725,8463,8193,64,23889,5393,12556,10360,29016,32,256,8492,24925,22272]

theorem envBound54250 : H12AffineFastState.Bounded env54250 := by
  intro p hp
  have h : env54250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54249_54250 : H12AffineEnvironment.transform 15 263 env54249 = env54250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54249 == env54250) = true)

theorem identity54250 : scanCanonicalize (H12AffineFastState.compose env54250 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54250 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env54251 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,114,24681,23589,1024,8233,4160,21588,29725,8314,8193,64,23588,5220,12409,10360,28717,32,117,8281,24616,22133]

theorem envBound54251 : H12AffineFastState.Bounded env54251 := by
  intro p hp
  have h : env54251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54250_54251 : H12AffineEnvironment.transform 7 117 env54250 = env54251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54250 == env54251) = true)

theorem identity54251 : scanCanonicalize (H12AffineFastState.compose env54251 (packedSelected [1,2,4,6,7,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 8232) := by decide +kernel

theorem selectedBound54251 : packedSelected [1,2,4,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54252 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,8232,8232,114,65,15373,1024,8233,4160,13436,5173,8314,8193,64,15372,5220,12409,10360,4101,32,117,8281,0,13917]

theorem envBound54252 : H12AffineFastState.Bounded env54252 := by
  intro p hp
  have h : env54252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54251_54252 : H12AffineEnvironment.transform 13 8232 env54251 = env54252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8232 env54251 == env54252) = true)

theorem identity54252 : scanCanonicalize (H12AffineFastState.compose env54252 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound54252 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env54253 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3109,8192,8232,8232,114,65,8232,1024,8233,3173,10329,2064,8314,8193,64,8233,2113,11356,10360,3104,32,117,8281,0,10872]

theorem envBound54253 : H12AffineFastState.Bounded env54253 := by
  intro p hp
  have h : env54253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54252_54253 : H12AffineEnvironment.transform 11 3109 env54252 = env54253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env54252 == env54253) = true)

theorem identity54253 : scanCanonicalize (H12AffineFastState.compose env54253 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54253 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env54254 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,2065,8192,8232,8232,114,65,8232,52,8233,2129,10329,2064,8314,8193,64,8233,2113,10344,10360,2068,32,117,8281,0,10872]

theorem envBound54254 : H12AffineFastState.Bounded env54254 := by
  intro p hp
  have h : env54254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54253_54254 : H12AffineEnvironment.transform 9 52 env54253 = env54254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54253 == env54254) = true)

theorem identity54254 : scanCanonicalize (H12AffineFastState.compose env54254 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound54254 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54255 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,2065,40,0,0,114,65,0,52,1,2129,2161,2064,82,41,64,1,2113,2112,2128,2068,32,117,113,0,2640]

theorem envBound54255 : H12AffineFastState.Bounded env54255 := by
  intro p hp
  have h : env54255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54254_54255 : H12AffineEnvironment.transform 12 40 env54254 = env54255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env54254 == env54255) = true)

theorem identity54255 : scanCanonicalize (H12AffineFastState.compose env54255 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound54255 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54256 : List Nat := [2,4,8,16,32,64,9,117,512,52,80,65,40,0,0,114,65,0,52,1,1,33,64,82,41,64,1,17,16,0,68,32,117,113,0,512]

theorem envBound54256 : H12AffineFastState.Bounded env54256 := by
  intro p hp
  have h : env54256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54255_54256 : H12AffineEnvironment.transform 10 80 env54255 = env54256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env54255 == env54256) = true)

theorem identity54256 : scanCanonicalize (H12AffineFastState.compose env54256 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54257 : List Nat := [2,4,8,16,1,64,9,84,512,21,80,65,9,0,0,83,65,0,21,1,1,0,64,82,8,64,1,17,16,0,68,1,84,80,0,512]

theorem envBound54257 : H12AffineFastState.Bounded env54257 := by
  intro p hp
  have h : env54257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54256_54257 : H12AffineEnvironment.transform 4 1 env54256 = env54257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54256 == env54257) = true)

theorem identity54257 : scanCanonicalize (H12AffineFastState.compose env54257 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound54257 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54258 : List Nat := [2,4,8,16,1,64,9,84,10,21,80,65,9,0,0,83,65,0,21,1,1,0,64,82,8,64,1,17,16,0,68,1,84,80,0,10]

theorem envBound54258 : H12AffineFastState.Bounded env54258 := by
  intro p hp
  have h : env54258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54257_54258 : H12AffineEnvironment.transform 8 10 env54257 = env54258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env54257 == env54258) = true)

theorem identity54258 : scanCanonicalize (H12AffineFastState.compose env54258 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54259 : List Nat := [2,4,8,12,1,64,9,72,10,9,76,65,9,0,0,79,65,0,9,1,1,0,64,78,8,64,1,13,12,0,68,1,72,76,0,10]

theorem envBound54259 : H12AffineFastState.Bounded env54259 := by
  intro p hp
  have h : env54259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54258_54259 : H12AffineEnvironment.transform 3 12 env54258 = env54259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54258 == env54259) = true)

theorem identity54259 : scanCanonicalize (H12AffineFastState.compose env54259 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound54259 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54260 : List Nat := [2,4,8,12,1,13,9,5,10,9,1,12,9,0,0,2,12,0,9,1,1,0,13,3,8,13,1,13,12,0,9,1,5,1,0,10]

theorem envBound54260 : H12AffineFastState.Bounded env54260 := by
  intro p hp
  have h : env54260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54259_54260 : H12AffineEnvironment.transform 5 13 env54259 = env54260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env54259 == env54260) = true)

theorem identity54260 : scanCanonicalize (H12AffineFastState.compose env54260 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54260 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54261 : List Nat := [2,4,0,4,1,5,1,5,2,1,1,4,1,0,0,2,4,0,1,1,1,0,5,3,0,5,1,5,4,0,1,1,5,1,0,2]

theorem envBound54261 : H12AffineFastState.Bounded env54261 := by
  intro p hp
  have h : env54261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54260_54261 : H12AffineEnvironment.transform 2 0 env54260 = env54261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54260 == env54261) = true)

def env54262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,62589,119878,147475,8193,64,303145,250966,102742,463943,135237,246118,256,147504,172316,210714]

theorem envBound54262 : H12AffineFastState.Bounded env54262 := by
  intro p hp
  have h : env54262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54245_54262 : H12AffineEnvironment.transform 20 4161 env54245 = env54262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54245 == env54262) = true)

theorem identity54262 : scanCanonicalize (H12AffineFastState.compose env54262 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54262 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,41341,98630,136467,8193,64,303145,229718,102742,463943,135237,234598,256,136496,172316,210714]

theorem envBound54263 : H12AffineFastState.Bounded env54263 := by
  intro p hp
  have h : env54263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54262_54263 : H12AffineEnvironment.transform 13 5376 env54262 = env54263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54262 == env54263) = true)

theorem identity54263 : scanCanonicalize (H12AffineFastState.compose env54263 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound54263 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env54264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,4161,41341,98630,73736,8193,64,303145,46157,102742,270684,75102,41341,256,73771,103431,513]

theorem envBound54264 : H12AffineFastState.Bounded env54264 := by
  intro p hp
  have h : env54264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54263_54264 : H12AffineEnvironment.transform 16 79131 env54263 = env54264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env54263 == env54264) = true)

theorem identity54264 : scanCanonicalize (H12AffineFastState.compose env54264 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound54264 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env54265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,9498,4097,262144,1024,32769,4161,41341,42076,1298,8193,64,303145,46157,46156,270684,68,41341,256,1329,45341,513]

theorem envBound54265 : H12AffineFastState.Bounded env54265 := by
  intro p hp
  have h : env54265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54264_54265 : H12AffineEnvironment.transform 15 9498 env54264 = env54265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env54264 == env54265) = true)

theorem identity54265 : scanCanonicalize (H12AffineFastState.compose env54265 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound54265 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,9498,4097,35188,1024,32769,4161,41341,42076,1298,8193,64,10589,46157,46156,43048,68,41341,256,1329,45341,513]

theorem envBound54266 : H12AffineFastState.Bounded env54266 := by
  intro p hp
  have h : env54266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54265_54266 : H12AffineEnvironment.transform 17 35188 env54265 = env54266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env54265 == env54266) = true)

def env54267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8328,64,17227835,18973837,102742,2556934,18890775,16876029,256,16777386,16834831,18966465]

theorem envBound54267 : H12AffineFastState.Bounded env54267 := by
  intro p hp
  have h : env54267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54192_54267 : H12AffineEnvironment.transform 21 2155581 env54192 = env54267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env54192 == env54267) = true)

def env54268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8192,64,17227835,18973701,102742,2556934,18890775,16875893,256,16777250,16834831,18966345]

theorem envBound54268 : H12AffineFastState.Bounded env54268 := by
  intro p hp
  have h : env54268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54267_54268 : H12AffineEnvironment.transform 6 8 env54267 = env54268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54267 == env54268) = true)

theorem identity54268 : scanCanonicalize (H12AffineFastState.compose env54268 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound54268 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env54269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,73770,16,16777216,8192,64,17227835,16793618,102742,442385,16876544,16875893,256,16777250,16834831,16819038]

theorem envBound54269 : H12AffineFastState.Bounded env54269 := by
  intro p hp
  have h : env54269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54268_54269 : H12AffineEnvironment.transform 20 115735 env54268 = env54269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env54268 == env54269) = true)

def env54270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,73770,16,95496,8192,64,496947,79130,102742,442385,61704,62589,256,95530,103431,120406]

theorem envBound54270 : H12AffineFastState.Bounded env54270 := by
  intro p hp
  have h : env54270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54269_54270 : H12AffineEnvironment.transform 23 95496 env54269 = env54270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env54269 == env54270) = true)

theorem identity54270 : scanCanonicalize (H12AffineFastState.compose env54270 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound54270 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,62589,16,41311,8192,64,409956,57677,17665,442385,61704,62589,256,41341,16464,513]

theorem envBound54271 : H12AffineFastState.Bounded env54271 := by
  intro p hp
  have h : env54271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54270_54271 : H12AffineEnvironment.transform 15 54359 env54270 = env54271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env54270 == env54271) = true)

def env54272 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,262144,1024,32769,4112,62509,16,41231,8192,16,409908,57629,17665,442385,61704,62509,256,41261,16384,513]

theorem envBound54272 : H12AffineFastState.Bounded env54272 := by
  intro p hp
  have h : env54272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54271_54272 : H12AffineEnvironment.transform 5 16 env54271 = env54272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54271 == env54272) = true)

theorem identity54272 : scanCanonicalize (H12AffineFastState.compose env54272 (packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound54272 : packedSelected [0,1,2,3,6,11,12,14,24,27,28,32,41] rootPS < 2^1333 := by decide +kernel

def env54273 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,263,131072,262144,1024,21761,4112,8493,16,29711,8192,16,409908,13341,17665,398609,9224,8493,256,29741,16384,513]

theorem envBound54273 : H12AffineFastState.Bounded env54273 := by
  intro p hp
  have h : env54273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54272_54273 : H12AffineEnvironment.transform 14 21760 env54272 = env54273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env54272 == env54273) = true)

theorem identity54273 : scanCanonicalize (H12AffineFastState.compose env54273 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound54273 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env54274 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,263,131072,32041,1024,21761,4112,8493,16,29711,8192,16,146461,13341,17665,157752,9224,8493,256,29741,16384,513]

theorem envBound54274 : H12AffineFastState.Bounded env54274 := by
  intro p hp
  have h : env54274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54273_54274 : H12AffineEnvironment.transform 17 32041 env54273 = env54274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env54273 == env54274) = true)

theorem identity54274 : scanCanonicalize (H12AffineFastState.compose env54274 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound54274 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env54275 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,21760,263,5393,32041,1024,21761,4112,8493,16,29711,8192,16,10508,13341,17665,32041,9224,8493,256,29741,16384,513]

theorem envBound54275 : H12AffineFastState.Bounded env54275 := by
  intro p hp
  have h : env54275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54274_54275 : H12AffineEnvironment.transform 16 5393 env54274 = env54275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env54274 == env54275) = true)

theorem identity54275 : scanCanonicalize (H12AffineFastState.compose env54275 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54275 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54276 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,1,263,5393,10280,1024,0,4112,8493,16,8462,8192,16,10508,13341,4096,10280,9224,8493,256,8492,5377,513]

theorem envBound54276 : H12AffineFastState.Bounded env54276 := by
  intro p hp
  have h : env54276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54275_54276 : H12AffineEnvironment.transform 13 5377 env54275 = env54276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54275 == env54276) = true)

theorem identity54276 : scanCanonicalize (H12AffineFastState.compose env54276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54277 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1024,0,4112,33,16,2,268,16,2048,5393,4096,2340,1284,33,256,32,5377,513]

theorem envBound54277 : H12AffineFastState.Bounded env54277 := by
  intro p hp
  have h : env54277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54276_54277 : H12AffineEnvironment.transform 12 268 env54276 = env54277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54276 == env54277) = true)

theorem identity54277 : scanCanonicalize (H12AffineFastState.compose env54277 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54278 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5173,2048,1024,0,4112,33,16,2,40,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound54278 : H12AffineFastState.Bounded env54278 := by
  intro p hp
  have h : env54278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54277_54278 : H12AffineEnvironment.transform 7 36 env54277 = env54278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54277 == env54278) = true)

def env54279 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,1,35,1029,2048,1024,0,32,33,16,2,40,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound54279 : H12AffineFastState.Bounded env54279 := by
  intro p hp
  have h : env54279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54278_54279 : H12AffineEnvironment.transform 11 48 env54278 = env54279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54278 == env54279) = true)

theorem identity54279 : scanCanonicalize (H12AffineFastState.compose env54279 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound54279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54280 : List Nat := [2,4,8,16,32,16,8,36,512,1024,0,48,40,1045,1,35,1029,0,1024,0,32,33,16,2,40,16,0,1029,48,0,1056,33,36,32,1045,513]

theorem envBound54280 : H12AffineFastState.Bounded env54280 := by
  intro p hp
  have h : env54280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54279_54280 : H12AffineEnvironment.transform 10 0 env54279 = env54280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env54279 == env54280) = true)

def env54281 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,48,40,33,1,35,49,0,52,0,32,33,16,2,40,16,0,49,48,0,20,33,36,32,33,513]

theorem envBound54281 : H12AffineFastState.Bounded env54281 := by
  intro p hp
  have h : env54281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54280_54281 : H12AffineEnvironment.transform 9 52 env54280 = env54281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54280 == env54281) = true)

theorem identity54281 : scanCanonicalize (H12AffineFastState.compose env54281 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54281 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54282 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,48,40,33,1,35,49,0,52,0,32,33,16,2,40,16,0,49,48,0,20,33,36,32,33,43]

theorem envBound54282 : H12AffineFastState.Bounded env54282 := by
  intro p hp
  have h : env54282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54281_54282 : H12AffineEnvironment.transform 8 42 env54281 = env54282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54281 == env54282) = true)

def leafEnv54282 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,48,40,33,1,35,49,0,52,0,32,33,16,2,20,40,1,16,0,49,48,0,20,33,36,32,4,35,33,43,1,32,0]

def active54282 : List Nat := [0,1,2,3,4]

def tree54282 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54282 : H12WitnessSearch.Good tree54282 := H12GlobalWitnessIndex.good

theorem leafIdentity54282 : H12AffineFastState.composeSystem env54282 rootObs = leafEnv54282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54282 rootObs == leafEnv54282) = true)

theorem terminalChecked54282 : H12PackedTerminal.terminalCheckFast leafEnv54282 active54282 tree54282 = true := by decide +kernel

def env54283 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,32,1,35,48,0,53,0,32,33,16,2,40,16,0,48,48,0,21,33,36,32,32,513]

theorem envBound54283 : H12AffineFastState.Bounded env54283 := by
  intro p hp
  have h : env54283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54280_54283 : H12AffineEnvironment.transform 9 53 env54280 = env54283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54280 == env54283) = true)

def leafEnv54283 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,48,40,32,1,35,48,0,53,0,32,33,16,2,21,40,1,16,0,48,48,0,21,33,36,32,4,35,32,513,1,32,0]

def active54283 : List Nat := [0,1,2,3,4,8]

def tree54283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54283 : H12WitnessSearch.Good tree54283 := H12GlobalWitnessIndex.good

theorem leafIdentity54283 : H12AffineFastState.composeSystem env54283 rootObs = leafEnv54283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54283 rootObs == leafEnv54283) = true)

theorem terminalChecked54283 : H12PackedTerminal.terminalCheckFast leafEnv54283 active54283 tree54283 = true := by decide +kernel

def env54284 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,1,35,1028,2048,1024,0,33,33,16,2,40,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound54284 : H12AffineFastState.Bounded env54284 := by
  intro p hp
  have h : env54284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54278_54284 : H12AffineEnvironment.transform 11 49 env54278 = env54284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54278 == env54284) = true)

theorem identity54284 : scanCanonicalize (H12AffineFastState.compose env54284 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound54284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54285 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1076,49,40,1044,1,35,1028,1076,1024,0,33,33,16,2,40,16,1076,1028,49,1076,1056,33,36,32,1044,513]

theorem envBound54285 : H12AffineFastState.Bounded env54285 := by
  intro p hp
  have h : env54285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54284_54285 : H12AffineEnvironment.transform 10 1076 env54284 = env54285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env54284 == env54285) = true)

def env54286 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,49,40,32,1,35,48,0,52,0,33,33,16,2,40,16,0,48,49,0,20,33,36,32,32,513]

theorem envBound54286 : H12AffineFastState.Bounded env54286 := by
  intro p hp
  have h : env54286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54285_54286 : H12AffineEnvironment.transform 9 52 env54285 = env54286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54285 == env54286) = true)

theorem identity54286 : scanCanonicalize (H12AffineFastState.compose env54286 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54287 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,49,40,32,1,35,48,0,52,0,33,33,16,2,40,16,0,48,49,0,20,33,36,32,32,43]

theorem envBound54287 : H12AffineFastState.Bounded env54287 := by
  intro p hp
  have h : env54287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54286_54287 : H12AffineEnvironment.transform 8 42 env54286 = env54287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54286 == env54287) = true)

def leafEnv54287 : List Nat := [2,4,8,16,32,16,8,36,42,52,0,49,40,32,1,35,48,0,52,0,33,33,16,2,20,40,1,16,0,48,49,0,20,33,36,32,4,35,32,43,1,33,0]

def active54287 : List Nat := [0,1,2,3,4]

def tree54287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54287 : H12WitnessSearch.Good tree54287 := H12GlobalWitnessIndex.good

theorem leafIdentity54287 : H12AffineFastState.composeSystem env54287 rootObs = leafEnv54287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54287 rootObs == leafEnv54287) = true)

theorem terminalChecked54287 : H12PackedTerminal.terminalCheckFast leafEnv54287 active54287 tree54287 = true := by decide +kernel

def env54288 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,1,35,49,1,53,0,33,33,16,2,40,16,1,49,49,1,21,33,36,32,33,513]

theorem envBound54288 : H12AffineFastState.Bounded env54288 := by
  intro p hp
  have h : env54288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54285_54288 : H12AffineEnvironment.transform 9 53 env54285 = env54288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54285 == env54288) = true)

def leafEnv54288 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,49,40,33,1,35,49,1,53,0,33,33,16,2,21,40,1,16,1,49,49,1,21,33,36,32,4,35,33,513,1,33,0]

def active54288 : List Nat := [0,1,2,3,4,8]

def tree54288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54288 : H12WitnessSearch.Good tree54288 := H12GlobalWitnessIndex.good

theorem leafIdentity54288 : H12AffineFastState.composeSystem env54288 rootObs = leafEnv54288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54288 rootObs == leafEnv54288) = true)

theorem terminalChecked54288 : H12PackedTerminal.terminalCheckFast leafEnv54288 active54288 tree54288 = true := by decide +kernel

def env54289 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,262144,1024,32769,4113,62508,16,41230,8192,17,409909,57628,17665,442385,61704,62508,256,41260,16385,513]

theorem envBound54289 : H12AffineFastState.Bounded env54289 := by
  intro p hp
  have h : env54289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54271_54289 : H12AffineEnvironment.transform 5 17 env54271 = env54289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54271 == env54289) = true)

theorem identity54289 : scanCanonicalize (H12AffineFastState.compose env54289 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54289 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env54290 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,10280,1024,32769,4113,62508,16,41230,8192,17,157981,57628,17665,190521,61704,62508,256,41260,16385,513]

theorem envBound54290 : H12AffineFastState.Bounded env54290 := by
  intro p hp
  have h : env54290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54289_54290 : H12AffineEnvironment.transform 17 10280 env54289 = env54290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54289 == env54290) = true)

theorem identity54290 : scanCanonicalize (H12AffineFastState.compose env54290 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54290 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54291 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,54278,131072,2340,1024,32769,4113,54560,16,32770,268,17,149521,49168,17665,182581,53252,54560,256,32800,16385,513]

theorem envBound54291 : H12AffineFastState.Bounded env54291 := by
  intro p hp
  have h : env54291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54290_54291 : H12AffineEnvironment.transform 12 268 env54290 = env54291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54290 == env54291) = true)

theorem identity54291 : scanCanonicalize (H12AffineFastState.compose env54291 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound54291 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54292 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,54278,38161,2340,1024,32769,4113,54560,16,32770,268,17,56576,49168,17665,23588,53252,54560,256,32800,16385,513]

theorem envBound54292 : H12AffineFastState.Bounded env54292 := by
  intro p hp
  have h : env54292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54291_54292 : H12AffineEnvironment.transform 16 38161 env54291 = env54292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env54291 == env54292) = true)

def env54293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,73770,16,95497,8192,64,496946,79131,102742,442385,61705,62588,256,95531,103430,120407]

theorem envBound54293 : H12AffineFastState.Bounded env54293 := by
  intro p hp
  have h : env54293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54269_54293 : H12AffineEnvironment.transform 23 95497 env54269 = env54293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env54269 == env54293) = true)

def env54294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,115735,73770,16,95497,8192,64,382242,79131,102742,294913,61705,62588,256,95531,103430,120407]

theorem envBound54294 : H12AffineFastState.Bounded env54294 := by
  intro p hp
  have h : env54294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54293_54294 : H12AffineEnvironment.transform 16 16400 env54293 = env54294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env54293 == env54294) = true)

theorem identity54294 : scanCanonicalize (H12AffineFastState.compose env54294 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound54294 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16400,262144,1024,32769,4161,62588,16,41311,8192,64,262516,57677,17664,294913,61705,62588,256,41341,16464,513]

theorem envBound54295 : H12AffineFastState.Bounded env54295 := by
  intro p hp
  have h : env54295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54294_54295 : H12AffineEnvironment.transform 15 54358 env54294 = env54295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env54294 == env54295) = true)

theorem identity54295 : scanCanonicalize (H12AffineFastState.compose env54295 (packedSelected [1,2,3,5,6,8,10,11,19,32] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound54295 : packedSelected [1,2,3,5,6,8,10,11,19,32] rootPS < 2^1333 := by decide +kernel

def env54296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16400,64809,1024,32769,4161,62588,16,41311,8192,64,64605,57677,17664,32040,61705,62588,256,41341,16464,513]

theorem envBound54296 : H12AffineFastState.Bounded env54296 := by
  intro p hp
  have h : env54296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54295_54296 : H12AffineEnvironment.transform 17 64809 env54295 = env54296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env54295 == env54296) = true)

theorem identity54296 : scanCanonicalize (H12AffineFastState.compose env54296 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54296 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env54297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,16400,32040,1024,0,4161,29821,16,8542,8192,64,31836,24908,17664,32040,28936,29821,256,8572,16464,513]

theorem envBound54297 : H12AffineFastState.Bounded env54297 := by
  intro p hp
  have h : env54297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54296_54297 : H12AffineEnvironment.transform 14 1 env54296 = env54297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54296 == env54297) = true)

theorem identity54297 : scanCanonicalize (H12AffineFastState.compose env54297 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound54297 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env54298 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21591,16400,23668,1024,0,4161,21793,16,2,348,64,23808,16400,17664,23668,20564,21793,256,32,16464,513]

theorem envBound54298 : H12AffineFastState.Bounded env54298 := by
  intro p hp
  have h : env54298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54297_54298 : H12AffineEnvironment.transform 12 348 env54297 = env54298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env54297 == env54298) = true)

theorem identity54298 : scanCanonicalize (H12AffineFastState.compose env54298 (packedSelected [0,2,4,6,7,9,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54298 : packedSelected [0,2,4,6,7,9,18] rootPS < 2^1333 := by decide +kernel

def env54299 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,1,21591,16400,23668,1024,0,4161,21509,16,2,120,64,23588,16400,17444,23668,20564,21509,36,32,16464,513]

theorem envBound54299 : H12AffineFastState.Bounded env54299 := by
  intro p hp
  have h : env54299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54298_54299 : H12AffineEnvironment.transform 7 36 env54298 = env54299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54298 == env54299) = true)

theorem identity54299 : scanCanonicalize (H12AffineFastState.compose env54299 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54299 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env54300 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,1,21511,16400,23588,1024,0,4113,21509,16,2,40,16,23588,16400,17444,23588,20484,21509,36,32,16384,513]

theorem envBound54300 : H12AffineFastState.Bounded env54300 := by
  intro p hp
  have h : env54300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54299_54300 : H12AffineEnvironment.transform 5 16 env54299 = env54300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54299 == env54300) = true)

theorem identity54300 : scanCanonicalize (H12AffineFastState.compose env54300 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound54300 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54301 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,35,5172,2048,1024,0,4113,33,16,2,40,16,2048,5172,4096,2048,1056,33,36,32,5156,513]

theorem envBound54301 : H12AffineFastState.Bounded env54301 := by
  intro p hp
  have h : env54301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54300_54301 : H12AffineEnvironment.transform 13 5156 env54300 = env54301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env54300 == env54301) = true)

def env54302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115735,73770,16,95497,8192,64,382243,79131,102742,294912,61705,62588,256,95531,103430,120407]

theorem envBound54302 : H12AffineFastState.Bounded env54302 := by
  intro p hp
  have h : env54302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54293_54302 : H12AffineEnvironment.transform 16 16401 env54293 = env54302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env54293 == env54302) = true)

theorem identity54302 : scanCanonicalize (H12AffineFastState.compose env54302 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54302 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env54303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115735,73770,16,95497,8192,64,130315,79131,102742,43048,61705,62588,256,95531,103430,120407]

theorem envBound54303 : H12AffineFastState.Bounded env54303 := by
  intro p hp
  have h : env54303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54302_54303 : H12AffineEnvironment.transform 17 10280 env54302 = env54303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54302 == env54303) = true)

theorem identity54303 : scanCanonicalize (H12AffineFastState.compose env54303 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound54303 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,16401,10280,1024,32769,4161,62588,16,41311,8192,64,10589,57677,17664,43048,61705,62588,256,41341,16464,513]

theorem envBound54304 : H12AffineFastState.Bounded env54304 := by
  intro p hp
  have h : env54304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54303_54304 : H12AffineEnvironment.transform 15 54358 env54303 = env54304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env54303 == env54304) = true)

theorem identity54304 : scanCanonicalize (H12AffineFastState.compose env54304 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54304 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,21590,16401,10280,1024,1,4161,29820,16,8543,8192,64,10589,24909,17664,10280,28937,29820,256,8573,16464,513]

theorem envBound54305 : H12AffineFastState.Bounded env54305 := by
  intro p hp
  have h : env54305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54304_54305 : H12AffineEnvironment.transform 14 0 env54304 = env54305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54304 == env54305) = true)

def env54306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,16777216,8193,64,17227835,18973700,102742,2556934,18890775,16875892,256,16777251,16834831,18966344]

theorem envBound54306 : H12AffineFastState.Bounded env54306 := by
  intro p hp
  have h : env54306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54267_54306 : H12AffineEnvironment.transform 6 9 env54267 = env54306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54267 == env54306) = true)

theorem identity54306 : scanCanonicalize (H12AffineFastState.compose env54306 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2327556) := by decide +kernel

theorem selectedBound54306 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env54307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2155581,2212871,2327556,8193,64,2450495,131072,102742,2556934,246803,2229616,256,2327591,2319627,189260]

theorem envBound54307 : H12AffineFastState.Bounded env54307 := by
  intro p hp
  have h : env54307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54306_54307 : H12AffineEnvironment.transform 23 2327556 env54306 = env54307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2327556 env54306 == env54307) = true)

theorem identity54307 : scanCanonicalize (H12AffineFastState.compose env54307 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound54307 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,262144,1024,32769,2097152,2155581,2114897,2229586,8193,64,2418025,131072,4096,2524496,148805,2229616,256,2229617,2286685,189260]

theorem envBound54308 : H12AffineFastState.Bounded env54308 := by
  intro p hp
  have h : env54308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54307_54308 : H12AffineEnvironment.transform 15 33110 env54307 = env54308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env54307 == env54308) = true)

theorem identity54308 : scanCanonicalize (H12AffineFastState.compose env54308 (packedSelected [11,15,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound54308 : packedSelected [11,15,32,38] rootPS < 2^1333 := by decide +kernel

def env54309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,24861,262144,1024,32769,2097152,2155581,2114897,2122831,8193,64,2418025,24861,4096,2417741,9304,2122861,256,2122860,2131264,33361]

theorem envBound54309 : H12AffineFastState.Bounded env54309 := by
  intro p hp
  have h : env54309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54308_54309 : H12AffineEnvironment.transform 16 24861 env54308 = env54309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env54308 == env54309) = true)

theorem identity54309 : scanCanonicalize (H12AffineFastState.compose env54309 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound54309 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env54310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,24861,43129,1024,32769,2097152,2155581,2114897,2122831,8193,64,2116880,24861,4096,2116660,9304,2122861,256,2122860,2131264,33361]

theorem envBound54310 : H12AffineFastState.Bounded env54310 := by
  intro p hp
  have h : env54310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54309_54310 : H12AffineEnvironment.transform 17 43129 env54309 = env54310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env54309 == env54310) = true)

theorem identity54310 : scanCanonicalize (H12AffineFastState.compose env54310 (packedSelected [1,2,6,8,10,14,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound54310 : packedSelected [1,2,6,8,10,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,32768,33110,5220,43129,1024,32769,2097152,2134340,2109480,2101558,8193,64,2111593,5220,4096,2111821,9304,2101524,256,2101525,2131264,33361]

theorem envBound54311 : H12AffineFastState.Bounded env54311 := by
  intro p hp
  have h : env54311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54310_54311 : H12AffineEnvironment.transform 13 13689 env54310 = env54311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env54310 == env54311) = true)

theorem identity54311 : scanCanonicalize (H12AffineFastState.compose env54311 (packedSelected [4,9,14,16,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54311 : packedSelected [4,9,14,16,21] rootPS < 2^1333 := by decide +kernel

def env54312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33110,5220,35188,1024,32769,2097152,2134340,2101541,2101558,268,64,2103652,5220,4096,2103360,1365,2101524,256,2101525,2131264,33361]

theorem envBound54312 : H12AffineFastState.Bounded env54312 := by
  intro p hp
  have h : env54312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54311_54312 : H12AffineEnvironment.transform 12 269 env54311 = env54312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54311 == env54312) = true)

theorem identity54312 : scanCanonicalize (H12AffineFastState.compose env54312 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(20+1) ^^^ 37221) := by decide +kernel

theorem selectedBound54312 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5236,32768,33110,5220,35188,1024,32769,37221,33,32832,32851,268,64,34817,5220,4096,35109,1365,32881,256,32880,5157,33361]

theorem envBound54313 : H12AffineFastState.Bounded env54313 := by
  intro p hp
  have h : env54313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54312_54313 : H12AffineEnvironment.transform 20 37221 env54312 = env54313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37221 env54312 == env54313) = true)

theorem identity54313 : scanCanonicalize (H12AffineFastState.compose env54313 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54313 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env54314 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,32768,32803,5220,34817,1024,32769,36880,33,32832,32851,121,64,34817,5220,4096,34896,1056,32881,117,32880,5157,33361]

theorem envBound54314 : H12AffineFastState.Bounded env54314 := by
  intro p hp
  have h : env54314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54313_54314 : H12AffineEnvironment.transform 7 117 env54313 = env54314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54313 == env54314) = true)

theorem identity54314 : scanCanonicalize (H12AffineFastState.compose env54314 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound54314 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env54315 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,80,115,5220,2129,1024,81,4160,33,16,3,121,64,2129,5220,4096,2048,1056,33,117,32,5157,513]

theorem envBound54315 : H12AffineFastState.Bounded env54315 := by
  intro p hp
  have h : env54315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54314_54315 : H12AffineEnvironment.transform 14 80 env54314 = env54315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env54314 == env54315) = true)

theorem identity54315 : scanCanonicalize (H12AffineFastState.compose env54315 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound54315 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54316 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,120,4113,80,115,4097,2129,101,81,4160,33,16,3,121,64,2129,4097,4096,2048,69,33,117,32,4160,513]

theorem envBound54316 : H12AffineFastState.Bounded env54316 := by
  intro p hp
  have h : env54316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54315_54316 : H12AffineEnvironment.transform 9 101 env54315 = env54316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env54315 == env54316) = true)

theorem identity54316 : scanCanonicalize (H12AffineFastState.compose env54316 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54317 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,1,34,4097,2048,52,0,4113,33,16,3,40,17,2048,4097,4096,2048,20,33,36,32,4113,513]

theorem envBound54317 : H12AffineFastState.Bounded env54317 := by
  intro p hp
  have h : env54317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54316_54317 : H12AffineEnvironment.transform 5 17 env54316 = env54317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54316 == env54317) = true)

theorem identity54317 : scanCanonicalize (H12AffineFastState.compose env54317 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound54317 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54318 : List Nat := [2,4,8,16,32,17,9,36,512,52,513,4096,41,4113,1,34,4097,513,52,0,4113,33,16,3,40,17,513,4097,4096,513,20,33,36,32,4113,513]

theorem envBound54318 : H12AffineFastState.Bounded env54318 := by
  intro p hp
  have h : env54318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54317_54318 : H12AffineEnvironment.transform 10 513 env54317 = env54318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env54317 == env54318) = true)

theorem identity54318 : scanCanonicalize (H12AffineFastState.compose env54318 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound54318 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54319 : List Nat := [2,4,8,16,32,17,9,36,11,52,10,4096,41,4113,1,34,4097,10,52,0,4113,33,16,3,40,17,10,4097,4096,10,20,33,36,32,4113,10]

theorem envBound54319 : H12AffineFastState.Bounded env54319 := by
  intro p hp
  have h : env54319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54318_54319 : H12AffineEnvironment.transform 8 11 env54318 = env54319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env54318 == env54319) = true)

def env54320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound54320 : H12AffineFastState.Bounded env54320 := by
  intro p hp
  have h : env54320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54190_54320 : H12AffineEnvironment.transform 18 1025 env54190 = env54320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env54190 == env54320) = true)

theorem identity54320 : scanCanonicalize (H12AffineFastState.compose env54320 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2237574) := by decide +kernel

theorem selectedBound54320 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2237574,8328,64,15066246,237578,10507601,8830976,10723478,4407622,257,8642602,8585614,10651457]

theorem envBound54321 : H12AffineFastState.Bounded env54321 := by
  intro p hp
  have h : env54321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54320_54321 : H12AffineEnvironment.transform 23 2237574 env54320 = env54321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2237574 env54320 == env54321) = true)

def env54322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15066246,115150,10507601,8692164,10600786,4268162,257,8487406,8478794,10544773]

theorem envBound54322 : H12AffineFastState.Bounded env54322 := by
  intro p hp
  have h : env54322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54321_54322 : H12AffineEnvironment.transform 16 25028 env54321 = env54322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env54321 == env54322) = true)

def env54323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4584662,115150,17665,2404756,119042,4268162,257,2199998,2191386,63189]

theorem envBound54323 : H12AffineFastState.Bounded env54323 := by
  intro p hp
  have h : env54323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54322_54323 : H12AffineEnvironment.transform 22 2101328 env54322 = env54323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env54322 == env54323) = true)

def env54324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,121942,115150,17665,2404756,119042,329730,257,2199998,2191386,63189]

theorem envBound54324 : H12AffineFastState.Bounded env54324 := by
  intro p hp
  have h : env54324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54323_54324 : H12AffineEnvironment.transform 21 272512 env54323 = env54324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54323 == env54324) = true)

def env54325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,121942,115014,17665,2404636,119042,329730,257,2199862,2191386,63069]

theorem envBound54325 : H12AffineFastState.Bounded env54325 := by
  intro p hp
  have h : env54325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54324_54325 : H12AffineEnvironment.transform 6 8 env54324 = env54325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54324 == env54325) = true)

def env54326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,272392,16,21762,8192,64,121942,115014,17665,303452,119042,329730,257,98678,90202,63069]

theorem envBound54326 : H12AffineFastState.Bounded env54326 := by
  intro p hp
  have h : env54326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54325_54326 : H12AffineEnvironment.transform 20 4160 env54325 = env54326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54325 == env54326) = true)

theorem identity54326 : scanCanonicalize (H12AffineFastState.compose env54326 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54326 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1025,8541,4160,272392,16,21762,8192,64,97546,90138,17665,262144,94302,329730,257,73770,90202,22273]

theorem envBound54327 : H12AffineFastState.Bounded env54327 := by
  intro p hp
  have h : env54327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54326_54327 : H12AffineEnvironment.transform 14 8540 env54326 = env54327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54326 == env54327) = true)

theorem identity54327 : scanCanonicalize (H12AffineFastState.compose env54327 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound54327 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,2421,1025,8541,4160,8573,16,21762,8192,64,97546,90138,17665,2421,94302,65911,257,73770,90202,22273]

theorem envBound54328 : H12AffineFastState.Bounded env54328 := by
  intro p hp
  have h : env54328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54327_54328 : H12AffineEnvironment.transform 17 2421 env54327 = env54328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env54327 == env54328) = true)

theorem identity54328 : scanCanonicalize (H12AffineFastState.compose env54328 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound54328 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env54329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30043,24908,2421,1025,8541,4160,8573,16,21762,8192,64,2129,5441,17665,2421,1285,29740,257,21873,5377,22273]

theorem envBound54329 : H12AffineFastState.Bounded env54329 := by
  intro p hp
  have h : env54329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54328_54329 : H12AffineEnvironment.transform 15 30043 env54328 = env54329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env54328 == env54329) = true)

theorem identity54329 : scanCanonicalize (H12AffineFastState.compose env54329 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound54329 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env54330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,8540,35,5172,2421,1025,8541,4160,8573,16,8314,8192,64,2129,5441,12409,2421,1285,340,257,8201,5377,8825]

theorem envBound54330 : H12AffineFastState.Bounded env54330 := by
  intro p hp
  have h : env54330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54329_54330 : H12AffineEnvironment.transform 13 13688 env54329 = env54330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env54329 == env54330) = true)

theorem identity54330 : scanCanonicalize (H12AffineFastState.compose env54330 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54330 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5457,373,35,5172,2421,1025,372,4160,340,16,83,41,64,2129,5441,4176,2421,1285,340,257,32,5377,592]

theorem envBound54331 : H12AffineFastState.Bounded env54331 := by
  intro p hp
  have h : env54331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54330_54331 : H12AffineEnvironment.transform 12 41 env54330 = env54331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54330 == env54331) = true)

theorem identity54331 : scanCanonicalize (H12AffineFastState.compose env54331 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54331 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54332 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5237,81,35,5172,2129,1025,80,4160,112,16,83,41,64,2129,5221,4176,2129,1057,112,37,32,5157,592]

theorem envBound54332 : H12AffineFastState.Bounded env54332 := by
  intro p hp
  have h : env54332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54331_54332 : H12AffineEnvironment.transform 7 36 env54331 = env54332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54331 == env54332) = true)

theorem identity54332 : scanCanonicalize (H12AffineFastState.compose env54332 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound54332 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54333 : List Nat := [2,4,8,16,32,64,8,36,512,1024,10,4096,41,5237,81,35,5172,91,1025,80,4160,112,16,83,41,64,91,5221,4176,91,1057,112,37,32,5157,592]

theorem envBound54333 : H12AffineFastState.Bounded env54333 := by
  intro p hp
  have h : env54333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54332_54333 : H12AffineEnvironment.transform 10 10 env54332 = env54333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env54332 == env54333) = true)

theorem identity54333 : scanCanonicalize (H12AffineFastState.compose env54333 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound54333 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54334 : List Nat := [2,4,8,16,32,64,8,36,512,1024,10,32,41,1109,81,35,1044,91,1025,80,96,112,16,83,41,64,91,1093,112,91,1057,112,37,32,1029,592]

theorem envBound54334 : H12AffineFastState.Bounded env54334 := by
  intro p hp
  have h : env54334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54333_54334 : H12AffineEnvironment.transform 11 32 env54333 = env54334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env54333 == env54334) = true)

theorem identity54334 : scanCanonicalize (H12AffineFastState.compose env54334 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54334 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env54335 : List Nat := [2,4,8,16,32,64,8,36,512,53,10,32,41,96,81,35,33,91,52,80,96,112,16,83,41,64,91,112,112,91,20,112,37,32,48,592]

theorem envBound54335 : H12AffineFastState.Bounded env54335 := by
  intro p hp
  have h : env54335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54334_54335 : H12AffineEnvironment.transform 9 53 env54334 = env54335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54334 == env54335) = true)

theorem identity54335 : scanCanonicalize (H12AffineFastState.compose env54335 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 46) := by decide +kernel

theorem selectedBound54335 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env54336 : List Nat := [2,4,8,16,32,46,8,36,512,53,10,32,41,14,63,35,33,53,52,62,14,30,16,61,41,46,53,30,30,53,20,30,37,32,48,574]

theorem envBound54336 : H12AffineFastState.Bounded env54336 := by
  intro p hp
  have h : env54336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54335_54336 : H12AffineEnvironment.transform 5 46 env54335 = env54336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 46 env54335 == env54336) = true)

theorem identity54336 : scanCanonicalize (H12AffineFastState.compose env54336 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54336 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54337 : List Nat := [2,4,8,16,1,15,8,5,512,20,10,1,8,14,30,2,0,20,21,31,14,30,16,28,8,15,20,30,30,20,20,30,4,1,17,543]

theorem envBound54337 : H12AffineFastState.Bounded env54337 := by
  intro p hp
  have h : env54337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54336_54337 : H12AffineEnvironment.transform 4 1 env54336 = env54337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54336 == env54337) = true)

theorem identity54337 : scanCanonicalize (H12AffineFastState.compose env54337 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound54337 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54338 : List Nat := [2,4,8,15,1,15,8,5,512,11,10,1,8,14,1,2,0,11,10,0,14,1,15,3,8,15,11,1,1,11,11,1,4,1,14,512]

theorem envBound54338 : H12AffineFastState.Bounded env54338 := by
  intro p hp
  have h : env54338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54337_54338 : H12AffineEnvironment.transform 3 15 env54337 = env54338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env54337 == env54338) = true)

theorem identity54338 : scanCanonicalize (H12AffineFastState.compose env54338 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54339 : List Nat := [2,0,8,11,1,11,8,1,512,11,10,1,8,10,1,2,0,11,10,0,10,1,11,3,8,11,11,1,1,11,11,1,0,1,10,512]

theorem envBound54339 : H12AffineFastState.Bounded env54339 := by
  intro p hp
  have h : env54339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54338_54339 : H12AffineEnvironment.transform 1 0 env54338 = env54339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54338 == env54339) = true)

theorem identity54339 : scanCanonicalize (H12AffineFastState.compose env54339 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound54339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54340 : List Nat := [2,0,8,11,1,11,8,1,8,11,10,1,8,10,1,2,0,11,10,0,10,1,11,3,8,11,11,1,1,11,11,1,0,1,10,8]

theorem envBound54340 : H12AffineFastState.Bounded env54340 := by
  intro p hp
  have h : env54340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54339_54340 : H12AffineEnvironment.transform 8 8 env54339 = env54340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env54339 == env54340) = true)

theorem identity54340 : scanCanonicalize (H12AffineFastState.compose env54340 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54340 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54341 : List Nat := [2,0,2,1,1,1,2,1,2,1,0,1,2,0,1,2,0,1,0,0,0,1,1,3,2,1,1,1,1,1,1,1,0,1,0,2]

theorem envBound54341 : H12AffineFastState.Bounded env54341 := by
  intro p hp
  have h : env54341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54340_54341 : H12AffineEnvironment.transform 2 2 env54340 = env54341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54340 == env54341) = true)

def env54342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272392,17,21763,8192,64,121942,115014,17665,303453,119042,329730,257,98679,90203,63069]

theorem envBound54342 : H12AffineFastState.Bounded env54342 := by
  intro p hp
  have h : env54342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54325_54342 : H12AffineEnvironment.transform 20 4161 env54325 = env54342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54325 == env54342) = true)

theorem identity54342 : scanCanonicalize (H12AffineFastState.compose env54342 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound54342 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4161,41341,17,21763,8192,64,121942,115014,17665,10280,119042,98679,257,98679,90203,63069]

theorem envBound54343 : H12AffineFastState.Bounded env54343 := by
  intro p hp
  have h : env54343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54342_54343 : H12AffineEnvironment.transform 17 35189 env54342 = env54343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env54342 == env54343) = true)

theorem identity54343 : scanCanonicalize (H12AffineFastState.compose env54343 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54343 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,65536,5392,35189,1025,32769,4161,41341,17,8543,8192,64,108554,111898,12637,10280,107870,98679,257,98679,70663,33281]

theorem envBound54344 : H12AffineFastState.Bounded env54344 := by
  intro p hp
  have h : env54344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54343_54344 : H12AffineEnvironment.transform 13 13404 env54343 = env54344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54343 == env54344) = true)

theorem identity54344 : scanCanonicalize (H12AffineFastState.compose env54344 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound54344 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,5392,35189,1025,32769,4161,41341,17,8543,8192,64,43357,46157,12637,10280,41993,32800,257,32800,5456,33281]

theorem envBound54345 : H12AffineFastState.Bounded env54345 := by
  intro p hp
  have h : env54345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54344_54345 : H12AffineEnvironment.transform 15 343 env54344 = env54345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env54344 == env54345) = true)

theorem identity54345 : scanCanonicalize (H12AffineFastState.compose env54345 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54345 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,343,5392,2421,1025,1,4161,8573,17,8543,8192,64,10589,13389,12637,10280,9225,32,257,32,5456,513]

theorem envBound54346 : H12AffineFastState.Bounded env54346 := by
  intro p hp
  have h : env54346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54345_54346 : H12AffineEnvironment.transform 14 0 env54345 = env54346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54345 == env54346) = true)

theorem identity54346 : scanCanonicalize (H12AffineFastState.compose env54346 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound54346 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,4113,0,343,5392,2421,1025,1,4161,1328,17,1298,1101,64,3344,4096,5392,3173,68,32,257,32,5456,513]

theorem envBound54347 : H12AffineFastState.Bounded env54347 := by
  intro p hp
  have h : env54347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54346_54347 : H12AffineEnvironment.transform 12 1101 env54346 = env54347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env54346 == env54347) = true)

theorem identity54347 : scanCanonicalize (H12AffineFastState.compose env54347 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54347 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env54348 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,121,4113,0,343,4388,2421,53,1,4161,260,17,294,121,64,2340,4096,4388,2129,68,32,257,32,4452,513]

theorem envBound54348 : H12AffineFastState.Bounded env54348 := by
  intro p hp
  have h : env54348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54347_54348 : H12AffineEnvironment.transform 9 52 env54347 = env54348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54347 == env54348) = true)

theorem identity54348 : scanCanonicalize (H12AffineFastState.compose env54348 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound54348 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54349 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,17,121,0,0,343,309,2421,53,1,80,260,17,294,121,64,2340,17,309,2129,68,32,257,32,373,513]

theorem envBound54349 : H12AffineFastState.Bounded env54349 := by
  intro p hp
  have h : env54349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54348_54349 : H12AffineEnvironment.transform 11 17 env54348 = env54349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54348 == env54349) = true)

theorem identity54349 : scanCanonicalize (H12AffineFastState.compose env54349 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound54349 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env54350 : List Nat := [2,4,8,16,32,64,8,256,373,52,2048,17,121,0,0,343,309,2421,53,1,80,260,17,294,121,64,2340,17,309,2129,68,32,257,32,373,372]

theorem envBound54350 : H12AffineFastState.Bounded env54350 := by
  intro p hp
  have h : env54350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54349_54350 : H12AffineEnvironment.transform 8 373 env54349 = env54350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env54349 == env54350) = true)

theorem identity54350 : scanCanonicalize (H12AffineFastState.compose env54350 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound54350 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env54351 : List Nat := [2,4,8,16,32,64,8,256,373,52,340,17,121,0,0,343,309,33,53,1,80,260,17,294,121,64,112,17,309,261,68,32,257,32,373,372]

theorem envBound54351 : H12AffineFastState.Bounded env54351 := by
  intro p hp
  have h : env54351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54350_54351 : H12AffineEnvironment.transform 10 340 env54350 = env54351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env54350 == env54351) = true)

theorem identity54351 : scanCanonicalize (H12AffineFastState.compose env54351 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54351 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env54352 : List Nat := [2,4,8,16,32,64,8,117,0,52,33,17,121,0,0,34,64,33,53,1,80,113,17,83,121,64,112,17,64,112,68,32,116,32,0,1]

theorem envBound54352 : H12AffineFastState.Bounded env54352 := by
  intro p hp
  have h : env54352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54351_54352 : H12AffineEnvironment.transform 7 117 env54351 = env54352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54351 == env54352) = true)

theorem identity54352 : scanCanonicalize (H12AffineFastState.compose env54352 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound54352 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54353 : List Nat := [2,4,8,16,32,1,8,52,0,52,33,17,56,0,0,34,1,33,53,1,17,48,17,18,56,1,49,17,1,49,5,32,53,32,0,1]

theorem envBound54353 : H12AffineFastState.Bounded env54353 := by
  intro p hp
  have h : env54353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54352_54353 : H12AffineEnvironment.transform 5 1 env54352 = env54353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54352 == env54353) = true)

theorem identity54353 : scanCanonicalize (H12AffineFastState.compose env54353 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54353 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54354 : List Nat := [2,4,8,0,32,1,8,36,0,36,33,1,40,0,0,34,1,33,37,1,1,32,1,2,40,1,33,1,1,33,5,32,37,32,0,1]

theorem envBound54354 : H12AffineFastState.Bounded env54354 := by
  intro p hp
  have h : env54354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54353_54354 : H12AffineEnvironment.transform 3 0 env54353 = env54354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54353 == env54354) = true)

def env54355 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,121942,115015,17665,2404637,119042,329730,257,2199863,2191386,63068]

theorem envBound54355 : H12AffineFastState.Bounded env54355 := by
  intro p hp
  have h : env54355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54324_54355 : H12AffineEnvironment.transform 6 9 env54324 = env54355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54324 == env54355) = true)

def env54356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,272393,16,21762,8193,64,121942,115015,17665,303453,119042,329730,257,98679,90202,63068]

theorem envBound54356 : H12AffineFastState.Bounded env54356 := by
  intro p hp
  have h : env54356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54355_54356 : H12AffineEnvironment.transform 20 4160 env54355 = env54356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54355 == env54356) = true)

theorem identity54356 : scanCanonicalize (H12AffineFastState.compose env54356 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound54356 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54357 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67619,1025,32769,4160,73770,16,21762,8193,64,121942,115015,17665,108926,119042,33,257,98679,90202,63068]

theorem envBound54357 : H12AffineFastState.Bounded env54357 := by
  intro p hp
  have h : env54357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54356_54357 : H12AffineEnvironment.transform 17 67619 env54356 = env54357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env54356 == env54357) = true)

theorem identity54357 : scanCanonicalize (H12AffineFastState.compose env54357 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound54357 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54358 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,24909,64808,1025,32769,4160,54561,16,21762,8193,64,10589,13388,17665,23669,9225,33,257,29820,38225,63068]

theorem envBound54358 : H12AffineFastState.Bounded env54358 := by
  intro p hp
  have h : env54358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54357_54358 : H12AffineEnvironment.transform 15 62731 env54357 = env54358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env54357 == env54358) = true)

theorem identity54358 : scanCanonicalize (H12AffineFastState.compose env54358 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound54358 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env54359 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,29963,24909,32040,1025,1,4160,21793,16,21762,8193,64,10589,13388,17665,23669,9225,33,257,29820,5457,30300]

theorem envBound54359 : H12AffineFastState.Bounded env54359 := by
  intro p hp
  have h : env54359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54358_54359 : H12AffineEnvironment.transform 14 0 env54358 = env54359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env54358 == env54359) = true)

theorem identity54359 : scanCanonicalize (H12AffineFastState.compose env54359 (packedSelected [3,5,7,10,12,14,15,16,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54359 : packedSelected [3,5,7,10,12,14,15,16,27] rootPS < 2^1333 := by decide +kernel

def env54360 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,0,8202,13388,10281,1025,1,4160,32,16,3,8193,64,10589,13388,4096,2420,9225,33,257,8573,5457,9053]

theorem envBound54360 : H12AffineFastState.Bounded env54360 := by
  intro p hp
  have h : env54360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54359_54360 : H12AffineEnvironment.transform 13 5377 env54359 = env54360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54359 == env54360) = true)

theorem identity54360 : scanCanonicalize (H12AffineFastState.compose env54360 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54360 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env54361 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4113,0,8202,12636,10281,273,1,4160,32,16,3,8193,64,10589,12636,4096,2420,8473,33,257,8573,4161,9053]

theorem envBound54361 : H12AffineFastState.Bounded env54361 := by
  intro p hp
  have h : env54361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54360_54361 : H12AffineEnvironment.transform 9 272 env54360 = env54361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54360 == env54361) = true)

theorem identity54361 : scanCanonicalize (H12AffineFastState.compose env54361 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54361 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54362 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,41,4113,0,35,4469,2048,273,1,4160,32,16,3,40,64,2420,4469,4096,2420,304,33,257,340,4161,884]

theorem envBound54362 : H12AffineFastState.Bounded env54362 := by
  intro p hp
  have h : env54362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54361_54362 : H12AffineEnvironment.transform 12 41 env54361 = env54362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54361 == env54362) = true)

theorem identity54362 : scanCanonicalize (H12AffineFastState.compose env54362 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54362 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54363 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4113,0,35,4388,2048,273,1,4113,32,16,3,40,17,2341,4388,4096,2341,304,33,257,261,4112,805]

theorem envBound54363 : H12AffineFastState.Bounded env54363 := by
  intro p hp
  have h : env54363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54362_54363 : H12AffineEnvironment.transform 5 17 env54362 = env54363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54362 == env54363) = true)

theorem identity54363 : scanCanonicalize (H12AffineFastState.compose env54363 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound54363 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54364 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,2357,41,2340,0,35,2065,2048,273,1,2340,32,16,3,40,17,2341,2065,2357,2341,304,33,257,261,2341,805]

theorem envBound54364 : H12AffineFastState.Bounded env54364 := by
  intro p hp
  have h : env54364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54363_54364 : H12AffineEnvironment.transform 11 2357 env54363 = env54364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env54363 == env54364) = true)

theorem identity54364 : scanCanonicalize (H12AffineFastState.compose env54364 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54364 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54365 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2065,41,2048,0,35,2065,2048,53,1,2048,32,16,3,40,17,2049,2065,2065,2049,20,33,37,33,2049,513]

theorem envBound54365 : H12AffineFastState.Bounded env54365 := by
  intro p hp
  have h : env54365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54364_54365 : H12AffineEnvironment.transform 7 36 env54364 = env54365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54364 == env54365) = true)

theorem identity54365 : scanCanonicalize (H12AffineFastState.compose env54365 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound54365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54366 : List Nat := [2,4,8,16,32,17,9,36,512,52,17,0,41,17,0,35,0,17,53,1,17,32,16,3,40,17,16,0,0,16,20,33,37,33,16,513]

theorem envBound54366 : H12AffineFastState.Bounded env54366 := by
  intro p hp
  have h : env54366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54365_54366 : H12AffineEnvironment.transform 10 17 env54365 = env54366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env54365 == env54366) = true)

theorem identity54366 : scanCanonicalize (H12AffineFastState.compose env54366 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54366 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54367 : List Nat := [2,4,8,16,11,17,9,15,512,31,17,0,2,17,0,8,0,17,30,1,17,11,16,3,3,17,16,0,0,16,20,10,14,10,16,513]

theorem envBound54367 : H12AffineFastState.Bounded env54367 := by
  intro p hp
  have h : env54367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54366_54367 : H12AffineEnvironment.transform 4 11 env54366 = env54367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54366 == env54367) = true)

def env54368 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272393,17,21763,8193,64,121942,115015,17665,303452,119042,329730,257,98678,90203,63068]

theorem envBound54368 : H12AffineFastState.Bounded env54368 := by
  intro p hp
  have h : env54368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54355_54368 : H12AffineEnvironment.transform 20 4161 env54355 = env54368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54355 == env54368) = true)

theorem identity54368 : scanCanonicalize (H12AffineFastState.compose env54368 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54368 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,4161,33,17,21763,8193,64,121942,115015,17665,35188,119042,73770,257,98678,90203,63068]

theorem envBound54369 : H12AffineFastState.Bounded env54369 := by
  intro p hp
  have h : env54369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54368_54369 : H12AffineEnvironment.transform 17 10280 env54368 = env54369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54368 == env54369) = true)

theorem identity54369 : scanCanonicalize (H12AffineFastState.compose env54369 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound54369 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env54370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,24909,10280,1025,32769,4161,33,17,21763,8193,64,31837,24908,17665,35188,28937,32801,257,8573,49232,63068]

theorem envBound54370 : H12AffineFastState.Bounded env54370 := by
  intro p hp
  have h : env54370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54369_54370 : H12AffineEnvironment.transform 15 40971 env54369 = env54370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env54369 == env54370) = true)

theorem identity54370 : scanCanonicalize (H12AffineFastState.compose env54370 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound54370 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54371 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,24909,10280,1025,29788,4161,33,17,21763,8193,64,31837,24908,17665,32041,28937,29820,257,8573,13325,513]

theorem envBound54371 : H12AffineFastState.Bounded env54371 := by
  intro p hp
  have h : env54371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54370_54371 : H12AffineEnvironment.transform 14 29789 env54370 = env54371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env54370 == env54371) = true)

theorem identity54371 : scanCanonicalize (H12AffineFastState.compose env54371 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54371 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54372 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,343,13388,10280,1025,8541,4161,33,17,2,8193,64,10588,13389,4096,10280,9224,8573,257,8573,13325,513]

theorem envBound54372 : H12AffineFastState.Bounded env54372 := by
  intro p hp
  have h : env54372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54371_54372 : H12AffineEnvironment.transform 13 5377 env54371 = env54372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54371 == env54372) = true)

def env54373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,121943,115150,17665,2404756,119042,329731,257,2199998,2191386,63189]

theorem envBound54373 : H12AffineFastState.Bounded env54373 := by
  intro p hp
  have h : env54373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54323_54373 : H12AffineEnvironment.transform 21 272513 env54323 = env54373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env54323 == env54373) = true)

theorem identity54373 : scanCanonicalize (H12AffineFastState.compose env54373 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound54373 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,272513,17,21763,8328,64,121943,115150,17665,303573,119042,329731,257,98815,90203,63189]

theorem envBound54374 : H12AffineFastState.Bounded env54374 := by
  intro p hp
  have h : env54374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54373_54374 : H12AffineEnvironment.transform 20 4161 env54373 = env54374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54373 == env54374) = true)

def env54375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,272393,17,21763,8192,64,121943,115014,17665,303453,119042,329731,257,98679,90203,63069]

theorem envBound54375 : H12AffineFastState.Bounded env54375 := by
  intro p hp
  have h : env54375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54374_54375 : H12AffineEnvironment.transform 6 8 env54374 = env54375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54374 == env54375) = true)

theorem identity54375 : scanCanonicalize (H12AffineFastState.compose env54375 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound54375 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1025,32769,4161,41340,17,21763,8192,64,121943,115014,17665,10280,119042,98678,257,98679,90203,63069]

theorem envBound54376 : H12AffineFastState.Bounded env54376 := by
  intro p hp
  have h : env54376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54375_54376 : H12AffineEnvironment.transform 17 35189 env54375 = env54376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env54375 == env54376) = true)

theorem identity54376 : scanCanonicalize (H12AffineFastState.compose env54376 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound54376 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,24908,23668,1025,21760,4161,29821,17,21763,8192,64,67926,70727,17665,10280,66563,87159,257,87158,90203,9052]

theorem envBound54377 : H12AffineFastState.Bounded env54377 := by
  intro p hp
  have h : env54377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54376_54377 : H12AffineEnvironment.transform 14 21761 env54376 = env54377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env54376 == env54377) = true)

theorem identity54377 : scanCanonicalize (H12AffineFastState.compose env54377 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54377 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env54378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,16401,23668,1025,21760,4161,21792,17,21763,349,64,67926,70727,17665,2421,66563,87159,257,87158,82182,513]

theorem envBound54378 : H12AffineFastState.Bounded env54378 := by
  intro p hp
  have h : env54378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54377_54378 : H12AffineEnvironment.transform 12 349 env54377 = env54378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54377 == env54378) = true)

theorem identity54378 : scanCanonicalize (H12AffineFastState.compose env54378 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54378 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54379 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21620,65536,16401,23668,1025,21621,4161,21589,17,21622,40,64,67619,70727,17524,2048,66563,87159,116,87158,82035,513]

theorem envBound54379 : H12AffineFastState.Bounded env54379 := by
  intro p hp
  have h : env54379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54378_54379 : H12AffineEnvironment.transform 7 117 env54378 = env54379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54378 == env54379) = true)

theorem identity54379 : scanCanonicalize (H12AffineFastState.compose env54379 (packedSelected [11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound54379 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env54380 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,4112,1124,65536,4097,3172,1025,1125,4161,1093,17,1126,40,64,67619,70727,5220,2048,66563,66663,116,66662,69731,513]

theorem envBound54380 : H12AffineFastState.Bounded env54380 := by
  intro p hp
  have h : env54380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54379_54380 : H12AffineEnvironment.transform 13 4112 env54379 = env54380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env54379 == env54380) = true)

theorem identity54380 : scanCanonicalize (H12AffineFastState.compose env54380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound54380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54381 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,4112,1124,1094,4097,3172,1025,1125,4161,1093,17,1126,40,64,3173,4097,5220,2048,69,33,116,32,5157,513]

theorem envBound54381 : H12AffineFastState.Bounded env54381 := by
  intro p hp
  have h : env54381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54380_54381 : H12AffineEnvironment.transform 15 1094 env54380 = env54381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env54380 == env54381) = true)

theorem identity54381 : scanCanonicalize (H12AffineFastState.compose env54381 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3173) := by decide +kernel

theorem selectedBound54381 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54382 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,3173,40,3189,1124,1094,3172,3172,1025,1125,3108,1093,17,1126,40,64,3173,3172,2049,2048,69,33,116,32,2112,513]

theorem envBound54382 : H12AffineFastState.Bounded env54382 := by
  intro p hp
  have h : env54382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54381_54382 : H12AffineEnvironment.transform 11 3173 env54381 = env54382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3173 env54381 == env54382) = true)

theorem identity54382 : scanCanonicalize (H12AffineFastState.compose env54382 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54382 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54383 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2128,40,2112,81,115,2129,2129,52,80,2065,112,17,83,40,64,2128,2129,2049,2048,69,33,116,32,2112,513]

theorem envBound54383 : H12AffineFastState.Bounded env54383 := by
  intro p hp
  have h : env54383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54382_54383 : H12AffineEnvironment.transform 9 53 env54382 = env54383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54382 == env54383) = true)

theorem identity54383 : scanCanonicalize (H12AffineFastState.compose env54383 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54383 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54384 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2048,40,2064,1,35,2049,2049,52,0,2065,32,17,3,40,16,2048,2049,2049,2048,21,33,36,32,2064,513]

theorem envBound54384 : H12AffineFastState.Bounded env54384 := by
  intro p hp
  have h : env54384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54383_54384 : H12AffineEnvironment.transform 5 16 env54383 = env54384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54383 == env54384) = true)

theorem identity54384 : scanCanonicalize (H12AffineFastState.compose env54384 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 516) := by decide +kernel

theorem selectedBound54384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54385 : List Nat := [2,4,8,16,32,16,8,37,512,53,516,516,40,532,1,35,517,517,52,0,533,32,17,3,40,16,516,517,517,516,21,33,36,32,532,513]

theorem envBound54385 : H12AffineFastState.Bounded env54385 := by
  intro p hp
  have h : env54385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54384_54385 : H12AffineEnvironment.transform 10 516 env54384 = env54385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 516 env54384 == env54385) = true)

theorem identity54385 : scanCanonicalize (H12AffineFastState.compose env54385 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54386 : List Nat := [2,4,8,7,32,7,8,37,512,34,516,516,40,515,1,35,517,517,35,0,514,32,6,3,40,7,516,517,517,516,2,33,36,32,515,513]

theorem envBound54386 : H12AffineFastState.Bounded env54386 := by
  intro p hp
  have h : env54386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54385_54386 : H12AffineEnvironment.transform 3 7 env54385 = env54386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54385 == env54386) = true)

theorem identity54386 : scanCanonicalize (H12AffineFastState.compose env54386 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54387 : List Nat := [2,2,8,1,32,1,8,35,512,34,514,514,40,515,1,35,515,515,35,0,514,32,0,3,40,1,514,515,515,514,2,33,34,32,515,513]

theorem envBound54387 : H12AffineFastState.Bounded env54387 := by
  intro p hp
  have h : env54387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54386_54387 : H12AffineEnvironment.transform 1 2 env54386 = env54387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54386 == env54387) = true)

theorem identity54387 : scanCanonicalize (H12AffineFastState.compose env54387 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54387 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54388 : List Nat := [2,2,3,1,32,1,3,35,512,34,514,514,35,515,1,35,515,515,35,0,514,32,0,3,35,1,514,515,515,514,2,33,34,32,515,513]

theorem envBound54388 : H12AffineFastState.Bounded env54388 := by
  intro p hp
  have h : env54388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54387_54388 : H12AffineEnvironment.transform 2 3 env54387 = env54388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54387 == env54388) = true)

theorem identity54388 : scanCanonicalize (H12AffineFastState.compose env54388 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54388 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54389 : List Nat := [2,2,3,1,1,1,3,2,512,3,514,514,2,515,1,2,515,515,2,0,514,1,0,3,2,1,514,515,515,514,2,0,3,1,515,513]

theorem envBound54389 : H12AffineFastState.Bounded env54389 := by
  intro p hp
  have h : env54389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54388_54389 : H12AffineEnvironment.transform 4 1 env54388 = env54389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54388 == env54389) = true)

def env54390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,272392,17,21763,8193,64,121943,115015,17665,303452,119042,329731,257,98678,90203,63068]

theorem envBound54390 : H12AffineFastState.Bounded env54390 := by
  intro p hp
  have h : env54390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54374_54390 : H12AffineEnvironment.transform 6 9 env54374 = env54390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54374 == env54390) = true)

theorem identity54390 : scanCanonicalize (H12AffineFastState.compose env54390 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54390 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,4161,32,17,21763,8193,64,121943,115015,17665,35188,119042,73771,257,98678,90203,63068]

theorem envBound54391 : H12AffineFastState.Bounded env54391 := by
  intro p hp
  have h : env54391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54390_54391 : H12AffineEnvironment.transform 17 10280 env54390 = env54391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54390 == env54391) = true)

theorem identity54391 : scanCanonicalize (H12AffineFastState.compose env54391 (packedSelected [0,2,4,6,9,11,18,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54391 : packedSelected [0,2,4,6,9,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env54392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,65536,5393,10280,1025,32769,4161,32,17,8543,8193,64,108555,111899,12637,35188,107870,73771,257,98678,70663,33280]

theorem envBound54392 : H12AffineFastState.Bounded env54392 := by
  intro p hp
  have h : env54392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54391_54392 : H12AffineEnvironment.transform 13 13404 env54391 = env54392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54391 == env54392) = true)

theorem identity54392 : scanCanonicalize (H12AffineFastState.compose env54392 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54392 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,8202,5393,10280,1025,32769,4161,32,17,8543,8193,64,34817,38161,12637,35188,34132,33,257,41340,13325,33280]

theorem envBound54393 : H12AffineFastState.Bounded env54393 := by
  intro p hp
  have h : env54393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54392_54393 : H12AffineEnvironment.transform 15 8202 env54392 = env54393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54392 == env54393) = true)

theorem identity54393 : scanCanonicalize (H12AffineFastState.compose env54393 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54393 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env54394 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,32768,8202,5393,10280,1025,32769,4113,32,17,8463,8193,16,34817,38161,12557,35108,34052,33,257,41260,13325,33280]

theorem envBound54394 : H12AffineFastState.Bounded env54394 := by
  intro p hp
  have h : env54394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54393_54394 : H12AffineEnvironment.transform 5 16 env54393 = env54394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54393 == env54394) = true)

theorem identity54394 : scanCanonicalize (H12AffineFastState.compose env54394 (packedSelected [2,3,5,6,7,9,11,12,16] rootPS)) = affineNative (2^(14+1) ^^^ 14137) := by decide +kernel

theorem selectedBound54394 : packedSelected [2,3,5,6,7,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env54395 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,14137,8202,5393,10280,1025,14136,4113,32,17,8463,8193,16,16184,8744,12557,15901,12861,33,257,5653,13325,13625]

theorem envBound54395 : H12AffineFastState.Bounded env54395 := by
  intro p hp
  have h : env54395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54394_54395 : H12AffineEnvironment.transform 14 14137 env54394 = env54395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14137 env54394 == env54395) = true)

theorem identity54395 : scanCanonicalize (H12AffineFastState.compose env54395 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54395 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env54396 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,5685,262,5393,2340,1025,5684,4113,32,17,3,269,16,7732,804,4097,7953,4913,33,257,5653,5377,5173]

theorem envBound54396 : H12AffineFastState.Bounded env54396 := by
  intro p hp
  have h : env54396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54395_54396 : H12AffineEnvironment.transform 12 268 env54395 = env54396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54395 == env54396) = true)

theorem identity54396 : scanCanonicalize (H12AffineFastState.compose env54396 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound54396 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54397 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,268,292,529,262,309,2340,1025,528,1077,32,17,3,269,16,2576,804,1061,2869,1813,33,257,561,293,17]

theorem envBound54397 : H12AffineFastState.Bounded env54397 := by
  intro p hp
  have h : env54397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54396_54397 : H12AffineEnvironment.transform 11 1060 env54396 = env54397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env54396 == env54397) = true)

theorem identity54397 : scanCanonicalize (H12AffineFastState.compose env54397 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound54397 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54398 : List Nat := [2,4,8,16,32,16,9,256,512,1024,309,1060,268,292,529,262,309,17,1025,528,1077,32,17,3,269,16,805,804,1061,512,1813,33,257,561,293,17]

theorem envBound54398 : H12AffineFastState.Bounded env54398 := by
  intro p hp
  have h : env54398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54397_54398 : H12AffineEnvironment.transform 10 309 env54397 = env54398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env54397 == env54398) = true)

theorem identity54398 : scanCanonicalize (H12AffineFastState.compose env54398 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound54398 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env54399 : List Nat := [2,4,8,16,32,16,9,52,512,1024,1,1060,56,16,529,50,1,17,1025,528,1077,32,17,3,57,16,529,528,1061,512,1569,33,53,561,17,17]

theorem envBound54399 : H12AffineFastState.Bounded env54399 := by
  intro p hp
  have h : env54399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54398_54399 : H12AffineEnvironment.transform 7 52 env54398 = env54399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env54398 == env54399) = true)

theorem identity54399 : scanCanonicalize (H12AffineFastState.compose env54399 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound54399 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54400 : List Nat := [2,4,8,16,32,16,9,52,512,533,1,561,56,16,529,50,1,17,532,528,544,32,17,3,57,16,529,528,560,512,52,33,53,561,17,17]

theorem envBound54400 : H12AffineFastState.Bounded env54400 := by
  intro p hp
  have h : env54400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54399_54400 : H12AffineEnvironment.transform 9 533 env54399 = env54400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env54399 == env54400) = true)

theorem identity54400 : scanCanonicalize (H12AffineFastState.compose env54400 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound54400 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54401 : List Nat := [2,4,8,16,32,16,9,52,17,4,1,32,56,16,0,50,1,17,5,1,49,32,17,3,57,16,0,1,33,17,52,33,53,32,17,17]

theorem envBound54401 : H12AffineFastState.Bounded env54401 := by
  intro p hp
  have h : env54401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54400_54401 : H12AffineEnvironment.transform 8 17 env54400 = env54401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env54400 == env54401) = true)

theorem identity54401 : scanCanonicalize (H12AffineFastState.compose env54401 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound54401 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54402 : List Nat := [2,4,8,16,4,16,9,16,17,4,1,4,28,16,0,22,1,17,5,1,21,4,17,3,29,16,0,1,5,17,16,5,17,4,17,17]

theorem envBound54402 : H12AffineFastState.Bounded env54402 := by
  intro p hp
  have h : env54402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54401_54402 : H12AffineEnvironment.transform 4 4 env54401 = env54402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env54401 == env54402) = true)

theorem identity54402 : scanCanonicalize (H12AffineFastState.compose env54402 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54402 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54403 : List Nat := [2,0,8,16,0,16,9,16,17,0,1,0,24,16,0,18,1,17,1,1,17,0,17,3,25,16,0,1,1,17,16,1,17,0,17,17]

theorem envBound54403 : H12AffineFastState.Bounded env54403 := by
  intro p hp
  have h : env54403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54402_54403 : H12AffineEnvironment.transform 1 0 env54402 = env54403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54402 == env54403) = true)

theorem identity54403 : scanCanonicalize (H12AffineFastState.compose env54403 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound54403 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54404 : List Nat := [2,0,8,2,0,2,9,2,3,0,1,0,10,2,0,0,1,3,1,1,3,0,3,3,11,2,0,1,1,3,2,1,3,0,3,3]

theorem envBound54404 : H12AffineFastState.Bounded env54404 := by
  intro p hp
  have h : env54404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54403_54404 : H12AffineEnvironment.transform 3 2 env54403 = env54404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env54403 == env54404) = true)

theorem identity54404 : scanCanonicalize (H12AffineFastState.compose env54404 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54404 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54405 : List Nat := [2,0,0,2,0,2,1,2,3,0,1,0,2,2,0,0,1,3,1,1,3,0,3,3,3,2,0,1,1,3,2,1,3,0,3,3]

theorem envBound54405 : H12AffineFastState.Bounded env54405 := by
  intro p hp
  have h : env54405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54404_54405 : H12AffineEnvironment.transform 2 0 env54404 = env54405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54404 == env54405) = true)

def env54406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4584663,115150,17664,2404757,119043,4268162,257,2199999,2191387,63188]

theorem envBound54406 : H12AffineFastState.Bounded env54406 := by
  intro p hp
  have h : env54406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54322_54406 : H12AffineEnvironment.transform 22 2101329 env54322 = env54406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env54322 == env54406) = true)

def env54407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,121943,115150,17664,2404757,119043,329730,257,2199999,2191387,63188]

theorem envBound54407 : H12AffineFastState.Bounded env54407 := by
  intro p hp
  have h : env54407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54406_54407 : H12AffineEnvironment.transform 21 272512 env54406 = env54407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env54406 == env54407) = true)

theorem identity54407 : scanCanonicalize (H12AffineFastState.compose env54407 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound54407 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25028,262144,1025,29908,2097152,272512,2101329,2114882,8328,64,75906,79131,17664,2377024,75222,329730,257,2188650,2191387,513]

theorem envBound54408 : H12AffineFastState.Bounded env54408 := by
  intro p hp
  have h : env54408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54407_54408 : H12AffineEnvironment.transform 14 29909 env54407 = env54408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env54407 == env54408) = true)

def env54409 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,24980,262144,1025,29828,2097152,272512,2101249,2114834,8328,16,75906,79131,17664,2376976,75142,329730,257,2188602,2191387,513]

theorem envBound54409 : H12AffineFastState.Bounded env54409 := by
  intro p hp
  have h : env54409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54408_54409 : H12AffineEnvironment.transform 5 16 env54408 = env54409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54408 == env54409) = true)

def env54410 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,24860,262144,1025,29708,2097152,272392,2101249,2114834,8192,16,75786,79131,17664,2376976,75022,329730,257,2188602,2191387,513]

theorem envBound54410 : H12AffineFastState.Bounded env54410 := by
  intro p hp
  have h : env54410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54409_54410 : H12AffineEnvironment.transform 6 8 env54409 = env54410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54409 == env54410) = true)

theorem identity54410 : scanCanonicalize (H12AffineFastState.compose env54410 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 69683) := by decide +kernel

theorem selectedBound54410 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54411 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,24860,262144,1025,29708,69683,272392,65586,87329,8192,16,75786,79131,17664,349475,75022,329730,257,29961,24616,513]

theorem envBound54411 : H12AffineFastState.Bounded env54411 := by
  intro p hp
  have h : env54411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54410_54411 : H12AffineEnvironment.transform 20 69683 env54410 = env54411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69683 env54410 == env54411) = true)

theorem identity54411 : scanCanonicalize (H12AffineFastState.compose env54411 (packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54411 : packedSelected [0,2,3,5,6,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env54412 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,263,24860,262144,1025,29708,4404,272392,309,21542,8192,16,10509,13340,17664,283684,9225,264453,257,29961,24616,513]

theorem envBound54412 : H12AffineFastState.Bounded env54412 := by
  intro p hp
  have h : env54412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54411_54412 : H12AffineEnvironment.transform 15 263 env54411 = env54412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54411 == env54412) = true)

theorem identity54412 : scanCanonicalize (H12AffineFastState.compose env54412 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22544) := by decide +kernel

theorem selectedBound54412 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54413 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,263,24860,22544,1025,29708,4404,28696,309,21542,8192,16,10509,13340,17664,3124,9225,20757,257,29961,24616,513]

theorem envBound54413 : H12AffineFastState.Bounded env54413 := by
  intro p hp
  have h : env54413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54412_54413 : H12AffineEnvironment.transform 17 22544 env54412 = env54413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22544 env54412 == env54413) = true)

theorem identity54413 : scanCanonicalize (H12AffineFastState.compose env54413 (packedSelected [1,2,3,6,8,10,11,12,15,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54413 : packedSelected [1,2,3,6,8,10,11,12,15,23,24] rootPS < 2^1333 := by decide +kernel

def env54414 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5157,8232,263,13625,3125,1025,8233,4404,9277,309,3,8192,16,10509,13340,4389,3124,9225,1328,257,8492,13325,513]

theorem envBound54414 : H12AffineFastState.Bounded env54414 := by
  intro p hp
  have h : env54414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54413_54414 : H12AffineEnvironment.transform 13 5157 env54413 = env54414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54413 == env54414) = true)

theorem identity54414 : scanCanonicalize (H12AffineFastState.compose env54414 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54414 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54415 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4113,8232,263,12557,2049,53,8233,4404,8201,309,3,8192,16,10509,12328,4389,2048,8253,260,257,8492,12345,513]

theorem envBound54415 : H12AffineFastState.Bounded env54415 := by
  intro p hp
  have h : env54415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54414_54415 : H12AffineEnvironment.transform 9 52 env54414 = env54415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54414 == env54415) = true)

theorem identity54415 : scanCanonicalize (H12AffineFastState.compose env54415 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54415 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54416 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4113,293,263,4096,2049,53,292,4404,260,309,3,269,16,2048,4389,4389,2048,304,260,257,33,4404,513]

theorem envBound54416 : H12AffineFastState.Bounded env54416 := by
  intro p hp
  have h : env54416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54415_54416 : H12AffineEnvironment.transform 12 269 env54415 = env54416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54415 == env54416) = true)

theorem identity54416 : scanCanonicalize (H12AffineFastState.compose env54416 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound54416 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env54417 : List Nat := [2,4,8,16,32,16,8,256,512,52,292,4096,269,4113,293,263,4096,293,53,292,4404,260,309,3,269,16,292,4389,4389,292,304,260,257,33,4404,513]

theorem envBound54417 : H12AffineFastState.Bounded env54417 := by
  intro p hp
  have h : env54417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54416_54417 : H12AffineEnvironment.transform 10 292 env54416 = env54417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env54416 == env54417) = true)

theorem identity54417 : scanCanonicalize (H12AffineFastState.compose env54417 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound54417 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54418 : List Nat := [2,4,8,16,32,16,8,256,512,52,292,17,269,0,293,263,17,293,53,292,293,260,309,3,269,16,292,308,308,292,304,260,257,33,293,513]

theorem envBound54418 : H12AffineFastState.Bounded env54418 := by
  intro p hp
  have h : env54418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54417_54418 : H12AffineEnvironment.transform 11 17 env54417 = env54418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54417 == env54418) = true)

theorem identity54418 : scanCanonicalize (H12AffineFastState.compose env54418 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54418 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54419 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,17,40,0,0,34,17,0,53,1,0,33,16,3,40,16,1,17,17,1,21,33,36,33,0,513]

theorem envBound54419 : H12AffineFastState.Bounded env54419 := by
  intro p hp
  have h : env54419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54418_54419 : H12AffineEnvironment.transform 7 37 env54418 = env54419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54418 == env54419) = true)

theorem identity54419 : scanCanonicalize (H12AffineFastState.compose env54419 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound54419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54420 : List Nat := [2,4,8,16,32,16,8,37,0,52,1,17,40,0,0,34,17,0,53,1,0,33,16,3,40,16,1,17,17,1,21,33,36,33,0,1]

theorem envBound54420 : H12AffineFastState.Bounded env54420 := by
  intro p hp
  have h : env54420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54419_54420 : H12AffineEnvironment.transform 8 0 env54419 = env54420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env54419 == env54420) = true)

theorem identity54420 : scanCanonicalize (H12AffineFastState.compose env54420 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54420 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54421 : List Nat := [2,4,8,11,32,11,8,37,0,47,1,10,40,0,0,34,10,0,46,1,0,33,11,3,40,11,1,10,10,1,14,33,36,33,0,1]

theorem envBound54421 : H12AffineFastState.Bounded env54421 := by
  intro p hp
  have h : env54421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54420_54421 : H12AffineEnvironment.transform 3 11 env54420 = env54421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54420 == env54421) = true)

def env54422 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24861,262144,1025,29709,2097152,272393,2101249,2114834,8193,16,75787,79131,17664,2376976,75023,329730,257,2188602,2191387,513]

theorem envBound54422 : H12AffineFastState.Bounded env54422 := by
  intro p hp
  have h : env54422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54409_54422 : H12AffineEnvironment.transform 6 9 env54409 = env54422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54409 == env54422) = true)

theorem identity54422 : scanCanonicalize (H12AffineFastState.compose env54422 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound54422 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54423 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24861,262144,1025,29709,25628,272393,29725,8462,8193,16,75787,79131,17664,270604,75023,329730,257,65830,70663,513]

theorem envBound54423 : H12AffineFastState.Bounded env54423 := by
  intro p hp
  have h : env54423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54422_54423 : H12AffineEnvironment.transform 20 25628 env54422 = env54423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env54422 == env54423) = true)

theorem identity54423 : scanCanonicalize (H12AffineFastState.compose env54423 (packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound54423 : packedSelected [1,4,8,9,12,14,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,65536,24861,23589,1025,29709,25628,29740,29725,8462,8193,16,75787,79131,17664,32041,75023,87079,257,65830,70663,513]

theorem envBound54424 : H12AffineFastState.Bounded env54424 := by
  intro p hp
  have h : env54424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54423_54424 : H12AffineEnvironment.transform 17 23589 env54423 = env54424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env54423 == env54424) = true)

theorem identity54424 : scanCanonicalize (H12AffineFastState.compose env54424 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound54424 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54425 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8460,65536,13341,2341,1025,8461,12572,8492,8477,8462,8193,16,75787,79131,4096,10281,75023,65831,257,65830,70663,513]

theorem envBound54425 : H12AffineFastState.Bounded env54425 := by
  intro p hp
  have h : env54425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54424_54425 : H12AffineEnvironment.transform 13 5376 env54424 = env54425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env54424 == env54425) = true)

def env54426 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,262144,1025,29829,2097152,272512,2101248,2114835,8328,17,75906,79131,17664,2376977,75143,329730,257,2188603,2191387,513]

theorem envBound54426 : H12AffineFastState.Bounded env54426 := by
  intro p hp
  have h : env54426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54408_54426 : H12AffineEnvironment.transform 5 17 env54408 = env54426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54408 == env54426) = true)

theorem identity54426 : scanCanonicalize (H12AffineFastState.compose env54426 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54426 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env54427 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,24981,10280,1025,29829,2097152,168,2101248,2114835,8328,17,75906,79131,17664,2125113,75143,73770,257,2188603,2191387,513]

theorem envBound54427 : H12AffineFastState.Bounded env54427 := by
  intro p hp
  have h : env54427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54426_54427 : H12AffineEnvironment.transform 17 10280 env54426 = env54427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54426 == env54427) = true)

theorem identity54427 : scanCanonicalize (H12AffineFastState.compose env54427 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54427 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env54428 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8203,24981,10280,1025,29829,2097152,168,2101248,2114835,8328,17,2185,5392,17664,2125113,1420,33,257,2114864,2117648,513]

theorem envBound54428 : H12AffineFastState.Bounded env54428 := by
  intro p hp
  have h : env54428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54427_54428 : H12AffineEnvironment.transform 15 8203 env54427 = env54428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54427 == env54428) = true)

theorem identity54428 : scanCanonicalize (H12AffineFastState.compose env54428 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound54428 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,137,8203,5528,10280,1025,136,2097152,168,2101248,2109726,8328,17,2185,5392,12557,2103604,1420,33,257,2109757,2106397,513]

theorem envBound54429 : H12AffineFastState.Bounded env54429 := by
  intro p hp
  have h : env54429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54428_54429 : H12AffineEnvironment.transform 13 13325 env54428 = env54429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env54428 == env54429) = true)

theorem identity54429 : scanCanonicalize (H12AffineFastState.compose env54429 (packedSelected [0,7,11,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 12572) := by decide +kernel

theorem selectedBound54429 : packedSelected [0,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env54430 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,137,8203,5528,10280,1025,136,12572,168,8476,2,8328,17,2185,5392,12557,10280,1420,33,257,33,5377,513]

theorem envBound54430 : H12AffineFastState.Bounded env54430 := by
  intro p hp
  have h : env54430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54429_54430 : H12AffineEnvironment.transform 20 12572 env54429 = env54430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12572 env54429 == env54430) = true)

theorem identity54430 : scanCanonicalize (H12AffineFastState.compose env54430 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54430 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,137,263,5528,2340,1025,136,4112,168,16,2,388,17,2185,5392,4097,2340,1420,33,257,33,5377,513]

theorem envBound54431 : H12AffineFastState.Bounded env54431 := by
  intro p hp
  have h : env54431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54430_54431 : H12AffineEnvironment.transform 12 268 env54430 = env54431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54430 == env54431) = true)

theorem identity54431 : scanCanonicalize (H12AffineFastState.compose env54431 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound54431 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54432 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,4096,129,5260,137,138,5141,2217,1025,136,4112,168,16,2,9,17,2185,5277,4097,2217,1025,33,140,33,5260,513]

theorem envBound54432 : H12AffineFastState.Bounded env54432 := by
  intro p hp
  have h : env54432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54431_54432 : H12AffineEnvironment.transform 7 141 env54431 = env54432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env54431 == env54432) = true)

theorem identity54432 : scanCanonicalize (H12AffineFastState.compose env54432 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound54432 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54433 : List Nat := [2,4,8,16,32,17,128,141,512,1024,1181,4096,129,5260,137,138,5141,1076,1025,136,4112,168,16,2,9,17,1044,5277,4097,1076,1025,33,140,33,5260,513]

theorem envBound54433 : H12AffineFastState.Bounded env54433 := by
  intro p hp
  have h : env54433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54432_54433 : H12AffineEnvironment.transform 10 1181 env54432 = env54433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env54432 == env54433) = true)

theorem identity54433 : scanCanonicalize (H12AffineFastState.compose env54433 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound54433 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env54434 : List Nat := [2,4,8,16,32,17,128,141,512,1024,1181,1589,129,697,137,138,544,1076,1025,136,1573,168,16,2,9,17,1044,680,1588,1076,1025,33,140,33,697,513]

theorem envBound54434 : H12AffineFastState.Bounded env54434 := by
  intro p hp
  have h : env54434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54433_54434 : H12AffineEnvironment.transform 11 1589 env54433 = env54434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env54433 == env54434) = true)

theorem identity54434 : scanCanonicalize (H12AffineFastState.compose env54434 (packedSelected [1,2,4,7,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54434 : packedSelected [1,2,4,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54435 : List Nat := [2,4,8,16,32,17,128,141,48,1024,1181,1029,129,137,137,138,16,1076,1025,136,1045,168,16,2,9,17,1044,152,1028,1076,1025,33,140,33,137,49]

theorem envBound54435 : H12AffineFastState.Bounded env54435 := by
  intro p hp
  have h : env54435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54434_54435 : H12AffineEnvironment.transform 8 48 env54434 = env54435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54434 == env54435) = true)

theorem identity54435 : scanCanonicalize (H12AffineFastState.compose env54435 (packedSelected [4,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound54435 : packedSelected [4,7,14] rootPS < 2^1333 := by decide +kernel

def env54436 : List Nat := [2,4,8,16,32,17,24,21,48,1024,1029,1029,25,17,17,18,16,1076,1025,16,1045,48,16,2,9,17,1044,0,1028,1076,1025,33,20,33,17,49]

theorem envBound54436 : H12AffineFastState.Bounded env54436 := by
  intro p hp
  have h : env54436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54435_54436 : H12AffineEnvironment.transform 6 24 env54435 = env54436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env54435 == env54436) = true)

theorem identity54436 : scanCanonicalize (H12AffineFastState.compose env54436 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54436 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54437 : List Nat := [2,4,8,16,0,17,24,21,16,1024,1029,1029,25,17,17,18,16,1044,1025,16,1045,16,16,2,9,17,1044,0,1028,1044,1025,1,20,1,17,17]

theorem envBound54437 : H12AffineFastState.Bounded env54437 := by
  intro p hp
  have h : env54437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54436_54437 : H12AffineEnvironment.transform 4 0 env54436 = env54437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54436 == env54437) = true)

theorem identity54437 : scanCanonicalize (H12AffineFastState.compose env54437 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54437 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54438 : List Nat := [2,4,8,1,0,0,9,4,1,1024,1029,1029,8,0,0,3,1,1029,1025,1,1028,1,1,2,9,0,1029,0,1028,1029,1025,1,5,1,0,0]

theorem envBound54438 : H12AffineFastState.Bounded env54438 := by
  intro p hp
  have h : env54438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54437_54438 : H12AffineEnvironment.transform 3 1 env54437 = env54438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54437 == env54438) = true)

theorem identity54438 : scanCanonicalize (H12AffineFastState.compose env54438 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54438 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54439 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,1,8,0,0,3,1,1,5,1,0,1,1,2,9,0,1,0,0,1,5,1,5,1,0,0]

theorem envBound54439 : H12AffineFastState.Bounded env54439 := by
  intro p hp
  have h : env54439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54438_54439 : H12AffineEnvironment.transform 9 4 env54438 = env54439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54438 == env54439) = true)

theorem identity54439 : scanCanonicalize (H12AffineFastState.compose env54439 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54440 : List Nat := [2,4,2,1,0,0,3,4,1,4,1,1,2,0,0,3,1,1,5,1,0,1,1,2,3,0,1,0,0,1,5,1,5,1,0,0]

theorem envBound54440 : H12AffineFastState.Bounded env54440 := by
  intro p hp
  have h : env54440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54439_54440 : H12AffineEnvironment.transform 2 2 env54439 = env54440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54439 == env54440) = true)

def env54441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,121942,115150,17664,2404757,119043,329731,257,2199999,2191387,63188]

end H12CloudChart1