import H12CloudChart1Data161

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity41085 : scanCanonicalize (H12AffineFastState.compose env41085 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41085 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41086 : List Nat := [2,4,8,16,0,17,8,5,1,5,17,16,8,16,0,3,1,16,5,1,1,1,17,3,8,16,16,0,17,16,5,0,5,1,16,1]

theorem envBound41086 : H12AffineFastState.Bounded env41086 := by
  intro p hp
  have h : env41086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41085_41086 : H12AffineEnvironment.transform 8 1 env41085 = env41086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41085 == env41086) = true)

theorem identity41086 : scanCanonicalize (H12AffineFastState.compose env41086 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41087 : List Nat := [2,4,8,0,0,1,8,5,1,5,1,0,8,0,0,3,1,0,5,1,1,1,1,3,8,0,0,0,1,0,5,0,5,1,0,1]

theorem envBound41087 : H12AffineFastState.Bounded env41087 := by
  intro p hp
  have h : env41087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41086_41087 : H12AffineEnvironment.transform 3 0 env41086 = env41087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41086 == env41087) = true)

theorem identity41087 : scanCanonicalize (H12AffineFastState.compose env41087 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound41087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41088 : List Nat := [2,1,8,0,0,1,8,0,1,0,1,0,8,0,0,3,1,0,0,1,1,1,1,3,8,0,0,0,1,0,0,0,0,1,0,1]

theorem envBound41088 : H12AffineFastState.Bounded env41088 := by
  intro p hp
  have h : env41088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41087_41088 : H12AffineEnvironment.transform 1 1 env41087 = env41088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env41087 == env41088) = true)

def env41089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4160,62588,119879,21763,8193,65,75786,115014,102743,35188,1365,119927,256,21793,46092,74251]

theorem envBound41089 : H12AffineFastState.Bounded env41089 := by
  intro p hp
  have h : env41089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41074_41089 : H12AffineEnvironment.transform 6 9 env41074 = env41089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41074 == env41089) = true)

theorem identity41089 : scanCanonicalize (H12AffineFastState.compose env41089 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound41089 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env41090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,343,24909,64809,1024,32769,4160,62588,54544,21763,8193,65,10589,49169,36864,35188,1365,54560,256,21793,46092,9052]

theorem envBound41090 : H12AffineFastState.Bounded env41090 := by
  intro p hp
  have h : env41090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41089_41090 : H12AffineEnvironment.transform 15 343 env41089 = env41090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env41089 == env41090) = true)

theorem identity41090 : scanCanonicalize (H12AffineFastState.compose env41090 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41090 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env41091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,343,24909,10281,1024,21761,4160,8572,16,21763,8193,65,10589,5393,17664,23668,1365,32,256,21793,24844,9052]

theorem envBound41091 : H12AffineFastState.Bounded env41091 := by
  intro p hp
  have h : env41091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41090_41091 : H12AffineEnvironment.transform 14 21760 env41090 = env41091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41090 == env41091) = true)

theorem identity41091 : scanCanonicalize (H12AffineFastState.compose env41091 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41091 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,343,16400,2420,1024,21761,4160,33,16,21763,348,65,2048,5393,17664,23668,1365,32,256,21793,16465,513]

theorem envBound41092 : H12AffineFastState.Bounded env41092 := by
  intro p hp
  have h : env41092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41091_41092 : H12AffineEnvironment.transform 12 349 env41091 = env41092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41091 == env41092) = true)

theorem identity41092 : scanCanonicalize (H12AffineFastState.compose env41092 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41092 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41093 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,262,16400,2341,1024,21761,4113,33,16,21763,269,16,2048,5393,17664,23589,1284,32,256,21793,16384,513]

theorem envBound41093 : H12AffineFastState.Bounded env41093 := by
  intro p hp
  have h : env41093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41092_41093 : H12AffineEnvironment.transform 5 17 env41092 = env41093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41092 == env41093) = true)

theorem identity41093 : scanCanonicalize (H12AffineFastState.compose env41093 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound41093 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41094 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,16384,18725,262,16400,2341,1024,18724,3124,33,16,18726,269,16,2048,2356,17664,16384,1284,32,256,18692,16384,513]

theorem envBound41094 : H12AffineFastState.Bounded env41094 := by
  intro p hp
  have h : env41094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41093_41094 : H12AffineEnvironment.transform 11 3109 env41093 = env41094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env41093 == env41094) = true)

theorem identity41094 : scanCanonicalize (H12AffineFastState.compose env41094 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 3899) := by decide +kernel

theorem selectedBound41094 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41095 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,3899,1566,262,3883,2341,1024,1567,3124,33,16,1565,269,16,2048,2356,2619,3899,1284,32,256,1599,3899,513]

theorem envBound41095 : H12AffineFastState.Bounded env41095 := by
  intro p hp
  have h : env41095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41094_41095 : H12AffineEnvironment.transform 13 3899 env41094 = env41095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3899 env41094 == env41095) = true)

theorem identity41095 : scanCanonicalize (H12AffineFastState.compose env41095 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound41095 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env41096 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1818,831,268,33,1566,262,49,1599,1024,1567,814,33,16,1565,269,16,1818,1582,1313,33,1284,32,256,1599,33,513]

theorem envBound41096 : H12AffineFastState.Bounded env41096 := by
  intro p hp
  have h : env41096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41095_41096 : H12AffineEnvironment.transform 10 1818 env41095 = env41096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env41095 == env41096) = true)

theorem identity41096 : scanCanonicalize (H12AffineFastState.compose env41096 (packedSelected [0,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound41096 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env41097 : List Nat := [2,4,8,16,32,17,9,256,512,827,33,831,268,33,293,262,49,260,827,292,814,33,16,294,269,16,33,277,538,33,575,32,256,260,33,513]

theorem envBound41097 : H12AffineFastState.Bounded env41097 := by
  intro p hp
  have h : env41097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41096_41097 : H12AffineEnvironment.transform 9 827 env41096 = env41097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env41096 == env41097) = true)

theorem identity41097 : scanCanonicalize (H12AffineFastState.compose env41097 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound41097 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41098 : List Nat := [2,4,8,16,19,17,9,256,512,776,18,780,268,18,278,262,2,260,776,279,797,18,16,277,269,16,18,277,538,18,524,19,256,260,18,513]

theorem envBound41098 : H12AffineFastState.Bounded env41098 := by
  intro p hp
  have h : env41098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41097_41098 : H12AffineEnvironment.transform 4 19 env41097 = env41098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env41097 == env41098) = true)

def env41099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,510000,8328,65,316533,417021,396525,35324,1501,272392,256,21793,46213,74250]

theorem envBound41099 : H12AffineFastState.Bounded env41099 := by
  intro p hp
  have h : env41099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41052_41099 : H12AffineEnvironment.transform 20 4161 env41052 = env41099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41052 == env41099) = true)

theorem identity41099 : scanCanonicalize (H12AffineFastState.compose env41099 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41099 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,169400,412156,452667,8328,65,316533,417021,396525,35324,1501,272392,256,21793,46213,513]

theorem envBound41100 : H12AffineFastState.Bounded env41100 := by
  intro p hp
  have h : env41100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41099_41100 : H12AffineEnvironment.transform 15 8203 env41099 = env41100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41099 == env41100) = true)

def env41101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4161,54696,264684,305195,8328,65,316533,269549,281853,35324,1501,272392,256,21793,46213,513]

theorem envBound41101 : H12AffineFastState.Bounded env41101 := by
  intro p hp
  have h : env41101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41100_41101 : H12AffineEnvironment.transform 16 16400 env41100 = env41101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41100 == env41101) = true)

def env41102 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4113,54696,264636,305195,8328,17,316453,269501,281773,35244,1421,272392,256,21793,46213,513]

theorem envBound41102 : H12AffineFastState.Bounded env41102 := by
  intro p hp
  have h : env41102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41101_41102 : H12AffineEnvironment.transform 5 16 env41101 = env41102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41101 == env41102) = true)

theorem identity41102 : scanCanonicalize (H12AffineFastState.compose env41102 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound41102 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env41103 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10400,1024,32769,4113,54696,8476,32907,8328,17,64645,13341,25613,35244,1421,168,256,21793,46213,513]

theorem envBound41103 : H12AffineFastState.Bounded env41103 := by
  intro p hp
  have h : env41103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41102_41103 : H12AffineEnvironment.transform 17 10400 env41102 = env41103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env41102 == env41103) = true)

theorem identity41103 : scanCanonicalize (H12AffineFastState.compose env41103 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound41103 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env41104 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,16400,10400,1024,29828,4113,8493,8476,29710,8328,17,2048,13341,25613,32041,1421,168,256,21793,16384,513]

theorem envBound41104 : H12AffineFastState.Bounded env41104 := by
  intro p hp
  have h : env41104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41103_41104 : H12AffineEnvironment.transform 14 29829 env41103 = env41104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env41103 == env41104) = true)

theorem identity41104 : scanCanonicalize (H12AffineFastState.compose env41104 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound41104 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env41105 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13445,0,8203,13461,10400,1024,1,4113,8493,8476,139,8328,17,2048,13341,4232,2476,1421,168,256,8612,13445,513]

theorem envBound41105 : H12AffineFastState.Bounded env41105 := by
  intro p hp
  have h : env41105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41104_41105 : H12AffineEnvironment.transform 13 13445 env41104 = env41105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env41104 == env41105) = true)

theorem identity41105 : scanCanonicalize (H12AffineFastState.compose env41105 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41105 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env41106 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,8203,13341,10280,1024,1,4113,8493,8476,3,8192,17,2048,13341,4096,2340,1285,32,256,8492,13325,513]

theorem envBound41106 : H12AffineFastState.Bounded env41106 := by
  intro p hp
  have h : env41106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41105_41106 : H12AffineEnvironment.transform 6 8 env41105 = env41106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41105 == env41106) = true)

theorem identity41106 : scanCanonicalize (H12AffineFastState.compose env41106 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41106 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41107 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2340,1024,1,4113,33,16,3,268,17,2048,5393,4096,2340,1285,32,256,32,5377,513]

theorem envBound41107 : H12AffineFastState.Bounded env41107 := by
  intro p hp
  have h : env41107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41106_41107 : H12AffineEnvironment.transform 12 268 env41106 = env41107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41106 == env41107) = true)

theorem identity41107 : scanCanonicalize (H12AffineFastState.compose env41107 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound41107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41108 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1028,268,261,0,263,277,2340,1024,1,1045,33,16,3,268,17,2048,277,1028,2340,1285,32,256,32,261,513]

theorem envBound41108 : H12AffineFastState.Bounded env41108 := by
  intro p hp
  have h : env41108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41107_41108 : H12AffineEnvironment.transform 11 1028 env41107 = env41108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env41107 == env41108) = true)

theorem identity41108 : scanCanonicalize (H12AffineFastState.compose env41108 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41108 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41109 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,1028,40,33,0,35,49,2048,1024,1,1045,33,16,3,40,17,2048,49,1028,2048,1057,32,36,32,33,513]

theorem envBound41109 : H12AffineFastState.Bounded env41109 := by
  intro p hp
  have h : env41109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41108_41109 : H12AffineEnvironment.transform 7 36 env41108 = env41109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41108 == env41109) = true)

theorem identity41109 : scanCanonicalize (H12AffineFastState.compose env41109 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound41109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41110 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1044,1028,40,33,0,35,49,1044,1024,1,1045,33,16,3,40,17,1044,49,1028,1044,1057,32,36,32,33,513]

theorem envBound41110 : H12AffineFastState.Bounded env41110 := by
  intro p hp
  have h : env41110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41109_41110 : H12AffineEnvironment.transform 10 1044 env41109 = env41110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env41109 == env41110) = true)

theorem identity41110 : scanCanonicalize (H12AffineFastState.compose env41110 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound41110 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41111 : List Nat := [2,4,8,16,32,16,8,36,512,564,544,560,40,33,0,35,49,544,564,1,545,33,16,3,40,17,544,49,560,544,533,32,36,32,33,513]

theorem envBound41111 : H12AffineFastState.Bounded env41111 := by
  intro p hp
  have h : env41111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41110_41111 : H12AffineEnvironment.transform 9 564 env41110 = env41111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env41110 == env41111) = true)

theorem identity41111 : scanCanonicalize (H12AffineFastState.compose env41111 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41111 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41112 : List Nat := [2,4,8,0,32,0,8,36,512,548,544,544,40,33,0,35,33,544,548,1,545,33,0,3,40,1,544,33,544,544,517,32,36,32,33,513]

theorem envBound41112 : H12AffineFastState.Bounded env41112 := by
  intro p hp
  have h : env41112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41111_41112 : H12AffineEnvironment.transform 3 0 env41111 = env41112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41111 == env41112) = true)

theorem identity41112 : scanCanonicalize (H12AffineFastState.compose env41112 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41112 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env41113 : List Nat := [2,4,8,0,32,0,8,36,1,37,33,33,40,33,0,35,33,33,37,1,32,33,0,3,40,1,33,33,33,33,4,32,36,32,33,0]

theorem envBound41113 : H12AffineFastState.Bounded env41113 := by
  intro p hp
  have h : env41113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41112_41113 : H12AffineEnvironment.transform 8 1 env41112 = env41113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41112 == env41113) = true)

theorem identity41113 : scanCanonicalize (H12AffineFastState.compose env41113 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41114 : List Nat := [2,4,8,0,0,0,8,4,1,5,1,1,8,1,0,3,1,1,5,1,0,1,0,3,8,1,1,1,1,1,4,0,4,0,1,0]

theorem envBound41114 : H12AffineFastState.Bounded env41114 := by
  intro p hp
  have h : env41114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41113_41114 : H12AffineEnvironment.transform 4 0 env41113 = env41114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41113 == env41114) = true)

def env41115 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4112,54696,264637,305195,8328,16,316452,269500,281772,35245,1420,272392,256,21793,46213,513]

theorem envBound41115 : H12AffineFastState.Bounded env41115 := by
  intro p hp
  have h : env41115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41101_41115 : H12AffineEnvironment.transform 5 17 env41101 = env41115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41101 == env41115) = true)

theorem identity41115 : scanCanonicalize (H12AffineFastState.compose env41115 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound41115 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env41116 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8203,16400,262144,1024,8581,4112,29740,264637,264623,8328,16,292256,269500,281772,10281,1420,272392,256,21793,5377,513]

theorem envBound41116 : H12AffineFastState.Bounded env41116 := by
  intro p hp
  have h : env41116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41115_41116 : H12AffineEnvironment.transform 14 8580 env41115 = env41116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env41115 == env41116) = true)

theorem identity41116 : scanCanonicalize (H12AffineFastState.compose env41116 (packedSelected [1,5,7,8,14,17,18,20,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound41116 : packedSelected [1,5,7,8,14,17,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env41117 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,8580,8203,5528,262144,1024,8581,4112,8612,264637,264623,8328,16,270376,269500,268580,10281,1420,272392,256,169,5377,513]

theorem envBound41117 : H12AffineFastState.Bounded env41117 := by
  intro p hp
  have h : env41117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41116_41117 : H12AffineEnvironment.transform 13 5512 env41116 = env41117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env41116 == env41117) = true)

theorem identity41117 : scanCanonicalize (H12AffineFastState.compose env41117 (packedSelected [0,1,3,5,7,8,11,12,14,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound41117 : packedSelected [0,1,3,5,7,8,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41118 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,8192,4404,8580,8203,4388,262144,188,8581,4112,8612,264637,264623,8328,16,270376,268288,268580,10281,304,272392,256,169,4541,513]

theorem envBound41118 : H12AffineFastState.Bounded env41118 := by
  intro p hp
  have h : env41118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41117_41118 : H12AffineEnvironment.transform 9 188 env41117 = env41118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env41117 == env41118) = true)

theorem identity41118 : scanCanonicalize (H12AffineFastState.compose env41118 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound41118 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41119 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,0,399,4388,262144,188,1,4112,32,264637,264623,268,16,262572,268288,268580,2477,304,264588,256,169,4541,513]

theorem envBound41119 : H12AffineFastState.Bounded env41119 := by
  intro p hp
  have h : env41119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41118_41119 : H12AffineEnvironment.transform 12 388 env41118 = env41119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env41118 == env41119) = true)

theorem identity41119 : scanCanonicalize (H12AffineFastState.compose env41119 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(17+1) ^^^ 2476) := by decide +kernel

theorem selectedBound41119 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env41120 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,0,399,4388,2476,188,1,4112,32,17,3,268,16,2048,4524,4232,2477,304,32,256,169,4541,513]

theorem envBound41120 : H12AffineFastState.Bounded env41120 := by
  intro p hp
  have h : env41120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41119_41120 : H12AffineEnvironment.transform 17 2476 env41119 = env41120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2476 env41119 == env41120) = true)

theorem identity41120 : scanCanonicalize (H12AffineFastState.compose env41120 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 956) := by decide +kernel

theorem selectedBound41120 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41121 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,956,388,648,0,399,664,2476,188,1,940,32,17,3,268,16,2048,528,820,2477,304,32,256,169,513,513]

theorem envBound41121 : H12AffineFastState.Bounded env41121 := by
  intro p hp
  have h : env41121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41120_41121 : H12AffineEnvironment.transform 11 956 env41120 = env41121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 956 env41120 == env41121) = true)

theorem identity41121 : scanCanonicalize (H12AffineFastState.compose env41121 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound41121 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41122 : List Nat := [2,4,8,16,32,17,128,256,512,188,512,956,388,648,0,399,664,940,188,1,940,32,17,3,268,16,512,528,820,941,304,32,256,169,513,513]

theorem envBound41122 : H12AffineFastState.Bounded env41122 := by
  intro p hp
  have h : env41122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41121_41122 : H12AffineEnvironment.transform 10 512 env41121 = env41122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env41121 == env41122) = true)

theorem identity41122 : scanCanonicalize (H12AffineFastState.compose env41122 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41122 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41123 : List Nat := [2,4,8,16,32,17,9,256,512,53,512,821,269,513,0,262,529,805,53,1,805,32,17,3,268,16,512,528,820,804,304,32,256,32,513,513]

theorem envBound41123 : H12AffineFastState.Bounded env41123 := by
  intro p hp
  have h : env41123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41122_41123 : H12AffineEnvironment.transform 6 9 env41122 = env41123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41122 == env41123) = true)

theorem identity41123 : scanCanonicalize (H12AffineFastState.compose env41123 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41123 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41124 : List Nat := [2,4,8,16,16,17,9,256,512,5,512,773,269,513,0,262,529,789,5,1,789,16,17,3,268,16,512,528,772,788,256,16,256,16,513,513]

theorem envBound41124 : H12AffineFastState.Bounded env41124 := by
  intro p hp
  have h : env41124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41123_41124 : H12AffineEnvironment.transform 4 16 env41123 = env41124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41123 == env41124) = true)

theorem identity41124 : scanCanonicalize (H12AffineFastState.compose env41124 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41124 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41125 : List Nat := [2,4,8,0,0,1,9,256,512,5,512,773,269,513,0,262,513,773,5,1,773,0,1,3,268,0,512,512,772,772,256,0,256,0,513,513]

theorem envBound41125 : H12AffineFastState.Bounded env41125 := by
  intro p hp
  have h : env41125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41124_41125 : H12AffineEnvironment.transform 3 0 env41124 = env41125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41124 == env41125) = true)

def env41126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,54697,264685,305194,8328,65,316533,269548,281852,35324,1501,272392,256,21793,46213,513]

theorem envBound41126 : H12AffineFastState.Bounded env41126 := by
  intro p hp
  have h : env41126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41100_41126 : H12AffineEnvironment.transform 16 16401 env41100 = env41126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41100 == env41126) = true)

theorem identity41126 : scanCanonicalize (H12AffineFastState.compose env41126 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound41126 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,2557,1024,32769,4161,54697,16,41431,8328,65,56712,5393,17665,35324,1501,8693,256,21793,46213,513]

theorem envBound41127 : H12AffineFastState.Bounded env41127 := by
  intro p hp
  have h : env41127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41126_41127 : H12AffineEnvironment.transform 17 2557 env41126 = env41127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env41126 == env41127) = true)

theorem identity41127 : scanCanonicalize (H12AffineFastState.compose env41127 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41127 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16401,2557,1024,21761,4161,169,16,29911,8328,65,2184,5393,17665,23804,1501,8693,256,21793,24965,513]

theorem envBound41128 : H12AffineFastState.Bounded env41128 := by
  intro p hp
  have h : env41128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41127_41128 : H12AffineEnvironment.transform 14 21760 env41127 = env41128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41127 == env41128) = true)

theorem identity41128 : scanCanonicalize (H12AffineFastState.compose env41128 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41128 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env41129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,16401,2420,1024,21761,4161,32,16,29790,8193,65,2049,5393,17665,23669,1364,8572,256,21793,24844,513]

theorem envBound41129 : H12AffineFastState.Bounded env41129 := by
  intro p hp
  have h : env41129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41128_41129 : H12AffineEnvironment.transform 6 9 env41128 = env41129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41128 == env41129) = true)

theorem identity41129 : scanCanonicalize (H12AffineFastState.compose env41129 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41129 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8203,13388,2420,1024,8540,4161,32,16,3,8193,65,2049,5393,12636,10280,1364,8572,256,8572,5457,513]

theorem envBound41130 : H12AffineFastState.Bounded env41130 := by
  intro p hp
  have h : env41130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41129_41130 : H12AffineEnvironment.transform 13 13405 env41129 = env41130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41129 == env41130) = true)

theorem identity41130 : scanCanonicalize (H12AffineFastState.compose env41130 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound41130 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env41131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,8192,9228,8541,8203,9245,2420,1024,8540,16,32,16,3,8193,65,2049,1344,8461,10280,1364,8572,256,8572,1280,513]

theorem envBound41131 : H12AffineFastState.Bounded env41131 := by
  intro p hp
  have h : env41131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41130_41131 : H12AffineEnvironment.transform 11 81 env41130 = env41131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env41130 == env41131) = true)

theorem identity41131 : scanCanonicalize (H12AffineFastState.compose env41131 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41131 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,348,1360,1,343,1345,2420,1024,0,16,32,16,3,349,65,2049,1344,81,2420,1364,32,256,32,1280,513]

theorem envBound41132 : H12AffineFastState.Bounded env41132 := by
  intro p hp
  have h : env41132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41131_41132 : H12AffineEnvironment.transform 12 348 env41131 = env41132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41131 == env41132) = true)

theorem identity41132 : scanCanonicalize (H12AffineFastState.compose env41132 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1151) := by decide +kernel

theorem selectedBound41132 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1151,81,348,1360,1,343,1345,1291,1024,0,16,32,16,3,349,65,1150,1344,81,1291,1364,32,256,32,1280,513]

theorem envBound41133 : H12AffineFastState.Bounded env41133 := by
  intro p hp
  have h : env41133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41132_41133 : H12AffineEnvironment.transform 10 1151 env41132 = env41133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1151 env41132 == env41133) = true)

theorem identity41133 : scanCanonicalize (H12AffineFastState.compose env41133 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound41133 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41134 : List Nat := [2,4,8,16,32,64,9,256,512,47,80,81,348,383,1,343,366,292,47,0,16,32,16,3,349,65,81,367,81,292,379,32,256,32,303,513]

theorem envBound41134 : H12AffineFastState.Bounded env41134 := by
  intro p hp
  have h : env41134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41133_41134 : H12AffineEnvironment.transform 9 47 env41133 = env41134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env41133 == env41134) = true)

theorem identity41134 : scanCanonicalize (H12AffineFastState.compose env41134 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41134 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41135 : List Nat := [2,4,8,16,32,64,9,68,512,47,80,81,24,59,1,19,42,96,47,0,16,32,16,3,25,65,81,43,81,96,63,32,68,32,107,513]

theorem envBound41135 : H12AffineFastState.Bounded env41135 := by
  intro p hp
  have h : env41135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41134_41135 : H12AffineEnvironment.transform 7 68 env41134 = env41135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41134 == env41135) = true)

theorem identity41135 : scanCanonicalize (H12AffineFastState.compose env41135 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41135 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41136 : List Nat := [2,4,8,16,1,64,9,68,512,14,80,81,24,26,1,19,11,65,14,0,16,1,16,3,25,65,81,10,81,65,30,1,68,1,74,513]

theorem envBound41136 : H12AffineFastState.Bounded env41136 := by
  intro p hp
  have h : env41136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41135_41136 : H12AffineEnvironment.transform 4 1 env41135 = env41136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41135 == env41136) = true)

theorem identity41136 : scanCanonicalize (H12AffineFastState.compose env41136 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound41136 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env41137 : List Nat := [2,4,8,16,1,64,9,68,80,14,80,81,24,26,1,19,11,65,14,0,16,1,16,3,25,65,81,10,81,65,30,1,68,1,74,81]

theorem envBound41137 : H12AffineFastState.Bounded env41137 := by
  intro p hp
  have h : env41137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41136_41137 : H12AffineEnvironment.transform 8 80 env41136 = env41137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env41136 == env41137) = true)

theorem identity41137 : scanCanonicalize (H12AffineFastState.compose env41137 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 19) := by decide +kernel

theorem selectedBound41137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41138 : List Nat := [2,4,8,16,1,19,9,23,3,14,3,2,24,26,1,19,11,18,14,0,16,1,16,3,25,18,2,10,2,18,30,1,23,1,25,2]

theorem envBound41138 : H12AffineFastState.Bounded env41138 := by
  intro p hp
  have h : env41138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41137_41138 : H12AffineEnvironment.transform 5 19 env41137 = env41138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 19 env41137 == env41138) = true)

theorem identity41138 : scanCanonicalize (H12AffineFastState.compose env41138 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound41138 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env41139 : List Nat := [2,4,8,15,1,12,9,8,3,14,3,2,7,5,1,12,11,13,14,0,15,1,15,3,6,13,2,10,2,13,1,1,8,1,6,2]

theorem envBound41139 : H12AffineFastState.Bounded env41139 := by
  intro p hp
  have h : env41139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41138_41139 : H12AffineEnvironment.transform 3 15 env41138 = env41139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env41138 == env41139) = true)

theorem identity41139 : scanCanonicalize (H12AffineFastState.compose env41139 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound41139 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env41140 : List Nat := [2,4,0,7,1,4,1,0,3,6,3,2,7,5,1,4,3,5,6,0,7,1,7,3,6,5,2,2,2,5,1,1,0,1,6,2]

theorem envBound41140 : H12AffineFastState.Bounded env41140 := by
  intro p hp
  have h : env41140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41139_41140 : H12AffineEnvironment.transform 2 0 env41139 = env41140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env41139 == env41140) = true)

def env41141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513341,510000,8328,65,2409525,2510012,396525,2136509,2102684,2373704,256,21793,46213,2175563]

theorem envBound41141 : H12AffineFastState.Bounded env41141 := by
  intro p hp
  have h : env41141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41051_41141 : H12AffineEnvironment.transform 21 169401 env41051 = env41141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env41051 == env41141) = true)

def env41142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,510000,8328,65,316533,417020,396525,35325,1500,272392,256,21793,46213,74251]

theorem envBound41142 : H12AffineFastState.Bounded env41142 := by
  intro p hp
  have h : env41142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41141_41142 : H12AffineEnvironment.transform 20 4160 env41141 = env41142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41141 == env41142) = true)

theorem identity41142 : scanCanonicalize (H12AffineFastState.compose env41142 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound41142 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,169401,412157,400622,8328,65,316533,417020,396525,35325,1500,272392,256,21793,46213,63189]

theorem envBound41143 : H12AffineFastState.Bounded env41143 := by
  intro p hp
  have h : env41143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41142_41143 : H12AffineEnvironment.transform 15 54494 env41142 = env41143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env41142 == env41143) = true)

def env41144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1024,32769,4160,169401,29725,8462,8328,65,190869,24860,12557,35325,1500,136680,256,21793,46213,63189]

theorem envBound41144 : H12AffineFastState.Bounded env41144 := by
  intro p hp
  have h : env41144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41143_41144 : H12AffineEnvironment.transform 17 146912 env41143 = env41144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env41143 == env41144) = true)

theorem identity41144 : scanCanonicalize (H12AffineFastState.compose env41144 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41144 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30082,131072,146912,1024,8541,4160,144613,29725,8462,8328,65,149705,24860,12557,10401,1500,136680,256,21793,5593,22409]

theorem envBound41145 : H12AffineFastState.Bounded env41145 := by
  intro p hp
  have h : env41145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41144_41145 : H12AffineEnvironment.transform 14 8540 env41144 = env41145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41144 == env41145) = true)

theorem identity41145 : scanCanonicalize (H12AffineFastState.compose env41145 (packedSelected [0,3,4,5,7,8,17,22,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41145 : packedSelected [0,3,4,5,7,8,17,22,28] rootPS < 2^1333 := by decide +kernel

def env41146 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,30082,131072,146864,1024,8461,4112,144565,29725,8462,8328,17,149657,24860,12557,10401,1420,136632,256,21793,5513,22409]

theorem envBound41146 : H12AffineFastState.Bounded env41146 := by
  intro p hp
  have h : env41146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41145_41146 : H12AffineEnvironment.transform 5 16 env41145 = env41146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41145 == env41146) = true)

theorem identity41146 : scanCanonicalize (H12AffineFastState.compose env41146 (packedSelected [10,17,18,23,31] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41146 : packedSelected [10,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env41147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,0,21646,131072,138428,1024,1,4112,136633,21777,2,388,17,149657,16400,4097,2477,1420,136632,256,21793,5513,22409]

theorem envBound41147 : H12AffineFastState.Bounded env41147 := by
  intro p hp
  have h : env41147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41146_41147 : H12AffineEnvironment.transform 12 268 env41146 = env41147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41146 == env41147) = true)

theorem identity41147 : scanCanonicalize (H12AffineFastState.compose env41147 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound41147 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env41148 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,0,262,131072,138428,1024,1,4112,136633,153,2,388,17,138513,5528,4097,2477,1420,136632,256,169,5513,513]

theorem envBound41148 : H12AffineFastState.Bounded env41148 := by
  intro p hp
  have h : env41148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41147_41148 : H12AffineEnvironment.transform 13 5512 env41147 = env41148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env41147 == env41148) = true)

theorem identity41148 : scanCanonicalize (H12AffineFastState.compose env41148 (packedSelected [1,8,10] rootPS)) = affineNative (2^(16+1) ^^^ 5309) := by decide +kernel

theorem selectedBound41148 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env41149 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5512,0,262,5309,2049,1024,1,4112,260,153,2,388,17,2476,5528,4097,2477,1420,261,256,169,5513,513]

theorem envBound41149 : H12AffineFastState.Bounded env41149 := by
  intro p hp
  have h : env41149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41148_41149 : H12AffineEnvironment.transform 16 5309 env41148 = env41149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5309 env41148 == env41149) = true)

theorem identity41149 : scanCanonicalize (H12AffineFastState.compose env41149 (packedSelected [0,2,6,7,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41149 : packedSelected [0,2,6,7,14] rootPS < 2^1333 := by decide +kernel

def env41150 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5172,2049,1024,1,4112,260,16,2,269,17,2341,5393,4097,2340,1285,261,256,32,5376,513]

theorem envBound41150 : H12AffineFastState.Bounded env41150 := by
  intro p hp
  have h : env41150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41149_41150 : H12AffineEnvironment.transform 6 9 env41149 = env41150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41149 == env41150) = true)

def env41151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1024,32769,4160,169401,29724,8463,8328,65,190868,24861,12556,35325,1500,136681,256,21793,46213,63189]

theorem envBound41151 : H12AffineFastState.Bounded env41151 := by
  intro p hp
  have h : env41151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41143_41151 : H12AffineEnvironment.transform 17 146913 env41143 = env41151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env41143 == env41151) = true)

theorem identity41151 : scanCanonicalize (H12AffineFastState.compose env41151 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound41151 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env41152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,131072,146913,1024,8661,4160,144493,29724,8463,8328,65,149568,24861,12556,10281,1500,136681,256,21793,5457,22273]

theorem envBound41152 : H12AffineFastState.Bounded env41152 := by
  intro p hp
  have h : env41152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41151_41152 : H12AffineEnvironment.transform 14 8660 env41151 = env41152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env41151 == env41152) = true)

theorem identity41152 : scanCanonicalize (H12AffineFastState.compose env41152 (packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound41152 : packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS < 2^1333 := by decide +kernel

def env41153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,5529,10360,1024,8661,4160,8692,29724,8463,8328,65,24025,24861,12556,10281,1500,112,256,21793,5457,22273]

theorem envBound41153 : H12AffineFastState.Bounded env41153 := by
  intro p hp
  have h : env41153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41152_41153 : H12AffineEnvironment.transform 16 5529 env41152 = env41153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env41152 == env41153) = true)

theorem identity41153 : scanCanonicalize (H12AffineFastState.compose env41153 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound41153 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env41154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,81,21647,5529,2557,1024,80,4160,113,21913,138,269,65,24025,16536,4233,2476,1500,112,256,21793,5457,22273]

theorem envBound41154 : H12AffineFastState.Bounded env41154 := by
  intro p hp
  have h : env41154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41153_41154 : H12AffineEnvironment.transform 12 389 env41153 = env41154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env41153 == env41154) = true)

theorem identity41154 : scanCanonicalize (H12AffineFastState.compose env41154 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound41154 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env41155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5376,81,399,5529,2557,1024,80,4160,113,153,138,269,65,2265,5528,4233,2476,1500,112,256,33,5457,513]

theorem envBound41155 : H12AffineFastState.Bounded env41155 := by
  intro p hp
  have h : env41155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41154_41155 : H12AffineEnvironment.transform 13 5376 env41154 = env41155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41154 == env41155) = true)

theorem identity41155 : scanCanonicalize (H12AffineFastState.compose env41155 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound41155 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env41156 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,389,4588,81,399,4469,2557,236,80,4160,113,153,138,269,65,2265,4468,4233,2476,304,112,256,33,4541,513]

theorem envBound41156 : H12AffineFastState.Bounded env41156 := by
  intro p hp
  have h : env41156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41155_41156 : H12AffineEnvironment.transform 9 236 env41155 = env41156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env41155 == env41156) = true)

theorem identity41156 : scanCanonicalize (H12AffineFastState.compose env41156 (packedSelected [0,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound41156 : packedSelected [0,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env41157 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,349,4404,81,343,4469,2341,52,80,4160,113,65,82,269,65,2049,4468,4177,2420,304,112,256,33,4453,513]

theorem envBound41157 : H12AffineFastState.Bounded env41157 := by
  intro p hp
  have h : env41157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41156_41157 : H12AffineEnvironment.transform 6 88 env41156 = env41157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env41156 == env41157) = true)

theorem identity41157 : scanCanonicalize (H12AffineFastState.compose env41157 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41157 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41158 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,1,263,4389,2341,52,0,4112,33,17,2,269,17,2049,4388,4097,2340,304,32,256,33,4405,513]

theorem envBound41158 : H12AffineFastState.Bounded env41158 := by
  intro p hp
  have h : env41158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41157_41158 : H12AffineEnvironment.transform 5 16 env41157 = env41158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41157 == env41158) = true)

theorem identity41158 : scanCanonicalize (H12AffineFastState.compose env41158 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41158 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41159 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,1,35,4097,2049,52,0,4112,33,17,2,41,17,2049,4096,4097,2048,20,32,36,33,4113,513]

theorem envBound41159 : H12AffineFastState.Bounded env41159 := by
  intro p hp
  have h : env41159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41158_41159 : H12AffineEnvironment.transform 7 36 env41158 = env41159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41158 == env41159) = true)

theorem identity41159 : scanCanonicalize (H12AffineFastState.compose env41159 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound41159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41160 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2096,41,2080,1,35,2097,2049,52,0,2080,33,17,2,41,17,2049,2096,2097,2048,20,32,36,33,2081,513]

theorem envBound41160 : H12AffineFastState.Bounded env41160 := by
  intro p hp
  have h : env41160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41159_41160 : H12AffineEnvironment.transform 11 2096 env41159 = env41160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env41159 == env41160) = true)

theorem identity41160 : scanCanonicalize (H12AffineFastState.compose env41160 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound41160 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41161 : List Nat := [2,4,8,16,32,16,8,36,512,52,529,545,41,561,1,35,544,528,52,0,561,33,17,2,41,17,528,545,544,529,20,32,36,33,560,513]

theorem envBound41161 : H12AffineFastState.Bounded env41161 := by
  intro p hp
  have h : env41161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41160_41161 : H12AffineEnvironment.transform 10 529 env41160 = env41161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env41160 == env41161) = true)

theorem identity41161 : scanCanonicalize (H12AffineFastState.compose env41161 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41161 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41162 : List Nat := [2,4,8,16,0,16,8,4,512,20,529,513,9,529,1,3,512,528,20,0,529,1,17,2,9,17,528,513,512,529,20,0,4,1,528,513]

theorem envBound41162 : H12AffineFastState.Bounded env41162 := by
  intro p hp
  have h : env41162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41161_41162 : H12AffineEnvironment.transform 4 0 env41161 = env41162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41161 == env41162) = true)

def env41163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,510000,8328,65,316532,417021,396525,35324,1501,272393,256,21793,46213,74250]

theorem envBound41163 : H12AffineFastState.Bounded env41163 := by
  intro p hp
  have h : env41163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41141_41163 : H12AffineEnvironment.transform 20 4161 env41141 = env41163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41141 == env41163) = true)

theorem identity41163 : scanCanonicalize (H12AffineFastState.compose env41163 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223719) := by decide +kernel

theorem selectedBound41163 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,169401,73755,41431,8328,65,245139,79130,91402,35324,1501,213486,256,21793,46213,74250]

theorem envBound41164 : H12AffineFastState.Bounded env41164 := by
  intro p hp
  have h : env41164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41163_41164 : H12AffineEnvironment.transform 17 223719 env41163 = env41164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223719 env41163 == env41164) = true)

def env41165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67755,1024,32769,4161,62709,73755,41431,8328,65,122079,79130,91402,35324,1501,73890,256,21793,46213,74250]

theorem envBound41165 : H12AffineFastState.Bounded env41165 := by
  intro p hp
  have h : env41165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41164_41165 : H12AffineEnvironment.transform 16 24908 env41164 = env41165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env41164 == env41165) = true)

theorem identity41165 : scanCanonicalize (H12AffineFastState.compose env41165 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound41165 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env41166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,24908,67755,1024,137,4161,29821,73755,8543,8328,65,89175,79130,91402,2420,1501,73890,256,21793,13325,74250]

theorem envBound41166 : H12AffineFastState.Bounded env41166 := by
  intro p hp
  have h : env41166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41165_41166 : H12AffineEnvironment.transform 14 136 env41165 = env41166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env41165 == env41166) = true)

theorem identity41166 : scanCanonicalize (H12AffineFastState.compose env41166 (packedSelected [2,3,4,5,6,10,16,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound41166 : packedSelected [2,3,4,5,6,10,16,17,22] rootPS < 2^1333 := by decide +kernel

def env41167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,5392,67755,1024,137,4161,33,73755,8543,8328,65,75787,79130,69974,2420,1501,73890,256,8573,13325,74250]

theorem envBound41167 : H12AffineFastState.Bounded env41167 := by
  intro p hp
  have h : env41167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41166_41167 : H12AffineEnvironment.transform 13 13404 env41166 = env41167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env41166 == env41167) = true)

theorem identity41167 : scanCanonicalize (H12AffineFastState.compose env41167 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41167 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env41168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,5392,10400,1024,137,4161,33,16,8543,8328,65,2048,5393,12637,2420,1501,169,256,8573,13325,513]

theorem envBound41168 : H12AffineFastState.Bounded env41168 := by
  intro p hp
  have h : env41168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41167_41168 : H12AffineEnvironment.transform 15 8203 env41167 = env41168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41167 == env41168) = true)

theorem identity41168 : scanCanonicalize (H12AffineFastState.compose env41168 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound41168 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,478,5392,2421,1024,137,4161,33,16,138,349,65,2048,5393,4232,2420,1501,169,256,168,5592,513]

theorem envBound41169 : H12AffineFastState.Bounded env41169 := by
  intro p hp
  have h : env41169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41168_41169 : H12AffineEnvironment.transform 12 469 env41168 = env41169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env41168 == env41169) = true)

theorem identity41169 : scanCanonicalize (H12AffineFastState.compose env41169 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41169 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5392,2421,1024,0,4161,33,16,3,349,65,2048,5393,4097,2420,1364,32,256,33,5457,513]

theorem envBound41170 : H12AffineFastState.Bounded env41170 := by
  intro p hp
  have h : env41170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41169_41170 : H12AffineEnvironment.transform 6 9 env41169 = env41170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41169 == env41170) = true)

theorem identity41170 : scanCanonicalize (H12AffineFastState.compose env41170 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41170 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41171 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,348,1296,1,343,1280,2421,1024,0,81,33,16,3,349,65,2048,1281,17,2420,1364,32,256,33,1345,513]

theorem envBound41171 : H12AffineFastState.Bounded env41171 := by
  intro p hp
  have h : env41171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41170_41171 : H12AffineEnvironment.transform 11 16 env41170 = env41171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41170 == env41171) = true)

theorem identity41171 : scanCanonicalize (H12AffineFastState.compose env41171 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1605) := by decide +kernel

theorem selectedBound41171 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env41172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1605,16,348,1296,1,343,1280,1840,1024,0,81,33,16,3,349,65,1605,1281,17,1841,1364,32,256,33,1345,513]

theorem envBound41172 : H12AffineFastState.Bounded env41172 := by
  intro p hp
  have h : env41172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41171_41172 : H12AffineEnvironment.transform 10 1605 env41171 = env41172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1605 env41171 == env41172) = true)

theorem identity41172 : scanCanonicalize (H12AffineFastState.compose env41172 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound41172 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41173 : List Nat := [2,4,8,16,32,64,9,256,512,816,373,16,348,544,1,343,560,0,816,0,81,33,16,3,349,65,373,561,17,1,612,32,256,33,625,513]

theorem envBound41173 : H12AffineFastState.Bounded env41173 := by
  intro p hp
  have h : env41173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41172_41173 : H12AffineEnvironment.transform 9 816 env41172 = env41173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env41172 == env41173) = true)

theorem identity41173 : scanCanonicalize (H12AffineFastState.compose env41173 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound41173 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41174 : List Nat := [2,4,8,16,32,64,9,256,324,116,373,16,348,356,1,343,372,0,116,0,81,33,16,3,349,65,373,373,17,1,288,32,256,33,309,325]

theorem envBound41174 : H12AffineFastState.Bounded env41174 := by
  intro p hp
  have h : env41174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41173_41174 : H12AffineEnvironment.transform 8 324 env41173 = env41174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env41173 == env41174) = true)

theorem identity41174 : scanCanonicalize (H12AffineFastState.compose env41174 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41174 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env41175 : List Nat := [2,4,8,16,0,64,9,256,324,84,341,16,348,324,1,343,340,0,84,0,81,1,16,3,349,65,341,341,17,1,256,0,256,1,277,325]

theorem envBound41175 : H12AffineFastState.Bounded env41175 := by
  intro p hp
  have h : env41175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41174_41175 : H12AffineEnvironment.transform 4 0 env41174 = env41175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41174 == env41175) = true)

theorem identity41175 : scanCanonicalize (H12AffineFastState.compose env41175 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41175 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41176 : List Nat := [2,4,8,16,0,64,9,5,65,84,80,16,89,65,1,82,81,0,84,0,81,1,16,3,88,65,80,80,17,1,5,0,5,1,16,64]

theorem envBound41176 : H12AffineFastState.Bounded env41176 := by
  intro p hp
  have h : env41176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41175_41176 : H12AffineEnvironment.transform 7 5 env41175 = env41176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41175 == env41176) = true)

theorem identity41176 : scanCanonicalize (H12AffineFastState.compose env41176 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound41176 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41177 : List Nat := [2,4,8,16,0,0,9,5,1,20,16,16,25,1,1,18,17,0,20,0,17,1,16,3,24,1,16,16,17,1,5,0,5,1,16,0]

theorem envBound41177 : H12AffineFastState.Bounded env41177 := by
  intro p hp
  have h : env41177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41176_41177 : H12AffineEnvironment.transform 5 0 env41176 = env41177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41176 == env41177) = true)

theorem identity41177 : scanCanonicalize (H12AffineFastState.compose env41177 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41177 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41178 : List Nat := [2,4,8,0,0,0,9,5,1,4,0,0,9,1,1,2,1,0,4,0,1,1,0,3,8,1,0,0,1,1,5,0,5,1,0,0]

theorem envBound41178 : H12AffineFastState.Bounded env41178 := by
  intro p hp
  have h : env41178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41177_41178 : H12AffineEnvironment.transform 3 0 env41177 = env41178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41177 == env41178) = true)

theorem identity41178 : scanCanonicalize (H12AffineFastState.compose env41178 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41178 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41179 : List Nat := [2,4,2,0,0,0,3,5,1,4,0,0,3,1,1,2,1,0,4,0,1,1,0,3,2,1,0,0,1,1,5,0,5,1,0,0]

theorem envBound41179 : H12AffineFastState.Bounded env41179 := by
  intro p hp
  have h : env41179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41178_41179 : H12AffineEnvironment.transform 2 2 env41178 = env41179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41178 == env41179) = true)

def env41180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67754,1024,32769,4161,62708,73755,41431,8328,65,122078,79130,91402,35324,1501,73891,256,21793,46213,74250]

theorem envBound41180 : H12AffineFastState.Bounded env41180 := by
  intro p hp
  have h : env41180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41164_41180 : H12AffineEnvironment.transform 16 24909 env41164 = env41180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env41164 == env41180) = true)

theorem identity41180 : scanCanonicalize (H12AffineFastState.compose env41180 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 34282) := by decide +kernel

theorem selectedBound41180 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env41181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,34282,24909,36160,1024,32769,4161,62708,42481,41431,8328,65,22836,45296,57568,35324,1501,42313,256,21793,46213,42976]

theorem envBound41181 : H12AffineFastState.Bounded env41181 := by
  intro p hp
  have h : env41181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41180_41181 : H12AffineEnvironment.transform 15 34282 env41180 = env41181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34282 env41180 == env41181) = true)

theorem identity41181 : scanCanonicalize (H12AffineFastState.compose env41181 (packedSelected [0,1,4,7,11,17,19,22,23,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41181 : packedSelected [0,1,4,7,11,17,19,22,23,28,31] rootPS < 2^1333 := by decide +kernel

def env41182 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,33951,24632,35893,1024,32769,4161,62708,42116,41122,8328,65,22593,45296,57568,34953,1192,42044,117,21588,46213,42645]

theorem envBound41182 : H12AffineFastState.Bounded env41182 := by
  intro p hp
  have h : env41182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41181_41182 : H12AffineEnvironment.transform 7 117 env41181 = env41182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41181 == env41182) = true)

theorem identity41182 : scanCanonicalize (H12AffineFastState.compose env41182 (packedSelected [0,4,5,14,16,17,18,22,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound41182 : packedSelected [0,4,5,14,16,17,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41183 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,216,1095,24632,3309,1024,217,4161,29740,9308,8314,8328,65,22593,12328,24632,2129,1192,9444,117,21588,13405,9805]

theorem envBound41183 : H12AffineFastState.Bounded env41183 := by
  intro p hp
  have h : env41183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41182_41183 : H12AffineEnvironment.transform 14 216 env41182 = env41183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env41182 == env41183) = true)

theorem identity41183 : scanCanonicalize (H12AffineFastState.compose env41183 (packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5293) := by decide +kernel

theorem selectedBound41183 : packedSelected [0,2,4,6,7,9,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env41184 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5293,216,1095,13461,3309,1024,217,4161,8321,9308,8314,8328,65,3308,12328,13461,2129,1192,9444,117,249,13405,9805]

theorem envBound41184 : H12AffineFastState.Bounded env41184 := by
  intro p hp
  have h : env41184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41183_41184 : H12AffineEnvironment.transform 13 5293 env41183 = env41184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5293 env41183 == env41184) = true)

theorem identity41184 : scanCanonicalize (H12AffineFastState.compose env41184 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41184 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41185 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,4096,8192,4296,216,34,12528,2184,101,217,4161,8321,8249,8314,8328,65,2185,12328,12528,2129,205,8321,117,249,12344,8744]

theorem envBound41185 : H12AffineFastState.Bounded env41185 := by
  intro p hp
  have h : env41185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41184_41185 : H12AffineEnvironment.transform 9 101 env41184 = env41185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41184 == env41185) = true)

theorem identity41185 : scanCanonicalize (H12AffineFastState.compose env41185 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound41185 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41186 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,2113,8192,2185,216,34,10417,2184,101,217,2048,8321,8249,8314,8328,65,2185,10345,10417,2129,205,8321,117,249,10361,8744]

theorem envBound41186 : H12AffineFastState.Bounded env41186 := by
  intro p hp
  have h : env41186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41185_41186 : H12AffineEnvironment.transform 11 2113 env41185 = env41186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env41185 == env41186) = true)

theorem identity41186 : scanCanonicalize (H12AffineFastState.compose env41186 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound41186 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env41187 : List Nat := [2,4,8,16,32,64,89,117,512,101,2048,2113,8192,2128,1,34,10344,2129,101,0,2048,8280,8249,8314,8273,65,2128,10345,10344,2129,20,8280,117,32,10361,8744]

theorem envBound41187 : H12AffineFastState.Bounded env41187 := by
  intro p hp
  have h : env41187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41186_41187 : H12AffineEnvironment.transform 6 89 env41186 = env41187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env41186 == env41187) = true)

theorem identity41187 : scanCanonicalize (H12AffineFastState.compose env41187 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41187 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41188 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,8192,81,1,34,8297,80,101,0,1,8280,8249,8314,8273,65,81,8296,8297,80,20,8280,117,32,8312,8744]

theorem envBound41188 : H12AffineFastState.Bounded env41188 := by
  intro p hp
  have h : env41188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41187_41188 : H12AffineEnvironment.transform 10 1 env41187 = env41188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41187 == env41188) = true)

theorem identity41188 : scanCanonicalize (H12AffineFastState.compose env41188 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41188 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41189 : List Nat := [2,4,8,16,32,64,89,117,512,101,1,64,41,81,1,34,64,80,101,0,1,113,16,83,120,65,81,65,64,80,20,113,117,32,81,513]

theorem envBound41189 : H12AffineFastState.Bounded env41189 := by
  intro p hp
  have h : env41189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41188_41189 : H12AffineEnvironment.transform 12 41 env41188 = env41189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41188 == env41189) = true)

theorem identity41189 : scanCanonicalize (H12AffineFastState.compose env41189 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound41189 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41190 : List Nat := [2,4,8,16,32,26,3,47,512,63,1,26,41,11,1,34,26,10,63,0,1,43,16,9,34,27,11,27,26,10,20,43,47,32,11,513]

theorem envBound41190 : H12AffineFastState.Bounded env41190 := by
  intro p hp
  have h : env41190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41189_41190 : H12AffineEnvironment.transform 5 26 env41189 = env41190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env41189 == env41190) = true)

theorem identity41190 : scanCanonicalize (H12AffineFastState.compose env41190 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound41190 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41191 : List Nat := [2,4,8,15,32,5,3,47,512,32,1,5,41,11,1,34,5,10,32,0,1,43,15,9,34,4,11,4,5,10,11,43,47,32,11,513]

theorem envBound41191 : H12AffineFastState.Bounded env41191 := by
  intro p hp
  have h : env41191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41190_41191 : H12AffineEnvironment.transform 3 15 env41190 = env41191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env41190 == env41191) = true)

theorem identity41191 : scanCanonicalize (H12AffineFastState.compose env41191 (packedSelected [0,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound41191 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env41192 : List Nat := [2,4,8,15,32,5,3,47,40,32,1,5,41,11,1,34,5,10,32,0,1,43,15,9,34,4,11,4,5,10,11,43,47,32,11,41]

theorem envBound41192 : H12AffineFastState.Bounded env41192 := by
  intro p hp
  have h : env41192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41191_41192 : H12AffineEnvironment.transform 8 40 env41191 = env41192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env41191 == env41192) = true)

theorem identity41192 : scanCanonicalize (H12AffineFastState.compose env41192 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound41192 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41193 : List Nat := [2,4,6,1,32,5,3,33,38,32,1,5,39,5,1,34,5,4,32,0,1,37,1,7,34,4,5,4,5,4,5,37,33,32,5,39]

theorem envBound41193 : H12AffineFastState.Bounded env41193 := by
  intro p hp
  have h : env41193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41192_41193 : H12AffineEnvironment.transform 2 6 env41192 = env41193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env41192 == env41193) = true)

theorem identity41193 : scanCanonicalize (H12AffineFastState.compose env41193 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound41193 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env41194 : List Nat := [2,4,6,1,4,5,3,5,2,4,1,5,3,5,1,6,5,4,4,0,1,1,1,7,6,4,5,4,5,4,5,1,5,4,5,3]

theorem envBound41194 : H12AffineFastState.Bounded env41194 := by
  intro p hp
  have h : env41194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41193_41194 : H12AffineEnvironment.transform 4 4 env41193 = env41194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env41193 == env41194) = true)

def env41195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound41195 : H12AffineFastState.Bounded env41195 := by
  intro p hp
  have h : env41195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40929_41195 : H12AffineEnvironment.transform 18 1025 env40929 = env41195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40929 == env41195) = true)

theorem identity41195 : scanCanonicalize (H12AffineFastState.compose env41195 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272560) := by decide +kernel

theorem selectedBound41195 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272560,16777216,8328,65,21227696,18973837,2391520,190641,17149089,23160257,257,19262493,19205560,17075063]

theorem envBound41196 : H12AffineFastState.Bounded env41196 := by
  intro p hp
  have h : env41196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41195_41196 : H12AffineEnvironment.transform 22 272560 env41195 = env41196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272560 env41195 == env41196) = true)

def env41197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227576,18973701,2391400,190521,17148969,23160137,257,19262493,19205424,17075063]

theorem envBound41197 : H12AffineFastState.Bounded env41197 := by
  intro p hp
  have h : env41197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41196_41197 : H12AffineEnvironment.transform 6 8 env41196 = env41197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41196 == env41197) = true)

theorem identity41197 : scanCanonicalize (H12AffineFastState.compose env41197 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound41197 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,16777216,8192,65,21227576,18973701,2118977,190521,16876544,23160137,257,18990132,18949401,16819038]

theorem envBound41198 : H12AffineFastState.Bounded env41198 := by
  intro p hp
  have h : env41198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41197_41198 : H12AffineEnvironment.transform 17 10281 env41197 = env41198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41197 == env41198) = true)

theorem identity41198 : scanCanonicalize (H12AffineFastState.compose env41198 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound41198 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env41199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,17,41311,8192,65,4409703,2172250,2118977,190521,75103,6407190,257,2188651,2196550,513]

theorem envBound41199 : H12AffineFastState.Bounded env41199 := by
  intro p hp
  have h : env41199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41198_41199 : H12AffineEnvironment.transform 23 41311 env41198 = env41199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env41198 == env41199) = true)

def env41200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41311,8192,65,4409703,115014,45405,190521,75103,4268042,257,98679,90202,513]

theorem envBound41200 : H12AffineFastState.Bounded env41200 := by
  intro p hp
  have h : env41200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41199_41200 : H12AffineEnvironment.transform 20 58396 env41199 = env41200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env41199 == env41200) = true)

def env41201 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41231,8192,17,4409655,114966,45325,190521,75023,4268042,257,98599,90122,513]

theorem envBound41201 : H12AffineFastState.Bounded env41201 := by
  intro p hp
  have h : env41201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41200_41201 : H12AffineEnvironment.transform 5 16 env41200 = env41201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41200 == env41201) = true)

theorem identity41201 : scanCanonicalize (H12AffineFastState.compose env41201 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound41201 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env41202 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1025,32769,58396,4194304,17,41231,8192,17,4385085,24860,45325,190521,34053,4227072,257,8493,49152,513]

theorem envBound41202 : H12AffineFastState.Bounded env41202 := by
  intro p hp
  have h : env41202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41201_41202 : H12AffineEnvironment.transform 15 40970 env41201 = env41202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env41201 == env41202) = true)

theorem identity41202 : scanCanonicalize (H12AffineFastState.compose env41202 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 155965) := by decide +kernel

theorem selectedBound41202 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41203 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,131072,10281,1025,32769,58396,155965,17,41231,8192,17,34816,24860,45325,190521,34053,188733,257,8493,49152,513]

theorem envBound41203 : H12AffineFastState.Bounded env41203 := by
  intro p hp
  have h : env41203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41202_41203 : H12AffineEnvironment.transform 21 155965 env41202 = env41203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 155965 env41202 == env41203) = true)

theorem identity41203 : scanCanonicalize (H12AffineFastState.compose env41203 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound41203 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41204 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1025,32769,58396,8492,17,41231,8192,17,34816,24860,45325,43048,34053,41260,257,8493,49152,513]

theorem envBound41204 : H12AffineFastState.Bounded env41204 := by
  intro p hp
  have h : env41204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41203_41204 : H12AffineEnvironment.transform 16 16401 env41203 = env41204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41203 == env41204) = true)

def env41205 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,4194304,17,41230,8192,16,4409654,114967,45324,190521,75022,4268042,257,98598,90123,513]

theorem envBound41205 : H12AffineFastState.Bounded env41205 := by
  intro p hp
  have h : env41205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41200_41205 : H12AffineEnvironment.transform 5 17 env41200 = env41205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41200 == env41205) = true)

theorem identity41205 : scanCanonicalize (H12AffineFastState.compose env41205 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246070) := by decide +kernel

theorem selectedBound41205 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env41206 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58396,246070,17,41230,8192,16,34816,114967,45324,190521,75022,188732,257,98598,90123,513]

theorem envBound41206 : H12AffineFastState.Bounded env41206 := by
  intro p hp
  have h : env41206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41205_41206 : H12AffineEnvironment.transform 21 246070 env41205 = env41206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246070 env41205 == env41206) = true)

theorem identity41206 : scanCanonicalize (H12AffineFastState.compose env41206 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41206 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env41207 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,65536,131072,10281,1025,0,25629,213303,17,8463,8192,16,2049,82198,12557,157752,75022,155965,257,65831,90123,513]

theorem envBound41207 : H12AffineFastState.Bounded env41207 := by
  intro p hp
  have h : env41207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41206_41207 : H12AffineEnvironment.transform 14 1 env41206 = env41207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41206 == env41207) = true)

theorem identity41207 : scanCanonicalize (H12AffineFastState.compose env41207 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound41207 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env41208 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,262,131072,10281,1025,0,25629,147505,17,8463,8192,16,2049,16400,12557,157752,9224,155965,257,33,24845,513]

theorem envBound41208 : H12AffineFastState.Bounded env41208 := by
  intro p hp
  have h : env41208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41207_41208 : H12AffineEnvironment.transform 15 262 env41207 = env41208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env41207 == env41208) = true)

theorem identity41208 : scanCanonicalize (H12AffineFastState.compose env41208 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound41208 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env41209 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,262,16401,10281,1025,0,25629,32,17,8463,8192,16,2049,16400,12557,10281,9224,8492,257,33,24845,513]

theorem envBound41209 : H12AffineFastState.Bounded env41209 := by
  intro p hp
  have h : env41209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41208_41209 : H12AffineEnvironment.transform 16 16401 env41208 = env41209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41208 == env41209) = true)

theorem identity41209 : scanCanonicalize (H12AffineFastState.compose env41209 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41209 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env41210 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,262,16401,2341,1025,0,17681,32,17,3,268,16,2049,16400,4097,2341,1284,32,257,33,16385,513]

theorem envBound41210 : H12AffineFastState.Bounded env41210 := by
  intro p hp
  have h : env41210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41209_41210 : H12AffineEnvironment.transform 12 268 env41209 = env41210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41209 == env41210) = true)

theorem identity41210 : scanCanonicalize (H12AffineFastState.compose env41210 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4388) := by decide +kernel

theorem selectedBound41210 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41211 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4388,1,262,4405,2341,1025,0,5173,32,17,3,268,16,2049,4404,4097,2341,1284,32,257,33,4389,513]

theorem envBound41211 : H12AffineFastState.Bounded env41211 := by
  intro p hp
  have h : env41211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41210_41211 : H12AffineEnvironment.transform 13 4388 env41210 = env41211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4388 env41210 == env41211) = true)

theorem identity41211 : scanCanonicalize (H12AffineFastState.compose env41211 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound41211 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41212 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,512,268,804,1,262,821,2341,1025,0,1589,32,17,3,268,16,2049,820,513,2341,1284,32,257,33,805,513]

theorem envBound41212 : H12AffineFastState.Bounded env41212 := by
  intro p hp
  have h : env41212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41211_41212 : H12AffineEnvironment.transform 11 512 env41211 = env41212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env41211 == env41212) = true)

theorem identity41212 : scanCanonicalize (H12AffineFastState.compose env41212 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound41212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41213 : List Nat := [2,4,8,16,32,17,8,256,512,769,2048,512,268,804,1,262,821,2341,768,0,308,32,17,3,268,16,2049,820,513,2341,517,32,257,33,805,513]

theorem envBound41213 : H12AffineFastState.Bounded env41213 := by
  intro p hp
  have h : env41213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41212_41213 : H12AffineEnvironment.transform 9 769 env41212 = env41213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env41212 == env41213) = true)

theorem identity41213 : scanCanonicalize (H12AffineFastState.compose env41213 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound41213 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41214 : List Nat := [2,4,8,16,32,17,8,53,512,564,2048,512,57,529,1,51,512,2064,565,0,1,32,17,3,57,16,2049,513,513,2064,517,32,52,33,528,513]

theorem envBound41214 : H12AffineFastState.Bounded env41214 := by
  intro p hp
  have h : env41214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41213_41214 : H12AffineEnvironment.transform 7 53 env41213 = env41214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env41213 == env41214) = true)

theorem identity41214 : scanCanonicalize (H12AffineFastState.compose env41214 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound41214 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41215 : List Nat := [2,4,8,16,32,17,8,53,512,564,16,512,57,529,1,51,512,0,565,0,1,32,17,3,57,16,17,513,513,0,517,32,52,33,528,513]

theorem envBound41215 : H12AffineFastState.Bounded env41215 := by
  intro p hp
  have h : env41215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41214_41215 : H12AffineEnvironment.transform 10 16 env41214 = env41215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env41214 == env41215) = true)

theorem identity41215 : scanCanonicalize (H12AffineFastState.compose env41215 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound41215 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41216 : List Nat := [2,4,8,16,32,17,8,53,33,21,16,33,57,48,1,51,33,0,20,0,1,32,17,3,57,16,17,32,32,0,36,32,52,33,49,32]

theorem envBound41216 : H12AffineFastState.Bounded env41216 := by
  intro p hp
  have h : env41216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41215_41216 : H12AffineEnvironment.transform 8 33 env41215 = env41216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env41215 == env41216) = true)

def env41217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,58397,4194304,17,41311,8192,65,4409703,115015,45404,190521,75103,4268043,257,98678,90203,513]

theorem envBound41217 : H12AffineFastState.Bounded env41217 := by
  intro p hp
  have h : env41217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41199_41217 : H12AffineEnvironment.transform 20 58397 env41199 = env41217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env41199 == env41217) = true)

theorem identity41217 : scanCanonicalize (H12AffineFastState.compose env41217 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41217 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58397,4194304,17,41311,8192,65,4352364,57676,45404,190521,1364,4194304,257,41341,16464,513]

theorem envBound41218 : H12AffineFastState.Bounded env41218 := by
  intro p hp
  have h : env41218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41217_41218 : H12AffineEnvironment.transform 15 8203 env41217 = env41218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41217 == env41218) = true)

theorem identity41218 : scanCanonicalize (H12AffineFastState.compose env41218 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 147553) := by decide +kernel

theorem selectedBound41218 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env41219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,58397,147553,17,41311,8192,65,10509,57676,45404,190521,1364,147553,257,41341,16464,513]

theorem envBound41219 : H12AffineFastState.Bounded env41219 := by
  intro p hp
  have h : env41219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41218_41219 : H12AffineEnvironment.transform 21 147553 env41218 = env41219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147553 env41218 == env41219) = true)

theorem identity41219 : scanCanonicalize (H12AffineFastState.compose env41219 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound41219 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,24861,10281,1025,32769,58397,8572,17,41311,8192,65,10509,57676,45404,35108,1364,8572,257,41341,16464,513]

theorem envBound41220 : H12AffineFastState.Bounded env41220 := by
  intro p hp
  have h : env41220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41219_41220 : H12AffineEnvironment.transform 16 24861 env41219 = env41220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env41219 == env41220) = true)

theorem identity41220 : scanCanonicalize (H12AffineFastState.compose env41220 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41220 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,16448,2420,1025,32769,50496,33,17,32770,349,65,2128,49169,36865,35108,1364,33,257,32800,16464,513]

theorem envBound41221 : H12AffineFastState.Bounded env41221 := by
  intro p hp
  have h : env41221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41220_41221 : H12AffineEnvironment.transform 12 349 env41220 = env41221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41220 == env41221) = true)

theorem identity41221 : scanCanonicalize (H12AffineFastState.compose env41221 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41221 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41222 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,262,16400,2340,1025,32769,50448,33,17,32770,269,17,2048,49169,36865,35108,1284,33,257,32800,16384,513]

theorem envBound41222 : H12AffineFastState.Bounded env41222 := by
  intro p hp
  have h : env41222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41221_41222 : H12AffineEnvironment.transform 5 16 env41221 = env41222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41221 == env41222) = true)

theorem identity41222 : scanCanonicalize (H12AffineFastState.compose env41222 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound41222 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41223 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,32768,262,5173,2340,1025,32769,37173,33,17,32770,269,17,2048,37940,36865,35108,1284,33,257,32800,5157,513]

theorem envBound41223 : H12AffineFastState.Bounded env41223 := by
  intro p hp
  have h : env41223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41222_41223 : H12AffineEnvironment.transform 13 5157 env41222 = env41223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env41222 == env41223) = true)

theorem identity41223 : scanCanonicalize (H12AffineFastState.compose env41223 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41223 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41224 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,0,262,5173,2340,1025,1,4405,33,17,2,269,17,2048,5172,4097,2340,1284,33,257,32,5157,513]

theorem envBound41224 : H12AffineFastState.Bounded env41224 := by
  intro p hp
  have h : env41224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41223_41224 : H12AffineEnvironment.transform 14 0 env41223 = env41224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41223 == env41224) = true)

def env41225 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2837,0,262,2821,2340,1025,1,3589,33,17,2,269,17,2048,2820,3889,2340,1284,33,257,32,2837,513]

theorem envBound41225 : H12AffineFastState.Bounded env41225 := by
  intro p hp
  have h : env41225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41224_41225 : H12AffineEnvironment.transform 11 3888 env41224 = env41225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env41224 == env41225) = true)

def env41226 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,269,1045,0,262,1029,1572,1025,1,261,33,17,2,269,17,1792,1028,49,1572,1284,33,257,32,1045,513]

theorem envBound41226 : H12AffineFastState.Bounded env41226 := by
  intro p hp
  have h : env41226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41225_41226 : H12AffineEnvironment.transform 10 1792 env41225 = env41226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41225 == env41226) = true)

theorem identity41226 : scanCanonicalize (H12AffineFastState.compose env41226 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound41226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41227 : List Nat := [2,4,8,16,32,16,8,256,512,516,260,48,269,529,0,262,513,32,517,1,261,33,17,2,269,17,260,512,49,32,768,33,257,32,529,513]

theorem envBound41227 : H12AffineFastState.Bounded env41227 := by
  intro p hp
  have h : env41227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41226_41227 : H12AffineEnvironment.transform 9 516 env41226 = env41227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env41226 == env41227) = true)

def env41228 : List Nat := [2,4,8,16,32,16,8,256,48,52,260,48,269,33,0,262,49,32,53,1,261,33,17,2,269,17,260,48,49,32,304,33,257,32,33,49]

theorem envBound41228 : H12AffineFastState.Bounded env41228 := by
  intro p hp
  have h : env41228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41227_41228 : H12AffineEnvironment.transform 8 48 env41227 = env41228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env41227 == env41228) = true)

theorem identity41228 : scanCanonicalize (H12AffineFastState.compose env41228 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound41228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41229 : List Nat := [2,4,8,16,32,16,8,63,48,52,59,48,50,33,0,57,49,32,53,1,58,33,17,2,50,17,59,48,49,32,15,33,62,32,33,49]

theorem envBound41229 : H12AffineFastState.Bounded env41229 := by
  intro p hp
  have h : env41229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41228_41229 : H12AffineEnvironment.transform 7 63 env41228 = env41229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env41228 == env41229) = true)

def leafEnv41229 : List Nat := [2,4,8,16,32,16,8,63,48,52,59,48,50,33,0,57,49,32,53,1,58,33,17,2,14,50,1,17,59,48,49,32,15,33,62,32,5,57,33,49,1,58,0]

def active41229 : List Nat := [0,1,2,3,4]

def tree41229 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41229 : H12WitnessSearch.Good tree41229 := H12GlobalWitnessIndex.good

theorem leafIdentity41229 : H12AffineFastState.composeSystem env41229 rootObs = leafEnv41229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41229 rootObs == leafEnv41229) = true)

theorem terminalChecked41229 : H12PackedTerminal.terminalCheckFast leafEnv41229 active41229 tree41229 = true := by decide +kernel

def env41230 : List Nat := [2,4,8,16,32,16,8,256,49,53,260,48,269,32,0,262,48,32,52,1,261,33,17,2,269,17,260,49,49,32,305,33,257,32,32,48]

theorem envBound41230 : H12AffineFastState.Bounded env41230 := by
  intro p hp
  have h : env41230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41227_41230 : H12AffineEnvironment.transform 8 49 env41227 = env41230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41227 == env41230) = true)

def env41231 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,269,1044,0,262,1028,1573,1025,1,260,33,17,2,269,17,1793,1029,48,1573,1284,33,257,32,1044,513]

theorem envBound41231 : H12AffineFastState.Bounded env41231 := by
  intro p hp
  have h : env41231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41225_41231 : H12AffineEnvironment.transform 10 1793 env41225 = env41231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41225 == env41231) = true)

theorem identity41231 : scanCanonicalize (H12AffineFastState.compose env41231 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound41231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41232 : List Nat := [2,4,8,16,32,16,8,256,276,1024,1045,49,269,1044,0,262,1028,1329,1025,1,260,33,17,2,269,17,1045,1029,48,1329,1284,33,257,32,1044,277]

theorem envBound41232 : H12AffineFastState.Bounded env41232 := by
  intro p hp
  have h : env41232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41231_41232 : H12AffineEnvironment.transform 8 276 env41231 = env41232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env41231 == env41232) = true)

def env41233 : List Nat := [2,4,8,16,32,16,8,256,276,52,33,49,269,32,0,262,48,261,53,1,260,33,17,2,269,17,33,49,48,261,304,33,257,32,32,277]

theorem envBound41233 : H12AffineFastState.Bounded env41233 := by
  intro p hp
  have h : env41233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41232_41233 : H12AffineEnvironment.transform 9 52 env41232 = env41233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41232 == env41233) = true)

theorem identity41233 : scanCanonicalize (H12AffineFastState.compose env41233 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41234 : List Nat := [2,4,8,10,32,10,8,256,270,46,33,43,269,32,0,262,42,261,47,1,260,33,11,2,269,11,33,43,42,261,298,33,257,32,32,271]

theorem envBound41234 : H12AffineFastState.Bounded env41234 := by
  intro p hp
  have h : env41234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41233_41234 : H12AffineEnvironment.transform 3 10 env41233 = env41234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41233 == env41234) = true)

def leafEnv41234 : List Nat := [2,4,8,10,32,10,8,256,270,46,33,43,269,32,0,262,42,261,47,1,260,33,11,2,299,269,1,11,33,43,42,261,298,33,257,32,5,262,32,271,1,260,0]

def active41234 : List Nat := [0,1,2,4,7]

def tree41234 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41234 : H12WitnessSearch.Good tree41234 := H12GlobalWitnessIndex.good

theorem leafIdentity41234 : H12AffineFastState.composeSystem env41234 rootObs = leafEnv41234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41234 rootObs == leafEnv41234) = true)

theorem terminalChecked41234 : H12PackedTerminal.terminalCheckFast leafEnv41234 active41234 tree41234 = true := by decide +kernel

def env41235 : List Nat := [2,4,8,16,32,16,8,256,276,53,32,49,269,33,0,262,49,260,52,1,260,33,17,2,269,17,32,48,48,260,305,33,257,32,33,277]

theorem envBound41235 : H12AffineFastState.Bounded env41235 := by
  intro p hp
  have h : env41235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41232_41235 : H12AffineEnvironment.transform 9 53 env41232 = env41235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41232 == env41235) = true)

def env41236 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2836,0,262,2820,2340,1025,1,3588,33,17,2,269,17,2048,2821,3888,2340,1284,33,257,32,2836,513]

theorem envBound41236 : H12AffineFastState.Bounded env41236 := by
  intro p hp
  have h : env41236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41224_41236 : H12AffineEnvironment.transform 11 3889 env41224 = env41236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env41224 == env41236) = true)

def env41237 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,269,1044,0,262,1028,1572,1025,1,260,33,17,2,269,17,1792,1029,48,1572,1284,33,257,32,1044,513]

theorem envBound41237 : H12AffineFastState.Bounded env41237 := by
  intro p hp
  have h : env41237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41236_41237 : H12AffineEnvironment.transform 10 1792 env41236 = env41237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41236 == env41237) = true)

theorem identity41237 : scanCanonicalize (H12AffineFastState.compose env41237 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41238 : List Nat := [2,4,8,16,32,16,8,256,49,1024,1329,49,269,1044,0,262,1028,1045,1025,1,260,33,17,2,269,17,1329,1029,48,1045,1284,33,257,32,1044,48]

theorem envBound41238 : H12AffineFastState.Bounded env41238 := by
  intro p hp
  have h : env41238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41237_41238 : H12AffineEnvironment.transform 8 49 env41237 = env41238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41237 == env41238) = true)

def env41239 : List Nat := [2,4,8,16,32,16,8,256,49,52,261,49,269,32,0,262,48,33,53,1,260,33,17,2,269,17,261,49,48,33,304,33,257,32,32,48]

theorem envBound41239 : H12AffineFastState.Bounded env41239 := by
  intro p hp
  have h : env41239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41238_41239 : H12AffineEnvironment.transform 9 52 env41238 = env41239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41238 == env41239) = true)

theorem identity41239 : scanCanonicalize (H12AffineFastState.compose env41239 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound41239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41240 : List Nat := [2,4,8,16,32,16,8,63,49,52,58,49,50,32,0,57,48,33,53,1,59,33,17,2,50,17,58,49,48,33,15,33,62,32,32,48]

theorem envBound41240 : H12AffineFastState.Bounded env41240 := by
  intro p hp
  have h : env41240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41239_41240 : H12AffineEnvironment.transform 7 63 env41239 = env41240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env41239 == env41240) = true)

def leafEnv41240 : List Nat := [2,4,8,16,32,16,8,63,49,52,58,49,50,32,0,57,48,33,53,1,59,33,17,2,14,50,1,17,58,49,48,33,15,33,62,32,5,57,32,48,1,59,0]

def active41240 : List Nat := [0,1,2,3,4]

def tree41240 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41240 : H12WitnessSearch.Good tree41240 := H12GlobalWitnessIndex.good

theorem leafIdentity41240 : H12AffineFastState.composeSystem env41240 rootObs = leafEnv41240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41240 rootObs == leafEnv41240) = true)

theorem terminalChecked41240 : H12PackedTerminal.terminalCheckFast leafEnv41240 active41240 tree41240 = true := by decide +kernel

def env41241 : List Nat := [2,4,8,16,32,16,8,256,49,53,260,49,269,33,0,262,49,32,52,1,260,33,17,2,269,17,260,48,48,32,305,33,257,32,33,48]

theorem envBound41241 : H12AffineFastState.Bounded env41241 := by
  intro p hp
  have h : env41241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41238_41241 : H12AffineEnvironment.transform 9 53 env41238 = env41241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41238 == env41241) = true)

def env41242 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,269,1045,0,262,1029,1573,1025,1,261,33,17,2,269,17,1793,1028,49,1573,1284,33,257,32,1045,513]

theorem envBound41242 : H12AffineFastState.Bounded env41242 := by
  intro p hp
  have h : env41242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41236_41242 : H12AffineEnvironment.transform 10 1793 env41236 = env41242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41236 == env41242) = true)

theorem identity41242 : scanCanonicalize (H12AffineFastState.compose env41242 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound41242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41243 : List Nat := [2,4,8,16,32,16,8,256,512,801,32,48,269,820,0,262,804,260,800,1,261,33,17,2,269,17,32,805,49,260,549,33,257,32,820,513]

theorem envBound41243 : H12AffineFastState.Bounded env41243 := by
  intro p hp
  have h : env41243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41242_41243 : H12AffineEnvironment.transform 9 801 env41242 = env41243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env41242 == env41243) = true)

def env41244 : List Nat := [2,4,8,16,32,16,8,256,276,53,32,48,269,32,0,262,48,260,52,1,261,33,17,2,269,17,32,49,49,260,305,33,257,32,32,277]

theorem envBound41244 : H12AffineFastState.Bounded env41244 := by
  intro p hp
  have h : env41244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41243_41244 : H12AffineEnvironment.transform 8 276 env41243 = env41244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env41243 == env41244) = true)

def env41245 : List Nat := [2,4,8,16,32,16,8,256,277,52,32,48,269,33,0,262,49,260,53,1,261,33,17,2,269,17,32,48,49,260,304,33,257,32,33,276]

theorem envBound41245 : H12AffineFastState.Bounded env41245 := by
  intro p hp
  have h : env41245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41243_41245 : H12AffineEnvironment.transform 8 277 env41243 = env41245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env41243 == env41245) = true)

theorem identity41245 : scanCanonicalize (H12AffineFastState.compose env41245 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41246 : List Nat := [2,4,8,10,32,10,8,256,271,46,32,42,269,33,0,262,43,260,47,1,261,33,11,2,269,11,32,42,43,260,298,33,257,32,33,270]

theorem envBound41246 : H12AffineFastState.Bounded env41246 := by
  intro p hp
  have h : env41246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41245_41246 : H12AffineEnvironment.transform 3 10 env41245 = env41246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41245 == env41246) = true)

def leafEnv41246 : List Nat := [2,4,8,10,32,10,8,256,271,46,32,42,269,33,0,262,43,260,47,1,261,33,11,2,299,269,1,11,32,42,43,260,298,33,257,32,5,262,33,270,1,261,0]

def active41246 : List Nat := [0,1,2,4,7]

def tree41246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41246 : H12WitnessSearch.Good tree41246 := H12GlobalWitnessIndex.good

theorem leafIdentity41246 : H12AffineFastState.composeSystem env41246 rootObs = leafEnv41246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41246 rootObs == leafEnv41246) = true)

theorem terminalChecked41246 : H12PackedTerminal.terminalCheckFast leafEnv41246 active41246 tree41246 = true := by decide +kernel

def env41247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,16777216,8193,65,21227577,18973700,2391401,190520,17148968,23160136,257,19262493,19205425,17075063]

theorem envBound41247 : H12AffineFastState.Bounded env41247 := by
  intro p hp
  have h : env41247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41196_41247 : H12AffineEnvironment.transform 6 9 env41196 = env41247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41196 == env41247) = true)

theorem identity41247 : scanCanonicalize (H12AffineFastState.compose env41247 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound41247 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,41292,16777216,8193,65,21227577,18973700,2159644,190520,16852317,23160136,257,18965864,18973764,16777730]

theorem envBound41248 : H12AffineFastState.Bounded env41248 := by
  intro p hp
  have h : env41248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41247_41248 : H12AffineEnvironment.transform 17 35189 env41247 = env41248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env41247 == env41248) = true)

theorem identity41248 : scanCanonicalize (H12AffineFastState.compose env41248 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 221208) := by decide +kernel

theorem selectedBound41248 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env41249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,41292,221208,8193,65,4229153,2286620,2159644,190520,148805,6423888,257,2229616,2286684,221722]

theorem envBound41249 : H12AffineFastState.Bounded env41249 := by
  intro p hp
  have h : env41249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41248_41249 : H12AffineEnvironment.transform 23 221208 env41248 = env41249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 221208 env41248 == env41249) = true)

def env41250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35189,1025,32769,2097152,4194304,41292,98644,8193,65,4229153,2098512,2159644,2420,41993,6349852,257,2155580,2098448,99158]

theorem envBound41250 : H12AffineFastState.Bounded env41250 := by
  intro p hp
  have h : env41250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41249_41250 : H12AffineEnvironment.transform 16 57676 env41249 = env41250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env41249 == env41250) = true)

def env41251 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,2097152,4194304,41016,98336,8193,65,4229153,2098212,2159644,2048,41993,6349852,117,2155580,2098276,98850]

theorem envBound41251 : H12AffineFastState.Bounded env41251 := by
  intro p hp
  have h : env41251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41250_41251 : H12AffineEnvironment.transform 7 116 env41250 = env41251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41250 == env41251) = true)

theorem identity41251 : scanCanonicalize (H12AffineFastState.compose env41251 (packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2114581) := by decide +kernel

theorem selectedBound41251 : packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env41252 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,2097152,2114581,41016,98336,8193,65,2149428,2098212,2159644,2048,41993,40969,117,2155580,2098276,98850]

theorem envBound41252 : H12AffineFastState.Bounded env41252 := by
  intro p hp
  have h : env41252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41251_41252 : H12AffineEnvironment.transform 21 2114581 env41251 = env41252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114581 env41251 == env41252) = true)

theorem identity41252 : scanCanonicalize (H12AffineFastState.compose env41252 (packedSelected [4,9,12,14,15,16,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound41252 : packedSelected [4,9,12,14,15,16,38,41] rootPS < 2^1333 := by decide +kernel

def env41253 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,57400,34817,1025,32769,91198,73771,41016,98336,8193,65,108554,90138,102434,2048,41993,40969,117,98306,90202,98850]

theorem envBound41253 : H12AffineFastState.Bounded env41253 := by
  intro p hp
  have h : env41253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41252_41253 : H12AffineEnvironment.transform 20 91198 env41252 = env41253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env41252 == env41253) = true)

theorem identity41253 : scanCanonicalize (H12AffineFastState.compose env41253 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound41253 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env41254 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,32768,65536,49217,34817,1025,32769,83015,65618,32833,98336,120,65,100467,82019,102434,2048,33904,32880,117,98306,81955,98850]

theorem envBound41254 : H12AffineFastState.Bounded env41254 := by
  intro p hp
  have h : env41254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41253_41254 : H12AffineEnvironment.transform 12 121 env41253 = env41254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env41253 == env41254) = true)

theorem identity41254 : scanCanonicalize (H12AffineFastState.compose env41254 (packedSelected [1,2,4,6,8,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound41254 : packedSelected [1,2,4,6,8,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env41255 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,81,65536,16400,2128,1025,80,83015,65618,16,65649,120,65,67618,82019,69747,2048,1057,33,117,65619,81955,66163]

theorem envBound41255 : H12AffineFastState.Bounded env41255 := by
  intro p hp
  have h : env41255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41254_41255 : H12AffineEnvironment.transform 14 81 env41254 = env41255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env41254 == env41255) = true)

theorem identity41255 : scanCanonicalize (H12AffineFastState.compose env41255 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound41255 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41256 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,81,21510,16400,2128,1025,80,4161,21588,16,21623,120,65,23588,5221,17525,2048,1057,33,117,21589,5157,22133]

theorem envBound41256 : H12AffineFastState.Bounded env41256 := by
  intro p hp
  have h : env41256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41255_41256 : H12AffineEnvironment.transform 15 21510 env41255 = env41256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env41255 == env41256) = true)

def env41257 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,2097152,4194304,41017,98337,8193,65,4229153,2098213,2159644,2049,41993,6349852,116,2155580,2098277,98851]

theorem envBound41257 : H12AffineFastState.Bounded env41257 := by
  intro p hp
  have h : env41257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41250_41257 : H12AffineEnvironment.transform 7 117 env41250 = env41257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41250 == env41257) = true)

theorem identity41257 : scanCanonicalize (H12AffineFastState.compose env41257 (packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2212918) := by decide +kernel

theorem selectedBound41257 : packedSelected [1,3,4,5,8,9,10,11,14,16,17,18,19,23,32] rootPS < 2^1333 := by decide +kernel

def env41258 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,2097152,2212918,41017,98337,8193,65,2182167,2098213,2159644,2049,41993,73770,116,2155580,2098277,98851]

theorem envBound41258 : H12AffineFastState.Bounded env41258 := by
  intro p hp
  have h : env41258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41257_41258 : H12AffineEnvironment.transform 21 2212918 env41257 = env41258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2212918 env41257 == env41258) = true)

theorem identity41258 : scanCanonicalize (H12AffineFastState.compose env41258 (packedSelected [4,9,12,14,15,16,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58397) := by decide +kernel

theorem selectedBound41258 : packedSelected [4,9,12,14,15,16,38,41] rootPS < 2^1333 := by decide +kernel

def env41259 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,57401,34816,1025,32769,58397,73771,41017,98337,8193,65,108554,57400,4097,2049,41993,73770,116,33,57464,98851]

theorem envBound41259 : H12AffineFastState.Bounded env41259 := by
  intro p hp
  have h : env41259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41258_41259 : H12AffineEnvironment.transform 20 58397 env41258 = env41259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env41258 == env41259) = true)

theorem identity41259 : scanCanonicalize (H12AffineFastState.compose env41259 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 41050) := by decide +kernel

theorem selectedBound41259 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env41260 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,41050,57401,34816,1025,32769,58397,32881,41017,8315,8193,65,2128,57400,4097,2049,41993,32880,116,33,57464,8825]

theorem envBound41260 : H12AffineFastState.Bounded env41260 := by
  intro p hp
  have h : env41260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41259_41260 : H12AffineEnvironment.transform 15 41050 env41259 = env41260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41050 env41259 == env41260) = true)

theorem identity41260 : scanCanonicalize (H12AffineFastState.compose env41260 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,15,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound41260 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41261 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,81,8203,24680,2129,1025,80,25676,32,8296,8315,8193,65,2128,24681,4097,2049,9304,33,116,33,24617,8825]

theorem envBound41261 : H12AffineFastState.Bounded env41261 := by
  intro p hp
  have h : env41261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41260_41261 : H12AffineEnvironment.transform 14 81 env41260 = env41261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env41260 == env41261) = true)

theorem identity41261 : scanCanonicalize (H12AffineFastState.compose env41261 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound41261 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env41262 : List Nat := [2,4,8,16,32,64,9,117,512,1024,528,4096,8192,16384,81,8203,24680,577,1025,80,25676,32,8296,8315,8193,65,576,24681,4097,529,9304,33,116,33,24617,8825]

theorem envBound41262 : H12AffineFastState.Bounded env41262 := by
  intro p hp
  have h : env41262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41261_41262 : H12AffineEnvironment.transform 10 528 env41261 = env41262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env41261 == env41262) = true)

theorem identity41262 : scanCanonicalize (H12AffineFastState.compose env41262 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41262 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env41263 : List Nat := [2,4,8,16,32,64,9,117,512,1024,528,4096,8192,13405,81,8203,5173,577,1025,80,4113,32,8296,8315,8193,65,576,5172,4097,529,9304,33,116,33,5236,8825]

theorem envBound41263 : H12AffineFastState.Bounded env41263 := by
  intro p hp
  have h : env41263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41262_41263 : H12AffineEnvironment.transform 13 13405 env41262 = env41263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41262 == env41263) = true)

theorem identity41263 : scanCanonicalize (H12AffineFastState.compose env41263 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41263 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41264 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,4096,8192,13324,0,8203,5173,528,1025,1,4113,32,8249,8234,8193,16,529,5172,4097,529,9225,33,37,33,5157,8744]

theorem envBound41264 : H12AffineFastState.Bounded env41264 := by
  intro p hp
  have h : env41264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41263_41264 : H12AffineEnvironment.transform 5 17 env41263 = env41264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41263 == env41264) = true)

theorem identity41264 : scanCanonicalize (H12AffineFastState.compose env41264 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 4664) := by decide +kernel

theorem selectedBound41264 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env41265 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,4096,4664,1588,0,4659,5173,528,1025,1,4113,32,4609,4626,4665,16,529,5172,4097,529,5681,33,37,33,5157,4112]

theorem envBound41265 : H12AffineFastState.Bounded env41265 := by
  intro p hp
  have h : env41265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41264_41265 : H12AffineEnvironment.transform 12 4664 env41264 = env41265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4664 env41264 == env41265) = true)

theorem identity41265 : scanCanonicalize (H12AffineFastState.compose env41265 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41265 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41266 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,4096,4664,513,0,4659,4096,528,52,1,4113,32,4609,4626,4665,16,529,4097,4097,529,4612,33,37,33,4112,4112]

theorem envBound41266 : H12AffineFastState.Bounded env41266 := by
  intro p hp
  have h : env41266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41265_41266 : H12AffineEnvironment.transform 9 53 env41265 = env41266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41265 == env41266) = true)

theorem identity41266 : scanCanonicalize (H12AffineFastState.compose env41266 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41266 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env41267 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,16,552,513,0,547,16,528,52,1,1,32,529,514,553,16,529,17,17,529,532,33,37,33,0,0]

theorem envBound41267 : H12AffineFastState.Bounded env41267 := by
  intro p hp
  have h : env41267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41266_41267 : H12AffineEnvironment.transform 11 16 env41266 = env41267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41266 == env41267) = true)

theorem identity41267 : scanCanonicalize (H12AffineFastState.compose env41267 (packedSelected [10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41267 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env41268 : List Nat := [2,4,8,16,32,17,9,36,0,53,16,16,40,1,0,35,16,16,52,1,1,32,17,2,41,16,17,17,17,17,20,33,37,33,0,0]

theorem envBound41268 : H12AffineFastState.Bounded env41268 := by
  intro p hp
  have h : env41268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41267_41268 : H12AffineEnvironment.transform 8 0 env41267 = env41268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41267 == env41268) = true)

theorem identity41268 : scanCanonicalize (H12AffineFastState.compose env41268 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41269 : List Nat := [2,4,8,16,1,17,9,5,0,20,16,16,9,1,0,2,16,16,21,1,1,1,17,2,8,16,17,17,17,17,20,0,4,0,0,0]

theorem envBound41269 : H12AffineFastState.Bounded env41269 := by
  intro p hp
  have h : env41269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41268_41269 : H12AffineEnvironment.transform 4 1 env41268 = env41269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41268 == env41269) = true)

theorem identity41269 : scanCanonicalize (H12AffineFastState.compose env41269 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound41269 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41270 : List Nat := [2,4,8,5,1,4,9,5,0,1,5,5,9,1,0,2,5,5,0,1,1,1,4,2,8,5,4,4,4,4,1,0,4,0,0,0]

theorem envBound41270 : H12AffineFastState.Bounded env41270 := by
  intro p hp
  have h : env41270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41269_41270 : H12AffineEnvironment.transform 3 5 env41269 = env41270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env41269 == env41270) = true)

def env41271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1025,32769,2097152,4194304,41292,98645,8193,65,4229153,2098513,2159644,2421,41992,6349853,257,2155581,2098449,99159]

theorem envBound41271 : H12AffineFastState.Bounded env41271 := by
  intro p hp
  have h : env41271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41249_41271 : H12AffineEnvironment.transform 16 57677 env41249 = env41271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env41249 == env41271) = true)

theorem identity41271 : scanCanonicalize (H12AffineFastState.compose env41271 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound41271 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1025,32769,2097152,4194304,41292,3,8193,65,4229153,2098513,2159644,2421,41992,6349853,257,2155581,2098449,513]

theorem envBound41272 : H12AffineFastState.Bounded env41272 := by
  intro p hp
  have h : env41272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41271_41272 : H12AffineEnvironment.transform 15 33110 env41271 = env41272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env41271 == env41272) = true)

theorem identity41272 : scanCanonicalize (H12AffineFastState.compose env41272 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound41272 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env41273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35189,1025,32769,2097152,41340,41292,3,8193,65,10589,2098513,2159644,2421,41992,2114913,257,2155581,2098449,513]

theorem envBound41273 : H12AffineFastState.Bounded env41273 := by
  intro p hp
  have h : env41273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41272_41273 : H12AffineEnvironment.transform 21 41340 env41272 = env41273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env41272 == env41273) = true)

theorem identity41273 : scanCanonicalize (H12AffineFastState.compose env41273 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound41273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8460,8282,16449,10361,1025,8461,2097152,112,64,3,8193,65,10589,2098513,2118928,2421,1284,2114913,257,2114865,2098449,513]

theorem envBound41274 : H12AffineFastState.Bounded env41274 := by
  intro p hp
  have h : env41274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41273_41274 : H12AffineEnvironment.transform 14 8460 env41273 = env41274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env41273 == env41274) = true)

theorem identity41274 : scanCanonicalize (H12AffineFastState.compose env41274 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41274 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41275 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8203,16400,10280,1025,8461,2097152,33,17,3,8193,16,10508,2098432,2118928,2340,1284,2114864,257,2114865,2098449,513]

theorem envBound41275 : H12AffineFastState.Bounded env41275 := by
  intro p hp
  have h : env41275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41274_41275 : H12AffineEnvironment.transform 5 17 env41274 = env41275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41274 == env41275) = true)

theorem identity41275 : scanCanonicalize (H12AffineFastState.compose env41275 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41275 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41276 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,8192,16384,8460,8203,16400,10280,52,8461,2097152,33,17,3,8193,16,10508,2097461,2117925,2340,305,2113797,257,2113796,2097444,513]

theorem envBound41276 : H12AffineFastState.Bounded env41276 := by
  intro p hp
  have h : env41276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41275_41276 : H12AffineEnvironment.transform 9 53 env41275 = env41276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41275 == env41276) = true)

theorem identity41276 : scanCanonicalize (H12AffineFastState.compose env41276 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41276 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41277 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,40,16384,292,35,16400,2048,52,293,2097152,33,17,3,41,16,2340,2097461,2117925,2340,305,2113797,257,2113796,2097444,513]

theorem envBound41277 : H12AffineFastState.Bounded env41277 := by
  intro p hp
  have h : env41277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41276_41277 : H12AffineEnvironment.transform 12 40 env41276 = env41277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41276 == env41277) = true)

theorem identity41277 : scanCanonicalize (H12AffineFastState.compose env41277 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41277 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41278 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,16384,1,35,16400,2048,52,0,2097152,33,17,3,41,16,2049,2097168,2117632,2049,20,2113568,36,2113569,2097153,513]

theorem envBound41278 : H12AffineFastState.Bounded env41278 := by
  intro p hp
  have h : env41278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41277_41278 : H12AffineEnvironment.transform 7 37 env41277 = env41278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41277 == env41278) = true)

theorem identity41278 : scanCanonicalize (H12AffineFastState.compose env41278 (packedSelected [1,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound41278 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env41279 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,4112,1,35,4096,2048,52,0,2097152,33,17,3,41,16,2049,2097168,2097168,2049,20,2101296,36,2101297,2097153,513]

theorem envBound41279 : H12AffineFastState.Bounded env41279 := by
  intro p hp
  have h : env41279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41278_41279 : H12AffineEnvironment.transform 13 4112 env41278 = env41279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env41278 == env41279) = true)

theorem identity41279 : scanCanonicalize (H12AffineFastState.compose env41279 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound41279 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41280 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,4096,40,4112,1,35,4096,48,52,0,2097152,33,17,3,41,16,49,2097168,2097168,49,20,2101296,36,2101297,2097153,513]

theorem envBound41280 : H12AffineFastState.Bounded env41280 := by
  intro p hp
  have h : env41280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41279_41280 : H12AffineEnvironment.transform 10 48 env41279 = env41280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env41279 == env41280) = true)

theorem identity41280 : scanCanonicalize (H12AffineFastState.compose env41280 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound41280 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env41281 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,1,35,32,48,52,0,2097152,33,17,3,41,16,49,2097168,2097168,49,20,2097168,36,2097169,2097153,513]

theorem envBound41281 : H12AffineFastState.Bounded env41281 := by
  intro p hp
  have h : env41281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41280_41281 : H12AffineEnvironment.transform 11 32 env41280 = env41281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env41280 == env41281) = true)

theorem identity41281 : scanCanonicalize (H12AffineFastState.compose env41281 (packedSelected [0,1,5] rootPS)) = affineNative (2^(20+1) ^^^ 48) := by decide +kernel

theorem selectedBound41281 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env41282 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,1,35,32,48,52,0,48,33,17,3,41,16,49,32,32,49,20,32,36,33,49,513]

theorem envBound41282 : H12AffineFastState.Bounded env41282 := by
  intro p hp
  have h : env41282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41281_41282 : H12AffineEnvironment.transform 20 48 env41281 = env41282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 48 env41281 == env41282) = true)

def leafEnv41282 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,40,48,1,35,32,48,52,0,48,33,17,3,21,41,1,16,49,32,32,49,20,32,36,33,5,34,49,513,1,49,0]

def active41282 : List Nat := [0,1,2,3,4,8]

def tree41282 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41282 : H12WitnessSearch.Good tree41282 := H12GlobalWitnessIndex.good

theorem leafIdentity41282 : H12AffineFastState.composeSystem env41282 rootObs = leafEnv41282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41282 rootObs == leafEnv41282) = true)

theorem terminalChecked41282 : H12PackedTerminal.terminalCheckFast leafEnv41282 active41282 tree41282 = true := by decide +kernel

def env41283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,1073741824,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound41283 : H12AffineFastState.Bounded env41283 := by
  intro p hp
  have h : env41283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37893_41283 : H12AffineEnvironment.transform 31 145662401 env37893 = env41283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env37893 == env41283) = true)

def env41284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254784,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound41284 : H12AffineFastState.Bounded env41284 := by
  intro p hp
  have h : env41284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41283_41284 : H12AffineEnvironment.transform 29 155254784 env41283 = env41284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env41283 == env41284) = true)

def env41285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254784,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound41285 : H12AffineFastState.Bounded env41285 := by
  intro p hp
  have h : env41285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41284_41285 : H12AffineEnvironment.transform 25 64 env41284 = env41285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env41284 == env41285) = true)

def env41286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound41286 : H12AffineFastState.Bounded env41286 := by
  intro p hp
  have h : env41286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41285_41286 : H12AffineEnvironment.transform 26 30393344 env41285 = env41286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env41285 == env41286) = true)

def env41287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound41287 : H12AffineFastState.Bounded env41287 := by
  intro p hp
  have h : env41287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41286_41287 : H12AffineEnvironment.transform 18 1024 env41286 = env41287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env41286 == env41287) = true)

theorem identity41287 : scanCanonicalize (H12AffineFastState.compose env41287 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41287 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8192,64,29868032,18973700,10507601,8830976,25265168,23160137,256,27378724,27337992,25207630]

theorem envBound41288 : H12AffineFastState.Bounded env41288 := by
  intro p hp
  have h : env41288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41287_41288 : H12AffineEnvironment.transform 6 8 env41287 = env41288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41287 == env41288) = true)

def env41289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,16777216,8192,64,21331968,18973700,2233681,294912,17024016,23160137,256,19104804,19096840,16966478]

theorem envBound41289 : H12AffineFastState.Bounded env41289 := by
  intro p hp
  have h : env41289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41288_41289 : H12AffineEnvironment.transform 22 147456 env41288 = env41289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env41288 == env41289) = true)

def env41290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118977,294912,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound41290 : H12AffineFastState.Bounded env41290 := by
  intro p hp
  have h : env41290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41289_41290 : H12AffineEnvironment.transform 16 16400 env41289 = env41290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41289 == env41290) = true)

def env41291 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118709,294912,16876544,23159869,116,18990132,18949228,16818730]

theorem envBound41291 : H12AffineFastState.Bounded env41291 := by
  intro p hp
  have h : env41291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41290_41291 : H12AffineEnvironment.transform 7 116 env41290 = env41291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41290 == env41291) = true)

theorem identity41291 : scanCanonicalize (H12AffineFastState.compose env41291 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound41291 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env41292 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,16777216,8192,64,21331968,17066042,374795,294912,16876544,21268483,116,17049610,17090642,16818730]

theorem envBound41292 : H12AffineFastState.Bounded env41292 := by
  intro p hp
  have h : env41292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41291_41292 : H12AffineEnvironment.transform 20 388158 env41291 = env41292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env41291 == env41292) = true)

def env41293 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,351316,8192,64,4250708,78958,374795,294912,317524,4314199,116,95326,103430,392830]

theorem envBound41293 : H12AffineFastState.Bounded env41293 := by
  intro p hp
  have h : env41293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41292_41293 : H12AffineEnvironment.transform 23 351316 env41292 = env41293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env41292 == env41293) = true)

theorem identity41293 : scanCanonicalize (H12AffineFastState.compose env41293 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound41293 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env41294 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,130175,1024,32769,4161,4194304,16,41003,8192,64,4250708,78958,17524,97407,74795,4314199,116,95326,103430,513]

theorem envBound41294 : H12AffineFastState.Bounded env41294 := by
  intro p hp
  have h : env41294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41293_41294 : H12AffineEnvironment.transform 17 130175 env41293 = env41294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env41293 == env41294) = true)

theorem identity41294 : scanCanonicalize (H12AffineFastState.compose env41294 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound41294 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env41295 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54359,16400,10280,1024,32769,4161,4194304,16,41003,8192,64,4250708,57401,17524,43048,61564,4194304,116,40969,16465,513]

theorem envBound41295 : H12AffineFastState.Bounded env41295 := by
  intro p hp
  have h : env41295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41294_41295 : H12AffineEnvironment.transform 15 54359 env41294 = env41295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env41294 == env41295) = true)

theorem identity41295 : scanCanonicalize (H12AffineFastState.compose env41295 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound41295 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env41296 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29708,8283,16400,10280,1024,29709,4161,4194304,16,21543,8192,64,4204632,5173,17524,23588,1136,4194304,116,21509,16465,513]

theorem envBound41296 : H12AffineFastState.Bounded env41296 := by
  intro p hp
  have h : env41296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41295_41296 : H12AffineEnvironment.transform 14 29708 env41295 = env41296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env41295 == env41296) = true)

theorem identity41296 : scanCanonicalize (H12AffineFastState.compose env41296 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29820) := by decide +kernel

theorem selectedBound41296 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41297 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29708,8283,16400,10280,1024,29709,4161,29820,16,21543,8192,64,23588,5173,17524,23588,1136,29820,116,21509,16465,513]

theorem envBound41297 : H12AffineFastState.Bounded env41297 := by
  intro p hp
  have h : env41297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41296_41297 : H12AffineEnvironment.transform 21 29820 env41296 = env41297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29820 env41296 == env41297) = true)

theorem identity41297 : scanCanonicalize (H12AffineFastState.compose env41297 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41297 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41298 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,21541,114,16400,2049,1024,21540,4161,21589,16,21543,41,64,23588,5173,17524,23588,1136,21589,116,21509,16465,513]

theorem envBound41298 : H12AffineFastState.Bounded env41298 := by
  intro p hp
  have h : env41298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41297_41298 : H12AffineEnvironment.transform 12 41 env41297 = env41298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41297 == env41298) = true)

theorem identity41298 : scanCanonicalize (H12AffineFastState.compose env41298 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41298 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41299 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21541,35,16400,2049,1024,21540,4112,21508,16,21543,41,17,23588,5173,17445,23588,1057,21508,37,21509,16384,513]

theorem envBound41299 : H12AffineFastState.Bounded env41299 := by
  intro p hp
  have h : env41299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41298_41299 : H12AffineEnvironment.transform 5 17 env41298 = env41299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41298 == env41299) = true)

theorem identity41299 : scanCanonicalize (H12AffineFastState.compose env41299 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound41299 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41300 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,35,5172,2049,1024,0,4112,32,16,3,41,17,2048,5173,4097,2048,1057,32,37,33,5156,513]

theorem envBound41300 : H12AffineFastState.Bounded env41300 := by
  intro p hp
  have h : env41300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41299_41300 : H12AffineEnvironment.transform 13 5156 env41299 = env41300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env41299 == env41300) = true)

theorem identity41300 : scanCanonicalize (H12AffineFastState.compose env41300 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41301 : List Nat := [2,4,8,0,32,1,8,37,512,1024,2048,4096,41,5156,1,35,5156,2049,1024,0,4096,32,0,3,41,1,2048,5157,4097,2048,1057,32,37,33,5156,513]

theorem envBound41301 : H12AffineFastState.Bounded env41301 := by
  intro p hp
  have h : env41301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41300_41301 : H12AffineEnvironment.transform 3 0 env41300 = env41301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41300 == env41301) = true)

theorem identity41301 : scanCanonicalize (H12AffineFastState.compose env41301 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound41301 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41302 : List Nat := [2,4,8,0,32,1,8,37,512,1024,2048,513,41,1573,1,35,1573,2049,1024,0,513,32,0,3,41,1,2048,1572,512,2048,1057,32,37,33,1573,513]

theorem envBound41302 : H12AffineFastState.Bounded env41302 := by
  intro p hp
  have h : env41302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41301_41302 : H12AffineEnvironment.transform 11 513 env41301 = env41302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env41301 == env41302) = true)

theorem identity41302 : scanCanonicalize (H12AffineFastState.compose env41302 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41302 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41303 : List Nat := [2,4,8,0,32,1,8,37,512,1024,1,513,41,1573,1,35,1573,0,1024,0,513,32,0,3,41,1,1,1572,512,1,1057,32,37,33,1573,513]

theorem envBound41303 : H12AffineFastState.Bounded env41303 := by
  intro p hp
  have h : env41303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41302_41303 : H12AffineEnvironment.transform 10 1 env41302 = env41303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41302 == env41303) = true)

theorem identity41303 : scanCanonicalize (H12AffineFastState.compose env41303 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound41303 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41304 : List Nat := [2,4,8,0,32,1,8,37,512,36,1,513,41,513,1,35,513,0,36,0,513,32,0,3,41,1,1,512,512,1,5,32,37,33,513,513]

theorem envBound41304 : H12AffineFastState.Bounded env41304 := by
  intro p hp
  have h : env41304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41303_41304 : H12AffineEnvironment.transform 9 36 env41303 = env41304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env41303 == env41304) = true)

theorem identity41304 : scanCanonicalize (H12AffineFastState.compose env41304 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound41304 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41305 : List Nat := [2,4,8,0,32,1,8,37,32,36,1,33,41,33,1,35,33,0,36,0,33,32,0,3,41,1,1,32,32,1,5,32,37,33,33,33]

theorem envBound41305 : H12AffineFastState.Bounded env41305 := by
  intro p hp
  have h : env41305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41304_41305 : H12AffineEnvironment.transform 8 32 env41304 = env41305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env41304 == env41305) = true)

theorem identity41305 : scanCanonicalize (H12AffineFastState.compose env41305 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41305 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41306 : List Nat := [2,4,8,0,0,1,8,5,0,4,1,1,9,1,1,3,1,0,4,0,1,0,0,3,9,1,1,0,0,1,5,0,5,1,1,1]

theorem envBound41306 : H12AffineFastState.Bounded env41306 := by
  intro p hp
  have h : env41306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41305_41306 : H12AffineEnvironment.transform 4 0 env41305 = env41306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41305 == env41306) = true)

def env41307 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,388158,4194304,16,351317,8192,64,4250709,78959,374795,294912,317525,4314198,116,95327,103431,392831]

theorem envBound41307 : H12AffineFastState.Bounded env41307 := by
  intro p hp
  have h : env41307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41292_41307 : H12AffineEnvironment.transform 23 351317 env41292 = env41307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env41292 == env41307) = true)

def env41308 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,115734,4194304,16,95357,8192,64,4250709,78959,102435,43048,61565,4314198,116,95327,103431,120407]

theorem envBound41308 : H12AffineFastState.Bounded env41308 := by
  intro p hp
  have h : env41308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41307_41308 : H12AffineEnvironment.transform 17 10280 env41307 = env41308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41307 == env41308) = true)

theorem identity41308 : scanCanonicalize (H12AffineFastState.compose env41308 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound41308 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41309 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,54358,16400,10280,1024,32769,4160,4194304,16,41003,8192,64,4250709,57401,17525,43048,61565,4194304,116,40969,16465,513]

theorem envBound41309 : H12AffineFastState.Bounded env41309 := by
  intro p hp
  have h : env41309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41308_41309 : H12AffineEnvironment.transform 15 54358 env41308 = env41309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env41308 == env41309) = true)

theorem identity41309 : scanCanonicalize (H12AffineFastState.compose env41309 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound41309 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env41310 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29709,8283,16400,10280,1024,29708,4160,4194304,16,21542,8192,64,4204632,5172,17525,23589,1136,4194304,116,21508,16465,513]

theorem envBound41310 : H12AffineFastState.Bounded env41310 := by
  intro p hp
  have h : env41310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41309_41310 : H12AffineEnvironment.transform 14 29709 env41309 = env41310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env41309 == env41310) = true)

theorem identity41310 : scanCanonicalize (H12AffineFastState.compose env41310 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29821) := by decide +kernel

theorem selectedBound41310 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41311 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29709,8283,16400,10280,1024,29708,4160,29821,16,21542,8192,64,23589,5172,17525,23589,1136,29821,116,21508,16465,513]

theorem envBound41311 : H12AffineFastState.Bounded env41311 := by
  intro p hp
  have h : env41311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41310_41311 : H12AffineEnvironment.transform 21 29821 env41310 = env41311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29821 env41310 == env41311) = true)

theorem identity41311 : scanCanonicalize (H12AffineFastState.compose env41311 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41311 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41312 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,21540,114,16400,2049,1024,21541,4160,21588,16,21542,41,64,23589,5172,17525,23589,1136,21588,116,21508,16465,513]

theorem envBound41312 : H12AffineFastState.Bounded env41312 := by
  intro p hp
  have h : env41312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41311_41312 : H12AffineEnvironment.transform 12 41 env41311 = env41312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41311 == env41312) = true)

theorem identity41312 : scanCanonicalize (H12AffineFastState.compose env41312 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41312 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41313 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,16384,21540,35,16400,2049,1024,21541,4113,21509,16,21542,41,17,23589,5172,17444,23589,1057,21509,37,21508,16384,513]

theorem envBound41313 : H12AffineFastState.Bounded env41313 := by
  intro p hp
  have h : env41313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41312_41313 : H12AffineEnvironment.transform 5 17 env41312 = env41313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41312 == env41313) = true)

theorem identity41313 : scanCanonicalize (H12AffineFastState.compose env41313 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound41313 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41314 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,35,5173,2049,1024,0,4113,32,16,3,41,17,2048,5172,4097,2048,1057,32,37,33,5157,513]

theorem envBound41314 : H12AffineFastState.Bounded env41314 := by
  intro p hp
  have h : env41314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41313_41314 : H12AffineEnvironment.transform 13 5157 env41313 = env41314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env41313 == env41314) = true)

theorem identity41314 : scanCanonicalize (H12AffineFastState.compose env41314 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41315 : List Nat := [2,4,8,1,32,0,8,37,512,1024,2048,4096,41,5157,1,35,5156,2049,1024,0,4096,32,1,3,41,0,2048,5157,4097,2048,1057,32,37,33,5157,513]

theorem envBound41315 : H12AffineFastState.Bounded env41315 := by
  intro p hp
  have h : env41315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41314_41315 : H12AffineEnvironment.transform 3 1 env41314 = env41315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41314 == env41315) = true)

theorem identity41315 : scanCanonicalize (H12AffineFastState.compose env41315 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound41315 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41316 : List Nat := [2,4,8,1,32,0,8,37,512,1024,2048,513,41,1572,1,35,1573,2049,1024,0,513,32,1,3,41,0,2048,1572,512,2048,1057,32,37,33,1572,513]

theorem envBound41316 : H12AffineFastState.Bounded env41316 := by
  intro p hp
  have h : env41316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41315_41316 : H12AffineEnvironment.transform 11 513 env41315 = env41316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env41315 == env41316) = true)

theorem identity41316 : scanCanonicalize (H12AffineFastState.compose env41316 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41316 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41317 : List Nat := [2,4,8,1,32,0,8,37,512,1024,1,513,41,1572,1,35,1573,0,1024,0,513,32,1,3,41,0,1,1572,512,1,1057,32,37,33,1572,513]

theorem envBound41317 : H12AffineFastState.Bounded env41317 := by
  intro p hp
  have h : env41317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41316_41317 : H12AffineEnvironment.transform 10 1 env41316 = env41317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41316 == env41317) = true)

theorem identity41317 : scanCanonicalize (H12AffineFastState.compose env41317 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound41317 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41318 : List Nat := [2,4,8,1,32,0,8,37,512,36,1,513,41,512,1,35,513,0,36,0,513,32,1,3,41,0,1,512,512,1,5,32,37,33,512,513]

theorem envBound41318 : H12AffineFastState.Bounded env41318 := by
  intro p hp
  have h : env41318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41317_41318 : H12AffineEnvironment.transform 9 36 env41317 = env41318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env41317 == env41318) = true)

theorem identity41318 : scanCanonicalize (H12AffineFastState.compose env41318 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound41318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41319 : List Nat := [2,4,8,1,32,0,8,37,32,36,1,33,41,32,1,35,33,0,36,0,33,32,1,3,41,0,1,32,32,1,5,32,37,33,32,33]

theorem envBound41319 : H12AffineFastState.Bounded env41319 := by
  intro p hp
  have h : env41319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41318_41319 : H12AffineEnvironment.transform 8 32 env41318 = env41319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env41318 == env41319) = true)

def env41320 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,115735,4194304,16,95356,8192,64,4250709,78959,102434,43049,61564,4314198,116,95327,103431,120406]

theorem envBound41320 : H12AffineFastState.Bounded env41320 := by
  intro p hp
  have h : env41320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41307_41320 : H12AffineEnvironment.transform 17 10281 env41307 = env41320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41307 == env41320) = true)

theorem identity41320 : scanCanonicalize (H12AffineFastState.compose env41320 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41320 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41321 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,58396,4194304,16,21623,8192,64,4250709,5220,45097,43049,61564,4256861,116,21588,46092,63069]

theorem envBound41321 : H12AffineFastState.Bounded env41321 := by
  intro p hp
  have h : env41321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41320_41321 : H12AffineEnvironment.transform 15 8203 env41320 = env41321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41320 == env41321) = true)

theorem identity41321 : scanCanonicalize (H12AffineFastState.compose env41321 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41321 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env41322 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29789,8203,16400,10281,1024,29788,4161,4194304,16,21623,8192,64,4204552,5220,17524,23668,1057,4194304,116,21588,16465,512]

theorem envBound41322 : H12AffineFastState.Bounded env41322 := by
  intro p hp
  have h : env41322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41321_41322 : H12AffineEnvironment.transform 14 29789 env41321 = env41322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41321 == env41322) = true)

theorem identity41322 : scanCanonicalize (H12AffineFastState.compose env41322 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound41322 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41323 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28729,8203,16400,10281,100,28728,4161,4194304,16,20499,8192,64,4204552,4096,16400,22544,69,4194304,116,20528,16465,512]

theorem envBound41323 : H12AffineFastState.Bounded env41323 := by
  intro p hp
  have h : env41323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41322_41323 : H12AffineEnvironment.transform 9 100 env41322 = env41323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env41322 == env41323) = true)

theorem identity41323 : scanCanonicalize (H12AffineFastState.compose env41323 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(21+1) ^^^ 18513) := by decide +kernel

theorem selectedBound41323 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env41324 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,16384,28729,8203,16400,10281,100,28728,4161,18513,16,20499,8192,64,24665,4096,16400,22544,69,18513,116,20528,16465,512]

theorem envBound41324 : H12AffineFastState.Bounded env41324 := by
  intro p hp
  have h : env41324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41323_41324 : H12AffineEnvironment.transform 21 18513 env41323 = env41324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 18513 env41323 == env41324) = true)

theorem identity41324 : scanCanonicalize (H12AffineFastState.compose env41324 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound41324 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env41325 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,2129,14440,8203,2113,10281,100,14441,4161,0,16,6210,8192,64,10248,4096,2113,4161,69,0,116,6241,2048,512]

theorem envBound41325 : H12AffineFastState.Bounded env41325 := by
  intro p hp
  have h : env41325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41324_41325 : H12AffineEnvironment.transform 13 2129 env41324 = env41325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env41324 == env41325) = true)

theorem identity41325 : scanCanonicalize (H12AffineFastState.compose env41325 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 6248) := by decide +kernel

theorem selectedBound41325 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41326 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,6248,2129,0,6243,2113,4161,100,1,4161,0,16,6210,6248,64,4192,4096,2113,4161,69,0,116,6241,2048,512]

theorem envBound41326 : H12AffineFastState.Bounded env41326 := by
  intro p hp
  have h : env41326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41325_41326 : H12AffineEnvironment.transform 12 6248 env41325 = env41326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6248 env41325 == env41326) = true)

theorem identity41326 : scanCanonicalize (H12AffineFastState.compose env41326 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound41326 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41327 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,2096,88,2129,0,83,2113,2161,100,1,2161,0,16,114,88,64,2128,2096,2113,2161,69,0,116,81,2048,512]

theorem envBound41327 : H12AffineFastState.Bounded env41327 := by
  intro p hp
  have h : env41327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41326_41327 : H12AffineEnvironment.transform 11 2096 env41326 = env41327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env41326 == env41327) = true)

theorem identity41327 : scanCanonicalize (H12AffineFastState.compose env41327 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41327 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41328 : List Nat := [2,4,8,16,0,64,8,84,512,68,2048,2064,88,2129,0,83,2113,2129,68,1,2129,0,16,82,88,64,2128,2064,2113,2129,69,0,84,81,2048,512]

theorem envBound41328 : H12AffineFastState.Bounded env41328 := by
  intro p hp
  have h : env41328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41327_41328 : H12AffineEnvironment.transform 4 0 env41327 = env41328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41327 == env41328) = true)

theorem identity41328 : scanCanonicalize (H12AffineFastState.compose env41328 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41328 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41329 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2064,8,2049,0,3,2065,2049,20,1,2049,0,16,2,8,16,2048,2064,2065,2049,21,0,4,1,2048,512]

theorem envBound41329 : H12AffineFastState.Bounded env41329 := by
  intro p hp
  have h : env41329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41328_41329 : H12AffineEnvironment.transform 5 16 env41328 = env41329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41328 == env41329) = true)

theorem identity41329 : scanCanonicalize (H12AffineFastState.compose env41329 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41330 : List Nat := [2,4,8,16,0,16,8,4,0,20,2048,2064,8,2049,0,3,2065,2049,20,1,2049,0,16,2,8,16,2048,2064,2065,2049,21,0,4,1,2048,0]

theorem envBound41330 : H12AffineFastState.Bounded env41330 := by
  intro p hp
  have h : env41330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41329_41330 : H12AffineEnvironment.transform 8 0 env41329 = env41330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41329 == env41330) = true)

theorem identity41330 : scanCanonicalize (H12AffineFastState.compose env41330 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound41330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41331 : List Nat := [2,4,8,16,0,16,8,4,0,20,30,14,8,31,0,3,15,31,20,1,31,0,16,2,8,16,30,14,15,31,21,0,4,1,30,0]

theorem envBound41331 : H12AffineFastState.Bounded env41331 := by
  intro p hp
  have h : env41331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41330_41331 : H12AffineEnvironment.transform 10 30 env41330 = env41331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env41330 == env41331) = true)

def leafEnv41331 : List Nat := [2,4,8,16,0,16,8,4,0,20,30,14,8,31,0,3,15,31,20,1,31,0,16,2,21,8,1,16,30,14,15,31,21,0,4,1,4,3,30,0,1,30,0]

def active41331 : List Nat := [0,1,2,3]

def tree41331 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41331 : H12WitnessSearch.Good tree41331 := H12GlobalWitnessIndex.good

theorem leafIdentity41331 : H12AffineFastState.composeSystem env41331 rootObs = leafEnv41331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41331 rootObs == leafEnv41331) = true)

theorem terminalChecked41331 : H12PackedTerminal.terminalCheckFast leafEnv41331 active41331 tree41331 = true := by decide +kernel

def env41332 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118708,294912,16876544,23159868,117,18990132,18949229,16818731]

theorem envBound41332 : H12AffineFastState.Bounded env41332 := by
  intro p hp
  have h : env41332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41290_41332 : H12AffineEnvironment.transform 7 117 env41290 = env41332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41290 == env41332) = true)

theorem identity41332 : scanCanonicalize (H12AffineFastState.compose env41332 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444308) := by decide +kernel

theorem selectedBound41332 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env41333 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,2444308,8192,64,6343700,313360,2118708,294912,2410516,4466728,117,296992,288889,2485823]

theorem envBound41333 : H12AffineFastState.Bounded env41333 := by
  intro p hp
  have h : env41333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41332_41333 : H12AffineEnvironment.transform 23 2444308 env41332 = env41333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444308 env41332 == env41333) = true)

def env41334 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,2097152,4194304,16,2199648,8192,64,6343700,5220,2118708,23668,2102368,4256860,117,21588,46093,2175563]

theorem envBound41334 : H12AffineFastState.Bounded env41334 := by
  intro p hp
  have h : env41334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41333_41334 : H12AffineEnvironment.transform 17 56436 env41333 = env41334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env41333 == env41334) = true)

def env41335 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,4160,4194304,16,98336,8192,64,4250708,5220,17524,23668,1056,4256860,117,21588,46093,74251]

theorem envBound41335 : H12AffineFastState.Bounded env41335 := by
  intro p hp
  have h : env41335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41334_41335 : H12AffineEnvironment.transform 20 4160 env41334 = env41335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41334 == env41335) = true)

theorem identity41335 : scanCanonicalize (H12AffineFastState.compose env41335 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound41335 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41336 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,16400,56436,1024,32769,4160,4194304,16,21622,8192,64,4250708,5220,17524,23668,1056,4256860,117,21588,46093,63069]

theorem envBound41336 : H12AffineFastState.Bounded env41336 := by
  intro p hp
  have h : env41336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41335_41336 : H12AffineEnvironment.transform 15 54358 env41335 = env41336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env41335 == env41336) = true)

theorem identity41336 : scanCanonicalize (H12AffineFastState.compose env41336 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 41048) := by decide +kernel

theorem selectedBound41336 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env41337 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,54358,16400,56436,1024,32769,4160,41048,16,21622,8192,64,31756,5220,17524,23668,1056,21508,117,21588,46093,63069]

theorem envBound41337 : H12AffineFastState.Bounded env41337 := by
  intro p hp
  have h : env41337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41336_41337 : H12AffineEnvironment.transform 21 41048 env41336 = env41337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41048 env41336 == env41337) = true)

theorem identity41337 : scanCanonicalize (H12AffineFastState.compose env41337 (packedSelected [4,10,11,12,14,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound41337 : packedSelected [4,10,11,12,14,19,22] rootPS < 2^1333 := by decide +kernel

def env41338 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,32768,40971,13389,43049,1024,32769,4160,41048,16,8235,8192,64,2129,5220,12329,10281,1056,8281,117,8201,46093,33280]

theorem envBound41338 : H12AffineFastState.Bounded env41338 := by
  intro p hp
  have h : env41338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41337_41338 : H12AffineEnvironment.transform 13 13405 env41337 = env41338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env41337 == env41338) = true)

theorem identity41338 : scanCanonicalize (H12AffineFastState.compose env41338 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41338 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41339 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,32768,32803,5221,34817,1024,32769,4160,32880,16,3,40,64,2129,5220,4097,2049,1056,113,117,33,37925,33280]

theorem envBound41339 : H12AffineFastState.Bounded env41339 := by
  intro p hp
  have h : env41339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41338_41339 : H12AffineEnvironment.transform 12 40 env41338 = env41339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41338 == env41339) = true)

end H12CloudChart1