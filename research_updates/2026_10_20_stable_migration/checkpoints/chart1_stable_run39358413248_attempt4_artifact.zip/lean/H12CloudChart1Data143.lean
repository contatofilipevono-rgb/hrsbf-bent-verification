import H12CloudChart1Data142

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans36260_36274 : H12AffineEnvironment.transform 7 117 env36260 = env36274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36260 == env36274) = true)

theorem identity36274 : scanCanonicalize (H12AffineFastState.compose env36274 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound36274 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36275 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,65,21039104,16834618,77835,2048,16876544,20971522,116,16818186,16793683,16818730]

theorem envBound36275 : H12AffineFastState.Bounded env36275 := by
  intro p hp
  have h : env36275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36274_36275 : H12AffineEnvironment.transform 20 91198 env36274 = env36275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env36274 == env36275) = true)

def env36276 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,17,21039104,16834618,77835,2048,16876544,20971522,36,16818186,16793603,16818730]

theorem envBound36276 : H12AffineFastState.Bounded env36276 := by
  intro p hp
  have h : env36276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36275_36276 : H12AffineEnvironment.transform 5 16 env36275 = env36276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36275 == env36276) = true)

theorem identity36276 : scanCanonicalize (H12AffineFastState.compose env36276 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292609) := by decide +kernel

theorem selectedBound36276 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36277 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,4292609,8193,17,34817,4284475,77835,2048,4195329,98307,36,4268043,4308994,4268587]

theorem envBound36277 : H12AffineFastState.Bounded env36277 := by
  intro p hp
  have h : env36277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36276_36277 : H12AffineEnvironment.transform 23 4292609 env36276 = env36277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292609 env36276 == env36277) = true)

theorem identity36277 : scanCanonicalize (H12AffineFastState.compose env36277 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound36277 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36278 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,16384,8232,65536,16401,10280,1025,8233,91198,4194304,17,4268073,8193,17,10281,4284475,77835,2048,4195329,73771,36,4268043,4284458,4268587]

theorem envBound36278 : H12AffineFastState.Bounded env36278 := by
  intro p hp
  have h : env36278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36277_36278 : H12AffineEnvironment.transform 14 8232 env36277 = env36278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env36277 == env36278) = true)

theorem identity36278 : scanCanonicalize (H12AffineFastState.compose env36278 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(13+1) ^^^ 13357) := by decide +kernel

theorem selectedBound36278 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env36279 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8232,65536,13372,10280,1025,8233,69651,4194304,17,4268073,8193,17,10281,4264982,77835,2048,4195329,73771,36,4268043,4264967,4268587]

theorem envBound36279 : H12AffineFastState.Bounded env36279 := by
  intro p hp
  have h : env36279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36278_36279 : H12AffineEnvironment.transform 13 13357 env36278 = env36279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13357 env36278 == env36279) = true)

theorem identity36279 : scanCanonicalize (H12AffineFastState.compose env36279 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound36279 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env36280 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13357,8232,65536,13372,10280,1025,8233,69651,8200,17,65569,8193,17,10281,78878,77835,2048,9225,73771,36,65539,78863,66083]

theorem envBound36280 : H12AffineFastState.Bounded env36280 := by
  intro p hp
  have h : env36280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36279_36280 : H12AffineEnvironment.transform 21 8200 env36279 = env36280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env36279 == env36280) = true)

theorem identity36280 : scanCanonicalize (H12AffineFastState.compose env36280 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36280 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36281 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5124,1,65536,5141,2049,1025,0,69651,33,17,65569,40,17,2048,70711,69666,2048,1056,65538,36,65539,70694,66083]

theorem envBound36281 : H12AffineFastState.Bounded env36281 := by
  intro p hp
  have h : env36281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36280_36281 : H12AffineEnvironment.transform 12 41 env36280 = env36281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36280 == env36281) = true)

theorem identity36281 : scanCanonicalize (H12AffineFastState.compose env36281 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound36281 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36282 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,41,2048,1,65536,2065,2049,1025,0,68631,33,17,65569,40,17,2048,67635,68646,2048,1056,65538,36,65539,67618,66083]

theorem envBound36282 : H12AffineFastState.Bounded env36282 := by
  intro p hp
  have h : env36282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36281_36282 : H12AffineEnvironment.transform 11 3076 env36281 = env36282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env36281 == env36282) = true)

theorem identity36282 : scanCanonicalize (H12AffineFastState.compose env36282 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound36282 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36283 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,3076,41,2048,1,35,2065,2049,1025,0,3124,33,17,2,40,17,2048,2064,3077,2048,1056,33,36,32,2049,512]

theorem envBound36283 : H12AffineFastState.Bounded env36283 := by
  intro p hp
  have h : env36283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36282_36283 : H12AffineEnvironment.transform 15 35 env36282 = env36283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env36282 == env36283) = true)

theorem identity36283 : scanCanonicalize (H12AffineFastState.compose env36283 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36283 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36284 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2097,41,2048,1,35,2065,2049,52,0,2049,33,17,2,40,17,2048,2064,2096,2048,21,33,36,32,2049,512]

theorem envBound36284 : H12AffineFastState.Bounded env36284 := by
  intro p hp
  have h : env36284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36283_36284 : H12AffineEnvironment.transform 9 53 env36283 = env36284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36283 == env36284) = true)

theorem identity36284 : scanCanonicalize (H12AffineFastState.compose env36284 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound36284 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36285 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,48,41,1,1,35,16,0,52,0,0,33,17,2,40,17,1,17,49,1,21,33,36,32,0,512]

theorem envBound36285 : H12AffineFastState.Bounded env36285 := by
  intro p hp
  have h : env36285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36284_36285 : H12AffineEnvironment.transform 10 1 env36284 = env36285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env36284 == env36285) = true)

theorem identity36285 : scanCanonicalize (H12AffineFastState.compose env36285 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36285 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36286 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,16,9,1,1,3,16,0,20,0,0,1,17,2,8,17,1,17,17,1,21,1,4,0,0,512]

theorem envBound36286 : H12AffineFastState.Bounded env36286 := by
  intro p hp
  have h : env36286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36285_36286 : H12AffineEnvironment.transform 4 0 env36285 = env36286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36285 == env36286) = true)

def env36287 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,16777216,8193,16,21039104,16834618,77835,2048,16876544,20971522,37,16818186,16793602,16818730]

theorem envBound36287 : H12AffineFastState.Bounded env36287 := by
  intro p hp
  have h : env36287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36275_36287 : H12AffineEnvironment.transform 5 17 env36275 = env36287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36275 == env36287) = true)

theorem identity36287 : scanCanonicalize (H12AffineFastState.compose env36287 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235274) := by decide +kernel

theorem selectedBound36287 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36288 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,4194304,17,4235274,8193,16,108554,4210736,77835,2048,4269066,40968,37,4194304,4251656,4194848]

theorem envBound36288 : H12AffineFastState.Bounded env36288 := by
  intro p hp
  have h : env36288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36287_36288 : H12AffineEnvironment.transform 23 4235274 env36287 = env36288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235274 env36287 == env36288) = true)

theorem identity36288 : scanCanonicalize (H12AffineFastState.compose env36288 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound36288 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env36289 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,32768,65536,16401,34816,1025,32769,91198,8201,17,32771,8193,16,108554,24633,77835,2048,66563,40968,37,8201,49153,8745]

theorem envBound36289 : H12AffineFastState.Bounded env36289 := by
  intro p hp
  have h : env36289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36288_36289 : H12AffineEnvironment.transform 21 8201 env36288 = env36289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env36288 == env36289) = true)

theorem identity36289 : scanCanonicalize (H12AffineFastState.compose env36289 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound36289 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env36290 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,8192,16384,8233,65536,16401,10281,1025,8232,91198,8201,17,8234,8193,16,67619,24633,77835,2048,66563,33,37,8201,24616,8745]

theorem envBound36290 : H12AffineFastState.Bounded env36290 := by
  intro p hp
  have h : env36290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36289_36290 : H12AffineEnvironment.transform 14 8233 env36289 = env36290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env36289 == env36290) = true)

theorem identity36290 : scanCanonicalize (H12AffineFastState.compose env36290 (packedSelected [12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound36290 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env36291 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,1052,16384,1077,65536,16401,3125,1025,1076,81954,1045,17,1078,1053,16,67619,17445,70679,2048,66563,33,37,1045,17460,1589]

theorem envBound36291 : H12AffineFastState.Bounded env36291 := by
  intro p hp
  have h : env36291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36290_36291 : H12AffineEnvironment.transform 12 1052 env36290 = env36291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env36290 == env36291) = true)

theorem identity36291 : scanCanonicalize (H12AffineFastState.compose env36291 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36291 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36292 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,16384,0,65536,16401,2048,52,1,81954,32,17,3,40,16,67619,16400,69666,2048,65590,33,37,32,16385,512]

theorem envBound36292 : H12AffineFastState.Bounded env36292 := by
  intro p hp
  have h : env36292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36291_36292 : H12AffineEnvironment.transform 9 53 env36291 = env36292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36291 == env36292) = true)

theorem identity36292 : scanCanonicalize (H12AffineFastState.compose env36292 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound36292 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36293 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,16384,0,2,16401,2048,52,1,16416,32,17,3,40,16,2081,16400,4128,2048,52,33,37,32,16385,512]

theorem envBound36293 : H12AffineFastState.Bounded env36293 := by
  intro p hp
  have h : env36293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36292_36293 : H12AffineEnvironment.transform 15 2 env36292 = env36293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env36292 == env36293) = true)

theorem identity36293 : scanCanonicalize (H12AffineFastState.compose env36293 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound36293 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36294 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4145,0,2,4128,2048,52,1,4113,32,17,3,40,16,2081,4129,4128,2048,52,33,37,32,4144,512]

theorem envBound36294 : H12AffineFastState.Bounded env36294 := by
  intro p hp
  have h : env36294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36293_36294 : H12AffineEnvironment.transform 13 4145 env36293 = env36294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env36293 == env36294) = true)

theorem identity36294 : scanCanonicalize (H12AffineFastState.compose env36294 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound36294 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env36295 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2097,41,2048,0,2,2065,2048,52,1,2080,32,17,3,40,16,2081,2064,2065,2048,52,33,37,32,2049,512]

theorem envBound36295 : H12AffineFastState.Bounded env36295 := by
  intro p hp
  have h : env36295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36294_36295 : H12AffineEnvironment.transform 11 2097 env36294 = env36295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env36294 == env36295) = true)

theorem identity36295 : scanCanonicalize (H12AffineFastState.compose env36295 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36295 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env36296 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,0,2,2065,2048,21,1,2049,1,17,3,9,16,2048,2064,2065,2048,21,0,4,1,2049,512]

theorem envBound36296 : H12AffineFastState.Bounded env36296 := by
  intro p hp
  have h : env36296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36295_36296 : H12AffineEnvironment.transform 4 1 env36295 = env36296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36295 == env36296) = true)

theorem identity36296 : scanCanonicalize (H12AffineFastState.compose env36296 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36297 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,2064,8,2048,0,2,2065,2048,21,1,2049,1,17,3,9,16,2048,2064,2065,2048,21,0,4,1,2049,1]

theorem envBound36297 : H12AffineFastState.Bounded env36297 := by
  intro p hp
  have h : env36297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36296_36297 : H12AffineEnvironment.transform 8 1 env36296 = env36297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36296 == env36297) = true)

theorem identity36297 : scanCanonicalize (H12AffineFastState.compose env36297 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound36297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36298 : List Nat := [2,4,8,16,1,17,9,5,1,20,30,14,8,30,0,2,15,30,21,1,31,1,17,3,9,16,30,14,15,30,21,0,4,1,31,1]

theorem envBound36298 : H12AffineFastState.Bounded env36298 := by
  intro p hp
  have h : env36298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36297_36298 : H12AffineEnvironment.transform 10 30 env36297 = env36298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env36297 == env36298) = true)

def leafEnv36298 : List Nat := [2,4,8,16,1,17,9,5,1,20,30,14,8,30,0,2,15,30,21,1,31,1,17,3,20,9,1,16,30,14,15,30,21,0,4,1,5,3,31,1,1,30,0]

def active36298 : List Nat := [0,1,2,3]

def tree36298 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36298 : H12WitnessSearch.Good tree36298 := H12GlobalWitnessIndex.good

theorem leafIdentity36298 : H12AffineFastState.composeSystem env36298 rootObs = leafEnv36298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36298 rootObs == leafEnv36298) = true)

theorem terminalChecked36298 : H12PackedTerminal.terminalCheckFast leafEnv36298 active36298 tree36298 = true := by decide +kernel

def env36299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35325,1025,32769,2097152,4194304,153,16777216,8328,65,21039613,18973837,2119112,2557,16876680,23160256,257,18990133,18949520,16819038]

theorem envBound36299 : H12AffineFastState.Bounded env36299 := by
  intro p hp
  have h : env36299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36247_36299 : H12AffineEnvironment.transform 16 16537 env36247 = env36299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env36247 == env36299) = true)

theorem identity36299 : scanCanonicalize (H12AffineFastState.compose env36299 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36299 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16537,10280,1025,8660,2097152,4194304,153,16777216,8328,65,21039613,18949464,2119112,2557,16852317,23160256,257,18965984,18949520,16777867]

theorem envBound36300 : H12AffineFastState.Bounded env36300 := by
  intro p hp
  have h : env36300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36299_36300 : H12AffineEnvironment.transform 14 8661 env36299 = env36300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36299 == env36300) = true)

def env36301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,17,16777216,8192,65,21039477,18949464,2118976,2421,16852317,23160136,257,18965864,18949400,16777731]

theorem envBound36301 : H12AffineFastState.Bounded env36301 := by
  intro p hp
  have h : env36301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36300_36301 : H12AffineEnvironment.transform 6 8 env36300 = env36301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36300 == env36301) = true)

theorem identity36301 : scanCanonicalize (H12AffineFastState.compose env36301 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(23+1) ^^^ 2188349) := by decide +kernel

theorem selectedBound36301 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env36302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,17,2188349,8192,65,6319432,16741,2118976,2421,2113888,4194677,257,341,16677,2188862]

theorem envBound36302 : H12AffineFastState.Bounded env36302 := by
  intro p hp
  have h : env36302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36301_36302 : H12AffineEnvironment.transform 23 2188349 env36301 = env36302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188349 env36301 == env36302) = true)

theorem identity36302 : scanCanonicalize (H12AffineFastState.compose env36302 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36302 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env36303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,4194304,17,2114614,8192,65,6319432,16741,2118976,2421,2113888,4194677,257,341,16677,2115125]

theorem envBound36303 : H12AffineFastState.Bounded env36303 := by
  intro p hp
  have h : env36303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36302_36303 : H12AffineEnvironment.transform 15 8203 env36302 = env36303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36302 == env36303) = true)

theorem identity36303 : scanCanonicalize (H12AffineFastState.compose env36303 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound36303 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env36304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,2097152,32,17,2114614,8192,65,2125160,16741,2118976,2421,2113888,341,257,341,16677,2115125]

theorem envBound36304 : H12AffineFastState.Bounded env36304 := by
  intro p hp
  have h : env36304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36303_36304 : H12AffineEnvironment.transform 21 32 env36303 = env36304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env36303 == env36304) = true)

theorem identity36304 : scanCanonicalize (H12AffineFastState.compose env36304 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36304 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8203,13625,10280,1025,8540,2097152,32,17,2109726,8192,65,2103360,13389,2105448,2421,2110536,341,257,341,13325,2110237]

theorem envBound36305 : H12AffineFastState.Bounded env36305 := by
  intro p hp
  have h : env36305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36304_36305 : H12AffineEnvironment.transform 13 13608 env36304 = env36305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36304 == env36305) = true)

theorem identity36305 : scanCanonicalize (H12AffineFastState.compose env36305 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(20+1) ^^^ 12605) := by decide +kernel

theorem selectedBound36305 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8203,13625,10280,1025,8540,12605,32,17,35,8192,65,10621,13389,4437,2421,1397,341,257,341,13325,544]

theorem envBound36306 : H12AffineFastState.Bounded env36306 := by
  intro p hp
  have h : env36306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36305_36306 : H12AffineEnvironment.transform 20 12605 env36305 = env36306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12605 env36305 == env36306) = true)

theorem identity36306 : scanCanonicalize (H12AffineFastState.compose env36306 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36306 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env36307 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,13405,8232,8203,13388,10280,1025,8233,12360,32,17,35,8192,65,10248,13389,4128,2048,1024,32,116,32,13325,544]

theorem envBound36307 : H12AffineFastState.Bounded env36307 := by
  intro p hp
  have h : env36307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36306_36307 : H12AffineEnvironment.transform 7 117 env36306 = env36307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36306 == env36307) = true)

def env36308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,2097152,4194304,16,16777216,8193,65,21039476,18949464,2118977,2420,16852317,23160137,257,18965865,18949401,16777730]

theorem envBound36308 : H12AffineFastState.Bounded env36308 := by
  intro p hp
  have h : env36308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36300_36308 : H12AffineEnvironment.transform 6 9 env36300 = env36308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36300 == env36308) = true)

theorem identity36308 : scanCanonicalize (H12AffineFastState.compose env36308 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound36308 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4262263,2172251,2118977,2420,75102,6382922,257,2188650,2172186,513]

theorem envBound36309 : H12AffineFastState.Bounded env36309 := by
  intro p hp
  have h : env36309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36308_36309 : H12AffineEnvironment.transform 23 3 env36308 = env36309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env36308 == env36309) = true)

theorem identity36309 : scanCanonicalize (H12AffineFastState.compose env36309 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36309 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,4194304,16,3,8193,65,4204925,2098513,2118977,2420,1364,6309184,257,2114912,2098448,513]

theorem envBound36310 : H12AffineFastState.Bounded env36310 := by
  intro p hp
  have h : env36310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36309_36310 : H12AffineEnvironment.transform 15 8202 env36309 = env36310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36309 == env36310) = true)

theorem identity36310 : scanCanonicalize (H12AffineFastState.compose env36310 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound36310 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,2097152,2114913,16,3,8193,65,2124828,2098513,2118977,2420,1364,33,257,2114912,2098448,513]

theorem envBound36311 : H12AffineFastState.Bounded env36311 := by
  intro p hp
  have h : env36311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36310_36311 : H12AffineEnvironment.transform 21 2114913 env36310 = env36311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env36310 == env36311) = true)

theorem identity36311 : scanCanonicalize (H12AffineFastState.compose env36311 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound36311 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16400,10280,1025,8541,17728,33,16,3,8193,65,10588,16401,4097,2420,1364,33,257,32,16464,513]

theorem envBound36312 : H12AffineFastState.Bounded env36312 := by
  intro p hp
  have h : env36312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36311_36312 : H12AffineEnvironment.transform 20 17728 env36311 = env36312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env36311 == env36312) = true)

theorem identity36312 : scanCanonicalize (H12AffineFastState.compose env36312 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound36312 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8540,8202,13340,10280,1025,8541,12620,33,16,3,8193,65,10588,13341,4097,2420,1364,33,257,32,13404,513]

theorem envBound36313 : H12AffineFastState.Bounded env36313 := by
  intro p hp
  have h : env36313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36312_36313 : H12AffineEnvironment.transform 13 13324 env36312 = env36313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env36312 == env36313) = true)

theorem identity36313 : scanCanonicalize (H12AffineFastState.compose env36313 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36313 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env36314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5457,1,343,5441,2421,1025,0,4113,33,16,3,348,65,2049,5440,4097,2420,1364,33,257,32,5377,513]

theorem envBound36314 : H12AffineFastState.Bounded env36314 := by
  intro p hp
  have h : env36314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36313_36314 : H12AffineEnvironment.transform 12 349 env36313 = env36314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36313 == env36314) = true)

theorem identity36314 : scanCanonicalize (H12AffineFastState.compose env36314 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound36314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36315 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,4096,349,4673,1,343,4689,2421,785,0,4113,33,16,3,348,65,2049,4688,4097,2420,580,33,257,32,4625,513]

theorem envBound36315 : H12AffineFastState.Bounded env36315 := by
  intro p hp
  have h : env36315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36314_36315 : H12AffineEnvironment.transform 9 784 env36314 = env36315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env36314 == env36315) = true)

theorem identity36315 : scanCanonicalize (H12AffineFastState.compose env36315 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound36315 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36316 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,80,349,529,1,343,513,2421,785,0,65,33,16,3,348,65,2049,512,81,2420,580,33,257,32,577,513]

theorem envBound36316 : H12AffineFastState.Bounded env36316 := by
  intro p hp
  have h : env36316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36315_36316 : H12AffineEnvironment.transform 11 80 env36315 = env36316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env36315 == env36316) = true)

def env36317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,4194304,147457,16777216,8328,65,21186916,18973837,2233680,149860,17024016,23160256,257,19104941,19096840,16966598]

theorem envBound36317 : H12AffineFastState.Bounded env36317 := by
  intro p hp
  have h : env36317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36246_36317 : H12AffineEnvironment.transform 17 182629 env36246 = env36317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env36246 == env36317) = true)

theorem identity36317 : scanCanonicalize (H12AffineFastState.compose env36317 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound36317 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env36318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,4194304,147457,188871,8328,65,4303011,2319690,2233680,149860,75223,6521863,257,2188650,2196687,513]

theorem envBound36318 : H12AffineFastState.Bounded env36318 := by
  intro p hp
  have h : env36318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36317_36318 : H12AffineEnvironment.transform 23 188871 env36317 = env36318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env36317 == env36318) = true)

def env36319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35325,1025,32769,2097152,4194304,153,41311,8328,65,4303011,2172370,2119112,2556,75223,6407327,257,2188650,2196687,513]

theorem envBound36319 : H12AffineFastState.Bounded env36319 := by
  intro p hp
  have h : env36319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36318_36319 : H12AffineEnvironment.transform 16 16536 env36318 = env36319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env36318 == env36319) = true)

theorem identity36319 : scanCanonicalize (H12AffineFastState.compose env36319 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36319 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env36320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,16536,10280,1025,8660,2097152,4194304,153,138,8328,65,4262262,2172370,2119112,2556,75223,6382922,257,2188650,2172186,513]

theorem envBound36320 : H12AffineFastState.Bounded env36320 := by
  intro p hp
  have h : env36320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36319_36320 : H12AffineEnvironment.transform 14 8661 env36319 = env36320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36319 == env36320) = true)

theorem identity36320 : scanCanonicalize (H12AffineFastState.compose env36320 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound36320 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env36321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10280,1025,8660,2097152,4194304,153,138,8328,65,4205044,2098512,2119112,2556,1365,6309320,257,2115048,2098584,513]

theorem envBound36321 : H12AffineFastState.Bounded env36321 := by
  intro p hp
  have h : env36321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36320_36321 : H12AffineEnvironment.transform 15 8322 env36320 = env36321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env36320 == env36321) = true)

theorem identity36321 : scanCanonicalize (H12AffineFastState.compose env36321 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound36321 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env36322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10280,1025,8660,2097152,168,153,138,8328,65,10588,2098512,2119112,2556,1365,2114912,257,2115048,2098584,513]

theorem envBound36322 : H12AffineFastState.Bounded env36322 := by
  intro p hp
  have h : env36322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36321_36322 : H12AffineEnvironment.transform 21 168 env36321 = env36322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env36321 == env36322) = true)

theorem identity36322 : scanCanonicalize (H12AffineFastState.compose env36322 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17817) := by decide +kernel

theorem selectedBound36322 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8322,16536,10280,1025,8660,17817,168,153,138,8328,65,10588,16585,4177,2556,1365,249,257,113,16385,513]

theorem envBound36323 : H12AffineFastState.Bounded env36323 := by
  intro p hp
  have h : env36323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36322_36323 : H12AffineEnvironment.transform 20 17817 env36322 = env36323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17817 env36322 == env36323) = true)

theorem identity36323 : scanCanonicalize (H12AffineFastState.compose env36323 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36323 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1025,8540,17681,32,17,2,8192,65,10588,16449,4177,2420,1365,113,257,113,16385,513]

theorem envBound36324 : H12AffineFastState.Bounded env36324 := by
  intro p hp
  have h : env36324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36323_36324 : H12AffineEnvironment.transform 6 8 env36323 = env36324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36323 == env36324) = true)

theorem identity36324 : scanCanonicalize (H12AffineFastState.compose env36324 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound36324 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,16384,293,114,16400,2128,1025,292,17681,32,17,2,120,65,2340,16449,4177,2420,1365,113,257,113,16385,513]

theorem envBound36325 : H12AffineFastState.Bounded env36325 := by
  intro p hp
  have h : env36325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36324_36325 : H12AffineEnvironment.transform 12 120 env36324 = env36325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env36324 == env36325) = true)

theorem identity36325 : scanCanonicalize (H12AffineFastState.compose env36325 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36325 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36326 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,120,16384,1,114,16400,2128,1025,0,17461,32,17,2,120,65,2048,16449,4177,2128,1137,113,37,113,16385,513]

theorem envBound36326 : H12AffineFastState.Bounded env36326 := by
  intro p hp
  have h : env36326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36325_36326 : H12AffineEnvironment.transform 7 36 env36325 = env36326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36325 == env36326) = true)

theorem identity36326 : scanCanonicalize (H12AffineFastState.compose env36326 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36326 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36327 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,120,16384,1,114,16400,2128,101,0,16465,32,17,2,120,65,2048,16449,4177,2128,21,113,37,113,16385,513]

theorem envBound36327 : H12AffineFastState.Bounded env36327 := by
  intro p hp
  have h : env36327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36326_36327 : H12AffineEnvironment.transform 9 100 env36326 = env36327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36326 == env36327) = true)

theorem identity36327 : scanCanonicalize (H12AffineFastState.compose env36327 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36327 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36328 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,16,120,16384,1,114,16400,2128,101,0,16465,32,17,2,120,65,2048,16449,65,2128,21,113,37,113,16385,513]

theorem envBound36328 : H12AffineFastState.Bounded env36328 := by
  intro p hp
  have h : env36328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36327_36328 : H12AffineEnvironment.transform 11 16 env36327 = env36328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36327 == env36328) = true)

theorem identity36328 : scanCanonicalize (H12AffineFastState.compose env36328 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36328 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36329 : List Nat := [2,4,8,16,32,64,8,36,512,100,0,16,120,16384,1,114,16400,80,101,0,16465,32,17,2,120,65,0,16449,65,80,21,113,37,113,16385,513]

theorem envBound36329 : H12AffineFastState.Bounded env36329 := by
  intro p hp
  have h : env36329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36328_36329 : H12AffineEnvironment.transform 10 0 env36328 = env36329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36328 == env36329) = true)

theorem identity36329 : scanCanonicalize (H12AffineFastState.compose env36329 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36329 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36330 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,16,40,16384,1,34,16400,0,53,0,16385,32,17,2,40,17,0,16401,17,0,21,33,37,33,16385,513]

theorem envBound36330 : H12AffineFastState.Bounded env36330 := by
  intro p hp
  have h : env36330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36329_36330 : H12AffineEnvironment.transform 5 16 env36329 = env36330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36329 == env36330) = true)

theorem identity36330 : scanCanonicalize (H12AffineFastState.compose env36330 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound36330 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36331 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,16,40,0,1,34,16,0,53,0,1,32,17,2,40,17,0,17,17,0,21,33,37,33,1,513]

theorem envBound36331 : H12AffineFastState.Bounded env36331 := by
  intro p hp
  have h : env36331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36330_36331 : H12AffineEnvironment.transform 13 0 env36330 = env36331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env36330 == env36331) = true)

theorem identity36331 : scanCanonicalize (H12AffineFastState.compose env36331 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36332 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,8,0,1,2,16,0,21,0,1,0,17,2,8,17,0,17,17,0,21,1,5,1,1,513]

theorem envBound36332 : H12AffineFastState.Bounded env36332 := by
  intro p hp
  have h : env36332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36331_36332 : H12AffineEnvironment.transform 4 0 env36331 = env36332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36331 == env36332) = true)

theorem identity36332 : scanCanonicalize (H12AffineFastState.compose env36332 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36332 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36333 : List Nat := [2,4,8,16,0,16,8,4,16,20,0,16,8,0,1,2,16,0,21,0,1,0,17,2,8,17,0,17,17,0,21,1,5,1,1,17]

theorem envBound36333 : H12AffineFastState.Bounded env36333 := by
  intro p hp
  have h : env36333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36332_36333 : H12AffineEnvironment.transform 8 16 env36332 = env36333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36332 == env36333) = true)

def env36334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35324,1025,32769,2097152,4194304,152,41310,8328,65,4303011,2172371,2119113,2557,75223,6407326,257,2188650,2196687,513]

theorem envBound36334 : H12AffineFastState.Bounded env36334 := by
  intro p hp
  have h : env36334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36318_36334 : H12AffineEnvironment.transform 16 16537 env36318 = env36334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env36318 == env36334) = true)

def env36335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4302891,2172251,2118977,2421,75103,6407190,257,2188650,2196551,513]

theorem envBound36335 : H12AffineFastState.Bounded env36335 := by
  intro p hp
  have h : env36335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36334_36335 : H12AffineEnvironment.transform 6 8 env36334 = env36335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36334 == env36335) = true)

theorem identity36335 : scanCanonicalize (H12AffineFastState.compose env36335 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36335 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229152,2098512,2118977,2421,1364,6349853,257,2114913,2139212,513]

theorem envBound36336 : H12AffineFastState.Bounded env36336 := by
  intro p hp
  have h : env36336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36335_36336 : H12AffineEnvironment.transform 15 8203 env36335 = env36336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36335 == env36336) = true)

theorem identity36336 : scanCanonicalize (H12AffineFastState.compose env36336 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound36336 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,2097152,41341,16,41310,8192,65,10589,2098512,2118977,2421,1364,2114912,257,2114913,2139212,513]

theorem envBound36337 : H12AffineFastState.Bounded env36337 := by
  intro p hp
  have h : env36337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36336_36337 : H12AffineEnvironment.transform 21 41341 env36336 = env36337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env36336 == env36337) = true)

theorem identity36337 : scanCanonicalize (H12AffineFastState.compose env36337 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound36337 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35188,1025,32769,38144,41341,16,41310,8192,65,10589,36944,49217,2421,1364,53344,257,53345,12620,513]

theorem envBound36338 : H12AffineFastState.Bounded env36338 := by
  intro p hp
  have h : env36338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36337_36338 : H12AffineEnvironment.transform 20 38144 env36337 = env36338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env36337 == env36338) = true)

theorem identity36338 : scanCanonicalize (H12AffineFastState.compose env36338 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound36338 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30776,1025,29005,25676,20529,16,20498,8192,65,10589,24860,12557,2421,1364,8492,257,8493,12620,513]

theorem envBound36339 : H12AffineFastState.Bounded env36339 := by
  intro p hp
  have h : env36339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36338_36339 : H12AffineEnvironment.transform 14 29004 env36338 = env36339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env36338 == env36339) = true)

theorem identity36339 : scanCanonicalize (H12AffineFastState.compose env36339 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36339 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36340 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,29004,8203,16401,30776,101,29005,24616,20529,16,20498,8192,65,10589,24860,12557,2421,304,8492,257,8493,12620,513]

theorem envBound36340 : H12AffineFastState.Bounded env36340 := by
  intro p hp
  have h : env36340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36339_36340 : H12AffineEnvironment.transform 9 100 env36339 = env36340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36339 == env36340) = true)

theorem identity36340 : scanCanonicalize (H12AffineFastState.compose env36340 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound36340 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env36341 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,10589,6161,8203,10572,4453,101,6160,2421,14700,16,14671,8192,65,10589,2113,12557,2421,304,8492,257,8493,12620,513]

theorem envBound36341 : H12AffineFastState.Bounded env36341 := by
  intro p hp
  have h : env36341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36340_36341 : H12AffineEnvironment.transform 13 10589 env36340 = env36341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env36340 == env36341) = true)

def env36342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41310,8193,65,4302890,2172250,2118976,2420,75102,6407191,257,2188650,2196550,513]

theorem envBound36342 : H12AffineFastState.Bounded env36342 := by
  intro p hp
  have h : env36342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36334_36342 : H12AffineEnvironment.transform 6 9 env36334 = env36342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36334 == env36342) = true)

theorem identity36342 : scanCanonicalize (H12AffineFastState.compose env36342 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound36342 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env36343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115734,4194304,17,41310,8193,65,4302890,57676,102742,2420,75102,4194305,257,41340,16464,513]

theorem envBound36343 : H12AffineFastState.Bounded env36343 := by
  intro p hp
  have h : env36343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36342_36343 : H12AffineEnvironment.transform 20 115734 env36342 = env36343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env36342 == env36343) = true)

def env36344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91198,4194304,17,374,8193,65,4261890,16740,78206,2420,75102,4194305,257,340,16464,513]

theorem envBound36344 : H12AffineFastState.Bounded env36344 := by
  intro p hp
  have h : env36344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36343_36344 : H12AffineEnvironment.transform 14 8232 env36343 = env36344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env36343 == env36344) = true)

theorem identity36344 : scanCanonicalize (H12AffineFastState.compose env36344 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound36344 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env36345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,342,16400,10589,1025,8233,25960,4194304,17,374,8193,65,4196692,16740,12328,2420,9224,4194305,257,340,16464,513]

theorem envBound36345 : H12AffineFastState.Bounded env36345 := by
  intro p hp
  have h : env36345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36344_36345 : H12AffineEnvironment.transform 15 342 env36344 = env36345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env36344 == env36345) = true)

theorem identity36345 : scanCanonicalize (H12AffineFastState.compose env36345 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound36345 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env36346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8232,342,16400,10589,1025,8233,25960,8573,17,374,8193,65,10281,16740,12328,2420,9224,8572,257,340,16464,513]

theorem envBound36346 : H12AffineFastState.Bounded env36346 := by
  intro p hp
  have h : env36346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36345_36346 : H12AffineEnvironment.transform 21 8573 env36345 = env36346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env36345 == env36346) = true)

theorem identity36346 : scanCanonicalize (H12AffineFastState.compose env36346 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36346 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,1,342,16400,2420,1025,0,17729,340,17,374,40,65,2048,16740,4097,2420,1057,341,257,340,16464,513]

theorem envBound36347 : H12AffineFastState.Bounded env36347 := by
  intro p hp
  have h : env36347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36346_36347 : H12AffineEnvironment.transform 12 41 env36346 = env36347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36346 == env36347) = true)

theorem identity36347 : scanCanonicalize (H12AffineFastState.compose env36347 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36347 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env36348 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,16384,1,262,16400,2340,1025,0,17681,260,17,294,40,17,2048,16692,4097,2340,1057,261,257,260,16384,513]

theorem envBound36348 : H12AffineFastState.Bounded env36348 := by
  intro p hp
  have h : env36348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36347_36348 : H12AffineEnvironment.transform 5 16 env36347 = env36348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36347 == env36348) = true)

theorem identity36348 : scanCanonicalize (H12AffineFastState.compose env36348 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound36348 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env36349 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,41,5157,1,262,5173,2340,1025,0,4404,260,17,294,40,17,2048,5393,4097,2340,1057,261,257,260,5157,513]

theorem envBound36349 : H12AffineFastState.Bounded env36349 := by
  intro p hp
  have h : env36349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36348_36349 : H12AffineEnvironment.transform 13 5157 env36348 = env36349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env36348 == env36349) = true)

theorem identity36349 : scanCanonicalize (H12AffineFastState.compose env36349 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36349 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env36350 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4113,33,17,3,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound36350 : H12AffineFastState.Bounded env36350 := by
  intro p hp
  have h : env36350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36349_36350 : H12AffineEnvironment.transform 7 37 env36349 = env36350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36349 == env36350) = true)

def env36351 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1045,1,35,1029,2049,1025,0,33,33,17,3,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound36351 : H12AffineFastState.Bounded env36351 := by
  intro p hp
  have h : env36351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36350_36351 : H12AffineEnvironment.transform 11 48 env36350 = env36351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36350 == env36351) = true)

theorem identity36351 : scanCanonicalize (H12AffineFastState.compose env36351 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36351 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36352 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,16,9,1045,1,3,1029,2049,1025,0,1,1,17,3,8,17,2048,1028,17,2049,1025,0,4,1,1045,513]

theorem envBound36352 : H12AffineFastState.Bounded env36352 := by
  intro p hp
  have h : env36352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36351_36352 : H12AffineEnvironment.transform 4 0 env36351 = env36352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36351 == env36352) = true)

def env36353 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,16,9,1,1,3,17,2049,21,0,1,1,17,3,8,17,2048,16,17,2049,21,0,4,1,1,513]

theorem envBound36353 : H12AffineFastState.Bounded env36353 := by
  intro p hp
  have h : env36353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36352_36353 : H12AffineEnvironment.transform 9 20 env36352 = env36353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env36352 == env36353) = true)

theorem identity36353 : scanCanonicalize (H12AffineFastState.compose env36353 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound36353 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36354 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,16,9,1,1,3,17,522,21,0,1,1,17,3,8,17,523,16,17,522,21,0,4,1,1,513]

theorem envBound36354 : H12AffineFastState.Bounded env36354 := by
  intro p hp
  have h : env36354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36353_36354 : H12AffineEnvironment.transform 10 523 env36353 = env36354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env36353 == env36354) = true)

def leafEnv36354 : List Nat := [2,4,8,16,0,16,9,5,512,20,523,16,9,1,1,3,17,522,21,0,1,1,17,3,20,8,1,17,523,16,17,522,21,0,4,1,5,2,1,513,1,1,0]

def active36354 : List Nat := [0,1,2,3,8]

def tree36354 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36354 : H12WitnessSearch.Good tree36354 := H12GlobalWitnessIndex.good

theorem leafIdentity36354 : H12AffineFastState.composeSystem env36354 rootObs = leafEnv36354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36354 rootObs == leafEnv36354) = true)

theorem terminalChecked36354 : H12PackedTerminal.terminalCheckFast leafEnv36354 active36354 tree36354 = true := by decide +kernel

def env36355 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,9,0,1,3,16,2049,20,0,1,1,17,3,8,17,2048,17,17,2049,20,0,4,1,0,513]

theorem envBound36355 : H12AffineFastState.Bounded env36355 := by
  intro p hp
  have h : env36355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36352_36355 : H12AffineEnvironment.transform 9 21 env36352 = env36355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36352 == env36355) = true)

theorem identity36355 : scanCanonicalize (H12AffineFastState.compose env36355 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36356 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,16,9,0,1,3,16,1,20,0,1,1,17,3,8,17,0,17,17,1,20,0,4,1,0,513]

theorem envBound36356 : H12AffineFastState.Bounded env36356 := by
  intro p hp
  have h : env36356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36355_36356 : H12AffineEnvironment.transform 10 0 env36355 = env36356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36355 == env36356) = true)

def leafEnv36356 : List Nat := [2,4,8,16,0,16,9,5,512,21,0,16,9,0,1,3,16,1,20,0,1,1,17,3,21,8,1,17,0,17,17,1,20,0,4,1,5,2,0,513,1,1,0]

def active36356 : List Nat := [0,1,2,3,8]

def tree36356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36356 : H12WitnessSearch.Good tree36356 := H12GlobalWitnessIndex.good

theorem leafIdentity36356 : H12AffineFastState.composeSystem env36356 rootObs = leafEnv36356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36356 rootObs == leafEnv36356) = true)

theorem terminalChecked36356 : H12PackedTerminal.terminalCheckFast leafEnv36356 active36356 tree36356 = true := by decide +kernel

def env36357 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1044,1,35,1028,2049,1025,0,32,33,17,3,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound36357 : H12AffineFastState.Bounded env36357 := by
  intro p hp
  have h : env36357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36350_36357 : H12AffineEnvironment.transform 11 49 env36350 = env36357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36350 == env36357) = true)

theorem identity36357 : scanCanonicalize (H12AffineFastState.compose env36357 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36358 : List Nat := [2,4,8,16,32,16,9,37,512,21,2048,49,41,1,1,35,17,2049,20,0,32,33,17,3,40,17,2048,16,48,2049,52,32,36,33,1,513]

theorem envBound36358 : H12AffineFastState.Bounded env36358 := by
  intro p hp
  have h : env36358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36357_36358 : H12AffineEnvironment.transform 9 21 env36357 = env36358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36357 == env36358) = true)

def env36359 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,17,9,1,1,3,17,2049,20,0,0,1,17,3,8,17,2048,16,16,2049,20,0,4,1,1,513]

theorem envBound36359 : H12AffineFastState.Bounded env36359 := by
  intro p hp
  have h : env36359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36358_36359 : H12AffineEnvironment.transform 4 0 env36358 = env36359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36358 == env36359) = true)

theorem identity36359 : scanCanonicalize (H12AffineFastState.compose env36359 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound36359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36360 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,17,9,1,1,3,17,0,20,0,0,1,17,3,8,17,1,16,16,0,20,0,4,1,1,513]

theorem envBound36360 : H12AffineFastState.Bounded env36360 := by
  intro p hp
  have h : env36360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36359_36360 : H12AffineEnvironment.transform 10 1 env36359 = env36360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env36359 == env36360) = true)

def leafEnv36360 : List Nat := [2,4,8,16,0,16,9,5,512,21,1,17,9,1,1,3,17,0,20,0,0,1,17,3,21,8,1,17,1,16,16,0,20,0,4,1,5,2,1,513,1,0,0]

def active36360 : List Nat := [0,1,2,3,8]

def tree36360 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36360 : H12WitnessSearch.Good tree36360 := H12GlobalWitnessIndex.good

theorem leafIdentity36360 : H12AffineFastState.composeSystem env36360 rootObs = leafEnv36360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36360 rootObs == leafEnv36360) = true)

theorem terminalChecked36360 : H12PackedTerminal.terminalCheckFast leafEnv36360 active36360 tree36360 = true := by decide +kernel

def env36361 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,16,8,1,1,2,17,2049,20,0,1,0,17,3,9,17,2048,16,17,2049,21,1,5,0,1,513]

theorem envBound36361 : H12AffineFastState.Bounded env36361 := by
  intro p hp
  have h : env36361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36358_36361 : H12AffineEnvironment.transform 4 1 env36358 = env36361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36358 == env36361) = true)

theorem identity36361 : scanCanonicalize (H12AffineFastState.compose env36361 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound36361 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36362 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,16,8,1,1,2,17,522,20,0,1,0,17,3,9,17,523,16,17,522,21,1,5,0,1,513]

theorem envBound36362 : H12AffineFastState.Bounded env36362 := by
  intro p hp
  have h : env36362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36361_36362 : H12AffineEnvironment.transform 10 523 env36361 = env36362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env36361 == env36362) = true)

def leafEnv36362 : List Nat := [2,4,8,16,1,16,9,4,512,21,523,16,8,1,1,2,17,522,20,0,1,0,17,3,20,9,1,17,523,16,17,522,21,1,5,0,5,3,1,513,1,1,0]

def active36362 : List Nat := [0,1,2,3,8]

def tree36362 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36362 : H12WitnessSearch.Good tree36362 := H12GlobalWitnessIndex.good

theorem leafIdentity36362 : H12AffineFastState.composeSystem env36362 rootObs = leafEnv36362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36362 rootObs == leafEnv36362) = true)

theorem terminalChecked36362 : H12PackedTerminal.terminalCheckFast leafEnv36362 active36362 tree36362 = true := by decide +kernel

def env36363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91199,4194304,17,375,8193,65,4261891,16741,78207,2420,75102,4194305,257,341,16464,513]

theorem envBound36363 : H12AffineFastState.Bounded env36363 := by
  intro p hp
  have h : env36363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36343_36363 : H12AffineEnvironment.transform 14 8233 env36343 = env36363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env36343 == env36363) = true)

theorem identity36363 : scanCanonicalize (H12AffineFastState.compose env36363 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36363 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env36364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,34,16400,10588,1025,8232,25629,4194304,17,375,8193,65,4196385,16741,12637,2420,9596,4194305,257,341,16464,513]

theorem envBound36364 : H12AffineFastState.Bounded env36364 := by
  intro p hp
  have h : env36364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36363_36364 : H12AffineEnvironment.transform 15 34 env36363 = env36364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36363 == env36364) = true)

theorem identity36364 : scanCanonicalize (H12AffineFastState.compose env36364 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound36364 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env36365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,34,16400,10588,1025,8232,25629,8493,17,375,8193,65,10508,16741,12637,2420,9596,8492,257,341,16464,513]

theorem envBound36365 : H12AffineFastState.Bounded env36365 := by
  intro p hp
  have h : env36365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36364_36365 : H12AffineEnvironment.transform 21 8493 env36364 = env36365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env36364 == env36365) = true)

theorem identity36365 : scanCanonicalize (H12AffineFastState.compose env36365 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36365 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env36366 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25629,8281,17,3,8193,65,10360,16401,12329,2048,9224,8280,117,33,16464,513]

theorem envBound36366 : H12AffineFastState.Bounded env36366 := by
  intro p hp
  have h : env36366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36365_36366 : H12AffineEnvironment.transform 7 116 env36365 = env36366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36365 == env36366) = true)

theorem identity36366 : scanCanonicalize (H12AffineFastState.compose env36366 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36366 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36367 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25629,8201,17,3,8193,17,10280,16401,12329,2048,9224,8200,37,33,16384,513]

theorem envBound36367 : H12AffineFastState.Bounded env36367 := by
  intro p hp
  have h : env36367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36366_36367 : H12AffineEnvironment.transform 5 16 env36366 = env36367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36366 == env36367) = true)

theorem identity36367 : scanCanonicalize (H12AffineFastState.compose env36367 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound36367 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36368 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,5157,8233,34,5173,10280,1025,8232,12344,8201,17,3,8193,17,10280,5172,12329,2048,9224,8200,37,33,5157,513]

theorem envBound36368 : H12AffineFastState.Bounded env36368 := by
  intro p hp
  have h : env36368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36367_36368 : H12AffineEnvironment.transform 13 5157 env36367 = env36368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env36367 == env36368) = true)

theorem identity36368 : scanCanonicalize (H12AffineFastState.compose env36368 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36368 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36369 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5157,1,34,5173,2048,1025,0,4112,33,17,3,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound36369 : H12AffineFastState.Bounded env36369 := by
  intro p hp
  have h : env36369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36368_36369 : H12AffineEnvironment.transform 12 40 env36368 = env36369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36368 == env36369) = true)

def env36370 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,40,1045,1,34,1029,2048,1025,0,32,33,17,3,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound36370 : H12AffineFastState.Bounded env36370 := by
  intro p hp
  have h : env36370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36369_36370 : H12AffineEnvironment.transform 11 48 env36369 = env36370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36369 == env36370) = true)

theorem identity36370 : scanCanonicalize (H12AffineFastState.compose env36370 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1540) := by decide +kernel

theorem selectedBound36370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36371 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1540,48,40,1045,1,34,1029,1540,1025,0,32,33,17,3,41,17,1540,1028,49,1540,1056,32,37,33,1045,513]

theorem envBound36371 : H12AffineFastState.Bounded env36371 := by
  intro p hp
  have h : env36371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36370_36371 : H12AffineEnvironment.transform 10 1540 env36370 = env36371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1540 env36370 == env36371) = true)

def env36372 : List Nat := [2,4,8,16,32,16,9,36,512,52,560,48,40,33,1,34,49,560,53,0,32,33,17,3,41,17,560,48,49,560,20,32,37,33,33,513]

theorem envBound36372 : H12AffineFastState.Bounded env36372 := by
  intro p hp
  have h : env36372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36371_36372 : H12AffineEnvironment.transform 9 52 env36371 = env36372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36371 == env36372) = true)

theorem identity36372 : scanCanonicalize (H12AffineFastState.compose env36372 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound36372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36373 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,10,18,27,1,24,11,522,15,0,26,27,17,3,19,17,522,10,11,522,20,26,31,27,27,513]

theorem envBound36373 : H12AffineFastState.Bounded env36373 := by
  intro p hp
  have h : env36373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36372_36373 : H12AffineEnvironment.transform 4 26 env36372 = env36373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env36372 == env36373) = true)

def leafEnv36373 : List Nat := [2,4,8,16,26,16,9,30,512,14,522,10,18,27,1,24,11,522,15,0,26,27,17,3,21,19,1,17,522,10,11,522,20,26,31,27,5,25,27,513,1,26,0]

def active36373 : List Nat := [0,1,2,3,8]

def tree36373 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36373 : H12WitnessSearch.Good tree36373 := H12GlobalWitnessIndex.good

theorem leafIdentity36373 : H12AffineFastState.composeSystem env36373 rootObs = leafEnv36373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36373 rootObs == leafEnv36373) = true)

theorem terminalChecked36373 : H12PackedTerminal.terminalCheckFast leafEnv36373 active36373 tree36373 = true := by decide +kernel

def env36374 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,48,40,32,1,34,48,561,52,0,32,33,17,3,41,17,561,49,49,561,21,32,37,33,32,513]

theorem envBound36374 : H12AffineFastState.Bounded env36374 := by
  intro p hp
  have h : env36374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36371_36374 : H12AffineEnvironment.transform 9 53 env36371 = env36374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36371 == env36374) = true)

theorem identity36374 : scanCanonicalize (H12AffineFastState.compose env36374 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36375 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,48,40,32,1,34,48,32,52,0,32,33,17,3,41,17,32,49,49,32,21,32,37,33,32,16]

theorem envBound36375 : H12AffineFastState.Bounded env36375 := by
  intro p hp
  have h : env36375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36374_36375 : H12AffineEnvironment.transform 8 17 env36374 = env36375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36374 == env36375) = true)

def leafEnv36375 : List Nat := [2,4,8,16,32,16,9,36,17,53,32,48,40,32,1,34,48,32,52,0,32,33,17,3,20,41,1,17,32,49,49,32,21,32,37,33,5,35,32,16,1,32,0]

def active36375 : List Nat := [0,1,2,3,4]

def tree36375 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36375 : H12WitnessSearch.Good tree36375 := H12GlobalWitnessIndex.good

theorem leafIdentity36375 : H12AffineFastState.composeSystem env36375 rootObs = leafEnv36375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36375 rootObs == leafEnv36375) = true)

theorem terminalChecked36375 : H12PackedTerminal.terminalCheckFast leafEnv36375 active36375 tree36375 = true := by decide +kernel

def env36376 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,40,1044,1,34,1028,2048,1025,0,33,33,17,3,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound36376 : H12AffineFastState.Bounded env36376 := by
  intro p hp
  have h : env36376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36369_36376 : H12AffineEnvironment.transform 11 49 env36369 = env36376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36369 == env36376) = true)

theorem identity36376 : scanCanonicalize (H12AffineFastState.compose env36376 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound36376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36377 : List Nat := [2,4,8,16,32,16,9,36,512,1024,561,49,40,1044,1,34,1028,561,1025,0,33,33,17,3,41,17,561,1029,48,561,1056,32,37,33,1044,513]

theorem envBound36377 : H12AffineFastState.Bounded env36377 := by
  intro p hp
  have h : env36377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36376_36377 : H12AffineEnvironment.transform 10 561 env36376 = env36377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env36376 == env36377) = true)

def env36378 : List Nat := [2,4,8,16,32,16,9,36,512,52,561,49,40,32,1,34,48,561,53,0,33,33,17,3,41,17,561,49,48,561,20,32,37,33,32,513]

theorem envBound36378 : H12AffineFastState.Bounded env36378 := by
  intro p hp
  have h : env36378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36377_36378 : H12AffineEnvironment.transform 9 52 env36377 = env36378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36377 == env36378) = true)

theorem identity36378 : scanCanonicalize (H12AffineFastState.compose env36378 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound36378 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36379 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,10,19,27,1,25,11,522,14,0,26,26,17,3,18,17,522,10,11,522,20,27,30,26,27,513]

theorem envBound36379 : H12AffineFastState.Bounded env36379 := by
  intro p hp
  have h : env36379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36378_36379 : H12AffineEnvironment.transform 4 27 env36378 = env36379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env36378 == env36379) = true)

def leafEnv36379 : List Nat := [2,4,8,16,27,16,9,31,512,15,522,10,19,27,1,25,11,522,14,0,26,26,17,3,21,18,1,17,522,10,11,522,20,27,30,26,5,24,27,513,1,26,0]

def active36379 : List Nat := [0,1,2,3,8]

def tree36379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36379 : H12WitnessSearch.Good tree36379 := H12GlobalWitnessIndex.good

theorem leafIdentity36379 : H12AffineFastState.composeSystem env36379 rootObs = leafEnv36379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36379 rootObs == leafEnv36379) = true)

theorem terminalChecked36379 : H12PackedTerminal.terminalCheckFast leafEnv36379 active36379 tree36379 = true := by decide +kernel

def env36380 : List Nat := [2,4,8,16,32,16,9,36,512,53,561,49,40,33,1,34,49,561,52,0,33,33,17,3,41,17,561,48,48,561,21,32,37,33,33,513]

theorem envBound36380 : H12AffineFastState.Bounded env36380 := by
  intro p hp
  have h : env36380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36377_36380 : H12AffineEnvironment.transform 9 53 env36377 = env36380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36377 == env36380) = true)

theorem identity36380 : scanCanonicalize (H12AffineFastState.compose env36380 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36380 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36381 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,49,40,33,1,34,49,33,52,0,33,33,17,3,41,17,33,48,48,33,21,32,37,33,33,17]

theorem envBound36381 : H12AffineFastState.Bounded env36381 := by
  intro p hp
  have h : env36381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36380_36381 : H12AffineEnvironment.transform 8 16 env36380 = env36381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36380 == env36381) = true)

def leafEnv36381 : List Nat := [2,4,8,16,32,16,9,36,16,53,33,49,40,33,1,34,49,33,52,0,33,33,17,3,20,41,1,17,33,48,48,33,21,32,37,33,5,35,33,17,1,33,0]

def active36381 : List Nat := [0,1,2,3,4]

def tree36381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36381 : H12WitnessSearch.Good tree36381 := H12GlobalWitnessIndex.good

theorem leafIdentity36381 : H12AffineFastState.composeSystem env36381 rootObs = leafEnv36381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36381 rootObs == leafEnv36381) = true)

theorem terminalChecked36381 : H12PackedTerminal.terminalCheckFast leafEnv36381 active36381 tree36381 = true := by decide +kernel

def env36382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound36382 : H12AffineFastState.Bounded env36382 := by
  intro p hp
  have h : env36382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34973_36382 : H12AffineEnvironment.transform 29 155254785 env34973 = env36382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env34973 == env36382) = true)

def env36383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound36383 : H12AffineFastState.Bounded env36383 := by
  intro p hp
  have h : env36383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36382_36383 : H12AffineEnvironment.transform 25 64 env36382 = env36383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env36382 == env36383) = true)

def env36384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound36384 : H12AffineFastState.Bounded env36384 := by
  intro p hp
  have h : env36384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36383_36384 : H12AffineEnvironment.transform 26 30393344 env36383 = env36384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env36383 == env36384) = true)

def env36385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound36385 : H12AffineFastState.Bounded env36385 := by
  intro p hp
  have h : env36385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36384_36385 : H12AffineEnvironment.transform 18 1024 env36384 = env36385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env36384 == env36385) = true)

theorem identity36385 : scanCanonicalize (H12AffineFastState.compose env36385 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound36385 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2212884,8328,64,15074324,16536,10507600,8830977,10502148,4235733,256,8388792,8446237,10577874]

theorem envBound36386 : H12AffineFastState.Bounded env36386 := by
  intro p hp
  have h : env36386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36385_36386 : H12AffineEnvironment.transform 23 2212884 env36385 = env36386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env36385 == env36386) = true)

def env36387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21912,2212884,8328,64,6705548,16536,2097352,431513,2102684,4235733,256,21792,46213,2175562]

theorem envBound36387 : H12AffineFastState.Bounded env36387 := by
  intro p hp
  have h : env36387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36386_36387 : H12AffineEnvironment.transform 22 21912 env36386 = env36387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21912 env36386 == env36387) = true)

def env36388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21912,98644,8328,64,4592844,16536,17800,431513,20700,4235733,256,21792,46213,96010]

theorem envBound36388 : H12AffineFastState.Bounded env36388 := by
  intro p hp
  have h : env36388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36387_36388 : H12AffineEnvironment.transform 20 17728 env36387 = env36388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env36387 == env36388) = true)

def env36389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21912,98644,8328,64,410092,16536,17800,431513,20700,62709,256,21792,46213,96010]

theorem envBound36389 : H12AffineFastState.Bounded env36389 := by
  intro p hp
  have h : env36389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36388_36389 : H12AffineEnvironment.transform 21 21792 env36388 = env36389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env36388 == env36389) = true)

def env36390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21776,98644,8192,64,409956,16400,17664,431377,20564,62589,256,21792,46093,96010]

theorem envBound36390 : H12AffineFastState.Bounded env36390 := by
  intro p hp
  have h : env36390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36389_36390 : H12AffineEnvironment.transform 6 8 env36389 = env36390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36389 == env36390) = true)

def env36391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398436,5392,4096,431377,1364,41341,256,32,46093,74250]

theorem envBound36391 : H12AffineFastState.Bounded env36391 := by
  intro p hp
  have h : env36391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36390_36391 : H12AffineEnvironment.transform 13 5376 env36390 = env36391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36390 == env36391) = true)

theorem identity36391 : scanCanonicalize (H12AffineFastState.compose env36391 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,32,16,73737,8192,64,398436,5392,4096,406604,1364,32,256,32,5456,74250]

theorem envBound36392 : H12AffineFastState.Bounded env36392 := by
  intro p hp
  have h : env36392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36391_36392 : H12AffineEnvironment.transform 14 8541 env36391 = env36392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36391 == env36392) = true)

theorem identity36392 : scanCanonicalize (H12AffineFastState.compose env36392 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound36392 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67699,1024,8540,4160,32,16,73737,8192,64,203799,5392,4096,212031,1364,32,256,32,5456,74250]

theorem envBound36393 : H12AffineFastState.Bounded env36393 := by
  intro p hp
  have h : env36393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36392_36393 : H12AffineEnvironment.transform 17 67699 env36392 = env36393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env36392 == env36393) = true)

theorem identity36393 : scanCanonicalize (H12AffineFastState.compose env36393 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound36393 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env36394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8575,131072,10508,1024,8540,4160,32,16,374,8192,64,146792,5392,4096,138560,1364,32,256,32,5456,885]

theorem envBound36394 : H12AffineFastState.Bounded env36394 := by
  intro p hp
  have h : env36394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36393_36394 : H12AffineEnvironment.transform 15 8575 env36393 = env36394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env36393 == env36394) = true)

theorem identity36394 : scanCanonicalize (H12AffineFastState.compose env36394 (packedSelected [1,8,9,11,14,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 15720) := by decide +kernel

theorem selectedBound36394 : packedSelected [1,8,9,11,14,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8575,15720,10508,1024,8540,4160,32,16,374,8192,64,0,5392,4096,8232,1364,32,256,32,5456,885]

theorem envBound36395 : H12AffineFastState.Bounded env36395 := by
  intro p hp
  have h : env36395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36394_36395 : H12AffineEnvironment.transform 16 15720 env36394 = env36395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 15720 env36394 == env36395) = true)

theorem identity36395 : scanCanonicalize (H12AffineFastState.compose env36395 (packedSelected [0,1,8,11,14,16,19,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36395 : packedSelected [0,1,8,11,14,16,19,20,27] rootPS < 2^1333 := by decide +kernel

def env36396 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8495,15672,10508,1024,8460,4112,32,16,294,8192,16,0,5392,4096,8232,1284,32,256,32,5376,805]

theorem envBound36396 : H12AffineFastState.Bounded env36396 := by
  intro p hp
  have h : env36396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36395_36396 : H12AffineEnvironment.transform 5 16 env36395 = env36396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36395 == env36396) = true)

theorem identity36396 : scanCanonicalize (H12AffineFastState.compose env36396 (packedSelected [1,2,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36396 : packedSelected [1,2,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env36397 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8233,8203,15388,10280,1024,8232,4112,32,16,2,8192,16,0,5172,4096,8232,1056,32,36,32,5156,513]

theorem envBound36397 : H12AffineFastState.Bounded env36397 := by
  intro p hp
  have h : env36397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36396_36397 : H12AffineEnvironment.transform 7 36 env36396 = env36397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36396 == env36397) = true)

def env36398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,17,98644,8192,64,398437,5393,4097,431377,1365,41340,256,33,46093,74251]

theorem envBound36398 : H12AffineFastState.Bounded env36398 := by
  intro p hp
  have h : env36398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36390_36398 : H12AffineEnvironment.transform 13 5377 env36390 = env36398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36390 == env36398) = true)

theorem identity36398 : scanCanonicalize (H12AffineFastState.compose env36398 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound36398 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36399 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,4161,33,17,98644,8192,64,171280,5393,4097,138340,1365,41340,256,33,46093,74251]

theorem envBound36399 : H12AffineFastState.Bounded env36399 := by
  intro p hp
  have h : env36399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36398_36399 : H12AffineEnvironment.transform 17 35189 env36398 = env36399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env36398 == env36399) = true)

theorem identity36399 : scanCanonicalize (H12AffineFastState.compose env36399 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound36399 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36400 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,35189,1024,32769,4161,33,17,98644,8192,64,34817,5393,4097,2421,1365,41340,256,33,46093,74251]

theorem envBound36400 : H12AffineFastState.Bounded env36400 := by
  intro p hp
  have h : env36400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36399_36400 : H12AffineEnvironment.transform 16 5393 env36399 = env36400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env36399 == env36400) = true)

theorem identity36400 : scanCanonicalize (H12AffineFastState.compose env36400 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36400 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,5393,35189,1024,32769,4161,33,17,41311,8192,64,34817,5393,4097,2421,1365,41340,256,33,46093,512]

theorem envBound36401 : H12AffineFastState.Bounded env36401 := by
  intro p hp
  have h : env36401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36400_36401 : H12AffineEnvironment.transform 15 8203 env36400 = env36401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36400 == env36401) = true)

theorem identity36401 : scanCanonicalize (H12AffineFastState.compose env36401 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound36401 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8201,8203,5393,10620,1024,8200,4161,33,17,342,8192,64,10248,5393,4097,2421,1365,373,256,33,5124,512]

theorem envBound36402 : H12AffineFastState.Bounded env36402 := by
  intro p hp
  have h : env36402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36401_36402 : H12AffineEnvironment.transform 14 8201 env36401 = env36402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env36401 == env36402) = true)

theorem identity36402 : scanCanonicalize (H12AffineFastState.compose env36402 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36402 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env36403 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8201,8203,5220,10249,1024,8200,4161,33,17,35,8192,64,10248,5220,4097,2048,1056,0,117,33,5124,512]

theorem envBound36403 : H12AffineFastState.Bounded env36403 := by
  intro p hp
  have h : env36403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36402_36403 : H12AffineEnvironment.transform 7 117 env36402 = env36403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36402 == env36403) = true)

theorem identity36403 : scanCanonicalize (H12AffineFastState.compose env36403 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2171) := by decide +kernel

theorem selectedBound36403 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36404 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2171,8192,3087,8201,8203,3103,10249,1024,8200,2106,33,17,35,8192,64,10248,3103,2170,2048,1056,0,117,33,3199,512]

theorem envBound36404 : H12AffineFastState.Bounded env36404 := by
  intro p hp
  have h : env36404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36403_36404 : H12AffineEnvironment.transform 11 2171 env36403 = env36404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2171 env36403 == env36404) = true)

theorem identity36404 : scanCanonicalize (H12AffineFastState.compose env36404 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound36404 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36405 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2171,121,3087,112,114,3103,2160,1024,113,2106,33,17,35,121,64,2161,3103,2170,2048,1056,0,117,33,3199,512]

theorem envBound36405 : H12AffineFastState.Bounded env36405 := by
  intro p hp
  have h : env36405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36404_36405 : H12AffineEnvironment.transform 12 121 env36404 = env36405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env36404 == env36405) = true)

theorem identity36405 : scanCanonicalize (H12AffineFastState.compose env36405 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound36405 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env36406 : List Nat := [2,4,8,16,32,26,8,47,512,1024,2048,2081,35,3087,42,40,3103,2090,1024,43,2106,33,17,35,35,26,2091,3103,2080,2048,1056,0,47,33,3109,512]

theorem envBound36406 : H12AffineFastState.Bounded env36406 := by
  intro p hp
  have h : env36406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36405_36406 : H12AffineEnvironment.transform 5 26 env36405 = env36406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env36405 == env36406) = true)

theorem identity36406 : scanCanonicalize (H12AffineFastState.compose env36406 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36406 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env36407 : List Nat := [2,4,8,16,1,26,8,14,512,1024,2048,2048,2,3087,11,9,3103,2059,1024,10,2075,0,17,2,2,26,2058,3103,2049,2048,1025,0,14,0,3076,512]

theorem envBound36407 : H12AffineFastState.Bounded env36407 := by
  intro p hp
  have h : env36407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36406_36407 : H12AffineEnvironment.transform 4 1 env36406 = env36407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36406 == env36407) = true)

theorem identity36407 : scanCanonicalize (H12AffineFastState.compose env36407 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound36407 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36408 : List Nat := [2,4,8,16,1,26,8,14,512,21,2048,2048,2,2074,11,9,2058,2059,21,10,2075,0,17,2,2,26,2058,2058,2049,2048,20,0,14,0,2065,512]

theorem envBound36408 : H12AffineFastState.Bounded env36408 := by
  intro p hp
  have h : env36408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36407_36408 : H12AffineEnvironment.transform 9 21 env36407 = env36408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env36407 == env36408) = true)

theorem identity36408 : scanCanonicalize (H12AffineFastState.compose env36408 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound36408 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36409 : List Nat := [2,4,8,16,1,26,8,14,14,21,2048,2048,2,2074,11,9,2058,2059,21,10,2075,0,17,2,2,26,2058,2058,2049,2048,20,0,14,0,2065,14]

theorem envBound36409 : H12AffineFastState.Bounded env36409 := by
  intro p hp
  have h : env36409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36408_36409 : H12AffineEnvironment.transform 8 14 env36408 = env36409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env36408 == env36409) = true)

theorem identity36409 : scanCanonicalize (H12AffineFastState.compose env36409 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36409 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36410 : List Nat := [2,4,8,11,1,1,8,14,14,14,2048,2048,2,2049,11,9,2058,2059,14,10,2048,0,10,2,2,1,2058,2058,2049,2048,15,0,14,0,2058,14]

theorem envBound36410 : H12AffineFastState.Bounded env36410 := by
  intro p hp
  have h : env36410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36409_36410 : H12AffineEnvironment.transform 3 11 env36409 = env36410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36409 == env36410) = true)

theorem identity36410 : scanCanonicalize (H12AffineFastState.compose env36410 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36410 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36411 : List Nat := [2,1,8,11,1,1,8,11,11,11,2048,2048,2,2049,11,9,2058,2059,11,10,2048,0,10,2,2,1,2058,2058,2049,2048,10,0,11,0,2058,11]

theorem envBound36411 : H12AffineFastState.Bounded env36411 := by
  intro p hp
  have h : env36411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36410_36411 : H12AffineEnvironment.transform 1 1 env36410 = env36411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36410 == env36411) = true)

theorem identity36411 : scanCanonicalize (H12AffineFastState.compose env36411 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36412 : List Nat := [2,1,0,3,1,1,0,3,3,3,2048,2048,2,2049,3,1,2050,2051,3,2,2048,0,2,2,2,1,2050,2050,2049,2048,2,0,3,0,2050,3]

theorem envBound36412 : H12AffineFastState.Bounded env36412 := by
  intro p hp
  have h : env36412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36411_36412 : H12AffineEnvironment.transform 2 0 env36411 = env36412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36411 == env36412) = true)

theorem identity36412 : scanCanonicalize (H12AffineFastState.compose env36412 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound36412 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36413 : List Nat := [2,1,0,3,1,1,0,3,3,3,1,1,2,0,3,1,3,2,3,2,1,0,2,2,2,1,3,3,0,1,2,0,3,0,3,3]

theorem envBound36413 : H12AffineFastState.Bounded env36413 := by
  intro p hp
  have h : env36413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36412_36413 : H12AffineEnvironment.transform 10 1 env36412 = env36413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env36412 == env36413) = true)

theorem identity36413 : scanCanonicalize (H12AffineFastState.compose env36413 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36413 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36414 : List Nat := [1,1,0,0,1,1,0,0,0,0,1,1,1,0,0,1,0,1,0,1,1,0,1,1,1,1,0,0,0,1,1,0,0,0,0,0]

theorem envBound36414 : H12AffineFastState.Bounded env36414 := by
  intro p hp
  have h : env36414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36413_36414 : H12AffineEnvironment.transform 0 1 env36413 = env36414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36413 == env36414) = true)

def env36415 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21777,98644,8193,64,409957,16401,17665,431376,20565,62588,256,21792,46092,96010]

theorem envBound36415 : H12AffineFastState.Bounded env36415 := by
  intro p hp
  have h : env36415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36389_36415 : H12AffineEnvironment.transform 6 9 env36389 = env36415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36389 == env36415) = true)

def env36416 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398437,5393,4097,431376,1365,41340,256,32,46092,74250]

theorem envBound36416 : H12AffineFastState.Bounded env36416 := by
  intro p hp
  have h : env36416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36415_36416 : H12AffineEnvironment.transform 13 5376 env36415 = env36416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36415 == env36416) = true)

theorem identity36416 : scanCanonicalize (H12AffineFastState.compose env36416 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36416 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36417 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,4160,32,17,98644,8193,64,146508,5393,4097,179513,1365,41340,256,32,46092,74250]

theorem envBound36417 : H12AffineFastState.Bounded env36417 := by
  intro p hp
  have h : env36417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36416_36417 : H12AffineEnvironment.transform 17 10281 env36416 = env36417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36416 == env36417) = true)

def env36418 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98644,8193,64,398436,5392,4096,431376,1364,41341,256,33,46092,74251]

theorem envBound36418 : H12AffineFastState.Bounded env36418 := by
  intro p hp
  have h : env36418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36415_36418 : H12AffineEnvironment.transform 13 5377 env36415 = env36418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36415 == env36418) = true)

theorem identity36418 : scanCanonicalize (H12AffineFastState.compose env36418 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36418 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36419 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398436,5392,4096,431376,1364,41341,256,33,46092,513]

theorem envBound36419 : H12AffineFastState.Bounded env36419 := by
  intro p hp
  have h : env36419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36418_36419 : H12AffineEnvironment.transform 15 8202 env36418 = env36419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36418 == env36419) = true)

theorem identity36419 : scanCanonicalize (H12AffineFastState.compose env36419 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36419 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env36420 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398436,5392,4096,406605,1364,32,256,33,5457,513]

theorem envBound36420 : H12AffineFastState.Bounded env36420 := by
  intro p hp
  have h : env36420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36419_36420 : H12AffineEnvironment.transform 14 8541 env36419 = env36420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36419 == env36420) = true)

theorem identity36420 : scanCanonicalize (H12AffineFastState.compose env36420 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36421 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,33,16,3,8193,16,398388,5392,4096,406557,1284,32,256,33,5377,513]

theorem envBound36421 : H12AffineFastState.Bounded env36421 := by
  intro p hp
  have h : env36421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36420_36421 : H12AffineEnvironment.transform 5 16 env36420 = env36421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36420 == env36421) = true)

theorem identity36421 : scanCanonicalize (H12AffineFastState.compose env36421 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138292) := by decide +kernel

theorem selectedBound36421 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36422 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,138292,1024,8460,4113,33,16,3,8193,16,2048,5392,4096,10281,1284,32,256,33,5377,513]

theorem envBound36422 : H12AffineFastState.Bounded env36422 := by
  intro p hp
  have h : env36422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36421_36422 : H12AffineEnvironment.transform 17 138292 env36421 = env36422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138292 env36421 == env36422) = true)

theorem identity36422 : scanCanonicalize (H12AffineFastState.compose env36422 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound36422 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env36423 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,13341,10281,1024,8460,4113,33,16,3,8193,16,2048,5392,4096,10281,1284,32,256,33,5377,513]

theorem envBound36423 : H12AffineFastState.Bounded env36423 := by
  intro p hp
  have h : env36423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36422_36423 : H12AffineEnvironment.transform 16 13341 env36422 = env36423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env36422 == env36423) = true)

theorem identity36423 : scanCanonicalize (H12AffineFastState.compose env36423 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36423 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36424 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5392,2340,1024,1,4113,33,16,3,268,16,2048,5392,4096,2340,1284,32,256,33,5377,513]

theorem envBound36424 : H12AffineFastState.Bounded env36424 := by
  intro p hp
  have h : env36424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36423_36424 : H12AffineEnvironment.transform 12 269 env36423 = env36424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36423 == env36424) = true)

theorem identity36424 : scanCanonicalize (H12AffineFastState.compose env36424 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36425 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5173,2049,1024,1,4113,33,16,3,41,16,2048,5173,4096,2049,1057,32,37,33,5156,513]

theorem envBound36425 : H12AffineFastState.Bounded env36425 := by
  intro p hp
  have h : env36425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36424_36425 : H12AffineEnvironment.transform 7 37 env36424 = env36425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36424 == env36425) = true)

def env36426 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,0,34,1029,2049,1024,1,33,33,16,3,41,16,2048,1029,48,2049,1057,32,37,33,1044,513]

theorem envBound36426 : H12AffineFastState.Bounded env36426 := by
  intro p hp
  have h : env36426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36425_36426 : H12AffineEnvironment.transform 11 48 env36425 = env36426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36425 == env36426) = true)

def env36427 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,0,34,1028,2049,1024,1,32,33,16,3,41,16,2048,1028,49,2049,1057,32,37,33,1045,513]

theorem envBound36427 : H12AffineFastState.Bounded env36427 := by
  intro p hp
  have h : env36427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36425_36427 : H12AffineEnvironment.transform 11 49 env36425 = env36427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36425 == env36427) = true)

theorem identity36427 : scanCanonicalize (H12AffineFastState.compose env36427 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36428 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,40,32,0,34,49,2049,53,1,32,33,16,3,41,16,2048,49,49,2049,20,32,37,33,32,513]

theorem envBound36428 : H12AffineFastState.Bounded env36428 := by
  intro p hp
  have h : env36428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36427_36428 : H12AffineEnvironment.transform 9 53 env36427 = env36428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36427 == env36428) = true)

theorem identity36428 : scanCanonicalize (H12AffineFastState.compose env36428 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36429 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,1,0,3,16,2049,20,1,1,0,16,3,8,16,2048,16,16,2049,20,1,4,0,1,513]

theorem envBound36429 : H12AffineFastState.Bounded env36429 := by
  intro p hp
  have h : env36429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36428_36429 : H12AffineEnvironment.transform 4 1 env36428 = env36429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36428 == env36429) = true)

def leafEnv36429 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,9,1,0,3,16,2049,20,1,1,0,16,3,20,8,1,16,2048,16,16,2049,20,1,4,0,4,2,1,513,1,1,0]

def active36429 : List Nat := [0,1,2,3,8,10]

def tree36429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36429 : H12WitnessSearch.Good tree36429 := H12GlobalWitnessIndex.good

theorem leafIdentity36429 : H12AffineFastState.composeSystem env36429 rootObs = leafEnv36429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36429 rootObs == leafEnv36429) = true)

theorem terminalChecked36429 : H12PackedTerminal.terminalCheckFast leafEnv36429 active36429 tree36429 = true := by decide +kernel

def env36430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21912,98644,8328,64,410093,16536,17800,431513,20700,62708,256,21792,46213,96010]

theorem envBound36430 : H12AffineFastState.Bounded env36430 := by
  intro p hp
  have h : env36430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36388_36430 : H12AffineEnvironment.transform 21 21793 env36388 = env36430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env36388 == env36430) = true)

theorem identity36430 : scanCanonicalize (H12AffineFastState.compose env36430 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound36430 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,169,16,98644,8328,64,398437,5392,4096,431513,1364,41340,256,168,46213,74370]

theorem envBound36431 : H12AffineFastState.Bounded env36431 := by
  intro p hp
  have h : env36431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36430_36431 : H12AffineEnvironment.transform 13 5512 env36430 = env36431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env36430 == env36431) = true)

def env36432 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398437,5392,4096,431377,1364,41340,256,32,46093,74250]

theorem envBound36432 : H12AffineFastState.Bounded env36432 := by
  intro p hp
  have h : env36432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36431_36432 : H12AffineEnvironment.transform 6 8 env36431 = env36432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36431 == env36432) = true)

theorem identity36432 : scanCanonicalize (H12AffineFastState.compose env36432 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36432 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36433 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,33,16,73737,8192,64,398437,5392,4096,406604,1364,33,256,32,5456,74250]

theorem envBound36433 : H12AffineFastState.Bounded env36433 := by
  intro p hp
  have h : env36433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36432_36433 : H12AffineEnvironment.transform 14 8541 env36432 = env36433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36432 == env36433) = true)

theorem identity36433 : scanCanonicalize (H12AffineFastState.compose env36433 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212030) := by decide +kernel

theorem selectedBound36433 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36434 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,212030,1024,8540,4160,33,16,73737,8192,64,75867,5392,4096,67698,1364,33,256,32,5456,74250]

theorem envBound36434 : H12AffineFastState.Bounded env36434 := by
  intro p hp
  have h : env36434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36433_36434 : H12AffineEnvironment.transform 17 212030 env36433 = env36434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212030 env36433 == env36434) = true)

theorem identity36434 : scanCanonicalize (H12AffineFastState.compose env36434 (packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound36434 : packedSelected [0,4,5,12,14,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env36435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,373,65536,131072,203798,1024,372,4160,33,16,65569,40,64,67699,5392,4096,67698,1364,33,256,32,5456,66082]

theorem envBound36435 : H12AffineFastState.Bounded env36435 := by
  intro p hp
  have h : env36435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36434_36435 : H12AffineEnvironment.transform 12 40 env36434 = env36435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env36434 == env36435) = true)

theorem identity36435 : scanCanonicalize (H12AffineFastState.compose env36435 (packedSelected [9,11,14,15,22] rootPS)) = affineNative (2^(16+1) ^^^ 69975) := by decide +kernel

theorem selectedBound36435 : packedSelected [9,11,14,15,22] rootPS < 2^1333 := by decide +kernel

def env36436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5376,373,65536,69975,3393,1024,372,4160,33,16,65569,40,64,67699,5392,4096,67698,1364,33,256,32,5456,66082]

theorem envBound36436 : H12AffineFastState.Bounded env36436 := by
  intro p hp
  have h : env36436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36435_36436 : H12AffineEnvironment.transform 16 69975 env36435 = env36436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69975 env36435 == env36436) = true)

theorem identity36436 : scanCanonicalize (H12AffineFastState.compose env36436 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36436 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env36437 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,373,65536,69975,2129,272,372,4160,33,16,65569,40,64,67699,4096,4096,67698,68,33,256,32,4160,66082]

theorem envBound36437 : H12AffineFastState.Bounded env36437 := by
  intro p hp
  have h : env36437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36436_36437 : H12AffineEnvironment.transform 9 272 env36436 = env36437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36436 == env36437) = true)

theorem identity36437 : scanCanonicalize (H12AffineFastState.compose env36437 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound36437 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36438 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,373,114,4389,2129,272,372,4160,33,16,83,40,64,2049,4096,4096,2048,68,33,256,32,4160,592]

theorem envBound36438 : H12AffineFastState.Bounded env36438 := by
  intro p hp
  have h : env36438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36437_36438 : H12AffineEnvironment.transform 15 114 env36437 = env36438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env36437 == env36438) = true)

theorem identity36438 : scanCanonicalize (H12AffineFastState.compose env36438 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36438 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env36439 : List Nat := [2,4,8,16,32,48,8,256,512,272,2048,4096,40,4112,261,2,4389,2081,272,260,4144,33,16,35,40,48,2049,4096,4096,2048,52,33,256,32,4144,544]

theorem envBound36439 : H12AffineFastState.Bounded env36439 := by
  intro p hp
  have h : env36439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36438_36439 : H12AffineEnvironment.transform 5 48 env36438 = env36439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36438 == env36439) = true)

theorem identity36439 : scanCanonicalize (H12AffineFastState.compose env36439 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36439 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36440 : List Nat := [2,4,8,16,0,16,8,256,512,272,2048,4096,8,4112,261,2,4357,2049,272,260,4112,1,16,3,8,16,2049,4096,4096,2048,20,1,256,0,4112,512]

theorem envBound36440 : H12AffineFastState.Bounded env36440 := by
  intro p hp
  have h : env36440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36439_36440 : H12AffineEnvironment.transform 4 0 env36439 = env36440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36439 == env36440) = true)

theorem identity36440 : scanCanonicalize (H12AffineFastState.compose env36440 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36440 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36441 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,4096,8,4112,0,2,4096,2049,21,1,4112,1,16,3,8,16,2049,4096,4096,2048,20,1,5,0,4112,512]

theorem envBound36441 : H12AffineFastState.Bounded env36441 := by
  intro p hp
  have h : env36441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36440_36441 : H12AffineEnvironment.transform 7 5 env36440 = env36441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36440 == env36441) = true)

theorem identity36441 : scanCanonicalize (H12AffineFastState.compose env36441 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound36441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36442 : List Nat := [2,4,8,16,0,16,8,5,512,21,2048,2065,8,2049,0,2,2065,2049,21,1,2049,1,16,3,8,16,2049,2065,2065,2048,20,1,5,0,2049,512]

theorem envBound36442 : H12AffineFastState.Bounded env36442 := by
  intro p hp
  have h : env36442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36441_36442 : H12AffineEnvironment.transform 11 2065 env36441 = env36442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env36441 == env36442) = true)

theorem identity36442 : scanCanonicalize (H12AffineFastState.compose env36442 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound36442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36443 : List Nat := [2,4,8,5,0,5,8,5,512,0,2048,2052,8,2049,0,2,2052,2049,0,1,2049,1,5,3,8,5,2049,2052,2052,2048,1,1,5,0,2049,512]

theorem envBound36443 : H12AffineFastState.Bounded env36443 := by
  intro p hp
  have h : env36443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36442_36443 : H12AffineEnvironment.transform 3 5 env36442 = env36443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env36442 == env36443) = true)

def env36444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98644,8193,64,398437,5392,4096,431376,1364,41340,256,33,46092,74251]

theorem envBound36444 : H12AffineFastState.Bounded env36444 := by
  intro p hp
  have h : env36444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36431_36444 : H12AffineEnvironment.transform 6 9 env36431 = env36444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36431 == env36444) = true)

theorem identity36444 : scanCanonicalize (H12AffineFastState.compose env36444 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36444 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398437,5392,4096,431376,1364,41340,256,33,46092,513]

theorem envBound36445 : H12AffineFastState.Bounded env36445 := by
  intro p hp
  have h : env36445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36444_36445 : H12AffineEnvironment.transform 15 8202 env36444 = env36445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36444 == env36445) = true)

theorem identity36445 : scanCanonicalize (H12AffineFastState.compose env36445 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36445 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env36446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398437,5392,4096,406605,1364,33,256,33,5457,513]

theorem envBound36446 : H12AffineFastState.Bounded env36446 := by
  intro p hp
  have h : env36446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36445_36446 : H12AffineEnvironment.transform 14 8541 env36445 = env36446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36445 == env36446) = true)

theorem identity36446 : scanCanonicalize (H12AffineFastState.compose env36446 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36446 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36447 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,32,16,3,8193,16,398389,5392,4096,406557,1284,33,256,33,5377,513]

theorem envBound36447 : H12AffineFastState.Bounded env36447 := by
  intro p hp
  have h : env36447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36446_36447 : H12AffineEnvironment.transform 5 16 env36446 = env36447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36446 == env36447) = true)

theorem identity36447 : scanCanonicalize (H12AffineFastState.compose env36447 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound36447 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36448 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10280,1024,8460,4113,32,16,3,8193,16,146461,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound36448 : H12AffineFastState.Bounded env36448 := by
  intro p hp
  have h : env36448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36447_36448 : H12AffineEnvironment.transform 17 10280 env36447 = env36448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36447 == env36448) = true)

theorem identity36448 : scanCanonicalize (H12AffineFastState.compose env36448 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36448 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36449 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,131072,2341,1024,1,4113,32,16,3,268,16,138512,5392,4096,138293,1284,33,256,33,5377,513]

theorem envBound36449 : H12AffineFastState.Bounded env36449 := by
  intro p hp
  have h : env36449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36448_36449 : H12AffineEnvironment.transform 12 269 env36448 = env36449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36448 == env36449) = true)

theorem identity36449 : scanCanonicalize (H12AffineFastState.compose env36449 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36449 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36450 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,0,263,131072,2341,272,1,4113,32,16,3,268,16,137216,4096,4096,137509,20,33,256,33,4113,513]

theorem envBound36450 : H12AffineFastState.Bounded env36450 := by
  intro p hp
  have h : env36450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36449_36450 : H12AffineEnvironment.transform 9 272 env36449 = env36450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36449 == env36450) = true)

theorem identity36450 : scanCanonicalize (H12AffineFastState.compose env36450 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound36450 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env36451 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,4113,0,263,4096,2341,272,1,4113,32,16,3,268,16,2048,4096,4096,2341,20,33,256,33,4113,513]

theorem envBound36451 : H12AffineFastState.Bounded env36451 := by
  intro p hp
  have h : env36451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36450_36451 : H12AffineEnvironment.transform 16 4096 env36450 = env36451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env36450 == env36451) = true)

theorem identity36451 : scanCanonicalize (H12AffineFastState.compose env36451 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36451 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36452 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,0,34,4096,2048,53,1,4113,32,16,3,41,16,2048,4096,4096,2048,20,33,37,33,4113,513]

theorem envBound36452 : H12AffineFastState.Bounded env36452 := by
  intro p hp
  have h : env36452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36451_36452 : H12AffineEnvironment.transform 7 37 env36451 = env36452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36451 == env36452) = true)

theorem identity36452 : scanCanonicalize (H12AffineFastState.compose env36452 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound36452 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36453 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2609,40,2592,0,34,2609,2048,53,1,2592,32,16,3,41,16,2048,2609,2609,2048,20,33,37,33,2592,513]

theorem envBound36453 : H12AffineFastState.Bounded env36453 := by
  intro p hp
  have h : env36453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36452_36453 : H12AffineEnvironment.transform 11 2609 env36452 = env36453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env36452 == env36453) = true)

theorem identity36453 : scanCanonicalize (H12AffineFastState.compose env36453 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound36453 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36454 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,1,40,16,0,34,1,560,53,1,16,32,16,3,41,16,560,1,1,560,20,33,37,33,16,513]

theorem envBound36454 : H12AffineFastState.Bounded env36454 := by
  intro p hp
  have h : env36454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36453_36454 : H12AffineEnvironment.transform 10 560 env36453 = env36454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env36453 == env36454) = true)

theorem identity36454 : scanCanonicalize (H12AffineFastState.compose env36454 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound36454 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env36455 : List Nat := [2,4,8,16,32,16,9,37,49,53,1,1,40,16,0,34,1,1,53,1,16,32,16,3,41,16,1,1,1,1,20,33,37,33,16,48]

theorem envBound36455 : H12AffineFastState.Bounded env36455 := by
  intro p hp
  have h : env36455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36454_36455 : H12AffineEnvironment.transform 8 49 env36454 = env36455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env36454 == env36455) = true)

theorem identity36455 : scanCanonicalize (H12AffineFastState.compose env36455 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36455 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env36456 : List Nat := [2,4,8,0,32,0,9,37,33,37,1,1,40,0,0,34,1,1,37,1,0,32,0,3,41,0,1,1,1,1,4,33,37,33,0,32]

theorem envBound36456 : H12AffineFastState.Bounded env36456 := by
  intro p hp
  have h : env36456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36455_36456 : H12AffineEnvironment.transform 3 0 env36455 = env36456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36455 == env36456) = true)

def env36457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21912,98645,8328,64,4592845,16536,17801,431513,20701,4235733,256,21792,46213,96011]

theorem envBound36457 : H12AffineFastState.Bounded env36457 := by
  intro p hp
  have h : env36457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36387_36457 : H12AffineEnvironment.transform 20 17729 env36387 = env36457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env36387 == env36457) = true)

def env36458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21912,98645,8328,64,410093,16536,17801,431513,20701,62709,256,21792,46213,96011]

theorem envBound36458 : H12AffineFastState.Bounded env36458 := by
  intro p hp
  have h : env36458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36457_36458 : H12AffineEnvironment.transform 21 21792 env36457 = env36458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env36457 == env36458) = true)

theorem identity36458 : scanCanonicalize (H12AffineFastState.compose env36458 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound36458 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,17729,21792,21912,95616,8328,64,410093,16536,17801,418124,20701,32,256,21792,16464,96011]

theorem envBound36459 : H12AffineFastState.Bounded env36459 := by
  intro p hp
  have h : env36459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36458_36459 : H12AffineEnvironment.transform 14 29909 env36458 = env36459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env36458 == env36459) = true)

def env36460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32160,1024,29908,17729,21792,21912,95616,8328,64,146509,16536,17801,138476,20701,32,256,21792,16464,96011]

theorem envBound36460 : H12AffineFastState.Bounded env36460 := by
  intro p hp
  have h : env36460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36459_36460 : H12AffineEnvironment.transform 17 32160 env36459 = env36460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env36459 == env36460) = true)

theorem identity36460 : scanCanonicalize (H12AffineFastState.compose env36460 (packedSelected [4,5,7,8,9,11,14,16,18,20,23,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound36460 : packedSelected [4,5,7,8,9,11,14,16,18,20,23,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env36461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,5528,32160,1024,29908,17729,21792,21912,95616,8328,64,10709,16536,17801,2420,20701,32,256,21792,16464,96011]

theorem envBound36461 : H12AffineFastState.Bounded env36461 := by
  intro p hp
  have h : env36461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36460_36461 : H12AffineEnvironment.transform 16 5528 env36460 = env36461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env36460 == env36461) = true)

theorem identity36461 : scanCanonicalize (H12AffineFastState.compose env36461 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36461 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env36462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5528,10400,1024,8660,4161,32,152,73856,8328,64,10709,5528,4233,2420,1501,32,256,32,5456,74251]

theorem envBound36462 : H12AffineFastState.Bounded env36462 := by
  intro p hp
  have h : env36462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36461_36462 : H12AffineEnvironment.transform 13 5376 env36461 = env36462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36461 == env36462) = true)

def env36463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32161,1024,29908,17729,21792,21912,95616,8328,64,146508,16536,17801,138477,20701,32,256,21792,16464,96011]

theorem envBound36463 : H12AffineFastState.Bounded env36463 := by
  intro p hp
  have h : env36463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36459_36463 : H12AffineEnvironment.transform 17 32161 env36459 = env36463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env36459 == env36463) = true)

theorem identity36463 : scanCanonicalize (H12AffineFastState.compose env36463 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound36463 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10281,1024,8540,4297,168,16,73736,8328,64,146508,5392,4097,138477,1365,32,256,168,5592,74371]

theorem envBound36464 : H12AffineFastState.Bounded env36464 := by
  intro p hp
  have h : env36464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36463_36464 : H12AffineEnvironment.transform 13 5512 env36463 = env36464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env36463 == env36464) = true)

theorem identity36464 : scanCanonicalize (H12AffineFastState.compose env36464 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound36464 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env36465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,79131,10281,1024,8540,4297,168,16,73736,8328,64,67927,5392,4097,76278,1365,32,256,168,5592,74371]

theorem envBound36465 : H12AffineFastState.Bounded env36465 := by
  intro p hp
  have h : env36465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36464_36465 : H12AffineEnvironment.transform 16 79131 env36464 = env36465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env36464 == env36465) = true)

theorem identity36465 : scanCanonicalize (H12AffineFastState.compose env36465 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound36465 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env36466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,5529,10281,1024,8540,4297,168,16,138,8328,64,10709,5392,4097,2420,1365,32,256,168,5592,513]

theorem envBound36466 : H12AffineFastState.Bounded env36466 := by
  intro p hp
  have h : env36466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36465_36466 : H12AffineEnvironment.transform 15 8322 env36465 = env36466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env36465 == env36466) = true)

theorem identity36466 : scanCanonicalize (H12AffineFastState.compose env36466 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound36466 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env36467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,136,343,5529,2556,1024,137,4297,168,16,138,349,64,2048,5392,4097,2420,1365,32,256,168,5592,513]

theorem envBound36467 : H12AffineFastState.Bounded env36467 := by
  intro p hp
  have h : env36467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36466_36467 : H12AffineEnvironment.transform 12 469 env36466 = env36467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env36466 == env36467) = true)

theorem identity36467 : scanCanonicalize (H12AffineFastState.compose env36467 (packedSelected [0,1,3,5,7,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound36467 : packedSelected [0,1,3,5,7,8,15] rootPS < 2^1333 := by decide +kernel

def env36468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,429,4096,469,5512,136,343,5529,81,1024,137,4297,168,16,138,349,64,429,5392,4097,217,1365,32,256,168,5592,513]

theorem envBound36468 : H12AffineFastState.Bounded env36468 := by
  intro p hp
  have h : env36468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36467_36468 : H12AffineEnvironment.transform 10 429 env36467 = env36468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env36467 == env36468) = true)

theorem identity36468 : scanCanonicalize (H12AffineFastState.compose env36468 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36468 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,4096,349,5376,0,343,5393,81,1024,1,4161,32,16,2,349,64,293,5392,4097,81,1365,32,256,32,5456,513]

theorem envBound36469 : H12AffineFastState.Bounded env36469 := by
  intro p hp
  have h : env36469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36468_36469 : H12AffineEnvironment.transform 6 8 env36468 = env36469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36468 == env36469) = true)

theorem identity36469 : scanCanonicalize (H12AffineFastState.compose env36469 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36469 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36470 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,4096,349,4452,0,343,4469,81,100,1,4161,32,16,2,349,64,293,4468,4097,81,305,32,256,32,4404,513]

theorem envBound36470 : H12AffineFastState.Bounded env36470 := by
  intro p hp
  have h : env36470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36469_36470 : H12AffineEnvironment.transform 9 100 env36469 = env36470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36469 == env36470) = true)

theorem identity36470 : scanCanonicalize (H12AffineFastState.compose env36470 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36470 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36471 : List Nat := [2,4,8,16,32,64,8,37,512,100,0,4096,120,4161,0,114,4176,81,100,1,4161,32,16,2,120,64,0,4177,4097,81,20,32,37,32,4113,513]

theorem envBound36471 : H12AffineFastState.Bounded env36471 := by
  intro p hp
  have h : env36471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36470_36471 : H12AffineEnvironment.transform 7 37 env36470 = env36471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36470 == env36471) = true)

def env36472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21912,98645,8328,64,410092,16536,17801,431513,20701,62708,256,21792,46213,96011]

theorem envBound36472 : H12AffineFastState.Bounded env36472 := by
  intro p hp
  have h : env36472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36457_36472 : H12AffineEnvironment.transform 21 21793 env36457 = env36472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env36457 == env36472) = true)

theorem identity36472 : scanCanonicalize (H12AffineFastState.compose env36472 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36472 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,17729,21793,21912,73736,8328,64,410092,16536,17801,406724,20701,21929,256,21792,5592,96011]

theorem envBound36473 : H12AffineFastState.Bounded env36473 := by
  intro p hp
  have h : env36473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36472_36473 : H12AffineEnvironment.transform 14 8541 env36472 = env36473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36472 == env36473) = true)

def env36474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,17729,21793,21912,73736,8328,64,158028,16536,17801,138340,20701,21929,256,21792,5592,96011]

theorem envBound36474 : H12AffineFastState.Bounded env36474 := by
  intro p hp
  have h : env36474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36473_36474 : H12AffineEnvironment.transform 17 10400 env36473 = env36474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36473 == env36474) = true)

theorem identity36474 : scanCanonicalize (H12AffineFastState.compose env36474 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound36474 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env36475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10400,1024,8540,17729,21793,21912,21762,8328,64,158028,16536,17801,138340,20701,21929,256,21792,5592,513]

theorem envBound36475 : H12AffineFastState.Bounded env36475 := by
  intro p hp
  have h : env36475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36474_36475 : H12AffineEnvironment.transform 15 29962 env36474 = env36475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env36474 == env36475) = true)

theorem identity36475 : scanCanonicalize (H12AffineFastState.compose env36475 (packedSelected [2,3,5,11,15,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound36475 : packedSelected [2,3,5,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env36476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,13673,10400,1024,8540,17729,21793,21912,21762,8328,64,23589,16536,17801,10509,20701,21929,256,21792,5592,513]

theorem envBound36476 : H12AffineFastState.Bounded env36476 := by
  intro p hp
  have h : env36476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36475_36476 : H12AffineEnvironment.transform 16 13673 env36475 = env36476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env36475 == env36476) = true)

theorem identity36476 : scanCanonicalize (H12AffineFastState.compose env36476 (packedSelected [0,1,2,4,6,7,8,9,10,12,16,23] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound36476 : packedSelected [0,1,2,4,6,7,8,9,10,12,16,23] rootPS < 2^1333 := by decide +kernel

def env36477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,216,21647,5356,2341,1024,217,17729,21793,21912,21762,269,64,23589,16536,17801,2184,20701,21929,256,21792,5592,513]

theorem envBound36477 : H12AffineFastState.Bounded env36477 := by
  intro p hp
  have h : env36477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36476_36477 : H12AffineEnvironment.transform 12 389 env36476 = env36477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env36476 == env36477) = true)

theorem identity36477 : scanCanonicalize (H12AffineFastState.compose env36477 (packedSelected [0,2,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound36477 : packedSelected [0,2,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env36478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,216,263,5356,2341,1024,217,4297,169,16,138,269,64,2477,5392,4097,2184,1365,33,256,168,5592,513]

theorem envBound36478 : H12AffineFastState.Bounded env36478 := by
  intro p hp
  have h : env36478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36477_36478 : H12AffineEnvironment.transform 13 5512 env36477 = env36478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env36477 == env36478) = true)

theorem identity36478 : scanCanonicalize (H12AffineFastState.compose env36478 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36478 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36479 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5457,1,263,5173,2341,1024,0,4112,112,16,83,269,64,2420,5392,4097,2129,1365,33,256,113,5377,513]

theorem envBound36479 : H12AffineFastState.Bounded env36479 := by
  intro p hp
  have h : env36479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36478_36479 : H12AffineEnvironment.transform 6 89 env36478 = env36479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36478 == env36479) = true)

theorem identity36479 : scanCanonicalize (H12AffineFastState.compose env36479 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36479 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36480 : List Nat := [2,4,8,16,32,64,89,117,512,1024,2048,4096,41,5156,1,114,5173,2128,1024,0,4112,112,16,83,120,64,2049,5221,4097,2129,1056,33,117,113,5236,513]

theorem envBound36480 : H12AffineFastState.Bounded env36480 := by
  intro p hp
  have h : env36480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36479_36480 : H12AffineEnvironment.transform 7 117 env36479 = env36480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36479 == env36480) = true)

theorem identity36480 : scanCanonicalize (H12AffineFastState.compose env36480 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36480 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36481 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1024,0,4112,33,16,2,41,17,2049,5172,4097,2048,1056,33,36,32,5157,513]

theorem envBound36481 : H12AffineFastState.Bounded env36481 := by
  intro p hp
  have h : env36481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36480_36481 : H12AffineEnvironment.transform 5 17 env36480 = env36481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36480 == env36481) = true)

theorem identity36481 : scanCanonicalize (H12AffineFastState.compose env36481 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36482 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4113,1,35,4096,2049,53,0,4112,33,16,2,41,17,2049,4097,4097,2048,21,33,36,32,4112,513]

theorem envBound36482 : H12AffineFastState.Bounded env36482 := by
  intro p hp
  have h : env36482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36481_36482 : H12AffineEnvironment.transform 9 53 env36481 = env36482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36481 == env36482) = true)

theorem identity36482 : scanCanonicalize (H12AffineFastState.compose env36482 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound36482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36483 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,4096,41,4113,1,35,4096,48,53,0,4112,33,16,2,41,17,48,4097,4097,49,21,33,36,32,4112,513]

theorem envBound36483 : H12AffineFastState.Bounded env36483 := by
  intro p hp
  have h : env36483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36482_36483 : H12AffineEnvironment.transform 10 49 env36482 = env36483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env36482 == env36483) = true)

theorem identity36483 : scanCanonicalize (H12AffineFastState.compose env36483 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36484 : List Nat := [2,4,8,16,1,17,8,5,512,20,16,4096,8,4113,1,2,4096,17,20,0,4112,0,16,2,8,17,17,4097,4097,16,21,0,5,1,4112,513]

theorem envBound36484 : H12AffineFastState.Bounded env36484 := by
  intro p hp
  have h : env36484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36483_36484 : H12AffineEnvironment.transform 4 1 env36483 = env36484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36483 == env36484) = true)

def env36485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,17729,21793,21912,73736,8328,64,158029,16536,17801,138341,20701,21929,256,21792,5592,96011]

theorem envBound36485 : H12AffineFastState.Bounded env36485 := by
  intro p hp
  have h : env36485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36473_36485 : H12AffineEnvironment.transform 17 10401 env36473 = env36485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36473 == env36485) = true)

theorem identity36485 : scanCanonicalize (H12AffineFastState.compose env36485 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound36485 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,4297,169,16,73736,8328,64,146629,5392,4097,138341,1365,33,256,168,5592,74371]

theorem envBound36486 : H12AffineFastState.Bounded env36486 := by
  intro p hp
  have h : env36486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36485_36486 : H12AffineEnvironment.transform 13 5512 env36485 = env36486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env36485 == env36486) = true)

theorem identity36486 : scanCanonicalize (H12AffineFastState.compose env36486 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound36486 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env36487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,5393,10401,1024,8540,4297,169,16,73736,8328,64,10708,5392,4097,2420,1365,33,256,168,5592,74371]

theorem envBound36487 : H12AffineFastState.Bounded env36487 := by
  intro p hp
  have h : env36487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36486_36487 : H12AffineEnvironment.transform 16 5393 env36486 = env36487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env36486 == env36487) = true)

theorem identity36487 : scanCanonicalize (H12AffineFastState.compose env36487 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound36487 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,5393,10401,1024,8540,4297,169,16,138,8328,64,10708,5392,4097,2420,1365,33,256,168,5592,513]

theorem envBound36488 : H12AffineFastState.Bounded env36488 := by
  intro p hp
  have h : env36488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36487_36488 : H12AffineEnvironment.transform 15 8322 env36487 = env36488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env36487 == env36488) = true)

theorem identity36488 : scanCanonicalize (H12AffineFastState.compose env36488 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound36488 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5512,33,510,5393,2525,1024,32,4297,169,16,138,500,64,2216,5392,4097,2420,1365,33,256,168,5592,513]

theorem envBound36489 : H12AffineFastState.Bounded env36489 := by
  intro p hp
  have h : env36489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36488_36489 : H12AffineEnvironment.transform 12 380 env36488 = env36489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env36488 == env36489) = true)

theorem identity36489 : scanCanonicalize (H12AffineFastState.compose env36489 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound36489 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env36490 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,380,4249,33,510,4096,2525,273,32,4297,169,16,138,500,64,2216,4097,4097,2420,68,33,256,168,4297,513]

theorem envBound36490 : H12AffineFastState.Bounded env36490 := by
  intro p hp
  have h : env36490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36489_36490 : H12AffineEnvironment.transform 9 273 env36489 = env36490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env36489 == env36490) = true)

theorem identity36490 : scanCanonicalize (H12AffineFastState.compose env36490 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound36490 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env36491 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2144,380,2297,33,510,2144,2525,273,32,2217,169,16,138,500,64,2216,2145,2145,2420,68,33,256,168,2217,513]

theorem envBound36491 : H12AffineFastState.Bounded env36491 := by
  intro p hp
  have h : env36491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36490_36491 : H12AffineEnvironment.transform 11 2144 env36490 = env36491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env36490 == env36491) = true)

theorem identity36491 : scanCanonicalize (H12AffineFastState.compose env36491 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound36491 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env36492 : List Nat := [2,4,8,16,32,64,128,256,512,273,508,412,380,261,33,510,412,33,273,32,341,169,16,138,500,64,340,413,413,136,68,33,256,168,341,513]

theorem envBound36492 : H12AffineFastState.Bounded env36492 := by
  intro p hp
  have h : env36492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36491_36492 : H12AffineEnvironment.transform 10 508 env36491 = env36492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env36491 == env36492) = true)

theorem identity36492 : scanCanonicalize (H12AffineFastState.compose env36492 (packedSelected [0,2,4,6,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 248) := by decide +kernel

theorem selectedBound36492 : packedSelected [0,2,4,6,11,12] rootPS < 2^1333 := by decide +kernel

def env36493 : List Nat := [2,4,8,16,32,64,128,256,248,273,508,412,380,261,33,510,412,33,273,32,341,169,16,138,500,64,340,413,413,136,68,33,256,168,341,249]

theorem envBound36493 : H12AffineFastState.Bounded env36493 := by
  intro p hp
  have h : env36493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36492_36493 : H12AffineEnvironment.transform 8 248 env36492 = env36493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 248 env36492 == env36493) = true)

theorem identity36493 : scanCanonicalize (H12AffineFastState.compose env36493 (packedSelected [0,4,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36493 : packedSelected [0,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36494 : List Nat := [2,4,8,16,32,64,128,21,248,4,233,137,105,16,33,235,137,33,4,32,64,169,16,138,225,64,65,136,136,136,68,33,21,168,64,249]

theorem envBound36494 : H12AffineFastState.Bounded env36494 := by
  intro p hp
  have h : env36494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36493_36494 : H12AffineEnvironment.transform 7 21 env36493 = env36494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36493 == env36494) = true)

theorem identity36494 : scanCanonicalize (H12AffineFastState.compose env36494 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36494 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env36495 : List Nat := [2,4,8,16,0,64,128,21,216,4,201,137,73,16,1,203,137,1,4,0,64,137,16,138,193,64,65,136,136,136,68,1,21,136,64,217]

theorem envBound36495 : H12AffineFastState.Bounded env36495 := by
  intro p hp
  have h : env36495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36494_36495 : H12AffineEnvironment.transform 4 0 env36494 = env36495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36494 == env36495) = true)

theorem identity36495 : scanCanonicalize (H12AffineFastState.compose env36495 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound36495 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36496 : List Nat := [2,4,8,16,0,64,89,21,1,4,16,80,73,16,1,18,80,1,4,0,64,80,16,83,24,64,65,81,81,81,68,1,21,81,64,0]

theorem envBound36496 : H12AffineFastState.Bounded env36496 := by
  intro p hp
  have h : env36496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36495_36496 : H12AffineEnvironment.transform 6 89 env36495 = env36496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36495 == env36496) = true)

theorem identity36496 : scanCanonicalize (H12AffineFastState.compose env36496 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36497 : List Nat := [2,4,8,16,0,0,25,21,1,4,16,16,9,16,1,18,16,1,4,0,0,16,16,19,24,0,1,17,17,17,4,1,21,17,0,0]

theorem envBound36497 : H12AffineFastState.Bounded env36497 := by
  intro p hp
  have h : env36497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36496_36497 : H12AffineEnvironment.transform 5 0 env36496 = env36497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36496 == env36497) = true)

theorem identity36497 : scanCanonicalize (H12AffineFastState.compose env36497 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36498 : List Nat := [2,4,8,0,0,0,9,5,1,4,0,0,9,0,1,2,0,1,4,0,0,0,0,3,8,0,1,1,1,1,4,1,5,1,0,0]

theorem envBound36498 : H12AffineFastState.Bounded env36498 := by
  intro p hp
  have h : env36498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36497_36498 : H12AffineEnvironment.transform 3 0 env36497 = env36498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36497 == env36498) = true)

def env36499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21913,2212884,8328,64,6705549,16536,2097353,431512,2102685,4235733,256,21793,46212,2175563]

theorem envBound36499 : H12AffineFastState.Bounded env36499 := by
  intro p hp
  have h : env36499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36386_36499 : H12AffineEnvironment.transform 22 21913 env36386 = env36499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21913 env36386 == env36499) = true)

def env36500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,4194304,21913,98644,8328,64,4592845,16536,17801,431512,20701,4235733,256,21793,46212,96011]

theorem envBound36500 : H12AffineFastState.Bounded env36500 := by
  intro p hp
  have h : env36500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36499_36500 : H12AffineEnvironment.transform 20 17728 env36499 = env36500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env36499 == env36500) = true)

def env36501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21792,21913,98644,8328,64,410093,16536,17801,431512,20701,62709,256,21793,46212,96011]

theorem envBound36501 : H12AffineFastState.Bounded env36501 := by
  intro p hp
  have h : env36501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36500_36501 : H12AffineEnvironment.transform 21 21792 env36500 = env36501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env36500 == env36501) = true)

theorem identity36501 : scanCanonicalize (H12AffineFastState.compose env36501 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound36501 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,131072,262144,1024,32769,17728,21792,21913,41431,8328,64,410093,16536,17801,431512,20701,62709,256,21793,46212,22408]

theorem envBound36502 : H12AffineFastState.Bounded env36502 := by
  intro p hp
  have h : env36502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36501_36502 : H12AffineEnvironment.transform 15 8323 env36501 = env36502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env36501 == env36502) = true)

def env36503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,262144,1024,32769,17728,21792,21913,41431,8328,64,283821,16536,17801,295128,20701,62709,256,21793,46212,22408]

theorem envBound36503 : H12AffineFastState.Bounded env36503 := by
  intro p hp
  have h : env36503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36502_36503 : H12AffineEnvironment.transform 16 5440 env36502 = env36503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env36502 == env36503) = true)

theorem identity36503 : scanCanonicalize (H12AffineFastState.compose env36503 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound36503 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5440,35109,1024,32769,17728,21792,21913,41431,8328,64,56712,16536,17801,2557,20701,62709,256,21793,46212,22408]

theorem envBound36504 : H12AffineFastState.Bounded env36504 := by
  intro p hp
  have h : env36504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36503_36504 : H12AffineEnvironment.transform 17 35109 env36503 = env36504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env36503 == env36504) = true)

theorem identity36504 : scanCanonicalize (H12AffineFastState.compose env36504 (packedSelected [0,9,11,18,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound36504 : packedSelected [0,9,11,18,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env36505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8323,5440,10481,1024,8661,17728,21792,21913,3,8328,64,31836,16536,17801,2557,20701,21793,256,21793,5456,22408]

theorem envBound36505 : H12AffineFastState.Bounded env36505 := by
  intro p hp
  have h : env36505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36504_36505 : H12AffineEnvironment.transform 14 8660 env36504 = env36505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env36504 == env36505) = true)

theorem identity36505 : scanCanonicalize (H12AffineFastState.compose env36505 (packedSelected [1,3,5,8,10,19,21] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36505 : packedSelected [1,3,5,8,10,19,21] rootPS < 2^1333 := by decide +kernel

def env36506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8660,8323,5440,10481,1024,8661,4113,113,200,3,8328,64,10509,5577,4312,2557,1420,112,256,112,5456,729]

theorem envBound36506 : H12AffineFastState.Bounded env36506 := by
  intro p hp
  have h : env36506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36505_36506 : H12AffineEnvironment.transform 13 5457 env36505 = env36506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36505 == env36506) = true)

theorem identity36506 : scanCanonicalize (H12AffineFastState.compose env36506 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36506 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,8202,5440,10360,1024,8540,4113,113,65,3,8193,64,10509,5440,4177,2420,1285,112,256,112,5456,592]

theorem envBound36507 : H12AffineFastState.Bounded env36507 := by
  intro p hp
  have h : env36507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36506_36507 : H12AffineEnvironment.transform 6 9 env36506 = env36507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36506 == env36507) = true)

theorem identity36507 : scanCanonicalize (H12AffineFastState.compose env36507 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound36507 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36508 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1085,5457,1376,1079,5440,3141,1024,1377,4113,113,65,3,1084,64,3376,5440,4177,2420,1285,112,256,112,5456,592]

theorem envBound36508 : H12AffineFastState.Bounded env36508 := by
  intro p hp
  have h : env36508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36507_36508 : H12AffineEnvironment.transform 12 1085 env36507 = env36508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env36507 == env36508) = true)

def env36509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,262144,1024,32769,17728,21792,21913,41431,8328,64,283820,16536,17801,295129,20701,62709,256,21793,46212,22408]

theorem envBound36509 : H12AffineFastState.Bounded env36509 := by
  intro p hp
  have h : env36509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36502_36509 : H12AffineEnvironment.transform 16 5441 env36502 = env36509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env36502 == env36509) = true)

theorem identity36509 : scanCanonicalize (H12AffineFastState.compose env36509 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound36509 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,5441,35244,1024,32769,17728,21792,21913,41431,8328,64,56576,16536,17801,2421,20701,62709,256,21793,46212,22408]

theorem envBound36510 : H12AffineFastState.Bounded env36510 := by
  intro p hp
  have h : env36510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36509_36510 : H12AffineEnvironment.transform 17 35244 env36509 = env36510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env36509 == env36510) = true)

theorem identity36510 : scanCanonicalize (H12AffineFastState.compose env36510 (packedSelected [0,3,4,5,7,8,16,18,20,22,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound36510 : packedSelected [0,3,4,5,7,8,16,18,20,22,23,28] rootPS < 2^1333 := by decide +kernel

def env36511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8580,8323,5441,10280,1024,8581,17728,21792,21913,83,8328,64,31876,16536,17801,2421,20701,21873,256,21793,5376,22408]

theorem envBound36511 : H12AffineFastState.Bounded env36511 := by
  intro p hp
  have h : env36511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36510_36511 : H12AffineEnvironment.transform 14 8580 env36510 = env36511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env36510 == env36511) = true)

theorem identity36511 : scanCanonicalize (H12AffineFastState.compose env36511 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound36511 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env36512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,16384,136,399,5441,2340,1024,137,17728,21792,21913,83,388,64,23944,16536,17801,2421,20701,21873,256,21793,5376,22408]

theorem envBound36512 : H12AffineFastState.Bounded env36512 := by
  intro p hp
  have h : env36512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36511_36512 : H12AffineEnvironment.transform 12 268 env36511 = env36512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env36511 == env36512) = true)

theorem identity36512 : scanCanonicalize (H12AffineFastState.compose env36512 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound36512 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env36513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,4113,136,399,5441,2340,1024,137,5457,1329,1416,83,388,64,3481,4233,5528,2421,204,1376,256,1328,5376,1945]

theorem envBound36513 : H12AffineFastState.Bounded env36513 := by
  intro p hp
  have h : env36513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36512_36513 : H12AffineEnvironment.transform 13 4113 env36512 = env36513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env36512 == env36513) = true)

theorem identity36513 : scanCanonicalize (H12AffineFastState.compose env36513 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36513 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env36514 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,4113,136,399,5393,2340,1024,137,5377,1329,1416,3,388,16,3481,4233,5528,2341,156,1328,256,1328,5376,1945]

theorem envBound36514 : H12AffineFastState.Bounded env36514 := by
  intro p hp
  have h : env36514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36513_36514 : H12AffineEnvironment.transform 5 16 env36513 = env36514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36513 == env36514) = true)

theorem identity36514 : scanCanonicalize (H12AffineFastState.compose env36514 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1417) := by decide +kernel

theorem selectedBound36514 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env36515 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1417,268,1432,136,399,152,2340,1024,137,136,1329,1416,3,388,16,3481,1280,17,2341,156,1328,256,1328,137,1945]

theorem envBound36515 : H12AffineFastState.Bounded env36515 := by
  intro p hp
  have h : env36515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36514_36515 : H12AffineEnvironment.transform 11 1417 env36514 = env36515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1417 env36514 == env36515) = true)

theorem identity36515 : scanCanonicalize (H12AffineFastState.compose env36515 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound36515 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env36516 : List Nat := [2,4,8,16,32,16,128,256,512,1024,293,1417,268,1432,136,399,152,1,1024,137,136,1329,1416,3,388,16,1212,1280,17,0,156,1328,256,1328,137,1945]

theorem envBound36516 : H12AffineFastState.Bounded env36516 := by
  intro p hp
  have h : env36516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36515_36516 : H12AffineEnvironment.transform 10 293 env36515 = env36516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env36515 == env36516) = true)

theorem identity36516 : scanCanonicalize (H12AffineFastState.compose env36516 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36516 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env36517 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1197,40,1212,136,171,152,1,1024,137,136,1045,1196,3,160,16,1212,1060,17,0,156,1044,36,1044,137,1725]

theorem envBound36517 : H12AffineFastState.Bounded env36517 := by
  intro p hp
  have h : env36517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36516_36517 : H12AffineEnvironment.transform 7 36 env36516 = env36517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36516 == env36517) = true)

def env36518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17728,21793,21913,98644,8328,64,410092,16536,17801,431512,20701,62708,256,21793,46212,96011]

theorem envBound36518 : H12AffineFastState.Bounded env36518 := by
  intro p hp
  have h : env36518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36500_36518 : H12AffineEnvironment.transform 21 21793 env36500 = env36518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env36500 == env36518) = true)

theorem identity36518 : scanCanonicalize (H12AffineFastState.compose env36518 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound36518 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21913,62558,8328,64,410092,16536,17801,431512,20701,62708,256,21793,46212,513]

theorem envBound36519 : H12AffineFastState.Bounded env36519 := by
  intro p hp
  have h : env36519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36518_36519 : H12AffineEnvironment.transform 15 29962 env36518 = env36519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env36518 == env36519) = true)

theorem identity36519 : scanCanonicalize (H12AffineFastState.compose env36519 (packedSelected [12,15,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36519 : packedSelected [12,15,21,38,41] rootPS < 2^1333 := by decide +kernel

def env36520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,262144,1024,32769,17728,21793,21776,62558,8193,64,409957,16401,17664,431377,20564,62589,256,21793,46093,513]

theorem envBound36520 : H12AffineFastState.Bounded env36520 := by
  intro p hp
  have h : env36520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36519_36520 : H12AffineEnvironment.transform 6 9 env36519 = env36520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36519 == env36520) = true)

theorem identity36520 : scanCanonicalize (H12AffineFastState.compose env36520 (packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36520 : packedSelected [0,3,4,7,9,10,14,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env36521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,131072,262144,1024,8540,17728,21793,21776,21763,8193,64,409957,16401,17664,406604,20564,21792,256,21793,5456,513]

theorem envBound36521 : H12AffineFastState.Bounded env36521 := by
  intro p hp
  have h : env36521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36520_36521 : H12AffineEnvironment.transform 14 8541 env36520 = env36521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36520 == env36521) = true)

theorem identity36521 : scanCanonicalize (H12AffineFastState.compose env36521 (packedSelected [0,2,6,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36521 : packedSelected [0,2,6,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env36522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,13340,262144,1024,8540,17728,21793,21776,21763,8193,64,292217,16401,17664,262224,20564,21792,256,21793,5456,513]

theorem envBound36522 : H12AffineFastState.Bounded env36522 := by
  intro p hp
  have h : env36522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36521_36522 : H12AffineEnvironment.transform 16 13340 env36521 = env36522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env36521 == env36522) = true)

theorem identity36522 : scanCanonicalize (H12AffineFastState.compose env36522 (packedSelected [4,9,12,14,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound36522 : packedSelected [4,9,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env36523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,13340,23668,1024,8540,17728,21793,21776,21763,8193,64,10509,16401,17664,23588,20564,21792,256,21793,5456,513]

theorem envBound36523 : H12AffineFastState.Bounded env36523 := by
  intro p hp
  have h : env36523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36522_36523 : H12AffineEnvironment.transform 17 23668 env36522 = env36523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env36522 == env36523) = true)

theorem identity36523 : scanCanonicalize (H12AffineFastState.compose env36523 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36523 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env36524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8282,13340,2340,1024,8540,4112,113,64,83,8193,64,10509,5441,4176,2420,1284,112,256,113,5456,513]

theorem envBound36524 : H12AffineFastState.Bounded env36524 := by
  intro p hp
  have h : env36524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1