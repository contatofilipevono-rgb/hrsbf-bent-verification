import H12CloudChart1Data120

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans30687_30688 : H12AffineEnvironment.transform 6 9 env30687 = env30688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30687 == env30688) = true)

theorem identity30688 : scanCanonicalize (H12AffineFastState.compose env30688 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30688 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env30689 : List Nat := [2,4,8,16,0,64,9,84,512,69,81,16,89,1,81,82,16,0,69,80,80,1,17,2,88,64,0,16,16,80,69,0,84,1,80,512]

theorem envBound30689 : H12AffineFastState.Bounded env30689 := by
  intro p hp
  have h : env30689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30688_30689 : H12AffineEnvironment.transform 4 0 env30688 = env30689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30688 == env30689) = true)

theorem identity30689 : scanCanonicalize (H12AffineFastState.compose env30689 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound30689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30690 : List Nat := [2,4,8,16,0,64,9,84,80,69,81,16,89,1,81,82,16,0,69,80,80,1,17,2,88,64,0,16,16,80,69,0,84,1,80,80]

theorem envBound30690 : H12AffineFastState.Bounded env30690 := by
  intro p hp
  have h : env30690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30689_30690 : H12AffineEnvironment.transform 8 80 env30689 = env30690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env30689 == env30690) = true)

theorem identity30690 : scanCanonicalize (H12AffineFastState.compose env30690 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound30690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30691 : List Nat := [2,4,8,15,0,64,9,75,79,69,78,15,70,1,78,77,15,0,69,79,79,1,14,2,71,64,0,15,15,79,69,0,75,1,79,79]

theorem envBound30691 : H12AffineFastState.Bounded env30691 := by
  intro p hp
  have h : env30691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30690_30691 : H12AffineEnvironment.transform 3 15 env30690 = env30691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env30690 == env30691) = true)

theorem identity30691 : scanCanonicalize (H12AffineFastState.compose env30691 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound30691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30692 : List Nat := [2,4,8,15,0,14,9,5,1,11,0,15,8,1,0,3,15,0,11,1,1,1,14,2,9,14,0,15,15,1,11,0,5,1,1,1]

theorem envBound30692 : H12AffineFastState.Bounded env30692 := by
  intro p hp
  have h : env30692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30691_30692 : H12AffineEnvironment.transform 5 14 env30691 = env30692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env30691 == env30692) = true)

def env30693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102814,98678,41293,41431,8328,64,146629,46276,77954,138341,99466,98814,256,168,46093,41820]

theorem envBound30693 : H12AffineFastState.Bounded env30693 := by
  intro p hp
  have h : env30693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30678_30693 : H12AffineEnvironment.transform 17 10281 env30678 = env30693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30678 == env30693) = true)

theorem identity30693 : scanCanonicalize (H12AffineFastState.compose env30693 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30693 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,78019,73771,16,138,8328,64,146629,5529,77954,138341,75223,73891,256,168,5456,513]

theorem envBound30694 : H12AffineFastState.Bounded env30694 := by
  intro p hp
  have h : env30694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30693_30694 : H12AffineEnvironment.transform 14 8541 env30693 = env30694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30693 == env30694) = true)

theorem identity30694 : scanCanonicalize (H12AffineFastState.compose env30694 (packedSelected [0,2,6,9,11,18,22,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound30694 : packedSelected [0,2,6,9,11,18,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env30695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79251,10281,1024,8540,78019,73771,16,138,8328,64,67926,5529,77954,76278,75223,73891,256,168,5456,513]

theorem envBound30695 : H12AffineFastState.Bounded env30695 := by
  intro p hp
  have h : env30695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30694_30695 : H12AffineEnvironment.transform 16 79251 env30694 = env30695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env30694 == env30695) = true)

theorem identity30695 : scanCanonicalize (H12AffineFastState.compose env30695 (packedSelected [0,3,5,7,10,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30695 : packedSelected [0,3,5,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env30696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1,65536,70863,2421,1024,0,70047,65911,16,138,468,64,67926,5529,70110,67754,66699,66047,256,168,5456,513]

theorem envBound30696 : H12AffineFastState.Bounded env30696 := by
  intro p hp
  have h : env30696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30695_30696 : H12AffineEnvironment.transform 12 348 env30695 = env30696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30695 == env30696) = true)

theorem identity30696 : scanCanonicalize (H12AffineFastState.compose env30696 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound30696 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env30697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,1,398,5441,2421,1024,0,4113,249,16,138,468,64,2264,5529,4176,2340,1285,113,256,168,5456,513]

theorem envBound30697 : H12AffineFastState.Bounded env30697 := by
  intro p hp
  have h : env30697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30696_30697 : H12AffineEnvironment.transform 15 398 env30696 = env30697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env30696 == env30697) = true)

theorem identity30697 : scanCanonicalize (H12AffineFastState.compose env30697 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30697 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30698 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5376,1,398,5393,2341,1024,0,4113,169,16,138,388,16,2184,5529,4096,2340,1285,33,256,168,5376,513]

theorem envBound30698 : H12AffineFastState.Bounded env30698 := by
  intro p hp
  have h : env30698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30697_30698 : H12AffineEnvironment.transform 5 16 env30697 = env30698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30697 == env30698) = true)

theorem identity30698 : scanCanonicalize (H12AffineFastState.compose env30698 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound30698 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env30699 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,444,268,1212,1,398,1197,2341,1024,0,429,169,16,138,388,16,2184,1061,444,2340,1285,33,256,168,1212,513]

theorem envBound30699 : H12AffineFastState.Bounded env30699 := by
  intro p hp
  have h : env30699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30698_30699 : H12AffineEnvironment.transform 11 444 env30698 = env30699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env30698 == env30699) = true)

theorem identity30699 : scanCanonicalize (H12AffineFastState.compose env30699 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound30699 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30700 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,444,268,1212,1,398,1197,292,1024,0,429,169,16,138,388,16,137,1061,444,293,1285,33,256,168,1212,513]

theorem envBound30700 : H12AffineFastState.Bounded env30700 := by
  intro p hp
  have h : env30700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30699_30700 : H12AffineEnvironment.transform 10 1 env30699 = env30700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env30699 == env30700) = true)

theorem identity30700 : scanCanonicalize (H12AffineFastState.compose env30700 (packedSelected [12] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30700 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env30701 : List Nat := [2,4,8,16,32,16,128,256,512,273,1,444,268,429,1,398,444,292,273,0,429,169,16,138,388,16,137,308,444,293,20,33,256,168,429,513]

theorem envBound30701 : H12AffineFastState.Bounded env30701 := by
  intro p hp
  have h : env30701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30700_30701 : H12AffineEnvironment.transform 9 273 env30700 = env30701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30700 == env30701) = true)

def env30702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175049,8328,64,2590067,46276,77954,2598354,99467,2101344,256,2199862,2172306,41821]

theorem envBound30702 : H12AffineFastState.Bounded env30702 := by
  intro p hp
  have h : env30702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30676_30702 : H12AffineEnvironment.transform 13 5377 env30676 = env30702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30676 == env30702) = true)

theorem identity30702 : scanCanonicalize (H12AffineFastState.compose env30702 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound30702 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,2097152,2101481,2142477,2142614,8328,64,2491564,46276,45405,2499597,1364,2101344,256,2101481,2139213,41821]

theorem envBound30703 : H12AffineFastState.Bounded env30703 := by
  intro p hp
  have h : env30703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30702_30703 : H12AffineEnvironment.transform 15 33247 env30702 = env30703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env30702 == env30703) = true)

theorem identity30703 : scanCanonicalize (H12AffineFastState.compose env30703 (packedSelected [1,12,15,19,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound30703 : packedSelected [1,12,15,19,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env30704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,46277,262144,1024,32769,2097152,2101481,2142477,2142614,8328,64,2404457,46276,45405,2396360,1364,2101344,256,2101481,2139213,41821]

theorem envBound30704 : H12AffineFastState.Bounded env30704 := by
  intro p hp
  have h : env30704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30703_30704 : H12AffineEnvironment.transform 16 46277 env30703 = env30704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env30703 == env30704) = true)

def env30705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,46277,262144,1024,32769,276704,272393,297453,297334,8328,64,34953,46276,45405,43048,1364,272512,256,272393,302253,41821]

theorem envBound30705 : H12AffineFastState.Bounded env30705 := by
  intro p hp
  have h : env30705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30704_30705 : H12AffineEnvironment.transform 20 276704 env30704 = env30705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276704 env30704 == env30705) = true)

theorem identity30705 : scanCanonicalize (H12AffineFastState.compose env30705 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound30705 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env30706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5392,262144,1024,8660,276704,272393,272440,272547,8328,64,10588,5393,4232,2557,1364,272512,256,272393,277880,648]

theorem envBound30706 : H12AffineFastState.Bounded env30706 := by
  intro p hp
  have h : env30706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30705_30706 : H12AffineEnvironment.transform 14 8661 env30705 = env30706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env30705 == env30706) = true)

theorem identity30706 : scanCanonicalize (H12AffineFastState.compose env30706 (packedSelected [0,1,2,3,5,7,8,10,11,14,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound30706 : packedSelected [0,1,2,3,5,7,8,10,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env30707 : List Nat := [2,4,8,16,32,64,128,85,512,1024,2048,4096,8192,5204,8320,8202,5189,262144,1024,8321,276704,272393,272440,272547,8328,64,10249,5188,4232,2216,1025,272512,85,272393,277549,648]

theorem envBound30707 : H12AffineFastState.Bounded env30707 := by
  intro p hp
  have h : env30707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30706_30707 : H12AffineEnvironment.transform 7 85 env30706 = env30707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env30706 == env30707) = true)

def env30708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,46277,262144,1024,32769,276705,272392,297452,297335,8328,64,34952,46276,45405,43049,1364,272513,256,272392,302252,41821]

theorem envBound30708 : H12AffineFastState.Bounded env30708 := by
  intro p hp
  have h : env30708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30704_30708 : H12AffineEnvironment.transform 20 276705 env30704 = env30708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276705 env30704 == env30708) = true)

theorem identity30708 : scanCanonicalize (H12AffineFastState.compose env30708 (packedSelected [1,5,8,19,21,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound30708 : packedSelected [1,5,8,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env30709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,46277,35189,1024,32769,45460,41341,153,2,8328,64,34952,46276,45405,43049,1364,41460,256,41341,5593,41821]

theorem envBound30709 : H12AffineFastState.Bounded env30709 := by
  intro p hp
  have h : env30709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30708_30709 : H12AffineEnvironment.transform 17 35189 env30708 = env30709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env30708 == env30709) = true)

theorem identity30709 : scanCanonicalize (H12AffineFastState.compose env30709 (packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 428) := by decide +kernel

theorem selectedBound30709 : packedSelected [0,1,2,4,7,8,9,12,15,19] rootPS < 2^1333 := by decide +kernel

def env30710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,428,115,13673,2265,1024,429,12344,8401,153,2,8328,64,2340,13672,12529,10629,1364,8280,256,8401,5593,8945]

theorem envBound30710 : H12AffineFastState.Bounded env30710 := by
  intro p hp
  have h : env30710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30709_30710 : H12AffineEnvironment.transform 14 428 env30709 = env30710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 428 env30709 == env30710) = true)

theorem identity30710 : scanCanonicalize (H12AffineFastState.compose env30710 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound30710 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,5377,428,115,5529,2265,1024,429,4296,33,153,2,120,64,2340,5528,4097,2421,1364,168,256,33,5593,513]

theorem envBound30711 : H12AffineFastState.Bounded env30711 := by
  intro p hp
  have h : env30711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30710_30711 : H12AffineEnvironment.transform 12 240 env30710 = env30711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env30710 == env30711) = true)

theorem identity30711 : scanCanonicalize (H12AffineFastState.compose env30711 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30711 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30712 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,240,5156,137,115,5308,2265,1024,136,4296,33,153,2,120,64,2049,5309,4097,2128,1137,168,37,33,5372,513]

theorem envBound30712 : H12AffineFastState.Bounded env30712 := by
  intro p hp
  have h : env30712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30711_30712 : H12AffineEnvironment.transform 7 37 env30711 = env30712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30711 == env30712) = true)

theorem identity30712 : scanCanonicalize (H12AffineFastState.compose env30712 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30712 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30713 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,161,5156,137,34,5308,2184,1024,136,4249,33,153,2,41,17,2049,5309,4097,2049,1056,168,37,33,5293,513]

theorem envBound30713 : H12AffineFastState.Bounded env30713 := by
  intro p hp
  have h : env30713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30712_30713 : H12AffineEnvironment.transform 5 17 env30712 = env30713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30712 == env30713) = true)

theorem identity30713 : scanCanonicalize (H12AffineFastState.compose env30713 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound30713 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30714 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,1060,161,0,137,34,152,2184,1024,136,1213,33,153,2,41,17,2049,153,1061,2049,1056,168,37,33,137,513]

theorem envBound30714 : H12AffineFastState.Bounded env30714 := by
  intro p hp
  have h : env30714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30713_30714 : H12AffineEnvironment.transform 11 1060 env30713 = env30714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env30713 == env30714) = true)

theorem identity30714 : scanCanonicalize (H12AffineFastState.compose env30714 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30714 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30715 : List Nat := [2,4,8,16,32,17,128,37,512,53,2048,17,161,0,137,34,152,2184,53,136,136,33,153,2,41,17,2049,153,16,2049,21,168,37,33,137,513]

theorem envBound30715 : H12AffineFastState.Bounded env30715 := by
  intro p hp
  have h : env30715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30714_30715 : H12AffineEnvironment.transform 9 53 env30714 = env30715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30714 == env30715) = true)

theorem identity30715 : scanCanonicalize (H12AffineFastState.compose env30715 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30715 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30716 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,17,41,0,1,34,16,2048,53,0,0,33,17,2,41,17,2049,17,16,2049,21,32,37,33,1,513]

theorem envBound30716 : H12AffineFastState.Bounded env30716 := by
  intro p hp
  have h : env30716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30715_30716 : H12AffineEnvironment.transform 6 8 env30715 = env30716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30715 == env30716) = true)

theorem identity30716 : scanCanonicalize (H12AffineFastState.compose env30716 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound30716 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30717 : List Nat := [2,4,8,16,32,17,8,37,33,53,2048,17,41,0,1,34,16,2048,53,0,0,33,17,2,41,17,2049,17,16,2049,21,32,37,33,1,32]

theorem envBound30717 : H12AffineFastState.Bounded env30717 := by
  intro p hp
  have h : env30717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30716_30717 : H12AffineEnvironment.transform 8 33 env30716 = env30717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env30716 == env30717) = true)

theorem identity30717 : scanCanonicalize (H12AffineFastState.compose env30717 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound30717 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30718 : List Nat := [2,4,8,16,32,17,8,37,33,53,48,17,41,0,1,34,16,48,53,0,0,33,17,2,41,17,49,17,16,49,21,32,37,33,1,32]

theorem envBound30718 : H12AffineFastState.Bounded env30718 := by
  intro p hp
  have h : env30718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30717_30718 : H12AffineEnvironment.transform 10 48 env30717 = env30718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env30717 == env30718) = true)

theorem identity30718 : scanCanonicalize (H12AffineFastState.compose env30718 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30718 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30719 : List Nat := [2,4,8,16,17,17,8,20,16,4,1,17,24,0,1,19,16,1,4,0,0,16,17,2,24,17,0,17,16,0,21,17,20,16,1,17]

theorem envBound30719 : H12AffineFastState.Bounded env30719 := by
  intro p hp
  have h : env30719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30718_30719 : H12AffineEnvironment.transform 4 17 env30718 = env30719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30718 == env30719) = true)

def env30720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,16777216,8328,64,17227834,18973837,77954,2598354,18932163,16850984,256,16818559,16793818,18990613]

theorem envBound30720 : H12AffineFastState.Bounded env30720 := by
  intro p hp
  have h : env30720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30629_30720 : H12AffineEnvironment.transform 21 2115049 env30629 = env30720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env30629 == env30720) = true)

def env30721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175048,8328,64,2609266,46277,77954,2598354,119179,2101344,256,2199863,2191506,63069]

theorem envBound30721 : H12AffineFastState.Bounded env30721 := by
  intro p hp
  have h : env30721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30720_30721 : H12AffineEnvironment.transform 23 2175048 env30720 = env30721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env30720 == env30721) = true)

def env30722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175048,8328,64,2590066,46277,77954,2598354,99467,2101344,256,2199863,2172306,41821]

theorem envBound30722 : H12AffineFastState.Bounded env30722 := by
  intro p hp
  have h : env30722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30721_30722 : H12AffineEnvironment.transform 13 5376 env30721 = env30722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30721 == env30722) = true)

theorem identity30722 : scanCanonicalize (H12AffineFastState.compose env30722 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound30722 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,169,73875,73736,8328,64,496946,46277,77954,505234,99467,32,256,98679,79314,41821]

theorem envBound30723 : H12AffineFastState.Bounded env30723 := by
  intro p hp
  have h : env30723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30722_30723 : H12AffineEnvironment.transform 20 4160 env30722 = env30723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env30722 == env30723) = true)

def env30724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,73755,73736,8192,64,496946,46157,77834,505114,99331,32,256,98679,79194,41821]

theorem envBound30724 : H12AffineFastState.Bounded env30724 := by
  intro p hp
  have h : env30724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30723_30724 : H12AffineEnvironment.transform 6 8 env30723 = env30724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30723 == env30724) = true)

theorem identity30724 : scanCanonicalize (H12AffineFastState.compose env30724 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound30724 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,103495,262144,1024,32769,4160,33,73755,73736,8192,64,262517,46157,77834,270685,99331,32,256,98679,79194,41821]

theorem envBound30725 : H12AffineFastState.Bounded env30725 := by
  intro p hp
  have h : env30725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30724_30725 : H12AffineEnvironment.transform 16 103495 env30724 = env30725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env30724 == env30725) = true)

theorem identity30725 : scanCanonicalize (H12AffineFastState.compose env30725 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30725 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env30726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,79131,262144,1024,8541,4160,33,73755,73736,8192,64,262517,5393,77834,270685,75103,32,256,73771,79194,513]

theorem envBound30726 : H12AffineFastState.Bounded env30726 := by
  intro p hp
  have h : env30726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30725_30726 : H12AffineEnvironment.transform 14 8540 env30725 = env30726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30725 == env30726) = true)

theorem identity30726 : scanCanonicalize (H12AffineFastState.compose env30726 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound30726 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30727 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,5157,8313,65536,78910,262144,1024,8312,4160,33,73755,73736,8192,64,262224,5172,77834,270456,74874,32,37,73771,78975,513]

theorem envBound30727 : H12AffineFastState.Bounded env30727 := by
  intro p hp
  have h : env30727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30726_30727 : H12AffineEnvironment.transform 7 37 env30726 = env30727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env30726 == env30727) = true)

theorem identity30727 : scanCanonicalize (H12AffineFastState.compose env30727 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound30727 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30728 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,8192,4113,8313,65536,77834,262144,52,8312,4160,33,73755,73736,8192,64,262224,4096,77834,270456,73806,32,37,73771,77899,513]

theorem envBound30728 : H12AffineFastState.Bounded env30728 := by
  intro p hp
  have h : env30728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30727_30728 : H12AffineEnvironment.transform 9 52 env30727 = env30728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env30727 == env30728) = true)

theorem identity30728 : scanCanonicalize (H12AffineFastState.compose env30728 (packedSelected [0,2,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4728) := by decide +kernel

theorem selectedBound30728 : packedSelected [0,2,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env30729 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4728,4113,4609,65536,66162,262144,52,4608,4160,33,70243,70256,4728,64,262224,4096,66162,266752,70198,32,37,70227,66099,513]

theorem envBound30729 : H12AffineFastState.Bounded env30729 := by
  intro p hp
  have h : env30729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30728_30729 : H12AffineEnvironment.transform 12 4728 env30728 = env30729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4728 env30728 == env30729) = true)

theorem identity30729 : scanCanonicalize (H12AffineFastState.compose env30729 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound30729 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env30730 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4728,4113,4609,65536,66162,67618,52,4608,4160,33,70243,70256,4728,64,67698,4096,66162,72226,70198,32,37,70227,66099,513]

theorem envBound30730 : H12AffineFastState.Bounded env30730 := by
  intro p hp
  have h : env30730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30729_30730 : H12AffineEnvironment.transform 17 67618 env30729 = env30730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env30729 == env30730) = true)

theorem identity30730 : scanCanonicalize (H12AffineFastState.compose env30730 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 4643) := by decide +kernel

theorem selectedBound30730 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30731 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,4096,4728,4113,4609,4643,4177,6657,52,4608,4160,33,64,83,4728,64,6737,4096,4177,2049,21,32,37,112,4112,513]

theorem envBound30731 : H12AffineFastState.Bounded env30731 := by
  intro p hp
  have h : env30731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30730_30731 : H12AffineEnvironment.transform 15 4643 env30730 = env30731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4643 env30730 == env30731) = true)

theorem identity30731 : scanCanonicalize (H12AffineFastState.compose env30731 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30731 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env30732 : List Nat := [2,4,8,16,32,64,8,37,16,52,2048,4096,4200,4113,4113,4147,4177,6161,52,4112,4160,33,64,83,4200,64,6209,4096,4177,2049,21,32,37,112,4112,17]

theorem envBound30732 : H12AffineFastState.Bounded env30732 := by
  intro p hp
  have h : env30732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30731_30732 : H12AffineEnvironment.transform 8 16 env30731 = env30732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30731 == env30732) = true)

theorem identity30732 : scanCanonicalize (H12AffineFastState.compose env30732 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound30732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30733 : List Nat := [2,4,8,16,32,64,8,37,16,52,2048,1,105,16,16,50,80,2064,52,17,65,33,64,83,105,64,2112,1,80,2049,21,32,37,112,17,17]

theorem envBound30733 : H12AffineFastState.Bounded env30733 := by
  intro p hp
  have h : env30733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30732_30733 : H12AffineEnvironment.transform 11 1 env30732 = env30733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env30732 == env30733) = true)

theorem identity30733 : scanCanonicalize (H12AffineFastState.compose env30733 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30733 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30734 : List Nat := [2,4,2,16,32,64,2,37,16,52,2048,1,99,16,16,50,80,2064,52,17,65,33,64,83,99,64,2112,1,80,2049,21,32,37,112,17,17]

theorem envBound30734 : H12AffineFastState.Bounded env30734 := by
  intro p hp
  have h : env30734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30733_30734 : H12AffineEnvironment.transform 2 2 env30733 = env30734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30733 == env30734) = true)

theorem identity30734 : scanCanonicalize (H12AffineFastState.compose env30734 (packedSelected [0,6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound30734 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env30735 : List Nat := [2,4,2,16,32,0,2,37,16,52,2048,1,35,16,16,50,16,2064,52,17,1,33,0,19,35,0,2048,1,16,2049,21,32,37,48,17,17]

theorem envBound30735 : H12AffineFastState.Bounded env30735 := by
  intro p hp
  have h : env30735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30734_30735 : H12AffineEnvironment.transform 5 0 env30734 = env30735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30734 == env30735) = true)

theorem identity30735 : scanCanonicalize (H12AffineFastState.compose env30735 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound30735 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env30736 : List Nat := [2,4,2,16,32,0,2,37,16,52,16,1,35,16,16,50,16,0,52,17,1,33,0,19,35,0,16,1,16,17,21,32,37,48,17,17]

theorem envBound30736 : H12AffineFastState.Bounded env30736 := by
  intro p hp
  have h : env30736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30735_30736 : H12AffineEnvironment.transform 10 16 env30735 = env30736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env30735 == env30736) = true)

theorem identity30736 : scanCanonicalize (H12AffineFastState.compose env30736 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30736 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30737 : List Nat := [2,4,2,0,32,0,2,37,0,36,0,1,35,0,0,34,0,0,36,1,1,33,0,3,35,0,0,1,0,1,5,32,37,32,1,1]

theorem envBound30737 : H12AffineFastState.Bounded env30737 := by
  intro p hp
  have h : env30737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30736_30737 : H12AffineEnvironment.transform 3 0 env30736 = env30737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30736 == env30737) = true)

def env30738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,73754,73736,8193,64,496946,46156,77835,505115,99330,32,256,98679,79195,41821]

theorem envBound30738 : H12AffineFastState.Bounded env30738 := by
  intro p hp
  have h : env30738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30723_30738 : H12AffineEnvironment.transform 6 9 env30723 = env30738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30723 == env30738) = true)

theorem identity30738 : scanCanonicalize (H12AffineFastState.compose env30738 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound30738 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79131,262144,1024,32769,4160,32,73754,73736,8193,64,303145,46156,77835,294912,99330,32,256,98679,79195,41821]

theorem envBound30739 : H12AffineFastState.Bounded env30739 := by
  intro p hp
  have h : env30739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30738_30739 : H12AffineEnvironment.transform 16 79131 env30738 = env30739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env30738 == env30739) = true)

theorem identity30739 : scanCanonicalize (H12AffineFastState.compose env30739 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30739 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env30740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,79131,262144,1024,8541,4160,32,73754,73736,8193,64,262517,5392,77835,270684,75102,32,256,73771,79195,513]

theorem envBound30740 : H12AffineFastState.Bounded env30740 := by
  intro p hp
  have h : env30740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30739_30740 : H12AffineEnvironment.transform 14 8540 env30739 = env30740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30739 == env30740) = true)

theorem identity30740 : scanCanonicalize (H12AffineFastState.compose env30740 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound30740 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,262,13341,262144,1024,8541,4160,32,8476,8462,8193,64,262517,5392,12557,270684,9304,32,256,8493,13405,513]

theorem envBound30741 : H12AffineFastState.Bounded env30741 := by
  intro p hp
  have h : env30741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30740_30741 : H12AffineEnvironment.transform 15 262 env30740 = env30741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env30740 == env30741) = true)

theorem identity30741 : scanCanonicalize (H12AffineFastState.compose env30741 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30741 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,262,5392,262144,1024,80,4160,32,17,3,268,64,262517,5392,4096,262225,1365,32,256,32,5456,513]

theorem envBound30742 : H12AffineFastState.Bounded env30742 := by
  intro p hp
  have h : env30742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30741_30742 : H12AffineEnvironment.transform 12 269 env30741 = env30742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30741 == env30742) = true)

theorem identity30742 : scanCanonicalize (H12AffineFastState.compose env30742 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound30742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,262,5392,2421,1024,80,4160,32,17,3,268,64,2048,5392,4096,2340,1365,32,256,32,5456,513]

theorem envBound30743 : H12AffineFastState.Bounded env30743 := by
  intro p hp
  have h : env30743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30742_30743 : H12AffineEnvironment.transform 17 2421 env30742 = env30743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env30742 == env30743) = true)

theorem identity30743 : scanCanonicalize (H12AffineFastState.compose env30743 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound30743 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,269,1124,81,262,1140,2421,1024,80,292,32,17,3,268,64,2048,1140,356,2340,1365,32,256,32,1076,513]

theorem envBound30744 : H12AffineFastState.Bounded env30744 := by
  intro p hp
  have h : env30744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30743_30744 : H12AffineEnvironment.transform 11 356 env30743 = env30744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env30743 == env30744) = true)

theorem identity30744 : scanCanonicalize (H12AffineFastState.compose env30744 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30744 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,356,269,1124,81,262,1140,81,1024,80,292,32,17,3,268,64,292,1140,356,0,1365,32,256,32,1076,513]

theorem envBound30745 : H12AffineFastState.Bounded env30745 := by
  intro p hp
  have h : env30745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30744_30745 : H12AffineEnvironment.transform 10 292 env30744 = env30745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30744 == env30745) = true)

theorem identity30745 : scanCanonicalize (H12AffineFastState.compose env30745 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30745 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30746 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,308,269,1076,1,262,1060,1,1024,0,292,32,17,3,268,16,292,1060,308,0,1285,32,256,32,1076,513]

theorem envBound30746 : H12AffineFastState.Bounded env30746 := by
  intro p hp
  have h : env30746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30745_30746 : H12AffineEnvironment.transform 5 16 env30745 = env30746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30745 == env30746) = true)

theorem identity30746 : scanCanonicalize (H12AffineFastState.compose env30746 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound30746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30747 : List Nat := [2,4,8,16,32,16,9,256,512,304,292,308,269,260,1,262,276,1,304,0,292,32,17,3,268,16,292,276,308,0,53,32,256,32,260,513]

theorem envBound30747 : H12AffineFastState.Bounded env30747 := by
  intro p hp
  have h : env30747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30746_30747 : H12AffineEnvironment.transform 9 304 env30746 = env30747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env30746 == env30747) = true)

theorem identity30747 : scanCanonicalize (H12AffineFastState.compose env30747 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30747 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30748 : List Nat := [2,4,8,16,32,16,9,256,1,304,292,308,269,260,1,262,276,1,304,0,292,32,17,3,268,16,292,276,308,0,53,32,256,32,260,0]

theorem envBound30748 : H12AffineFastState.Bounded env30748 := by
  intro p hp
  have h : env30748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30747_30748 : H12AffineEnvironment.transform 8 1 env30747 = env30748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30747 == env30748) = true)

theorem identity30748 : scanCanonicalize (H12AffineFastState.compose env30748 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30748 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30749 : List Nat := [2,4,8,1,32,1,9,256,1,289,292,293,269,260,1,262,261,1,289,0,292,32,0,3,268,1,292,261,293,0,36,32,256,32,260,0]

theorem envBound30749 : H12AffineFastState.Bounded env30749 := by
  intro p hp
  have h : env30749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30748_30749 : H12AffineEnvironment.transform 3 1 env30748 = env30749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30748 == env30749) = true)

theorem identity30749 : scanCanonicalize (H12AffineFastState.compose env30749 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30749 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30750 : List Nat := [2,4,8,1,1,1,9,256,1,256,261,260,269,260,1,262,261,1,256,0,261,1,0,3,268,1,261,261,260,0,5,1,256,1,260,0]

theorem envBound30750 : H12AffineFastState.Bounded env30750 := by
  intro p hp
  have h : env30750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30749_30750 : H12AffineEnvironment.transform 4 1 env30749 = env30750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30749 == env30750) = true)

theorem identity30750 : scanCanonicalize (H12AffineFastState.compose env30750 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30751 : List Nat := [2,4,8,1,1,1,9,4,1,4,1,0,9,0,1,2,1,1,4,0,1,1,0,3,8,1,1,1,0,0,5,1,4,1,0,0]

theorem envBound30751 : H12AffineFastState.Bounded env30751 := by
  intro p hp
  have h : env30751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30750_30751 : H12AffineEnvironment.transform 7 4 env30750 = env30751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30750 == env30751) = true)

def env30752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175048,8328,64,2590067,46277,77954,2598354,99466,2101344,256,2199863,2172307,41820]

theorem envBound30752 : H12AffineFastState.Bounded env30752 := by
  intro p hp
  have h : env30752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30721_30752 : H12AffineEnvironment.transform 13 5377 env30721 = env30752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30721 == env30752) = true)

def env30753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101344,2175066,2175048,8192,64,2590067,46157,77834,2598234,99330,2101344,256,2199863,2172187,41820]

theorem envBound30753 : H12AffineFastState.Bounded env30753 := by
  intro p hp
  have h : env30753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30752_30753 : H12AffineEnvironment.transform 6 8 env30752 = env30753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30752 == env30753) = true)

def env30754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,2097152,2101344,2175066,2175048,8192,64,2338139,46157,77834,2329970,99330,2101344,256,2199863,2172187,41820]

theorem envBound30754 : H12AffineFastState.Bounded env30754 := by
  intro p hp
  have h : env30754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30753_30754 : H12AffineEnvironment.transform 17 10280 env30753 = env30754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30753 == env30754) = true)

theorem identity30754 : scanCanonicalize (H12AffineFastState.compose env30754 (packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound30754 : packedSelected [3,4,5,7,8,9,10,14,16,20,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env30755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,10280,1024,32769,2097152,2101344,2175066,2175048,8192,64,2136129,46157,77834,2144360,99330,2101344,256,2199863,2172187,41820]

theorem envBound30755 : H12AffineFastState.Bounded env30755 := by
  intro p hp
  have h : env30755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30754_30755 : H12AffineEnvironment.transform 16 79130 env30754 = env30755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env30754 == env30755) = true)

theorem identity30755 : scanCanonicalize (H12AffineFastState.compose env30755 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 45340) := by decide +kernel

theorem selectedBound30755 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,10280,1024,32769,45340,41340,98630,98644,8192,64,10589,46157,77834,2420,99330,41340,256,73771,103431,41820]

theorem envBound30756 : H12AffineFastState.Bounded env30756 := by
  intro p hp
  have h : env30756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30755_30756 : H12AffineEnvironment.transform 20 45340 env30755 = env30756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45340 env30755 == env30756) = true)

def env30757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,2097152,2101344,2175066,2175048,8192,64,2338138,46157,77834,2329971,99330,2101344,256,2199863,2172187,41820]

theorem envBound30757 : H12AffineFastState.Bounded env30757 := by
  intro p hp
  have h : env30757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30753_30757 : H12AffineEnvironment.transform 17 10281 env30753 = env30757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30753 == env30757) = true)

theorem identity30757 : scanCanonicalize (H12AffineFastState.compose env30757 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound30757 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,77898,73770,16,2,8192,64,171280,46157,77834,179513,99330,73770,256,41341,5457,41820]

theorem envBound30758 : H12AffineFastState.Bounded env30758 := by
  intro p hp
  have h : env30758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30757_30758 : H12AffineEnvironment.transform 20 77898 env30757 = env30758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env30757 == env30758) = true)

theorem identity30758 : scanCanonicalize (H12AffineFastState.compose env30758 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound30758 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,103495,10281,1024,32769,77898,73770,16,2,8192,64,67927,46157,77834,76158,99330,73770,256,41341,5457,41820]

theorem envBound30759 : H12AffineFastState.Bounded env30759 := by
  intro p hp
  have h : env30759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30758_30759 : H12AffineEnvironment.transform 16 103495 env30758 = env30759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env30758 == env30759) = true)

theorem identity30759 : scanCanonicalize (H12AffineFastState.compose env30759 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound30759 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env30760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,65536,70727,10281,1024,1,77898,73770,16,2,8192,64,67927,13389,77834,76158,66562,73770,256,8573,5457,9052]

theorem envBound30760 : H12AffineFastState.Bounded env30760 := by
  intro p hp
  have h : env30760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30759_30760 : H12AffineEnvironment.transform 14 0 env30759 = env30760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env30759 == env30760) = true)

theorem identity30760 : scanCanonicalize (H12AffineFastState.compose env30760 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30760 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,0,65536,70727,2048,1024,1,69731,65539,16,2,41,64,67927,5220,69667,67927,66562,65539,256,340,5457,885]

theorem envBound30761 : H12AffineFastState.Bounded env30761 := by
  intro p hp
  have h : env30761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30760_30761 : H12AffineEnvironment.transform 12 41 env30760 = env30761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30760 == env30761) = true)

def env30762 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101345,2175067,2175048,8193,64,2590067,46156,77835,2598235,99331,2101344,256,2199863,2172186,41820]

theorem envBound30762 : H12AffineFastState.Bounded env30762 := by
  intro p hp
  have h : env30762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30752_30762 : H12AffineEnvironment.transform 6 9 env30752 = env30762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30752 == env30762) = true)

theorem identity30762 : scanCanonicalize (H12AffineFastState.compose env30762 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30762 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30763 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,2097152,2101345,2175067,2175048,8193,64,2565166,5393,77835,2556934,75102,2101344,256,2175082,2172186,513]

theorem envBound30763 : H12AffineFastState.Bounded env30763 := by
  intro p hp
  have h : env30763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30762_30763 : H12AffineEnvironment.transform 14 8541 env30762 = env30763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30762 == env30763) = true)

def env30764 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1024,8540,2097152,2101345,2175067,2175048,8193,64,2296838,5393,77835,2305070,75102,2101344,256,2175082,2172186,513]

theorem envBound30764 : H12AffineFastState.Bounded env30764 := by
  intro p hp
  have h : env30764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30763_30764 : H12AffineEnvironment.transform 17 10280 env30763 = env30764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env30763 == env30764) = true)

theorem identity30764 : scanCanonicalize (H12AffineFastState.compose env30764 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound30764 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30765 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,10280,1024,8540,2097152,2101345,2175067,2175048,8193,64,2111772,5393,77835,2103604,75102,2101344,256,2175082,2172186,513]

theorem envBound30765 : H12AffineFastState.Bounded env30765 := by
  intro p hp
  have h : env30765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30764_30765 : H12AffineEnvironment.transform 16 79130 env30764 = env30765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env30764 == env30765) = true)

theorem identity30765 : scanCanonicalize (H12AffineFastState.compose env30765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,79130,10280,1024,8540,5457,1328,75018,75033,8193,64,11341,5393,77835,3173,75102,1329,256,75067,77899,513]

theorem envBound30766 : H12AffineFastState.Bounded env30766 := by
  intro p hp
  have h : env30766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30765_30766 : H12AffineEnvironment.transform 20 5457 env30765 = env30766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env30765 == env30766) = true)

theorem identity30766 : scanCanonicalize (H12AffineFastState.compose env30766 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound30766 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env30767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,8192,1345,8541,65536,75098,10280,1024,8540,1297,1328,75018,75033,8193,64,11341,1361,73803,3173,75102,1329,256,75067,73739,513]

theorem envBound30767 : H12AffineFastState.Bounded env30767 := by
  intro p hp
  have h : env30767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30766_30767 : H12AffineEnvironment.transform 11 64 env30766 = env30767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env30766 == env30767) = true)

theorem identity30767 : scanCanonicalize (H12AffineFastState.compose env30767 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound30767 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env30768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,8192,1345,8541,342,9228,10280,1024,8540,1297,1328,9308,9295,8193,64,11341,1361,8477,3173,9224,1329,256,9325,8541,513]

theorem envBound30768 : H12AffineFastState.Bounded env30768 := by
  intro p hp
  have h : env30768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30767_30768 : H12AffineEnvironment.transform 15 342 env30767 = env30768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env30767 == env30768) = true)

theorem identity30768 : scanCanonicalize (H12AffineFastState.compose env30768 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30768 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env30769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,64,268,1345,81,342,1280,2340,1024,80,1297,1328,1360,1347,269,64,3393,1361,17,3173,1284,1329,256,1377,81,513]

theorem envBound30769 : H12AffineFastState.Bounded env30769 := by
  intro p hp
  have h : env30769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30768_30769 : H12AffineEnvironment.transform 12 268 env30768 = env30769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30768 == env30769) = true)

theorem identity30769 : scanCanonicalize (H12AffineFastState.compose env30769 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound30769 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,64,268,1345,81,342,1280,1125,1024,80,1297,1328,1360,1347,269,64,0,1361,17,292,1284,1329,256,1377,81,513]

theorem envBound30770 : H12AffineFastState.Bounded env30770 := by
  intro p hp
  have h : env30770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30769_30770 : H12AffineEnvironment.transform 10 1345 env30769 = env30770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env30769 == env30770) = true)

theorem identity30770 : scanCanonicalize (H12AffineFastState.compose env30770 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30770 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30771 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1296,17,268,1296,0,263,1280,1076,1024,1,1297,1328,1281,1298,269,17,0,1280,17,292,1284,1329,256,1328,0,513]

theorem envBound30771 : H12AffineFastState.Bounded env30771 := by
  intro p hp
  have h : env30771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30770_30771 : H12AffineEnvironment.transform 5 17 env30770 = env30771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30770 == env30771) = true)

theorem identity30771 : scanCanonicalize (H12AffineFastState.compose env30771 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30771 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30772 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,17,268,1,0,263,17,293,273,1,0,33,16,3,269,17,0,17,17,292,21,32,256,33,0,513]

theorem envBound30772 : H12AffineFastState.Bounded env30772 := by
  intro p hp
  have h : env30772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30771_30772 : H12AffineEnvironment.transform 9 273 env30771 = env30772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30771 == env30772) = true)

theorem identity30772 : scanCanonicalize (H12AffineFastState.compose env30772 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30773 : List Nat := [2,4,8,1,32,0,9,256,512,256,1,0,268,1,0,263,0,293,256,1,0,33,1,3,269,0,0,0,0,292,4,32,256,33,0,513]

theorem envBound30773 : H12AffineFastState.Bounded env30773 := by
  intro p hp
  have h : env30773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30772_30773 : H12AffineEnvironment.transform 3 1 env30772 = env30773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30772 == env30773) = true)

theorem identity30773 : scanCanonicalize (H12AffineFastState.compose env30773 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound30773 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30774 : List Nat := [2,4,8,1,32,0,9,256,261,256,1,0,268,1,0,263,0,293,256,1,0,33,1,3,269,0,0,0,0,292,4,32,256,33,0,260]

theorem envBound30774 : H12AffineFastState.Bounded env30774 := by
  intro p hp
  have h : env30774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30773_30774 : H12AffineEnvironment.transform 8 261 env30773 = env30774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env30773 == env30774) = true)

theorem identity30774 : scanCanonicalize (H12AffineFastState.compose env30774 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30775 : List Nat := [2,4,8,1,32,0,9,5,0,5,1,0,9,1,0,2,0,32,5,1,0,33,1,3,8,0,0,0,0,33,4,32,5,33,0,1]

theorem envBound30775 : H12AffineFastState.Bounded env30775 := by
  intro p hp
  have h : env30775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30774_30775 : H12AffineEnvironment.transform 7 5 env30774 = env30775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30774 == env30775) = true)

theorem identity30775 : scanCanonicalize (H12AffineFastState.compose env30775 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30776 : List Nat := [2,4,8,1,0,0,9,5,0,5,1,0,9,1,0,2,0,0,5,1,0,1,1,3,8,0,0,0,0,1,4,0,5,1,0,1]

theorem envBound30776 : H12AffineFastState.Bounded env30776 := by
  intro p hp
  have h : env30776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30775_30776 : H12AffineEnvironment.transform 4 0 env30775 = env30776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30775 == env30776) = true)

def env30777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,2097152,2101345,2175067,2175048,8193,64,2296839,5393,77835,2305071,75102,2101344,256,2175082,2172186,513]

theorem envBound30777 : H12AffineFastState.Bounded env30777 := by
  intro p hp
  have h : env30777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30763_30777 : H12AffineEnvironment.transform 17 10281 env30763 = env30777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30763 == env30777) = true)

theorem identity30777 : scanCanonicalize (H12AffineFastState.compose env30777 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 206091) := by decide +kernel

theorem selectedBound30777 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env30778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,206091,210282,136528,136515,8193,64,10508,5393,77835,2340,75102,210283,256,136545,131089,513]

theorem envBound30778 : H12AffineFastState.Bounded env30778 := by
  intro p hp
  have h : env30778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30777_30778 : H12AffineEnvironment.transform 20 206091 env30777 = env30778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206091 env30777 == env30778) = true)

theorem identity30778 : scanCanonicalize (H12AffineFastState.compose env30778 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound30778 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env30779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,10281,1024,8540,77850,73851,65,82,8193,64,10508,5393,77835,2340,75102,73850,256,112,5376,513]

theorem envBound30779 : H12AffineFastState.Bounded env30779 := by
  intro p hp
  have h : env30779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30778_30779 : H12AffineEnvironment.transform 16 5393 env30778 = env30779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env30778 == env30779) = true)

theorem identity30779 : scanCanonicalize (H12AffineFastState.compose env30779 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound30779 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,343,5393,10281,1024,8540,12621,8492,65,82,8193,64,10508,5393,12636,2340,9225,8493,256,112,5376,513]

theorem envBound30780 : H12AffineFastState.Bounded env30780 := by
  intro p hp
  have h : env30780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30779_30780 : H12AffineEnvironment.transform 15 343 env30779 = env30780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env30779 == env30780) = true)

def env30781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175049,8328,64,2609267,46276,77954,2598354,119178,2101345,256,2199862,2191507,63068]

theorem envBound30781 : H12AffineFastState.Bounded env30781 := by
  intro p hp
  have h : env30781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30720_30781 : H12AffineEnvironment.transform 23 2175049 env30720 = env30781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env30720 == env30781) = true)

def env30782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175049,8328,64,2590067,46276,77954,2598354,99466,2101345,256,2199862,2172307,41820]

theorem envBound30782 : H12AffineFastState.Bounded env30782 := by
  intro p hp
  have h : env30782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30781_30782 : H12AffineEnvironment.transform 13 5376 env30781 = env30782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30781 == env30782) = true)

theorem identity30782 : scanCanonicalize (H12AffineFastState.compose env30782 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30782 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,2097152,2101481,2175187,2175049,8328,64,2565166,5529,77954,2557071,75223,2101345,256,2175083,2172307,513]

theorem envBound30783 : H12AffineFastState.Bounded env30783 := by
  intro p hp
  have h : env30783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30782_30783 : H12AffineEnvironment.transform 14 8541 env30782 = env30783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30782 == env30783) = true)

def env30784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,2097152,2101481,2175187,2175049,8328,64,2296974,5529,77954,2305071,75223,2101345,256,2175083,2172307,513]

theorem envBound30784 : H12AffineFastState.Bounded env30784 := by
  intro p hp
  have h : env30784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30783_30784 : H12AffineEnvironment.transform 17 10400 env30783 = env30784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30783 == env30784) = true)

def env30785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,2097152,2101345,2175067,2175049,8192,64,2296838,5393,77834,2305071,75103,2101345,256,2175083,2172187,513]

theorem envBound30785 : H12AffineFastState.Bounded env30785 := by
  intro p hp
  have h : env30785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30784_30785 : H12AffineEnvironment.transform 6 8 env30784 = env30785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30784 == env30785) = true)

theorem identity30785 : scanCanonicalize (H12AffineFastState.compose env30785 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound30785 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10280,1024,8540,2097152,2101345,2175067,2175049,8192,64,2111773,5393,77834,2103604,75103,2101345,256,2175083,2172187,513]

theorem envBound30786 : H12AffineFastState.Bounded env30786 := by
  intro p hp
  have h : env30786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30785_30786 : H12AffineEnvironment.transform 16 79131 env30785 = env30786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env30785 == env30786) = true)

theorem identity30786 : scanCanonicalize (H12AffineFastState.compose env30786 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound30786 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9499,4096,10280,1024,8540,2097152,2101345,2102592,2102610,8192,64,2111773,5393,5393,2103604,68,2101345,256,2102640,2097152,513]

theorem envBound30787 : H12AffineFastState.Bounded env30787 := by
  intro p hp
  have h : env30787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30786_30787 : H12AffineEnvironment.transform 15 9499 env30786 = env30787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env30786 == env30787) = true)

theorem identity30787 : scanCanonicalize (H12AffineFastState.compose env30787 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(20+1) ^^^ 3393) := by decide +kernel

theorem selectedBound30787 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env30788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,9499,4096,10280,1024,8540,3393,7456,6145,6163,8192,64,13404,5393,5393,5237,68,7456,256,6193,3393,513]

theorem envBound30788 : H12AffineFastState.Bounded env30788 := by
  intro p hp
  have h : env30788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30787_30788 : H12AffineEnvironment.transform 20 3393 env30787 = env30788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3393 env30787 == env30788) = true)

theorem identity30788 : scanCanonicalize (H12AffineFastState.compose env30788 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound30788 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env30789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,8192,2049,8541,9499,3329,10280,1024,8540,3393,33,1280,1298,8192,64,10589,2064,2064,2420,68,33,256,1328,3393,513]

theorem envBound30789 : H12AffineFastState.Bounded env30789 := by
  intro p hp
  have h : env30789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30788_30789 : H12AffineEnvironment.transform 11 3329 env30788 = env30789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env30788 == env30789) = true)

theorem identity30789 : scanCanonicalize (H12AffineFastState.compose env30789 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30789 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,41,2049,372,1330,3329,2049,1024,373,3393,33,1280,1298,41,64,2420,2064,2064,2420,68,33,256,1328,3393,513]

theorem envBound30790 : H12AffineFastState.Bounded env30790 := by
  intro p hp
  have h : env30790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30789_30790 : H12AffineEnvironment.transform 12 41 env30789 = env30790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30789 == env30790) = true)

theorem identity30790 : scanCanonicalize (H12AffineFastState.compose env30790 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30790 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30791 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,3109,41,2049,80,1046,3109,2049,1024,81,3173,33,1060,1078,41,64,2128,2064,2064,2128,68,33,36,1044,3173,513]

theorem envBound30791 : H12AffineFastState.Bounded env30791 := by
  intro p hp
  have h : env30791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30790_30791 : H12AffineEnvironment.transform 7 36 env30790 = env30791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30790 == env30791) = true)

theorem identity30791 : scanCanonicalize (H12AffineFastState.compose env30791 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound30791 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30792 : List Nat := [2,4,8,16,32,64,8,36,512,1024,592,1653,41,593,80,1046,1653,593,1024,81,1589,33,1060,1078,41,64,512,576,576,512,68,33,36,1044,1589,513]

theorem envBound30792 : H12AffineFastState.Bounded env30792 := by
  intro p hp
  have h : env30792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30791_30792 : H12AffineEnvironment.transform 10 592 env30791 = env30792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env30791 == env30792) = true)

theorem identity30792 : scanCanonicalize (H12AffineFastState.compose env30792 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound30792 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env30793 : List Nat := [2,4,8,16,32,64,8,36,512,101,592,528,41,593,80,115,528,593,101,81,592,33,65,83,41,64,512,576,576,512,68,33,36,113,592,513]

theorem envBound30793 : H12AffineFastState.Bounded env30793 := by
  intro p hp
  have h : env30793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30792_30793 : H12AffineEnvironment.transform 9 101 env30792 = env30793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env30792 == env30793) = true)

theorem identity30793 : scanCanonicalize (H12AffineFastState.compose env30793 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30793 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30794 : List Nat := [2,4,8,16,32,17,8,36,512,52,513,528,41,512,1,34,528,512,52,0,513,33,16,2,41,17,512,529,529,512,21,33,36,32,513,513]

theorem envBound30794 : H12AffineFastState.Bounded env30794 := by
  intro p hp
  have h : env30794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30793_30794 : H12AffineEnvironment.transform 5 17 env30793 = env30794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30793 == env30794) = true)

theorem identity30794 : scanCanonicalize (H12AffineFastState.compose env30794 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound30794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30795 : List Nat := [2,4,8,16,32,17,8,36,48,52,49,32,41,48,1,34,32,48,52,0,49,33,16,2,41,17,48,33,33,48,21,33,36,32,49,49]

theorem envBound30795 : H12AffineFastState.Bounded env30795 := by
  intro p hp
  have h : env30795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30794_30795 : H12AffineEnvironment.transform 8 48 env30794 = env30795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env30794 == env30795) = true)

theorem identity30795 : scanCanonicalize (H12AffineFastState.compose env30795 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound30795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30796 : List Nat := [2,4,8,16,17,17,8,21,1,5,0,17,24,1,1,19,17,1,5,0,0,16,16,2,24,17,1,16,16,1,21,16,21,17,0,0]

theorem envBound30796 : H12AffineFastState.Bounded env30796 := by
  intro p hp
  have h : env30796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30795_30796 : H12AffineEnvironment.transform 4 17 env30795 = env30796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env30795 == env30796) = true)

theorem identity30796 : scanCanonicalize (H12AffineFastState.compose env30796 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30796 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30797 : List Nat := [2,4,8,1,0,0,8,4,1,5,0,0,9,1,1,2,0,1,5,0,0,1,1,2,9,0,1,1,1,1,4,1,4,0,0,0]

theorem envBound30797 : H12AffineFastState.Bounded env30797 := by
  intro p hp
  have h : env30797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30796_30797 : H12AffineEnvironment.transform 3 1 env30796 = env30797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30796 == env30797) = true)

def env30798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,2097152,2101344,2175066,2175049,8193,64,2296839,5392,77835,2305071,75102,2101345,256,2175083,2172186,513]

theorem envBound30798 : H12AffineFastState.Bounded env30798 := by
  intro p hp
  have h : env30798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30784_30798 : H12AffineEnvironment.transform 6 9 env30784 = env30798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30784 == env30798) = true)

theorem identity30798 : scanCanonicalize (H12AffineFastState.compose env30798 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 206091) := by decide +kernel

theorem selectedBound30798 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env30799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1024,8540,206091,210283,136529,136514,8193,64,10508,5392,77835,2340,75102,210282,256,136544,131089,513]

theorem envBound30799 : H12AffineFastState.Bounded env30799 := by
  intro p hp
  have h : env30799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30798_30799 : H12AffineEnvironment.transform 20 206091 env30798 = env30799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 206091 env30798 == env30799) = true)

theorem identity30799 : scanCanonicalize (H12AffineFastState.compose env30799 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound30799 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env30800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,5392,10281,1024,8540,77851,73851,65,82,8193,64,10508,5392,77835,2340,75102,73850,256,112,5377,513]

theorem envBound30800 : H12AffineFastState.Bounded env30800 := by
  intro p hp
  have h : env30800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30799_30800 : H12AffineEnvironment.transform 16 5392 env30799 = env30800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env30799 == env30800) = true)

theorem identity30800 : scanCanonicalize (H12AffineFastState.compose env30800 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound30800 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30801 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,343,5392,10281,1024,8540,12620,8492,65,82,8193,64,10508,5392,12636,2340,9225,8493,256,112,5377,513]

theorem envBound30801 : H12AffineFastState.Bounded env30801 := by
  intro p hp
  have h : env30801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30800_30801 : H12AffineEnvironment.transform 15 343 env30800 = env30801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env30800 == env30801) = true)

def env30802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,2097152,2101481,2175187,2175049,8328,64,2296975,5529,77954,2305070,75223,2101345,256,2175083,2172307,513]

theorem envBound30802 : H12AffineFastState.Bounded env30802 := by
  intro p hp
  have h : env30802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30783_30802 : H12AffineEnvironment.transform 17 10401 env30783 = env30802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30783 == env30802) = true)

theorem identity30802 : scanCanonicalize (H12AffineFastState.compose env30802 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 78019) := by decide +kernel

theorem selectedBound30802 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,73770,16,138,8328,64,146508,5529,77954,138477,75223,73890,256,168,5456,513]

theorem envBound30803 : H12AffineFastState.Bounded env30803 := by
  intro p hp
  have h : env30803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30802_30803 : H12AffineEnvironment.transform 20 78019 env30802 = env30803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78019 env30802 == env30803) = true)

theorem identity30803 : scanCanonicalize (H12AffineFastState.compose env30803 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound30803 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10401,1024,8540,78019,73770,16,138,8328,64,67927,5529,77954,76278,75223,73890,256,168,5456,513]

theorem envBound30804 : H12AffineFastState.Bounded env30804 := by
  intro p hp
  have h : env30804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30803_30804 : H12AffineEnvironment.transform 16 79131 env30803 = env30804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env30803 == env30804) = true)

theorem identity30804 : scanCanonicalize (H12AffineFastState.compose env30804 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound30804 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,9499,4096,10401,1024,8540,5592,1329,16,138,8328,64,11340,5529,5529,3309,204,1465,256,168,5456,513]

theorem envBound30805 : H12AffineFastState.Bounded env30805 := by
  intro p hp
  have h : env30805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30804_30805 : H12AffineEnvironment.transform 15 9499 env30804 = env30805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env30804 == env30805) = true)

theorem identity30805 : scanCanonicalize (H12AffineFastState.compose env30805 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound30805 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env30806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5376,1212,250,4096,3392,1024,1213,5592,1329,16,138,1385,64,2477,5529,5529,3309,204,1465,256,168,5456,513]

theorem envBound30806 : H12AffineFastState.Bounded env30806 := by
  intro p hp
  have h : env30806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30805_30806 : H12AffineEnvironment.transform 12 1505 env30805 = env30806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env30805 == env30806) = true)

theorem identity30806 : scanCanonicalize (H12AffineFastState.compose env30806 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30806 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env30807 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,161,4160,508,250,4096,2048,320,509,4248,113,16,138,41,64,2477,4313,4313,2477,204,249,256,168,4112,513]

theorem envBound30807 : H12AffineFastState.Bounded env30807 := by
  intro p hp
  have h : env30807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30806_30807 : H12AffineEnvironment.transform 9 320 env30806 = env30807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30806 == env30807) = true)

theorem identity30807 : scanCanonicalize (H12AffineFastState.compose env30807 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound30807 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env30808 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2492,161,2556,508,250,2492,2048,320,509,2340,113,16,138,41,64,2477,2405,2405,2477,204,249,256,168,2476,513]

theorem envBound30808 : H12AffineFastState.Bounded env30808 := by
  intro p hp
  have h : env30808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30807_30808 : H12AffineEnvironment.transform 11 2492 env30807 = env30808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env30807 == env30808) = true)

theorem identity30808 : scanCanonicalize (H12AffineFastState.compose env30808 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30808 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30809 : List Nat := [2,4,8,16,32,64,128,36,512,100,2048,2200,161,2264,216,250,2200,2048,100,217,2048,113,16,138,41,64,2185,2113,2113,2185,204,249,36,168,2184,513]

theorem envBound30809 : H12AffineFastState.Bounded env30809 := by
  intro p hp
  have h : env30809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30808_30809 : H12AffineEnvironment.transform 7 36 env30808 = env30809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30808 == env30809) = true)

theorem identity30809 : scanCanonicalize (H12AffineFastState.compose env30809 (packedSelected [4,6] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound30809 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env30810 : List Nat := [2,4,8,16,32,64,128,36,512,100,544,696,161,760,216,250,696,544,100,217,544,113,16,138,41,64,681,609,609,681,204,249,36,168,680,513]

theorem envBound30810 : H12AffineFastState.Bounded env30810 := by
  intro p hp
  have h : env30810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30809_30810 : H12AffineEnvironment.transform 10 544 env30809 = env30810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env30809 == env30810) = true)

theorem identity30810 : scanCanonicalize (H12AffineFastState.compose env30810 (packedSelected [3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30810 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env30811 : List Nat := [2,4,8,16,32,64,9,36,512,100,544,561,40,625,81,115,561,544,100,80,544,113,16,3,41,64,544,609,609,544,69,112,36,33,545,513]

theorem envBound30811 : H12AffineFastState.Bounded env30811 := by
  intro p hp
  have h : env30811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30810_30811 : H12AffineEnvironment.transform 6 9 env30810 = env30811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30810 == env30811) = true)

theorem identity30811 : scanCanonicalize (H12AffineFastState.compose env30811 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30811 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30812 : List Nat := [2,4,8,16,32,1,9,36,512,37,544,561,40,560,16,50,561,544,37,17,544,48,16,3,41,1,544,544,544,544,4,49,36,33,545,513]

theorem envBound30812 : H12AffineFastState.Bounded env30812 := by
  intro p hp
  have h : env30812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30811_30812 : H12AffineEnvironment.transform 5 1 env30811 = env30812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30811 == env30812) = true)

def env30813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101480,2175186,2175049,8328,64,2590066,46276,77954,2598354,99467,2101345,256,2199862,2172306,41821]

theorem envBound30813 : H12AffineFastState.Bounded env30813 := by
  intro p hp
  have h : env30813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30781_30813 : H12AffineEnvironment.transform 13 5377 env30781 = env30813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30781 == env30813) = true)

theorem identity30813 : scanCanonicalize (H12AffineFastState.compose env30813 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45341) := by decide +kernel

theorem selectedBound30813 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41461,98767,98644,8328,64,472175,46276,77954,464079,99467,41340,256,73771,103567,41821]

theorem envBound30814 : H12AffineFastState.Bounded env30814 := by
  intro p hp
  have h : env30814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30813_30814 : H12AffineEnvironment.transform 20 45341 env30813 = env30814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45341 env30813 == env30814) = true)

def env30815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41341,98631,98644,8192,64,472175,46156,77834,463943,99331,41340,256,73771,103431,41821]

theorem envBound30815 : H12AffineFastState.Bounded env30815 := by
  intro p hp
  have h : env30815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30814_30815 : H12AffineEnvironment.transform 6 8 env30814 = env30815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30814 == env30815) = true)

theorem identity30815 : scanCanonicalize (H12AffineFastState.compose env30815 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound30815 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79130,262144,1024,32769,45341,41341,98631,98644,8192,64,262517,46156,77834,270685,99331,41340,256,73771,103431,41821]

theorem envBound30816 : H12AffineFastState.Bounded env30816 := by
  intro p hp
  have h : env30816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30815_30816 : H12AffineEnvironment.transform 16 79130 env30815 = env30816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env30815 == env30816) = true)

theorem identity30816 : scanCanonicalize (H12AffineFastState.compose env30816 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30816 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env30817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79130,262144,1024,8541,4161,33,73755,73736,8192,64,262517,5392,77834,270685,75103,32,256,73771,79195,513]

theorem envBound30817 : H12AffineFastState.Bounded env30817 := by
  intro p hp
  have h : env30817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30816_30817 : H12AffineEnvironment.transform 14 8540 env30816 = env30817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30816 == env30817) = true)

theorem identity30817 : scanCanonicalize (H12AffineFastState.compose env30817 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound30817 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,79130,10508,1024,8541,4161,33,73755,73736,8192,64,10361,5392,77834,2129,75103,32,256,73771,79195,513]

theorem envBound30818 : H12AffineFastState.Bounded env30818 := by
  intro p hp
  have h : env30818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30817_30818 : H12AffineEnvironment.transform 17 10508 env30817 = env30818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env30817 == env30818) = true)

theorem identity30818 : scanCanonicalize (H12AffineFastState.compose env30818 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30818 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30819 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4113,8540,65536,77834,10508,272,8541,4161,33,73755,73736,8192,64,10361,4096,77834,2129,73807,32,256,73771,77899,513]

theorem envBound30819 : H12AffineFastState.Bounded env30819 := by
  intro p hp
  have h : env30819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30818_30819 : H12AffineEnvironment.transform 9 272 env30818 = env30819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30818 == env30819) = true)

theorem identity30819 : scanCanonicalize (H12AffineFastState.compose env30819 (packedSelected [2,5,6,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound30819 : packedSelected [2,5,6,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30820 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,513,8192,528,8540,65536,74251,10508,272,8541,576,33,73755,73736,8192,64,10361,513,74251,2129,73807,32,256,73771,74314,513]

theorem envBound30820 : H12AffineFastState.Bounded env30820 := by
  intro p hp
  have h : env30820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30819_30820 : H12AffineEnvironment.transform 11 513 env30819 = env30820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env30819 == env30820) = true)

theorem identity30820 : scanCanonicalize (H12AffineFastState.compose env30820 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound30820 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env30821 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,513,8192,528,8540,8494,805,10508,272,8541,576,33,309,294,8192,64,10361,513,805,2129,353,32,256,261,868,513]

theorem envBound30821 : H12AffineFastState.Bounded env30821 := by
  intro p hp
  have h : env30821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30820_30821 : H12AffineEnvironment.transform 15 8494 env30820 = env30821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env30820 == env30821) = true)

theorem identity30821 : scanCanonicalize (H12AffineFastState.compose env30821 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30821 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30822 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,513,269,528,81,35,805,2049,272,80,576,33,309,294,269,64,2420,513,805,2129,353,32,256,261,868,513]

theorem envBound30822 : H12AffineFastState.Bounded env30822 := by
  intro p hp
  have h : env30822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30821_30822 : H12AffineEnvironment.transform 12 269 env30821 = env30822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30821 == env30822) = true)

theorem identity30822 : scanCanonicalize (H12AffineFastState.compose env30822 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound30822 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30823 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,513,120,528,81,35,592,2049,101,80,576,33,64,83,120,64,2049,513,592,2129,20,32,117,112,529,513]

theorem envBound30823 : H12AffineFastState.Bounded env30823 := by
  intro p hp
  have h : env30823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30822_30823 : H12AffineEnvironment.transform 7 117 env30822 = env30823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env30822 == env30823) = true)

theorem identity30823 : scanCanonicalize (H12AffineFastState.compose env30823 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound30823 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30824 : List Nat := [2,4,8,16,32,64,8,117,512,101,26,513,120,528,81,35,592,27,101,80,576,33,64,83,120,64,27,513,592,75,20,32,117,112,529,513]

theorem envBound30824 : H12AffineFastState.Bounded env30824 := by
  intro p hp
  have h : env30824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30823_30824 : H12AffineEnvironment.transform 10 26 env30823 = env30824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env30823 == env30824) = true)

theorem identity30824 : scanCanonicalize (H12AffineFastState.compose env30824 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30824 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env30825 : List Nat := [2,4,8,16,32,17,8,36,512,52,26,513,41,528,0,35,513,27,52,1,529,33,17,2,41,17,27,513,513,26,20,32,36,33,529,513]

theorem envBound30825 : H12AffineFastState.Bounded env30825 := by
  intro p hp
  have h : env30825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30824_30825 : H12AffineEnvironment.transform 5 17 env30824 = env30825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30824 == env30825) = true)

theorem identity30825 : scanCanonicalize (H12AffineFastState.compose env30825 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound30825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30826 : List Nat := [2,4,8,16,32,17,8,36,27,52,26,26,41,11,0,35,26,27,52,1,10,33,17,2,41,17,27,26,26,26,20,32,36,33,10,26]

theorem envBound30826 : H12AffineFastState.Bounded env30826 := by
  intro p hp
  have h : env30826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30825_30826 : H12AffineEnvironment.transform 8 27 env30825 = env30826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env30825 == env30826) = true)

theorem identity30826 : scanCanonicalize (H12AffineFastState.compose env30826 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30826 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30827 : List Nat := [2,4,8,11,32,10,8,36,0,47,1,1,41,11,0,35,1,0,47,1,10,33,10,2,41,10,0,1,1,1,15,32,36,33,10,1]

theorem envBound30827 : H12AffineFastState.Bounded env30827 := by
  intro p hp
  have h : env30827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30826_30827 : H12AffineEnvironment.transform 3 11 env30826 = env30827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30826 == env30827) = true)

theorem identity30827 : scanCanonicalize (H12AffineFastState.compose env30827 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30827 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30828 : List Nat := [2,4,3,0,32,1,3,36,0,36,1,1,34,0,0,35,1,0,36,1,1,33,1,2,34,1,0,1,1,1,4,32,36,33,1,1]

theorem envBound30828 : H12AffineFastState.Bounded env30828 := by
  intro p hp
  have h : env30828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30827_30828 : H12AffineEnvironment.transform 2 3 env30827 = env30828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30827 == env30828) = true)

def env30829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,45341,41340,98630,98644,8193,64,472175,46157,77835,463942,99330,41340,256,73771,103430,41821]

theorem envBound30829 : H12AffineFastState.Bounded env30829 := by
  intro p hp
  have h : env30829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30814_30829 : H12AffineEnvironment.transform 6 9 env30814 = env30829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30814 == env30829) = true)

theorem identity30829 : scanCanonicalize (H12AffineFastState.compose env30829 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound30829 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103494,262144,1024,32769,45341,41340,98630,98644,8193,64,303145,46157,77835,294912,99330,41340,256,73771,103430,41821]

theorem envBound30830 : H12AffineFastState.Bounded env30830 := by
  intro p hp
  have h : env30830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30829_30830 : H12AffineEnvironment.transform 16 103494 env30829 = env30830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env30829 == env30830) = true)

theorem identity30830 : scanCanonicalize (H12AffineFastState.compose env30830 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound30830 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env30831 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,262144,1024,8541,4161,32,73754,73736,8193,64,262517,5393,77835,270684,75102,32,256,73771,79194,513]

theorem envBound30831 : H12AffineFastState.Bounded env30831 := by
  intro p hp
  have h : env30831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30830_30831 : H12AffineEnvironment.transform 14 8540 env30830 = env30831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env30830 == env30831) = true)

theorem identity30831 : scanCanonicalize (H12AffineFastState.compose env30831 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound30831 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30832 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,76079,1024,8541,4161,32,73754,73736,8193,64,75866,5393,77835,67699,75102,32,256,73771,79194,513]

theorem envBound30832 : H12AffineFastState.Bounded env30832 := by
  intro p hp
  have h : env30832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30831_30832 : H12AffineEnvironment.transform 17 76079 env30831 = env30832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env30831 == env30832) = true)

theorem identity30832 : scanCanonicalize (H12AffineFastState.compose env30832 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound30832 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env30833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5393,2340,1024,8541,4161,32,17,3,8193,64,2129,5393,4096,10360,1365,32,256,32,5457,513]

theorem envBound30833 : H12AffineFastState.Bounded env30833 := by
  intro p hp
  have h : env30833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30832_30833 : H12AffineEnvironment.transform 15 8203 env30832 = env30833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env30832 == env30833) = true)

theorem identity30833 : scanCanonicalize (H12AffineFastState.compose env30833 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound30833 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5393,2340,1024,1,4161,32,17,3,349,64,2129,5393,4096,2340,1365,32,256,32,5457,513]

theorem envBound30834 : H12AffineFastState.Bounded env30834 := by
  intro p hp
  have h : env30834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30833_30834 : H12AffineEnvironment.transform 12 348 env30833 = env30834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env30833 == env30834) = true)

theorem identity30834 : scanCanonicalize (H12AffineFastState.compose env30834 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound30834 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,309,348,1076,0,343,1060,2340,1024,1,372,32,17,3,349,64,2129,1060,309,2340,1365,32,256,32,1124,513]

theorem envBound30835 : H12AffineFastState.Bounded env30835 := by
  intro p hp
  have h : env30835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30834_30835 : H12AffineEnvironment.transform 11 309 env30834 = env30835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env30834 == env30835) = true)

theorem identity30835 : scanCanonicalize (H12AffineFastState.compose env30835 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30835 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,309,348,1076,0,343,1060,0,1024,1,372,32,17,3,349,64,373,1060,309,0,1365,32,256,32,1124,513]

theorem envBound30836 : H12AffineFastState.Bounded env30836 := by
  intro p hp
  have h : env30836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30835_30836 : H12AffineEnvironment.transform 10 292 env30835 = env30836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30835 == env30836) = true)

theorem identity30836 : scanCanonicalize (H12AffineFastState.compose env30836 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound30836 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30837 : List Nat := [2,4,8,16,32,64,9,256,512,100,292,309,348,80,0,343,64,0,100,1,372,32,17,3,349,64,373,64,309,0,305,32,256,32,0,513]

theorem envBound30837 : H12AffineFastState.Bounded env30837 := by
  intro p hp
  have h : env30837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30836_30837 : H12AffineEnvironment.transform 9 100 env30836 = env30837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env30836 == env30837) = true)

theorem identity30837 : scanCanonicalize (H12AffineFastState.compose env30837 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30837 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env30838 : List Nat := [2,4,8,16,32,16,9,256,512,52,292,309,268,0,0,263,16,0,52,1,292,32,17,3,269,16,293,16,309,0,305,32,256,32,0,513]

theorem envBound30838 : H12AffineFastState.Bounded env30838 := by
  intro p hp
  have h : env30838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30837_30838 : H12AffineEnvironment.transform 5 16 env30837 = env30838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30837 == env30838) = true)

theorem identity30838 : scanCanonicalize (H12AffineFastState.compose env30838 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30838 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30839 : List Nat := [2,4,8,16,32,16,9,5,512,52,33,48,9,0,0,2,16,0,52,1,33,32,17,3,8,16,32,16,48,0,52,32,5,32,0,513]

theorem envBound30839 : H12AffineFastState.Bounded env30839 := by
  intro p hp
  have h : env30839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30838_30839 : H12AffineEnvironment.transform 7 5 env30838 = env30839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30838 == env30839) = true)

theorem identity30839 : scanCanonicalize (H12AffineFastState.compose env30839 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30839 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30840 : List Nat := [2,4,8,16,0,16,9,5,512,20,1,16,9,0,0,2,16,0,20,1,1,0,17,3,8,16,0,16,16,0,20,0,5,0,0,513]

theorem envBound30840 : H12AffineFastState.Bounded env30840 := by
  intro p hp
  have h : env30840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30839_30840 : H12AffineEnvironment.transform 4 0 env30839 = env30840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30839 == env30840) = true)

theorem identity30840 : scanCanonicalize (H12AffineFastState.compose env30840 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30841 : List Nat := [2,4,8,16,0,16,9,5,0,20,1,16,9,0,0,2,16,0,20,1,1,0,17,3,8,16,0,16,16,0,20,0,5,0,0,1]

theorem envBound30841 : H12AffineFastState.Bounded env30841 := by
  intro p hp
  have h : env30841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30840_30841 : H12AffineEnvironment.transform 8 0 env30840 = env30841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30840 == env30841) = true)

theorem identity30841 : scanCanonicalize (H12AffineFastState.compose env30841 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30842 : List Nat := [2,4,8,10,0,10,9,5,0,14,1,10,9,0,0,2,10,0,14,1,1,0,11,3,8,10,0,10,10,0,14,0,5,0,0,1]

theorem envBound30842 : H12AffineFastState.Bounded env30842 := by
  intro p hp
  have h : env30842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30841_30842 : H12AffineEnvironment.transform 3 10 env30841 = env30842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30841 == env30842) = true)

theorem identity30842 : scanCanonicalize (H12AffineFastState.compose env30842 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30842 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30843 : List Nat := [2,4,3,1,0,1,2,5,0,5,1,1,2,0,0,2,1,0,5,1,1,0,0,3,3,1,0,1,1,0,5,0,5,0,0,1]

theorem envBound30843 : H12AffineFastState.Bounded env30843 := by
  intro p hp
  have h : env30843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30842_30843 : H12AffineEnvironment.transform 2 3 env30842 = env30843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30842 == env30843) = true)

def env30844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound30844 : H12AffineFastState.Bounded env30844 := by
  intro p hp
  have h : env30844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30627_30844 : H12AffineEnvironment.transform 18 1025 env30627 = env30844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env30627 == env30844) = true)

theorem identity30844 : scanCanonicalize (H12AffineFastState.compose env30844 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2262355) := by decide +kernel

theorem selectedBound30844 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env30845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,2262355,8328,64,15025490,197087,10507601,8830976,10682691,4448402,257,8602110,8626266,10626708]

theorem envBound30845 : H12AffineFastState.Bounded env30845 := by
  intro p hp
  have h : env30845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30844_30845 : H12AffineEnvironment.transform 23 2262355 env30844 = env30845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2262355 env30844 == env30845) = true)

def env30846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,8388608,2114883,8328,64,15025490,115151,10507601,8650768,10600787,4268162,257,8487406,8478794,10544772]

theorem envBound30846 : H12AffineFastState.Bounded env30846 := by
  intro p hp
  have h : env30846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30845_30846 : H12AffineEnvironment.transform 16 49168 env30845 = env30846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env30845 == env30846) = true)

def env30847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101328,2114883,8328,64,4543746,115151,17665,2363456,119043,4268162,257,2199998,2191386,63188]

theorem envBound30847 : H12AffineFastState.Bounded env30847 := by
  intro p hp
  have h : env30847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30846_30847 : H12AffineEnvironment.transform 22 2101328 env30846 = env30847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env30846 == env30847) = true)

def env30848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101328,2114883,8328,64,97666,115151,17665,2363456,119043,329730,257,2199998,2191386,63188]

theorem envBound30848 : H12AffineFastState.Bounded env30848 := by
  intro p hp
  have h : env30848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30847_30848 : H12AffineEnvironment.transform 21 272512 env30847 = env30848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30847 == env30848) = true)

theorem identity30848 : scanCanonicalize (H12AffineFastState.compose env30848 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound30848 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77899,272512,73755,95496,8328,64,97666,115151,17665,335883,119043,329730,257,41461,16465,63188]

theorem envBound30849 : H12AffineFastState.Bounded env30849 := by
  intro p hp
  have h : env30849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30848_30849 : H12AffineEnvironment.transform 20 77899 env30848 = env30849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env30848 == env30849) = true)

def env30850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10400,1025,32769,77899,32,73755,95496,8328,64,97666,115151,17665,67755,119043,73890,257,41461,16465,63188]

theorem envBound30850 : H12AffineFastState.Bounded env30850 := by
  intro p hp
  have h : env30850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30849_30850 : H12AffineEnvironment.transform 17 10400 env30849 = env30850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30849 == env30850) = true)

theorem identity30850 : scanCanonicalize (H12AffineFastState.compose env30850 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound30850 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env30851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,65536,38124,10400,1025,32769,77899,32,73755,74228,8328,64,76158,103731,4605,67755,99839,73890,257,41461,5293,41512]

theorem envBound30851 : H12AffineFastState.Bounded env30851 := by
  intro p hp
  have h : env30851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30850_30851 : H12AffineEnvironment.transform 13 5372 env30850 = env30851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env30850 == env30851) = true)

theorem identity30851 : scanCanonicalize (H12AffineFastState.compose env30851 (packedSelected [3,4,5,9,12,14,15,16,17,18,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound30851 : packedSelected [3,4,5,9,12,14,15,16,17,18,23,31] rootPS < 2^1333 := by decide +kernel

def env30852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8541,65536,13745,10400,1025,8540,77899,32,73755,74228,8328,64,76158,78958,4605,67755,74914,73890,257,168,5293,885]

theorem envBound30852 : H12AffineFastState.Bounded env30852 := by
  intro p hp
  have h : env30852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30851_30852 : H12AffineEnvironment.transform 14 8541 env30851 = env30852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env30851 == env30852) = true)

theorem identity30852 : scanCanonicalize (H12AffineFastState.compose env30852 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8695) := by decide +kernel

theorem selectedBound30852 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8541,8695,13745,10400,1025,8540,4540,32,492,3,8328,64,2185,5529,4605,10588,1365,341,257,168,5293,885]

theorem envBound30853 : H12AffineFastState.Bounded env30853 := by
  intro p hp
  have h : env30853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30852_30853 : H12AffineEnvironment.transform 15 8695 env30852 = env30853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8695 env30852 == env30853) = true)

theorem identity30853 : scanCanonicalize (H12AffineFastState.compose env30853 (packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30853 : packedSelected [0,2,3,5,6,7,10,11,12,15,18,20] rootPS < 2^1333 := by decide +kernel

def env30854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5372,293,399,5577,2264,1025,292,4540,32,492,3,240,64,2185,5529,4605,2340,1365,341,257,168,5293,885]

theorem envBound30854 : H12AffineFastState.Bounded env30854 := by
  intro p hp
  have h : env30854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30853_30854 : H12AffineEnvironment.transform 12 120 env30853 = env30854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30853 == env30854) = true)

def env30855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10401,1025,32769,77899,33,73755,95496,8328,64,97666,115151,17665,67754,119043,73891,257,41461,16465,63188]

theorem envBound30855 : H12AffineFastState.Bounded env30855 := by
  intro p hp
  have h : env30855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30849_30855 : H12AffineEnvironment.transform 17 10401 env30849 = env30855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30849 == env30855) = true)

theorem identity30855 : scanCanonicalize (H12AffineFastState.compose env30855 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound30855 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env30856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,30042,49168,10401,1025,32769,17681,33,21825,82,8328,64,2264,46229,17665,32240,42073,22009,257,41461,16465,63188]

theorem envBound30856 : H12AffineFastState.Bounded env30856 := by
  intro p hp
  have h : env30856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30855_30856 : H12AffineEnvironment.transform 15 30042 env30855 = env30856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env30855 == env30856) = true)

theorem identity30856 : scanCanonicalize (H12AffineFastState.compose env30856 (packedSelected [0,1,5,8,9,10,19,22,24,26,27,31] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30856 : packedSelected [0,1,5,8,9,10,19,22,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env30857 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,49168,10401,1025,32769,17681,33,21776,3,8328,17,2185,46229,17665,32161,41992,21928,257,41380,16384,63109]

theorem envBound30857 : H12AffineFastState.Bounded env30857 := by
  intro p hp
  have h : env30857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30856_30857 : H12AffineEnvironment.transform 5 17 env30856 = env30857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30856 == env30857) = true)

theorem identity30857 : scanCanonicalize (H12AffineFastState.compose env30857 (packedSelected [1,5,8,16,17,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound30857 : packedSelected [1,5,8,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,32768,399,46228,10401,1025,32769,12693,33,8596,3,8328,17,2185,46229,12677,2341,41992,8492,257,41380,13444,33281]

theorem envBound30858 : H12AffineFastState.Bounded env30858 := by
  intro p hp
  have h : env30858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30857_30858 : H12AffineEnvironment.transform 13 13444 env30857 = env30858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env30857 == env30858) = true)

theorem identity30858 : scanCanonicalize (H12AffineFastState.compose env30858 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound30858 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env30859 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,136,399,13340,10401,1025,137,12693,33,8596,3,8328,17,2185,13341,12677,2341,9344,8492,257,8492,13444,649]

theorem envBound30859 : H12AffineFastState.Bounded env30859 := by
  intro p hp
  have h : env30859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30858_30859 : H12AffineEnvironment.transform 14 136 env30858 = env30859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env30858 == env30859) = true)

def env30860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97667,115151,17665,2363456,119043,329731,257,2199998,2191386,63188]

theorem envBound30860 : H12AffineFastState.Bounded env30860 := by
  intro p hp
  have h : env30860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30847_30860 : H12AffineEnvironment.transform 21 272513 env30847 = env30860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30847 == env30860) = true)

theorem identity30860 : scanCanonicalize (H12AffineFastState.compose env30860 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30860 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,23945,57797,17665,2363456,61705,272393,257,2142644,2117648,63188]

theorem envBound30861 : H12AffineFastState.Bounded env30861 := by
  intro p hp
  have h : env30861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30860_30861 : H12AffineEnvironment.transform 15 8202 env30860 = env30861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30860 == env30861) = true)

def env30862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272393,2101328,2114883,8192,64,23809,57677,17665,2363456,61705,272393,257,2142524,2117648,63068]

theorem envBound30862 : H12AffineFastState.Bounded env30862 := by
  intro p hp
  have h : env30862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30861_30862 : H12AffineEnvironment.transform 6 8 env30861 = env30862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30861 == env30862) = true)

theorem identity30862 : scanCanonicalize (H12AffineFastState.compose env30862 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound30862 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env30863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,25628,272393,29772,8543,8192,64,23809,57677,17665,291932,61705,272393,257,54560,13324,63068]

theorem envBound30863 : H12AffineFastState.Bounded env30863 := by
  intro p hp
  have h : env30863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30862_30863 : H12AffineEnvironment.transform 20 25628 env30862 = env30863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env30862 == env30863) = true)

theorem identity30863 : scanCanonicalize (H12AffineFastState.compose env30863 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound30863 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env30864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1025,32769,25628,32,29772,8543,8192,64,23809,57677,17665,23669,61705,32,257,54560,13324,63068]

theorem envBound30864 : H12AffineFastState.Bounded env30864 := by
  intro p hp
  have h : env30864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30863_30864 : H12AffineEnvironment.transform 17 10281 env30863 = env30864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env30863 == env30864) = true)

theorem identity30864 : scanCanonicalize (H12AffineFastState.compose env30864 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound30864 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,13389,10281,1025,29788,25628,32,29772,8543,8192,64,23809,5392,17665,23669,1364,32,257,8573,13324,513]

theorem envBound30865 : H12AffineFastState.Bounded env30865 := by
  intro p hp
  have h : env30865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30864_30865 : H12AffineEnvironment.transform 14 29789 env30864 = env30865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env30864 == env30865) = true)

theorem identity30865 : scanCanonicalize (H12AffineFastState.compose env30865 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30865 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env30866 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8202,13340,10281,1025,29709,25628,32,29725,8462,8192,17,23809,5392,17665,23588,1285,32,257,8492,13324,513]

theorem envBound30866 : H12AffineFastState.Bounded env30866 := by
  intro p hp
  have h : env30866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30865_30866 : H12AffineEnvironment.transform 5 17 env30865 = env30866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30865 == env30866) = true)

theorem identity30866 : scanCanonicalize (H12AffineFastState.compose env30866 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30866 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env30867 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8202,13340,10281,1025,8460,12573,32,8476,8462,8192,17,2048,5392,4096,2341,1285,32,257,8492,13324,513]

theorem envBound30867 : H12AffineFastState.Bounded env30867 := by
  intro p hp
  have h : env30867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30866_30867 : H12AffineEnvironment.transform 13 5377 env30866 = env30867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30866 == env30867) = true)

def env30868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,2097152,272392,2101328,2114883,8193,64,23808,57676,17665,2363456,61705,272393,257,2142525,2117648,63069]

theorem envBound30868 : H12AffineFastState.Bounded env30868 := by
  intro p hp
  have h : env30868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30861_30868 : H12AffineEnvironment.transform 6 9 env30861 = env30868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30861 == env30868) = true)

theorem identity30868 : scanCanonicalize (H12AffineFastState.compose env30868 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound30868 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env30869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38161,262144,1025,32769,2097152,272392,2101328,2101314,8193,64,2049,46157,4096,2363456,41992,272393,257,2142525,2098449,41820]

theorem envBound30869 : H12AffineFastState.Bounded env30869 := by
  intro p hp
  have h : env30869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30868_30869 : H12AffineEnvironment.transform 13 5377 env30868 = env30869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env30868 == env30869) = true)

theorem identity30869 : scanCanonicalize (H12AffineFastState.compose env30869 (packedSelected [3,5,8,16,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound30869 : packedSelected [3,5,8,16,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env30870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,38161,35188,1025,32769,2097152,41340,2101328,2101314,8193,64,2049,46157,4096,2136372,41992,41341,257,2142525,2098449,41820]

theorem envBound30870 : H12AffineFastState.Bounded env30870 := by
  intro p hp
  have h : env30870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30869_30870 : H12AffineEnvironment.transform 17 35188 env30869 = env30870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env30869 == env30870) = true)

theorem identity30870 : scanCanonicalize (H12AffineFastState.compose env30870 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound30870 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env30871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7180,5377,32768,7174,38161,35188,1025,32769,2097152,40304,2101328,2101314,7181,64,2049,34881,4096,2136372,38916,40305,257,2133297,2098449,40784]

theorem envBound30871 : H12AffineFastState.Bounded env30871 := by
  intro p hp
  have h : env30871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30870_30871 : H12AffineEnvironment.transform 12 7180 env30870 = env30871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env30870 == env30871) = true)

theorem identity30871 : scanCanonicalize (H12AffineFastState.compose env30871 (packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound30871 : packedSelected [1,2,3,4,5,6,8,9,11,15,16,20] rootPS < 2^1333 := by decide +kernel

def env30872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,32768,342,34881,35188,1025,32769,2097152,32800,2100480,2100498,349,64,2049,34881,3408,2131044,34132,32801,257,2133297,2098449,33280]

theorem envBound30872 : H12AffineFastState.Bounded env30872 := by
  intro p hp
  have h : env30872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30871_30872 : H12AffineEnvironment.transform 11 3408 env30871 = env30872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env30871 == env30872) = true)

theorem identity30872 : scanCanonicalize (H12AffineFastState.compose env30872 (packedSelected [1,4,8,9,10,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound30872 : packedSelected [1,4,8,9,10,12,14,16] rootPS < 2^1333 := by decide +kernel

def env30873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,2421,342,308,1,1025,2420,2097152,2389,2100480,2100498,349,64,2049,308,3408,2100497,3105,2388,257,2098244,2098449,2933]

theorem envBound30873 : H12AffineFastState.Bounded env30873 := by
  intro p hp
  have h : env30873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30872_30873 : H12AffineEnvironment.transform 14 2421 env30872 = env30873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env30872 == env30873) = true)

theorem identity30873 : scanCanonicalize (H12AffineFastState.compose env30873 (packedSelected [0,4,6,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 2128) := by decide +kernel

theorem selectedBound30873 : packedSelected [0,4,6,14,15] rootPS < 2^1333 := by decide +kernel

def env30874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3408,348,2129,2421,342,308,1,1025,2420,2128,2389,1360,1346,349,64,2049,308,3408,1345,3105,2388,257,3092,3393,2933]

theorem envBound30874 : H12AffineFastState.Bounded env30874 := by
  intro p hp
  have h : env30874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30873_30874 : H12AffineEnvironment.transform 20 2128 env30873 = env30874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2128 env30873 == env30874) = true)

theorem identity30874 : scanCanonicalize (H12AffineFastState.compose env30874 (packedSelected [0,1,3,5,6,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30874 : packedSelected [0,1,3,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env30875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,356,348,1125,1345,342,308,1,1025,1344,1124,1377,1360,1346,349,64,1077,308,356,1345,21,1376,257,32,373,1857]

theorem envBound30875 : H12AffineFastState.Bounded env30875 := by
  intro p hp
  have h : env30875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30874_30875 : H12AffineEnvironment.transform 10 1076 env30874 = env30875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env30874 == env30875) = true)

theorem identity30875 : scanCanonicalize (H12AffineFastState.compose env30875 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30875 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30876 : List Nat := [2,4,8,16,32,64,9,256,512,320,372,356,348,293,1,342,308,1,321,0,292,33,16,2,349,64,373,308,356,1,21,32,257,32,373,513]

theorem envBound30876 : H12AffineFastState.Bounded env30876 := by
  intro p hp
  have h : env30876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30875_30876 : H12AffineEnvironment.transform 9 320 env30875 = env30876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30875 == env30876) = true)

theorem identity30876 : scanCanonicalize (H12AffineFastState.compose env30876 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30877 : List Nat := [2,4,8,0,32,64,9,256,512,320,356,356,332,293,1,326,292,1,321,0,292,33,0,2,333,64,357,292,356,1,5,32,257,32,357,513]

theorem envBound30877 : H12AffineFastState.Bounded env30877 := by
  intro p hp
  have h : env30877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30876_30877 : H12AffineEnvironment.transform 3 0 env30876 = env30877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30876 == env30877) = true)

theorem identity30877 : scanCanonicalize (H12AffineFastState.compose env30877 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound30877 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30878 : List Nat := [2,4,8,0,32,64,9,256,292,320,356,356,332,293,1,326,292,1,321,0,292,33,0,2,333,64,357,292,356,1,5,32,257,32,357,293]

theorem envBound30878 : H12AffineFastState.Bounded env30878 := by
  intro p hp
  have h : env30878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30877_30878 : H12AffineEnvironment.transform 8 292 env30877 = env30878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env30877 == env30878) = true)

theorem identity30878 : scanCanonicalize (H12AffineFastState.compose env30878 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30878 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30879 : List Nat := [2,4,8,0,32,1,9,256,292,257,293,293,269,293,1,263,292,1,256,0,292,33,0,2,268,1,292,292,293,1,5,32,257,32,292,293]

theorem envBound30879 : H12AffineFastState.Bounded env30879 := by
  intro p hp
  have h : env30879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30878_30879 : H12AffineEnvironment.transform 5 1 env30878 = env30879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30878 == env30879) = true)

theorem identity30879 : scanCanonicalize (H12AffineFastState.compose env30879 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30880 : List Nat := [2,4,8,0,0,1,9,256,260,257,261,261,269,261,1,263,260,1,256,0,260,1,0,2,268,1,260,260,261,1,5,0,257,0,260,261]

theorem envBound30880 : H12AffineFastState.Bounded env30880 := by
  intro p hp
  have h : env30880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30879_30880 : H12AffineEnvironment.transform 4 0 env30879 = env30880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30879 == env30880) = true)

theorem identity30880 : scanCanonicalize (H12AffineFastState.compose env30880 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30881 : List Nat := [2,4,8,0,0,1,9,5,1,4,0,0,8,0,1,2,1,1,5,0,1,1,0,2,9,1,1,1,0,1,5,0,4,0,1,0]

theorem envBound30881 : H12AffineFastState.Bounded env30881 := by
  intro p hp
  have h : env30881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30880_30881 : H12AffineEnvironment.transform 7 5 env30880 = env30881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30880 == env30881) = true)

def env30882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543747,115151,17664,2363457,119042,4268162,257,2199999,2191387,63189]

theorem envBound30882 : H12AffineFastState.Bounded env30882 := by
  intro p hp
  have h : env30882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30846_30882 : H12AffineEnvironment.transform 22 2101329 env30846 = env30882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env30846 == env30882) = true)

def env30883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97667,115151,17664,2363457,119042,329730,257,2199999,2191387,63189]

theorem envBound30883 : H12AffineFastState.Bounded env30883 := by
  intro p hp
  have h : env30883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30882_30883 : H12AffineEnvironment.transform 21 272512 env30882 = env30883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30882 == env30883) = true)

theorem identity30883 : scanCanonicalize (H12AffineFastState.compose env30883 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound30883 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115870,272512,120015,98781,8328,64,97667,115151,17664,382175,119042,329730,257,21793,46213,63189]

theorem envBound30884 : H12AffineFastState.Bounded env30884 := by
  intro p hp
  have h : env30884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30883_30884 : H12AffineEnvironment.transform 20 115870 env30883 = env30884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env30883 == env30884) = true)

def env30885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115734,272392,119879,98645,8192,64,97547,115015,17664,382039,119042,329730,257,21793,46093,63069]

theorem envBound30885 : H12AffineFastState.Bounded env30885 := by
  intro p hp
  have h : env30885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30884_30885 : H12AffineEnvironment.transform 6 8 env30884 = env30885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30884 == env30885) = true)

theorem identity30885 : scanCanonicalize (H12AffineFastState.compose env30885 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound30885 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env30886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5440,262144,1025,21841,69958,272392,65815,87045,8192,64,97547,70679,17664,327943,66642,329730,257,21793,24925,8973]

theorem envBound30886 : H12AffineFastState.Bounded env30886 := by
  intro p hp
  have h : env30886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30885_30886 : H12AffineEnvironment.transform 14 21840 env30885 = env30886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env30885 == env30886) = true)

theorem identity30886 : scanCanonicalize (H12AffineFastState.compose env30886 (packedSelected [17,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30886 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env30887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,65536,5440,262144,1025,0,69958,272392,65815,65876,8192,64,75866,70679,4177,327943,66642,329730,257,112,13324,8973]

theorem envBound30887 : H12AffineFastState.Bounded env30887 := by
  intro p hp
  have h : env30887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30886_30887 : H12AffineEnvironment.transform 13 5457 env30886 = env30887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30886 == env30887) = true)

theorem identity30887 : scanCanonicalize (H12AffineFastState.compose env30887 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound30887 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env30888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,342,5440,262144,1025,0,4112,272392,65,2,8192,64,10508,5441,4177,262225,1284,264532,257,112,13324,8973]

theorem envBound30888 : H12AffineFastState.Bounded env30888 := by
  intro p hp
  have h : env30888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30887_30888 : H12AffineEnvironment.transform 15 342 env30887 = env30888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env30887 == env30888) = true)

theorem identity30888 : scanCanonicalize (H12AffineFastState.compose env30888 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound30888 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env30889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,1,342,5440,2340,1025,0,4112,8492,65,2,8192,64,10508,5441,4177,2421,1284,112,257,112,13324,8973]

theorem envBound30889 : H12AffineFastState.Bounded env30889 := by
  intro p hp
  have h : env30889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30888_30889 : H12AffineEnvironment.transform 17 2340 env30888 = env30889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env30888 == env30889) = true)

theorem identity30889 : scanCanonicalize (H12AffineFastState.compose env30889 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound30889 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env30890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,8192,3344,1,342,3329,2340,1025,0,2129,8492,65,2,8192,64,10508,3328,2064,2421,1284,112,257,112,11341,8973]

theorem envBound30890 : H12AffineFastState.Bounded env30890 := by
  intro p hp
  have h : env30890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30889_30890 : H12AffineEnvironment.transform 11 2113 env30889 = env30890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env30889 == env30890) = true)

theorem identity30890 : scanCanonicalize (H12AffineFastState.compose env30890 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound30890 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env30891 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2113,8192,2048,1,342,2065,2340,273,0,2129,8492,65,2,8192,64,10508,2064,2064,2421,20,112,257,112,10589,8973]

theorem envBound30891 : H12AffineFastState.Bounded env30891 := by
  intro p hp
  have h : env30891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30890_30891 : H12AffineEnvironment.transform 9 272 env30890 = env30891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30890 == env30891) = true)

theorem identity30891 : scanCanonicalize (H12AffineFastState.compose env30891 (packedSelected [2,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound30891 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env30892 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2113,2317,2048,1,342,2065,2340,273,0,2129,2081,65,2,2317,64,1,2064,2064,2421,20,112,257,112,80,2560]

theorem envBound30892 : H12AffineFastState.Bounded env30892 := by
  intro p hp
  have h : env30892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30891_30892 : H12AffineEnvironment.transform 12 2317 env30891 = env30892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env30891 == env30892) = true)

theorem identity30892 : scanCanonicalize (H12AffineFastState.compose env30892 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30892 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env30893 : List Nat := [2,4,8,16,16,64,8,256,512,272,2048,2113,2317,2048,1,342,2065,2324,273,0,2129,2065,65,2,2317,64,1,2064,2064,2373,20,64,257,64,80,2560]

theorem envBound30893 : H12AffineFastState.Bounded env30893 := by
  intro p hp
  have h : env30893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30892_30893 : H12AffineEnvironment.transform 4 16 env30892 = env30893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30892 == env30893) = true)

theorem identity30893 : scanCanonicalize (H12AffineFastState.compose env30893 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound30893 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30894 : List Nat := [2,4,8,16,16,64,8,85,512,69,2048,2113,2136,2048,1,3,2065,2113,68,0,2129,2065,65,2,2136,64,1,2064,2064,2064,20,64,84,64,80,2560]

theorem envBound30894 : H12AffineFastState.Bounded env30894 := by
  intro p hp
  have h : env30894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30893_30894 : H12AffineEnvironment.transform 7 85 env30893 = env30894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env30893 == env30894) = true)

theorem identity30894 : scanCanonicalize (H12AffineFastState.compose env30894 (packedSelected [0,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30894 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env30895 : List Nat := [2,4,8,16,16,16,8,5,512,21,2048,2065,2056,2048,1,3,2065,2065,20,0,2049,2065,17,2,2056,16,1,2064,2064,2064,20,16,4,16,0,2560]

theorem envBound30895 : H12AffineFastState.Bounded env30895 := by
  intro p hp
  have h : env30895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30894_30895 : H12AffineEnvironment.transform 5 16 env30894 = env30895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30894 == env30895) = true)

theorem identity30895 : scanCanonicalize (H12AffineFastState.compose env30895 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30895 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env30896 : List Nat := [2,4,8,16,16,16,8,5,17,21,2048,2065,2056,2048,1,3,2065,2065,20,0,2049,2065,17,2,2056,16,1,2064,2064,2064,20,16,4,16,0,2065]

theorem envBound30896 : H12AffineFastState.Bounded env30896 := by
  intro p hp
  have h : env30896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30895_30896 : H12AffineEnvironment.transform 8 17 env30895 = env30896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30895 == env30896) = true)

theorem identity30896 : scanCanonicalize (H12AffineFastState.compose env30896 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30897 : List Nat := [2,4,8,0,0,0,8,5,1,5,2048,2049,2056,2048,1,3,2049,2049,4,0,2049,2049,1,2,2056,0,1,2048,2048,2048,4,0,4,0,0,2049]

theorem envBound30897 : H12AffineFastState.Bounded env30897 := by
  intro p hp
  have h : env30897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30896_30897 : H12AffineEnvironment.transform 3 0 env30896 = env30897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30896 == env30897) = true)

def env30898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,115735,272393,119878,98644,8193,64,97546,115014,17664,382038,119042,329730,257,21793,46092,63068]

theorem envBound30898 : H12AffineFastState.Bounded env30898 := by
  intro p hp
  have h : env30898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30884_30898 : H12AffineEnvironment.transform 6 9 env30884 = env30898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30884 == env30898) = true)

theorem identity30898 : scanCanonicalize (H12AffineFastState.compose env30898 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound30898 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env30899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,49168,262144,1025,32769,50276,272393,54325,33063,8193,64,32121,49461,17664,316453,53617,264305,257,21793,46092,63068]

theorem envBound30899 : H12AffineFastState.Bounded env30899 := by
  intro p hp
  have h : env30899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30898_30899 : H12AffineEnvironment.transform 15 115 env30898 = env30899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env30898 == env30899) = true)

theorem identity30899 : scanCanonicalize (H12AffineFastState.compose env30899 (packedSelected [2,3,4,6,7,8,11,12,15,18,22,24,26,27,28,35] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound30899 : packedSelected [2,3,4,6,7,8,11,12,15,18,22,24,26,27,28,35] rootPS < 2^1333 := by decide +kernel

def env30900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8312,115,24680,262144,1025,8313,25628,272393,29773,8543,8193,64,32121,24909,17664,291933,28937,264305,257,21793,5236,22052]

theorem envBound30900 : H12AffineFastState.Bounded env30900 := by
  intro p hp
  have h : env30900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30899_30900 : H12AffineEnvironment.transform 14 8312 env30899 = env30900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env30899 == env30900) = true)

theorem identity30900 : scanCanonicalize (H12AffineFastState.compose env30900 (packedSelected [1,4,5,8,9,14,17,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound30900 : packedSelected [1,4,5,8,9,14,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,0,115,16400,262144,1025,1,17508,264305,21557,295,121,64,23809,16693,17664,283685,20849,264305,257,21793,5236,22052]

theorem envBound30901 : H12AffineFastState.Bounded env30901 := by
  intro p hp
  have h : env30901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30900_30901 : H12AffineEnvironment.transform 12 120 env30900 = env30901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env30900 == env30901) = true)

theorem identity30901 : scanCanonicalize (H12AffineFastState.compose env30901 (packedSelected [16,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound30901 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env30902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,0,115,16400,2129,1025,1,17508,32,21557,295,121,64,23809,16693,17664,23668,20849,32,257,21793,5236,22052]

theorem envBound30902 : H12AffineFastState.Bounded env30902 := by
  intro p hp
  have h : env30902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30901_30902 : H12AffineEnvironment.transform 17 2129 env30901 = env30902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env30901 == env30902) = true)

theorem identity30902 : scanCanonicalize (H12AffineFastState.compose env30902 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound30902 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,0,115,5392,2129,1025,1,4452,32,309,295,121,64,2049,5173,4096,2420,1137,32,257,33,5236,804]

theorem envBound30903 : H12AffineFastState.Bounded env30903 := by
  intro p hp
  have h : env30903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30902_30903 : H12AffineEnvironment.transform 13 5376 env30902 = env30903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30902 == env30903) = true)

theorem identity30903 : scanCanonicalize (H12AffineFastState.compose env30903 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30903 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env30904 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,41,5376,0,34,5392,2048,1025,1,4405,32,309,295,40,17,2049,5173,4096,2341,1056,32,257,33,5157,804]

theorem envBound30904 : H12AffineFastState.Bounded env30904 := by
  intro p hp
  have h : env30904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30903_30904 : H12AffineEnvironment.transform 5 17 env30903 = env30904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30903 == env30904) = true)

theorem identity30904 : scanCanonicalize (H12AffineFastState.compose env30904 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30904 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env30905 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,34,5172,2048,1025,1,4113,32,17,3,40,17,2049,5173,4096,2049,1056,32,37,33,5157,512]

theorem envBound30905 : H12AffineFastState.Bounded env30905 := by
  intro p hp
  have h : env30905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30904_30905 : H12AffineEnvironment.transform 7 36 env30904 = env30905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30904 == env30905) = true)

theorem identity30905 : scanCanonicalize (H12AffineFastState.compose env30905 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30906 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,0,2,5140,2048,1025,1,4113,0,17,3,8,17,2049,5141,4096,2049,1024,0,5,1,5125,512]

theorem envBound30906 : H12AffineFastState.Bounded env30906 := by
  intro p hp
  have h : env30906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30905_30906 : H12AffineEnvironment.transform 4 0 env30905 = env30906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30905 == env30906) = true)

theorem identity30906 : scanCanonicalize (H12AffineFastState.compose env30906 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound30906 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30907 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,9,5124,0,2,5140,523,1025,1,4113,0,17,3,8,17,522,5141,4096,522,1024,0,5,1,5125,512]

theorem envBound30907 : H12AffineFastState.Bounded env30907 := by
  intro p hp
  have h : env30907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30906_30907 : H12AffineEnvironment.transform 10 523 env30906 = env30907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env30906 == env30907) = true)

def env30908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97666,115151,17664,2363457,119042,329731,257,2199999,2191387,63189]

theorem envBound30908 : H12AffineFastState.Bounded env30908 := by
  intro p hp
  have h : env30908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30882_30908 : H12AffineEnvironment.transform 21 272513 env30882 = env30908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env30882 == env30908) = true)

theorem identity30908 : scanCanonicalize (H12AffineFastState.compose env30908 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound30908 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49168,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,43356,5393,17664,2363457,1500,318685,257,2114913,2139333,63189]

theorem envBound30909 : H12AffineFastState.Bounded env30909 := by
  intro p hp
  have h : env30909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30908_30909 : H12AffineEnvironment.transform 15 54494 env30908 = env30909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env30908 == env30909) = true)

theorem identity30909 : scanCanonicalize (H12AffineFastState.compose env30909 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30909 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env30910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13508,262144,1025,29909,2097152,272513,2101329,2114883,8328,64,23944,5393,17664,2363457,1500,272393,257,2114913,2117649,513]

theorem envBound30910 : H12AffineFastState.Bounded env30910 := by
  intro p hp
  have h : env30910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30909_30910 : H12AffineEnvironment.transform 14 29908 env30909 = env30910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30909 == env30910) = true)

theorem identity30910 : scanCanonicalize (H12AffineFastState.compose env30910 (packedSelected [16,20] rootPS)) = affineNative (2^(20+1) ^^^ 281653) := by decide +kernel

theorem selectedBound30910 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13508,262144,1025,29909,281653,272513,285796,264566,8328,64,23944,5393,17664,23668,1500,272393,257,264532,269348,513]

theorem envBound30911 : H12AffineFastState.Bounded env30911 := by
  intro p hp
  have h : env30911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30910_30911 : H12AffineEnvironment.transform 20 281653 env30910 = env30911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281653 env30910 == env30911) = true)

theorem identity30911 : scanCanonicalize (H12AffineFastState.compose env30911 (packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 32240) := by decide +kernel

theorem selectedBound30911 : packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS < 2^1333 := by decide +kernel

def env30912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,13508,32240,1025,29909,12741,21873,8596,29830,8328,64,23944,5393,17664,23668,1500,22009,257,29860,25044,513]

theorem envBound30912 : H12AffineFastState.Bounded env30912 := by
  intro p hp
  have h : env30912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30911_30912 : H12AffineEnvironment.transform 17 32240 env30911 = env30912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env30911 == env30912) = true)

theorem identity30912 : scanCanonicalize (H12AffineFastState.compose env30912 (packedSelected [2,3,4,6,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound30912 : packedSelected [2,3,4,6,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,8202,13508,10401,1025,8580,12741,32,8596,8663,8328,64,2265,5393,4177,2341,1500,168,257,8693,13445,513]

theorem envBound30913 : H12AffineFastState.Bounded env30913 := by
  intro p hp
  have h : env30913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30912_30913 : H12AffineEnvironment.transform 13 5457 env30912 = env30913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env30912 == env30913) = true)

theorem identity30913 : scanCanonicalize (H12AffineFastState.compose env30913 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30913 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env30914 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8460,8202,13389,10280,1025,8461,12620,32,8477,8542,8193,64,2128,5393,4177,2341,1365,33,257,8572,13324,513]

theorem envBound30914 : H12AffineFastState.Bounded env30914 := by
  intro p hp
  have h : env30914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30913_30914 : H12AffineEnvironment.transform 6 9 env30913 = env30914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30913 == env30914) = true)

theorem identity30914 : scanCanonicalize (H12AffineFastState.compose env30914 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound30914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,1,263,5440,2341,1025,0,4161,32,16,83,268,64,2128,5393,4177,2341,1365,33,257,113,5377,513]

theorem envBound30915 : H12AffineFastState.Bounded env30915 := by
  intro p hp
  have h : env30915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30914_30915 : H12AffineEnvironment.transform 12 269 env30914 = env30915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env30914 == env30915) = true)

theorem identity30915 : scanCanonicalize (H12AffineFastState.compose env30915 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound30915 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env30916 : List Nat := [2,4,8,16,32,64,9,256,512,612,2048,4096,269,4917,1,263,4900,2341,613,0,4161,32,16,83,268,64,2128,4981,4177,2341,817,33,257,113,4965,513]

theorem envBound30916 : H12AffineFastState.Bounded env30916 := by
  intro p hp
  have h : env30916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30915_30916 : H12AffineEnvironment.transform 9 612 env30915 = env30916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env30915 == env30916) = true)

theorem identity30916 : scanCanonicalize (H12AffineFastState.compose env30916 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2624) := by decide +kernel

theorem selectedBound30916 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env30917 : List Nat := [2,4,8,16,32,64,9,256,512,612,2048,2624,269,2421,1,263,2404,2341,613,0,2561,32,16,83,268,64,2128,2357,2577,2341,817,33,257,113,2341,513]

theorem envBound30917 : H12AffineFastState.Bounded env30917 := by
  intro p hp
  have h : env30917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30916_30917 : H12AffineEnvironment.transform 11 2624 env30916 = env30917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2624 env30916 == env30917) = true)

theorem identity30917 : scanCanonicalize (H12AffineFastState.compose env30917 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound30917 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30918 : List Nat := [2,4,8,16,32,64,9,256,512,612,592,16,269,805,1,263,820,885,613,0,81,32,16,83,268,64,512,869,65,885,817,33,257,113,885,513]

theorem envBound30918 : H12AffineFastState.Bounded env30918 := by
  intro p hp
  have h : env30918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30917_30918 : H12AffineEnvironment.transform 10 592 env30917 = env30918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env30917 == env30918) = true)

theorem identity30918 : scanCanonicalize (H12AffineFastState.compose env30918 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound30918 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30919 : List Nat := [2,4,8,16,32,64,9,256,64,36,16,16,269,357,1,263,372,309,37,0,81,32,16,83,268,64,64,293,65,309,369,33,257,113,309,65]

theorem envBound30919 : H12AffineFastState.Bounded env30919 := by
  intro p hp
  have h : env30919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30918_30919 : H12AffineEnvironment.transform 8 64 env30918 = env30919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env30918 == env30919) = true)

theorem identity30919 : scanCanonicalize (H12AffineFastState.compose env30919 (packedSelected [0,2,9] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound30919 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env30920 : List Nat := [2,4,8,16,32,64,9,101,64,36,16,16,104,0,1,98,17,80,37,0,81,32,16,83,105,64,64,64,65,80,20,33,100,113,80,65]

theorem envBound30920 : H12AffineFastState.Bounded env30920 := by
  intro p hp
  have h : env30920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30919_30920 : H12AffineEnvironment.transform 7 101 env30919 = env30920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env30919 == env30920) = true)

theorem identity30920 : scanCanonicalize (H12AffineFastState.compose env30920 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30920 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30921 : List Nat := [2,4,8,16,16,64,9,85,64,20,16,16,88,0,1,82,17,80,21,0,81,16,16,83,89,64,64,64,65,80,20,17,84,65,80,65]

theorem envBound30921 : H12AffineFastState.Bounded env30921 := by
  intro p hp
  have h : env30921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30920_30921 : H12AffineEnvironment.transform 4 16 env30920 = env30921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30920 == env30921) = true)

theorem identity30921 : scanCanonicalize (H12AffineFastState.compose env30921 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30922 : List Nat := [2,4,8,1,1,64,9,68,64,5,1,1,73,0,1,67,0,65,4,0,64,1,1,66,72,64,64,64,65,65,5,0,69,65,65,65]

theorem envBound30922 : H12AffineFastState.Bounded env30922 := by
  intro p hp
  have h : env30922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30921_30922 : H12AffineEnvironment.transform 3 1 env30921 = env30922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30921 == env30922) = true)

def env30923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025490,115150,10507601,8650769,10600786,4268163,257,8487407,8478795,10544773]

theorem envBound30923 : H12AffineFastState.Bounded env30923 := by
  intro p hp
  have h : env30923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30845_30923 : H12AffineEnvironment.transform 16 49169 env30845 = env30923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env30845 == env30923) = true)

def env30924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543746,115150,17665,2363457,119042,4268163,257,2199999,2191387,63189]

theorem envBound30924 : H12AffineFastState.Bounded env30924 := by
  intro p hp
  have h : env30924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30923_30924 : H12AffineEnvironment.transform 22 2101328 env30923 = env30924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env30923 == env30924) = true)

def env30925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97666,115150,17665,2363457,119042,329731,257,2199999,2191387,63189]

theorem envBound30925 : H12AffineFastState.Bounded env30925 := by
  intro p hp
  have h : env30925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30924_30925 : H12AffineEnvironment.transform 21 272512 env30924 = env30925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env30924 == env30925) = true)

theorem identity30925 : scanCanonicalize (H12AffineFastState.compose env30925 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound30925 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env30926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,262144,1025,29909,2097152,272512,2101328,2114882,8328,64,97666,79130,17665,2363457,75222,329731,257,2188651,2191387,513]

theorem envBound30926 : H12AffineFastState.Bounded env30926 := by
  intro p hp
  have h : env30926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30925_30926 : H12AffineEnvironment.transform 14 29908 env30925 = env30926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env30925 == env30926) = true)

def env30927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10400,1025,29909,2097152,32,2101328,2114882,8328,64,97666,79130,17665,2111713,75222,73891,257,2188651,2191387,513]

theorem envBound30927 : H12AffineFastState.Bounded env30927 := by
  intro p hp
  have h : env30927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30926_30927 : H12AffineEnvironment.transform 17 10400 env30926 = env30927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env30926 == env30927) = true)

theorem identity30927 : scanCanonicalize (H12AffineFastState.compose env30927 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound30927 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env30928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21726,13509,10400,1025,29909,2097152,32,2101328,2114882,8328,64,10588,25028,17665,2111713,28936,29821,257,2109877,2106565,513]

theorem envBound30928 : H12AffineFastState.Bounded env30928 := by
  intro p hp
  have h : env30928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30927_30928 : H12AffineEnvironment.transform 15 21726 env30927 = env30928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env30927 == env30928) = true)

theorem identity30928 : scanCanonicalize (H12AffineFastState.compose env30928 (packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 4588) := by decide +kernel

theorem selectedBound30928 : packedSelected [0,4,8,9,10,12,15,17,18,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env30929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,21726,13509,10400,1025,29909,4588,32,444,21678,8328,64,10588,25028,17665,10509,28936,29821,257,8281,13609,513]

theorem envBound30929 : H12AffineFastState.Bounded env30929 := by
  intro p hp
  have h : env30929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30928_30929 : H12AffineEnvironment.transform 20 4588 env30928 = env30929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4588 env30928 == env30929) = true)

theorem identity30929 : scanCanonicalize (H12AffineFastState.compose env30929 (packedSelected [0,1,5,8,11,14,17,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30929 : packedSelected [0,1,5,8,11,14,17,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30930 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,21511,13340,10361,1025,29708,4405,32,357,21623,8273,64,10588,24861,17665,10509,28936,29821,257,8281,13609,513]

theorem envBound30930 : H12AffineFastState.Bounded env30930 := by
  intro p hp
  have h : env30930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30929_30930 : H12AffineEnvironment.transform 6 89 env30929 = env30930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30929 == env30930) = true)

theorem identity30930 : scanCanonicalize (H12AffineFastState.compose env30930 (packedSelected [0,1,2,3,5,6,7,8,11,12,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound30930 : packedSelected [0,1,2,3,5,6,7,8,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env30931 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2357,8192,16384,27960,19762,11561,10361,1025,27961,2048,32,357,19778,8273,64,10588,24861,17665,10509,26685,27976,257,8281,11292,513]

theorem envBound30931 : H12AffineFastState.Bounded env30931 := by
  intro p hp
  have h : env30931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30930_30931 : H12AffineEnvironment.transform 11 2357 env30930 = env30931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env30930 == env30931) = true)

theorem identity30931 : scanCanonicalize (H12AffineFastState.compose env30931 (packedSelected [4,9,18] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound30931 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env30932 : List Nat := [2,4,8,16,32,64,89,256,512,1024,292,17,8192,16384,25628,17430,9229,8541,1025,25629,292,32,357,17510,8273,64,8312,24861,17665,8233,24857,25708,257,8281,9528,513]

theorem envBound30932 : H12AffineFastState.Bounded env30932 := by
  intro p hp
  have h : env30932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30931_30932 : H12AffineEnvironment.transform 10 292 env30931 = env30932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env30931 == env30932) = true)

theorem identity30932 : scanCanonicalize (H12AffineFastState.compose env30932 (packedSelected [0,1,3,4,5,7,8,9,11,12,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound30932 : packedSelected [0,1,3,4,5,7,8,9,11,12,20] rootPS < 2^1333 := by decide +kernel

def env30933 : List Nat := [2,4,8,16,32,64,89,36,512,1024,0,17,8192,16384,25628,17430,9229,8313,1025,25629,0,32,65,17510,8273,64,8312,24633,17445,8233,24637,25708,37,8281,9244,513]

theorem envBound30933 : H12AffineFastState.Bounded env30933 := by
  intro p hp
  have h : env30933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30932_30933 : H12AffineEnvironment.transform 7 36 env30932 = env30933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env30932 == env30933) = true)

theorem identity30933 : scanCanonicalize (H12AffineFastState.compose env30933 (packedSelected [2,3,4,5,6,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound30933 : packedSelected [2,3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env30934 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,17,8192,16384,25628,17430,9229,8232,1025,25629,0,32,16,17463,8192,17,8233,24633,17445,8233,24637,25661,37,8200,9244,513]

theorem envBound30934 : H12AffineFastState.Bounded env30934 := by
  intro p hp
  have h : env30934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30933_30934 : H12AffineEnvironment.transform 5 17 env30933 = env30934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30933 == env30934) = true)

theorem identity30934 : scanCanonicalize (H12AffineFastState.compose env30934 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound30934 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env30935 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,8192,16384,24617,16419,8248,8232,52,24616,0,32,16,16386,8192,17,8233,24633,16400,8233,24637,24584,37,8200,8233,513]

theorem envBound30935 : H12AffineFastState.Bounded env30935 := by
  intro p hp
  have h : env30935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30934_30935 : H12AffineEnvironment.transform 9 53 env30934 = env30935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env30934 == env30935) = true)

theorem identity30935 : scanCanonicalize (H12AffineFastState.compose env30935 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound30935 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env30936 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,17,8192,1,8232,34,8248,8232,52,8233,0,32,16,3,8192,17,8233,8248,17,8233,8252,8201,37,8200,8233,513]

theorem envBound30936 : H12AffineFastState.Bounded env30936 := by
  intro p hp
  have h : env30936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30935_30936 : H12AffineEnvironment.transform 13 1 env30935 = env30936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env30935 == env30936) = true)

theorem identity30936 : scanCanonicalize (H12AffineFastState.compose env30936 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30936 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30937 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,17,8192,1,8232,34,8248,8232,52,8233,0,32,16,3,8192,17,8233,8248,17,8233,8252,8201,37,8200,8233,0]

theorem envBound30937 : H12AffineFastState.Bounded env30937 := by
  intro p hp
  have h : env30937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30936_30937 : H12AffineEnvironment.transform 8 1 env30936 = env30937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30936 == env30937) = true)

theorem identity30937 : scanCanonicalize (H12AffineFastState.compose env30937 (packedSelected [0,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30937 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env30938 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,17,41,1,1,34,17,1,52,0,0,32,16,3,41,17,0,17,17,0,21,32,37,33,0,0]

theorem envBound30938 : H12AffineFastState.Bounded env30938 := by
  intro p hp
  have h : env30938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30937_30938 : H12AffineEnvironment.transform 12 41 env30937 = env30938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30937 == env30938) = true)

theorem identity30938 : scanCanonicalize (H12AffineFastState.compose env30938 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30939 : List Nat := [2,4,8,16,11,17,8,15,1,30,0,17,2,1,1,9,17,1,31,0,0,11,16,3,2,17,0,17,17,0,21,11,14,10,0,0]

theorem envBound30939 : H12AffineFastState.Bounded env30939 := by
  intro p hp
  have h : env30939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30938_30939 : H12AffineEnvironment.transform 4 11 env30938 = env30939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30938 == env30939) = true)

def env30940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13509,10401,1025,29909,2097152,33,2101328,2114882,8328,64,97666,79130,17665,2111712,75222,73890,257,2188651,2191387,513]

theorem envBound30940 : H12AffineFastState.Bounded env30940 := by
  intro p hp
  have h : env30940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30926_30940 : H12AffineEnvironment.transform 17 10401 env30926 = env30940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env30926 == env30940) = true)

def env30941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13509,10401,1025,8661,2097152,33,2101328,2101314,8328,64,75906,79130,4097,2111712,75222,73890,257,2175083,2172187,513]

theorem envBound30941 : H12AffineFastState.Bounded env30941 := by
  intro p hp
  have h : env30941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30940_30941 : H12AffineEnvironment.transform 13 5376 env30940 = env30941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env30940 == env30941) = true)

theorem identity30941 : scanCanonicalize (H12AffineFastState.compose env30941 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30941 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env30942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1025,8541,2097152,33,2101328,2101314,8192,64,75786,79130,4097,2111592,75102,73770,257,2175083,2172187,513]

theorem envBound30942 : H12AffineFastState.Bounded env30942 := by
  intro p hp
  have h : env30942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30941_30942 : H12AffineEnvironment.transform 6 8 env30941 = env30942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30941 == env30942) = true)

theorem identity30942 : scanCanonicalize (H12AffineFastState.compose env30942 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 12573) := by decide +kernel

theorem selectedBound30942 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env30943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,65536,13389,10281,1025,8541,12573,33,8525,8543,8192,64,75786,79130,4097,2421,75102,73770,257,65910,70662,513]

theorem envBound30943 : H12AffineFastState.Bounded env30943 := by
  intro p hp
  have h : env30943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30942_30943 : H12AffineEnvironment.transform 20 12573 env30942 = env30943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12573 env30942 == env30943) = true)

theorem identity30943 : scanCanonicalize (H12AffineFastState.compose env30943 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound30943 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,13389,10281,1025,8541,12573,33,8525,8543,8192,64,2048,5392,4097,2421,1364,32,257,8572,13324,513]

theorem envBound30944 : H12AffineFastState.Bounded env30944 := by
  intro p hp
  have h : env30944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30943_30944 : H12AffineEnvironment.transform 15 8202 env30943 = env30944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env30943 == env30944) = true)

theorem identity30944 : scanCanonicalize (H12AffineFastState.compose env30944 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30944 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env30945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,262,5441,2341,1025,81,4113,33,65,83,268,64,2048,5392,4097,2421,1364,32,257,112,5376,513]

theorem envBound30945 : H12AffineFastState.Bounded env30945 := by
  intro p hp
  have h : env30945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30944_30945 : H12AffineEnvironment.transform 12 268 env30944 = env30945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30944 == env30945) = true)

theorem identity30945 : scanCanonicalize (H12AffineFastState.compose env30945 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound30945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env30946 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5393,2341,1025,1,4113,33,17,3,268,16,2048,5392,4097,2341,1284,32,257,32,5376,513]

theorem envBound30946 : H12AffineFastState.Bounded env30946 := by
  intro p hp
  have h : env30946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1