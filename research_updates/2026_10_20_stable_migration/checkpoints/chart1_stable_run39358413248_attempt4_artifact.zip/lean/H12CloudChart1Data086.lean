import H12CloudChart1Data085

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans21753_21762 : H12AffineEnvironment.transform 6 89 env21753 = env21762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21753 == env21762) = true)

theorem identity21762 : scanCanonicalize (H12AffineFastState.compose env21762 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound21762 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env21763 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,40970,131072,149861,1024,32769,4161,136496,32784,21763,8273,65,190796,24860,50432,2421,61704,169313,256,41260,16464,30220]

theorem envBound21763 : H12AffineFastState.Bounded env21763 := by
  intro p hp
  have h : env21763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21762_21763 : H12AffineEnvironment.transform 15 40970 env21762 = env21763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env21762 == env21763) = true)

theorem identity21763 : scanCanonicalize (H12AffineFastState.compose env21763 (packedSelected [4,7,9,14,16,18,20,23,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21763 : packedSelected [4,7,9,14,16,18,20,23,27,35] rootPS < 2^1333 := by decide +kernel

def env21764 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,33031,131072,149861,1024,32769,4161,136496,32784,21763,348,65,182337,16401,50432,2421,53253,169313,256,32801,16464,22273]

theorem envBound21764 : H12AffineFastState.Bounded env21764 := by
  intro p hp
  have h : env21764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21763_21764 : H12AffineEnvironment.transform 12 269 env21763 = env21764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21763 == env21764) = true)

theorem identity21764 : scanCanonicalize (H12AffineFastState.compose env21764 (packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound21764 : packedSelected [1,3,4,5,7,8,9,10,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env21765 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21760,21511,131072,149861,1024,21761,4161,136496,21776,21763,348,65,138561,16401,4096,2421,1285,147553,256,21793,16464,22273]

theorem envBound21765 : H12AffineFastState.Bounded env21765 := by
  intro p hp
  have h : env21765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21764_21765 : H12AffineEnvironment.transform 14 21760 env21764 = env21765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env21764 == env21765) = true)

theorem identity21765 : scanCanonicalize (H12AffineFastState.compose env21765 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound21765 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env21766 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21760,21511,5140,23921,1024,21761,4161,292,21776,21763,348,65,2389,16401,4096,2421,1285,21621,256,21793,16464,22273]

theorem envBound21766 : H12AffineFastState.Bounded env21766 := by
  intro p hp
  have h : env21766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21765_21766 : H12AffineEnvironment.transform 16 5140 env21765 = env21766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env21765 == env21766) = true)

theorem identity21766 : scanCanonicalize (H12AffineFastState.compose env21766 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound21766 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env21767 : List Nat := [2,4,8,16,32,64,89,85,512,1024,2048,4096,88,16384,21589,21511,5140,23588,1024,21588,4161,113,21573,21590,9,65,2048,16401,4096,2080,1104,21621,85,21620,16464,22100]

theorem envBound21767 : H12AffineFastState.Bounded env21767 := by
  intro p hp
  have h : env21767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21766_21767 : H12AffineEnvironment.transform 7 85 env21766 = env21767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env21766 == env21767) = true)

theorem identity21767 : scanCanonicalize (H12AffineFastState.compose env21767 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21767 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21768 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,9,16384,21508,21511,5140,23588,1024,21509,4112,32,21524,21511,9,16,2048,16401,4096,2080,1025,21540,4,21541,16385,22021]

theorem envBound21768 : H12AffineFastState.Bounded env21768 := by
  intro p hp
  have h : env21768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21767_21768 : H12AffineEnvironment.transform 5 17 env21767 = env21768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21767 == env21768) = true)

theorem identity21768 : scanCanonicalize (H12AffineFastState.compose env21768 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound21768 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21769 : List Nat := [2,4,8,16,32,17,8,4,48,1024,2048,4096,9,16384,21508,21511,5140,23588,1024,21509,4112,32,21524,21511,9,16,2048,16401,4096,2080,1025,21540,4,21541,16385,21557]

theorem envBound21769 : H12AffineFastState.Bounded env21769 := by
  intro p hp
  have h : env21769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21768_21769 : H12AffineEnvironment.transform 8 48 env21768 = env21769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env21768 == env21769) = true)

theorem identity21769 : scanCanonicalize (H12AffineFastState.compose env21769 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound21769 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env21770 : List Nat := [2,4,8,16,32,17,8,4,48,1024,2048,3109,9,16384,18465,18466,2097,16385,1024,18464,3125,32,18481,18466,9,16,2048,16401,3109,2080,1025,18433,4,18432,16385,18448]

theorem envBound21770 : H12AffineFastState.Bounded env21770 := by
  intro p hp
  have h : env21770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21769_21770 : H12AffineEnvironment.transform 11 3109 env21769 = env21770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env21769 == env21770) = true)

theorem identity21770 : scanCanonicalize (H12AffineFastState.compose env21770 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound21770 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21771 : List Nat := [2,4,8,16,32,17,8,4,48,1024,1076,17,9,16384,17429,17430,1029,16385,1024,17428,1,32,17413,17430,9,16,1076,16401,17,1044,1025,17461,4,17460,16385,17444]

theorem envBound21771 : H12AffineFastState.Bounded env21771 := by
  intro p hp
  have h : env21771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21770_21771 : H12AffineEnvironment.transform 10 1076 env21770 = env21771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env21770 == env21771) = true)

theorem identity21771 : scanCanonicalize (H12AffineFastState.compose env21771 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21771 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env21772 : List Nat := [2,4,8,16,16,17,8,4,0,1024,1028,17,9,16384,17429,17430,1029,16385,1024,17428,1,16,17413,17430,9,16,1028,16401,17,1044,1025,17413,4,17412,16385,17428]

theorem envBound21772 : H12AffineFastState.Bounded env21772 := by
  intro p hp
  have h : env21772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21771_21772 : H12AffineEnvironment.transform 4 16 env21771 = env21772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21771 == env21772) = true)

theorem identity21772 : scanCanonicalize (H12AffineFastState.compose env21772 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21773 : List Nat := [2,4,8,16,16,17,8,4,0,21,17,17,9,16384,16384,16387,16,16385,21,16385,1,16,16400,16387,9,16,17,16401,17,1,20,16400,4,16401,16385,16385]

theorem envBound21773 : H12AffineFastState.Bounded env21773 := by
  intro p hp
  have h : env21773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21772_21773 : H12AffineEnvironment.transform 9 21 env21772 = env21773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21772 == env21773) = true)

theorem identity21773 : scanCanonicalize (H12AffineFastState.compose env21773 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound21773 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21774 : List Nat := [2,4,8,16,16,17,8,4,0,21,17,17,9,1,1,2,16,0,21,0,1,16,17,2,9,16,17,16,17,1,20,17,4,16,0,0]

theorem envBound21774 : H12AffineFastState.Bounded env21774 := by
  intro p hp
  have h : env21774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21773_21774 : H12AffineEnvironment.transform 13 1 env21773 = env21774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env21773 == env21774) = true)

theorem identity21774 : scanCanonicalize (H12AffineFastState.compose env21774 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21775 : List Nat := [2,4,8,0,0,1,8,4,0,5,1,1,9,1,1,2,0,0,5,0,1,0,1,2,9,0,1,0,1,1,4,1,4,0,0,0]

theorem envBound21775 : H12AffineFastState.Bounded env21775 := by
  intro p hp
  have h : env21775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21774_21775 : H12AffineEnvironment.transform 3 0 env21774 = env21775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21774 == env21775) = true)

theorem identity21775 : scanCanonicalize (H12AffineFastState.compose env21775 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21776 : List Nat := [2,0,8,0,0,1,8,0,0,1,1,1,9,1,1,2,0,0,1,0,1,0,1,2,9,0,1,0,1,1,0,1,0,0,0,0]

theorem envBound21776 : H12AffineFastState.Bounded env21776 := by
  intro p hp
  have h : env21776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21775_21776 : H12AffineEnvironment.transform 1 0 env21775 = env21776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21775 == env21776) = true)

def env21777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363553,21763,8328,65,215367,115151,4378673,4332612,4408371,4268162,256,4396238,4453739,4350948]

theorem envBound21777 : H12AffineFastState.Bounded env21777 := by
  intro p hp
  have h : env21777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21751_21777 : H12AffineEnvironment.transform 22 4363553 env21751 = env21777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env21751 == env21777) = true)

theorem identity21777 : scanCanonicalize (H12AffineFastState.compose env21777 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,4194304,4363553,21763,8328,65,158029,57797,4378673,4332612,4351033,4194440,256,4338884,4380001,4350948]

theorem envBound21778 : H12AffineFastState.Bounded env21778 := by
  intro p hp
  have h : env21778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21777_21778 : H12AffineEnvironment.transform 15 8202 env21777 = env21778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21777 == env21778) = true)

theorem identity21778 : scanCanonicalize (H12AffineFastState.compose env21778 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound21778 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env21779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4161,156133,62660,21763,8328,65,158029,57797,45524,32161,1500,156013,256,21793,46212,513]

theorem envBound21779 : H12AffineFastState.Bounded env21779 := by
  intro p hp
  have h : env21779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21778_21779 : H12AffineEnvironment.transform 21 156133 env21778 = env21779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env21778 == env21779) = true)

theorem identity21779 : scanCanonicalize (H12AffineFastState.compose env21779 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound21779 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env21780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,23804,1024,32769,4161,29820,62660,21763,8328,65,31956,57797,45524,32161,1500,29940,256,21793,46212,513]

theorem envBound21780 : H12AffineFastState.Bounded env21780 := by
  intro p hp
  have h : env21780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21779_21780 : H12AffineEnvironment.transform 16 5529 env21779 = env21780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env21779 == env21780) = true)

theorem identity21780 : scanCanonicalize (H12AffineFastState.compose env21780 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound21780 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env21781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8202,5529,23804,1024,136,4161,29820,29773,21763,8328,65,31956,24908,12637,32161,1500,29940,256,21793,13325,513]

theorem envBound21781 : H12AffineFastState.Bounded env21781 := by
  intro p hp
  have h : env21781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21780_21781 : H12AffineEnvironment.transform 14 137 env21780 = env21781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env21780 == env21781) = true)

theorem identity21781 : scanCanonicalize (H12AffineFastState.compose env21781 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21781 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env21782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,137,8202,5529,2420,1024,136,4161,8692,8645,139,8328,65,10588,13508,12637,10281,1500,8572,256,169,13325,513]

theorem envBound21782 : H12AffineFastState.Bounded env21782 := by
  intro p hp
  have h : env21782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21781_21782 : H12AffineEnvironment.transform 13 5512 env21781 = env21782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21781 == env21782) = true)

theorem identity21782 : scanCanonicalize (H12AffineFastState.compose env21782 (packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21782 : packedSelected [0,2,3,4,5,7,9,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env21783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,8202,5393,2420,1024,0,4161,8572,8525,3,8192,65,10588,13388,12637,10281,1364,8572,256,33,13325,513]

theorem envBound21783 : H12AffineFastState.Bounded env21783 := by
  intro p hp
  have h : env21783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21782_21783 : H12AffineEnvironment.transform 6 8 env21782 = env21783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21782 == env21783) = true)

theorem identity21783 : scanCanonicalize (H12AffineFastState.compose env21783 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21783 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env21784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2420,1024,0,4161,33,16,3,349,65,2049,5393,4096,2420,1364,33,256,33,5456,513]

theorem envBound21784 : H12AffineFastState.Bounded env21784 := by
  intro p hp
  have h : env21784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21783_21784 : H12AffineEnvironment.transform 12 349 env21783 = env21784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21783 == env21784) = true)

theorem identity21784 : scanCanonicalize (H12AffineFastState.compose env21784 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound21784 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1060,349,292,1,343,309,2420,1024,0,1125,33,16,3,349,65,2049,309,1060,2420,1364,33,256,33,372,513]

theorem envBound21785 : H12AffineFastState.Bounded env21785 := by
  intro p hp
  have h : env21785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21784_21785 : H12AffineEnvironment.transform 11 1060 env21784 = env21785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env21784 == env21785) = true)

def env21786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830977,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound21786 : H12AffineFastState.Bounded env21786 := by
  intro p hp
  have h : env21786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21588_21786 : H12AffineEnvironment.transform 18 1025 env21588 = env21786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21588 == env21786) = true)

theorem identity21786 : scanCanonicalize (H12AffineFastState.compose env21786 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485414) := by decide +kernel

theorem selectedBound21786 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485414,16777216,8328,65,23211175,18973836,375287,2305191,19163319,23160256,257,17049610,17090990,19222369]

theorem envBound21787 : H12AffineFastState.Bounded env21787 := by
  intro p hp
  have h : env21787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21786_21787 : H12AffineEnvironment.transform 22 2485414 env21786 = env21787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485414 env21786 == env21787) = true)

def env21788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485414,16777216,8328,65,16959643,18973836,375287,2305191,19163319,16876028,257,17049610,17090990,19222369]

theorem envBound21788 : H12AffineFastState.Bounded env21788 := by
  intro p hp
  have h : env21788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21787_21788 : H12AffineEnvironment.transform 21 2155580 env21787 = env21788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env21787 == env21788) = true)

def env21789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,16777216,8192,65,16959507,18973700,375167,2305071,19163199,16875892,257,17049610,17090854,19222369]

theorem envBound21789 : H12AffineFastState.Bounded env21789 := by
  intro p hp
  have h : env21789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21788_21789 : H12AffineEnvironment.transform 6 8 env21788 = env21789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21788 == env21789) = true)

theorem identity21789 : scanCanonicalize (H12AffineFastState.compose env21789 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound21789 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,16,16777216,8192,65,16959507,17066042,375167,442385,16876545,16875892,257,17049610,17090854,16819039]

theorem envBound21790 : H12AffineFastState.Bounded env21790 := by
  intro p hp
  have h : env21790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21789_21790 : H12AffineEnvironment.transform 20 388158 env21789 = env21790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env21789 == env21790) = true)

theorem identity21790 : scanCanonicalize (H12AffineFastState.compose env21790 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound21790 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,16,272426,8192,65,450617,16400,375167,442385,371755,371038,257,32,57612,297845]

theorem envBound21791 : H12AffineFastState.Bounded env21791 := by
  intro p hp
  have h : env21791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21790_21791 : H12AffineEnvironment.transform 23 272426 env21790 = env21791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env21790 == env21791) = true)

theorem identity21791 : scanCanonicalize (H12AffineFastState.compose env21791 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound21791 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env21792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,388158,329730,16,272426,8192,65,360482,16400,375167,368650,371755,371038,257,32,57612,297845]

theorem envBound21792 : H12AffineFastState.Bounded env21792 := by
  intro p hp
  have h : env21792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21791_21792 : H12AffineEnvironment.transform 16 90139 env21791 = env21792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env21791 == env21792) = true)

theorem identity21792 : scanCanonicalize (H12AffineFastState.compose env21792 (packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound21792 : packedSelected [0,4,7,11,16,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env21793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,67618,1025,32769,58396,32,16,73736,8192,65,34816,16400,45405,43048,41993,41340,257,32,57612,99159]

theorem envBound21793 : H12AffineFastState.Bounded env21793 := by
  intro p hp
  have h : env21793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21792_21793 : H12AffineEnvironment.transform 17 67618 env21792 = env21793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env21792 == env21793) = true)

theorem identity21793 : scanCanonicalize (H12AffineFastState.compose env21793 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound21793 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env21794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,32802,57401,34816,1025,32769,58396,32,16,41002,8192,65,34816,16400,45405,43048,41993,41340,257,32,57612,885]

theorem envBound21794 : H12AffineFastState.Bounded env21794 := by
  intro p hp
  have h : env21794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21793_21794 : H12AffineEnvironment.transform 15 32802 env21793 = env21794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env21793 == env21794) = true)

theorem identity21794 : scanCanonicalize (H12AffineFastState.compose env21794 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21794 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env21795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,32802,46156,34816,1025,32769,45161,32,16,41002,8192,65,34816,5221,45405,43048,41993,41340,257,32,46457,885]

theorem envBound21795 : H12AffineFastState.Bounded env21795 := by
  intro p hp
  have h : env21795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21794_21795 : H12AffineEnvironment.transform 13 5237 env21794 = env21795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21794 == env21795) = true)

theorem identity21795 : scanCanonicalize (H12AffineFastState.compose env21795 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21795 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8575,5393,10589,1025,8540,4404,32,16,375,8192,65,10589,5221,4096,2421,1364,33,257,32,5156,885]

theorem envBound21796 : H12AffineFastState.Bounded env21796 := by
  intro p hp
  have h : env21796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21795_21796 : H12AffineEnvironment.transform 14 8541 env21795 = env21796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21795 == env21796) = true)

theorem identity21796 : scanCanonicalize (H12AffineFastState.compose env21796 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21796 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,0,34,5393,2048,1025,1,4404,32,16,375,349,65,2048,5221,4096,2421,1364,33,257,32,5156,885]

theorem envBound21797 : H12AffineFastState.Bounded env21797 := by
  intro p hp
  have h : env21797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21796_21797 : H12AffineEnvironment.transform 12 349 env21796 = env21797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21796 == env21797) = true)

theorem identity21797 : scanCanonicalize (H12AffineFastState.compose env21797 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21797 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env21798 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,349,4113,0,34,4469,2048,101,1,4404,32,16,375,349,65,2048,4097,4096,2421,304,33,257,32,4160,885]

theorem envBound21798 : H12AffineFastState.Bounded env21798 := by
  intro p hp
  have h : env21798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21797_21798 : H12AffineEnvironment.transform 9 100 env21797 = env21798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21797 == env21798) = true)

def env21799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,16777216,8193,65,16959506,18973701,375166,2305070,19163198,16875893,257,17049610,17090855,19222369]

theorem envBound21799 : H12AffineFastState.Bounded env21799 := by
  intro p hp
  have h : env21799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21788_21799 : H12AffineEnvironment.transform 6 9 env21788 = env21799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21788 == env21799) = true)

def env21800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,16777216,8193,65,16959506,18973701,102742,2305070,18890774,16875893,257,16777250,16834831,18966345]

theorem envBound21800 : H12AffineFastState.Bounded env21800 := by
  intro p hp
  have h : env21800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21799_21800 : H12AffineEnvironment.transform 17 10280 env21799 = env21800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21799 == env21800) = true)

theorem identity21800 : scanCanonicalize (H12AffineFastState.compose env21800 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2188616) := by decide +kernel

theorem selectedBound21800 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21801 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,2188616,8193,65,2338138,57677,102742,2305070,75102,2155581,257,2188650,2196551,513]

theorem envBound21801 : H12AffineFastState.Bounded env21801 := by
  intro p hp
  have h : env21801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21800_21801 : H12AffineEnvironment.transform 23 2188616 env21800 = env21801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2188616 env21800 == env21801) = true)

theorem identity21801 : scanCanonicalize (H12AffineFastState.compose env21801 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound21801 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env21802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,2097152,2155580,2212871,2188616,8193,65,2182166,57677,102742,2215266,75102,2155581,257,2188650,2196551,513]

theorem envBound21802 : H12AffineFastState.Bounded env21802 := by
  intro p hp
  have h : env21802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21801_21802 : H12AffineEnvironment.transform 16 57676 env21801 = env21802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env21801 == env21802) = true)

theorem identity21802 : scanCanonicalize (H12AffineFastState.compose env21802 (packedSelected [1,3,5,8,14,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound21802 : packedSelected [1,3,5,8,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env21803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1025,32769,124186,65830,8477,32850,8193,65,43276,57677,102742,10360,75102,65831,257,32880,24925,513]

theorem envBound21803 : H12AffineFastState.Bounded env21803 := by
  intro p hp
  have h : env21803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21802_21803 : H12AffineEnvironment.transform 20 124186 env21802 = env21803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env21802 == env21803) = true)

theorem identity21803 : scanCanonicalize (H12AffineFastState.compose env21803 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21803 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env21804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,57676,10280,1025,32769,58444,112,8477,32850,8193,65,43276,57677,36864,10360,9224,113,257,32880,24925,513]

theorem envBound21804 : H12AffineFastState.Bounded env21804 := by
  intro p hp
  have h : env21804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21803_21804 : H12AffineEnvironment.transform 15 342 env21803 = env21804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21803 == env21804) = true)

theorem identity21804 : scanCanonicalize (H12AffineFastState.compose env21804 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21804 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,342,49217,2341,1025,32769,50497,112,16,32850,268,65,34817,49216,36864,2421,1285,113,257,32880,16464,513]

theorem envBound21805 : H12AffineFastState.Bounded env21805 := by
  intro p hp
  have h : env21805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21804_21805 : H12AffineEnvironment.transform 12 269 env21804 = env21805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21804 == env21805) = true)

def env21806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,16777216,8193,65,16959506,18973701,102743,2305070,18890775,16875893,257,16777251,16834830,18966344]

theorem envBound21806 : H12AffineFastState.Bounded env21806 := by
  intro p hp
  have h : env21806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21799_21806 : H12AffineEnvironment.transform 17 10281 env21799 = env21806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21799 == env21806) = true)

theorem identity21806 : scanCanonicalize (H12AffineFastState.compose env21806 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound21806 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155580,2212870,41310,8193,65,158028,2172251,102743,2305070,2154825,73771,257,41341,16464,2213398]

theorem envBound21807 : H12AffineFastState.Bounded env21807 := by
  intro p hp
  have h : env21807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21806_21807 : H12AffineEnvironment.transform 23 41310 env21806 = env21807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env21806 == env21807) = true)

theorem identity21807 : scanCanonicalize (H12AffineFastState.compose env21807 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 173068) := by decide +kernel

theorem selectedBound21807 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,173068,147504,221194,41310,8193,65,158028,229719,102743,100386,148805,73771,257,41341,16464,221722]

theorem envBound21808 : H12AffineFastState.Bounded env21808 := by
  intro p hp
  have h : env21808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21807_21808 : H12AffineEnvironment.transform 20 173068 env21807 = env21808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 173068 env21807 == env21808) = true)

theorem identity21808 : scanCanonicalize (H12AffineFastState.compose env21808 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound21808 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env21809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,131072,10281,1025,29005,152896,147504,221194,20498,8193,65,158028,225307,90139,96622,148805,73771,257,20529,16464,221722]

theorem envBound21809 : H12AffineFastState.Bounded env21809 := by
  intro p hp
  have h : env21809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21808_21809 : H12AffineEnvironment.transform 14 29004 env21808 = env21809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env21808 == env21809) = true)

theorem identity21809 : scanCanonicalize (H12AffineFastState.compose env21809 (packedSelected [1,3,5,10,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound21809 : packedSelected [1,3,5,10,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,16401,10281,1025,29005,5457,33,73755,20498,8193,65,10589,77834,90139,96622,1364,73771,257,20529,16464,74251]

theorem envBound21810 : H12AffineFastState.Bounded env21810 := by
  intro p hp
  have h : env21810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21809_21810 : H12AffineEnvironment.transform 16 16401 env21809 = env21810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21809 == env21810) = true)

theorem identity21810 : scanCanonicalize (H12AffineFastState.compose env21810 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound21810 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env21811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,81,65536,12556,10281,1025,80,5457,33,73755,8463,8193,65,10589,77834,69894,67699,1364,73771,257,8492,12621,74251]

theorem envBound21811 : H12AffineFastState.Bounded env21811 := by
  intro p hp
  have h : env21811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21810_21811 : H12AffineEnvironment.transform 13 12573 env21810 = env21811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env21810 == env21811) = true)

theorem identity21811 : scanCanonicalize (H12AffineFastState.compose env21811 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound21811 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env21812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,5236,81,65536,5221,3392,1025,80,5457,33,66930,1126,1384,65,3124,71011,69894,67699,1364,66882,257,1093,5156,67426]

theorem envBound21812 : H12AffineFastState.Bounded env21812 := by
  intro p hp
  have h : env21812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21811_21812 : H12AffineEnvironment.transform 12 1385 env21811 = env21812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env21811 == env21812) = true)

theorem identity21812 : scanCanonicalize (H12AffineFastState.compose env21812 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21812 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env21813 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,1353,5204,81,65536,5189,3392,1025,80,5457,1,66898,1094,1352,65,3092,70979,69894,67667,1364,66882,257,1093,5124,67394]

theorem envBound21813 : H12AffineFastState.Bounded env21813 := by
  intro p hp
  have h : env21813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21812_21813 : H12AffineEnvironment.transform 4 0 env21812 = env21813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21812 == env21813) = true)

theorem identity21813 : scanCanonicalize (H12AffineFastState.compose env21813 (packedSelected [0,1,2,5,6,7,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2372) := by decide +kernel

theorem selectedBound21813 : packedSelected [0,1,2,5,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21814 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,2372,1353,3344,81,65536,3329,3392,1025,80,3093,1,66898,1094,1352,65,3092,68615,67650,67667,1364,66882,257,1093,3392,67394]

theorem envBound21814 : H12AffineFastState.Bounded env21814 := by
  intro p hp
  have h : env21814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21813_21814 : H12AffineEnvironment.transform 11 2372 env21813 = env21814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2372 env21813 == env21814) = true)

theorem identity21814 : scanCanonicalize (H12AffineFastState.compose env21814 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21814 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env21815 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,2372,1353,3344,81,342,3329,3392,1025,80,3093,1,1028,1094,1352,65,3092,3409,2324,2309,1364,1044,257,1093,3392,1556]

theorem envBound21815 : H12AffineFastState.Bounded env21815 := by
  intro p hp
  have h : env21815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21814_21815 : H12AffineEnvironment.transform 15 342 env21814 = env21815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21814 == env21815) = true)

theorem identity21815 : scanCanonicalize (H12AffineFastState.compose env21815 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21815 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21816 : List Nat := [2,4,8,16,0,64,9,256,512,21,2048,2372,348,2309,81,342,2324,2389,20,80,2048,1,17,83,349,65,2049,2372,2324,2309,321,1,257,80,2389,513]

theorem envBound21816 : H12AffineFastState.Bounded env21816 := by
  intro p hp
  have h : env21816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21815_21816 : H12AffineEnvironment.transform 9 21 env21815 = env21816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21815 == env21816) = true)

theorem identity21816 : scanCanonicalize (H12AffineFastState.compose env21816 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21816 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21817 : List Nat := [2,4,8,16,0,64,9,5,512,21,2048,2113,89,2048,81,83,2065,2128,20,80,2048,1,17,83,88,65,2049,2113,2065,2048,68,1,4,80,2128,513]

theorem envBound21817 : H12AffineFastState.Bounded env21817 := by
  intro p hp
  have h : env21817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21816_21817 : H12AffineEnvironment.transform 7 5 env21816 = env21817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21816 == env21817) = true)

theorem identity21817 : scanCanonicalize (H12AffineFastState.compose env21817 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21818 : List Nat := [2,4,8,16,0,64,9,5,0,21,2048,2113,89,2048,81,83,2065,2128,20,80,2048,1,17,83,88,65,2049,2113,2065,2048,68,1,4,80,2128,1]

theorem envBound21818 : H12AffineFastState.Bounded env21818 := by
  intro p hp
  have h : env21818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21817_21818 : H12AffineEnvironment.transform 8 0 env21817 = env21818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21817 == env21818) = true)

theorem identity21818 : scanCanonicalize (H12AffineFastState.compose env21818 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound21818 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21819 : List Nat := [2,4,8,16,0,64,9,5,0,21,17,80,89,17,81,83,0,65,20,80,17,1,17,83,88,65,16,80,0,17,68,1,4,80,65,1]

theorem envBound21819 : H12AffineFastState.Bounded env21819 := by
  intro p hp
  have h : env21819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21818_21819 : H12AffineEnvironment.transform 10 17 env21818 = env21819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env21818 == env21819) = true)

def env21820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485414,16777216,8328,65,16959642,18973836,375287,2305191,19163319,16876029,257,17049610,17090990,19222369]

theorem envBound21820 : H12AffineFastState.Bounded env21820 := by
  intro p hp
  have h : env21820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21787_21820 : H12AffineEnvironment.transform 21 2155581 env21787 = env21820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env21787 == env21820) = true)

def env21821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,16777216,8192,65,16959506,18973700,375167,2305071,19163199,16875893,257,17049610,17090854,19222369]

theorem envBound21821 : H12AffineFastState.Bounded env21821 := by
  intro p hp
  have h : env21821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21820_21821 : H12AffineEnvironment.transform 6 8 env21820 = env21821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21820 == env21821) = true)

def env21822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,16777216,8192,65,16959506,18973700,102743,2305071,18890775,16875893,257,16777250,16834830,18966345]

theorem envBound21822 : H12AffineFastState.Bounded env21822 := by
  intro p hp
  have h : env21822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21821_21822 : H12AffineEnvironment.transform 17 10280 env21821 = env21822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21821 == env21822) = true)

theorem identity21822 : scanCanonicalize (H12AffineFastState.compose env21822 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound21822 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21823 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155581,2212870,2,8192,65,182288,2196486,102743,2305071,2113557,98679,257,32,57612,2189131]

theorem envBound21823 : H12AffineFastState.Bounded env21823 := by
  intro p hp
  have h : env21823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21822_21823 : H12AffineEnvironment.transform 23 2 env21822 = env21823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env21822 == env21823) = true)

theorem identity21823 : scanCanonicalize (H12AffineFastState.compose env21823 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound21823 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env21824 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,73770,17,2,8192,65,182288,16401,102743,190520,99330,98679,257,32,57612,41820]

theorem envBound21824 : H12AffineFastState.Bounded env21824 := by
  intro p hp
  have h : env21824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21823_21824 : H12AffineEnvironment.transform 20 115735 env21823 = env21824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env21823 == env21824) = true)

theorem identity21824 : scanCanonicalize (H12AffineFastState.compose env21824 (packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 115014) := by decide +kernel

theorem selectedBound21824 : packedSelected [0,3,4,7,10,16,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21825 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,115014,10280,1025,32769,115735,73770,17,2,8192,65,67926,16401,102743,76158,99330,98679,257,32,57612,41820]

theorem envBound21825 : H12AffineFastState.Bounded env21825 := by
  intro p hp
  have h : env21825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21824_21825 : H12AffineEnvironment.transform 16 115014 env21824 = env21825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115014 env21824 == env21825) = true)

theorem identity21825 : scanCanonicalize (H12AffineFastState.compose env21825 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21825 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env21826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,82247,10280,1025,0,82966,73770,17,2,8192,65,67926,16401,69974,76158,66563,65910,257,32,24845,9053]

theorem envBound21826 : H12AffineFastState.Bounded env21826 := by
  intro p hp
  have h : env21826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21825_21826 : H12AffineEnvironment.transform 14 1 env21825 = env21826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21825 == env21826) = true)

theorem identity21826 : scanCanonicalize (H12AffineFastState.compose env21826 (packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound21826 : packedSelected [0,3,5,7,9,10,12,14,15,16,22] rootPS < 2^1333 := by decide +kernel

def env21827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8574,24633,10280,1025,0,25960,340,17,2,8192,65,10280,16401,12328,2048,9597,8200,257,32,24845,9053]

theorem envBound21827 : H12AffineFastState.Bounded env21827 := by
  intro p hp
  have h : env21827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21826_21827 : H12AffineEnvironment.transform 15 8574 env21826 = env21827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env21826 == env21827) = true)

theorem identity21827 : scanCanonicalize (H12AffineFastState.compose env21827 (packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound21827 : packedSelected [0,1,2,4,5,6,7,8,9,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env21828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,8574,5172,10280,1025,0,4453,340,17,2,8192,65,10280,13340,12328,2048,9597,8200,257,32,5376,9053]

theorem envBound21828 : H12AffineFastState.Bounded env21828 := by
  intro p hp
  have h : env21828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21827_21828 : H12AffineEnvironment.transform 13 13325 env21827 = env21828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env21827 == env21828) = true)

theorem identity21828 : scanCanonicalize (H12AffineFastState.compose env21828 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21828 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env21829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,1,35,5172,2421,1025,0,4453,340,17,2,349,65,2421,5441,4469,2048,1056,341,257,32,5376,512]

theorem envBound21829 : H12AffineFastState.Bounded env21829 := by
  intro p hp
  have h : env21829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21828_21829 : H12AffineEnvironment.transform 12 349 env21828 = env21829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21828 == env21829) = true)

theorem identity21829 : scanCanonicalize (H12AffineFastState.compose env21829 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21829 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21830 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,35,5172,2341,1025,0,4405,260,17,2,269,17,2341,5393,4389,2048,1056,261,257,32,5376,512]

theorem envBound21830 : H12AffineFastState.Bounded env21830 := by
  intro p hp
  have h : env21830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21829_21830 : H12AffineEnvironment.transform 5 16 env21829 = env21830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21829 == env21830) = true)

theorem identity21830 : scanCanonicalize (H12AffineFastState.compose env21830 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21830 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21831 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,1,3,5140,2309,1025,0,4373,260,17,2,269,17,2309,5393,4357,2048,1024,261,257,0,5376,512]

theorem envBound21831 : H12AffineFastState.Bounded env21831 := by
  intro p hp
  have h : env21831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21830_21831 : H12AffineEnvironment.transform 4 0 env21830 = env21831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21830 == env21831) = true)

theorem identity21831 : scanCanonicalize (H12AffineFastState.compose env21831 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21831 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21832 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,1,3,5140,2049,1025,0,4113,0,17,2,9,17,2049,5141,4097,2048,1024,1,5,0,5124,512]

theorem envBound21832 : H12AffineFastState.Bounded env21832 := by
  intro p hp
  have h : env21832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21831_21832 : H12AffineEnvironment.transform 7 4 env21831 = env21832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21831 == env21832) = true)

def env21833 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1044,1,3,1028,2049,1025,0,1,0,17,2,9,17,2049,1029,17,2048,1024,1,5,0,1044,512]

theorem envBound21833 : H12AffineFastState.Bounded env21833 := by
  intro p hp
  have h : env21833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21832_21833 : H12AffineEnvironment.transform 11 16 env21832 = env21833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21832 == env21833) = true)

theorem identity21833 : scanCanonicalize (H12AffineFastState.compose env21833 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound21833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21834 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1044,16,9,1044,1,3,1028,1045,1025,0,1,0,17,2,9,17,1045,1029,17,1044,1024,1,5,0,1044,512]

theorem envBound21834 : H12AffineFastState.Bounded env21834 := by
  intro p hp
  have h : env21834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21833_21834 : H12AffineEnvironment.transform 10 1044 env21833 = env21834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env21833 == env21834) = true)

def env21835 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,16,9,0,1,3,16,1,21,0,1,0,17,2,9,17,1,17,17,0,20,1,5,0,0,512]

theorem envBound21835 : H12AffineFastState.Bounded env21835 := by
  intro p hp
  have h : env21835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21834_21835 : H12AffineEnvironment.transform 9 20 env21834 = env21835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21834 == env21835) = true)

theorem identity21835 : scanCanonicalize (H12AffineFastState.compose env21835 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound21835 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21836 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,9,0,1,3,4,1,1,0,1,0,5,2,9,5,1,5,5,0,0,1,5,0,0,512]

theorem envBound21836 : H12AffineFastState.Bounded env21836 := by
  intro p hp
  have h : env21836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21835_21836 : H12AffineEnvironment.transform 3 4 env21835 = env21836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env21835 == env21836) = true)

def leafEnv21836 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,4,9,0,1,3,4,1,1,0,1,0,5,2,1,9,1,5,1,5,5,0,0,1,5,0,5,3,0,512,1,1,0]

def active21836 : List Nat := [0,1,2,8]

def tree21836 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21836 : H12WitnessSearch.Good tree21836 := H12GlobalWitnessIndex.good

theorem leafIdentity21836 : H12AffineFastState.composeSystem env21836 rootObs = leafEnv21836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21836 rootObs == leafEnv21836) = true)

theorem terminalChecked21836 : H12PackedTerminal.terminalCheckFast leafEnv21836 active21836 tree21836 = true := by decide +kernel

def env21837 : List Nat := [2,4,8,16,0,16,8,4,512,21,1,16,9,1,1,3,17,0,20,0,1,0,17,2,9,17,0,16,17,1,21,1,5,0,1,512]

theorem envBound21837 : H12AffineFastState.Bounded env21837 := by
  intro p hp
  have h : env21837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21834_21837 : H12AffineEnvironment.transform 9 21 env21834 = env21837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21834 == env21837) = true)

theorem identity21837 : scanCanonicalize (H12AffineFastState.compose env21837 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound21837 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21838 : List Nat := [2,4,8,16,0,16,8,4,31,21,1,16,9,1,1,3,17,0,20,0,1,0,17,2,9,17,0,16,17,1,21,1,5,0,1,31]

theorem envBound21838 : H12AffineFastState.Bounded env21838 := by
  intro p hp
  have h : env21838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21837_21838 : H12AffineEnvironment.transform 8 31 env21837 = env21838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env21837 == env21838) = true)

def leafEnv21838 : List Nat := [2,4,8,16,0,16,8,4,31,21,1,16,9,1,1,3,17,0,20,0,1,0,17,2,20,9,1,17,0,16,17,1,21,1,5,0,5,3,1,31,1,1,0]

def active21838 : List Nat := [0,1,2,3]

def tree21838 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21838 : H12WitnessSearch.Good tree21838 := H12GlobalWitnessIndex.good

theorem leafIdentity21838 : H12AffineFastState.composeSystem env21838 rootObs = leafEnv21838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21838 rootObs == leafEnv21838) = true)

theorem terminalChecked21838 : H12PackedTerminal.terminalCheckFast leafEnv21838 active21838 tree21838 = true := by decide +kernel

def env21839 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1045,1,3,1029,2049,1025,0,0,0,17,2,9,17,2049,1028,16,2048,1024,1,5,0,1045,512]

theorem envBound21839 : H12AffineFastState.Bounded env21839 := by
  intro p hp
  have h : env21839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21832_21839 : H12AffineEnvironment.transform 11 17 env21832 = env21839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env21832 == env21839) = true)

theorem identity21839 : scanCanonicalize (H12AffineFastState.compose env21839 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21839 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21840 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,9,1045,1,3,1029,1,1025,0,0,0,17,2,9,17,1,1028,16,0,1024,1,5,0,1045,512]

theorem envBound21840 : H12AffineFastState.Bounded env21840 := by
  intro p hp
  have h : env21840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21839_21840 : H12AffineEnvironment.transform 10 0 env21839 = env21840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21839 == env21840) = true)

def env21841 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,1,1,3,17,1,21,0,0,0,17,2,9,17,1,16,16,0,20,1,5,0,1,512]

theorem envBound21841 : H12AffineFastState.Bounded env21841 := by
  intro p hp
  have h : env21841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21840_21841 : H12AffineEnvironment.transform 9 20 env21840 = env21841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env21840 == env21841) = true)

theorem identity21841 : scanCanonicalize (H12AffineFastState.compose env21841 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound21841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21842 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,1,3,5,1,1,0,0,0,5,2,9,5,1,4,4,0,0,1,5,0,1,512]

theorem envBound21842 : H12AffineFastState.Bounded env21842 := by
  intro p hp
  have h : env21842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21841_21842 : H12AffineEnvironment.transform 3 4 env21841 = env21842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env21841 == env21842) = true)

def leafEnv21842 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,1,3,5,1,1,0,0,0,5,2,1,9,1,5,1,4,4,0,0,1,5,0,5,3,1,512,1,0,0]

def active21842 : List Nat := [0,1,2,8]

def tree21842 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21842 : H12WitnessSearch.Good tree21842 := H12GlobalWitnessIndex.good

theorem leafIdentity21842 : H12AffineFastState.composeSystem env21842 rootObs = leafEnv21842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21842 rootObs == leafEnv21842) = true)

theorem terminalChecked21842 : H12PackedTerminal.terminalCheckFast leafEnv21842 active21842 tree21842 = true := by decide +kernel

def env21843 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,0,1,3,16,1,20,0,0,0,17,2,9,17,1,17,16,0,21,1,5,0,0,512]

theorem envBound21843 : H12AffineFastState.Bounded env21843 := by
  intro p hp
  have h : env21843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21840_21843 : H12AffineEnvironment.transform 9 21 env21840 = env21843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21840 == env21843) = true)

theorem identity21843 : scanCanonicalize (H12AffineFastState.compose env21843 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound21843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21844 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,9,0,1,3,16,1,20,0,0,0,17,2,9,17,1,17,16,0,21,1,5,0,0,30]

theorem envBound21844 : H12AffineFastState.Bounded env21844 := by
  intro p hp
  have h : env21844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21843_21844 : H12AffineEnvironment.transform 8 30 env21843 = env21844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env21843 == env21844) = true)

def leafEnv21844 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,9,0,1,3,16,1,20,0,0,0,17,2,20,9,1,17,1,17,16,0,21,1,5,0,5,3,0,30,1,0,0]

def active21844 : List Nat := [0,1,2,3]

def tree21844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21844 : H12WitnessSearch.Good tree21844 := H12GlobalWitnessIndex.good

theorem leafIdentity21844 : H12AffineFastState.composeSystem env21844 rootObs = leafEnv21844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21844 rootObs == leafEnv21844) = true)

theorem terminalChecked21844 : H12PackedTerminal.terminalCheckFast leafEnv21844 active21844 tree21844 = true := by decide +kernel

def env21845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,16777216,8192,65,16959506,18973700,102742,2305071,18890774,16875893,257,16777251,16834831,18966344]

theorem envBound21845 : H12AffineFastState.Bounded env21845 := by
  intro p hp
  have h : env21845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21821_21845 : H12AffineEnvironment.transform 17 10281 env21821 = env21845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21821 == env21845) = true)

theorem identity21845 : scanCanonicalize (H12AffineFastState.compose env21845 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 2212884) := by decide +kernel

theorem selectedBound21845 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,2155581,2212871,2212884,8192,65,2296838,16400,102742,2305071,99330,2114913,257,2212919,2172187,41820]

theorem envBound21846 : H12AffineFastState.Bounded env21846 := by
  intro p hp
  have h : env21846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21845_21846 : H12AffineEnvironment.transform 23 2212884 env21845 = env21846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212884 env21845 == env21846) = true)

theorem identity21846 : scanCanonicalize (H12AffineFastState.compose env21846 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21846 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,2114912,2188634,2188617,8192,65,2296838,16400,77835,2305071,75103,2114913,257,2188650,2172187,513]

theorem envBound21847 : H12AffineFastState.Bounded env21847 := by
  intro p hp
  have h : env21847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21846_21847 : H12AffineEnvironment.transform 14 8541 env21846 = env21847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21846 == env21847) = true)

theorem identity21847 : scanCanonicalize (H12AffineFastState.compose env21847 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21847 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,10281,1025,8540,2097152,2114912,2114896,2114883,8192,65,2239500,16400,4097,2231333,1365,2114913,257,2114912,2098449,513]

theorem envBound21848 : H12AffineFastState.Bounded env21848 := by
  intro p hp
  have h : env21848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21847_21848 : H12AffineEnvironment.transform 15 8202 env21847 = env21848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21847 == env21848) = true)

theorem identity21848 : scanCanonicalize (H12AffineFastState.compose env21848 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound21848 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,131072,10281,1025,8540,2097152,2101525,2101541,2101558,8192,65,2239500,5221,4097,2231333,1365,2101524,257,2101525,2098449,513]

theorem envBound21849 : H12AffineFastState.Bounded env21849 := by
  intro p hp
  have h : env21849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21848_21849 : H12AffineEnvironment.transform 13 5237 env21848 = env21849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env21848 == env21849) = true)

theorem identity21849 : scanCanonicalize (H12AffineFastState.compose env21849 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21849 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,131072,10281,1025,8540,13324,9497,9513,9530,8192,65,137216,5221,4097,145449,1365,9496,257,9497,12573,513]

theorem envBound21850 : H12AffineFastState.Bounded env21850 := by
  intro p hp
  have h : env21850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21849_21850 : H12AffineEnvironment.transform 20 13324 env21849 = env21850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13324 env21849 == env21850) = true)

theorem identity21850 : scanCanonicalize (H12AffineFastState.compose env21850 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 12636) := by decide +kernel

theorem selectedBound21850 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8202,12636,10281,1025,8540,13324,9497,9513,9530,8192,65,10588,5221,4097,2421,1365,9496,257,9497,12573,513]

theorem envBound21851 : H12AffineFastState.Bounded env21851 := by
  intro p hp
  have h : env21851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21850_21851 : H12AffineEnvironment.transform 16 12636 env21850 = env21851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12636 env21850 == env21851) = true)

theorem identity21851 : scanCanonicalize (H12AffineFastState.compose env21851 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound21851 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env21852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,8192,3125,8541,8202,10524,10281,1025,8540,11340,9497,9513,9530,8192,65,10588,3109,2113,2421,1365,9496,257,9497,10589,513]

theorem envBound21852 : H12AffineFastState.Bounded env21852 := by
  intro p hp
  have h : env21852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21851_21852 : H12AffineEnvironment.transform 11 2112 env21851 = env21852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env21851 == env21852) = true)

theorem identity21852 : scanCanonicalize (H12AffineFastState.compose env21852 (packedSelected [4,9,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21852 : packedSelected [4,9,15] rootPS < 2^1333 := by decide +kernel

def env21853 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,2112,8192,2049,8541,8202,10524,10281,53,8540,10360,8493,8477,8462,8192,65,10588,2065,2113,2421,353,8492,257,8493,10589,513]

theorem envBound21853 : H12AffineFastState.Bounded env21853 := by
  intro p hp
  have h : env21853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21852_21853 : H12AffineEnvironment.transform 9 52 env21852 = env21853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21852 == env21853) = true)

theorem identity21853 : scanCanonicalize (H12AffineFastState.compose env21853 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21853 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21854 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2064,8192,2049,8461,8202,10524,10281,53,8460,10280,8493,8477,8462,8192,17,10508,2065,2065,2341,305,8492,257,8493,10509,513]

theorem envBound21854 : H12AffineFastState.Bounded env21854 := by
  intro p hp
  have h : env21854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21853_21854 : H12AffineEnvironment.transform 5 16 env21853 = env21854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21853 == env21854) = true)

def env21855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485295,16777216,8193,65,16959507,18973701,375166,2305070,19163198,16875892,257,17049610,17090855,19222369]

theorem envBound21855 : H12AffineFastState.Bounded env21855 := by
  intro p hp
  have h : env21855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21820_21855 : H12AffineEnvironment.transform 6 9 env21820 = env21855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21820 == env21855) = true)

theorem identity21855 : scanCanonicalize (H12AffineFastState.compose env21855 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound21855 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env21856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329731,17,16777216,8193,65,16959507,17066043,375166,442384,16876544,16875892,257,17049610,17090855,16819039]

theorem envBound21856 : H12AffineFastState.Bounded env21856 := by
  intro p hp
  have h : env21856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21855_21856 : H12AffineEnvironment.transform 20 388158 env21855 = env21856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env21855 == env21856) = true)

theorem identity21856 : scanCanonicalize (H12AffineFastState.compose env21856 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound21856 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329731,17,41310,8193,65,158029,313701,375166,442384,75102,73770,257,297300,288889,513]

theorem envBound21857 : H12AffineFastState.Bounded env21857 := by
  intro p hp
  have h : env21857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21856_21857 : H12AffineEnvironment.transform 23 41310 env21856 = env21857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env21856 == env21857) = true)

def env21858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,73771,17,41310,8193,65,158029,57677,102742,190520,75102,73770,257,41340,16465,513]

theorem envBound21858 : H12AffineFastState.Bounded env21858 := by
  intro p hp
  have h : env21858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21857_21858 : H12AffineEnvironment.transform 17 10280 env21857 = env21858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env21857 == env21858) = true)

theorem identity21858 : scanCanonicalize (H12AffineFastState.compose env21858 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21858 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env21859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,58397,32,17,41310,8193,65,158029,57677,45405,190520,1365,33,257,41340,16465,513]

theorem envBound21859 : H12AffineFastState.Bounded env21859 := by
  intro p hp
  have h : env21859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21858_21859 : H12AffineEnvironment.transform 15 8203 env21858 = env21859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21858 == env21859) = true)

theorem identity21859 : scanCanonicalize (H12AffineFastState.compose env21859 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound21859 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10280,1025,32769,58397,32,17,41310,8193,65,43356,57677,45405,10281,1365,33,257,41340,16465,513]

theorem envBound21860 : H12AffineFastState.Bounded env21860 := by
  intro p hp
  have h : env21860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21859_21860 : H12AffineEnvironment.transform 16 49169 env21859 = env21860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21859 == env21860) = true)

theorem identity21860 : scanCanonicalize (H12AffineFastState.compose env21860 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21860 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env21861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,16400,10280,1025,0,25628,32,17,8543,8193,65,10589,24908,12636,10281,1365,33,257,8573,16465,513]

theorem envBound21861 : H12AffineFastState.Bounded env21861 := by
  intro p hp
  have h : env21861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21860_21861 : H12AffineEnvironment.transform 14 1 env21860 = env21861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21860 == env21861) = true)

theorem identity21861 : scanCanonicalize (H12AffineFastState.compose env21861 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21861 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,342,16400,2421,1025,0,17729,32,17,2,348,65,2048,16401,4097,2420,1365,33,257,32,16465,513]

theorem envBound21862 : H12AffineFastState.Bounded env21862 := by
  intro p hp
  have h : env21862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21861_21862 : H12AffineEnvironment.transform 12 349 env21861 = env21862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21861 == env21862) = true)

theorem identity21862 : scanCanonicalize (H12AffineFastState.compose env21862 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1637) := by decide +kernel

theorem selectedBound21862 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1637,1,342,1653,2421,1025,0,804,32,17,2,348,65,2048,1652,4097,2420,1365,33,257,32,1588,513]

theorem envBound21863 : H12AffineFastState.Bounded env21863 := by
  intro p hp
  have h : env21863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21862_21863 : H12AffineEnvironment.transform 13 1637 env21862 = env21863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1637 env21862 == env21863) = true)

theorem identity21863 : scanCanonicalize (H12AffineFastState.compose env21863 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound21863 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,529,4096,349,1637,1,342,1653,868,1025,0,804,32,17,2,348,65,529,1652,4097,869,1365,33,257,32,1588,513]

theorem envBound21864 : H12AffineFastState.Bounded env21864 := by
  intro p hp
  have h : env21864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21863_21864 : H12AffineEnvironment.transform 10 529 env21863 = env21864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env21863 == env21864) = true)

theorem identity21864 : scanCanonicalize (H12AffineFastState.compose env21864 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound21864 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,529,869,349,1637,1,342,1653,868,1025,0,804,32,17,2,348,65,529,1652,868,869,1365,33,257,32,1588,513]

theorem envBound21865 : H12AffineFastState.Bounded env21865 := by
  intro p hp
  have h : env21865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21864_21865 : H12AffineEnvironment.transform 11 869 env21864 = env21865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env21864 == env21865) = true)

theorem identity21865 : scanCanonicalize (H12AffineFastState.compose env21865 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21865 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env21866 : List Nat := [2,4,8,16,32,17,9,256,512,1024,529,820,268,1588,1,263,1572,821,1025,0,804,32,17,2,269,16,529,1573,821,820,1284,33,257,32,1588,513]

theorem envBound21866 : H12AffineFastState.Bounded env21866 := by
  intro p hp
  have h : env21866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21865_21866 : H12AffineEnvironment.transform 5 17 env21865 = env21866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21865 == env21866) = true)

theorem identity21866 : scanCanonicalize (H12AffineFastState.compose env21866 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound21866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21867 : List Nat := [2,4,8,16,32,17,9,256,512,37,529,820,268,529,1,263,513,821,36,0,804,32,17,2,269,16,529,512,821,820,289,33,257,32,529,513]

theorem envBound21867 : H12AffineFastState.Bounded env21867 := by
  intro p hp
  have h : env21867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21866_21867 : H12AffineEnvironment.transform 9 37 env21866 = env21867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env21866 == env21867) = true)

theorem identity21867 : scanCanonicalize (H12AffineFastState.compose env21867 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound21867 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21868 : List Nat := [2,4,8,16,32,17,9,256,292,37,309,16,268,309,1,263,293,17,36,0,0,32,17,2,269,16,309,292,17,16,289,33,257,32,309,293]

theorem envBound21868 : H12AffineFastState.Bounded env21868 := by
  intro p hp
  have h : env21868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21867_21868 : H12AffineEnvironment.transform 8 292 env21867 = env21868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env21867 == env21868) = true)

def env21869 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,115735,73770,17,41310,8193,65,158029,57676,102743,190521,75102,73770,257,41341,16464,513]

theorem envBound21869 : H12AffineFastState.Bounded env21869 := by
  intro p hp
  have h : env21869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21857_21869 : H12AffineEnvironment.transform 17 10281 env21857 = env21869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env21857 == env21869) = true)

theorem identity21869 : scanCanonicalize (H12AffineFastState.compose env21869 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21869 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,10281,1025,32769,58397,32,17,41310,8193,65,158029,57676,45405,190521,1364,32,257,41341,16464,513]

theorem envBound21870 : H12AffineFastState.Bounded env21870 := by
  intro p hp
  have h : env21870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21869_21870 : H12AffineEnvironment.transform 15 8202 env21869 = env21870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21869 == env21870) = true)

theorem identity21870 : scanCanonicalize (H12AffineFastState.compose env21870 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 54544) := by decide +kernel

theorem selectedBound21870 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,54544,10281,1025,32769,58397,32,17,41310,8193,65,48221,57676,45405,15657,1364,32,257,41341,16464,513]

theorem envBound21871 : H12AffineFastState.Bounded env21871 := by
  intro p hp
  have h : env21871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21870_21871 : H12AffineEnvironment.transform 16 54544 env21870 = env21871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 54544 env21870 == env21871) = true)

theorem identity21871 : scanCanonicalize (H12AffineFastState.compose env21871 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound21871 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1361,8192,16384,32768,8202,49217,10281,1025,32769,58397,32,17,41310,8193,65,43276,57676,41996,10360,1364,32,257,41341,16464,513]

theorem envBound21872 : H12AffineFastState.Bounded env21872 := by
  intro p hp
  have h : env21872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21871_21872 : H12AffineEnvironment.transform 11 1361 env21871 = env21872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env21871 == env21872) = true)

theorem identity21872 : scanCanonicalize (H12AffineFastState.compose env21872 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound21872 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env21873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,8192,16384,32768,8202,49217,8312,1025,32769,58397,32,17,41310,8193,65,41309,57676,41996,8233,1364,32,257,41341,16464,513]

theorem envBound21873 : H12AffineFastState.Bounded env21873 := by
  intro p hp
  have h : env21873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21872_21873 : H12AffineEnvironment.transform 10 81 env21872 = env21873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env21872 == env21873) = true)

theorem identity21873 : scanCanonicalize (H12AffineFastState.compose env21873 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound21873 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env21874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,1052,16384,32768,1046,49217,1124,1025,32769,49153,32,17,34114,1053,65,34113,50512,32784,1077,1364,32,257,34145,16464,513]

theorem envBound21874 : H12AffineFastState.Bounded env21874 := by
  intro p hp
  have h : env21874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21873_21874 : H12AffineEnvironment.transform 12 1052 env21873 = env21874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env21873 == env21874) = true)

theorem identity21874 : scanCanonicalize (H12AffineFastState.compose env21874 (packedSelected [1,3,5,6,7,8,9,10,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21874 : packedSelected [1,3,5,6,7,8,9,10,18] rootPS < 2^1333 := by decide +kernel

def env21875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,81,1361,1052,16384,0,1046,16449,1124,1025,1,16385,32,17,1346,1053,65,1345,17744,16,1077,1364,32,257,1377,16464,513]

theorem envBound21875 : H12AffineFastState.Bounded env21875 := by
  intro p hp
  have h : env21875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21874_21875 : H12AffineEnvironment.transform 14 0 env21874 = env21875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21874 == env21875) = true)

theorem identity21875 : scanCanonicalize (H12AffineFastState.compose env21875 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21875 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21876 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1280,1052,16384,0,1046,16400,1077,1025,1,16385,32,17,1299,1053,16,1296,17665,16,1077,1285,32,257,1328,16385,513]

theorem envBound21876 : H12AffineFastState.Bounded env21876 := by
  intro p hp
  have h : env21876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21875_21876 : H12AffineEnvironment.transform 5 17 env21875 = env21876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21875 == env21876) = true)

theorem identity21876 : scanCanonicalize (H12AffineFastState.compose env21876 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 1070) := by decide +kernel

theorem selectedBound21876 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env21877 : List Nat := [2,4,8,16,32,17,9,256,512,1024,0,1280,1052,1070,0,1046,1086,1077,1025,1,1071,32,17,1299,1053,16,1296,303,16,1077,1285,32,257,1328,1071,513]

theorem envBound21877 : H12AffineFastState.Bounded env21877 := by
  intro p hp
  have h : env21877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21876_21877 : H12AffineEnvironment.transform 13 1070 env21876 = env21877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1070 env21876 == env21877) = true)

theorem identity21877 : scanCanonicalize (H12AffineFastState.compose env21877 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound21877 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21878 : List Nat := [2,4,8,16,32,17,9,256,512,30,0,286,2,48,0,8,32,43,31,1,49,32,17,269,3,16,270,303,16,43,283,32,257,302,49,513]

theorem envBound21878 : H12AffineFastState.Bounded env21878 := by
  intro p hp
  have h : env21878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21877_21878 : H12AffineEnvironment.transform 9 30 env21877 = env21878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env21877 == env21878) = true)

theorem identity21878 : scanCanonicalize (H12AffineFastState.compose env21878 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound21878 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env21879 : List Nat := [2,4,8,16,32,17,9,62,512,30,0,32,2,48,0,8,32,43,31,1,49,32,17,51,3,16,48,17,16,43,37,32,63,16,49,513]

theorem envBound21879 : H12AffineFastState.Bounded env21879 := by
  intro p hp
  have h : env21879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21878_21879 : H12AffineEnvironment.transform 7 62 env21878 = env21879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env21878 == env21879) = true)

theorem identity21879 : scanCanonicalize (H12AffineFastState.compose env21879 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21879 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env21880 : List Nat := [2,4,8,16,17,17,9,15,512,30,0,17,2,1,0,8,17,26,31,1,0,17,17,2,3,16,1,17,16,26,20,17,14,16,0,513]

theorem envBound21880 : H12AffineFastState.Bounded env21880 := by
  intro p hp
  have h : env21880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21879_21880 : H12AffineEnvironment.transform 4 17 env21879 = env21880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21879 == env21880) = true)

theorem identity21880 : scanCanonicalize (H12AffineFastState.compose env21880 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21881 : List Nat := [2,4,8,1,0,0,9,15,512,15,0,0,2,1,0,8,0,11,14,1,0,0,0,2,3,1,1,0,1,11,5,0,14,1,0,513]

theorem envBound21881 : H12AffineFastState.Bounded env21881 := by
  intro p hp
  have h : env21881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21880_21881 : H12AffineEnvironment.transform 3 1 env21880 = env21881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21880 == env21881) = true)

theorem identity21881 : scanCanonicalize (H12AffineFastState.compose env21881 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound21881 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21882 : List Nat := [2,4,8,1,0,0,9,15,3,15,0,0,2,1,0,8,0,11,14,1,0,0,0,2,3,1,1,0,1,11,5,0,14,1,0,2]

theorem envBound21882 : H12AffineFastState.Bounded env21882 := by
  intro p hp
  have h : env21882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21881_21882 : H12AffineEnvironment.transform 8 3 env21881 = env21882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env21881 == env21882) = true)

theorem identity21882 : scanCanonicalize (H12AffineFastState.compose env21882 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21882 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env21883 : List Nat := [2,4,3,1,0,0,2,4,3,4,0,0,2,1,0,3,0,0,5,1,0,0,0,2,3,1,1,0,1,0,5,0,5,1,0,2]

theorem envBound21883 : H12AffineFastState.Bounded env21883 := by
  intro p hp
  have h : env21883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21882_21883 : H12AffineEnvironment.transform 2 3 env21882 = env21883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21882 == env21883) = true)

theorem identity21883 : scanCanonicalize (H12AffineFastState.compose env21883 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound21883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21884 : List Nat := [2,0,3,1,0,0,2,0,3,0,0,0,2,1,0,3,0,0,1,1,0,0,0,2,3,1,1,0,1,0,1,0,1,1,0,2]

theorem envBound21884 : H12AffineFastState.Bounded env21884 := by
  intro p hp
  have h : env21884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21883_21884 : H12AffineEnvironment.transform 1 0 env21883 = env21884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env21883 == env21884) = true)

def env21885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507601,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound21885 : H12AffineFastState.Bounded env21885 := by
  intro p hp
  have h : env21885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21587_21885 : H12AffineEnvironment.transform 26 30393345 env21587 = env21885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env21587 == env21885) = true)

def env21886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound21886 : H12AffineFastState.Bounded env21886 := by
  intro p hp
  have h : env21886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21885_21886 : H12AffineEnvironment.transform 18 1024 env21885 = env21886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21885 == env21886) = true)

theorem identity21886 : scanCanonicalize (H12AffineFastState.compose env21886 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound21886 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,16777216,8328,65,29403623,18973837,10507601,8497639,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound21887 : H12AffineFastState.Bounded env21887 := by
  intro p hp
  have h : env21887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21886_21887 : H12AffineEnvironment.transform 17 223718 env21886 = env21887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env21886 == env21887) = true)

def env21888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,2199964,8328,65,14760059,5393,10507601,8497639,10491277,4256861,256,8410416,8434836,10564186]

theorem envBound21888 : H12AffineFastState.Bounded env21888 := by
  intro p hp
  have h : env21888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21887_21888 : H12AffineEnvironment.transform 23 2199964 env21887 = env21888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env21887 == env21888) = true)

def env21889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101328,2199964,8328,65,4270123,5393,17665,2210231,1501,4256861,256,2114912,2139332,74250]

theorem envBound21889 : H12AffineFastState.Bounded env21889 := by
  intro p hp
  have h : env21889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21888_21889 : H12AffineEnvironment.transform 22 2101328 env21888 = env21889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21888 == env21889) = true)

def env21890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,16,98780,8328,65,4270123,5393,17665,109047,1501,4256861,256,21792,46212,74250]

theorem envBound21890 : H12AffineFastState.Bounded env21890 := by
  intro p hp
  have h : env21890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21889_21890 : H12AffineEnvironment.transform 20 4160 env21889 = env21890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21889 == env21890) = true)

def env21891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,4194304,16,98644,8192,65,4270123,5393,17665,108927,1365,4256861,256,21792,46092,74250]

theorem envBound21891 : H12AffineFastState.Bounded env21891 := by
  intro p hp
  have h : env21891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21890_21891 : H12AffineEnvironment.transform 6 8 env21890 = env21891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21890 == env21891) = true)

theorem identity21891 : scanCanonicalize (H12AffineFastState.compose env21891 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound21891 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,108926,1024,32769,4160,4194304,16,98644,8192,65,4270123,5393,17665,108927,1365,4256861,256,21792,46092,74250]

theorem envBound21892 : H12AffineFastState.Bounded env21892 := by
  intro p hp
  have h : env21892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21891_21892 : H12AffineEnvironment.transform 16 49168 env21891 = env21892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env21891 == env21892) = true)

theorem identity21892 : scanCanonicalize (H12AffineFastState.compose env21892 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound21892 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5440,97326,1024,21841,4160,4194304,16,87044,8192,65,4270123,5393,17665,97327,1365,4202765,256,21792,24924,74250]

theorem envBound21893 : H12AffineFastState.Bounded env21893 := by
  intro p hp
  have h : env21893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21892_21893 : H12AffineEnvironment.transform 14 21840 env21892 = env21893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env21892 == env21893) = true)

theorem identity21893 : scanCanonicalize (H12AffineFastState.compose env21893 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 21873) := by decide +kernel

theorem selectedBound21893 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21840,65536,5440,97326,1024,21841,4160,21873,16,87044,8192,65,97626,5393,17665,97327,1365,29820,256,21792,24924,74250]

theorem envBound21894 : H12AffineFastState.Bounded env21894 := by
  intro p hp
  have h : env21894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21893_21894 : H12AffineEnvironment.transform 21 21873 env21893 = env21894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21873 env21893 == env21894) = true)

theorem identity21894 : scanCanonicalize (H12AffineFastState.compose env21894 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound21894 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env21895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8313,65536,5440,67847,1024,8312,4160,8280,16,74029,8192,65,67699,5393,12328,67846,1365,341,256,8201,5237,74250]

theorem envBound21895 : H12AffineFastState.Bounded env21895 := by
  intro p hp
  have h : env21895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21894_21895 : H12AffineEnvironment.transform 13 13609 env21894 = env21895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env21894 == env21895) = true)

theorem identity21895 : scanCanonicalize (H12AffineFastState.compose env21895 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound21895 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env21896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8313,114,5440,2421,1024,8312,4160,8280,16,8543,8192,65,2049,5393,12328,2420,1365,341,256,8201,5237,8824]

theorem envBound21896 : H12AffineFastState.Bounded env21896 := by
  intro p hp
  have h : env21896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21895_21896 : H12AffineEnvironment.transform 15 114 env21895 = env21896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env21895 == env21896) = true)

theorem identity21896 : scanCanonicalize (H12AffineFastState.compose env21896 (packedSelected [1,2,3,4,6,8,9,10,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21896 : packedSelected [1,2,3,4,6,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env21897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,81,114,5440,2421,1024,80,4160,112,16,375,40,65,2049,5393,4096,2420,1365,341,256,33,5237,592]

theorem envBound21897 : H12AffineFastState.Bounded env21897 := by
  intro p hp
  have h : env21897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21896_21897 : H12AffineEnvironment.transform 12 40 env21896 = env21897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21896 == env21897) = true)

theorem identity21897 : scanCanonicalize (H12AffineFastState.compose env21897 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21897 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21898 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,40,5156,81,114,5221,2128,1024,80,4160,112,16,82,40,65,2049,5172,4096,2129,1136,112,37,33,5237,592]

theorem envBound21898 : H12AffineFastState.Bounded env21898 := by
  intro p hp
  have h : env21898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21897_21898 : H12AffineEnvironment.transform 7 37 env21897 = env21898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21897 == env21898) = true)

theorem identity21898 : scanCanonicalize (H12AffineFastState.compose env21898 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21898 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21899 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,34,5173,2048,1024,0,4112,32,16,2,40,17,2049,5172,4096,2049,1056,32,37,33,5157,512]

theorem envBound21899 : H12AffineFastState.Bounded env21899 := by
  intro p hp
  have h : env21899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21898_21899 : H12AffineEnvironment.transform 5 16 env21898 = env21899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21898 == env21899) = true)

theorem identity21899 : scanCanonicalize (H12AffineFastState.compose env21899 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21900 : List Nat := [2,4,8,16,1,16,8,4,512,1024,2048,4096,9,5125,1,3,5140,2048,1024,0,4112,1,16,2,9,17,2049,5141,4096,2049,1025,1,4,0,5124,512]

theorem envBound21900 : H12AffineFastState.Bounded env21900 := by
  intro p hp
  have h : env21900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21899_21900 : H12AffineEnvironment.transform 4 1 env21899 = env21900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21899 == env21900) = true)

theorem identity21900 : scanCanonicalize (H12AffineFastState.compose env21900 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound21900 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21901 : List Nat := [2,4,8,16,1,16,8,4,512,1024,522,4096,9,5125,1,3,5140,522,1024,0,4112,1,16,2,9,17,523,5141,4096,523,1025,1,4,0,5124,512]

theorem envBound21901 : H12AffineFastState.Bounded env21901 := by
  intro p hp
  have h : env21901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21900_21901 : H12AffineEnvironment.transform 10 522 env21900 = env21901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env21900 == env21901) = true)

def env21902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,4194304,16,98645,8193,65,4270123,5393,17665,108926,1364,4256861,256,21792,46093,74250]

theorem envBound21902 : H12AffineFastState.Bounded env21902 := by
  intro p hp
  have h : env21902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21890_21902 : H12AffineEnvironment.transform 6 9 env21890 = env21902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21890 == env21902) = true)

theorem identity21902 : scanCanonicalize (H12AffineFastState.compose env21902 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound21902 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67619,1024,32769,4160,4194304,16,98645,8193,65,4270123,5393,17665,108926,1364,4256861,256,21792,46093,74250]

theorem envBound21903 : H12AffineFastState.Bounded env21903 := by
  intro p hp
  have h : env21903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21902_21903 : H12AffineEnvironment.transform 16 24908 env21902 = env21903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env21902 == env21903) = true)

theorem identity21903 : scanCanonicalize (H12AffineFastState.compose env21903 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound21903 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env21904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67619,1024,32769,4160,65910,16,98645,8193,65,10589,5393,17665,108926,1364,128299,256,21792,46093,74250]

theorem envBound21904 : H12AffineFastState.Bounded env21904 := by
  intro p hp
  have h : env21904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21903_21904 : H12AffineEnvironment.transform 21 65910 env21903 = env21904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env21903 == env21904) = true)

theorem identity21904 : scanCanonicalize (H12AffineFastState.compose env21904 (packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound21904 : packedSelected [2,4,5,6,10,11,12,15,16,18,19,22,24,31] rootPS < 2^1333 := by decide +kernel

def env21905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,64809,1024,32769,4160,62588,16,29791,8193,65,10589,5393,17665,23668,1364,33,256,21792,46093,55040]

theorem envBound21905 : H12AffineFastState.Bounded env21905 := by
  intro p hp
  have h : env21905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21904_21905 : H12AffineEnvironment.transform 15 62730 env21904 = env21905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env21904 == env21905) = true)

theorem identity21905 : scanCanonicalize (H12AffineFastState.compose env21905 (packedSelected [2,5,6,10,11,12,14,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound21905 : packedSelected [2,5,6,10,11,12,14,20,24] rootPS < 2^1333 := by decide +kernel

def env21906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,33031,5441,35108,1024,32769,4160,32881,16,82,8193,65,10589,5393,12556,10361,1364,33,256,8493,46093,41741]

theorem envBound21906 : H12AffineFastState.Bounded env21906 := by
  intro p hp
  have h : env21906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21905_21906 : H12AffineEnvironment.transform 13 13325 env21905 = env21906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env21905 == env21906) = true)

theorem identity21906 : scanCanonicalize (H12AffineFastState.compose env21906 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21906 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env21907 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,33031,5393,35108,1024,32769,4112,32801,16,2,8193,17,10509,5393,12556,10281,1284,33,256,8493,46093,41741]

theorem envBound21907 : H12AffineFastState.Bounded env21907 := by
  intro p hp
  have h : env21907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21906_21907 : H12AffineEnvironment.transform 5 16 env21906 = env21907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21906 == env21907) = true)

theorem identity21907 : scanCanonicalize (H12AffineFastState.compose env21907 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21907 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env21908 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,262,5393,2341,1024,0,4112,32,16,2,8193,17,10509,5393,12556,10281,1284,33,256,8493,13324,8972]

theorem envBound21908 : H12AffineFastState.Bounded env21908 := by
  intro p hp
  have h : env21908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21907_21908 : H12AffineEnvironment.transform 14 1 env21907 = env21908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21907 == env21908) = true)

theorem identity21908 : scanCanonicalize (H12AffineFastState.compose env21908 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound21908 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21909 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3109,8192,10280,1,262,2356,2341,1024,0,3125,32,16,2,8193,17,10509,2356,11561,10281,1284,33,256,8493,10281,8972]

theorem envBound21909 : H12AffineFastState.Bounded env21909 := by
  intro p hp
  have h : env21909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21908_21909 : H12AffineEnvironment.transform 11 3109 env21908 = env21909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env21908 == env21909) = true)

theorem identity21909 : scanCanonicalize (H12AffineFastState.compose env21909 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound21909 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env21910 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1029,32,8192,9261,1,262,1329,1312,1024,0,48,32,16,2,8193,17,9480,1329,8492,9260,1284,33,256,8493,9260,8972]

theorem envBound21910 : H12AffineFastState.Bounded env21910 := by
  intro p hp
  have h : env21910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21909_21910 : H12AffineEnvironment.transform 10 1029 env21909 = env21910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env21909 == env21910) = true)

theorem identity21910 : scanCanonicalize (H12AffineFastState.compose env21910 (packedSelected [2,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound21910 : packedSelected [2,6,10] rootPS < 2^1333 := by decide +kernel

def env21911 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1029,32,56,1045,1,262,1329,1312,1024,0,48,32,16,2,57,17,1328,1329,276,1044,1284,33,256,277,1044,820]

theorem envBound21911 : H12AffineFastState.Bounded env21911 := by
  intro p hp
  have h : env21911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21910_21911 : H12AffineEnvironment.transform 12 56 env21910 = env21911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env21910 == env21911) = true)

theorem identity21911 : scanCanonicalize (H12AffineFastState.compose env21911 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21912 : List Nat := [2,4,8,16,32,16,9,256,512,272,277,32,56,261,1,262,33,48,272,0,48,32,16,2,57,17,32,33,276,260,20,33,256,277,260,820]

theorem envBound21912 : H12AffineFastState.Bounded env21912 := by
  intro p hp
  have h : env21912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21911_21912 : H12AffineEnvironment.transform 9 272 env21911 = env21912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21911 == env21912) = true)

theorem identity21912 : scanCanonicalize (H12AffineFastState.compose env21912 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21912 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env21913 : List Nat := [2,4,8,16,32,16,9,53,512,37,32,32,56,48,1,51,33,48,37,0,48,32,16,2,57,17,32,33,33,49,20,33,53,32,49,513]

theorem envBound21913 : H12AffineFastState.Bounded env21913 := by
  intro p hp
  have h : env21913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21912_21913 : H12AffineEnvironment.transform 7 53 env21912 = env21913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21912 == env21913) = true)

theorem identity21913 : scanCanonicalize (H12AffineFastState.compose env21913 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound21913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21914 : List Nat := [2,4,8,16,2,16,9,23,512,7,2,2,26,18,1,17,3,18,7,0,18,2,16,2,27,17,2,3,3,19,20,3,23,2,19,513]

theorem envBound21914 : H12AffineFastState.Bounded env21914 := by
  intro p hp
  have h : env21914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21913_21914 : H12AffineEnvironment.transform 4 2 env21913 = env21914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env21913 == env21914) = true)

theorem identity21914 : scanCanonicalize (H12AffineFastState.compose env21914 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21914 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21915 : List Nat := [2,4,8,10,2,10,9,13,512,7,2,2,0,8,1,11,3,8,7,0,8,2,10,2,1,11,2,3,3,9,14,3,13,2,9,513]

theorem envBound21915 : H12AffineFastState.Bounded env21915 := by
  intro p hp
  have h : env21915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21914_21915 : H12AffineEnvironment.transform 3 10 env21914 = env21915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21914 == env21915) = true)

theorem identity21915 : scanCanonicalize (H12AffineFastState.compose env21915 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21915 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21916 : List Nat := [2,4,3,1,2,1,2,6,512,7,2,2,0,3,1,0,3,3,7,0,3,2,1,2,1,0,2,3,3,2,5,3,6,2,2,513]

theorem envBound21916 : H12AffineFastState.Bounded env21916 := by
  intro p hp
  have h : env21916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21915_21916 : H12AffineEnvironment.transform 2 3 env21915 = env21916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21915 == env21916) = true)

theorem identity21916 : scanCanonicalize (H12AffineFastState.compose env21916 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound21916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21917 : List Nat := [2,1,3,1,2,1,2,3,512,2,2,2,0,3,1,0,3,3,2,0,3,2,1,2,1,0,2,3,3,2,0,3,3,2,2,513]

theorem envBound21917 : H12AffineFastState.Bounded env21917 := by
  intro p hp
  have h : env21917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21916_21917 : H12AffineEnvironment.transform 1 1 env21916 = env21917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env21916 == env21917) = true)

def env21918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,17,98781,8328,65,4270123,5393,17665,109046,1501,4256861,256,21793,46213,74250]

theorem envBound21918 : H12AffineFastState.Bounded env21918 := by
  intro p hp
  have h : env21918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21889_21918 : H12AffineEnvironment.transform 20 4161 env21889 = env21918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21889 == env21918) = true)

theorem identity21918 : scanCanonicalize (H12AffineFastState.compose env21918 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169401) := by decide +kernel

theorem selectedBound21918 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,169401,17,98781,8328,65,245138,5393,17665,109046,1501,156132,256,21793,46213,74250]

theorem envBound21919 : H12AffineFastState.Bounded env21919 := by
  intro p hp
  have h : env21919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21918_21919 : H12AffineEnvironment.transform 21 169401 env21918 = env21919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env21918 == env21919) = true)

def env21920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169265,17,98645,8192,65,245018,5393,17665,108926,1365,156012,256,21793,46093,74250]

theorem envBound21920 : H12AffineFastState.Bounded env21920 := by
  intro p hp
  have h : env21920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21919_21920 : H12AffineEnvironment.transform 6 8 env21919 = env21920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21919 == env21920) = true)

theorem identity21920 : scanCanonicalize (H12AffineFastState.compose env21920 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21920 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21921 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4161,169265,17,2,8192,65,146509,5393,17665,10281,1365,156012,256,21793,46093,41821]

theorem envBound21921 : H12AffineFastState.Bounded env21921 := by
  intro p hp
  have h : env21921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21920_21921 : H12AffineEnvironment.transform 15 33111 env21920 = env21921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21920 == env21921) = true)

theorem identity21921 : scanCanonicalize (H12AffineFastState.compose env21921 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21921 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21922 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33111,131072,171061,1024,32769,4161,169265,17,2,8192,65,146509,5393,12557,10281,1365,136544,256,8493,46093,41821]

theorem envBound21922 : H12AffineFastState.Bounded env21922 := by
  intro p hp
  have h : env21922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21921_21922 : H12AffineEnvironment.transform 13 13324 env21921 = env21922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21921 == env21922) = true)

theorem identity21922 : scanCanonicalize (H12AffineFastState.compose env21922 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46393) := by decide +kernel

theorem selectedBound21922 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env21923 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,33111,46393,10508,1024,32769,4161,8200,17,2,8192,65,35188,5393,12557,10281,1365,41049,256,8493,46093,41821]

theorem envBound21923 : H12AffineFastState.Bounded env21923 := by
  intro p hp
  have h : env21923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21922_21923 : H12AffineEnvironment.transform 16 46393 env21922 = env21923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46393 env21922 == env21923) = true)

theorem identity21923 : scanCanonicalize (H12AffineFastState.compose env21923 (packedSelected [1,3,8,10,12,15,16,18,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21923 : packedSelected [1,3,8,10,12,15,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env21924 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,33111,37941,2048,1024,32769,4161,260,17,2,268,65,35188,5393,4097,2341,1365,33109,256,33,38145,33361]

theorem envBound21924 : H12AffineFastState.Bounded env21924 := by
  intro p hp
  have h : env21924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21923_21924 : H12AffineEnvironment.transform 12 268 env21923 = env21924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21923 == env21924) = true)

theorem identity21924 : scanCanonicalize (H12AffineFastState.compose env21924 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound21924 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,261,82,5424,2048,1024,260,4161,260,17,2,268,65,2161,5393,4097,2341,1365,80,256,33,5124,852]

theorem envBound21925 : H12AffineFastState.Bounded env21925 := by
  intro p hp
  have h : env21925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21924_21925 : H12AffineEnvironment.transform 14 261 env21924 = env21925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env21924 == env21925) = true)

theorem identity21925 : scanCanonicalize (H12AffineFastState.compose env21925 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21925 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env21926 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,261,2,5424,2048,1024,260,4113,260,17,2,268,17,2081,5393,4097,2341,1285,0,256,33,5124,772]

theorem envBound21926 : H12AffineFastState.Bounded env21926 := by
  intro p hp
  have h : env21926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21925_21926 : H12AffineEnvironment.transform 5 16 env21925 = env21926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21925 == env21926) = true)

theorem identity21926 : scanCanonicalize (H12AffineFastState.compose env21926 (packedSelected [0,1,2,6,7,8,10,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21926 : packedSelected [0,1,2,6,7,8,10,14] rootPS < 2^1333 := by decide +kernel

def env21927 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,268,5376,261,2,5392,2048,1024,260,4113,260,17,2,268,17,2049,5393,4097,2309,1285,0,256,1,5124,772]

theorem envBound21927 : H12AffineFastState.Bounded env21927 := by
  intro p hp
  have h : env21927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21926_21927 : H12AffineEnvironment.transform 4 0 env21926 = env21927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21926 == env21927) = true)

theorem identity21927 : scanCanonicalize (H12AffineFastState.compose env21927 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21927 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21928 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,9,5125,0,2,5141,2048,1024,1,4113,1,17,2,9,17,2049,5140,4097,2048,1024,0,5,1,5124,513]

theorem envBound21928 : H12AffineFastState.Bounded env21928 := by
  intro p hp
  have h : env21928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21927_21928 : H12AffineEnvironment.transform 7 5 env21927 = env21928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21927 == env21928) = true)

theorem identity21928 : scanCanonicalize (H12AffineFastState.compose env21928 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21929 : List Nat := [2,4,8,16,0,16,8,5,512,4,2048,4096,9,4097,0,2,4113,2048,4,1,4113,1,17,2,9,17,2049,4112,4097,2048,4,0,5,1,4096,513]

theorem envBound21929 : H12AffineFastState.Bounded env21929 := by
  intro p hp
  have h : env21929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21928_21929 : H12AffineEnvironment.transform 9 4 env21928 = env21929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21928 == env21929) = true)

theorem identity21929 : scanCanonicalize (H12AffineFastState.compose env21929 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound21929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21930 : List Nat := [2,4,8,16,0,16,8,5,512,4,2048,529,9,528,0,2,512,2048,4,1,512,1,17,2,9,17,2049,513,528,2048,4,0,5,1,529,513]

theorem envBound21930 : H12AffineFastState.Bounded env21930 := by
  intro p hp
  have h : env21930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21929_21930 : H12AffineEnvironment.transform 11 529 env21929 = env21930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env21929 == env21930) = true)

theorem identity21930 : scanCanonicalize (H12AffineFastState.compose env21930 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound21930 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21931 : List Nat := [2,4,8,16,0,16,8,5,512,4,513,529,9,528,0,2,512,513,4,1,512,1,17,2,9,17,512,513,528,513,4,0,5,1,529,513]

theorem envBound21931 : H12AffineFastState.Bounded env21931 := by
  intro p hp
  have h : env21931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21930_21931 : H12AffineEnvironment.transform 10 513 env21930 = env21931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env21930 == env21931) = true)

theorem identity21931 : scanCanonicalize (H12AffineFastState.compose env21931 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21931 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env21932 : List Nat := [2,4,8,1,0,1,8,5,512,4,513,512,9,513,0,2,512,513,4,1,512,1,0,2,9,0,512,513,513,513,4,0,5,1,512,513]

theorem envBound21932 : H12AffineFastState.Bounded env21932 := by
  intro p hp
  have h : env21932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21931_21932 : H12AffineEnvironment.transform 3 1 env21931 = env21932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21931 == env21932) = true)

theorem identity21932 : scanCanonicalize (H12AffineFastState.compose env21932 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21933 : List Nat := [2,4,8,1,0,1,8,5,1,4,0,1,9,0,0,2,1,0,4,1,1,1,0,2,9,0,1,0,0,0,4,0,5,1,1,0]

theorem envBound21933 : H12AffineFastState.Bounded env21933 := by
  intro p hp
  have h : env21933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21932_21933 : H12AffineEnvironment.transform 8 1 env21932 = env21933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21932 == env21933) = true)

theorem identity21933 : scanCanonicalize (H12AffineFastState.compose env21933 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound21933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21934 : List Nat := [2,4,2,1,0,1,2,5,1,4,0,1,3,0,0,2,1,0,4,1,1,1,0,2,3,0,1,0,0,0,4,0,5,1,1,0]

theorem envBound21934 : H12AffineFastState.Bounded env21934 := by
  intro p hp
  have h : env21934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21933_21934 : H12AffineEnvironment.transform 2 2 env21933 = env21934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env21933 == env21934) = true)

def env21935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,169264,17,98644,8193,65,245019,5393,17665,108927,1364,156013,256,21793,46092,74250]

theorem envBound21935 : H12AffineFastState.Bounded env21935 := by
  intro p hp
  have h : env21935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21919_21935 : H12AffineEnvironment.transform 6 9 env21919 = env21935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21919 == env21935) = true)

theorem identity21935 : scanCanonicalize (H12AffineFastState.compose env21935 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21935 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,169264,17,41311,8193,65,171280,5393,17665,35188,1364,156013,256,21793,46092,513]

theorem envBound21936 : H12AffineFastState.Bounded env21936 := by
  intro p hp
  have h : env21936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21935_21936 : H12AffineEnvironment.transform 15 8203 env21935 = env21936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21935 == env21936) = true)

theorem identity21936 : scanCanonicalize (H12AffineFastState.compose env21936 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound21936 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4161,54560,17,41311,8193,65,56576,5393,17665,35188,1364,8573,256,21793,46092,513]

theorem envBound21937 : H12AffineFastState.Bounded env21937 := by
  intro p hp
  have h : env21937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21936_21937 : H12AffineEnvironment.transform 16 16400 env21936 = env21937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env21936 == env21937) = true)

theorem identity21937 : scanCanonicalize (H12AffineFastState.compose env21937 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21937 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,2420,1024,8540,4161,29821,17,2,8193,65,31837,5393,17665,10281,1364,8573,256,21793,5457,513]

theorem envBound21938 : H12AffineFastState.Bounded env21938 := by
  intro p hp
  have h : env21938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21937_21938 : H12AffineEnvironment.transform 14 8541 env21937 = env21938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21937 == env21938) = true)

theorem identity21938 : scanCanonicalize (H12AffineFastState.compose env21938 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21938 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8203,5440,2420,1024,8540,4161,8493,17,2,8193,65,10509,5393,4177,10281,1364,8573,256,113,5457,513]

theorem envBound21939 : H12AffineFastState.Bounded env21939 := by
  intro p hp
  have h : env21939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21938_21939 : H12AffineEnvironment.transform 13 5456 env21938 = env21939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21938 == env21939) = true)

theorem identity21939 : scanCanonicalize (H12AffineFastState.compose env21939 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound21939 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,105,5456,308,98,5440,2420,1024,309,4161,324,17,2,104,65,2404,5393,4177,2112,1364,276,256,113,5457,513]

theorem envBound21940 : H12AffineFastState.Bounded env21940 := by
  intro p hp
  have h : env21940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21939_21940 : H12AffineEnvironment.transform 12 105 env21939 = env21940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env21939 == env21940) = true)

theorem identity21940 : scanCanonicalize (H12AffineFastState.compose env21940 (packedSelected [1,2,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21940 : packedSelected [1,2,6,8,12] rootPS < 2^1333 := by decide +kernel

def env21941 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,105,4404,308,98,4388,2420,100,309,4161,324,17,2,104,65,2404,4469,4177,2112,304,276,256,113,4405,513]

theorem envBound21941 : H12AffineFastState.Bounded env21941 := by
  intro p hp
  have h : env21941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21940_21941 : H12AffineEnvironment.transform 9 100 env21940 = env21941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21940 == env21941) = true)

theorem identity21941 : scanCanonicalize (H12AffineFastState.compose env21941 (packedSelected [1,3,5,8,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21941 : packedSelected [1,3,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env21942 : List Nat := [2,4,8,16,32,64,9,53,512,100,2048,4096,105,4097,1,98,4113,2113,100,0,4161,113,17,2,104,65,2129,4160,4177,2112,5,33,53,113,4096,513]

theorem envBound21942 : H12AffineFastState.Bounded env21942 := by
  intro p hp
  have h : env21942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21941_21942 : H12AffineEnvironment.transform 7 53 env21941 = env21942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21941 == env21942) = true)

def env21943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101329,2199964,8328,65,4270122,5393,17664,2210230,1500,4256861,256,2114913,2139333,74251]

theorem envBound21943 : H12AffineFastState.Bounded env21943 := by
  intro p hp
  have h : env21943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21888_21943 : H12AffineEnvironment.transform 22 2101329 env21888 = env21943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21888 == env21943) = true)

def env21944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,17,98780,8328,65,4270122,5393,17664,109046,1500,4256861,256,21793,46213,74251]

theorem envBound21944 : H12AffineFastState.Bounded env21944 := by
  intro p hp
  have h : env21944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21943_21944 : H12AffineEnvironment.transform 20 4160 env21943 = env21944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21943 == env21944) = true)

theorem identity21944 : scanCanonicalize (H12AffineFastState.compose env21944 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156012) := by decide +kernel

theorem selectedBound21944 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,156012,17,98780,8328,65,215366,5393,17664,109046,1500,169265,256,21793,46213,74251]

theorem envBound21945 : H12AffineFastState.Bounded env21945 := by
  intro p hp
  have h : env21945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21944_21945 : H12AffineEnvironment.transform 21 156012 env21944 = env21945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156012 env21944 == env21945) = true)

def env21946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,156012,17,98644,8192,65,215366,5393,17664,108926,1364,169265,256,21793,46093,74251]

theorem envBound21946 : H12AffineFastState.Bounded env21946 := by
  intro p hp
  have h : env21946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21945_21946 : H12AffineEnvironment.transform 6 8 env21945 = env21946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21945 == env21946) = true)

theorem identity21946 : scanCanonicalize (H12AffineFastState.compose env21946 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound21946 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190520,1024,32769,4160,156012,17,2,8192,65,182288,5393,17664,10280,1364,169265,256,21793,46093,41821]

theorem envBound21947 : H12AffineFastState.Bounded env21947 := by
  intro p hp
  have h : env21947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21946_21947 : H12AffineEnvironment.transform 15 33110 env21946 = env21947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env21946 == env21947) = true)

theorem identity21947 : scanCanonicalize (H12AffineFastState.compose env21947 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21947 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,149860,1024,8541,4160,156012,17,2,8192,65,158028,5393,17664,10280,1364,144493,256,21793,5457,513]

theorem envBound21948 : H12AffineFastState.Bounded env21948 := by
  intro p hp
  have h : env21948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21947_21948 : H12AffineEnvironment.transform 14 8540 env21947 = env21948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21947 == env21948) = true)

theorem identity21948 : scanCanonicalize (H12AffineFastState.compose env21948 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound21948 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,5173,23889,1024,8541,4160,30041,17,2,8192,65,32121,5393,17664,10280,1364,8280,256,21793,5457,513]

theorem envBound21949 : H12AffineFastState.Bounded env21949 := by
  intro p hp
  have h : env21949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21948_21949 : H12AffineEnvironment.transform 16 5173 env21948 = env21949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env21948 == env21949) = true)

theorem identity21949 : scanCanonicalize (H12AffineFastState.compose env21949 (packedSelected [1,2,8,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound21949 : packedSelected [1,2,8,10,14] rootPS < 2^1333 := by decide +kernel

def env21950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,1345,1047,5173,23889,1024,1344,4160,20804,17,2,1053,65,22884,5393,17664,3125,1364,1093,256,21793,5457,513]

theorem envBound21950 : H12AffineFastState.Bounded env21950 := by
  intro p hp
  have h : env21950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21949_21950 : H12AffineEnvironment.transform 12 1053 env21949 = env21950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env21949 == env21950) = true)

theorem identity21950 : scanCanonicalize (H12AffineFastState.compose env21950 (packedSelected [0,1,2,6,7,8,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound21950 : packedSelected [0,1,2,6,7,8,10,16] rootPS < 2^1333 := by decide +kernel

def env21951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,5156,1345,1047,5173,2421,1024,1344,4160,1376,17,2,1053,65,3392,5393,4388,3125,1364,1093,256,261,5457,513]

theorem envBound21951 : H12AffineFastState.Bounded env21951 := by
  intro p hp
  have h : env21951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21950_21951 : H12AffineEnvironment.transform 13 5156 env21950 = env21951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env21950 == env21951) = true)

theorem identity21951 : scanCanonicalize (H12AffineFastState.compose env21951 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21951 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env21952 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,41,4112,373,35,4097,2421,52,372,4160,340,17,2,41,65,2420,4389,4388,2049,352,113,256,261,4453,513]

theorem envBound21952 : H12AffineFastState.Bounded env21952 := by
  intro p hp
  have h : env21952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21951_21952 : H12AffineEnvironment.transform 9 52 env21951 = env21952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21951 == env21952) = true)

theorem identity21952 : scanCanonicalize (H12AffineFastState.compose env21952 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21953 : List Nat := [2,4,8,16,32,64,8,117,512,52,2048,4096,41,4112,0,35,4097,2048,52,1,4160,33,17,2,41,65,2049,4176,4177,2049,21,113,117,112,4112,513]

theorem envBound21953 : H12AffineFastState.Bounded env21953 := by
  intro p hp
  have h : env21953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21952_21953 : H12AffineEnvironment.transform 7 117 env21952 = env21953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21952 == env21953) = true)

def env21954 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,156012,17,98645,8193,65,215366,5393,17664,108927,1365,169265,256,21793,46092,74251]

theorem envBound21954 : H12AffineFastState.Bounded env21954 := by
  intro p hp
  have h : env21954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21945_21954 : H12AffineEnvironment.transform 6 9 env21945 = env21954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21945 == env21954) = true)

theorem identity21954 : scanCanonicalize (H12AffineFastState.compose env21954 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21954 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149861,1024,32769,4160,156012,17,41311,8193,65,158028,5393,17664,35189,1365,169265,256,21793,46092,513]

theorem envBound21955 : H12AffineFastState.Bounded env21955 := by
  intro p hp
  have h : env21955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21954_21955 : H12AffineEnvironment.transform 15 8202 env21954 = env21955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21954 == env21955) = true)

theorem identity21955 : scanCanonicalize (H12AffineFastState.compose env21955 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound21955 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4160,8573,17,41311,8193,65,10589,5393,17664,35189,1365,54560,256,21793,46092,513]

theorem envBound21956 : H12AffineFastState.Bounded env21956 := by
  intro p hp
  have h : env21956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21955_21956 : H12AffineEnvironment.transform 16 16401 env21955 = env21956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env21955 == env21956) = true)

theorem identity21956 : scanCanonicalize (H12AffineFastState.compose env21956 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21956 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,16401,2420,1024,8541,4160,8573,17,3,8193,65,10589,5393,17664,10281,1365,29820,256,21793,5456,513]

theorem envBound21957 : H12AffineFastState.Bounded env21957 := by
  intro p hp
  have h : env21957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21956_21957 : H12AffineEnvironment.transform 14 8540 env21956 = env21957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21956 == env21957) = true)

theorem identity21957 : scanCanonicalize (H12AffineFastState.compose env21957 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound21957 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8540,8202,13340,2420,1024,8541,4160,8573,17,3,8193,65,10589,5393,12557,10281,1365,113,256,8492,5456,513]

theorem envBound21958 : H12AffineFastState.Bounded env21958 := by
  intro p hp
  have h : env21958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21957_21958 : H12AffineEnvironment.transform 13 13325 env21957 = env21958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env21957 == env21958) = true)

theorem identity21958 : scanCanonicalize (H12AffineFastState.compose env21958 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21958 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21959 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,12392,8540,8202,12409,2420,101,8541,4160,8573,17,3,8193,65,10589,4468,12557,10281,304,113,256,8492,4405,513]

theorem envBound21959 : H12AffineFastState.Bounded env21959 := by
  intro p hp
  have h : env21959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21958_21959 : H12AffineEnvironment.transform 9 101 env21958 = env21959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21958 == env21959) = true)

theorem identity21959 : scanCanonicalize (H12AffineFastState.compose env21959 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21959 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env21960 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,349,4405,1,343,4388,2420,101,0,4160,32,17,3,348,65,2048,4468,4176,2420,304,113,256,113,4405,513]

theorem envBound21960 : H12AffineFastState.Bounded env21960 := by
  intro p hp
  have h : env21960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21959_21960 : H12AffineEnvironment.transform 12 349 env21959 = env21960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21959 == env21960) = true)

theorem identity21960 : scanCanonicalize (H12AffineFastState.compose env21960 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21960 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21961 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,1,262,4388,2341,52,0,4113,32,17,3,269,16,2048,4389,4097,2341,304,32,256,32,4405,513]

theorem envBound21961 : H12AffineFastState.Bounded env21961 := by
  intro p hp
  have h : env21961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21960_21961 : H12AffineEnvironment.transform 5 17 env21960 = env21961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21960 == env21961) = true)

theorem identity21961 : scanCanonicalize (H12AffineFastState.compose env21961 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21962 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4112,1,35,4097,2048,52,0,4113,32,17,3,40,16,2048,4096,4097,2048,21,32,37,32,4112,513]

theorem envBound21962 : H12AffineFastState.Bounded env21962 := by
  intro p hp
  have h : env21962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21961_21962 : H12AffineEnvironment.transform 7 37 env21961 = env21962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21961 == env21962) = true)

theorem identity21962 : scanCanonicalize (H12AffineFastState.compose env21962 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound21962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21963 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2609,41,2593,1,35,2608,2048,52,0,2592,32,17,3,40,16,2048,2609,2608,2048,21,32,37,32,2593,513]

theorem envBound21963 : H12AffineFastState.Bounded env21963 := by
  intro p hp
  have h : env21963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21962_21963 : H12AffineEnvironment.transform 11 2609 env21962 = env21963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env21962 == env21963) = true)

theorem identity21963 : scanCanonicalize (H12AffineFastState.compose env21963 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound21963 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21964 : List Nat := [2,4,8,16,32,17,9,37,512,52,17,544,41,560,1,35,545,17,52,0,561,32,17,3,40,16,17,544,545,17,21,32,37,32,560,513]

theorem envBound21964 : H12AffineFastState.Bounded env21964 := by
  intro p hp
  have h : env21964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21963_21964 : H12AffineEnvironment.transform 10 17 env21963 = env21964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env21963 == env21964) = true)

def env21965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,16,98781,8328,65,4270122,5393,17664,109047,1500,4256861,256,21792,46212,74251]

theorem envBound21965 : H12AffineFastState.Bounded env21965 := by
  intro p hp
  have h : env21965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21943_21965 : H12AffineEnvironment.transform 20 4161 env21943 = env21965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21943 == env21965) = true)

theorem identity21965 : scanCanonicalize (H12AffineFastState.compose env21965 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21965 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,223718,1024,29908,4161,4194304,16,95496,8328,65,4270122,5393,17664,89378,1500,4194440,256,21792,16465,74251]

theorem envBound21966 : H12AffineFastState.Bounded env21966 := by
  intro p hp
  have h : env21966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21965_21966 : H12AffineEnvironment.transform 14 29909 env21965 = env21966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21965 == env21966) = true)

def env21967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212198,1024,8660,4161,4194304,16,73736,8328,65,4270122,5393,4096,67618,1500,4194440,256,32,5457,74251]

theorem envBound21967 : H12AffineFastState.Bounded env21967 := by
  intro p hp
  have h : env21967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21966_21967 : H12AffineEnvironment.transform 13 5376 env21966 = env21967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21966 == env21967) = true)

theorem identity21967 : scanCanonicalize (H12AffineFastState.compose env21967 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound21967 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13508,67618,1024,8660,4161,4194304,16,73736,8328,65,4270122,5393,4096,67618,1500,4194440,256,32,5457,74251]

theorem envBound21968 : H12AffineFastState.Bounded env21968 := by
  intro p hp
  have h : env21968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21967_21968 : H12AffineEnvironment.transform 16 13508 env21967 = env21968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env21967 == env21968) = true)

theorem identity21968 : scanCanonicalize (H12AffineFastState.compose env21968 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21968 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env21969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,13508,10280,1024,8660,4161,4194304,16,2,8328,65,4196384,5393,4096,10280,1500,4194440,256,32,5457,513]

theorem envBound21969 : H12AffineFastState.Bounded env21969 := by
  intro p hp
  have h : env21969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21968_21969 : H12AffineEnvironment.transform 15 8202 env21968 = env21969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21968 == env21969) = true)

theorem identity21969 : scanCanonicalize (H12AffineFastState.compose env21969 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound21969 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8202,13508,10280,1024,8660,4161,112,16,2,8328,65,2128,5393,4096,10280,1500,248,256,32,5457,513]

theorem envBound21970 : H12AffineFastState.Bounded env21970 := by
  intro p hp
  have h : env21970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21969_21970 : H12AffineEnvironment.transform 21 112 env21969 = env21970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env21969 == env21970) = true)

theorem identity21970 : scanCanonicalize (H12AffineFastState.compose env21970 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21970 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env21971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,137,342,5528,2420,1024,136,4161,112,16,2,468,65,2128,5393,4096,2420,1500,248,256,32,5457,513]

theorem envBound21971 : H12AffineFastState.Bounded env21971 := by
  intro p hp
  have h : env21971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21970_21971 : H12AffineEnvironment.transform 12 348 env21970 = env21971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21970 == env21971) = true)

theorem identity21971 : scanCanonicalize (H12AffineFastState.compose env21971 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21971 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21972 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,2420,1024,1,4161,112,16,2,349,65,2128,5393,4096,2420,1365,113,256,32,5457,513]

theorem envBound21972 : H12AffineFastState.Bounded env21972 := by
  intro p hp
  have h : env21972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21971_21972 : H12AffineEnvironment.transform 6 9 env21971 = env21972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21971 == env21972) = true)

def env21973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212199,1024,8661,4161,4194304,16,73737,8328,65,4270122,5393,4097,67619,1500,4194440,256,33,5456,74251]

theorem envBound21973 : H12AffineFastState.Bounded env21973 := by
  intro p hp
  have h : env21973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21966_21973 : H12AffineEnvironment.transform 13 5377 env21966 = env21973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env21966 == env21973) = true)

theorem identity21973 : scanCanonicalize (H12AffineFastState.compose env21973 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound21973 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,67755,1024,8661,4161,4194304,16,73737,8328,65,4270122,5393,4097,67619,1500,4194440,256,33,5456,74251]

theorem envBound21974 : H12AffineFastState.Bounded env21974 := by
  intro p hp
  have h : env21974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21973_21974 : H12AffineEnvironment.transform 16 13388 env21973 = env21974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env21973 == env21974) = true)

theorem identity21974 : scanCanonicalize (H12AffineFastState.compose env21974 (packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound21974 : packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS < 2^1333 := by decide +kernel

def env21975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13388,67755,1024,8661,4161,8572,16,73737,8328,65,67926,5393,4097,67619,1500,8692,256,33,5456,74251]

theorem envBound21975 : H12AffineFastState.Bounded env21975 := by
  intro p hp
  have h : env21975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21974_21975 : H12AffineEnvironment.transform 21 8572 env21974 = env21975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env21974 == env21975) = true)

theorem identity21975 : scanCanonicalize (H12AffineFastState.compose env21975 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21975 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env21976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,398,13388,2341,1024,8661,4161,8572,16,8583,8328,65,2264,5393,4097,2477,1500,8692,256,33,5456,9093]

theorem envBound21976 : H12AffineFastState.Bounded env21976 := by
  intro p hp
  have h : env21976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21975_21976 : H12AffineEnvironment.transform 15 398 env21975 = env21976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21975 == env21976) = true)

theorem identity21976 : scanCanonicalize (H12AffineFastState.compose env21976 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21976 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env21977 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,398,13340,2341,1024,8581,4113,8492,16,8583,8328,17,2184,5393,4097,2477,1420,8612,256,33,5376,9093]

theorem envBound21977 : H12AffineFastState.Bounded env21977 := by
  intro p hp
  have h : env21977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21976_21977 : H12AffineEnvironment.transform 5 16 env21976 = env21977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21976 == env21977) = true)

theorem identity21977 : scanCanonicalize (H12AffineFastState.compose env21977 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21977 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env21978 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,137,398,5393,2341,1024,136,4113,33,16,138,389,17,2184,5393,4097,2477,1420,169,256,33,5376,648]

theorem envBound21978 : H12AffineFastState.Bounded env21978 := by
  intro p hp
  have h : env21978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21977_21978 : H12AffineEnvironment.transform 12 269 env21977 = env21978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21977 == env21978) = true)

theorem identity21978 : scanCanonicalize (H12AffineFastState.compose env21978 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1464) := by decide +kernel

theorem selectedBound21978 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21979 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1464,4096,269,5377,137,398,5393,1181,1024,136,4113,33,16,138,389,17,1328,5393,4097,1045,1420,169,256,33,5376,648]

theorem envBound21979 : H12AffineFastState.Bounded env21979 := by
  intro p hp
  have h : env21979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21978_21979 : H12AffineEnvironment.transform 10 1464 env21978 = env21979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1464 env21978 == env21979) = true)

theorem identity21979 : scanCanonicalize (H12AffineFastState.compose env21979 (packedSelected [0,2,3,4,5,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound21979 : packedSelected [0,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21980 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1464,1028,269,261,137,398,277,1181,1024,136,1045,33,16,138,389,17,1328,277,1029,1045,1420,169,256,33,260,648]

theorem envBound21980 : H12AffineFastState.Bounded env21980 := by
  intro p hp
  have h : env21980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21979_21980 : H12AffineEnvironment.transform 11 1028 env21979 = env21980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env21979 == env21980) = true)

theorem identity21980 : scanCanonicalize (H12AffineFastState.compose env21980 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound21980 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21981 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1045,1028,160,168,137,35,184,1181,1024,136,1045,33,16,138,40,17,1181,184,1029,1045,1057,169,173,33,169,648]

theorem envBound21981 : H12AffineFastState.Bounded env21981 := by
  intro p hp
  have h : env21981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21980_21981 : H12AffineEnvironment.transform 7 173 env21980 = env21981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env21980 == env21981) = true)

theorem identity21981 : scanCanonicalize (H12AffineFastState.compose env21981 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21981 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21982 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1045,1028,41,33,0,35,49,1044,1024,1,1045,33,16,3,40,17,1044,49,1029,1045,1057,32,36,33,32,513]

theorem envBound21982 : H12AffineFastState.Bounded env21982 := by
  intro p hp
  have h : env21982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21981_21982 : H12AffineEnvironment.transform 6 9 env21981 = env21982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21981 == env21982) = true)

theorem identity21982 : scanCanonicalize (H12AffineFastState.compose env21982 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound21982 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21983 : List Nat := [2,4,8,16,32,16,9,36,52,1024,1045,1028,41,33,0,35,49,1044,1024,1,1045,33,16,3,40,17,1044,49,1029,1045,1057,32,36,33,32,53]

theorem envBound21983 : H12AffineFastState.Bounded env21983 := by
  intro p hp
  have h : env21983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21982_21983 : H12AffineEnvironment.transform 8 52 env21982 = env21983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env21982 == env21983) = true)

theorem identity21983 : scanCanonicalize (H12AffineFastState.compose env21983 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21984 : List Nat := [2,4,8,16,32,16,9,36,52,53,32,49,41,33,0,35,49,33,53,1,32,33,16,3,40,17,33,49,48,32,20,32,36,33,32,53]

theorem envBound21984 : H12AffineFastState.Bounded env21984 := by
  intro p hp
  have h : env21984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21983_21984 : H12AffineEnvironment.transform 9 53 env21983 = env21984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21983 == env21984) = true)

theorem identity21984 : scanCanonicalize (H12AffineFastState.compose env21984 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound21984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21985 : List Nat := [2,4,8,9,32,9,9,36,45,44,32,40,41,33,0,35,40,33,44,1,32,33,9,3,40,8,33,40,41,32,13,32,36,33,32,44]

theorem envBound21985 : H12AffineFastState.Bounded env21985 := by
  intro p hp
  have h : env21985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21984_21985 : H12AffineEnvironment.transform 3 9 env21984 = env21985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env21984 == env21985) = true)

theorem identity21985 : scanCanonicalize (H12AffineFastState.compose env21985 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound21985 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21986 : List Nat := [2,3,8,9,32,9,9,35,42,43,32,40,41,33,0,35,40,33,43,1,32,33,9,3,40,8,33,40,41,32,10,32,35,33,32,43]

theorem envBound21986 : H12AffineFastState.Bounded env21986 := by
  intro p hp
  have h : env21986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21985_21986 : H12AffineEnvironment.transform 1 3 env21985 = env21986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env21985 == env21986) = true)

def env21987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,8388608,2199965,8328,65,14760058,5392,10507601,8497639,10491276,4256860,256,8410417,8434837,10564187]

theorem envBound21987 : H12AffineFastState.Bounded env21987 := by
  intro p hp
  have h : env21987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21887_21987 : H12AffineEnvironment.transform 23 2199965 env21887 = env21987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env21887 == env21987) = true)

def env21988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101328,2199965,8328,65,4270122,5392,17665,2210231,1500,4256860,256,2114913,2139333,74251]

theorem envBound21988 : H12AffineFastState.Bounded env21988 := by
  intro p hp
  have h : env21988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21987_21988 : H12AffineEnvironment.transform 22 2101328 env21987 = env21988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env21987 == env21988) = true)

def env21989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,16,98781,8328,65,4270122,5392,17665,109047,1500,4256860,256,21793,46213,74251]

theorem envBound21989 : H12AffineFastState.Bounded env21989 := by
  intro p hp
  have h : env21989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21988_21989 : H12AffineEnvironment.transform 20 4160 env21988 = env21989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21988 == env21989) = true)

theorem identity21989 : scanCanonicalize (H12AffineFastState.compose env21989 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound21989 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,179512,1024,32769,4160,4194304,16,21763,8328,65,4259060,5392,17665,32041,1500,4256860,256,21793,46213,63189]

theorem envBound21990 : H12AffineFastState.Bounded env21990 := by
  intro p hp
  have h : env21990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21989_21990 : H12AffineEnvironment.transform 15 54494 env21989 = env21990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env21989 == env21990) = true)

def env21991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1024,32769,4160,4194304,16,21763,8192,65,4258940,5392,17665,32041,1364,4256860,256,21793,46093,63069]

theorem envBound21991 : H12AffineFastState.Bounded env21991 := by
  intro p hp
  have h : env21991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21990_21991 : H12AffineEnvironment.transform 6 8 env21990 = env21991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21990 == env21991) = true)

theorem identity21991 : scanCanonicalize (H12AffineFastState.compose env21991 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound21991 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32041,1024,32769,4160,4194304,16,21763,8192,65,4258940,5392,17665,32041,1364,4256860,256,21793,46093,63069]

theorem envBound21992 : H12AffineFastState.Bounded env21992 := by
  intro p hp
  have h : env21992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21991_21992 : H12AffineEnvironment.transform 16 49169 env21991 = env21992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21991 == env21992) = true)

theorem identity21992 : scanCanonicalize (H12AffineFastState.compose env21992 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound21992 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env21993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,32041,1024,32769,4160,32800,16,21763,8192,65,31836,5392,17665,32041,1364,29820,256,21793,46093,63069]

theorem envBound21993 : H12AffineFastState.Bounded env21993 := by
  intro p hp
  have h : env21993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21992_21993 : H12AffineEnvironment.transform 21 32800 env21992 = env21993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env21992 == env21993) = true)

theorem identity21993 : scanCanonicalize (H12AffineFastState.compose env21993 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21993 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env21994 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,24908,32041,1024,8540,4160,8573,16,21763,8192,65,31836,5392,17665,32041,1364,29820,256,21793,5456,22272]

theorem envBound21994 : H12AffineFastState.Bounded env21994 := by
  intro p hp
  have h : env21994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21993_21994 : H12AffineEnvironment.transform 14 8541 env21993 = env21994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21993 == env21994) = true)

theorem identity21994 : scanCanonicalize (H12AffineFastState.compose env21994 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21994 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env21995 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,28699,24908,30777,272,8540,4160,8573,16,20499,8192,65,31052,4096,16401,30777,68,29036,256,20529,4160,21008]

theorem envBound21995 : H12AffineFastState.Bounded env21995 := by
  intro p hp
  have h : env21995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21994_21995 : H12AffineEnvironment.transform 9 272 env21994 = env21995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21994 == env21995) = true)

theorem identity21995 : scanCanonicalize (H12AffineFastState.compose env21995 (packedSelected [2,3,4,5,6,9,11,15,19] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound21995 : packedSelected [2,3,4,5,6,9,11,15,19] rootPS < 2^1333 := by decide +kernel

def env21996 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,6476,16384,6161,18775,22528,16757,272,6160,4160,6193,16,20499,6476,65,16384,4096,16401,16757,68,18464,256,20529,4160,21008]

theorem envBound21996 : H12AffineFastState.Bounded env21996 := by
  intro p hp
  have h : env21996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21995_21996 : H12AffineEnvironment.transform 12 6476 env21995 = env21996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env21995 == env21996) = true)

theorem identity21996 : scanCanonicalize (H12AffineFastState.compose env21996 (packedSelected [0,4,7,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound21996 : packedSelected [0,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env21997 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,4096,4380,16384,4161,16647,20560,16757,272,4160,4160,4193,16,20499,4380,65,16384,4096,16401,16757,68,16496,256,20529,4160,21008]

theorem envBound21997 : H12AffineFastState.Bounded env21997 := by
  intro p hp
  have h : env21997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21996_21997 : H12AffineEnvironment.transform 10 80 env21996 = env21997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env21996 == env21997) = true)

theorem identity21997 : scanCanonicalize (H12AffineFastState.compose env21997 (packedSelected [0,1,2,3,5,6,7,8,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound21997 : packedSelected [0,1,2,3,5,6,7,8,15,20] rootPS < 2^1333 := by decide +kernel

def env21998 : List Nat := [2,4,8,16,32,64,8,256,512,272,80,65,349,16384,0,16647,16401,16757,272,1,1,32,16,16466,349,65,16384,65,16401,16757,68,16496,256,16496,1,16977]

theorem envBound21998 : H12AffineFastState.Bounded env21998 := by
  intro p hp
  have h : env21998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21997_21998 : H12AffineEnvironment.transform 11 65 env21997 = env21998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env21997 == env21998) = true)

theorem identity21998 : scanCanonicalize (H12AffineFastState.compose env21998 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21998 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21999 : List Nat := [2,4,8,16,32,16,8,256,512,272,0,17,269,16384,0,16647,16401,16677,272,1,1,32,16,16386,269,17,16384,17,16401,16677,20,16416,256,16416,1,16897]

theorem envBound21999 : H12AffineFastState.Bounded env21999 := by
  intro p hp
  have h : env21999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21998_21999 : H12AffineEnvironment.transform 5 16 env21998 = env21999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21998 == env21999) = true)

theorem identity21999 : scanCanonicalize (H12AffineFastState.compose env21999 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21999 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env22000 : List Nat := [2,4,8,16,32,16,8,36,512,52,0,17,41,16384,0,16419,16401,16385,52,1,1,32,16,16386,41,17,16384,17,16401,16385,20,16416,36,16416,1,16897]

theorem envBound22000 : H12AffineFastState.Bounded env22000 := by
  intro p hp
  have h : env22000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21999_22000 : H12AffineEnvironment.transform 7 36 env21999 = env22000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21999 == env22000) = true)

theorem identity22000 : scanCanonicalize (H12AffineFastState.compose env22000 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound22000 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env22001 : List Nat := [2,4,8,16,32,16,8,36,48,52,0,17,41,16384,0,16419,16401,16385,52,1,1,32,16,16386,41,17,16384,17,16401,16385,20,16416,36,16416,1,16433]

theorem envBound22001 : H12AffineFastState.Bounded env22001 := by
  intro p hp
  have h : env22001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22000_22001 : H12AffineEnvironment.transform 8 48 env22000 = env22001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env22000 == env22001) = true)

theorem identity22001 : scanCanonicalize (H12AffineFastState.compose env22001 (packedSelected [1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22001 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env22002 : List Nat := [2,4,8,16,1,16,8,5,17,21,0,17,8,16384,0,16386,16401,16385,21,1,1,1,16,16386,8,17,16384,17,16401,16385,20,16385,5,16385,1,16400]

theorem envBound22002 : H12AffineFastState.Bounded env22002 := by
  intro p hp
  have h : env22002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22001_22002 : H12AffineEnvironment.transform 4 1 env22001 = env22002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22001 == env22002) = true)

theorem identity22002 : scanCanonicalize (H12AffineFastState.compose env22002 (packedSelected [0,1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound22002 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env22003 : List Nat := [2,4,8,16,1,16,8,5,17,21,0,17,8,1,0,3,16,0,21,1,1,1,16,3,8,17,1,17,16,0,20,0,5,0,1,17]

theorem envBound22003 : H12AffineFastState.Bounded env22003 := by
  intro p hp
  have h : env22003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22002_22003 : H12AffineEnvironment.transform 13 1 env22002 = env22003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env22002 == env22003) = true)

def env22004 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,4194304,16,21763,8193,65,4258941,5392,17665,32041,1365,4256860,256,21793,46092,63068]

theorem envBound22004 : H12AffineFastState.Bounded env22004 := by
  intro p hp
  have h : env22004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21990_22004 : H12AffineEnvironment.transform 6 9 env21990 = env22004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21990 == env22004) = true)

theorem identity22004 : scanCanonicalize (H12AffineFastState.compose env22004 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound22004 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22005 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,56437,1024,32769,4160,4194304,16,21763,8193,65,4258941,5392,17665,32041,1365,4256860,256,21793,46092,63068]

theorem envBound22005 : H12AffineFastState.Bounded env22005 := by
  intro p hp
  have h : env22005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22004_22005 : H12AffineEnvironment.transform 16 24909 env22004 = env22005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env22004 == env22005) = true)

theorem identity22005 : scanCanonicalize (H12AffineFastState.compose env22005 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound22005 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env22006 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,24909,10280,1024,29788,4160,4194304,16,21763,8193,65,4196384,5392,17665,32041,1365,4194305,256,21793,16465,513]

theorem envBound22006 : H12AffineFastState.Bounded env22006 := by
  intro p hp
  have h : env22006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22005_22006 : H12AffineEnvironment.transform 14 29789 env22005 = env22006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env22005 == env22006) = true)

theorem identity22006 : scanCanonicalize (H12AffineFastState.compose env22006 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound22006 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22007 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,24909,10280,1024,29788,4160,8492,16,21763,8193,65,10508,5392,17665,32041,1365,8493,256,21793,16465,513]

theorem envBound22007 : H12AffineFastState.Bounded env22007 := by
  intro p hp
  have h : env22007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22006_22007 : H12AffineEnvironment.transform 21 8492 env22006 = env22007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env22006 == env22007) = true)

theorem identity22007 : scanCanonicalize (H12AffineFastState.compose env22007 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22007 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22008 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,8202,24861,10280,1024,29708,4112,8492,16,21763,8193,17,10508,5392,17665,32041,1285,8493,256,21793,16385,513]

theorem envBound22008 : H12AffineFastState.Bounded env22008 := by
  intro p hp
  have h : env22008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22007_22008 : H12AffineEnvironment.transform 5 16 env22007 = env22008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22007 == env22008) = true)

theorem identity22008 : scanCanonicalize (H12AffineFastState.compose env22008 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22009 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,262,16401,2340,1024,21760,4112,32,16,21763,269,17,2048,5392,17665,23589,1285,33,256,21793,16385,513]

theorem envBound22009 : H12AffineFastState.Bounded env22009 := by
  intro p hp
  have h : env22009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22008_22009 : H12AffineEnvironment.transform 12 268 env22008 = env22009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22008 == env22009) = true)

theorem identity22009 : scanCanonicalize (H12AffineFastState.compose env22009 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 3637) := by decide +kernel

theorem selectedBound22009 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22010 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,3637,6964,262,3620,2340,1024,6965,4112,32,16,6966,269,17,2048,5392,2868,4624,1285,33,256,6932,3636,513]

theorem envBound22010 : H12AffineFastState.Bounded env22010 := by
  intro p hp
  have h : env22010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22009_22010 : H12AffineEnvironment.transform 13 3637 env22009 = env22010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3637 env22009 == env22010) = true)

theorem identity22010 : scanCanonicalize (H12AffineFastState.compose env22010 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1556) := by decide +kernel

theorem selectedBound22010 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env22011 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1556,268,3637,3360,262,3620,2340,1024,3361,1540,32,16,3362,269,17,2048,772,2868,1028,1285,33,256,3328,3636,513]

theorem envBound22011 : H12AffineFastState.Bounded env22011 := by
  intro p hp
  have h : env22011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22010_22011 : H12AffineEnvironment.transform 11 1556 env22010 = env22011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env22010 == env22011) = true)

theorem identity22011 : scanCanonicalize (H12AffineFastState.compose env22011 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound22011 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env22012 : List Nat := [2,4,8,16,32,16,9,256,512,1024,513,1556,268,1076,1825,262,1061,805,1024,1824,1540,32,16,1827,269,17,513,772,309,1028,1285,33,256,1793,1077,513]

theorem envBound22012 : H12AffineFastState.Bounded env22012 := by
  intro p hp
  have h : env22012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22011_22012 : H12AffineEnvironment.transform 10 513 env22011 = env22012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env22011 == env22012) = true)

theorem identity22012 : scanCanonicalize (H12AffineFastState.compose env22012 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22012 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env22013 : List Nat := [2,4,8,16,32,16,9,256,512,21,513,513,268,33,820,262,48,805,21,821,529,32,16,822,269,17,513,772,309,17,272,33,256,788,32,513]

theorem envBound22013 : H12AffineFastState.Bounded env22013 := by
  intro p hp
  have h : env22013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22012_22013 : H12AffineEnvironment.transform 9 21 env22012 = env22013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22012 == env22013) = true)

def env22014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,17,98780,8328,65,4270122,5392,17665,109046,1500,4256860,256,21792,46212,74251]

theorem envBound22014 : H12AffineFastState.Bounded env22014 := by
  intro p hp
  have h : env22014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21988_22014 : H12AffineEnvironment.transform 20 4161 env21988 = env22014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21988 == env22014) = true)

theorem identity22014 : scanCanonicalize (H12AffineFastState.compose env22014 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213350) := by decide +kernel

end H12CloudChart1