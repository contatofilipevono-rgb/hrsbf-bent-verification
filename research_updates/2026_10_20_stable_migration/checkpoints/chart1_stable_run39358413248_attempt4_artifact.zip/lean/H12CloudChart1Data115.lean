import H12CloudChart1Data114

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29152 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,9293,65536,79131,262144,1024,9292,77899,32,73755,75033,8192,64,262516,79130,4097,271437,75103,75067,256,32,4160,513]

theorem envBound29152 : H12AffineFastState.Bounded env29152 := by
  intro p hp
  have h : env29152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29151_29152 : H12AffineEnvironment.transform 14 9293 env29151 = env29152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env29151 == env29152) = true)

theorem identity29152 : scanCanonicalize (H12AffineFastState.compose env29152 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound29152 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env29153 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,373,65536,69667,262144,1024,372,71027,32,66851,65569,1336,64,262516,69666,4097,262517,65639,65539,256,32,4160,513]

theorem envBound29153 : H12AffineFastState.Bounded env29153 := by
  intro p hp
  have h : env29153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29152_29153 : H12AffineEnvironment.transform 12 1336 env29152 = env29153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env29152 == env29153) = true)

theorem identity29153 : scanCanonicalize (H12AffineFastState.compose env29153 (packedSelected [3,5,10,18,21,32] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound29153 : packedSelected [3,5,10,18,21,32] rootPS < 2^1333 := by decide +kernel

def env29154 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,373,65536,69667,3124,1024,372,71027,32,66851,65569,1336,64,3392,69666,4097,3393,65639,65539,256,32,4160,513]

theorem envBound29154 : H12AffineFastState.Bounded env29154 := by
  intro p hp
  have h : env29154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29153_29154 : H12AffineEnvironment.transform 17 3124 env29153 = env29154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env29153 == env29154) = true)

theorem identity29154 : scanCanonicalize (H12AffineFastState.compose env29154 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound29154 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29155 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5376,373,263,4388,3124,1024,372,5236,32,1060,294,1336,64,3392,4389,4097,3393,352,260,256,32,4160,513]

theorem envBound29155 : H12AffineFastState.Bounded env29155 := by
  intro p hp
  have h : env29155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29154_29155 : H12AffineEnvironment.transform 15 263 env29154 = env29155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env29154 == env29155) = true)

theorem identity29155 : scanCanonicalize (H12AffineFastState.compose env29155 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound29155 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29156 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,884,1336,1652,373,263,592,3124,1024,372,1792,32,1060,294,1336,64,3392,593,885,3393,352,260,256,32,820,513]

theorem envBound29156 : H12AffineFastState.Bounded env29156 := by
  intro p hp
  have h : env29156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29155_29156 : H12AffineEnvironment.transform 11 884 env29155 = env29156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env29155 == env29156) = true)

theorem identity29156 : scanCanonicalize (H12AffineFastState.compose env29156 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29156 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env29157 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,884,348,528,373,263,592,2128,100,372,868,32,64,294,348,64,2340,593,885,2341,352,260,256,32,820,513]

theorem envBound29157 : H12AffineFastState.Bounded env29157 := by
  intro p hp
  have h : env29157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29156_29157 : H12AffineEnvironment.transform 9 100 env29156 = env29157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29156 == env29157) = true)

theorem identity29157 : scanCanonicalize (H12AffineFastState.compose env29157 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29157 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29158 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,592,120,528,81,35,592,2128,100,80,576,32,64,2,120,64,2048,593,593,2049,68,32,36,32,528,513]

theorem envBound29158 : H12AffineFastState.Bounded env29158 := by
  intro p hp
  have h : env29158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29157_29158 : H12AffineEnvironment.transform 7 36 env29157 = env29158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29157 == env29158) = true)

theorem identity29158 : scanCanonicalize (H12AffineFastState.compose env29158 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29158 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29159 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,512,40,528,1,35,512,2048,52,0,528,32,16,2,40,16,2048,513,513,2049,20,32,36,32,528,513]

theorem envBound29159 : H12AffineFastState.Bounded env29159 := by
  intro p hp
  have h : env29159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29158_29159 : H12AffineEnvironment.transform 5 16 env29158 = env29159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29158 == env29159) = true)

theorem identity29159 : scanCanonicalize (H12AffineFastState.compose env29159 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29160 : List Nat := [2,4,8,16,17,16,8,21,512,5,2048,512,25,528,1,18,512,2048,5,0,528,17,16,2,25,16,2048,513,513,2049,20,17,21,17,528,513]

theorem envBound29160 : H12AffineFastState.Bounded env29160 := by
  intro p hp
  have h : env29160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29159_29160 : H12AffineEnvironment.transform 4 17 env29159 = env29160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29159 == env29160) = true)

theorem identity29160 : scanCanonicalize (H12AffineFastState.compose env29160 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29160 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29161 : List Nat := [2,4,8,1,0,1,8,4,512,5,2048,512,8,513,1,3,512,2048,5,0,513,0,1,2,8,1,2048,513,513,2049,5,0,4,0,513,513]

theorem envBound29161 : H12AffineFastState.Bounded env29161 := by
  intro p hp
  have h : env29161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29160_29161 : H12AffineEnvironment.transform 3 1 env29160 = env29161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29160 == env29161) = true)

theorem identity29161 : scanCanonicalize (H12AffineFastState.compose env29161 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound29161 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29162 : List Nat := [2,4,8,1,0,1,8,4,512,5,513,512,8,513,1,3,512,513,5,0,513,0,1,2,8,1,513,513,513,512,5,0,4,0,513,513]

theorem envBound29162 : H12AffineFastState.Bounded env29162 := by
  intro p hp
  have h : env29162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29161_29162 : H12AffineEnvironment.transform 10 513 env29161 = env29162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env29161 == env29162) = true)

def env29163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98644,8193,64,472174,79130,4097,505114,75102,98678,256,33,46093,513]

theorem envBound29163 : H12AffineFastState.Bounded env29163 := by
  intro p hp
  have h : env29163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29149_29163 : H12AffineEnvironment.transform 6 9 env29149 = env29163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29149 == env29163) = true)

theorem identity29163 : scanCanonicalize (H12AffineFastState.compose env29163 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound29163 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,45341,32,41293,3,8193,64,439609,46157,4097,406605,41993,33,256,33,46093,513]

theorem envBound29164 : H12AffineFastState.Bounded env29164 := by
  intro p hp
  have h : env29164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29163_29164 : H12AffineEnvironment.transform 15 33111 env29163 = env29164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env29163 == env29164) = true)

theorem identity29164 : scanCanonicalize (H12AffineFastState.compose env29164 (packedSelected [2,6,21] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound29164 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env29165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46109,262144,1024,32769,45341,32,41293,3,8193,64,262436,46157,4097,294992,41993,33,256,33,46093,513]

theorem envBound29165 : H12AffineFastState.Bounded env29165 := by
  intro p hp
  have h : env29165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29164_29165 : H12AffineEnvironment.transform 16 46109 env29164 = env29165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env29164 == env29165) = true)

theorem identity29165 : scanCanonicalize (H12AffineFastState.compose env29165 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29165 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env29166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,343,13341,262144,1024,1,12573,32,8525,3,8193,64,262436,13389,4097,262224,9225,33,256,33,13325,513]

theorem envBound29166 : H12AffineFastState.Bounded env29166 := by
  intro p hp
  have h : env29166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29165_29166 : H12AffineEnvironment.transform 14 0 env29165 = env29166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29165 == env29166) = true)

theorem identity29166 : scanCanonicalize (H12AffineFastState.compose env29166 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29166 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,343,13341,2420,1024,1,12573,32,8525,3,8193,64,2128,13389,4097,2340,9225,33,256,33,13325,513]

theorem envBound29167 : H12AffineFastState.Bounded env29167 := by
  intro p hp
  have h : env29167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29166_29167 : H12AffineEnvironment.transform 17 2420 env29166 = env29167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29166 == env29167) = true)

theorem identity29167 : scanCanonicalize (H12AffineFastState.compose env29167 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29167 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,0,343,5393,2420,1024,1,4113,32,65,3,269,64,2128,5441,4097,2340,1285,33,256,33,5377,513]

theorem envBound29168 : H12AffineFastState.Bounded env29168 := by
  intro p hp
  have h : env29168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29167_29168 : H12AffineEnvironment.transform 12 268 env29167 = env29168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29167 == env29168) = true)

theorem identity29168 : scanCanonicalize (H12AffineFastState.compose env29168 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound29168 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env29169 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,268,4160,0,343,4177,2420,320,1,4113,32,65,3,269,64,2128,4097,4097,2340,69,33,256,33,4161,513]

theorem envBound29169 : H12AffineFastState.Bounded env29169 := by
  intro p hp
  have h : env29169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29168_29169 : H12AffineEnvironment.transform 9 320 env29168 = env29169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29168 == env29169) = true)

theorem identity29169 : scanCanonicalize (H12AffineFastState.compose env29169 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29169 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29170 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4113,0,262,4096,2341,273,1,4113,32,16,3,269,17,2049,4097,4097,2340,20,33,256,33,4112,513]

theorem envBound29170 : H12AffineFastState.Bounded env29170 := by
  intro p hp
  have h : env29170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29169_29170 : H12AffineEnvironment.transform 5 17 env29169 = env29170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29169 == env29170) = true)

theorem identity29170 : scanCanonicalize (H12AffineFastState.compose env29170 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29171 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,41,4113,0,35,4096,2048,52,1,4113,32,16,3,40,17,2049,4097,4097,2049,20,33,37,33,4112,513]

theorem envBound29171 : H12AffineFastState.Bounded env29171 := by
  intro p hp
  have h : env29171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29170_29171 : H12AffineEnvironment.transform 7 37 env29170 = env29171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29170 == env29171) = true)

theorem identity29171 : scanCanonicalize (H12AffineFastState.compose env29171 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound29171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29172 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,41,32,0,35,49,2048,52,1,32,32,16,3,40,17,2049,48,48,2049,20,33,37,33,33,513]

theorem envBound29172 : H12AffineFastState.Bounded env29172 := by
  intro p hp
  have h : env29172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29171_29172 : H12AffineEnvironment.transform 11 49 env29171 = env29172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env29171 == env29172) = true)

theorem identity29172 : scanCanonicalize (H12AffineFastState.compose env29172 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound29172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29173 : List Nat := [2,4,8,16,32,17,9,37,32,52,2048,49,41,32,0,35,49,2048,52,1,32,32,16,3,40,17,2049,48,48,2049,20,33,37,33,33,33]

theorem envBound29173 : H12AffineFastState.Bounded env29173 := by
  intro p hp
  have h : env29173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29172_29173 : H12AffineEnvironment.transform 8 32 env29172 = env29173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env29172 == env29173) = true)

theorem identity29173 : scanCanonicalize (H12AffineFastState.compose env29173 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound29173 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29174 : List Nat := [2,4,8,16,32,17,9,37,32,52,33,49,41,32,0,35,49,33,52,1,32,32,16,3,40,17,32,48,48,32,20,33,37,33,33,33]

theorem envBound29174 : H12AffineFastState.Bounded env29174 := by
  intro p hp
  have h : env29174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29173_29174 : H12AffineEnvironment.transform 10 33 env29173 = env29174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env29173 == env29174) = true)

def env29175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787061,79130,8466578,8819968,8389956,98679,256,8462395,8492190,8462994]

theorem envBound29175 : H12AffineFastState.Bounded env29175 := by
  intro p hp
  have h : env29175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29147_29175 : H12AffineEnvironment.transform 21 33 env29147 = env29175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29147 == env29175) = true)

theorem identity29175 : scanCanonicalize (H12AffineFastState.compose env29175 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound29175 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,4160,33,8388608,41431,8328,64,8787061,5529,8392721,8819968,8389956,41460,256,8388792,8434717,8389137]

theorem envBound29176 : H12AffineFastState.Bounded env29176 := by
  intro p hp
  have h : env29176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29175_29176 : H12AffineEnvironment.transform 15 8323 env29175 = env29176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env29175 == env29176) = true)

def env29177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,262144,1024,32769,4160,33,8388608,41431,8328,64,8651061,5529,8392721,8683584,8389956,41460,256,8388792,8434717,8389137]

theorem envBound29177 : H12AffineFastState.Bounded env29177 := by
  intro p hp
  have h : env29177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29176_29177 : H12AffineEnvironment.transform 16 5440 env29176 = env29177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env29176 == env29177) = true)

theorem identity29177 : scanCanonicalize (H12AffineFastState.compose env29177 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound29177 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35244,1024,32769,4160,33,8388608,41431,8328,64,8423577,5529,8392721,8391148,8389956,41460,256,8388792,8434717,8389137]

theorem envBound29178 : H12AffineFastState.Bounded env29178 := by
  intro p hp
  have h : env29178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29177_29178 : H12AffineEnvironment.transform 17 35244 env29177 = env29178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env29177 == env29178) = true)

theorem identity29178 : scanCanonicalize (H12AffineFastState.compose env29178 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 41245) := by decide +kernel

theorem selectedBound29178 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env29179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5440,35244,1024,32769,4160,33,41245,41431,8328,64,10628,5529,45324,43249,42073,41460,256,41381,5376,41740]

theorem envBound29179 : H12AffineFastState.Bounded env29179 := by
  intro p hp
  have h : env29179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29178_29179 : H12AffineEnvironment.transform 22 41245 env29178 = env29179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41245 env29178 == env29179) = true)

theorem identity29179 : scanCanonicalize (H12AffineFastState.compose env29179 (packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound29179 : packedSelected [0,3,4,5,7,9,11,15,19,20] rootPS < 2^1333 := by decide +kernel

def env29180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,80,8323,5440,2556,1024,81,4160,33,8525,8583,8328,64,10628,5529,12636,10401,9225,8612,256,8693,5376,9052]

theorem envBound29180 : H12AffineFastState.Bounded env29180 := by
  intro p hp
  have h : env29180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29179_29180 : H12AffineEnvironment.transform 14 80 env29179 = env29180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env29179 == env29180) = true)

theorem identity29180 : scanCanonicalize (H12AffineFastState.compose env29180 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29180 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env29181 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,8202,5440,2421,1024,81,4160,33,8525,8462,8193,64,10509,5392,12636,10280,9225,8493,256,8572,5376,9052]

theorem envBound29181 : H12AffineFastState.Bounded env29181 := by
  intro p hp
  have h : env29181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29180_29181 : H12AffineEnvironment.transform 6 9 env29180 = env29181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29180 == env29181) = true)

def env29182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,262144,1024,32769,4160,33,8388608,41431,8328,64,8651060,5529,8392721,8683585,8389956,41460,256,8388792,8434717,8389137]

theorem envBound29182 : H12AffineFastState.Bounded env29182 := by
  intro p hp
  have h : env29182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29176_29182 : H12AffineEnvironment.transform 16 5441 env29176 = env29182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29176 == env29182) = true)

theorem identity29182 : scanCanonicalize (H12AffineFastState.compose env29182 (packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound29182 : packedSelected [1,4,7,9,16,19,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,5441,35109,1024,32769,4160,33,8388608,41431,8328,64,8423441,5529,8392721,8391012,8389956,41460,256,8388792,8434717,8389137]

theorem envBound29183 : H12AffineFastState.Bounded env29183 := by
  intro p hp
  have h : env29183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29182_29183 : H12AffineEnvironment.transform 17 35109 env29182 = env29183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env29182 == env29183) = true)

theorem identity29183 : scanCanonicalize (H12AffineFastState.compose env29183 (packedSelected [4,5,7,8,9,10,16,18,20,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29183 : packedSelected [4,5,7,8,9,10,16,18,20,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,81,8323,5441,2420,1024,80,4160,33,8388608,8582,8328,64,8390720,5529,8392721,8391012,8389956,8613,256,8388792,8401996,8389137]

theorem envBound29184 : H12AffineFastState.Bounded env29184 := by
  intro p hp
  have h : env29184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29183_29184 : H12AffineEnvironment.transform 14 81 env29183 = env29184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29183 == env29184) = true)

theorem identity29184 : scanCanonicalize (H12AffineFastState.compose env29184 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29184 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,399,5441,2420,1024,80,4160,33,8388608,138,388,64,8390720,5529,8392721,8391012,8389956,169,256,8388792,8394048,8389137]

theorem envBound29185 : H12AffineFastState.Bounded env29185 := by
  intro p hp
  have h : env29185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29184_29185 : H12AffineEnvironment.transform 12 268 env29184 = env29185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29184 == env29185) = true)

theorem identity29185 : scanCanonicalize (H12AffineFastState.compose env29185 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(22+1) ^^^ 201) := by decide +kernel

theorem selectedBound29185 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env29186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,399,5441,2420,1024,80,4160,33,201,138,388,64,2185,5529,4312,2477,1421,169,256,113,5513,728]

theorem envBound29186 : H12AffineFastState.Bounded env29186 := by
  intro p hp
  have h : env29186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29185_29186 : H12AffineEnvironment.transform 22 201 env29185 = env29186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 201 env29185 == env29186) = true)

theorem identity29186 : scanCanonicalize (H12AffineFastState.compose env29186 (packedSelected [0,1,3,5,7,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound29186 : packedSelected [0,1,3,5,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29187 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,268,4161,81,399,4096,2420,321,80,4160,33,201,138,388,64,2185,4312,4312,2477,204,169,256,113,4296,728]

theorem envBound29187 : H12AffineFastState.Bounded env29187 := by
  intro p hp
  have h : env29187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29186_29187 : H12AffineEnvironment.transform 9 321 env29186 = env29187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29186 == env29187) = true)

theorem identity29187 : scanCanonicalize (H12AffineFastState.compose env29187 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29187 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env29188 : List Nat := [2,4,8,16,32,64,89,256,512,321,2048,4096,268,4161,81,342,4096,2420,321,80,4160,33,16,83,349,64,2128,4097,4097,2420,21,112,256,113,4113,513]

theorem envBound29188 : H12AffineFastState.Bounded env29188 := by
  intro p hp
  have h : env29188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29187_29188 : H12AffineEnvironment.transform 6 89 env29187 = env29188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29187 == env29188) = true)

theorem identity29188 : scanCanonicalize (H12AffineFastState.compose env29188 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29188 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29189 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,4096,268,4112,0,263,4096,2341,272,1,4113,33,16,2,268,17,2049,4097,4097,2341,21,33,256,32,4113,513]

theorem envBound29189 : H12AffineFastState.Bounded env29189 := by
  intro p hp
  have h : env29189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29188_29189 : H12AffineEnvironment.transform 5 17 env29188 = env29189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29188 == env29189) = true)

theorem identity29189 : scanCanonicalize (H12AffineFastState.compose env29189 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29190 : List Nat := [2,4,8,16,16,17,8,256,512,272,2048,4096,268,4112,0,263,4096,2325,272,1,4113,17,16,2,268,17,2049,4097,4097,2325,21,17,256,16,4113,513]

theorem envBound29190 : H12AffineFastState.Bounded env29190 := by
  intro p hp
  have h : env29190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29189_29190 : H12AffineEnvironment.transform 4 16 env29189 = env29190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29189 == env29190) = true)

theorem identity29190 : scanCanonicalize (H12AffineFastState.compose env29190 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound29190 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29191 : List Nat := [2,4,8,16,16,17,8,256,512,272,2048,773,268,789,0,263,773,2325,272,1,788,17,16,2,268,17,2049,772,772,2325,21,17,256,16,788,513]

theorem envBound29191 : H12AffineFastState.Bounded env29191 := by
  intro p hp
  have h : env29191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29190_29191 : H12AffineEnvironment.transform 11 773 env29190 = env29191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env29190 == env29191) = true)

theorem identity29191 : scanCanonicalize (H12AffineFastState.compose env29191 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29191 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29192 : List Nat := [2,4,8,16,16,17,8,5,512,21,2048,512,9,528,0,2,512,2064,21,1,529,17,16,2,9,17,2049,513,513,2064,21,17,5,16,529,513]

theorem envBound29192 : H12AffineFastState.Bounded env29192 := by
  intro p hp
  have h : env29192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29191_29192 : H12AffineEnvironment.transform 7 5 env29191 = env29192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29191 == env29192) = true)

theorem identity29192 : scanCanonicalize (H12AffineFastState.compose env29192 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound29192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29193 : List Nat := [2,4,8,16,16,17,8,5,512,21,528,512,9,528,0,2,512,512,21,1,529,17,16,2,9,17,529,513,513,512,21,17,5,16,529,513]

theorem envBound29193 : H12AffineFastState.Bounded env29193 := by
  intro p hp
  have h : env29193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29192_29193 : H12AffineEnvironment.transform 10 528 env29192 = env29193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env29192 == env29193) = true)

theorem identity29193 : scanCanonicalize (H12AffineFastState.compose env29193 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound29193 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29194 : List Nat := [2,4,8,16,16,17,8,5,17,21,1,17,9,1,0,2,17,17,21,1,0,17,16,2,9,17,0,16,16,17,21,17,5,16,0,16]

theorem envBound29194 : H12AffineFastState.Bounded env29194 := by
  intro p hp
  have h : env29194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29193_29194 : H12AffineEnvironment.transform 8 17 env29193 = env29194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env29193 == env29194) = true)

theorem identity29194 : scanCanonicalize (H12AffineFastState.compose env29194 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29194 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29195 : List Nat := [2,4,8,0,0,1,8,5,1,5,1,1,9,1,0,2,1,1,5,1,0,1,0,2,9,1,0,0,0,1,5,1,5,0,0,0]

theorem envBound29195 : H12AffineFastState.Bounded env29195 := by
  intro p hp
  have h : env29195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29194_29195 : H12AffineEnvironment.transform 3 0 env29194 = env29195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29194 == env29195) = true)

def env29196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981332,79130,8466578,8819969,8389957,4292951,256,8462394,8492190,8462995]

theorem envBound29196 : H12AffineFastState.Bounded env29196 := by
  intro p hp
  have h : env29196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29146_29196 : H12AffineEnvironment.transform 13 5377 env29146 = env29196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29146 == env29196) = true)

def env29197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787060,79130,8466578,8819969,8389957,98679,256,8462394,8492190,8462995]

theorem envBound29197 : H12AffineFastState.Bounded env29197 := by
  intro p hp
  have h : env29197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29196_29197 : H12AffineEnvironment.transform 21 32 env29196 = env29197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29196 == env29197) = true)

theorem identity29197 : scanCanonicalize (H12AffineFastState.compose env29197 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound29197 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,98767,98645,8328,64,497083,79130,45405,464078,99466,98679,256,41461,5457,41820]

theorem envBound29198 : H12AffineFastState.Bounded env29198 := by
  intro p hp
  have h : env29198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29197_29198 : H12AffineEnvironment.transform 22 98767 env29197 = env29198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env29197 == env29198) = true)

theorem identity29198 : scanCanonicalize (H12AffineFastState.compose env29198 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29198 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,78018,32,73874,73736,8328,64,472294,79130,4096,464078,75223,73770,256,168,5457,513]

theorem envBound29199 : H12AffineFastState.Bounded env29199 := by
  intro p hp
  have h : env29199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29198_29199 : H12AffineEnvironment.transform 14 8541 env29198 = env29199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29198 == env29199) = true)

def env29200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10400,1024,8540,78018,32,73874,73736,8328,64,203846,79130,4096,212078,75223,73770,256,168,5457,513]

theorem envBound29200 : H12AffineFastState.Bounded env29200 := by
  intro p hp
  have h : env29200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29199_29200 : H12AffineEnvironment.transform 17 10400 env29199 = env29200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29199 == env29200) = true)

theorem identity29200 : scanCanonicalize (H12AffineFastState.compose env29200 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29200 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,10400,1024,8540,4160,32,16,138,8328,64,146628,5528,4096,138476,1365,168,256,168,5457,513]

theorem envBound29201 : H12AffineFastState.Bounded env29201 := by
  intro p hp
  have h : env29201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29200_29201 : H12AffineEnvironment.transform 15 8322 env29200 = env29201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29200 == env29201) = true)

theorem identity29201 : scanCanonicalize (H12AffineFastState.compose env29201 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound29201 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,5377,1124,1467,131072,3481,1024,1125,4160,32,16,138,1457,64,137725,5528,4096,138476,1365,168,256,168,5457,513]

theorem envBound29202 : H12AffineFastState.Bounded env29202 := by
  intro p hp
  have h : env29202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29201_29202 : H12AffineEnvironment.transform 12 1337 env29201 = env29202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env29201 == env29202) = true)

theorem identity29202 : scanCanonicalize (H12AffineFastState.compose env29202 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound29202 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env29203 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4248,509,34,131072,2048,409,508,4160,32,16,138,40,64,137725,4097,4096,137589,204,168,256,168,4296,513]

theorem envBound29203 : H12AffineFastState.Bounded env29203 := by
  intro p hp
  have h : env29203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29202_29203 : H12AffineEnvironment.transform 9 409 env29202 = env29203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env29202 == env29203) = true)

theorem identity29203 : scanCanonicalize (H12AffineFastState.compose env29203 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 4524) := by decide +kernel

theorem selectedBound29203 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29204 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4248,509,34,4524,2048,409,508,4160,32,16,138,40,64,2129,4097,4096,2265,204,168,256,168,4296,513]

theorem envBound29204 : H12AffineFastState.Bounded env29204 := by
  intro p hp
  have h : env29204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29203_29204 : H12AffineEnvironment.transform 16 4524 env29203 = env29204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4524 env29203 == env29204) = true)

theorem identity29204 : scanCanonicalize (H12AffineFastState.compose env29204 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound29204 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29205 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,153,160,1,509,34,309,2048,409,508,217,32,16,138,40,64,2129,152,153,2265,204,168,256,168,81,513]

theorem envBound29205 : H12AffineFastState.Bounded env29205 := by
  intro p hp
  have h : env29205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29204_29205 : H12AffineEnvironment.transform 11 153 env29204 = env29205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env29204 == env29205) = true)

theorem identity29205 : scanCanonicalize (H12AffineFastState.compose env29205 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29205 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29206 : List Nat := [2,4,8,16,32,64,128,36,512,189,2048,153,160,1,217,34,17,2048,189,216,217,32,16,138,40,64,2129,152,153,2265,204,168,36,168,81,513]

theorem envBound29206 : H12AffineFastState.Bounded env29206 := by
  intro p hp
  have h : env29206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29205_29206 : H12AffineEnvironment.transform 7 36 env29205 = env29206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29205 == env29206) = true)

theorem identity29206 : scanCanonicalize (H12AffineFastState.compose env29206 (packedSelected [0,1,2,3,5,6,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound29206 : packedSelected [0,1,2,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29207 : List Nat := [2,4,8,16,32,64,72,36,512,117,2048,81,104,1,17,34,17,2048,117,16,17,32,16,66,40,64,2129,80,81,2065,4,96,36,96,81,513]

theorem envBound29207 : H12AffineFastState.Bounded env29207 := by
  intro p hp
  have h : env29207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29206_29207 : H12AffineEnvironment.transform 6 72 env29206 = env29207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env29206 == env29207) = true)

theorem identity29207 : scanCanonicalize (H12AffineFastState.compose env29207 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound29207 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env29208 : List Nat := [2,4,8,16,32,64,72,36,512,117,65,81,104,1,17,34,17,65,117,16,17,32,16,66,40,64,16,80,81,80,4,96,36,96,81,513]

theorem envBound29208 : H12AffineFastState.Bounded env29208 := by
  intro p hp
  have h : env29208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29207_29208 : H12AffineEnvironment.transform 10 65 env29207 = env29208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env29207 == env29208) = true)

theorem identity29208 : scanCanonicalize (H12AffineFastState.compose env29208 (packedSelected [3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29208 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env29209 : List Nat := [2,4,8,16,32,32,40,36,512,21,33,49,8,1,17,34,17,33,21,16,17,32,16,34,40,32,16,48,49,48,4,0,36,0,49,513]

theorem envBound29209 : H12AffineFastState.Bounded env29209 := by
  intro p hp
  have h : env29209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29208_29209 : H12AffineEnvironment.transform 5 32 env29208 = env29209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29208 == env29209) = true)

theorem identity29209 : scanCanonicalize (H12AffineFastState.compose env29209 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29209 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29210 : List Nat := [2,4,8,16,16,16,24,20,512,21,17,1,8,1,17,18,17,17,21,16,17,16,16,18,24,16,16,0,1,0,4,0,20,0,1,513]

theorem envBound29210 : H12AffineFastState.Bounded env29210 := by
  intro p hp
  have h : env29210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29209_29210 : H12AffineEnvironment.transform 4 16 env29209 = env29210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29209 == env29210) = true)

def env29211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10401,1024,8540,78018,32,73874,73736,8328,64,203847,79130,4096,212079,75223,73770,256,168,5457,513]

theorem envBound29211 : H12AffineFastState.Bounded env29211 := by
  intro p hp
  have h : env29211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29199_29211 : H12AffineEnvironment.transform 17 10401 env29199 = env29211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29199 == env29211) = true)

theorem identity29211 : scanCanonicalize (H12AffineFastState.compose env29211 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound29211 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env29212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,13389,10401,1024,8540,78018,32,73874,73736,8328,64,75786,79130,4096,67618,75223,73770,256,168,5457,513]

theorem envBound29212 : H12AffineFastState.Bounded env29212 := by
  intro p hp
  have h : env29212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29211_29212 : H12AffineEnvironment.transform 16 13389 env29211 = env29212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env29211 == env29212) = true)

theorem identity29212 : scanCanonicalize (H12AffineFastState.compose env29212 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound29212 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env29213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,65536,5529,2421,1024,136,69910,32,65862,66012,348,64,68062,70862,4096,67618,66563,66046,256,168,5457,513]

theorem envBound29213 : H12AffineFastState.Bounded env29213 := by
  intro p hp
  have h : env29213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29212_29213 : H12AffineEnvironment.transform 12 468 env29212 = env29213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env29212 == env29213) = true)

theorem identity29213 : scanCanonicalize (H12AffineFastState.compose env29213 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29213 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,478,5529,2421,1024,136,4296,32,152,2,348,64,2048,5392,4096,2556,1501,32,256,168,5457,513]

theorem envBound29214 : H12AffineFastState.Bounded env29214 := by
  intro p hp
  have h : env29214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29213_29214 : H12AffineEnvironment.transform 15 478 env29213 = env29214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29213 == env29214) = true)

theorem identity29214 : scanCanonicalize (H12AffineFastState.compose env29214 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound29214 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29215 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,301,5377,112,295,5472,2421,1024,113,4145,32,97,2,348,64,2048,5392,4096,2309,1316,32,256,81,5457,513]

theorem envBound29215 : H12AffineFastState.Bounded env29215 := by
  intro p hp
  have h : env29215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29214_29215 : H12AffineEnvironment.transform 6 121 env29214 = env29215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env29214 == env29215) = true)

theorem identity29215 : scanCanonicalize (H12AffineFastState.compose env29215 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29215 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env29216 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5377,0,295,5392,2309,1024,1,4145,32,17,2,300,48,2048,5392,4096,2309,1316,32,256,33,5409,513]

theorem envBound29216 : H12AffineFastState.Bounded env29216 := by
  intro p hp
  have h : env29216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29215_29216 : H12AffineEnvironment.transform 5 48 env29215 = env29216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29215 == env29216) = true)

theorem identity29216 : scanCanonicalize (H12AffineFastState.compose env29216 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound29216 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29217 : List Nat := [2,4,8,16,32,48,9,256,261,1024,2048,4096,301,5377,0,295,5392,2309,1024,1,4145,32,17,2,300,48,2048,5392,4096,2309,1316,32,256,33,5409,260]

theorem envBound29217 : H12AffineFastState.Bounded env29217 := by
  intro p hp
  have h : env29217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29216_29217 : H12AffineEnvironment.transform 8 261 env29216 = env29217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env29216 == env29217) = true)

def env29218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787061,79130,8466578,8819969,8389957,98678,256,8462394,8492190,8462995]

theorem envBound29218 : H12AffineFastState.Bounded env29218 := by
  intro p hp
  have h : env29218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29196_29218 : H12AffineEnvironment.transform 21 33 env29196 = env29218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29196 == env29218) = true)

theorem identity29218 : scanCanonicalize (H12AffineFastState.compose env29218 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound29218 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,45341,33,8388608,138,8328,64,8787061,46277,8433997,8819969,8389957,169,256,8430053,8394049,8430412]

theorem envBound29219 : H12AffineFastState.Bounded env29219 := by
  intro p hp
  have h : env29219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29218_29219 : H12AffineEnvironment.transform 15 33247 env29218 = env29219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env29218 == env29219) = true)

theorem identity29219 : scanCanonicalize (H12AffineFastState.compose env29219 (packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 297452) := by decide +kernel

theorem selectedBound29219 : packedSelected [1,4,7,9,11,12,14,15,16,18,19,20,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env29220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,45341,33,297452,138,8328,64,171417,46277,276641,138477,298153,169,256,272393,302253,273056]

theorem envBound29220 : H12AffineFastState.Bounded env29220 := by
  intro p hp
  have h : env29220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29219_29220 : H12AffineEnvironment.transform 22 297452 env29219 = env29220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297452 env29219 == env29220) = true)

theorem identity29220 : scanCanonicalize (H12AffineFastState.compose env29220 (packedSelected [1,4,7,9,10,11,12,15,18,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound29220 : packedSelected [1,4,7,9,10,11,12,15,18,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,10401,1024,32769,45341,33,41293,138,8328,64,171417,46277,4096,138477,41992,169,256,168,46092,513]

theorem envBound29221 : H12AffineFastState.Bounded env29221 := by
  intro p hp
  have h : env29221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29220_29221 : H12AffineEnvironment.transform 17 10401 env29220 = env29221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29220 == env29221) = true)

theorem identity29221 : scanCanonicalize (H12AffineFastState.compose env29221 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound29221 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,13460,10401,1024,32769,45341,33,41293,138,8328,64,43277,46277,4096,10361,41992,169,256,168,46092,513]

theorem envBound29222 : H12AffineFastState.Bounded env29222 := by
  intro p hp
  have h : env29222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29221_29222 : H12AffineEnvironment.transform 16 13460 env29221 = env29222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env29221 == env29222) = true)

theorem identity29222 : scanCanonicalize (H12AffineFastState.compose env29222 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29222 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env29223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,32768,33247,5528,2477,1024,32769,36881,33,32833,138,388,64,34817,38345,4096,2421,34052,169,256,168,38144,513]

theorem envBound29223 : H12AffineFastState.Bounded env29223 := by
  intro p hp
  have h : env29223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29222_29223 : H12AffineEnvironment.transform 12 268 env29222 = env29223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29222 == env29223) = true)

def env29224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119893,8328,64,12981333,79131,8466578,8830976,8409157,4314199,256,8484154,8492191,8484755]

theorem envBound29224 : H12AffineFastState.Bounded env29224 := by
  intro p hp
  have h : env29224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29145_29224 : H12AffineEnvironment.transform 23 119893 env29145 = env29224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119893 env29145 == env29224) = true)

def env29225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981333,79131,8466578,8819968,8389957,4292951,256,8462394,8492191,8462995]

theorem envBound29225 : H12AffineFastState.Bounded env29225 := by
  intro p hp
  have h : env29225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29224_29225 : H12AffineEnvironment.transform 13 5376 env29224 = env29225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29224 == env29225) = true)

def env29226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787061,79131,8466578,8819968,8389957,98679,256,8462394,8492191,8462995]

theorem envBound29226 : H12AffineFastState.Bounded env29226 := by
  intro p hp
  have h : env29226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29225_29226 : H12AffineEnvironment.transform 21 32 env29225 = env29226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29225 == env29226) = true)

theorem identity29226 : scanCanonicalize (H12AffineFastState.compose env29226 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29226 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,78019,32,8388608,73736,8328,64,8787061,79131,8466578,8795229,8389957,73770,256,8462394,8467906,8462995]

theorem envBound29227 : H12AffineFastState.Bounded env29227 := by
  intro p hp
  have h : env29227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29226_29227 : H12AffineEnvironment.transform 14 8541 env29226 = env29227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29226 == env29227) = true)

def env29228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,78019,32,8388608,73736,8328,64,8535253,79131,8466578,8527101,8389957,73770,256,8462394,8467906,8462995]

theorem envBound29228 : H12AffineFastState.Bounded env29228 := by
  intro p hp
  have h : env29228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29227_29228 : H12AffineEnvironment.transform 17 10400 env29227 = env29228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env29227 == env29228) = true)

theorem identity29228 : scanCanonicalize (H12AffineFastState.compose env29228 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound29228 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,10400,1024,8540,4161,32,8388608,138,8328,64,8535253,5529,8392720,8527101,8389957,168,256,8388792,8394048,8389137]

theorem envBound29229 : H12AffineFastState.Bounded env29229 := by
  intro p hp
  have h : env29229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29228_29229 : H12AffineEnvironment.transform 15 8322 env29228 = env29229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env29228 == env29229) = true)

theorem identity29229 : scanCanonicalize (H12AffineFastState.compose env29229 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound29229 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env29230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5529,10400,1024,8540,4161,32,8388608,138,8328,64,8399180,5529,8392720,8391012,8389957,168,256,8388792,8394048,8389137]

theorem envBound29230 : H12AffineFastState.Bounded env29230 := by
  intro p hp
  have h : env29230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29229_29230 : H12AffineEnvironment.transform 16 5529 env29229 = env29230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env29229 == env29230) = true)

theorem identity29230 : scanCanonicalize (H12AffineFastState.compose env29230 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 8477) := by decide +kernel

theorem selectedBound29230 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,5529,10400,1024,8540,4161,32,8477,138,8328,64,2129,5529,12557,10361,9304,168,256,8613,13405,8972]

theorem envBound29231 : H12AffineFastState.Bounded env29231 := by
  intro p hp
  have h : env29231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29230_29231 : H12AffineEnvironment.transform 22 8477 env29230 = env29231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 8477 env29230 == env29231) = true)

theorem identity29231 : scanCanonicalize (H12AffineFastState.compose env29231 (packedSelected [0,1,3,4,5,7,8,11,12,14,15,18,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29231 : packedSelected [0,1,3,4,5,7,8,11,12,14,15,18,20,22] rootPS < 2^1333 := by decide +kernel

def env29232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,5393,10280,1024,8540,4161,32,8477,2,8192,64,2129,5393,12557,10361,9304,32,256,8493,13405,8972]

theorem envBound29232 : H12AffineFastState.Bounded env29232 := by
  intro p hp
  have h : env29232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29231_29232 : H12AffineEnvironment.transform 6 8 env29231 = env29232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29231 == env29232) = true)

def env29233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,32,8388608,73736,8328,64,8535252,79131,8466578,8527100,8389957,73770,256,8462394,8467906,8462995]

theorem envBound29233 : H12AffineFastState.Bounded env29233 := by
  intro p hp
  have h : env29233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29227_29233 : H12AffineEnvironment.transform 17 10401 env29227 = env29233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env29227 == env29233) = true)

theorem identity29233 : scanCanonicalize (H12AffineFastState.compose env29233 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound29233 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,32,73874,73736,8328,64,203846,79131,4096,212078,75223,73770,256,168,5456,513]

theorem envBound29234 : H12AffineFastState.Bounded env29234 := by
  intro p hp
  have h : env29234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29233_29234 : H12AffineEnvironment.transform 22 73874 env29233 = env29234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env29233 == env29234) = true)

theorem identity29234 : scanCanonicalize (H12AffineFastState.compose env29234 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound29234 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env29235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,13388,10401,1024,8540,78019,32,73874,73736,8328,64,75786,79131,4096,67618,75223,73770,256,168,5456,513]

theorem envBound29235 : H12AffineFastState.Bounded env29235 := by
  intro p hp
  have h : env29235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29234_29235 : H12AffineEnvironment.transform 16 13388 env29234 = env29235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env29234 == env29235) = true)

theorem identity29235 : scanCanonicalize (H12AffineFastState.compose env29235 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound29235 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env29236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,65536,5528,2421,1024,136,69911,32,65862,66012,348,64,68062,70863,4096,67618,66563,66046,256,168,5456,513]

theorem envBound29236 : H12AffineFastState.Bounded env29236 := by
  intro p hp
  have h : env29236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29235_29236 : H12AffineEnvironment.transform 12 468 env29235 = env29236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env29235 == env29236) = true)

theorem identity29236 : scanCanonicalize (H12AffineFastState.compose env29236 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound29236 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,478,5528,2421,1024,136,4297,32,152,2,348,64,2048,5393,4096,2556,1501,32,256,168,5456,513]

theorem envBound29237 : H12AffineFastState.Bounded env29237 := by
  intro p hp
  have h : env29237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29236_29237 : H12AffineEnvironment.transform 15 478 env29236 = env29237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env29236 == env29237) = true)

theorem identity29237 : scanCanonicalize (H12AffineFastState.compose env29237 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29237 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29238 : List Nat := [2,4,8,16,32,49,128,256,512,1024,2048,4096,421,5376,137,431,5528,2308,1024,136,4280,32,152,2,301,49,2048,5393,4096,2445,1452,32,256,168,5409,513]

theorem envBound29238 : H12AffineFastState.Bounded env29238 := by
  intro p hp
  have h : env29238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29237_29238 : H12AffineEnvironment.transform 5 49 env29237 = env29238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29237 == env29238) = true)

theorem identity29238 : scanCanonicalize (H12AffineFastState.compose env29238 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29238 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env29239 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5376,0,294,5393,2308,1024,1,4145,32,17,2,301,49,2048,5393,4096,2308,1317,32,256,33,5409,513]

theorem envBound29239 : H12AffineFastState.Bounded env29239 := by
  intro p hp
  have h : env29239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29238_29239 : H12AffineEnvironment.transform 6 9 env29238 = env29239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29238 == env29239) = true)

theorem identity29239 : scanCanonicalize (H12AffineFastState.compose env29239 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound29239 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29240 : List Nat := [2,4,8,16,32,49,9,256,261,1024,2048,4096,300,5376,0,294,5393,2308,1024,1,4145,32,17,2,301,49,2048,5393,4096,2308,1317,32,256,33,5409,260]

theorem envBound29240 : H12AffineFastState.Bounded env29240 := by
  intro p hp
  have h : env29240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29239_29240 : H12AffineEnvironment.transform 8 261 env29239 = env29240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env29239 == env29240) = true)

def env29241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787060,79131,8466578,8819968,8389957,98678,256,8462394,8492191,8462995]

theorem envBound29241 : H12AffineFastState.Bounded env29241 := by
  intro p hp
  have h : env29241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29225_29241 : H12AffineEnvironment.transform 21 33 env29225 = env29241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29225 == env29241) = true)

theorem identity29241 : scanCanonicalize (H12AffineFastState.compose env29241 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound29241 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,41293,98645,8328,64,439609,79131,102879,406605,41992,98678,256,98679,79314,99294]

theorem envBound29242 : H12AffineFastState.Bounded env29242 := by
  intro p hp
  have h : env29242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29241_29242 : H12AffineEnvironment.transform 22 41293 env29241 = env29242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env29241 == env29242) = true)

theorem identity29242 : scanCanonicalize (H12AffineFastState.compose env29242 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound29242 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,78019,33,41293,98645,8328,64,203847,79131,102879,236851,41992,98678,256,98679,79314,99294]

theorem envBound29243 : H12AffineFastState.Bounded env29243 := by
  intro p hp
  have h : env29243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29242_29243 : H12AffineEnvironment.transform 17 108926 env29242 = env29243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env29242 == env29243) = true)

def env29244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67618,1024,8541,78019,33,17,73737,8328,64,203847,79131,77955,212079,1364,73770,256,73771,79314,74370]

theorem envBound29244 : H12AffineFastState.Bounded env29244 := by
  intro p hp
  have h : env29244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29243_29244 : H12AffineEnvironment.transform 14 8540 env29243 = env29244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29243 == env29244) = true)

theorem identity29244 : scanCanonicalize (H12AffineFastState.compose env29244 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound29244 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,398,131072,2476,1024,8541,12621,33,17,8583,8328,64,138697,13461,12557,146913,1364,8612,256,8613,13404,8972]

theorem envBound29245 : H12AffineFastState.Bounded env29245 := by
  intro p hp
  have h : env29245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29244_29245 : H12AffineEnvironment.transform 15 398 env29244 = env29245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env29244 == env29245) = true)

theorem identity29245 : scanCanonicalize (H12AffineFastState.compose env29245 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29245 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,263,131072,2341,1024,8541,12621,33,17,8462,8193,64,138560,13340,12557,146792,1364,8493,256,8492,13404,8972]

theorem envBound29246 : H12AffineFastState.Bounded env29246 := by
  intro p hp
  have h : env29246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29245_29246 : H12AffineEnvironment.transform 6 9 env29245 = env29246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29245 == env29246) = true)

theorem identity29246 : scanCanonicalize (H12AffineFastState.compose env29246 (packedSelected [0,4,6,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound29246 : packedSelected [0,4,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,263,4097,2341,1024,8541,12621,33,17,8462,8193,64,3393,13340,12557,11625,1364,8493,256,8492,13404,8972]

theorem envBound29247 : H12AffineFastState.Bounded env29247 := by
  intro p hp
  have h : env29247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29246_29247 : H12AffineEnvironment.transform 16 4097 env29246 = env29247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env29246 == env29247) = true)

theorem identity29247 : scanCanonicalize (H12AffineFastState.compose env29247 (packedSelected [1,6,8,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound29247 : packedSelected [1,6,8,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env29248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,5376,1344,263,4097,2341,1024,1345,5457,33,17,1298,1053,64,3393,4096,5393,2421,1364,1329,256,1328,4160,1808]

theorem envBound29248 : H12AffineFastState.Bounded env29248 := by
  intro p hp
  have h : env29248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29247_29248 : H12AffineEnvironment.transform 12 1052 env29247 = env29248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env29247 == env29248) = true)

theorem identity29248 : scanCanonicalize (H12AffineFastState.compose env29248 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29248 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env29249 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,121,4453,293,263,4097,2341,101,292,4404,33,17,375,120,64,2340,4096,4468,2421,305,340,256,341,4160,885]

theorem envBound29249 : H12AffineFastState.Bounded env29249 := by
  intro p hp
  have h : env29249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29248_29249 : H12AffineEnvironment.transform 9 101 env29248 = env29249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29248 == env29249) = true)

theorem identity29249 : scanCanonicalize (H12AffineFastState.compose env29249 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29249 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29250 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,121,4112,80,114,4097,2128,101,81,4161,33,17,2,120,64,2129,4096,4097,2048,68,33,117,32,4160,512]

theorem envBound29250 : H12AffineFastState.Bounded env29250 := by
  intro p hp
  have h : env29250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29249_29250 : H12AffineEnvironment.transform 7 117 env29249 = env29250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29249 == env29250) = true)

theorem identity29250 : scanCanonicalize (H12AffineFastState.compose env29250 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound29250 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29251 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,97,121,113,80,114,96,2128,101,81,32,33,17,2,120,64,2129,97,96,2048,68,33,117,32,33,512]

theorem envBound29251 : H12AffineFastState.Bounded env29251 := by
  intro p hp
  have h : env29251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29250_29251 : H12AffineEnvironment.transform 11 97 env29250 = env29251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env29250 == env29251) = true)

theorem identity29251 : scanCanonicalize (H12AffineFastState.compose env29251 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 36) := by decide +kernel

theorem selectedBound29251 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29252 : List Nat := [2,4,8,16,32,64,9,117,512,101,36,97,121,113,80,114,96,116,101,81,32,33,17,2,120,64,117,97,96,36,68,33,117,32,33,512]

theorem envBound29252 : H12AffineFastState.Bounded env29252 := by
  intro p hp
  have h : env29252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29251_29252 : H12AffineEnvironment.transform 10 36 env29251 = env29252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 36 env29251 == env29252) = true)

theorem identity29252 : scanCanonicalize (H12AffineFastState.compose env29252 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29252 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29253 : List Nat := [2,4,8,16,0,64,9,85,512,69,4,65,89,81,80,82,64,84,69,81,0,1,17,2,88,64,85,65,64,4,68,1,85,0,1,512]

theorem envBound29253 : H12AffineFastState.Bounded env29253 := by
  intro p hp
  have h : env29253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29252_29253 : H12AffineEnvironment.transform 4 0 env29252 = env29253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29252 == env29253) = true)

theorem identity29253 : scanCanonicalize (H12AffineFastState.compose env29253 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29254 : List Nat := [2,0,8,16,0,64,9,81,512,65,0,65,89,81,80,82,64,80,65,81,0,1,17,2,88,64,81,65,64,0,64,1,81,0,1,512]

theorem envBound29254 : H12AffineFastState.Bounded env29254 := by
  intro p hp
  have h : env29254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29253_29254 : H12AffineEnvironment.transform 1 0 env29253 = env29254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29253 == env29254) = true)

theorem identity29254 : scanCanonicalize (H12AffineFastState.compose env29254 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29255 : List Nat := [2,0,8,16,0,17,9,0,512,16,0,16,8,0,1,3,17,1,16,0,0,1,17,2,9,17,0,16,17,0,17,1,0,0,1,512]

theorem envBound29255 : H12AffineFastState.Bounded env29255 := by
  intro p hp
  have h : env29255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29254_29255 : H12AffineEnvironment.transform 5 17 env29254 = env29255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29254 == env29255) = true)

def env29256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67619,1024,8540,78019,33,16,73736,8328,64,203847,79131,77954,212078,1365,73771,256,73770,79314,74371]

theorem envBound29256 : H12AffineFastState.Bounded env29256 := by
  intro p hp
  have h : env29256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29243_29256 : H12AffineEnvironment.transform 14 8541 env29243 = env29256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29243 == env29256) = true)

theorem identity29256 : scanCanonicalize (H12AffineFastState.compose env29256 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound29256 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,13461,67619,1024,8540,78019,33,16,73736,8328,64,75986,79131,77954,67835,1365,73771,256,73770,79314,74371]

theorem envBound29257 : H12AffineFastState.Bounded env29257 := by
  intro p hp
  have h : env29257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29256_29257 : H12AffineEnvironment.transform 16 13461 env29256 = env29257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env29256 == env29257) = true)

theorem identity29257 : scanCanonicalize (H12AffineFastState.compose env29257 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound29257 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env29258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,398,13461,2477,1024,8540,12621,33,16,8582,8328,64,10588,13461,12556,2421,1365,8613,256,8612,13404,8973]

theorem envBound29258 : H12AffineFastState.Bounded env29258 := by
  intro p hp
  have h : env29258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29257_29258 : H12AffineEnvironment.transform 15 398 env29257 = env29258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env29257 == env29258) = true)

theorem identity29258 : scanCanonicalize (H12AffineFastState.compose env29258 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound29258 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env29259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,398,5393,2477,1024,216,4297,33,16,2,268,64,2264,5393,4232,2421,1365,33,256,32,5592,649]

theorem envBound29259 : H12AffineFastState.Bounded env29259 := by
  intro p hp
  have h : env29259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29258_29259 : H12AffineEnvironment.transform 12 388 env29258 = env29259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env29258 == env29259) = true)

theorem identity29259 : scanCanonicalize (H12AffineFastState.compose env29259 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound29259 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29260 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,41,5293,217,35,5308,2048,1024,216,4297,33,16,2,161,64,2264,5308,4232,2264,1272,33,173,32,5237,649]

theorem envBound29260 : H12AffineFastState.Bounded env29260 := by
  intro p hp
  have h : env29260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29259_29260 : H12AffineEnvironment.transform 7 173 env29259 = env29260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env29259 == env29260) = true)

theorem identity29260 : scanCanonicalize (H12AffineFastState.compose env29260 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29260 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env29261 : List Nat := [2,4,8,16,32,64,128,173,512,52,2048,4096,41,4249,217,35,4232,2048,52,216,4297,33,16,2,161,64,2264,4232,4232,2264,204,33,173,32,4161,649]

theorem envBound29261 : H12AffineFastState.Bounded env29261 := by
  intro p hp
  have h : env29261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29260_29261 : H12AffineEnvironment.transform 9 52 env29260 = env29261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29260 == env29261) = true)

def env29262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981333,79131,8466578,8819969,8389956,4292950,256,8462395,8492191,8462994]

theorem envBound29262 : H12AffineFastState.Bounded env29262 := by
  intro p hp
  have h : env29262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29224_29262 : H12AffineEnvironment.transform 13 5377 env29224 = env29262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29224 == env29262) = true)

def env29263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787061,79131,8466578,8819969,8389956,98678,256,8462395,8492191,8462994]

theorem envBound29263 : H12AffineFastState.Bounded env29263 := by
  intro p hp
  have h : env29263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29262_29263 : H12AffineEnvironment.transform 21 32 env29262 = env29263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29262 == env29263) = true)

def env29264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,8388608,98644,8192,64,8787061,79131,8466458,8819969,8389956,98678,256,8462395,8492055,8462874]

theorem envBound29264 : H12AffineFastState.Bounded env29264 := by
  intro p hp
  have h : env29264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29263_29264 : H12AffineEnvironment.transform 6 8 env29263 = env29264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29263 == env29264) = true)

def env29265 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,16,98644,8192,64,398437,79131,77834,431377,1364,98678,256,73771,103431,74250]

theorem envBound29265 : H12AffineFastState.Bounded env29265 := by
  intro p hp
  have h : env29265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29264_29265 : H12AffineEnvironment.transform 22 16 env29264 = env29265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env29264 == env29265) = true)

theorem identity29265 : scanCanonicalize (H12AffineFastState.compose env29265 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound29265 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,45340,32,16,2,8192,64,398437,46157,45404,431377,1364,32,256,41341,5457,41820]

theorem envBound29266 : H12AffineFastState.Bounded env29266 := by
  intro p hp
  have h : env29266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29265_29266 : H12AffineEnvironment.transform 15 33110 env29265 = env29266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env29265 == env29266) = true)

theorem identity29266 : scanCanonicalize (H12AffineFastState.compose env29266 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29266 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env29267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5393,262144,1024,32769,45340,32,16,2,8192,64,262516,46157,45404,294912,1364,32,256,41341,5457,41820]

theorem envBound29267 : H12AffineFastState.Bounded env29267 := by
  intro p hp
  have h : env29267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29266_29267 : H12AffineEnvironment.transform 16 5393 env29266 = env29267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29266 == env29267) = true)

theorem identity29267 : scanCanonicalize (H12AffineFastState.compose env29267 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 43356) := by decide +kernel

theorem selectedBound29267 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env29268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5393,43356,1024,32769,45340,32,16,2,8192,64,43048,46157,45404,10588,1364,32,256,41341,5457,41820]

theorem envBound29268 : H12AffineFastState.Bounded env29268 := by
  intro p hp
  have h : env29268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29267_29268 : H12AffineEnvironment.transform 17 43356 env29267 = env29268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43356 env29267 == env29268) = true)

theorem identity29268 : scanCanonicalize (H12AffineFastState.compose env29268 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound29268 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env29269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8313,8495,5393,2341,1024,8312,4453,32,16,2,8192,64,2129,5172,4389,10588,1364,32,256,260,5457,805]

theorem envBound29269 : H12AffineFastState.Bounded env29269 := by
  intro p hp
  have h : env29269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29268_29269 : H12AffineEnvironment.transform 14 8313 env29268 = env29269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env29268 == env29269) = true)

theorem identity29269 : scanCanonicalize (H12AffineFastState.compose env29269 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29269 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env29270 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8313,8282,5220,2128,1024,8312,4112,32,16,2,8192,64,2129,5172,4176,10281,1057,32,117,113,5156,592]

theorem envBound29270 : H12AffineFastState.Bounded env29270 := by
  intro p hp
  have h : env29270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29269_29270 : H12AffineEnvironment.transform 7 117 env29269 = env29270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29269 == env29270) = true)

theorem identity29270 : scanCanonicalize (H12AffineFastState.compose env29270 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound29270 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29271 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,81,114,5220,2128,1024,80,4112,32,16,2,40,64,2129,5172,4176,2049,1057,32,117,113,5156,592]

theorem envBound29271 : H12AffineFastState.Bounded env29271 := by
  intro p hp
  have h : env29271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29270_29271 : H12AffineEnvironment.transform 12 40 env29270 = env29271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env29270 == env29271) = true)

theorem identity29271 : scanCanonicalize (H12AffineFastState.compose env29271 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29271 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env29272 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1024,0,4112,32,16,2,40,16,2049,5172,4096,2049,1057,32,37,33,5156,512]

theorem envBound29272 : H12AffineFastState.Bounded env29272 := by
  intro p hp
  have h : env29272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29271_29272 : H12AffineEnvironment.transform 5 16 env29271 = env29272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29271 == env29272) = true)

theorem identity29272 : scanCanonicalize (H12AffineFastState.compose env29272 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29273 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,4096,8,5124,1,2,5140,2048,1024,0,4112,0,16,2,8,16,2049,5140,4096,2049,1025,0,5,1,5124,512]

theorem envBound29273 : H12AffineFastState.Bounded env29273 := by
  intro p hp
  have h : env29273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29272_29273 : H12AffineEnvironment.transform 4 0 env29272 = env29273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29272 == env29273) = true)

def env29274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,17,98644,8192,64,398436,79131,77835,431376,1365,98678,256,73770,103430,74251]

theorem envBound29274 : H12AffineFastState.Bounded env29274 := by
  intro p hp
  have h : env29274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29264_29274 : H12AffineEnvironment.transform 22 17 env29264 = env29274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env29264 == env29274) = true)

theorem identity29274 : scanCanonicalize (H12AffineFastState.compose env29274 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound29274 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108926,1024,32769,77898,32,17,98644,8192,64,245018,79131,77835,212078,1365,98678,256,73770,103430,74251]

theorem envBound29275 : H12AffineFastState.Bounded env29275 := by
  intro p hp
  have h : env29275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29274_29275 : H12AffineEnvironment.transform 17 108926 env29274 = env29275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env29274 == env29275) = true)

theorem identity29275 : scanCanonicalize (H12AffineFastState.compose env29275 (packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 111946) := by decide +kernel

theorem selectedBound29275 : packedSelected [0,3,5,8,9,16,19,20,22,26,27,28] rootPS < 2^1333 := by decide +kernel

def env29276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111946,108926,1024,32769,77898,32,17,98644,8192,64,2128,79131,77835,35108,1365,98678,256,73770,103430,74251]

theorem envBound29276 : H12AffineFastState.Bounded env29276 := by
  intro p hp
  have h : env29276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29275_29276 : H12AffineEnvironment.transform 16 111946 env29275 = env29276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111946 env29275 == env29276) = true)

theorem identity29276 : scanCanonicalize (H12AffineFastState.compose env29276 (packedSelected [3,11,14,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 34099) := by decide +kernel

theorem selectedBound29276 : packedSelected [3,11,14,16,18,24] rootPS < 2^1333 := by decide +kernel

def env29277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,34099,12409,11341,1024,32769,46457,32,17,1127,8192,64,2128,45096,46392,35108,1365,1093,256,42265,4405,42808]

theorem envBound29277 : H12AffineFastState.Bounded env29277 := by
  intro p hp
  have h : env29277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29276_29277 : H12AffineEnvironment.transform 15 34099 env29276 = env29277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34099 env29276 == env29277) = true)

theorem identity29277 : scanCanonicalize (H12AffineFastState.compose env29277 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound29277 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,373,1094,12409,11341,1024,372,13324,32,17,1127,8192,64,2128,12637,13389,2129,1365,1093,256,9324,4405,9805]

theorem envBound29278 : H12AffineFastState.Bounded env29278 := by
  intro p hp
  have h : env29278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29277_29278 : H12AffineEnvironment.transform 14 373 env29277 = env29278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env29277 == env29278) = true)

theorem identity29278 : scanCanonicalize (H12AffineFastState.compose env29278 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound29278 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env29279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,373,1094,5173,2049,1024,372,4160,32,17,1127,1100,64,2128,5393,4097,2129,1365,1093,256,32,4405,513]

theorem envBound29279 : H12AffineFastState.Bounded env29279 := by
  intro p hp
  have h : env29279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29278_29279 : H12AffineEnvironment.transform 12 1100 env29278 = env29279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env29278 == env29279) = true)

theorem identity29279 : scanCanonicalize (H12AffineFastState.compose env29279 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29279 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29280 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,40,4453,373,34,4177,2049,100,372,4160,32,17,3,40,64,2128,4469,4097,2129,305,33,256,32,4405,513]

theorem envBound29280 : H12AffineFastState.Bounded env29280 := by
  intro p hp
  have h : env29280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29279_29280 : H12AffineEnvironment.transform 9 100 env29279 = env29280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29279 == env29280) = true)

theorem identity29280 : scanCanonicalize (H12AffineFastState.compose env29280 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29281 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,4096,40,4112,0,34,4177,2049,100,1,4160,32,17,3,40,64,2128,4096,4097,2129,68,33,117,32,4160,513]

theorem envBound29281 : H12AffineFastState.Bounded env29281 := by
  intro p hp
  have h : env29281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29280_29281 : H12AffineEnvironment.transform 7 117 env29280 = env29281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29280 == env29281) = true)

theorem identity29281 : scanCanonicalize (H12AffineFastState.compose env29281 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29281 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env29282 : List Nat := [2,4,8,16,32,49,8,4,512,21,2048,4096,40,4112,0,34,4128,2049,21,1,4145,32,17,3,40,49,2081,4096,4097,2080,53,33,4,32,4145,513]

theorem envBound29282 : H12AffineFastState.Bounded env29282 := by
  intro p hp
  have h : env29282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29281_29282 : H12AffineEnvironment.transform 5 49 env29281 = env29282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29281 == env29282) = true)

theorem identity29282 : scanCanonicalize (H12AffineFastState.compose env29282 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound29282 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29283 : List Nat := [2,4,8,16,32,49,8,4,512,21,2048,2097,40,2081,0,34,2065,2049,21,1,2048,32,17,3,40,49,2081,2097,2096,2080,53,33,4,32,2048,513]

theorem envBound29283 : H12AffineFastState.Bounded env29283 := by
  intro p hp
  have h : env29283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29282_29283 : H12AffineEnvironment.transform 11 2097 env29282 = env29283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env29282 == env29283) = true)

theorem identity29283 : scanCanonicalize (H12AffineFastState.compose env29283 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound29283 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29284 : List Nat := [2,4,8,16,32,49,8,4,512,21,561,512,40,528,0,34,544,560,21,1,561,32,17,3,40,49,528,512,513,529,53,33,4,32,561,513]

theorem envBound29284 : H12AffineFastState.Bounded env29284 := by
  intro p hp
  have h : env29284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29283_29284 : H12AffineEnvironment.transform 10 561 env29283 = env29284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env29283 == env29284) = true)

def env29285 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,8388608,98644,8193,64,8787061,79131,8466459,8819969,8389956,98678,256,8462395,8492054,8462875]

theorem envBound29285 : H12AffineFastState.Bounded env29285 := by
  intro p hp
  have h : env29285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29263_29285 : H12AffineEnvironment.transform 6 9 env29263 = env29285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29263 == env29285) = true)

def env29286 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,16,98644,8193,64,398437,79131,77835,431377,1364,98678,256,73771,103430,74251]

theorem envBound29286 : H12AffineFastState.Bounded env29286 := by
  intro p hp
  have h : env29286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29285_29286 : H12AffineEnvironment.transform 22 16 env29285 = env29286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env29285 == env29286) = true)

theorem identity29286 : scanCanonicalize (H12AffineFastState.compose env29286 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29286 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398437,5393,4097,431377,1364,41340,256,33,46092,513]

theorem envBound29287 : H12AffineFastState.Bounded env29287 := by
  intro p hp
  have h : env29287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29286_29287 : H12AffineEnvironment.transform 15 8202 env29286 = env29287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29286 == env29287) = true)

theorem identity29287 : scanCanonicalize (H12AffineFastState.compose env29287 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29287 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398437,5393,4097,406604,1364,33,256,33,5457,513]

theorem envBound29288 : H12AffineFastState.Bounded env29288 := by
  intro p hp
  have h : env29288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29287_29288 : H12AffineEnvironment.transform 14 8541 env29287 = env29288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29287 == env29288) = true)

theorem identity29288 : scanCanonicalize (H12AffineFastState.compose env29288 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound29288 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5441,262144,1024,8540,4161,32,16,3,8193,64,262436,5393,4097,270605,1364,33,256,33,5457,513]

theorem envBound29289 : H12AffineFastState.Bounded env29289 := by
  intro p hp
  have h : env29289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29288_29289 : H12AffineEnvironment.transform 16 5441 env29288 = env29289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29288 == env29289) = true)

theorem identity29289 : scanCanonicalize (H12AffineFastState.compose env29289 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound29289 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5441,10361,1024,8540,4161,32,16,3,8193,64,10589,5393,4097,2420,1364,33,256,33,5457,513]

theorem envBound29290 : H12AffineFastState.Bounded env29290 := by
  intro p hp
  have h : env29290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29289_29290 : H12AffineEnvironment.transform 17 10361 env29289 = env29290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env29289 == env29290) = true)

theorem identity29290 : scanCanonicalize (H12AffineFastState.compose env29290 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29290 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29291 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,5393,10281,1024,8460,4113,32,16,3,8193,16,10509,5393,4097,2340,1284,33,256,33,5377,513]

theorem envBound29291 : H12AffineFastState.Bounded env29291 := by
  intro p hp
  have h : env29291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29290_29291 : H12AffineEnvironment.transform 5 16 env29290 = env29291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29290 == env29291) = true)

theorem identity29291 : scanCanonicalize (H12AffineFastState.compose env29291 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound29291 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29292 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,8192,308,8461,8202,292,10281,1024,8460,1060,32,16,3,8193,16,10509,292,1076,2340,1284,33,256,33,308,513]

theorem envBound29292 : H12AffineFastState.Bounded env29292 := by
  intro p hp
  have h : env29292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29291_29292 : H12AffineEnvironment.transform 11 1077 env29291 = env29292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env29291 == env29292) = true)

theorem identity29292 : scanCanonicalize (H12AffineFastState.compose env29292 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2083) := by decide +kernel

theorem selectedBound29292 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env29293 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,2083,308,2350,2089,292,10,1024,2351,1060,32,16,3,2082,16,302,292,1076,2340,1284,33,256,33,308,513]

theorem envBound29293 : H12AffineFastState.Bounded env29293 := by
  intro p hp
  have h : env29293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29292_29293 : H12AffineEnvironment.transform 12 2083 env29292 = env29293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2083 env29292 == env29293) = true)

theorem identity29293 : scanCanonicalize (H12AffineFastState.compose env29293 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound29293 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29294 : List Nat := [2,4,8,16,32,16,9,256,512,1024,302,1077,269,308,0,263,292,10,1024,1,1060,32,16,3,268,16,302,292,1076,10,1284,33,256,33,308,513]

theorem envBound29294 : H12AffineFastState.Bounded env29294 := by
  intro p hp
  have h : env29294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29293_29294 : H12AffineEnvironment.transform 10 302 env29293 = env29294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env29293 == env29294) = true)

theorem identity29294 : scanCanonicalize (H12AffineFastState.compose env29294 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound29294 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29295 : List Nat := [2,4,8,16,32,16,9,256,512,289,302,276,269,308,0,263,292,10,289,1,261,32,16,3,268,16,302,292,277,10,37,33,256,33,308,513]

theorem envBound29295 : H12AffineFastState.Bounded env29295 := by
  intro p hp
  have h : env29295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29294_29295 : H12AffineEnvironment.transform 9 289 env29294 = env29295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env29294 == env29295) = true)

theorem identity29295 : scanCanonicalize (H12AffineFastState.compose env29295 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound29295 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29296 : List Nat := [2,4,8,16,32,16,9,63,512,30,17,43,50,11,0,56,27,10,30,1,58,32,16,3,51,16,17,27,42,10,37,33,63,33,11,513]

theorem envBound29296 : H12AffineFastState.Bounded env29296 := by
  intro p hp
  have h : env29296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29295_29296 : H12AffineEnvironment.transform 7 63 env29295 = env29296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env29295 == env29296) = true)

theorem identity29296 : scanCanonicalize (H12AffineFastState.compose env29296 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29296 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29297 : List Nat := [2,4,8,16,16,16,9,15,512,30,17,27,2,11,0,8,27,10,30,1,10,16,16,3,3,16,17,27,26,10,21,17,15,17,11,513]

theorem envBound29297 : H12AffineFastState.Bounded env29297 := by
  intro p hp
  have h : env29297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29296_29297 : H12AffineEnvironment.transform 4 16 env29296 = env29297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29296 == env29297) = true)

theorem identity29297 : scanCanonicalize (H12AffineFastState.compose env29297 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29297 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env29298 : List Nat := [2,4,8,0,0,0,9,15,512,14,1,11,2,11,0,8,11,10,14,1,10,0,0,3,3,0,1,11,10,10,5,1,15,1,11,513]

theorem envBound29298 : H12AffineFastState.Bounded env29298 := by
  intro p hp
  have h : env29298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29297_29298 : H12AffineEnvironment.transform 3 0 env29297 = env29298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29297 == env29298) = true)

theorem identity29298 : scanCanonicalize (H12AffineFastState.compose env29298 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound29298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29299 : List Nat := [2,4,8,0,0,0,9,15,8,14,1,11,2,11,0,8,11,10,14,1,10,0,0,3,3,0,1,11,10,10,5,1,15,1,11,9]

theorem envBound29299 : H12AffineFastState.Bounded env29299 := by
  intro p hp
  have h : env29299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29298_29299 : H12AffineEnvironment.transform 8 8 env29298 = env29299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env29298 == env29299) = true)

theorem identity29299 : scanCanonicalize (H12AffineFastState.compose env29299 (packedSelected [12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29299 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env29300 : List Nat := [2,4,3,0,0,0,2,4,3,5,1,0,2,0,0,3,0,1,5,1,1,0,0,3,3,0,1,0,1,1,5,1,4,1,0,2]

theorem envBound29300 : H12AffineFastState.Bounded env29300 := by
  intro p hp
  have h : env29300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29299_29300 : H12AffineEnvironment.transform 2 3 env29299 = env29300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29299 == env29300) = true)

theorem identity29300 : scanCanonicalize (H12AffineFastState.compose env29300 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29301 : List Nat := [2,2,3,0,0,0,2,2,3,3,1,0,2,0,0,3,0,1,3,1,1,0,0,3,3,0,1,0,1,1,3,1,2,1,0,2]

theorem envBound29301 : H12AffineFastState.Bounded env29301 := by
  intro p hp
  have h : env29301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29300_29301 : H12AffineEnvironment.transform 1 2 env29300 = env29301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29300 == env29301) = true)

def env29302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,17,98644,8193,64,398436,79131,77834,431376,1365,98678,256,73770,103431,74250]

theorem envBound29302 : H12AffineFastState.Bounded env29302 := by
  intro p hp
  have h : env29302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29285_29302 : H12AffineEnvironment.transform 22 17 env29285 = env29302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env29285 == env29302) = true)

theorem identity29302 : scanCanonicalize (H12AffineFastState.compose env29302 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound29302 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,77899,32,17,98644,8193,64,203847,79131,77834,236851,1365,98678,256,73770,103431,74250]

theorem envBound29303 : H12AffineFastState.Bounded env29303 := by
  intro p hp
  have h : env29303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29302_29303 : H12AffineEnvironment.transform 17 67619 env29302 = env29303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env29302 == env29303) = true)

theorem identity29303 : scanCanonicalize (H12AffineFastState.compose env29303 (packedSelected [1,2,6,8,10,11,12,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 103494) := by decide +kernel

theorem selectedBound29303 : packedSelected [1,2,6,8,10,11,12,14,20] rootPS < 2^1333 := by decide +kernel

def env29304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,103494,67619,1024,32769,77899,32,17,98644,8193,64,34817,79131,77834,2421,1365,98678,256,73770,103431,74250]

theorem envBound29304 : H12AffineFastState.Bounded env29304 := by
  intro p hp
  have h : env29304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29303_29304 : H12AffineEnvironment.transform 16 103494 env29303 = env29304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103494 env29303 == env29304) = true)

theorem identity29304 : scanCanonicalize (H12AffineFastState.compose env29304 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound29304 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,5393,35188,1024,32769,45340,32,17,3,8193,64,34817,46156,45405,2421,1365,33,256,41341,5456,41821]

theorem envBound29305 : H12AffineFastState.Bounded env29305 := by
  intro p hp
  have h : env29305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29304_29305 : H12AffineEnvironment.transform 15 33111 env29304 = env29305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env29304 == env29305) = true)

theorem identity29305 : scanCanonicalize (H12AffineFastState.compose env29305 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound29305 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,32768,33111,5393,35188,1024,32769,37220,32,17,3,121,64,34817,37940,37157,2421,1365,33,256,33029,5456,33573]

theorem envBound29306 : H12AffineFastState.Bounded env29306 := by
  intro p hp
  have h : env29306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29305_29306 : H12AffineEnvironment.transform 12 120 env29305 = env29306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env29305 == env29306) = true)

theorem identity29306 : scanCanonicalize (H12AffineFastState.compose env29306 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29306 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,0,343,5393,2420,1024,1,4452,32,17,3,121,64,2049,5172,4389,2421,1365,33,256,261,5456,805]

theorem envBound29307 : H12AffineFastState.Bounded env29307 := by
  intro p hp
  have h : env29307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29306_29307 : H12AffineEnvironment.transform 14 0 env29306 = env29307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29306 == env29307) = true)

theorem identity29307 : scanCanonicalize (H12AffineFastState.compose env29307 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29307 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29308 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,0,34,5220,2049,1024,1,4113,32,17,3,121,64,2049,5172,4176,2048,1056,33,117,112,5157,592]

theorem envBound29308 : H12AffineFastState.Bounded env29308 := by
  intro p hp
  have h : env29308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29307_29308 : H12AffineEnvironment.transform 7 117 env29307 = env29308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29307 == env29308) = true)

theorem identity29308 : scanCanonicalize (H12AffineFastState.compose env29308 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29308 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29309 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,120,5236,0,34,5220,1,1024,1,4113,32,17,3,121,64,1,5172,4176,0,1056,33,117,112,5157,592]

theorem envBound29309 : H12AffineFastState.Bounded env29309 := by
  intro p hp
  have h : env29309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29308_29309 : H12AffineEnvironment.transform 10 0 env29308 = env29309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29308 == env29309) = true)

theorem identity29309 : scanCanonicalize (H12AffineFastState.compose env29309 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound29309 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env29310 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,64,120,1076,0,34,1060,1,1024,1,81,32,17,3,121,64,1,1140,16,0,1056,33,117,112,1125,592]

theorem envBound29310 : H12AffineFastState.Bounded env29310 := by
  intro p hp
  have h : env29310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29309_29310 : H12AffineEnvironment.transform 11 64 env29309 = env29310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env29309 == env29310) = true)

def env29311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787060,79131,8466578,8819969,8389956,98679,256,8462395,8492191,8462994]

theorem envBound29311 : H12AffineFastState.Bounded env29311 := by
  intro p hp
  have h : env29311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29262_29311 : H12AffineEnvironment.transform 21 33 env29262 = env29311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env29262 == env29311) = true)

theorem identity29311 : scanCanonicalize (H12AffineFastState.compose env29311 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound29311 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,16,98644,8328,64,398436,79131,77954,431377,1364,98679,256,73771,103567,74370]

theorem envBound29312 : H12AffineFastState.Bounded env29312 := by
  intro p hp
  have h : env29312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29311_29312 : H12AffineEnvironment.transform 22 16 env29311 = env29312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env29311 == env29312) = true)

def env29313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,16,98644,8192,64,398436,79131,77834,431377,1364,98679,256,73771,103431,74250]

theorem envBound29313 : H12AffineFastState.Bounded env29313 := by
  intro p hp
  have h : env29313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29312_29313 : H12AffineEnvironment.transform 6 8 env29312 = env29313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29312 == env29313) = true)

theorem identity29313 : scanCanonicalize (H12AffineFastState.compose env29313 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound29313 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,45340,33,16,2,8192,64,398436,46157,45404,431377,1364,33,256,41341,5457,41820]

theorem envBound29314 : H12AffineFastState.Bounded env29314 := by
  intro p hp
  have h : env29314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29313_29314 : H12AffineEnvironment.transform 15 33110 env29313 = env29314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env29313 == env29314) = true)

theorem identity29314 : scanCanonicalize (H12AffineFastState.compose env29314 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound29314 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env29315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,46156,262144,1024,32769,45340,33,16,2,8192,64,303144,46157,45404,270685,1364,33,256,41341,5457,41820]

theorem envBound29315 : H12AffineFastState.Bounded env29315 := by
  intro p hp
  have h : env29315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29314_29315 : H12AffineEnvironment.transform 16 46156 env29314 = env29315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env29314 == env29315) = true)

theorem identity29315 : scanCanonicalize (H12AffineFastState.compose env29315 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29315 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,262144,1024,8540,4161,33,16,2,8192,64,262517,5392,4097,270685,1364,33,256,32,5457,513]

theorem envBound29316 : H12AffineFastState.Bounded env29316 := by
  intro p hp
  have h : env29316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29315_29316 : H12AffineEnvironment.transform 14 8541 env29315 = env29316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29315 == env29316) = true)

theorem identity29316 : scanCanonicalize (H12AffineFastState.compose env29316 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound29316 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10281,1024,8540,4161,33,16,2,8192,64,10588,5392,4097,2420,1364,33,256,32,5457,513]

theorem envBound29317 : H12AffineFastState.Bounded env29317 := by
  intro p hp
  have h : env29317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29316_29317 : H12AffineEnvironment.transform 17 10281 env29316 = env29317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29316 == env29317) = true)

theorem identity29317 : scanCanonicalize (H12AffineFastState.compose env29317 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound29317 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,9,5377,340,2,5393,2080,1024,341,4161,33,16,2,9,64,2389,5392,4097,2420,1364,33,256,32,5457,513]

theorem envBound29318 : H12AffineFastState.Bounded env29318 := by
  intro p hp
  have h : env29318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29317_29318 : H12AffineEnvironment.transform 12 9 env29317 = env29318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env29317 == env29318) = true)

theorem identity29318 : scanCanonicalize (H12AffineFastState.compose env29318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29319 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,9,4112,340,2,4096,2080,273,341,4161,33,16,2,9,64,2389,4097,4097,2420,69,33,256,32,4160,513]

theorem envBound29319 : H12AffineFastState.Bounded env29319 := by
  intro p hp
  have h : env29319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29318_29319 : H12AffineEnvironment.transform 9 273 env29318 = env29319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29318 == env29319) = true)

theorem identity29319 : scanCanonicalize (H12AffineFastState.compose env29319 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound29319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29320 : List Nat := [2,4,8,16,32,64,8,100,512,117,2048,4096,9,4112,48,2,4096,2080,117,49,4161,33,16,2,9,64,2097,4097,4097,2064,69,33,100,32,4160,513]

theorem envBound29320 : H12AffineFastState.Bounded env29320 := by
  intro p hp
  have h : env29320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29319_29320 : H12AffineEnvironment.transform 7 100 env29319 = env29320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env29319 == env29320) = true)

theorem identity29320 : scanCanonicalize (H12AffineFastState.compose env29320 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound29320 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29321 : List Nat := [2,4,8,16,32,64,8,100,512,117,2048,529,9,513,48,2,529,2080,117,49,592,33,16,2,9,64,2097,528,528,2064,69,33,100,32,593,513]

theorem envBound29321 : H12AffineFastState.Bounded env29321 := by
  intro p hp
  have h : env29321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29320_29321 : H12AffineEnvironment.transform 11 529 env29320 = env29321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env29320 == env29321) = true)

theorem identity29321 : scanCanonicalize (H12AffineFastState.compose env29321 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound29321 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29322 : List Nat := [2,4,8,16,32,64,8,100,512,117,608,529,9,513,48,2,529,576,117,49,592,33,16,2,9,64,593,528,528,624,69,33,100,32,593,513]

theorem envBound29322 : H12AffineFastState.Bounded env29322 := by
  intro p hp
  have h : env29322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29321_29322 : H12AffineEnvironment.transform 10 608 env29321 = env29322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env29321 == env29322) = true)

theorem identity29322 : scanCanonicalize (H12AffineFastState.compose env29322 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29322 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29323 : List Nat := [2,4,8,16,32,17,8,53,512,36,561,529,9,513,48,2,529,529,36,49,513,33,16,2,9,17,512,528,528,545,20,33,53,32,512,513]

theorem envBound29323 : H12AffineFastState.Bounded env29323 := by
  intro p hp
  have h : env29323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29322_29323 : H12AffineEnvironment.transform 5 17 env29322 = env29323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29322 == env29323) = true)

theorem identity29323 : scanCanonicalize (H12AffineFastState.compose env29323 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29324 : List Nat := [2,4,8,16,32,17,8,53,1,36,48,16,9,0,48,2,16,16,36,49,0,33,16,2,9,17,1,17,17,32,20,33,53,32,1,0]

theorem envBound29324 : H12AffineFastState.Bounded env29324 := by
  intro p hp
  have h : env29324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29323_29324 : H12AffineEnvironment.transform 8 1 env29323 = env29324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29323 == env29324) = true)

theorem identity29324 : scanCanonicalize (H12AffineFastState.compose env29324 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29325 : List Nat := [2,4,8,16,1,17,8,20,1,5,17,16,9,0,17,2,16,16,5,16,0,0,16,2,9,17,1,17,17,1,20,0,20,1,1,0]

theorem envBound29325 : H12AffineFastState.Bounded env29325 := by
  intro p hp
  have h : env29325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29324_29325 : H12AffineEnvironment.transform 4 1 env29324 = env29325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29324 == env29325) = true)

theorem identity29325 : scanCanonicalize (H12AffineFastState.compose env29325 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29325 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env29326 : List Nat := [2,4,8,1,1,0,8,5,1,5,0,1,9,0,0,2,1,1,5,1,0,0,1,2,9,0,1,0,0,1,5,0,5,1,1,0]

theorem envBound29326 : H12AffineFastState.Bounded env29326 := by
  intro p hp
  have h : env29326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29325_29326 : H12AffineEnvironment.transform 3 1 env29325 = env29326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29325 == env29326) = true)

def env29327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,33,16,98644,8193,64,398436,79131,77835,431377,1364,98679,256,73771,103430,74251]

theorem envBound29327 : H12AffineFastState.Bounded env29327 := by
  intro p hp
  have h : env29327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29312_29327 : H12AffineEnvironment.transform 6 9 env29312 = env29327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29312 == env29327) = true)

theorem identity29327 : scanCanonicalize (H12AffineFastState.compose env29327 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29327 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398436,5393,4097,431377,1364,41341,256,33,46092,513]

theorem envBound29328 : H12AffineFastState.Bounded env29328 := by
  intro p hp
  have h : env29328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29327_29328 : H12AffineEnvironment.transform 15 8202 env29327 = env29328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29327 == env29328) = true)

theorem identity29328 : scanCanonicalize (H12AffineFastState.compose env29328 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29328 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398436,5393,4097,406604,1364,32,256,33,5457,513]

theorem envBound29329 : H12AffineFastState.Bounded env29329 := by
  intro p hp
  have h : env29329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29328_29329 : H12AffineEnvironment.transform 14 8541 env29328 = env29329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29328 == env29329) = true)

theorem identity29329 : scanCanonicalize (H12AffineFastState.compose env29329 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound29329 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5441,262144,1024,8540,4161,33,16,3,8193,64,262437,5393,4097,270605,1364,32,256,33,5457,513]

theorem envBound29330 : H12AffineFastState.Bounded env29330 := by
  intro p hp
  have h : env29330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29329_29330 : H12AffineEnvironment.transform 16 5441 env29329 = env29330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env29329 == env29330) = true)

theorem identity29330 : scanCanonicalize (H12AffineFastState.compose env29330 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound29330 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5441,2421,1024,8540,4161,33,16,3,8193,64,2128,5393,4097,10360,1364,32,256,33,5457,513]

theorem envBound29331 : H12AffineFastState.Bounded env29331 := by
  intro p hp
  have h : env29331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29330_29331 : H12AffineEnvironment.transform 17 2421 env29330 = env29331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env29330 == env29331) = true)

theorem identity29331 : scanCanonicalize (H12AffineFastState.compose env29331 (packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29331 : packedSelected [0,3,4,5,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5441,2421,1024,1,4161,33,16,3,348,64,2128,5393,4097,2341,1364,32,256,33,5457,513]

theorem envBound29332 : H12AffineFastState.Bounded env29332 := by
  intro p hp
  have h : env29332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29331_29332 : H12AffineEnvironment.transform 12 349 env29331 = env29332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29331 == env29332) = true)

theorem identity29332 : scanCanonicalize (H12AffineFastState.compose env29332 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29332 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29333 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1024,1,4112,33,16,3,269,17,2049,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound29333 : H12AffineFastState.Bounded env29333 := by
  intro p hp
  have h : env29333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29332_29333 : H12AffineEnvironment.transform 5 17 env29332 = env29333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29332 == env29333) = true)

theorem identity29333 : scanCanonicalize (H12AffineFastState.compose env29333 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29333 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29334 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5172,2048,1024,1,4112,33,16,3,41,17,2049,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound29334 : H12AffineFastState.Bounded env29334 := by
  intro p hp
  have h : env29334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29333_29334 : H12AffineEnvironment.transform 7 36 env29333 = env29334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29333 == env29334) = true)

theorem identity29334 : scanCanonicalize (H12AffineFastState.compose env29334 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29334 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29335 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4113,0,34,4096,2048,52,1,4112,33,16,3,41,17,2049,4097,4097,2049,21,32,36,33,4112,513]

theorem envBound29335 : H12AffineFastState.Bounded env29335 := by
  intro p hp
  have h : env29335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29334_29335 : H12AffineEnvironment.transform 9 52 env29334 = env29335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29334 == env29335) = true)

theorem identity29335 : scanCanonicalize (H12AffineFastState.compose env29335 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound29335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29336 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,33,40,48,0,34,33,2048,52,1,49,33,16,3,41,17,2049,32,32,2049,21,32,36,33,49,513]

theorem envBound29336 : H12AffineFastState.Bounded env29336 := by
  intro p hp
  have h : env29336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29335_29336 : H12AffineEnvironment.transform 11 33 env29335 = env29336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env29335 == env29336) = true)

theorem identity29336 : scanCanonicalize (H12AffineFastState.compose env29336 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound29336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29337 : List Nat := [2,4,8,16,32,17,9,36,512,52,32,33,40,48,0,34,33,32,52,1,49,33,16,3,41,17,33,32,32,33,21,32,36,33,49,513]

theorem envBound29337 : H12AffineFastState.Bounded env29337 := by
  intro p hp
  have h : env29337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29336_29337 : H12AffineEnvironment.transform 10 32 env29336 = env29337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env29336 == env29337) = true)

theorem identity29337 : scanCanonicalize (H12AffineFastState.compose env29337 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29337 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29338 : List Nat := [2,4,8,1,32,0,9,36,512,37,32,33,40,33,0,34,33,32,37,1,32,33,1,3,41,0,33,32,32,33,4,32,36,33,32,513]

theorem envBound29338 : H12AffineFastState.Bounded env29338 := by
  intro p hp
  have h : env29338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29337_29338 : H12AffineEnvironment.transform 3 1 env29337 = env29338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29337 == env29338) = true)

def env29339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound29339 : H12AffineFastState.Bounded env29339 := by
  intro p hp
  have h : env29339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29143_29339 : H12AffineEnvironment.transform 18 1025 env29143 = env29339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env29143 == env29339) = true)

theorem identity29339 : scanCanonicalize (H12AffineFastState.compose env29339 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10650946) := by decide +kernel

theorem selectedBound29339 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10650946,8328,64,6636867,8585678,10507601,8830977,2294098,12836995,257,213487,237643,2238085]

theorem envBound29340 : H12AffineFastState.Bounded env29340 := by
  intro p hp
  have h : env29340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29339_29340 : H12AffineEnvironment.transform 23 10650946 env29339 = env29340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10650946 env29339 == env29340) = true)

def env29341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180224,2114882,8328,64,6636867,115150,2266449,262145,2294098,4268163,257,213487,237643,2238085]

theorem envBound29341 : H12AffineFastState.Bounded env29341 := by
  intro p hp
  have h : env29341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29340_29341 : H12AffineEnvironment.transform 22 180224 env29340 = env29341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env29340 == env29341) = true)

def env29342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,169234,8328,64,4691219,115150,17665,262145,119042,4268163,257,213487,237643,63189]

theorem envBound29342 : H12AffineFastState.Bounded env29342 := by
  intro p hp
  have h : env29342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29341_29342 : H12AffineEnvironment.transform 20 184400 env29341 = env29342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env29341 == env29342) = true)

def env29343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,169234,8328,64,245139,115150,17665,262145,119042,329731,257,213487,237643,63189]

theorem envBound29343 : H12AffineFastState.Bounded env29343 := by
  intro p hp
  have h : env29343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29342_29343 : H12AffineEnvironment.transform 21 272512 env29342 = env29343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29342 == env29343) = true)

theorem identity29343 : scanCanonicalize (H12AffineFastState.compose env29343 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound29343 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58517,272512,62661,41431,8328,64,100694,115150,17665,262145,119042,329731,257,95530,103566,63189]

theorem envBound29344 : H12AffineFastState.Bounded env29344 := by
  intro p hp
  have h : env29344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29343_29344 : H12AffineEnvironment.transform 16 13509 env29343 = env29344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env29343 == env29344) = true)

def env29345 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58517,272512,62613,41351,8328,16,100614,115102,17665,262145,119042,329731,257,95530,103566,63109]

theorem envBound29345 : H12AffineFastState.Bounded env29345 := by
  intro p hp
  have h : env29345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29344_29345 : H12AffineEnvironment.transform 5 16 env29344 = env29345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29344 == env29345) = true)

theorem identity29345 : scanCanonicalize (H12AffineFastState.compose env29345 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 100522) := by decide +kernel

theorem selectedBound29345 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env29346 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,100522,1025,32769,58517,106538,62613,41351,8328,16,100614,115102,17665,100523,119042,32937,257,95530,103566,63109]

theorem envBound29346 : H12AffineFastState.Bounded env29346 := by
  intro p hp
  have h : env29346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29345_29346 : H12AffineEnvironment.transform 17 100522 env29345 = env29346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100522 env29345 == env29346) = true)

theorem identity29346 : scanCanonicalize (H12AffineFastState.compose env29346 (packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound29346 : packedSelected [3,4,7,9,11,17,19,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env29347 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,13461,76198,1025,8461,17817,65830,21913,139,8328,16,75786,90258,17665,76199,94222,8613,257,95530,79234,22409]

theorem envBound29347 : H12AffineFastState.Bounded env29347 := by
  intro p hp
  have h : env29347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29346_29347 : H12AffineEnvironment.transform 14 8460 env29346 = env29347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env29346 == env29347) = true)

theorem identity29347 : scanCanonicalize (H12AffineFastState.compose env29347 (packedSelected [17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29347 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env29348 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,262,13461,10400,1025,8461,17817,32,21913,139,8328,16,10508,24980,17665,10401,28936,8613,257,29740,13444,22409]

theorem envBound29348 : H12AffineFastState.Bounded env29348 := by
  intro p hp
  have h : env29348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29347_29348 : H12AffineEnvironment.transform 15 262 env29347 = env29348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29347 == env29348) = true)

theorem identity29348 : scanCanonicalize (H12AffineFastState.compose env29348 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound29348 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29349 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,262,13461,10400,1025,8461,4113,32,17,139,8328,16,10508,13340,4233,10401,9344,8613,257,8612,13444,513]

theorem envBound29349 : H12AffineFastState.Bounded env29349 := by
  intro p hp
  have h : env29349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29348_29349 : H12AffineEnvironment.transform 13 5512 env29348 = env29349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env29348 == env29349) = true)

theorem identity29349 : scanCanonicalize (H12AffineFastState.compose env29349 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29350 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,262,13340,10281,1025,8461,4113,32,17,2,8193,16,10508,13340,4096,10280,9225,8492,257,8493,13325,513]

theorem envBound29350 : H12AffineFastState.Bounded env29350 := by
  intro p hp
  have h : env29350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29349_29350 : H12AffineEnvironment.transform 6 9 env29349 = env29350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29349 == env29350) = true)

theorem identity29350 : scanCanonicalize (H12AffineFastState.compose env29350 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29350 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29351 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4113,32,17,2,268,16,2049,5393,4096,2341,1284,33,257,32,5376,513]

theorem envBound29351 : H12AffineFastState.Bounded env29351 := by
  intro p hp
  have h : env29351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29350_29351 : H12AffineEnvironment.transform 12 269 env29350 = env29351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29350 == env29351) = true)

theorem identity29351 : scanCanonicalize (H12AffineFastState.compose env29351 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound29351 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29352 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,33,269,1312,1,262,1328,2340,1025,0,48,32,17,2,268,16,2049,1328,33,2341,1284,33,257,32,1313,513]

theorem envBound29352 : H12AffineFastState.Bounded env29352 := by
  intro p hp
  have h : env29352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29351_29352 : H12AffineEnvironment.transform 11 33 env29351 = env29352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env29351 == env29352) = true)

theorem identity29352 : scanCanonicalize (H12AffineFastState.compose env29352 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound29352 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29353 : List Nat := [2,4,8,16,32,16,9,256,293,1024,2048,33,269,1312,1,262,1328,2340,1025,0,48,32,17,2,268,16,2049,1328,33,2341,1284,33,257,32,1313,292]

theorem envBound29353 : H12AffineFastState.Bounded env29353 := by
  intro p hp
  have h : env29353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29352_29353 : H12AffineEnvironment.transform 8 293 env29352 = env29353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env29352 == env29353) = true)

theorem identity29353 : scanCanonicalize (H12AffineFastState.compose env29353 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound29353 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29354 : List Nat := [2,4,8,16,32,16,9,256,293,1024,277,33,269,1312,1,262,1328,49,1025,0,48,32,17,2,268,16,276,1328,33,48,1284,33,257,32,1313,292]

theorem envBound29354 : H12AffineFastState.Bounded env29354 := by
  intro p hp
  have h : env29354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29353_29354 : H12AffineEnvironment.transform 10 277 env29353 = env29354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env29353 == env29354) = true)

theorem identity29354 : scanCanonicalize (H12AffineFastState.compose env29354 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29354 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29355 : List Nat := [2,4,8,16,32,16,9,5,32,1024,16,33,8,1061,1,3,1077,49,1025,0,48,32,17,2,9,16,17,1077,33,48,1025,33,4,32,1060,33]

theorem envBound29355 : H12AffineFastState.Bounded env29355 := by
  intro p hp
  have h : env29355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29354_29355 : H12AffineEnvironment.transform 7 5 env29354 = env29355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29354 == env29355) = true)

theorem identity29355 : scanCanonicalize (H12AffineFastState.compose env29355 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29355 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29356 : List Nat := [2,4,8,16,1,16,9,5,1,1024,16,0,8,1028,1,3,1044,16,1025,0,17,1,17,2,9,16,17,1044,0,17,1025,0,4,1,1029,0]

theorem envBound29356 : H12AffineFastState.Bounded env29356 := by
  intro p hp
  have h : env29356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29355_29356 : H12AffineEnvironment.transform 4 1 env29355 = env29356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29355 == env29356) = true)

def env29357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58517,272512,62612,41350,8328,17,100615,115103,17665,262145,119042,329731,257,95530,103566,63108]

theorem envBound29357 : H12AffineFastState.Bounded env29357 := by
  intro p hp
  have h : env29357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29344_29357 : H12AffineEnvironment.transform 5 17 env29344 = env29357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29344 == env29357) = true)

theorem identity29357 : scanCanonicalize (H12AffineFastState.compose env29357 (packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23725) := by decide +kernel

theorem selectedBound29357 : packedSelected [1,3,4,7,9,10,14,16,18,19,20,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env29358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,23725,1025,32769,58517,29741,62612,41350,8328,17,100615,115103,17665,23724,119042,87214,257,95530,103566,63108]

theorem envBound29358 : H12AffineFastState.Bounded env29358 := by
  intro p hp
  have h : env29358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29357_29358 : H12AffineEnvironment.transform 17 23725 env29357 = env29358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23725 env29357 == env29358) = true)

theorem identity29358 : scanCanonicalize (H12AffineFastState.compose env29358 (packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound29358 : packedSelected [3,5,8,11,16,19,20,26,28,32] rootPS < 2^1333 := by decide +kernel

def env29359 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13460,23725,1025,32769,58517,29741,62612,41350,8328,17,23944,5392,17665,23724,1421,32801,257,41381,16385,63108]

theorem envBound29359 : H12AffineFastState.Bounded env29359 := by
  intro p hp
  have h : env29359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29358_29359 : H12AffineEnvironment.transform 15 54415 env29358 = env29359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env29358 == env29359) = true)

theorem identity29359 : scanCanonicalize (H12AffineFastState.compose env29359 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound29359 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env29360 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,137,21510,13460,23725,1025,136,25628,29741,29725,8463,8328,17,23944,5392,17665,23724,1421,168,257,8492,16385,30221]

theorem envBound29360 : H12AffineFastState.Bounded env29360 := by
  intro p hp
  have h : env29360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29359_29360 : H12AffineEnvironment.transform 14 137 env29359 = env29360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env29359 == env29360) = true)

theorem identity29360 : scanCanonicalize (H12AffineFastState.compose env29360 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound29360 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env29361 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,8192,16384,137,18831,10525,16676,1025,136,25628,27044,27028,8463,8328,17,16385,2201,17665,16677,1421,168,257,8492,16385,27524]

theorem envBound29361 : H12AffineFastState.Bounded env29361 := by
  intro p hp
  have h : env29361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29360_29361 : H12AffineEnvironment.transform 11 3465 env29360 = env29361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env29360 == env29361) = true)

theorem identity29361 : scanCanonicalize (H12AffineFastState.compose env29361 (packedSelected [2,4,6,9,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound29361 : packedSelected [2,4,6,9,12,15,18] rootPS < 2^1333 := by decide +kernel

def env29362 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,3384,16384,137,18831,1061,16676,1025,136,18724,17564,17580,3127,3504,17,16385,2201,17665,16677,1421,168,257,3092,16385,18108]

theorem envBound29362 : H12AffineFastState.Bounded env29362 := by
  intro p hp
  have h : env29362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29361_29362 : H12AffineEnvironment.transform 12 3384 env29361 = env29362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env29361 == env29362) = true)

theorem identity29362 : scanCanonicalize (H12AffineFastState.compose env29362 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound29362 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env29363 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3465,3384,2340,137,171,1061,2048,1025,136,0,3512,3464,3127,3504,17,2341,2201,3109,2049,1421,168,257,3092,2341,3992]

theorem envBound29363 : H12AffineFastState.Bounded env29363 := by
  intro p hp
  have h : env29363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29362_29363 : H12AffineEnvironment.transform 13 2340 env29362 = env29363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env29362 == env29363) = true)

theorem identity29363 : scanCanonicalize (H12AffineFastState.compose env29363 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound29363 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29364 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3108,3221,2185,137,171,1061,2048,1025,136,0,3093,3109,3127,3101,17,2184,2201,3109,2049,1056,168,172,3092,2184,3637]

theorem envBound29364 : H12AffineFastState.Bounded env29364 := by
  intro p hp
  have h : env29364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29363_29364 : H12AffineEnvironment.transform 7 173 env29363 = env29364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env29363 == env29364) = true)

theorem identity29364 : scanCanonicalize (H12AffineFastState.compose env29364 (packedSelected [1,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound29364 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env29365 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,153,40,1076,137,171,1061,1213,1025,136,0,168,152,138,160,17,1077,1060,152,1212,1056,168,172,169,1077,648]

theorem envBound29365 : H12AffineFastState.Bounded env29365 := by
  intro p hp
  have h : env29365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29364_29365 : H12AffineEnvironment.transform 10 1213 env29364 = env29365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env29364 == env29365) = true)

theorem identity29365 : scanCanonicalize (H12AffineFastState.compose env29365 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29365 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env29366 : List Nat := [2,4,8,16,32,17,128,173,512,52,137,153,40,0,137,171,17,137,53,136,0,168,152,138,160,17,1,16,152,136,20,168,172,169,1,648]

theorem envBound29366 : H12AffineFastState.Bounded env29366 := by
  intro p hp
  have h : env29366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29365_29366 : H12AffineEnvironment.transform 9 52 env29365 = env29366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29365 == env29366) = true)

theorem identity29366 : scanCanonicalize (H12AffineFastState.compose env29366 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29366 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29367 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,40,0,1,35,17,1,53,0,0,32,16,2,40,17,1,16,16,0,20,32,36,33,1,512]

theorem envBound29367 : H12AffineFastState.Bounded env29367 := by
  intro p hp
  have h : env29367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29366_29367 : H12AffineEnvironment.transform 6 8 env29366 = env29367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29366 == env29367) = true)

theorem identity29367 : scanCanonicalize (H12AffineFastState.compose env29367 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound29367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29368 : List Nat := [2,4,8,14,32,15,8,37,512,42,1,15,40,0,1,35,15,1,43,0,0,32,14,2,40,15,1,14,14,0,10,32,36,33,1,512]

theorem envBound29368 : H12AffineFastState.Bounded env29368 := by
  intro p hp
  have h : env29368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29367_29368 : H12AffineEnvironment.transform 3 14 env29367 = env29368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env29367 == env29368) = true)

theorem identity29368 : scanCanonicalize (H12AffineFastState.compose env29368 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29368 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29369 : List Nat := [2,4,8,14,0,15,8,5,512,10,1,15,8,0,1,3,15,1,11,0,0,0,14,2,8,15,1,14,14,0,10,0,4,1,1,512]

theorem envBound29369 : H12AffineFastState.Bounded env29369 := by
  intro p hp
  have h : env29369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29368_29369 : H12AffineEnvironment.transform 4 0 env29368 = env29369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29368 == env29369) = true)

theorem identity29369 : scanCanonicalize (H12AffineFastState.compose env29369 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29369 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29370 : List Nat := [2,4,8,14,0,15,8,5,0,10,1,15,8,0,1,3,15,1,11,0,0,0,14,2,8,15,1,14,14,0,10,0,4,1,1,0]

theorem envBound29370 : H12AffineFastState.Bounded env29370 := by
  intro p hp
  have h : env29370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29369_29370 : H12AffineEnvironment.transform 8 0 env29369 = env29370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29369 == env29370) = true)

theorem identity29370 : scanCanonicalize (H12AffineFastState.compose env29370 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound29370 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29371 : List Nat := [2,4,6,0,0,1,6,5,0,4,1,1,6,0,1,3,1,1,5,0,0,0,0,2,6,1,1,0,0,0,4,0,4,1,1,0]

theorem envBound29371 : H12AffineFastState.Bounded env29371 := by
  intro p hp
  have h : env29371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29370_29371 : H12AffineEnvironment.transform 2 6 env29370 = env29371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env29370 == env29371) = true)

def env29372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,169234,8328,64,245138,115150,17665,262145,119042,329730,257,213487,237643,63189]

theorem envBound29372 : H12AffineFastState.Bounded env29372 := by
  intro p hp
  have h : env29372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29342_29372 : H12AffineEnvironment.transform 21 272513 env29342 = env29372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29342 == env29372) = true)

theorem identity29372 : scanCanonicalize (H12AffineFastState.compose env29372 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29372 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,140420,272513,144596,156102,8328,64,215366,79130,17665,262145,75222,329730,257,213487,218271,513]

theorem envBound29373 : H12AffineFastState.Bounded env29373 := by
  intro p hp
  have h : env29373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29372_29373 : H12AffineEnvironment.transform 14 29908 env29372 = env29373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29372 == env29373) = true)

def env29374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,140300,272393,144476,155982,8192,64,215366,79130,17665,262145,75102,329730,257,213351,218135,513]

theorem envBound29374 : H12AffineFastState.Bounded env29374 := by
  intro p hp
  have h : env29374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29373_29374 : H12AffineEnvironment.transform 6 8 env29373 = env29374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29373 == env29374) = true)

def env29375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,140300,33,144476,155982,8192,64,215366,79130,17665,10281,75102,73770,257,213351,218135,513]

theorem envBound29375 : H12AffineFastState.Bounded env29375 := by
  intro p hp
  have h : env29375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29374_29375 : H12AffineEnvironment.transform 17 10280 env29374 = env29375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env29374 == env29375) = true)

theorem identity29375 : scanCanonicalize (H12AffineFastState.compose env29375 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29375 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env29376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10280,1025,8540,140300,33,144476,144463,8192,64,203847,79130,4096,10281,75102,73770,257,201830,196886,513]

theorem envBound29376 : H12AffineFastState.Bounded env29376 := by
  intro p hp
  have h : env29376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29375_29376 : H12AffineEnvironment.transform 13 5377 env29375 = env29376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29375 == env29376) = true)

theorem identity29376 : scanCanonicalize (H12AffineFastState.compose env29376 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound29376 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env29377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,5393,10280,1025,8540,12573,33,8525,8542,8192,64,67926,79130,4096,10281,75102,73770,257,65911,70663,513]

theorem envBound29377 : H12AffineFastState.Bounded env29377 := by
  intro p hp
  have h : env29377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29376_29377 : H12AffineEnvironment.transform 16 5393 env29376 = env29377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env29376 == env29377) = true)

theorem identity29377 : scanCanonicalize (H12AffineFastState.compose env29377 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29377 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,5393,2420,1025,0,4161,33,17,2,348,64,67926,70726,4096,2421,66562,65910,257,65911,70663,513]

theorem envBound29378 : H12AffineFastState.Bounded env29378 := by
  intro p hp
  have h : env29378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29377_29378 : H12AffineEnvironment.transform 12 348 env29377 = env29378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29377 == env29378) = true)

theorem identity29378 : scanCanonicalize (H12AffineFastState.compose env29378 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29378 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5393,2420,1025,0,4161,33,17,2,348,64,2049,5393,4096,2421,1365,33,257,32,5456,513]

theorem envBound29379 : H12AffineFastState.Bounded env29379 := by
  intro p hp
  have h : env29379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29378_29379 : H12AffineEnvironment.transform 15 343 env29378 = env29379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29378 == env29379) = true)

theorem identity29379 : scanCanonicalize (H12AffineFastState.compose env29379 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound29379 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29380 : List Nat := [2,4,8,16,32,64,8,256,512,564,2048,4096,348,4917,1,343,4901,2420,565,0,4161,33,17,2,348,64,2049,4901,4096,2421,865,33,257,32,4964,513]

theorem envBound29380 : H12AffineFastState.Bounded env29380 := by
  intro p hp
  have h : env29380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29379_29380 : H12AffineEnvironment.transform 9 564 env29379 = env29380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env29379 == env29380) = true)

theorem identity29380 : scanCanonicalize (H12AffineFastState.compose env29380 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29380 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29381 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,4096,268,4917,1,263,4901,2340,565,0,4113,33,17,2,268,16,2049,4901,4096,2341,817,33,257,32,4916,513]

theorem envBound29381 : H12AffineFastState.Bounded env29381 := by
  intro p hp
  have h : env29381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29380_29381 : H12AffineEnvironment.transform 5 16 env29380 = env29381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29380 == env29381) = true)

theorem identity29381 : scanCanonicalize (H12AffineFastState.compose env29381 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound29381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29382 : List Nat := [2,4,8,16,32,16,8,256,512,564,2048,513,268,308,1,263,292,2340,565,0,528,33,17,2,268,16,2049,292,513,2341,817,33,257,32,309,513]

theorem envBound29382 : H12AffineFastState.Bounded env29382 := by
  intro p hp
  have h : env29382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29381_29382 : H12AffineEnvironment.transform 11 513 env29381 = env29382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env29381 == env29382) = true)

theorem identity29382 : scanCanonicalize (H12AffineFastState.compose env29382 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound29382 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29383 : List Nat := [2,4,8,16,32,16,8,256,512,564,821,513,268,308,1,263,292,529,565,0,528,33,17,2,268,16,820,292,513,528,817,33,257,32,309,513]

theorem envBound29383 : H12AffineFastState.Bounded env29383 := by
  intro p hp
  have h : env29383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29382_29383 : H12AffineEnvironment.transform 10 821 env29382 = env29383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env29382 == env29383) = true)

theorem identity29383 : scanCanonicalize (H12AffineFastState.compose env29383 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound29383 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29384 : List Nat := [2,4,8,16,32,16,8,256,293,273,16,292,268,308,1,263,292,308,272,0,309,33,17,2,268,16,17,292,292,309,20,33,257,32,309,292]

theorem envBound29384 : H12AffineFastState.Bounded env29384 := by
  intro p hp
  have h : env29384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29383_29384 : H12AffineEnvironment.transform 8 293 env29383 = env29384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env29383 == env29384) = true)

theorem identity29384 : scanCanonicalize (H12AffineFastState.compose env29384 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29384 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29385 : List Nat := [2,4,8,16,16,16,8,256,277,273,16,276,268,260,1,263,276,260,272,0,261,17,17,2,268,16,17,276,276,261,20,17,257,16,261,276]

theorem envBound29385 : H12AffineFastState.Bounded env29385 := by
  intro p hp
  have h : env29385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29384_29385 : H12AffineEnvironment.transform 4 16 env29384 = env29385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29384 == env29385) = true)

theorem identity29385 : scanCanonicalize (H12AffineFastState.compose env29385 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29385 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29386 : List Nat := [2,4,8,16,16,16,8,21,0,4,16,1,25,17,1,18,1,17,5,0,16,17,17,2,25,16,17,1,1,16,20,17,20,16,16,1]

theorem envBound29386 : H12AffineFastState.Bounded env29386 := by
  intro p hp
  have h : env29386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29385_29386 : H12AffineEnvironment.transform 7 21 env29385 = env29386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29385 == env29386) = true)

def env29387 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1025,29789,140300,32,144476,155982,8192,64,215366,79130,17665,10280,75102,73771,257,213351,218135,513]

theorem envBound29387 : H12AffineFastState.Bounded env29387 := by
  intro p hp
  have h : env29387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29374_29387 : H12AffineEnvironment.transform 17 10281 env29374 = env29387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env29374 == env29387) = true)

theorem identity29387 : scanCanonicalize (H12AffineFastState.compose env29387 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound29387 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29388 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1025,29789,4160,32,16,21762,8192,64,97546,79130,17665,10280,75102,73771,257,95531,90203,513]

theorem envBound29388 : H12AffineFastState.Bounded env29388 := by
  intro p hp
  have h : env29388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29387_29388 : H12AffineEnvironment.transform 16 13388 env29387 = env29388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env29387 == env29388) = true)

theorem identity29388 : scanCanonicalize (H12AffineFastState.compose env29388 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 15372) := by decide +kernel

theorem selectedBound29388 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29389 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15372,2128,65536,13388,10281,1025,2129,4160,32,16,10510,8192,64,65798,79130,14605,10280,75102,73771,257,67879,72791,513]

theorem envBound29389 : H12AffineFastState.Bounded env29389 := by
  intro p hp
  have h : env29389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29388_29389 : H12AffineEnvironment.transform 13 15372 env29388 = env29389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15372 env29388 == env29389) = true)

theorem identity29389 : scanCanonicalize (H12AffineFastState.compose env29389 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 10331) := by decide +kernel

theorem selectedBound29389 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29390 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,15372,2128,10331,13388,10281,1025,2129,4160,32,16,10510,8192,64,10589,7489,14605,10280,3333,2160,257,8572,13324,513]

theorem envBound29390 : H12AffineFastState.Bounded env29390 := by
  intro p hp
  have h : env29390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29389_29390 : H12AffineEnvironment.transform 15 10331 env29389 = env29390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10331 env29389 == env29390) = true)

theorem identity29390 : scanCanonicalize (H12AffineFastState.compose env29390 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 4429) := by decide +kernel

theorem selectedBound29390 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env29391 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4429,3393,2128,6422,1281,6500,1025,2129,4160,32,16,6211,4429,64,6160,7489,2112,6501,3333,2160,257,4145,1345,513]

theorem envBound29391 : H12AffineFastState.Bounded env29391 := by
  intro p hp
  have h : env29391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29390_29391 : H12AffineEnvironment.transform 12 4429 env29390 = env29391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4429 env29390 == env29391) = true)

theorem identity29391 : scanCanonicalize (H12AffineFastState.compose env29391 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound29391 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,4429,0,1297,5207,1281,5157,1025,1296,4160,32,16,5378,4429,64,5457,4096,1281,5156,68,1329,257,4145,1345,513]

theorem envBound29392 : H12AffineFastState.Bounded env29392 := by
  intro p hp
  have h : env29392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29391_29392 : H12AffineEnvironment.transform 10 1345 env29391 = env29392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29391 == env29392) = true)

theorem identity29392 : scanCanonicalize (H12AffineFastState.compose env29392 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound29392 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,356,41,0,1297,1331,1281,1345,1025,1296,292,32,16,1126,41,64,1077,356,1281,1344,68,1329,257,341,1345,513]

theorem envBound29393 : H12AffineFastState.Bounded env29393 := by
  intro p hp
  have h : env29393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29392_29393 : H12AffineEnvironment.transform 11 356 env29392 = env29393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env29392 == env29393) = true)

theorem identity29393 : scanCanonicalize (H12AffineFastState.compose env29393 (packedSelected [0,2,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29393 : packedSelected [0,2,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env29394 : List Nat := [2,4,8,16,32,64,8,256,512,100,293,356,41,0,373,343,357,293,101,372,292,32,16,2,41,64,81,356,357,292,68,341,257,341,293,513]

theorem envBound29394 : H12AffineFastState.Bounded env29394 := by
  intro p hp
  have h : env29394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29393_29394 : H12AffineEnvironment.transform 9 100 env29393 = env29394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29393 == env29394) = true)

theorem identity29394 : scanCanonicalize (H12AffineFastState.compose env29394 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound29394 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env29395 : List Nat := [2,4,8,16,32,33,8,256,512,5,293,261,41,0,276,310,260,293,4,277,292,32,16,2,41,33,48,261,260,292,37,308,257,308,293,513]

theorem envBound29395 : H12AffineFastState.Bounded env29395 := by
  intro p hp
  have h : env29395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29394_29395 : H12AffineEnvironment.transform 5 33 env29394 = env29395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env29394 == env29395) = true)

theorem identity29395 : scanCanonicalize (H12AffineFastState.compose env29395 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29395 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env29396 : List Nat := [2,4,8,16,32,33,8,21,512,5,48,16,41,0,1,35,17,48,4,0,49,32,16,2,41,33,48,16,17,49,37,33,20,33,48,513]

theorem envBound29396 : H12AffineFastState.Bounded env29396 := by
  intro p hp
  have h : env29396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29395_29396 : H12AffineEnvironment.transform 7 21 env29395 = env29396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29395 == env29396) = true)

theorem identity29396 : scanCanonicalize (H12AffineFastState.compose env29396 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29397 : List Nat := [2,4,8,1,32,33,8,4,512,5,33,1,41,0,1,35,0,33,4,0,32,32,1,2,41,33,33,1,0,32,37,33,5,33,33,513]

theorem envBound29397 : H12AffineFastState.Bounded env29397 := by
  intro p hp
  have h : env29397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29396_29397 : H12AffineEnvironment.transform 3 1 env29396 = env29397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29396 == env29397) = true)

theorem identity29397 : scanCanonicalize (H12AffineFastState.compose env29397 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound29397 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29398 : List Nat := [2,4,8,1,32,33,8,4,33,5,33,1,41,0,1,35,0,33,4,0,32,32,1,2,41,33,33,1,0,32,37,33,5,33,33,32]

theorem envBound29398 : H12AffineFastState.Bounded env29398 := by
  intro p hp
  have h : env29398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29397_29398 : H12AffineEnvironment.transform 8 33 env29397 = env29398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env29397 == env29398) = true)

theorem identity29398 : scanCanonicalize (H12AffineFastState.compose env29398 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29399 : List Nat := [2,4,8,1,1,0,8,4,0,5,0,1,8,0,1,2,0,0,4,0,1,1,1,2,8,0,0,1,0,1,4,0,5,0,0,1]

theorem envBound29399 : H12AffineFastState.Bounded env29399 := by
  intro p hp
  have h : env29399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29398_29399 : H12AffineEnvironment.transform 4 1 env29398 = env29399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29398 == env29399) = true)

def env29400 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,140301,272392,144477,155983,8193,64,215366,79130,17665,262145,75103,329730,257,213350,218134,513]

theorem envBound29400 : H12AffineFastState.Bounded env29400 := by
  intro p hp
  have h : env29400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29373_29400 : H12AffineEnvironment.transform 6 9 env29373 = env29400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29373 == env29400) = true)

theorem identity29400 : scanCanonicalize (H12AffineFastState.compose env29400 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound29400 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29401 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,82966,272392,87110,65876,8193,64,10589,79130,17665,262145,75103,329730,257,8573,13325,513]

theorem envBound29401 : H12AffineFastState.Bounded env29401 := by
  intro p hp
  have h : env29401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29400_29401 : H12AffineEnvironment.transform 16 90139 env29400 = env29401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env29400 == env29401) = true)

theorem identity29401 : scanCanonicalize (H12AffineFastState.compose env29401 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound29401 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env29402 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21511,13340,262144,1025,29788,4113,272392,65,21843,8193,64,10589,24861,17665,262145,29016,285701,257,8573,13325,513]

theorem envBound29402 : H12AffineFastState.Bounded env29402 := by
  intro p hp
  have h : env29402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29401_29402 : H12AffineEnvironment.transform 15 21511 env29401 = env29402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env29401 == env29402) = true)

theorem identity29402 : scanCanonicalize (H12AffineFastState.compose env29402 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 22593) := by decide +kernel

theorem selectedBound29402 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env29403 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21511,13340,22593,1025,29788,4113,28745,65,21843,8193,64,10589,24861,17665,22592,29016,1092,257,8573,13325,513]

theorem envBound29403 : H12AffineFastState.Bounded env29403 := by
  intro p hp
  have h : env29403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29402_29403 : H12AffineEnvironment.transform 17 22593 env29402 = env29403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22593 env29402 == env29403) = true)

theorem identity29403 : scanCanonicalize (H12AffineFastState.compose env29403 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound29403 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env29404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12392,1077,9327,13340,10281,1025,1076,4113,33,65,9531,8193,64,10589,4469,13673,10280,304,1092,257,8573,13325,513]

theorem envBound29404 : H12AffineFastState.Bounded env29404 := by
  intro p hp
  have h : env29404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29403_29404 : H12AffineEnvironment.transform 13 12392 env29403 = env29404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env29403 == env29404) = true)

theorem identity29404 : scanCanonicalize (H12AffineFastState.compose env29404 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound29404 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env29405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,8192,11625,1077,9327,10525,10281,1025,1076,3344,33,65,9531,8193,64,10589,3188,10344,10280,304,1092,257,8573,10508,513]

theorem envBound29405 : H12AffineFastState.Bounded env29405 := by
  intro p hp
  have h : env29405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29404_29405 : H12AffineEnvironment.transform 11 3329 env29404 = env29405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env29404 == env29405) = true)

theorem identity29405 : scanCanonicalize (H12AffineFastState.compose env29405 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound29405 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env29406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,269,3172,1077,1378,2064,2340,1025,1076,3344,33,65,1078,268,64,2128,3188,2405,2341,304,1092,257,112,2049,513]

theorem envBound29406 : H12AffineFastState.Bounded env29406 := by
  intro p hp
  have h : env29406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29405_29406 : H12AffineEnvironment.transform 12 269 env29405 = env29406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env29405 == env29406) = true)

theorem identity29406 : scanCanonicalize (H12AffineFastState.compose env29406 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound29406 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29407 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,3188,120,3172,1077,1047,2064,2129,1025,1076,3173,33,65,1078,121,64,2128,3188,2064,2128,69,1092,116,112,2049,513]

theorem envBound29407 : H12AffineFastState.Bounded env29407 := by
  intro p hp
  have h : env29407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29406_29407 : H12AffineEnvironment.transform 7 117 env29406 = env29407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env29406 == env29407) = true)

end H12CloudChart1