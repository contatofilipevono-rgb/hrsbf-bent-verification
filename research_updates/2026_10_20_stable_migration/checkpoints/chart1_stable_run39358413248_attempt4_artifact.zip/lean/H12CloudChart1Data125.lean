import H12CloudChart1Data124

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound31715 : H12AffineFastState.Bounded env31715 := by
  intro p hp
  have h : env31715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31714_31715 : H12AffineEnvironment.transform 15 8202 env31714 = env31715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31714 == env31715) = true)

theorem identity31715 : scanCanonicalize (H12AffineFastState.compose env31715 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound31715 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24861,35109,1024,32769,4160,21872,17,41310,8192,65,64524,5393,17665,10281,1364,41260,256,21792,46092,513]

theorem envBound31716 : H12AffineFastState.Bounded env31716 := by
  intro p hp
  have h : env31716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31715_31716 : H12AffineEnvironment.transform 16 24861 env31715 = env31716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env31715 == env31716) = true)

theorem identity31716 : scanCanonicalize (H12AffineFastState.compose env31716 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31716 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env31717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,16400,35109,1024,32769,4160,21872,17,32851,269,65,56577,5393,17665,2340,1364,32801,256,21792,38145,513]

theorem envBound31717 : H12AffineFastState.Bounded env31717 := by
  intro p hp
  have h : env31717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31716_31717 : H12AffineEnvironment.transform 12 269 env31716 = env31717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31716 == env31717) = true)

theorem identity31717 : scanCanonicalize (H12AffineFastState.compose env31717 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound31717 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,263,16400,2421,1024,81,4160,21872,17,3,269,65,23889,5393,17665,2340,1364,113,256,21792,5457,513]

theorem envBound31718 : H12AffineFastState.Bounded env31718 := by
  intro p hp
  have h : env31718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31717_31718 : H12AffineEnvironment.transform 14 80 env31717 = env31718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env31717 == env31718) = true)

def env31719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,201831,17,98645,8193,65,171280,5393,17665,67619,1365,254011,256,21792,46093,74251]

theorem envBound31719 : H12AffineFastState.Bounded env31719 := by
  intro p hp
  have h : env31719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31713_31719 : H12AffineEnvironment.transform 6 9 env31713 = env31719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31713 == env31719) = true)

theorem identity31719 : scanCanonicalize (H12AffineFastState.compose env31719 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31719 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,149860,1024,32769,4160,169265,17,3,8193,65,171280,5393,17665,35189,1365,156013,256,21792,46093,41821]

theorem envBound31720 : H12AffineFastState.Bounded env31720 := by
  intro p hp
  have h : env31720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31719_31720 : H12AffineEnvironment.transform 15 33110 env31719 = env31720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31719 == env31720) = true)

theorem identity31720 : scanCanonicalize (H12AffineFastState.compose env31720 (packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound31720 : packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,33110,131072,146508,1024,32769,4160,169265,17,3,8193,65,171280,5393,12329,35189,1365,136261,256,8200,46093,41821]

theorem envBound31721 : H12AffineFastState.Bounded env31721 := by
  intro p hp
  have h : env31721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31720_31721 : H12AffineEnvironment.transform 13 13608 env31720 = env31721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env31720 == env31721) = true)

theorem identity31721 : scanCanonicalize (H12AffineFastState.compose env31721 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound31721 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,32768,33110,13624,2420,1024,32769,4160,40969,17,3,8193,65,43048,5393,12329,35189,1365,8573,256,8200,46093,41821]

theorem envBound31722 : H12AffineFastState.Bounded env31722 := by
  intro p hp
  have h : env31722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31721_31722 : H12AffineEnvironment.transform 16 13624 env31721 = env31722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env31721 == env31722) = true)

theorem identity31722 : scanCanonicalize (H12AffineFastState.compose env31722 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound31722 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env31723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,293,115,13624,2420,1024,292,4160,8492,17,3,8193,65,10509,5393,12329,2128,1365,8573,256,8200,13608,8824]

theorem envBound31723 : H12AffineFastState.Bounded env31723 := by
  intro p hp
  have h : env31723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31722_31723 : H12AffineEnvironment.transform 14 293 env31722 = env31723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env31722 == env31723) = true)

theorem identity31723 : scanCanonicalize (H12AffineFastState.compose env31723 (packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31723 : packedSelected [0,1,2,6,7,8,11,12,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env31724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,293,115,5221,2420,1024,292,4160,113,17,3,348,65,2128,5393,4468,2128,1365,32,256,341,5237,805]

theorem envBound31724 : H12AffineFastState.Bounded env31724 := by
  intro p hp
  have h : env31724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31723_31724 : H12AffineEnvironment.transform 12 349 env31723 = env31724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31723 == env31724) = true)

theorem identity31724 : scanCanonicalize (H12AffineFastState.compose env31724 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31724 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31725 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5237,0,115,5221,2129,1024,1,4160,113,17,3,121,65,2128,5172,4177,2128,1136,32,37,112,5237,512]

theorem envBound31725 : H12AffineFastState.Bounded env31725 := by
  intro p hp
  have h : env31725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31724_31725 : H12AffineEnvironment.transform 7 37 env31724 = env31725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31724 == env31725) = true)

theorem identity31725 : scanCanonicalize (H12AffineFastState.compose env31725 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31725 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31726 : List Nat := [2,4,8,16,1,64,9,4,512,1024,2048,4096,89,5204,0,82,5188,2129,1024,1,4160,80,17,3,88,65,2128,5141,4177,2128,1105,1,4,81,5204,512]

theorem envBound31726 : H12AffineFastState.Bounded env31726 := by
  intro p hp
  have h : env31726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31725_31726 : H12AffineEnvironment.transform 4 1 env31725 = env31726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31725 == env31726) = true)

def env31727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,8388608,98781,8328,65,12683758,5393,8406289,8456242,8390092,4256860,256,8410417,8434837,8462875]

theorem envBound31727 : H12AffineFastState.Bounded env31727 := by
  intro p hp
  have h : env31727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31693_31727 : H12AffineEnvironment.transform 20 4161 env31693 = env31727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31693 == env31727) = true)

def env31728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98781,8328,65,4295166,5393,17665,67618,1500,4256860,256,21793,46213,74251]

theorem envBound31728 : H12AffineFastState.Bounded env31728 := by
  intro p hp
  have h : env31728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31727_31728 : H12AffineEnvironment.transform 22 16 env31727 = env31728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31727 == env31728) = true)

theorem identity31728 : scanCanonicalize (H12AffineFastState.compose env31728 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31728 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,4194304,16,41431,8328,65,4237812,5393,17665,10280,1500,4256860,256,21793,46213,513]

theorem envBound31729 : H12AffineFastState.Bounded env31729 := by
  intro p hp
  have h : env31729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31728_31729 : H12AffineEnvironment.transform 15 8202 env31728 = env31729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31728 == env31729) = true)

theorem identity31729 : scanCanonicalize (H12AffineFastState.compose env31729 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound31729 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,32936,16,41431,8328,65,10588,5393,17665,10280,1500,29940,256,21793,46213,513]

theorem envBound31730 : H12AffineFastState.Bounded env31730 := by
  intro p hp
  have h : env31730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31729_31730 : H12AffineEnvironment.transform 21 32936 env31729 = env31730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env31729 == env31730) = true)

theorem identity31730 : scanCanonicalize (H12AffineFastState.compose env31730 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound31730 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env31731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4161,32936,16,41431,8328,65,10588,5393,17665,10280,1500,29940,256,21793,46213,513]

theorem envBound31731 : H12AffineFastState.Bounded env31731 := by
  intro p hp
  have h : env31731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31730_31731 : H12AffineEnvironment.transform 16 16400 env31730 = env31731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31730 == env31731) = true)

theorem identity31731 : scanCanonicalize (H12AffineFastState.compose env31731 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31731 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env31732 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4112,32936,16,41350,8328,16,10509,5393,17665,10280,1421,29861,256,21793,46213,513]

theorem envBound31732 : H12AffineFastState.Bounded env31732 := by
  intro p hp
  have h : env31732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31731_31732 : H12AffineEnvironment.transform 5 17 env31731 = env31732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31731 == env31732) = true)

theorem identity31732 : scanCanonicalize (H12AffineFastState.compose env31732 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31732 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env31733 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4112,32800,16,41230,8192,16,10509,5393,17665,10280,1285,29741,256,21793,46093,513]

theorem envBound31733 : H12AffineFastState.Bounded env31733 := by
  intro p hp
  have h : env31733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31732_31733 : H12AffineEnvironment.transform 6 8 env31732 = env31733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31732 == env31733) = true)

theorem identity31733 : scanCanonicalize (H12AffineFastState.compose env31733 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31733 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31734 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,8202,16400,10281,1024,0,4112,33,16,8463,8192,16,10509,5393,17665,10280,1285,29741,256,21793,13324,513]

theorem envBound31734 : H12AffineFastState.Bounded env31734 := by
  intro p hp
  have h : env31734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31733_31734 : H12AffineEnvironment.transform 14 1 env31733 = env31734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31733 == env31734) = true)

theorem identity31734 : scanCanonicalize (H12AffineFastState.compose env31734 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound31734 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env31735 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,1,8202,5393,10281,1024,0,4112,33,16,8463,8192,16,10509,5393,4096,10280,1285,8492,256,32,13324,513]

theorem envBound31735 : H12AffineFastState.Bounded env31735 := by
  intro p hp
  have h : env31735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31734_31735 : H12AffineEnvironment.transform 13 5377 env31734 = env31735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31734 == env31735) = true)

theorem identity31735 : scanCanonicalize (H12AffineFastState.compose env31735 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 3645) := by decide +kernel

theorem selectedBound31735 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31736 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3645,5377,1,3639,5393,1556,1024,0,4112,33,16,3890,3645,16,1840,5393,4096,1557,1285,3857,256,32,6705,513]

theorem envBound31736 : H12AffineFastState.Bounded env31736 := by
  intro p hp
  have h : env31736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31735_31736 : H12AffineEnvironment.transform 12 3645 env31735 = env31736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3645 env31735 == env31736) = true)

theorem identity31736 : scanCanonicalize (H12AffineFastState.compose env31736 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1840) := by decide +kernel

theorem selectedBound31736 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31737 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1840,4096,269,5377,1,263,5393,1556,1024,0,4112,33,16,2,269,16,1840,5393,4096,1557,1285,33,256,32,5377,513]

theorem envBound31737 : H12AffineFastState.Bounded env31737 := by
  intro p hp
  have h : env31737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31736_31737 : H12AffineEnvironment.transform 10 1840 env31736 = env31737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1840 env31736 == env31737) = true)

theorem identity31737 : scanCanonicalize (H12AffineFastState.compose env31737 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound31737 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31738 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1840,1028,269,261,1,263,277,1556,1024,0,1044,33,16,2,269,16,1840,277,1028,1557,1285,33,256,32,261,513]

theorem envBound31738 : H12AffineFastState.Bounded env31738 := by
  intro p hp
  have h : env31738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31737_31738 : H12AffineEnvironment.transform 11 1028 env31737 = env31738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env31737 == env31738) = true)

theorem identity31738 : scanCanonicalize (H12AffineFastState.compose env31738 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound31738 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31739 : List Nat := [2,4,8,16,32,17,8,256,512,305,513,309,269,261,1,263,277,805,305,0,293,33,16,2,269,16,513,277,309,804,52,33,256,32,261,513]

theorem envBound31739 : H12AffineFastState.Bounded env31739 := by
  intro p hp
  have h : env31739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31738_31739 : H12AffineEnvironment.transform 9 305 env31738 = env31739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env31738 == env31739) = true)

theorem identity31739 : scanCanonicalize (H12AffineFastState.compose env31739 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31740 : List Nat := [2,4,8,16,1,17,8,256,512,272,513,276,269,261,1,263,277,772,272,0,260,0,16,2,269,16,513,277,276,773,21,0,256,1,261,513]

theorem envBound31740 : H12AffineFastState.Bounded env31740 := by
  intro p hp
  have h : env31740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31739_31740 : H12AffineEnvironment.transform 4 1 env31739 = env31740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31739 == env31740) = true)

theorem identity31740 : scanCanonicalize (H12AffineFastState.compose env31740 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound31740 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31741 : List Nat := [2,4,8,16,1,17,8,256,276,272,277,276,269,261,1,263,277,16,272,0,260,0,16,2,269,16,277,277,276,17,21,0,256,1,261,277]

theorem envBound31741 : H12AffineFastState.Bounded env31741 := by
  intro p hp
  have h : env31741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31740_31741 : H12AffineEnvironment.transform 8 276 env31740 = env31741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env31740 == env31741) = true)

theorem identity31741 : scanCanonicalize (H12AffineFastState.compose env31741 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31741 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env31742 : List Nat := [2,4,8,0,1,1,8,256,260,256,261,260,269,261,1,263,261,0,256,0,260,0,0,2,269,0,261,261,260,1,5,0,256,1,261,261]

theorem envBound31742 : H12AffineFastState.Bounded env31742 := by
  intro p hp
  have h : env31742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31741_31742 : H12AffineEnvironment.transform 3 0 env31741 = env31742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31741 == env31742) = true)

theorem identity31742 : scanCanonicalize (H12AffineFastState.compose env31742 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound31742 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31743 : List Nat := [2,4,8,0,1,1,8,15,11,15,10,11,2,10,1,8,10,0,15,0,11,0,0,2,2,0,10,10,11,1,5,0,15,1,10,10]

theorem envBound31743 : H12AffineFastState.Bounded env31743 := by
  intro p hp
  have h : env31743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31742_31743 : H12AffineEnvironment.transform 7 15 env31742 = env31743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env31742 == env31743) = true)

def env31744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,17,98781,8328,65,4295167,5393,17664,67619,1501,4256860,256,21792,46212,74250]

theorem envBound31744 : H12AffineFastState.Bounded env31744 := by
  intro p hp
  have h : env31744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31727_31744 : H12AffineEnvironment.transform 22 17 env31727 = env31744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31727 == env31744) = true)

theorem identity31744 : scanCanonicalize (H12AffineFastState.compose env31744 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254130) := by decide +kernel

theorem selectedBound31744 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,254130,17,98781,8328,65,158029,5393,17664,67619,1501,201966,256,21792,46212,74250]

theorem envBound31745 : H12AffineFastState.Bounded env31745 := by
  intro p hp
  have h : env31745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31744_31745 : H12AffineEnvironment.transform 21 254130 env31744 = env31745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254130 env31744 == env31745) = true)

theorem identity31745 : scanCanonicalize (H12AffineFastState.compose env31745 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31745 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env31746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4161,180409,17,41430,8328,65,158029,5393,17664,10280,1501,144613,256,21792,46212,513]

theorem envBound31746 : H12AffineFastState.Bounded env31746 := by
  intro p hp
  have h : env31746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31745_31746 : H12AffineEnvironment.transform 15 8203 env31745 = env31746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31745 == env31746) = true)

theorem identity31746 : scanCanonicalize (H12AffineFastState.compose env31746 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31746 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43048,1024,32769,4161,32936,17,41430,8328,65,10588,5393,17664,10280,1501,29940,256,21792,46212,513]

theorem envBound31747 : H12AffineFastState.Bounded env31747 := by
  intro p hp
  have h : env31747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31746_31747 : H12AffineEnvironment.transform 16 16401 env31746 = env31747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31746 == env31747) = true)

theorem identity31747 : scanCanonicalize (H12AffineFastState.compose env31747 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound31747 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env31748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29708,8203,16401,23588,1024,29709,4161,29860,17,21978,8328,65,10588,5393,17664,10280,1501,29940,256,21792,16520,513]

theorem envBound31748 : H12AffineFastState.Bounded env31748 := by
  intro p hp
  have h : env31748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31747_31748 : H12AffineEnvironment.transform 14 29708 env31747 = env31748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env31747 == env31748) = true)

theorem identity31748 : scanCanonicalize (H12AffineFastState.compose env31748 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31748 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env31749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,1,8203,13340,10281,1024,0,4161,169,17,8663,8328,65,10588,5393,12557,10280,1501,249,256,8493,13445,513]

theorem envBound31749 : H12AffineFastState.Bounded env31749 := by
  intro p hp
  have h : env31749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31748_31749 : H12AffineEnvironment.transform 13 13325 env31748 = env31749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env31748 == env31749) = true)

theorem identity31749 : scanCanonicalize (H12AffineFastState.compose env31749 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound31749 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env31750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3188,8192,10361,1,8203,10344,10281,1024,0,3125,169,17,8663,8328,65,10588,2405,11641,10280,1501,249,256,8493,10481,513]

theorem envBound31750 : H12AffineFastState.Bounded env31750 := by
  intro p hp
  have h : env31750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31749_31750 : H12AffineEnvironment.transform 11 3188 env31749 = env31750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env31749 == env31750) = true)

theorem identity31750 : scanCanonicalize (H12AffineFastState.compose env31750 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31750 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env31751 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3188,8192,10361,1,8203,10344,10281,1024,0,3125,113,17,8463,8272,65,10588,2405,11641,10280,1285,33,256,8493,10281,513]

theorem envBound31751 : H12AffineFastState.Bounded env31751 := by
  intro p hp
  have h : env31751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31750_31751 : H12AffineEnvironment.transform 6 88 env31750 = env31751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31750 == env31751) = true)

theorem identity31751 : scanCanonicalize (H12AffineFastState.compose env31751 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound31751 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31752 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3188,1384,3345,1,1379,3328,3393,1024,0,3125,113,17,1127,1336,65,3124,2405,2065,3392,1285,33,256,1093,3393,513]

theorem envBound31752 : H12AffineFastState.Bounded env31752 := by
  intro p hp
  have h : env31752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31751_31752 : H12AffineEnvironment.transform 12 1384 env31751 = env31752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env31751 == env31752) = true)

theorem identity31752 : scanCanonicalize (H12AffineFastState.compose env31752 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31753 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,1337,3345,1,1330,3328,3344,1024,0,3125,32,17,1078,1336,16,3124,2356,2065,3345,1285,33,256,1044,3344,513]

theorem envBound31753 : H12AffineFastState.Bounded env31753 := by
  intro p hp
  have h : env31753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31752_31753 : H12AffineEnvironment.transform 5 17 env31752 = env31753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31752 == env31753) = true)

theorem identity31753 : scanCanonicalize (H12AffineFastState.compose env31753 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31753 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31754 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2065,269,2341,1,262,2356,2340,52,0,2049,32,17,2,268,16,2048,2356,2065,2341,305,33,256,32,2340,513]

theorem envBound31754 : H12AffineFastState.Bounded env31754 := by
  intro p hp
  have h : env31754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31753_31754 : H12AffineEnvironment.transform 9 52 env31753 = env31754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31753 == env31754) = true)

theorem identity31754 : scanCanonicalize (H12AffineFastState.compose env31754 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31754 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31755 : List Nat := [2,4,8,16,32,17,9,256,512,52,1,16,269,292,1,262,309,293,52,0,0,32,17,2,268,16,1,309,16,292,305,33,256,32,293,513]

theorem envBound31755 : H12AffineFastState.Bounded env31755 := by
  intro p hp
  have h : env31755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31754_31755 : H12AffineEnvironment.transform 10 1 env31754 = env31755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31754 == env31755) = true)

def env31756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784942,5392,10507600,8456242,10491276,4256861,256,8410416,8434836,10564187]

theorem envBound31756 : H12AffineFastState.Bounded env31756 := by
  intro p hp
  have h : env31756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31692_31756 : H12AffineEnvironment.transform 23 2199965 env31692 = env31756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env31692 == env31756) = true)

def env31757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,8388608,98781,8328,65,12683758,5392,8406288,8456242,8390092,4256861,256,8410416,8434836,8462875]

theorem envBound31757 : H12AffineFastState.Bounded env31757 := by
  intro p hp
  have h : env31757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31756_31757 : H12AffineEnvironment.transform 20 4160 env31756 = env31757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env31756 == env31757) = true)

def env31758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98781,8328,65,4295166,5392,17664,67618,1500,4256861,256,21792,46212,74251]

theorem envBound31758 : H12AffineFastState.Bounded env31758 := by
  intro p hp
  have h : env31758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31757_31758 : H12AffineEnvironment.transform 22 16 env31757 = env31758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31757 == env31758) = true)

def env31759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98645,8192,65,4295030,5392,17664,67618,1364,4256861,256,21792,46092,74251]

theorem envBound31759 : H12AffineFastState.Bounded env31759 := by
  intro p hp
  have h : env31759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31758_31759 : H12AffineEnvironment.transform 6 8 env31758 = env31759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31758 == env31759) = true)

theorem identity31759 : scanCanonicalize (H12AffineFastState.compose env31759 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound31759 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67619,1024,32769,4160,4194304,16,98645,8192,65,4295030,5392,17664,67618,1364,4256861,256,21792,46092,74251]

theorem envBound31760 : H12AffineFastState.Bounded env31760 := by
  intro p hp
  have h : env31760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31759_31760 : H12AffineEnvironment.transform 16 49169 env31759 = env31760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env31759 == env31760) = true)

theorem identity31760 : scanCanonicalize (H12AffineFastState.compose env31760 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31760 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,67619,1024,0,4160,4194304,16,65876,8192,65,4262263,5392,17664,67618,1364,4224092,256,21792,13325,74251]

theorem envBound31761 : H12AffineFastState.Bounded env31761 := by
  intro p hp
  have h : env31761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31760_31761 : H12AffineEnvironment.transform 14 1 env31760 = env31761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31760 == env31761) = true)

theorem identity31761 : scanCanonicalize (H12AffineFastState.compose env31761 (packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound31761 : packedSelected [0,1,2,3,6,7,8,10,20,24] rootPS < 2^1333 := by decide +kernel

def env31762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,67619,1024,0,4160,65830,16,65876,8192,65,2129,5392,17664,67618,1364,95610,256,21792,13325,74251]

theorem envBound31762 : H12AffineFastState.Bounded env31762 := by
  intro p hp
  have h : env31762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31761_31762 : H12AffineEnvironment.transform 21 65830 env31761 = env31762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env31761 == env31762) = true)

theorem identity31762 : scanCanonicalize (H12AffineFastState.compose env31762 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound31762 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env31763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,13388,67619,1024,0,4160,65830,16,65876,8192,65,2129,5392,12636,67618,1364,65830,256,8572,13325,74251]

theorem envBound31763 : H12AffineFastState.Bounded env31763 := by
  intro p hp
  have h : env31763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31762_31763 : H12AffineEnvironment.transform 13 13404 env31762 = env31763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env31762 == env31763) = true)

theorem identity31763 : scanCanonicalize (H12AffineFastState.compose env31763 (packedSelected [0,7,10,11,12,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound31763 : packedSelected [0,7,10,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env31764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8283,13388,10360,1024,0,4160,8573,16,8463,8192,65,2129,5392,12636,10361,1364,8573,256,8572,13325,592]

theorem envBound31764 : H12AffineFastState.Bounded env31764 := by
  intro p hp
  have h : env31764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31763_31764 : H12AffineEnvironment.transform 15 8283 env31763 = env31764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env31763 == env31764) = true)

theorem identity31764 : scanCanonicalize (H12AffineFastState.compose env31764 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound31764 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env31765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6476,3344,1,6423,3328,4404,1024,0,4160,6193,16,6211,6476,65,2129,5392,2064,4405,1364,6193,256,6192,3393,592]

theorem envBound31765 : H12AffineFastState.Bounded env31765 := by
  intro p hp
  have h : env31765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31764_31765 : H12AffineEnvironment.transform 12 6476 env31764 = env31765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env31764 == env31765) = true)

theorem identity31765 : scanCanonicalize (H12AffineFastState.compose env31765 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound31765 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,348,3344,1,263,3328,2340,1024,0,2128,33,16,83,348,65,2129,3328,2064,2341,1364,33,256,32,3393,592]

theorem envBound31766 : H12AffineFastState.Bounded env31766 := by
  intro p hp
  have h : env31766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31765_31766 : H12AffineEnvironment.transform 11 2064 env31765 = env31766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env31765 == env31766) = true)

theorem identity31766 : scanCanonicalize (H12AffineFastState.compose env31766 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound31766 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env31767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,577,593,348,1873,1,263,1857,869,1024,0,529,33,16,83,348,65,528,1857,593,868,1364,33,256,32,1792,592]

theorem envBound31767 : H12AffineFastState.Bounded env31767 := by
  intro p hp
  have h : env31767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31766_31767 : H12AffineEnvironment.transform 10 577 env31766 = env31767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env31766 == env31767) = true)

theorem identity31767 : scanCanonicalize (H12AffineFastState.compose env31767 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound31767 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31768 : List Nat := [2,4,8,16,32,64,8,256,512,257,577,593,348,592,1,263,576,869,257,0,529,33,16,83,348,65,528,576,593,868,85,33,256,32,513,592]

theorem envBound31768 : H12AffineFastState.Bounded env31768 := by
  intro p hp
  have h : env31768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31767_31768 : H12AffineEnvironment.transform 9 257 env31767 = env31768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env31767 == env31768) = true)

theorem identity31768 : scanCanonicalize (H12AffineFastState.compose env31768 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound31768 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31769 : List Nat := [2,4,8,16,32,64,8,256,324,257,261,277,348,276,1,263,260,33,257,0,341,33,16,83,348,65,340,260,277,32,85,33,256,32,325,276]

theorem envBound31769 : H12AffineFastState.Bounded env31769 := by
  intro p hp
  have h : env31769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31768_31769 : H12AffineEnvironment.transform 8 324 env31768 = env31769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env31768 == env31769) = true)

theorem identity31769 : scanCanonicalize (H12AffineFastState.compose env31769 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31769 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env31770 : List Nat := [2,4,8,16,17,64,8,256,324,257,261,277,348,276,1,263,260,16,257,0,341,16,16,83,348,65,340,260,277,17,85,16,256,17,325,276]

theorem envBound31770 : H12AffineFastState.Bounded env31770 := by
  intro p hp
  have h : env31770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31769_31770 : H12AffineEnvironment.transform 4 17 env31769 = env31770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31769 == env31770) = true)

theorem identity31770 : scanCanonicalize (H12AffineFastState.compose env31770 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31770 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31771 : List Nat := [2,4,8,16,17,0,8,256,260,257,261,277,284,276,1,263,260,16,257,0,277,16,16,19,284,1,276,260,277,17,21,16,256,17,261,276]

theorem envBound31771 : H12AffineFastState.Bounded env31771 := by
  intro p hp
  have h : env31771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31770_31771 : H12AffineEnvironment.transform 5 0 env31770 = env31771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31770 == env31771) = true)

theorem identity31771 : scanCanonicalize (H12AffineFastState.compose env31771 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31772 : List Nat := [2,4,8,0,1,0,8,256,260,257,261,261,268,260,1,263,260,0,257,0,261,0,0,3,268,1,260,260,261,1,5,0,256,1,261,260]

theorem envBound31772 : H12AffineFastState.Bounded env31772 := by
  intro p hp
  have h : env31772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31771_31772 : H12AffineEnvironment.transform 3 0 env31771 = env31772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31771 == env31772) = true)

theorem identity31772 : scanCanonicalize (H12AffineFastState.compose env31772 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound31772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31773 : List Nat := [2,4,8,0,1,0,8,11,15,10,14,14,7,15,1,12,15,0,10,0,14,0,0,3,7,1,15,15,14,1,5,0,11,1,14,15]

theorem envBound31773 : H12AffineFastState.Bounded env31773 := by
  intro p hp
  have h : env31773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31772_31773 : H12AffineEnvironment.transform 7 11 env31772 = env31773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env31772 == env31773) = true)

theorem identity31773 : scanCanonicalize (H12AffineFastState.compose env31773 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound31773 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31774 : List Nat := [2,4,6,0,1,0,6,5,1,4,0,0,7,1,1,2,1,0,4,0,0,0,0,3,7,1,1,1,0,1,5,0,5,1,0,1]

theorem envBound31774 : H12AffineFastState.Bounded env31774 := by
  intro p hp
  have h : env31774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31773_31774 : H12AffineEnvironment.transform 2 6 env31773 = env31774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env31773 == env31774) = true)

def env31775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,16,98644,8193,65,4295031,5392,17664,67618,1365,4256861,256,21792,46093,74251]

theorem envBound31775 : H12AffineFastState.Bounded env31775 := by
  intro p hp
  have h : env31775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31758_31775 : H12AffineEnvironment.transform 6 9 env31758 = env31775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31758 == env31775) = true)

theorem identity31775 : scanCanonicalize (H12AffineFastState.compose env31775 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound31775 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,108926,1024,32769,4160,4194304,16,98644,8193,65,4295031,5392,17664,67618,1365,4256861,256,21792,46093,74251]

theorem envBound31776 : H12AffineFastState.Bounded env31776 := by
  intro p hp
  have h : env31776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31775_31776 : H12AffineEnvironment.transform 16 24908 env31775 = env31776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env31775 == env31776) = true)

theorem identity31776 : scanCanonicalize (H12AffineFastState.compose env31776 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound31776 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env31777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30042,24908,56356,1024,32769,4160,4194304,16,62478,8193,65,4258861,5392,17664,32120,1365,4256861,256,21792,46093,22353]

theorem envBound31777 : H12AffineFastState.Bounded env31777 := by
  intro p hp
  have h : env31777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31776_31777 : H12AffineEnvironment.transform 15 30042 env31776 = env31777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env31776 == env31777) = true)

theorem identity31777 : scanCanonicalize (H12AffineFastState.compose env31777 (packedSelected [1,3,7,8,10,12,14,15,19,20,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound31777 : packedSelected [1,3,7,8,10,12,14,15,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,32768,21795,16693,56356,1024,32769,4160,4194304,16,54391,120,65,4250708,5392,17664,23809,1365,4248612,256,21792,38004,22353]

theorem envBound31778 : H12AffineFastState.Bounded env31778 := by
  intro p hp
  have h : env31778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31777_31778 : H12AffineEnvironment.transform 12 121 env31777 = env31778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env31777 == env31778) = true)

theorem identity31778 : scanCanonicalize (H12AffineFastState.compose env31778 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound31778 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,32768,115,5221,35188,1024,32769,4160,4194304,16,33063,120,65,4229380,5392,4176,2129,1365,4227444,256,112,38004,513]

theorem envBound31779 : H12AffineFastState.Bounded env31779 := by
  intro p hp
  have h : env31779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31778_31779 : H12AffineEnvironment.transform 13 5456 env31778 = env31779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env31778 == env31779) = true)

theorem identity31779 : scanCanonicalize (H12AffineFastState.compose env31779 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(21+1) ^^^ 32801) := by decide +kernel

theorem selectedBound31779 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env31780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,32768,115,5221,35188,1024,32769,4160,32801,16,33063,120,65,2341,5392,4176,2129,1365,341,256,112,38004,513]

theorem envBound31780 : H12AffineFastState.Bounded env31780 := by
  intro p hp
  have h : env31780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31779_31780 : H12AffineEnvironment.transform 21 32801 env31779 = env31780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32801 env31779 == env31780) = true)

theorem identity31780 : scanCanonicalize (H12AffineFastState.compose env31780 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound31780 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5456,1,115,5221,2421,1024,0,4160,32,16,294,120,65,2341,5392,4176,2129,1365,341,256,112,5237,513]

theorem envBound31781 : H12AffineFastState.Bounded env31781 := by
  intro p hp
  have h : env31781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31780_31781 : H12AffineEnvironment.transform 14 1 env31780 = env31781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env31780 == env31781) = true)

theorem identity31781 : scanCanonicalize (H12AffineFastState.compose env31781 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound31781 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31782 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,4096,121,4112,1,115,4389,2421,320,0,4160,32,16,294,120,65,2341,4176,4176,2129,21,341,256,112,4405,513]

theorem envBound31782 : H12AffineFastState.Bounded env31782 := by
  intro p hp
  have h : env31782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31781_31782 : H12AffineEnvironment.transform 9 320 env31781 = env31782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31781 == env31782) = true)

theorem identity31782 : scanCanonicalize (H12AffineFastState.compose env31782 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound31782 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31783 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2065,121,2049,1,115,2356,2421,320,0,2129,32,16,294,120,65,2341,2113,2113,2129,21,341,256,112,2340,513]

theorem envBound31783 : H12AffineFastState.Bounded env31783 := by
  intro p hp
  have h : env31783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31782_31783 : H12AffineEnvironment.transform 11 2065 env31782 = env31783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env31782 == env31783) = true)

theorem identity31783 : scanCanonicalize (H12AffineFastState.compose env31783 (packedSelected [1,2,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound31783 : packedSelected [1,2,8,11] rootPS < 2^1333 := by decide +kernel

def env31784 : List Nat := [2,4,8,16,32,64,9,69,512,5,2048,2065,121,2049,1,115,2161,2096,5,0,2129,32,16,99,120,65,2144,2113,2113,2129,21,16,69,112,2145,513]

theorem envBound31784 : H12AffineFastState.Bounded env31784 := by
  intro p hp
  have h : env31784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31783_31784 : H12AffineEnvironment.transform 7 69 env31783 = env31784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env31783 == env31784) = true)

theorem identity31784 : scanCanonicalize (H12AffineFastState.compose env31784 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31784 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31785 : List Nat := [2,4,8,16,32,0,9,5,512,5,2048,2065,57,2049,1,51,2097,2096,5,0,2065,32,16,35,56,1,2080,2049,2049,2065,21,16,5,48,2081,513]

theorem envBound31785 : H12AffineFastState.Bounded env31785 := by
  intro p hp
  have h : env31785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31784_31785 : H12AffineEnvironment.transform 5 0 env31784 = env31785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31784 == env31785) = true)

theorem identity31785 : scanCanonicalize (H12AffineFastState.compose env31785 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31785 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env31786 : List Nat := [2,4,8,16,16,0,9,5,512,5,2048,2065,9,2049,1,3,2049,2048,5,0,2065,16,16,19,8,1,2064,2049,2049,2065,21,16,5,0,2065,513]

theorem envBound31786 : H12AffineFastState.Bounded env31786 := by
  intro p hp
  have h : env31786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31785_31786 : H12AffineEnvironment.transform 4 16 env31785 = env31786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31785 == env31786) = true)

theorem identity31786 : scanCanonicalize (H12AffineFastState.compose env31786 (packedSelected [2,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31786 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env31787 : List Nat := [2,4,8,0,0,0,9,5,512,5,2048,2049,9,2049,1,3,2049,2048,5,0,2049,0,0,3,8,1,2048,2049,2049,2049,5,0,5,0,2049,513]

theorem envBound31787 : H12AffineFastState.Bounded env31787 := by
  intro p hp
  have h : env31787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31786_31787 : H12AffineEnvironment.transform 3 0 env31786 = env31787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31786 == env31787) = true)

theorem identity31787 : scanCanonicalize (H12AffineFastState.compose env31787 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31788 : List Nat := [2,4,8,0,0,0,9,5,0,5,2048,2049,9,2049,1,3,2049,2048,5,0,2049,0,0,3,8,1,2048,2049,2049,2049,5,0,5,0,2049,1]

theorem envBound31788 : H12AffineFastState.Bounded env31788 := by
  intro p hp
  have h : env31788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31787_31788 : H12AffineEnvironment.transform 8 0 env31787 = env31788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31787 == env31788) = true)

def env31789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,4194304,17,98781,8328,65,4295167,5392,17665,67619,1501,4256861,256,21793,46213,74250]

theorem envBound31789 : H12AffineFastState.Bounded env31789 := by
  intro p hp
  have h : env31789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31757_31789 : H12AffineEnvironment.transform 22 17 env31757 = env31789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31757 == env31789) = true)

theorem identity31789 : scanCanonicalize (H12AffineFastState.compose env31789 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180409) := by decide +kernel

theorem selectedBound31789 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180409,17,98781,8328,65,215366,5392,17665,67619,1501,144612,256,21793,46213,74250]

theorem envBound31790 : H12AffineFastState.Bounded env31790 := by
  intro p hp
  have h : env31790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31789_31790 : H12AffineEnvironment.transform 21 180409 env31789 = env31790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env31789 == env31790) = true)

def env31791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180273,17,98645,8192,65,215366,5392,17665,67619,1365,144492,256,21793,46093,74250]

theorem envBound31791 : H12AffineFastState.Bounded env31791 := by
  intro p hp
  have h : env31791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31790_31791 : H12AffineEnvironment.transform 6 8 env31790 = env31791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31790 == env31791) = true)

theorem identity31791 : scanCanonicalize (H12AffineFastState.compose env31791 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31791 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4160,180273,17,41310,8192,65,158029,5392,17665,10280,1365,144492,256,21793,46093,513]

theorem envBound31792 : H12AffineFastState.Bounded env31792 := by
  intro p hp
  have h : env31792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31791_31792 : H12AffineEnvironment.transform 15 8203 env31791 = env31792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31791 == env31792) = true)

theorem identity31792 : scanCanonicalize (H12AffineFastState.compose env31792 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound31792 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43048,1024,32769,4160,32800,17,41310,8192,65,10588,5392,17665,10280,1365,29821,256,21793,46093,513]

theorem envBound31793 : H12AffineFastState.Bounded env31793 := by
  intro p hp
  have h : env31793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31792_31793 : H12AffineEnvironment.transform 16 16401 env31792 = env31793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31792 == env31793) = true)

theorem identity31793 : scanCanonicalize (H12AffineFastState.compose env31793 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31793 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,2420,1024,8541,4160,8572,17,2,8192,65,10588,5392,17665,10280,1365,29821,256,21793,5457,513]

theorem envBound31794 : H12AffineFastState.Bounded env31794 := by
  intro p hp
  have h : env31794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31793_31794 : H12AffineEnvironment.transform 14 8540 env31793 = env31794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31793 == env31794) = true)

theorem identity31794 : scanCanonicalize (H12AffineFastState.compose env31794 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31794 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env31795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8203,13340,2420,1024,8541,4160,8572,17,2,8192,65,10588,5392,12556,10280,1365,112,256,8492,5457,513]

theorem envBound31795 : H12AffineFastState.Bounded env31795 := by
  intro p hp
  have h : env31795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31794_31795 : H12AffineEnvironment.transform 13 13325 env31794 = env31795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env31794 == env31795) = true)

theorem identity31795 : scanCanonicalize (H12AffineFastState.compose env31795 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound31795 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4404,1125,1330,4389,2420,1024,1124,4160,1093,17,2,1337,65,3173,5392,5173,3345,1365,112,256,1045,5457,513]

theorem envBound31796 : H12AffineFastState.Bounded env31796 := by
  intro p hp
  have h : env31796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31795_31796 : H12AffineEnvironment.transform 12 1337 env31795 = env31796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env31795 == env31796) = true)

theorem identity31796 : scanCanonicalize (H12AffineFastState.compose env31796 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31796 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env31797 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,348,4404,0,343,4389,2420,101,1,4160,32,17,2,348,65,2048,4469,4176,2420,304,112,256,112,4404,513]

theorem envBound31797 : H12AffineFastState.Bounded env31797 := by
  intro p hp
  have h : env31797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31796_31797 : H12AffineEnvironment.transform 9 101 env31796 = env31797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31796 == env31797) = true)

theorem identity31797 : scanCanonicalize (H12AffineFastState.compose env31797 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31798 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4404,0,263,4389,2340,53,1,4112,32,17,2,268,17,2048,4389,4096,2340,304,32,256,32,4404,513]

theorem envBound31798 : H12AffineFastState.Bounded env31798 := by
  intro p hp
  have h : env31798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31797_31798 : H12AffineEnvironment.transform 5 16 env31797 = env31798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31797 == env31798) = true)

theorem identity31798 : scanCanonicalize (H12AffineFastState.compose env31798 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31798 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31799 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,40,4112,0,35,4097,2048,53,1,4112,32,17,2,40,17,2048,4097,4096,2048,20,32,36,32,4112,513]

theorem envBound31799 : H12AffineFastState.Bounded env31799 := by
  intro p hp
  have h : env31799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31798_31799 : H12AffineEnvironment.transform 7 36 env31798 = env31799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31798 == env31799) = true)

theorem identity31799 : scanCanonicalize (H12AffineFastState.compose env31799 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound31799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31800 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2081,40,2097,0,35,2080,2048,53,1,2097,32,17,2,40,17,2048,2080,2081,2048,20,32,36,32,2097,513]

theorem envBound31800 : H12AffineFastState.Bounded env31800 := by
  intro p hp
  have h : env31800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31799_31800 : H12AffineEnvironment.transform 11 2081 env31799 = env31800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env31799 == env31800) = true)

theorem identity31800 : scanCanonicalize (H12AffineFastState.compose env31800 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31800 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31801 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,33,40,49,0,35,32,0,53,1,49,32,17,2,40,17,0,32,33,0,20,32,36,32,49,513]

theorem envBound31801 : H12AffineFastState.Bounded env31801 := by
  intro p hp
  have h : env31801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31800_31801 : H12AffineEnvironment.transform 10 0 env31800 = env31801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31800 == env31801) = true)

def env31802 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180272,17,98644,8193,65,215366,5392,17665,67619,1364,144493,256,21793,46092,74250]

theorem envBound31802 : H12AffineFastState.Bounded env31802 := by
  intro p hp
  have h : env31802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31790_31802 : H12AffineEnvironment.transform 6 9 env31790 = env31802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31790 == env31802) = true)

theorem identity31802 : scanCanonicalize (H12AffineFastState.compose env31802 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound31802 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,131072,149861,1024,32769,4160,180272,17,3,8193,65,182289,5392,17665,35188,1364,144493,256,21793,46092,41821]

theorem envBound31803 : H12AffineFastState.Bounded env31803 := by
  intro p hp
  have h : env31803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31802_31803 : H12AffineEnvironment.transform 15 33111 env31802 = env31803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env31802 == env31803) = true)

def env31804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,8388608,98780,8328,65,12683759,5392,8406289,8456242,8390093,4256861,256,8410416,8434836,8462874]

theorem envBound31804 : H12AffineFastState.Bounded env31804 := by
  intro p hp
  have h : env31804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31756_31804 : H12AffineEnvironment.transform 20 4161 env31756 = env31804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env31756 == env31804) = true)

def env31805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,16,98780,8328,65,4295167,5392,17665,67618,1501,4256861,256,21792,46212,74250]

theorem envBound31805 : H12AffineFastState.Bounded env31805 := by
  intro p hp
  have h : env31805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31804_31805 : H12AffineEnvironment.transform 22 16 env31804 = env31805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31804 == env31805) = true)

theorem identity31805 : scanCanonicalize (H12AffineFastState.compose env31805 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound31805 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212199,1024,29908,4161,4194304,16,95497,8328,65,4291882,5392,17665,67618,1501,4194440,256,21792,16465,74250]

theorem envBound31806 : H12AffineFastState.Bounded env31806 := by
  intro p hp
  have h : env31806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31805_31806 : H12AffineEnvironment.transform 14 29909 env31805 = env31806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env31805 == env31806) = true)

def env31807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212199,1024,8660,4161,4194304,16,73737,8328,65,4270122,5392,4097,67618,1501,4194440,256,32,5457,74250]

theorem envBound31807 : H12AffineFastState.Bounded env31807 := by
  intro p hp
  have h : env31807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31806_31807 : H12AffineEnvironment.transform 13 5376 env31806 = env31807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31806 == env31807) = true)

theorem identity31807 : scanCanonicalize (H12AffineFastState.compose env31807 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound31807 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,67754,1024,8660,4161,4194304,16,73737,8328,65,4270122,5392,4097,67618,1501,4194440,256,32,5457,74250]

theorem envBound31808 : H12AffineFastState.Bounded env31808 := by
  intro p hp
  have h : env31808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31807_31808 : H12AffineEnvironment.transform 16 13389 env31807 = env31808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env31807 == env31808) = true)

theorem identity31808 : scanCanonicalize (H12AffineFastState.compose env31808 (packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS)) = affineNative (2^(21+1) ^^^ 73851) := by decide +kernel

theorem selectedBound31808 : packedSelected [0,4,7,8,9,12,16,18,19,28] rootPS < 2^1333 := by decide +kernel

def env31809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13389,67754,1024,8660,4161,73851,16,73737,8328,65,2129,5392,4097,67618,1501,73971,256,32,5457,74250]

theorem envBound31809 : H12AffineFastState.Bounded env31809 := by
  intro p hp
  have h : env31809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31808_31809 : H12AffineEnvironment.transform 21 73851 env31808 = env31809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73851 env31808 == env31809) = true)

theorem identity31809 : scanCanonicalize (H12AffineFastState.compose env31809 (packedSelected [2,3,4,5,6,10,16,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound31809 : packedSelected [2,3,4,5,6,10,16,18,22,23] rootPS < 2^1333 := by decide +kernel

def env31810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8282,13389,10480,1024,8660,4161,33,16,83,8328,65,2129,5392,4097,10360,1501,169,256,32,5457,592]

theorem envBound31810 : H12AffineFastState.Bounded env31810 := by
  intro p hp
  have h : env31810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31809_31810 : H12AffineEnvironment.transform 15 8282 env31809 = env31810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env31809 == env31810) = true)

theorem identity31810 : scanCanonicalize (H12AffineFastState.compose env31810 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31810 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env31811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,263,5392,2477,1024,137,4161,33,16,83,469,65,2129,5392,4097,2341,1501,169,256,32,5457,592]

theorem envBound31811 : H12AffineFastState.Bounded env31811 := by
  intro p hp
  have h : env31811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31810_31811 : H12AffineEnvironment.transform 12 349 env31810 = env31811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31810 == env31811) = true)

theorem identity31811 : scanCanonicalize (H12AffineFastState.compose env31811 (packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3324) := by decide +kernel

theorem selectedBound31811 : packedSelected [1,3,5,6,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3324,349,2556,136,263,2540,2477,1024,137,3261,33,16,83,469,65,2129,2540,3325,2341,1501,169,256,32,2477,592]

theorem envBound31812 : H12AffineFastState.Bounded env31812 := by
  intro p hp
  have h : env31812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31811_31812 : H12AffineEnvironment.transform 11 3324 env31811 = env31812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3324 env31811 == env31812) = true)

theorem identity31812 : scanCanonicalize (H12AffineFastState.compose env31812 (packedSelected [0,1,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound31812 : packedSelected [0,1,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1092,184,349,1464,136,263,1448,1513,1024,137,249,33,16,83,469,65,1045,1448,185,1377,1501,169,256,32,1513,592]

theorem envBound31813 : H12AffineFastState.Bounded env31813 := by
  intro p hp
  have h : env31813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31812_31813 : H12AffineEnvironment.transform 10 1092 env31812 = env31813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env31812 == env31813) = true)

theorem identity31813 : scanCanonicalize (H12AffineFastState.compose env31813 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31813 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env31814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1092,48,349,1328,0,263,1312,1377,1024,1,113,33,16,83,349,65,1045,1312,49,1377,1365,33,256,32,1377,592]

theorem envBound31814 : H12AffineFastState.Bounded env31814 := by
  intro p hp
  have h : env31814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31813_31814 : H12AffineEnvironment.transform 6 8 env31813 = env31814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31813 == env31814) = true)

theorem identity31814 : scanCanonicalize (H12AffineFastState.compose env31814 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31814 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env31815 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1045,48,268,1328,0,263,1312,1328,1024,1,32,33,16,2,268,16,1045,1312,49,1328,1284,33,256,32,1328,513]

theorem envBound31815 : H12AffineFastState.Bounded env31815 := by
  intro p hp
  have h : env31815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31814_31815 : H12AffineEnvironment.transform 5 17 env31814 = env31815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31814 == env31815) = true)

theorem identity31815 : scanCanonicalize (H12AffineFastState.compose env31815 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound31815 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31816 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1045,48,40,1044,0,35,1028,1044,1024,1,32,33,16,2,40,16,1045,1028,49,1044,1056,33,36,32,1044,513]

theorem envBound31816 : H12AffineFastState.Bounded env31816 := by
  intro p hp
  have h : env31816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31815_31816 : H12AffineEnvironment.transform 7 36 env31815 = env31816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env31815 == env31816) = true)

theorem identity31816 : scanCanonicalize (H12AffineFastState.compose env31816 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 513) := by decide +kernel

theorem selectedBound31816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31817 : List Nat := [2,4,8,16,32,17,8,36,512,513,532,48,40,533,0,35,517,533,513,1,32,33,16,2,40,16,532,517,49,533,545,33,36,32,533,513]

theorem envBound31817 : H12AffineFastState.Bounded env31817 := by
  intro p hp
  have h : env31817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31816_31817 : H12AffineEnvironment.transform 9 513 env31816 = env31817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 513 env31816 == env31817) = true)

theorem identity31817 : scanCanonicalize (H12AffineFastState.compose env31817 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound31817 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31818 : List Nat := [2,4,8,15,32,14,8,36,512,513,523,47,40,522,0,35,517,522,513,1,32,33,15,2,40,15,523,517,46,522,545,33,36,32,522,513]

theorem envBound31818 : H12AffineFastState.Bounded env31818 := by
  intro p hp
  have h : env31818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31817_31818 : H12AffineEnvironment.transform 3 15 env31817 = env31818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env31817 == env31818) = true)

theorem identity31818 : scanCanonicalize (H12AffineFastState.compose env31818 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound31818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31819 : List Nat := [2,4,8,15,32,14,8,36,12,13,7,47,40,6,0,35,9,6,13,1,32,33,15,2,40,15,7,9,46,6,45,33,36,32,6,13]

theorem envBound31819 : H12AffineFastState.Bounded env31819 := by
  intro p hp
  have h : env31819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31818_31819 : H12AffineEnvironment.transform 8 12 env31818 = env31819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env31818 == env31819) = true)

def env31820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212199,1024,8661,4161,4194304,16,73736,8328,65,4270123,5392,4096,67618,1501,4194440,256,33,5456,74250]

theorem envBound31820 : H12AffineFastState.Bounded env31820 := by
  intro p hp
  have h : env31820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31806_31820 : H12AffineEnvironment.transform 13 5377 env31806 = env31820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env31806 == env31820) = true)

theorem identity31820 : scanCanonicalize (H12AffineFastState.compose env31820 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound31820 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13509,67618,1024,8661,4161,4194304,16,73736,8328,65,4270123,5392,4096,67618,1501,4194440,256,33,5456,74250]

theorem envBound31821 : H12AffineFastState.Bounded env31821 := by
  intro p hp
  have h : env31821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31820_31821 : H12AffineEnvironment.transform 16 13509 env31820 = env31821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env31820 == env31821) = true)

theorem identity31821 : scanCanonicalize (H12AffineFastState.compose env31821 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31821 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13509,10281,1024,8661,4161,4194304,16,3,8328,65,4196384,5392,4096,10281,1501,4194440,256,33,5456,513]

theorem envBound31822 : H12AffineFastState.Bounded env31822 := by
  intro p hp
  have h : env31822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31821_31822 : H12AffineEnvironment.transform 15 8203 env31821 = env31822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31821 == env31822) = true)

theorem identity31822 : scanCanonicalize (H12AffineFastState.compose env31822 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound31822 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13509,10281,1024,8661,4161,248,16,3,8328,65,2264,5392,4096,10281,1501,112,256,33,5456,513]

theorem envBound31823 : H12AffineFastState.Bounded env31823 := by
  intro p hp
  have h : env31823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31822_31823 : H12AffineEnvironment.transform 21 248 env31822 = env31823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env31822 == env31823) = true)

theorem identity31823 : scanCanonicalize (H12AffineFastState.compose env31823 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound31823 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,1,478,5392,2556,1024,0,4161,248,16,3,349,65,2264,5392,4096,2556,1501,112,256,33,5456,513]

theorem envBound31824 : H12AffineFastState.Bounded env31824 := by
  intro p hp
  have h : env31824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31823_31824 : H12AffineEnvironment.transform 12 469 env31823 = env31824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env31823 == env31824) = true)

theorem identity31824 : scanCanonicalize (H12AffineFastState.compose env31824 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31824 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env31825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,1,398,5392,2476,1024,0,4113,168,16,3,269,17,2184,5392,4096,2476,1421,32,256,33,5376,513]

theorem envBound31825 : H12AffineFastState.Bounded env31825 := by
  intro p hp
  have h : env31825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31824_31825 : H12AffineEnvironment.transform 5 16 env31824 = env31825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31824 == env31825) = true)

theorem identity31825 : scanCanonicalize (H12AffineFastState.compose env31825 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound31825 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31826 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2097,389,3376,1,398,3361,2476,1024,0,2080,168,16,3,269,17,2184,3361,2097,2476,1421,32,256,33,3377,513]

theorem envBound31826 : H12AffineFastState.Bounded env31826 := by
  intro p hp
  have h : env31826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31825_31826 : H12AffineEnvironment.transform 11 2097 env31825 = env31826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env31825 == env31826) = true)

theorem identity31826 : scanCanonicalize (H12AffineFastState.compose env31826 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound31826 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env31827 : List Nat := [2,4,8,16,32,16,128,256,512,920,2048,2097,389,2728,1,398,2745,2476,920,0,2080,168,16,3,269,17,2184,2745,2097,2476,533,32,256,33,2729,513]

theorem envBound31827 : H12AffineFastState.Bounded env31827 := by
  intro p hp
  have h : env31827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31826_31827 : H12AffineEnvironment.transform 9 920 env31826 = env31827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env31826 == env31827) = true)

theorem identity31827 : scanCanonicalize (H12AffineFastState.compose env31827 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound31827 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31828 : List Nat := [2,4,8,16,32,16,41,256,512,817,2048,2097,300,2561,1,295,2576,2309,817,0,2080,1,16,3,269,17,2081,2576,2097,2309,533,32,256,33,2560,513]

theorem envBound31828 : H12AffineFastState.Bounded env31828 := by
  intro p hp
  have h : env31828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31827_31828 : H12AffineEnvironment.transform 6 41 env31827 = env31828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env31827 == env31828) = true)

theorem identity31828 : scanCanonicalize (H12AffineFastState.compose env31828 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound31828 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31829 : List Nat := [2,4,8,16,32,16,41,256,276,37,2048,2097,300,2325,1,295,2308,2309,37,0,2080,1,16,3,269,17,2081,2308,2097,2309,257,32,256,33,2324,277]

theorem envBound31829 : H12AffineFastState.Bounded env31829 := by
  intro p hp
  have h : env31829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31828_31829 : H12AffineEnvironment.transform 8 276 env31828 = env31829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env31828 == env31829) = true)

theorem identity31829 : scanCanonicalize (H12AffineFastState.compose env31829 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31829 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env31830 : List Nat := [2,4,8,16,16,16,25,256,276,21,2048,2049,284,2325,1,279,2308,2309,21,0,2064,1,16,3,269,17,2065,2308,2049,2309,257,16,256,17,2324,277]

theorem envBound31830 : H12AffineFastState.Bounded env31830 := by
  intro p hp
  have h : env31830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31829_31830 : H12AffineEnvironment.transform 4 16 env31829 = env31830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31829 == env31830) = true)

theorem identity31830 : scanCanonicalize (H12AffineFastState.compose env31830 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31830 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env31831 : List Nat := [2,4,8,0,0,0,9,256,260,5,2048,2049,268,2309,1,263,2308,2309,5,0,2048,1,0,3,269,1,2049,2308,2049,2309,257,0,256,1,2308,261]

theorem envBound31831 : H12AffineFastState.Bounded env31831 := by
  intro p hp
  have h : env31831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31830_31831 : H12AffineEnvironment.transform 3 0 env31830 = env31831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31830 == env31831) = true)

theorem identity31831 : scanCanonicalize (H12AffineFastState.compose env31831 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31832 : List Nat := [2,4,8,0,0,0,9,5,1,5,2048,2049,9,2048,1,2,2049,2048,5,0,2048,1,0,3,8,1,2049,2049,2049,2048,4,0,5,1,2049,0]

theorem envBound31832 : H12AffineFastState.Bounded env31832 := by
  intro p hp
  have h : env31832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31831_31832 : H12AffineEnvironment.transform 7 5 env31831 = env31832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31831 == env31832) = true)

theorem identity31832 : scanCanonicalize (H12AffineFastState.compose env31832 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31833 : List Nat := [2,4,8,0,0,0,9,5,1,5,1,0,9,1,1,2,0,1,5,0,1,1,0,3,8,1,0,0,0,1,4,0,5,1,0,0]

theorem envBound31833 : H12AffineFastState.Bounded env31833 := by
  intro p hp
  have h : env31833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31832_31833 : H12AffineEnvironment.transform 10 1 env31832 = env31833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31832 == env31833) = true)

def env31834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,4194304,17,98780,8328,65,4295166,5392,17664,67619,1500,4256861,256,21793,46213,74251]

theorem envBound31834 : H12AffineFastState.Bounded env31834 := by
  intro p hp
  have h : env31834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31804_31834 : H12AffineEnvironment.transform 22 17 env31804 = env31834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31804 == env31834) = true)

theorem identity31834 : scanCanonicalize (H12AffineFastState.compose env31834 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound31834 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env31835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,144492,17,98780,8328,65,245138,5392,17664,67619,1500,180273,256,21793,46213,74251]

theorem envBound31835 : H12AffineFastState.Bounded env31835 := by
  intro p hp
  have h : env31835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31834_31835 : H12AffineEnvironment.transform 21 144492 env31834 = env31835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env31834 == env31835) = true)

def env31836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,144492,17,98644,8192,65,245018,5392,17664,67619,1364,180273,256,21793,46093,74251]

theorem envBound31836 : H12AffineFastState.Bounded env31836 := by
  intro p hp
  have h : env31836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31835_31836 : H12AffineEnvironment.transform 6 8 env31835 = env31836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31835 == env31836) = true)

theorem identity31836 : scanCanonicalize (H12AffineFastState.compose env31836 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31836 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,144492,17,41310,8192,65,171280,5392,17664,10281,1364,180273,256,21793,46093,513]

theorem envBound31837 : H12AffineFastState.Bounded env31837 := by
  intro p hp
  have h : env31837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31836_31837 : H12AffineEnvironment.transform 15 8202 env31836 = env31837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31836 == env31837) = true)

theorem identity31837 : scanCanonicalize (H12AffineFastState.compose env31837 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound31837 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31838 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,24861,35109,1024,32769,4161,21873,17,41310,8192,65,64525,5392,17664,10281,1364,41260,256,21793,46093,513]

theorem envBound31838 : H12AffineFastState.Bounded env31838 := by
  intro p hp
  have h : env31838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31837_31838 : H12AffineEnvironment.transform 16 24861 env31837 = env31838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env31837 == env31838) = true)

theorem identity31838 : scanCanonicalize (H12AffineFastState.compose env31838 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31838 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env31839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,16400,35109,1024,32769,4161,21873,17,32851,269,65,56576,5392,17664,2340,1364,32801,256,21793,38144,513]

theorem envBound31839 : H12AffineFastState.Bounded env31839 := by
  intro p hp
  have h : env31839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31838_31839 : H12AffineEnvironment.transform 12 269 env31838 = env31839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31838 == env31839) = true)

theorem identity31839 : scanCanonicalize (H12AffineFastState.compose env31839 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound31839 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,263,16400,2421,1024,81,4161,21873,17,3,269,65,23888,5392,17664,2340,1364,113,256,21793,5456,513]

theorem envBound31840 : H12AffineFastState.Bounded env31840 := by
  intro p hp
  have h : env31840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31839_31840 : H12AffineEnvironment.transform 14 80 env31839 = env31840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env31839 == env31840) = true)

theorem identity31840 : scanCanonicalize (H12AffineFastState.compose env31840 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31840 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env31841 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,263,16400,2341,1024,1,4113,21793,17,3,269,17,23808,5392,17664,2340,1284,33,256,21793,5376,513]

theorem envBound31841 : H12AffineFastState.Bounded env31841 := by
  intro p hp
  have h : env31841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31840_31841 : H12AffineEnvironment.transform 5 16 env31840 = env31841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31840 == env31841) = true)

theorem identity31841 : scanCanonicalize (H12AffineFastState.compose env31841 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 7937) := by decide +kernel

theorem selectedBound31841 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31842 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,7937,0,263,7953,2341,1024,1,4113,2592,17,3,269,17,513,5392,6657,2340,1284,33,256,2592,5376,513]

theorem envBound31842 : H12AffineFastState.Bounded env31842 := by
  intro p hp
  have h : env31842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31841_31842 : H12AffineEnvironment.transform 13 7937 env31841 = env31842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7937 env31841 == env31842) = true)

theorem identity31842 : scanCanonicalize (H12AffineFastState.compose env31842 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31842 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31843 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,6673,0,263,6657,2341,272,1,4113,2592,17,3,269,17,513,4096,6657,2340,20,33,256,2592,4112,513]

theorem envBound31843 : H12AffineFastState.Bounded env31843 := by
  intro p hp
  have h : env31843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31842_31843 : H12AffineEnvironment.transform 9 272 env31842 = env31843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31842 == env31843) = true)

theorem identity31843 : scanCanonicalize (H12AffineFastState.compose env31843 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound31843 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env31844 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,529,269,2048,0,263,2064,2341,272,1,512,2592,17,3,269,17,513,529,2064,2340,20,33,256,2592,513,513]

theorem envBound31844 : H12AffineFastState.Bounded env31844 := by
  intro p hp
  have h : env31844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31843_31844 : H12AffineEnvironment.transform 11 529 env31843 = env31844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env31843 == env31844) = true)

theorem identity31844 : scanCanonicalize (H12AffineFastState.compose env31844 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound31844 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env31845 : List Nat := [2,4,8,16,32,16,8,256,512,272,821,529,269,821,0,263,805,528,272,1,512,277,17,3,269,17,513,529,805,529,20,33,256,277,513,513]

theorem envBound31845 : H12AffineFastState.Bounded env31845 := by
  intro p hp
  have h : env31845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31844_31845 : H12AffineEnvironment.transform 10 821 env31844 = env31845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env31844 == env31845) = true)

def env31846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,144492,17,98645,8193,65,245019,5392,17664,67619,1365,180273,256,21793,46092,74251]

theorem envBound31846 : H12AffineFastState.Bounded env31846 := by
  intro p hp
  have h : env31846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31835_31846 : H12AffineEnvironment.transform 6 9 env31835 = env31846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31835 == env31846) = true)

theorem identity31846 : scanCanonicalize (H12AffineFastState.compose env31846 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31846 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env31847 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,149860,1024,32769,4161,144492,17,3,8193,65,146509,5392,17664,35189,1365,180273,256,21793,46092,41821]

theorem envBound31847 : H12AffineFastState.Bounded env31847 := by
  intro p hp
  have h : env31847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31846_31847 : H12AffineEnvironment.transform 15 33110 env31846 = env31847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31846 == env31847) = true)

theorem identity31847 : scanCanonicalize (H12AffineFastState.compose env31847 (packedSelected [0,3,7,8,9,12,14,15,16,22,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound31847 : packedSelected [0,3,7,8,9,12,14,15,16,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env31848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33110,131072,138512,1024,32769,4161,144492,17,3,8193,65,146509,5392,4468,35189,1365,169029,256,341,46092,41821]

theorem envBound31848 : H12AffineFastState.Bounded env31848 := by
  intro p hp
  have h : env31848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31847_31848 : H12AffineEnvironment.transform 13 5236 env31847 = env31848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env31847 == env31848) = true)

theorem identity31848 : scanCanonicalize (H12AffineFastState.compose env31848 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound31848 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env31849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,32768,33110,13625,10281,1024,32769,4161,341,17,3,8193,65,2420,5392,4468,35189,1365,41340,256,341,46092,41821]

theorem envBound31849 : H12AffineFastState.Bounded env31849 := by
  intro p hp
  have h : env31849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31848_31849 : H12AffineEnvironment.transform 16 13625 env31848 = env31849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env31848 == env31849) = true)

theorem identity31849 : scanCanonicalize (H12AffineFastState.compose env31849 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31849 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8541,8203,13625,10281,1024,8540,4161,341,17,3,8193,65,2420,5392,4468,10280,1365,33,256,341,5457,512]

theorem envBound31850 : H12AffineFastState.Bounded env31850 := by
  intro p hp
  have h : env31850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31849_31850 : H12AffineEnvironment.transform 14 8541 env31849 = env31850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31849 == env31850) = true)

theorem identity31850 : scanCanonicalize (H12AffineFastState.compose env31850 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound31850 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,89,5236,260,82,5472,2160,1024,261,4161,341,17,3,88,65,2420,5392,4468,2161,1365,33,256,341,5457,512]

theorem envBound31851 : H12AffineFastState.Bounded env31851 := by
  intro p hp
  have h : env31851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31850_31851 : H12AffineEnvironment.transform 12 89 env31850 = env31851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env31850 == env31851) = true)

theorem identity31851 : scanCanonicalize (H12AffineFastState.compose env31851 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31851 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env31852 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,40,5125,260,35,5393,2049,1024,261,4144,292,17,3,41,48,2309,5392,4357,2048,1316,33,256,292,5408,512]

theorem envBound31852 : H12AffineFastState.Bounded env31852 := by
  intro p hp
  have h : env31852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31851_31852 : H12AffineEnvironment.transform 5 49 env31851 = env31852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31851 == env31852) = true)

theorem identity31852 : scanCanonicalize (H12AffineFastState.compose env31852 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31852 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31853 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,40,5125,33,35,5172,2049,1024,32,4144,1,17,3,41,48,2080,5173,4128,2048,1025,33,37,1,5125,512]

theorem envBound31853 : H12AffineFastState.Bounded env31853 := by
  intro p hp
  have h : env31853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31852_31853 : H12AffineEnvironment.transform 7 37 env31852 = env31853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31852 == env31853) = true)

def env31854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound31854 : H12AffineFastState.Bounded env31854 := by
  intro p hp
  have h : env31854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31690_31854 : H12AffineEnvironment.transform 18 1025 env31690 = env31854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env31690 == env31854) = true)

theorem identity31854 : scanCanonicalize (H12AffineFastState.compose env31854 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661170) := by decide +kernel

theorem selectedBound31854 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661170,8328,65,4450482,10857534,10507600,8830977,371875,15027570,257,2485278,2428347,297845]

theorem envBound31855 : H12AffineFastState.Bounded env31855 := by
  intro p hp
  have h : env31855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31854_31855 : H12AffineEnvironment.transform 23 8661170 env31854 = env31855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661170 env31854 == env31855) = true)

def env31856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450362,10857534,10507600,8830977,371755,15027570,257,2485278,2428211,297845]

theorem envBound31856 : H12AffineFastState.Bounded env31856 := by
  intro p hp
  have h : env31856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31855_31856 : H12AffineEnvironment.transform 6 8 env31855 = env31856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31855 == env31856) = true)

theorem identity31856 : scanCanonicalize (H12AffineFastState.compose env31856 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 256366) := by decide +kernel

theorem selectedBound31856 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env31857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,256366,1025,32769,2097152,4194304,8388608,8634708,8192,65,4450362,10634576,10507600,8464751,148805,14853148,257,2229616,2286685,221723]

theorem envBound31857 : H12AffineFastState.Bounded env31857 := by
  intro p hp
  have h : env31857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31856_31857 : H12AffineEnvironment.transform 17 256366 env31856 = env31857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 256366 env31856 == env31857) = true)

def env31858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108926,1025,32769,2097152,4194304,8388608,8487236,8192,65,4302890,10487104,10507600,8464751,1365,14738444,257,2114912,2139213,74251]

theorem envBound31858 : H12AffineFastState.Bounded env31858 := by
  intro p hp
  have h : env31858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31857_31858 : H12AffineEnvironment.transform 16 16400 env31857 = env31858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env31857 == env31858) = true)

theorem identity31858 : scanCanonicalize (H12AffineFastState.compose env31858 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound31858 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env31859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108926,1025,32769,2097152,4194304,4194353,4292981,8192,65,4302890,6292849,6313313,4270430,1365,2155581,257,2114912,2139213,74251]

theorem envBound31859 : H12AffineFastState.Bounded env31859 := by
  intro p hp
  have h : env31859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31858_31859 : H12AffineEnvironment.transform 22 4194353 env31858 = env31859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env31858 == env31859) = true)

theorem identity31859 : scanCanonicalize (H12AffineFastState.compose env31859 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31859 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env31860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,2097152,4194304,4194353,4235647,8192,65,4229152,6292849,6313313,4196692,1365,2155581,257,2114912,2139213,513]

theorem envBound31860 : H12AffineFastState.Bounded env31860 := by
  intro p hp
  have h : env31860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31859_31860 : H12AffineEnvironment.transform 15 8202 env31859 = env31860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31859 == env31860) = true)

theorem identity31860 : scanCanonicalize (H12AffineFastState.compose env31860 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 13325) := by decide +kernel

theorem selectedBound31860 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35188,1025,32769,13325,4194304,4194353,4235647,8192,65,4229152,4206972,4219244,4196692,1365,53296,257,29037,36928,513]

theorem envBound31861 : H12AffineFastState.Bounded env31861 := by
  intro p hp
  have h : env31861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31860_31861 : H12AffineEnvironment.transform 20 13325 env31860 = env31861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 13325 env31860 == env31861) = true)

theorem identity31861 : scanCanonicalize (H12AffineFastState.compose env31861 (packedSelected [0,7,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound31861 : packedSelected [0,7,20,21] rootPS < 2^1333 := by decide +kernel

def env31862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,16400,2420,1025,1,13325,4194304,4194353,4202879,8192,65,4196384,4206972,4219244,4196692,1365,20528,257,29037,4160,513]

theorem envBound31862 : H12AffineFastState.Bounded env31862 := by
  intro p hp
  have h : env31862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31861_31862 : H12AffineEnvironment.transform 14 0 env31861 = env31862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env31861 == env31862) = true)

theorem identity31862 : scanCanonicalize (H12AffineFastState.compose env31862 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound31862 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env31863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,0,8202,12637,2420,1025,1,13325,4194304,4194353,4202879,8192,65,4196384,4206972,4198433,4196692,1365,8573,257,32,4160,513]

theorem envBound31863 : H12AffineFastState.Bounded env31863 := by
  intro p hp
  have h : env31863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31862_31863 : H12AffineEnvironment.transform 13 12621 env31862 = env31863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env31862 == env31863) = true)

theorem identity31863 : scanCanonicalize (H12AffineFastState.compose env31863 (packedSelected [3,5,10,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound31863 : packedSelected [3,5,10,18,23] rootPS < 2^1333 := by decide +kernel

def env31864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,0,343,4096,2420,1025,1,5456,4194304,4194353,4194338,349,65,4196384,4198433,4198433,4196692,1365,32,257,32,4160,513]

theorem envBound31864 : H12AffineFastState.Bounded env31864 := by
  intro p hp
  have h : env31864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31863_31864 : H12AffineEnvironment.transform 12 349 env31863 = env31864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env31863 == env31864) = true)

theorem identity31864 : scanCanonicalize (H12AffineFastState.compose env31864 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31864 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,0,343,4096,2420,1025,1,5456,32,17,2,349,65,2048,4097,4097,2420,1365,32,257,32,4160,513]

theorem envBound31865 : H12AffineFastState.Bounded env31865 := by
  intro p hp
  have h : env31865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31864_31865 : H12AffineEnvironment.transform 21 32 env31864 = env31865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31864 == env31865) = true)

theorem identity31865 : scanCanonicalize (H12AffineFastState.compose env31865 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound31865 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31866 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,349,4112,0,343,4096,2420,100,1,4405,32,17,2,349,65,2048,4097,4097,2420,304,32,257,32,4160,513]

theorem envBound31866 : H12AffineFastState.Bounded env31866 := by
  intro p hp
  have h : env31866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31865_31866 : H12AffineEnvironment.transform 9 101 env31865 = env31866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env31865 == env31866) = true)

theorem identity31866 : scanCanonicalize (H12AffineFastState.compose env31866 (packedSelected [4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31866 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env31867 : List Nat := [2,4,8,16,17,64,8,256,512,84,2048,4096,349,4112,0,343,4096,2373,85,1,4356,17,17,2,349,65,2048,4097,4097,2373,257,17,257,17,4160,513]

theorem envBound31867 : H12AffineFastState.Bounded env31867 := by
  intro p hp
  have h : env31867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31866_31867 : H12AffineEnvironment.transform 4 17 env31866 = env31867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31866 == env31867) = true)

theorem identity31867 : scanCanonicalize (H12AffineFastState.compose env31867 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31868 : List Nat := [2,4,8,16,17,16,8,256,512,4,2048,4096,269,4112,0,263,4096,2325,5,1,4356,17,17,2,269,17,2048,4097,4097,2325,257,17,257,17,4112,513]

theorem envBound31868 : H12AffineFastState.Bounded env31868 := by
  intro p hp
  have h : env31868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31867_31868 : H12AffineEnvironment.transform 5 16 env31867 = env31868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31867 == env31868) = true)

def env31869 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,4194304,8388608,8487237,8192,65,4302891,10487105,10507600,8464751,1364,14738445,257,2114913,2139212,74250]

theorem envBound31869 : H12AffineFastState.Bounded env31869 := by
  intro p hp
  have h : env31869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31857_31869 : H12AffineEnvironment.transform 16 16401 env31857 = env31869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env31857 == env31869) = true)

theorem identity31869 : scanCanonicalize (H12AffineFastState.compose env31869 (packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS)) = affineNative (2^(22+1) ^^^ 4235629) := by decide +kernel

theorem selectedBound31869 : packedSelected [0,1,3,4,7,10,12,15,16,19,20,22,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env31870 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,4194304,4235629,4268072,8192,65,4302891,6333484,6353981,4294658,1364,2114912,257,2114913,2139212,74250]

theorem envBound31870 : H12AffineFastState.Bounded env31870 := by
  intro p hp
  have h : env31870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31869_31870 : H12AffineEnvironment.transform 22 4235629 env31869 = env31870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235629 env31869 == env31870) = true)

theorem identity31870 : scanCanonicalize (H12AffineFastState.compose env31870 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2122860) := by decide +kernel

theorem selectedBound31870 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env31871 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,108927,1025,32769,2097152,2122860,2147585,2180164,8192,65,2214983,49216,36945,2223214,1364,2114912,257,2114913,2139212,74250]

theorem envBound31871 : H12AffineFastState.Bounded env31871 := by
  intro p hp
  have h : env31871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31870_31871 : H12AffineEnvironment.transform 21 2122860 env31870 = env31871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122860 env31870 == env31871) = true)

theorem identity31871 : scanCanonicalize (H12AffineFastState.compose env31871 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31871 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env31872 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,67619,1025,8541,2097152,2122860,2122845,2180164,8192,65,2190619,24860,12557,2182450,1364,2114912,257,2114913,2098448,74250]

theorem envBound31872 : H12AffineFastState.Bounded env31872 := by
  intro p hp
  have h : env31872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31871_31872 : H12AffineEnvironment.transform 14 8540 env31871 = env31872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31871 == env31872) = true)

theorem identity31872 : scanCanonicalize (H12AffineFastState.compose env31872 (packedSelected [3,4,5,9,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound31872 : packedSelected [3,4,5,9,19] rootPS < 2^1333 := by decide +kernel

def env31873 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16401,10281,1025,8541,2097152,2122860,2122845,2122830,8192,65,2116881,24860,12557,2125112,1364,2114912,257,2114913,2098448,512]

theorem envBound31873 : H12AffineFastState.Bounded env31873 := by
  intro p hp
  have h : env31873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31872_31873 : H12AffineEnvironment.transform 15 8202 env31872 = env31873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env31872 == env31873) = true)

theorem identity31873 : scanCanonicalize (H12AffineFastState.compose env31873 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31873 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31874 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,8493,8202,16401,10281,1025,8492,2097152,2122781,2122796,2122815,8192,48,2116881,24860,12557,2125112,1317,2114833,257,2114832,2098448,512]

theorem envBound31874 : H12AffineFastState.Bounded env31874 := by
  intro p hp
  have h : env31874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31873_31874 : H12AffineEnvironment.transform 5 49 env31873 = env31874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31873 == env31874) = true)

theorem identity31874 : scanCanonicalize (H12AffineFastState.compose env31874 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(20+1) ^^^ 17712) := by decide +kernel

theorem selectedBound31874 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31875 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,16384,8493,8202,16401,10281,1025,8492,17712,8493,8476,8463,8192,48,2081,24860,12557,10248,1317,33,257,32,16416,512]

theorem envBound31875 : H12AffineFastState.Bounded env31875 := by
  intro p hp
  have h : env31875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31874_31875 : H12AffineEnvironment.transform 20 17712 env31874 = env31875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17712 env31874 == env31875) = true)

theorem identity31875 : scanCanonicalize (H12AffineFastState.compose env31875 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound31875 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31876 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,8192,5376,8493,8202,5393,10281,1025,8492,4144,8493,8476,8463,8192,48,2081,13340,12557,10248,1317,33,257,32,5408,512]

theorem envBound31876 : H12AffineFastState.Bounded env31876 := by
  intro p hp
  have h : env31876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31875_31876 : H12AffineEnvironment.transform 13 5376 env31875 = env31876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env31875 == env31876) = true)

theorem identity31876 : scanCanonicalize (H12AffineFastState.compose env31876 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31876 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31877 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,269,5376,32,263,5393,2340,1025,33,4144,32,17,2,269,48,2081,5393,4096,2309,1317,33,257,32,5408,512]

theorem envBound31877 : H12AffineFastState.Bounded env31877 := by
  intro p hp
  have h : env31877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31876_31877 : H12AffineEnvironment.transform 12 269 env31876 = env31877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31876 == env31877) = true)

theorem identity31877 : scanCanonicalize (H12AffineFastState.compose env31877 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31877 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31878 : List Nat := [2,4,8,16,32,49,8,5,512,1024,2048,4096,8,5125,32,2,5140,2081,1025,33,4144,32,17,2,8,48,2081,5140,4096,2048,1056,33,4,32,5157,512]

theorem envBound31878 : H12AffineFastState.Bounded env31878 := by
  intro p hp
  have h : env31878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31877_31878 : H12AffineEnvironment.transform 7 5 env31877 = env31878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31877 == env31878) = true)

theorem identity31878 : scanCanonicalize (H12AffineFastState.compose env31878 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31878 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31879 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5125,0,2,5140,2049,1025,1,4112,0,17,2,8,16,2049,5140,4096,2048,1024,1,4,0,5125,512]

theorem envBound31879 : H12AffineFastState.Bounded env31879 := by
  intro p hp
  have h : env31879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31878_31879 : H12AffineEnvironment.transform 4 0 env31878 = env31879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31878 == env31879) = true)

def env31880 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1045,0,2,1028,2049,1025,1,0,0,17,2,8,16,2049,1028,16,2048,1024,1,4,0,1045,512]

theorem envBound31880 : H12AffineFastState.Bounded env31880 := by
  intro p hp
  have h : env31880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31879_31880 : H12AffineEnvironment.transform 11 16 env31879 = env31880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31879 == env31880) = true)

theorem identity31880 : scanCanonicalize (H12AffineFastState.compose env31880 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound31880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31881 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1044,16,8,1045,0,2,1028,1045,1025,1,0,0,17,2,8,16,1045,1028,16,1044,1024,1,4,0,1045,512]

theorem envBound31881 : H12AffineFastState.Bounded env31881 := by
  intro p hp
  have h : env31881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31880_31881 : H12AffineEnvironment.transform 10 1044 env31880 = env31881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env31880 == env31881) = true)

def env31882 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,1,0,2,16,1,21,1,0,0,17,2,8,16,1,16,16,0,20,1,4,0,1,512]

theorem envBound31882 : H12AffineFastState.Bounded env31882 := by
  intro p hp
  have h : env31882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31881_31882 : H12AffineEnvironment.transform 9 20 env31881 = env31882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31881 == env31882) = true)

theorem identity31882 : scanCanonicalize (H12AffineFastState.compose env31882 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound31882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31883 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,4,8,1,0,2,4,1,1,1,0,0,5,2,8,4,1,4,4,0,0,1,4,0,1,512]

theorem envBound31883 : H12AffineFastState.Bounded env31883 := by
  intro p hp
  have h : env31883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31882_31883 : H12AffineEnvironment.transform 3 4 env31882 = env31883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env31882 == env31883) = true)

def leafEnv31883 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,4,8,1,0,2,4,1,1,1,0,0,5,2,1,8,1,4,1,4,4,0,0,1,4,0,5,2,1,512,1,0,0]

def active31883 : List Nat := [0,1,2,8]

def tree31883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31883 : H12WitnessSearch.Good tree31883 := H12GlobalWitnessIndex.good

theorem leafIdentity31883 : H12AffineFastState.composeSystem env31883 rootObs = leafEnv31883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31883 rootObs == leafEnv31883) = true)

theorem terminalChecked31883 : H12PackedTerminal.terminalCheckFast leafEnv31883 active31883 tree31883 = true := by decide +kernel

def env31884 : List Nat := [2,4,8,16,0,17,8,5,512,21,1,16,8,0,0,2,17,0,20,1,0,0,17,2,8,16,0,17,16,1,21,1,4,0,0,512]

theorem envBound31884 : H12AffineFastState.Bounded env31884 := by
  intro p hp
  have h : env31884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31881_31884 : H12AffineEnvironment.transform 9 21 env31881 = env31884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env31881 == env31884) = true)

theorem identity31884 : scanCanonicalize (H12AffineFastState.compose env31884 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound31884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31885 : List Nat := [2,4,8,16,0,17,8,5,31,21,1,16,8,0,0,2,17,0,20,1,0,0,17,2,8,16,0,17,16,1,21,1,4,0,0,31]

theorem envBound31885 : H12AffineFastState.Bounded env31885 := by
  intro p hp
  have h : env31885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31884_31885 : H12AffineEnvironment.transform 8 31 env31884 = env31885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env31884 == env31885) = true)

def leafEnv31885 : List Nat := [2,4,8,16,0,17,8,5,31,21,1,16,8,0,0,2,17,0,20,1,0,0,17,2,20,8,1,16,0,17,16,1,21,1,4,0,5,2,0,31,1,0,0]

def active31885 : List Nat := [0,1,2,3]

def tree31885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31885 : H12WitnessSearch.Good tree31885 := H12GlobalWitnessIndex.good

theorem leafIdentity31885 : H12AffineFastState.composeSystem env31885 rootObs = leafEnv31885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31885 rootObs == leafEnv31885) = true)

theorem terminalChecked31885 : H12PackedTerminal.terminalCheckFast leafEnv31885 active31885 tree31885 = true := by decide +kernel

def env31886 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1044,0,2,1029,2049,1025,1,1,0,17,2,8,16,2049,1029,17,2048,1024,1,4,0,1044,512]

theorem envBound31886 : H12AffineFastState.Bounded env31886 := by
  intro p hp
  have h : env31886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31879_31886 : H12AffineEnvironment.transform 11 17 env31879 = env31886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31879 == env31886) = true)

theorem identity31886 : scanCanonicalize (H12AffineFastState.compose env31886 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31887 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,8,1044,0,2,1029,1,1025,1,1,0,17,2,8,16,1,1029,17,0,1024,1,4,0,1044,512]

theorem envBound31887 : H12AffineFastState.Bounded env31887 := by
  intro p hp
  have h : env31887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31886_31887 : H12AffineEnvironment.transform 10 0 env31886 = env31887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31886 == env31887) = true)

def env31888 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,0,2,17,1,21,1,1,0,17,2,8,16,1,17,17,0,20,1,4,0,0,512]

theorem envBound31888 : H12AffineFastState.Bounded env31888 := by
  intro p hp
  have h : env31888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31887_31888 : H12AffineEnvironment.transform 9 20 env31887 = env31888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env31887 == env31888) = true)

theorem identity31888 : scanCanonicalize (H12AffineFastState.compose env31888 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound31888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31889 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,0,2,5,1,1,1,1,0,5,2,8,4,1,5,5,0,0,1,4,0,0,512]

theorem envBound31889 : H12AffineFastState.Bounded env31889 := by
  intro p hp
  have h : env31889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31888_31889 : H12AffineEnvironment.transform 3 4 env31888 = env31889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env31888 == env31889) = true)

def leafEnv31889 : List Nat := [2,4,8,4,0,5,8,5,512,0,0,5,8,0,0,2,5,1,1,1,1,0,5,2,1,8,1,4,1,5,5,0,0,1,4,0,5,2,0,512,1,1,0]

def active31889 : List Nat := [0,1,2,8]

def tree31889 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31889 : H12WitnessSearch.Good tree31889 := H12GlobalWitnessIndex.good

theorem leafIdentity31889 : H12AffineFastState.composeSystem env31889 rootObs = leafEnv31889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31889 rootObs == leafEnv31889) = true)

theorem terminalChecked31889 : H12PackedTerminal.terminalCheckFast leafEnv31889 active31889 tree31889 = true := by decide +kernel

def env31890 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,1,0,2,16,1,20,1,1,0,17,2,8,16,1,16,17,0,21,1,4,0,1,512]

theorem envBound31890 : H12AffineFastState.Bounded env31890 := by
  intro p hp
  have h : env31890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31887_31890 : H12AffineEnvironment.transform 9 21 env31887 = env31890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env31887 == env31890) = true)

theorem identity31890 : scanCanonicalize (H12AffineFastState.compose env31890 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound31890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31891 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,8,1,0,2,16,1,20,1,1,0,17,2,8,16,1,16,17,0,21,1,4,0,1,30]

theorem envBound31891 : H12AffineFastState.Bounded env31891 := by
  intro p hp
  have h : env31891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31890_31891 : H12AffineEnvironment.transform 8 30 env31890 = env31891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env31890 == env31891) = true)

def leafEnv31891 : List Nat := [2,4,8,16,0,17,8,5,30,21,0,17,8,1,0,2,16,1,20,1,1,0,17,2,20,8,1,16,1,16,17,0,21,1,4,0,5,2,1,30,1,1,0]

def active31891 : List Nat := [0,1,2,3]

def tree31891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood31891 : H12WitnessSearch.Good tree31891 := H12GlobalWitnessIndex.good

theorem leafIdentity31891 : H12AffineFastState.composeSystem env31891 rootObs = leafEnv31891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env31891 rootObs == leafEnv31891) = true)

theorem terminalChecked31891 : H12PackedTerminal.terminalCheckFast leafEnv31891 active31891 tree31891 = true := by decide +kernel

def env31892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661051,8193,65,4450363,10857534,10507600,8830977,371754,15027570,257,2485278,2428210,297845]

theorem envBound31892 : H12AffineFastState.Bounded env31892 := by
  intro p hp
  have h : env31892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31855_31892 : H12AffineEnvironment.transform 6 9 env31855 = env31892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31855 == env31892) = true)

theorem identity31892 : scanCanonicalize (H12AffineFastState.compose env31892 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound31892 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env31893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8429903,8193,65,4450363,10560842,10507600,8538485,75102,14795782,257,2188650,2196550,513]

theorem envBound31893 : H12AffineFastState.Bounded env31893 := by
  intro p hp
  have h : env31893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31892_31893 : H12AffineEnvironment.transform 17 35188 env31892 = env31893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env31892 == env31893) = true)

def env31894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,16,41311,8193,65,4450363,2172250,2118976,149861,75102,6407190,257,2188650,2196550,513]

theorem envBound31894 : H12AffineFastState.Bounded env31894 := by
  intro p hp
  have h : env31894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31893_31894 : H12AffineEnvironment.transform 22 16 env31893 = env31894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env31893 == env31894) = true)

theorem identity31894 : scanCanonicalize (H12AffineFastState.compose env31894 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound31894 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env31895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2172250,2118976,76159,75102,6407190,257,2188650,2196550,513]

theorem envBound31895 : H12AffineFastState.Bounded env31895 := by
  intro p hp
  have h : env31895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31894_31895 : H12AffineEnvironment.transform 16 90138 env31894 = env31895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env31894 == env31895) = true)

theorem identity31895 : scanCanonicalize (H12AffineFastState.compose env31895 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound31895 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57676,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2139148,2118976,43049,41992,6309184,257,2155580,2098448,513]

theorem envBound31896 : H12AffineFastState.Bounded env31896 := by
  intro p hp
  have h : env31896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31895_31896 : H12AffineEnvironment.transform 15 33110 env31895 = env31896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env31895 == env31896) = true)

theorem identity31896 : scanCanonicalize (H12AffineFastState.compose env31896 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31896 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env31897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,2097152,4194304,16,2,8193,65,4204924,2098513,2118976,2420,1365,6309184,257,2114913,2098448,513]

theorem envBound31897 : H12AffineFastState.Bounded env31897 := by
  intro p hp
  have h : env31897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31896_31897 : H12AffineEnvironment.transform 14 8541 env31896 = env31897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31896 == env31897) = true)

theorem identity31897 : scanCanonicalize (H12AffineFastState.compose env31897 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound31897 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,2097152,2114912,16,2,8193,65,2124828,2098513,2118976,2420,1365,32,257,2114913,2098448,513]

theorem envBound31898 : H12AffineFastState.Bounded env31898 := by
  intro p hp
  have h : env31898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31897_31898 : H12AffineEnvironment.transform 21 2114912 env31897 = env31898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env31897 == env31898) = true)

theorem identity31898 : scanCanonicalize (H12AffineFastState.compose env31898 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound31898 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1025,8540,25677,8493,16,2,8193,65,2129,24860,12557,2420,1365,32,257,8492,24925,513]

theorem envBound31899 : H12AffineFastState.Bounded env31899 := by
  intro p hp
  have h : env31899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31898_31899 : H12AffineEnvironment.transform 20 25677 env31898 = env31899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env31898 == env31899) = true)

theorem identity31899 : scanCanonicalize (H12AffineFastState.compose env31899 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31899 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env31900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,81,263,16401,2341,1025,80,17729,33,16,2,269,65,2129,16400,4097,2420,1365,32,257,32,16465,513]

theorem envBound31900 : H12AffineFastState.Bounded env31900 := by
  intro p hp
  have h : env31900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31899_31900 : H12AffineEnvironment.transform 12 268 env31899 = env31900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31899 == env31900) = true)

theorem identity31900 : scanCanonicalize (H12AffineFastState.compose env31900 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1393) := by decide +kernel

theorem selectedBound31900 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1393,268,16384,81,263,16401,2341,1025,80,17729,33,16,2,269,65,2129,16400,1392,2420,1365,32,257,32,16465,513]

theorem envBound31901 : H12AffineFastState.Bounded env31901 := by
  intro p hp
  have h : env31901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31900_31901 : H12AffineEnvironment.transform 11 1393 env31900 = env31901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1393 env31900 == env31901) = true)

theorem identity31901 : scanCanonicalize (H12AffineFastState.compose env31901 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2625) := by decide +kernel

theorem selectedBound31901 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1393,268,2625,81,263,2640,2341,1025,80,3840,33,16,2,269,65,2129,2641,1392,2420,1365,32,257,32,2576,513]

theorem envBound31902 : H12AffineFastState.Bounded env31902 := by
  intro p hp
  have h : env31902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31901_31902 : H12AffineEnvironment.transform 13 2625 env31901 = env31902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2625 env31901 == env31902) = true)

theorem identity31902 : scanCanonicalize (H12AffineFastState.compose env31902 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound31902 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31903 : List Nat := [2,4,8,16,32,64,9,256,276,1024,2048,1393,268,2389,81,263,2372,2341,1025,80,3092,33,16,2,269,65,2129,2373,1392,2420,1365,32,257,32,2308,277]

theorem envBound31903 : H12AffineFastState.Bounded env31903 := by
  intro p hp
  have h : env31903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31902_31903 : H12AffineEnvironment.transform 8 276 env31902 = env31903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env31902 == env31903) = true)

theorem identity31903 : scanCanonicalize (H12AffineFastState.compose env31903 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31903 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31904 : List Nat := [2,4,8,16,32,64,9,85,65,1024,2048,1060,89,2048,81,82,2065,2160,1025,80,3092,33,16,2,88,65,2129,2064,1061,2081,1024,32,84,32,2129,64]

theorem envBound31904 : H12AffineFastState.Bounded env31904 := by
  intro p hp
  have h : env31904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31903_31904 : H12AffineEnvironment.transform 7 85 env31903 = env31904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31903 == env31904) = true)

def env31905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,17,41310,8193,65,4450363,2172251,2118977,149860,75102,6407191,257,2188650,2196550,513]

theorem envBound31905 : H12AffineFastState.Bounded env31905 := by
  intro p hp
  have h : env31905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31893_31905 : H12AffineEnvironment.transform 22 17 env31893 = env31905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env31893 == env31905) = true)

theorem identity31905 : scanCanonicalize (H12AffineFastState.compose env31905 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound31905 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env31906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,115734,4194304,17,41310,8193,65,4450363,57677,102743,149860,75102,4194305,257,41340,16464,513]

theorem envBound31906 : H12AffineFastState.Bounded env31906 := by
  intro p hp
  have h : env31906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31905_31906 : H12AffineEnvironment.transform 20 115734 env31905 = env31906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env31905 == env31906) = true)

def env31907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9292,1025,11577,92462,4194304,17,3174,8193,65,4408579,19573,81007,149860,75102,4194305,257,3140,16464,513]

theorem envBound31907 : H12AffineFastState.Bounded env31907 := by
  intro p hp
  have h : env31907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31906_31907 : H12AffineEnvironment.transform 14 11576 env31906 = env31907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env31906 == env31907) = true)

theorem identity31907 : scanCanonicalize (H12AffineFastState.compose env31907 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound31907 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env31908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11576,65536,82247,9292,1025,11577,92462,4194304,17,3174,8193,65,4195396,19573,81007,67619,75102,4194305,257,3140,16464,513]

theorem envBound31908 : H12AffineFastState.Bounded env31908 := by
  intro p hp
  have h : env31908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31907_31908 : H12AffineEnvironment.transform 16 82247 env31907 = env31908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env31907 == env31908) = true)

def env31909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,65536,82247,9292,1025,8541,91466,4194304,17,2,8193,65,4195396,16401,77835,66631,75102,4194305,257,32,16464,513]

theorem envBound31909 : H12AffineFastState.Bounded env31909 := by
  intro p hp
  have h : env31909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31908_31909 : H12AffineEnvironment.transform 10 1124 env31908 = env31909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env31908 == env31909) = true)

theorem identity31909 : scanCanonicalize (H12AffineFastState.compose env31909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound31909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8540,28698,12637,9292,1025,8541,5456,4194304,17,2,8193,65,4195396,16401,16401,29789,21828,4194305,257,32,16464,513]

theorem envBound31910 : H12AffineFastState.Bounded env31910 := by
  intro p hp
  have h : env31910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31909_31910 : H12AffineEnvironment.transform 15 28698 env31909 = env31910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env31909 == env31910) = true)

theorem identity31910 : scanCanonicalize (H12AffineFastState.compose env31910 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound31910 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env31911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,41,16384,373,20531,4468,1125,1025,372,5456,4194304,17,2,40,65,4195396,16401,16401,21620,21828,4194305,257,32,16464,513]

theorem envBound31911 : H12AffineFastState.Bounded env31911 := by
  intro p hp
  have h : env31911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31910_31911 : H12AffineEnvironment.transform 12 41 env31910 = env31911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env31910 == env31911) = true)

theorem identity31911 : scanCanonicalize (H12AffineFastState.compose env31911 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound31911 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env31912 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,1,20531,4096,1125,1025,0,5156,4194304,17,2,40,65,4195396,16401,16401,21620,21552,4194305,117,32,16464,513]

theorem envBound31912 : H12AffineFastState.Bounded env31912 := by
  intro p hp
  have h : env31912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31911_31912 : H12AffineEnvironment.transform 7 116 env31911 = env31912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31911 == env31912) = true)

theorem identity31912 : scanCanonicalize (H12AffineFastState.compose env31912 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1045) := by decide +kernel

theorem selectedBound31912 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31913 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,16384,1,20531,4096,1125,1025,0,5156,1045,17,2,40,65,81,16401,16401,21620,21552,1044,117,32,16464,513]

theorem envBound31913 : H12AffineFastState.Bounded env31913 := by
  intro p hp
  have h : env31913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31912_31913 : H12AffineEnvironment.transform 21 1045 env31912 = env31913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1045 env31912 == env31913) = true)

theorem identity31913 : scanCanonicalize (H12AffineFastState.compose env31913 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound31913 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env31914 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,4096,41,1,1,4146,4096,1125,1025,0,5156,1045,17,2,40,65,81,16,16,5237,5169,1044,117,32,81,513]

theorem envBound31914 : H12AffineFastState.Bounded env31914 := by
  intro p hp
  have h : env31914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31913_31914 : H12AffineEnvironment.transform 13 1 env31913 = env31914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env31913 == env31914) = true)

theorem identity31914 : scanCanonicalize (H12AffineFastState.compose env31914 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound31914 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31915 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1124,16,41,1,1,34,16,1125,1025,0,1076,1045,17,2,40,65,81,16,16,1125,1057,1044,117,32,81,513]

theorem envBound31915 : H12AffineFastState.Bounded env31915 := by
  intro p hp
  have h : env31915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31914_31915 : H12AffineEnvironment.transform 11 16 env31914 = env31915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31914 == env31915) = true)

theorem identity31915 : scanCanonicalize (H12AffineFastState.compose env31915 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound31915 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31916 : List Nat := [2,4,8,16,32,64,9,116,81,1024,1124,16,41,1,1,34,16,1125,1025,0,1076,1045,17,2,40,65,81,16,16,1125,1057,1044,117,32,81,80]

theorem envBound31916 : H12AffineFastState.Bounded env31916 := by
  intro p hp
  have h : env31916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31915_31916 : H12AffineEnvironment.transform 8 81 env31915 = env31916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env31915 == env31916) = true)

theorem identity31916 : scanCanonicalize (H12AffineFastState.compose env31916 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound31916 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31917 : List Nat := [2,4,8,16,32,64,9,116,81,100,0,16,41,1,1,34,16,1,101,0,80,113,17,2,40,65,81,16,16,1,69,112,117,32,81,80]

theorem envBound31917 : H12AffineFastState.Bounded env31917 := by
  intro p hp
  have h : env31917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31916_31917 : H12AffineEnvironment.transform 9 100 env31916 = env31917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env31916 == env31917) = true)

theorem identity31917 : scanCanonicalize (H12AffineFastState.compose env31917 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound31917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31918 : List Nat := [2,4,8,16,32,32,9,20,49,4,0,16,41,1,1,34,16,1,5,0,48,17,17,2,40,33,49,16,16,1,37,16,21,32,49,48]

theorem envBound31918 : H12AffineFastState.Bounded env31918 := by
  intro p hp
  have h : env31918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31917_31918 : H12AffineEnvironment.transform 5 32 env31917 = env31918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env31917 == env31918) = true)

def env31919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,16384,8541,65536,82247,9292,1025,8540,91467,4194304,17,3,8193,65,4195396,16400,77834,66630,75102,4194305,257,33,16464,513]

theorem envBound31919 : H12AffineFastState.Bounded env31919 := by
  intro p hp
  have h : env31919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31908_31919 : H12AffineEnvironment.transform 10 1125 env31908 = env31919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env31908 == env31919) = true)

def env31920 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,8192,16384,8461,65536,82199,9244,1025,8460,91419,4194304,17,3,8193,17,4195348,16400,77834,66582,75022,4194305,257,33,16384,513]

theorem envBound31920 : H12AffineFastState.Bounded env31920 := by
  intro p hp
  have h : env31920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31920 : H12AffineEnvironment.transform 5 16 env31919 = env31920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31919 == env31920) = true)

theorem identity31920 : scanCanonicalize (H12AffineFastState.compose env31920 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31920 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31921 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,1,65536,82199,1296,1025,0,82967,4194304,17,3,269,17,4195348,16400,69894,66582,66562,4194305,257,33,16384,513]

theorem envBound31921 : H12AffineFastState.Bounded env31921 := by
  intro p hp
  have h : env31921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31920_31921 : H12AffineEnvironment.transform 12 268 env31920 = env31921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31920 == env31921) = true)

theorem identity31921 : scanCanonicalize (H12AffineFastState.compose env31921 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31921 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31922 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,1,65536,82199,1296,1025,0,82967,32,17,3,269,17,1076,16400,69894,66582,66562,33,257,33,16384,513]

theorem envBound31922 : H12AffineFastState.Bounded env31922 := by
  intro p hp
  have h : env31922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31921_31922 : H12AffineEnvironment.transform 21 32 env31921 = env31922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31921 == env31922) = true)

theorem identity31922 : scanCanonicalize (H12AffineFastState.compose env31922 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound31922 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31923 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,16384,1,263,16400,1296,1025,0,17680,32,17,3,269,17,1076,16400,4097,1297,1285,33,257,33,16384,513]

theorem envBound31923 : H12AffineFastState.Bounded env31923 := by
  intro p hp
  have h : env31923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31922_31923 : H12AffineEnvironment.transform 15 263 env31922 = env31923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env31922 == env31923) = true)

theorem identity31923 : scanCanonicalize (H12AffineFastState.compose env31923 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound31923 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31924 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,4096,268,1297,1,263,1281,1296,1025,0,1,32,17,3,269,17,1076,1281,4097,1297,1285,33,257,33,1297,513]

theorem envBound31924 : H12AffineFastState.Bounded env31924 := by
  intro p hp
  have h : env31924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31923_31924 : H12AffineEnvironment.transform 13 1297 env31923 = env31924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31923 == env31924) = true)

theorem identity31924 : scanCanonicalize (H12AffineFastState.compose env31924 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound31924 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31925 : List Nat := [2,4,8,16,32,16,9,256,512,794,815,4096,268,523,1,263,539,522,795,0,1,32,17,3,269,17,814,539,4097,523,543,33,257,33,523,513]

theorem envBound31925 : H12AffineFastState.Bounded env31925 := by
  intro p hp
  have h : env31925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31924_31925 : H12AffineEnvironment.transform 9 794 env31924 = env31925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env31924 == env31925) = true)

theorem identity31925 : scanCanonicalize (H12AffineFastState.compose env31925 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31925 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31926 : List Nat := [2,4,8,16,32,16,9,4,512,542,555,4096,8,523,1,3,539,522,543,0,1,32,17,3,9,17,554,539,4097,523,543,33,5,33,523,513]

theorem envBound31926 : H12AffineFastState.Bounded env31926 := by
  intro p hp
  have h : env31926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31925_31926 : H12AffineEnvironment.transform 7 4 env31925 = env31926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31925 == env31926) = true)

theorem identity31926 : scanCanonicalize (H12AffineFastState.compose env31926 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound31926 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31927 : List Nat := [2,4,8,16,32,16,9,4,512,542,555,16,8,523,1,3,539,522,543,0,1,32,17,3,9,17,554,539,17,523,543,33,5,33,523,513]

theorem envBound31927 : H12AffineFastState.Bounded env31927 := by
  intro p hp
  have h : env31927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31926_31927 : H12AffineEnvironment.transform 11 16 env31926 = env31927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31926 == env31927) = true)

theorem identity31927 : scanCanonicalize (H12AffineFastState.compose env31927 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound31927 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31928 : List Nat := [2,4,8,16,32,16,9,4,11,21,32,16,8,0,1,3,16,1,20,0,1,32,17,3,9,17,33,16,17,0,20,33,5,33,0,10]

theorem envBound31928 : H12AffineFastState.Bounded env31928 := by
  intro p hp
  have h : env31928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31927_31928 : H12AffineEnvironment.transform 8 11 env31927 = env31928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env31927 == env31928) = true)

theorem identity31928 : scanCanonicalize (H12AffineFastState.compose env31928 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31928 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env31929 : List Nat := [2,4,8,16,1,16,9,4,11,21,1,16,8,0,1,3,16,1,20,0,1,1,17,3,9,17,0,16,17,0,20,0,5,0,0,10]

theorem envBound31929 : H12AffineFastState.Bounded env31929 := by
  intro p hp
  have h : env31929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31928_31929 : H12AffineEnvironment.transform 4 1 env31928 = env31929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31928 == env31929) = true)

theorem identity31929 : scanCanonicalize (H12AffineFastState.compose env31929 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31930 : List Nat := [2,0,8,16,1,16,9,0,11,17,1,16,8,0,1,3,16,1,16,0,1,1,17,3,9,17,0,16,17,0,16,0,1,0,0,10]

theorem envBound31930 : H12AffineFastState.Bounded env31930 := by
  intro p hp
  have h : env31930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31929_31930 : H12AffineEnvironment.transform 1 0 env31929 = env31930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31929 == env31930) = true)

theorem identity31930 : scanCanonicalize (H12AffineFastState.compose env31930 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound31930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31931 : List Nat := [2,0,8,3,1,3,9,0,11,2,1,3,8,0,1,3,3,1,3,0,1,1,2,3,9,2,0,3,2,0,3,0,1,0,0,10]

theorem envBound31931 : H12AffineFastState.Bounded env31931 := by
  intro p hp
  have h : env31931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31930_31931 : H12AffineEnvironment.transform 3 3 env31930 = env31931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env31930 == env31931) = true)

def env31932 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8460,65536,82198,9245,1025,8461,91418,4194304,17,3,8193,16,4195349,16400,77834,66583,75023,4194305,257,33,16385,513]

theorem envBound31932 : H12AffineFastState.Bounded env31932 := by
  intro p hp
  have h : env31932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31932 : H12AffineEnvironment.transform 5 17 env31919 = env31932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31919 == env31932) = true)

theorem identity31932 : scanCanonicalize (H12AffineFastState.compose env31932 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound31932 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31933 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8460,262,16400,9245,1025,8461,25628,4194304,17,3,8193,16,4195349,16400,12556,1297,9225,4194305,257,33,16385,513]

theorem envBound31933 : H12AffineFastState.Bounded env31933 := by
  intro p hp
  have h : env31933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31932_31933 : H12AffineEnvironment.transform 15 262 env31932 = env31933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env31932 == env31933) = true)

theorem identity31933 : scanCanonicalize (H12AffineFastState.compose env31933 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31933 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31934 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,16384,8460,262,16400,9245,1025,8461,25628,32,17,3,8193,16,1077,16400,12556,1297,9225,33,257,33,16385,513]

theorem envBound31934 : H12AffineFastState.Bounded env31934 := by
  intro p hp
  have h : env31934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31933_31934 : H12AffineEnvironment.transform 21 32 env31933 = env31934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31933 == env31934) = true)

theorem identity31934 : scanCanonicalize (H12AffineFastState.compose env31934 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 9529) := by decide +kernel

theorem selectedBound31934 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31935 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,8192,9529,8460,262,9513,9245,1025,8461,293,32,17,3,8193,16,1077,9513,12556,1297,9225,33,257,33,9528,513]

theorem envBound31935 : H12AffineFastState.Bounded env31935 := by
  intro p hp
  have h : env31935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31934_31935 : H12AffineEnvironment.transform 13 9529 env31934 = env31935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9529 env31934 == env31935) = true)

theorem identity31935 : scanCanonicalize (H12AffineFastState.compose env31935 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound31935 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env31936 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1076,4096,269,1076,1,262,1060,1296,1025,0,293,32,17,3,268,16,1077,1060,4097,1297,1284,33,257,33,1077,513]

theorem envBound31936 : H12AffineFastState.Bounded env31936 := by
  intro p hp
  have h : env31936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31935_31936 : H12AffineEnvironment.transform 12 269 env31935 = env31936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env31935 == env31936) = true)

theorem identity31936 : scanCanonicalize (H12AffineFastState.compose env31936 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound31936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31937 : List Nat := [2,4,8,16,32,17,9,256,512,52,0,4096,269,0,1,262,16,292,53,0,293,32,17,3,268,16,1,16,4097,293,304,33,257,33,1,513]

theorem envBound31937 : H12AffineFastState.Bounded env31937 := by
  intro p hp
  have h : env31937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31936_31937 : H12AffineEnvironment.transform 9 52 env31936 = env31937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env31936 == env31937) = true)

theorem identity31937 : scanCanonicalize (H12AffineFastState.compose env31937 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound31937 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31938 : List Nat := [2,4,8,16,32,17,9,256,303,52,0,4096,269,0,1,262,16,292,53,0,293,32,17,3,268,16,1,16,4097,293,304,33,257,33,1,302]

theorem envBound31938 : H12AffineFastState.Bounded env31938 := by
  intro p hp
  have h : env31938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31937_31938 : H12AffineEnvironment.transform 8 303 env31937 = env31938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env31937 == env31938) = true)

theorem identity31938 : scanCanonicalize (H12AffineFastState.compose env31938 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound31938 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31939 : List Nat := [2,4,8,16,32,17,9,256,303,52,0,276,269,0,1,262,16,292,53,0,293,32,17,3,268,16,1,16,277,293,304,33,257,33,1,302]

theorem envBound31939 : H12AffineFastState.Bounded env31939 := by
  intro p hp
  have h : env31939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31938_31939 : H12AffineEnvironment.transform 11 276 env31938 = env31939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env31938 == env31939) = true)

def env31940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9293,1025,11576,92463,4194304,17,3175,8193,65,4408578,19572,81006,149860,75102,4194305,257,3141,16464,513]

theorem envBound31940 : H12AffineFastState.Bounded env31940 := by
  intro p hp
  have h : env31940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31906_31940 : H12AffineEnvironment.transform 14 11577 env31906 = env31940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env31906 == env31940) = true)

theorem identity31940 : scanCanonicalize (H12AffineFastState.compose env31940 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85283) := by decide +kernel

theorem selectedBound31940 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env31941 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,11577,65536,85283,9293,1025,11576,92463,4194304,17,3175,8193,65,4196385,19572,81006,66631,75102,4194305,257,3141,16464,513]

theorem envBound31941 : H12AffineFastState.Bounded env31941 := by
  intro p hp
  have h : env31941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31940_31941 : H12AffineEnvironment.transform 16 85283 env31940 = env31941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85283 env31940 == env31941) = true)

theorem identity31941 : scanCanonicalize (H12AffineFastState.compose env31941 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound31941 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env31942 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,4096,8192,16384,8541,65536,82247,9293,1025,8540,91467,4194304,17,3,8193,65,4195397,16400,77834,66631,75102,4194305,257,33,16464,513]

theorem envBound31942 : H12AffineFastState.Bounded env31942 := by
  intro p hp
  have h : env31942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31941_31942 : H12AffineEnvironment.transform 10 1124 env31941 = env31942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env31941 == env31942) = true)

def env31943 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,8192,16384,8461,65536,82199,9245,1025,8460,91419,4194304,17,3,8193,17,4195349,16400,77834,66583,75022,4194305,257,33,16384,513]

theorem envBound31943 : H12AffineFastState.Bounded env31943 := by
  intro p hp
  have h : env31943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31942_31943 : H12AffineEnvironment.transform 5 16 env31942 = env31943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31942 == env31943) = true)

theorem identity31943 : scanCanonicalize (H12AffineFastState.compose env31943 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound31943 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31944 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,1,65536,82199,1297,1025,0,82967,4194304,17,3,269,17,4195349,16400,69894,66583,66562,4194305,257,33,16384,513]

theorem envBound31944 : H12AffineFastState.Bounded env31944 := by
  intro p hp
  have h : env31944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31943_31944 : H12AffineEnvironment.transform 12 268 env31943 = env31944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env31943 == env31944) = true)

theorem identity31944 : scanCanonicalize (H12AffineFastState.compose env31944 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31944 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31945 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,1,65536,82199,1297,1025,0,82967,32,17,3,269,17,1077,16400,69894,66583,66562,33,257,33,16384,513]

theorem envBound31945 : H12AffineFastState.Bounded env31945 := by
  intro p hp
  have h : env31945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31944_31945 : H12AffineEnvironment.transform 21 32 env31944 = env31945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31944 == env31945) = true)

theorem identity31945 : scanCanonicalize (H12AffineFastState.compose env31945 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound31945 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env31946 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,16384,1,263,16400,1297,1025,0,17680,32,17,3,269,17,1077,16400,4097,1296,1285,33,257,33,16384,513]

theorem envBound31946 : H12AffineFastState.Bounded env31946 := by
  intro p hp
  have h : env31946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31945_31946 : H12AffineEnvironment.transform 15 263 env31945 = env31946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env31945 == env31946) = true)

theorem identity31946 : scanCanonicalize (H12AffineFastState.compose env31946 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound31946 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31947 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1076,4096,268,1297,1,263,1281,1297,1025,0,1,32,17,3,269,17,1077,1281,4097,1296,1285,33,257,33,1297,513]

theorem envBound31947 : H12AffineFastState.Bounded env31947 := by
  intro p hp
  have h : env31947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31946_31947 : H12AffineEnvironment.transform 13 1297 env31946 = env31947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31946 == env31947) = true)

theorem identity31947 : scanCanonicalize (H12AffineFastState.compose env31947 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound31947 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31948 : List Nat := [2,4,8,16,32,16,9,256,512,795,815,4096,268,522,1,263,538,522,794,0,1,32,17,3,269,17,814,538,4097,523,542,33,257,33,522,513]

theorem envBound31948 : H12AffineFastState.Bounded env31948 := by
  intro p hp
  have h : env31948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31947_31948 : H12AffineEnvironment.transform 9 795 env31947 = env31948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env31947 == env31948) = true)

theorem identity31948 : scanCanonicalize (H12AffineFastState.compose env31948 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31948 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31949 : List Nat := [2,4,8,16,32,16,9,5,512,542,554,4096,9,522,1,2,538,522,543,0,1,32,17,3,8,17,555,538,4097,523,542,33,4,33,522,513]

theorem envBound31949 : H12AffineFastState.Bounded env31949 := by
  intro p hp
  have h : env31949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31948_31949 : H12AffineEnvironment.transform 7 5 env31948 = env31949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31948 == env31949) = true)

theorem identity31949 : scanCanonicalize (H12AffineFastState.compose env31949 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound31949 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31950 : List Nat := [2,4,8,16,32,16,9,5,512,542,554,17,9,522,1,2,538,522,543,0,1,32,17,3,8,17,555,538,16,523,542,33,4,33,522,513]

theorem envBound31950 : H12AffineFastState.Bounded env31950 := by
  intro p hp
  have h : env31950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31949_31950 : H12AffineEnvironment.transform 11 17 env31949 = env31950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31949 == env31950) = true)

theorem identity31950 : scanCanonicalize (H12AffineFastState.compose env31950 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound31950 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env31951 : List Nat := [2,4,8,16,32,16,9,5,11,21,33,17,9,1,1,2,17,1,20,0,1,32,17,3,8,17,32,17,16,0,21,33,4,33,1,10]

theorem envBound31951 : H12AffineFastState.Bounded env31951 := by
  intro p hp
  have h : env31951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31950_31951 : H12AffineEnvironment.transform 8 11 env31950 = env31951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env31950 == env31951) = true)

theorem identity31951 : scanCanonicalize (H12AffineFastState.compose env31951 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31951 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env31952 : List Nat := [2,4,8,16,1,16,9,5,11,21,0,17,9,1,1,2,17,1,20,0,1,1,17,3,8,17,1,17,16,0,21,0,4,0,1,10]

theorem envBound31952 : H12AffineFastState.Bounded env31952 := by
  intro p hp
  have h : env31952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31951_31952 : H12AffineEnvironment.transform 4 1 env31951 = env31952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31951 == env31952) = true)

theorem identity31952 : scanCanonicalize (H12AffineFastState.compose env31952 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound31952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31953 : List Nat := [2,4,8,14,1,14,9,5,11,11,0,15,9,1,1,2,15,1,10,0,1,1,15,3,8,15,1,15,14,0,11,0,4,0,1,10]

theorem envBound31953 : H12AffineFastState.Bounded env31953 := by
  intro p hp
  have h : env31953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31952_31953 : H12AffineEnvironment.transform 3 14 env31952 = env31953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env31952 == env31953) = true)

theorem identity31953 : scanCanonicalize (H12AffineFastState.compose env31953 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31954 : List Nat := [2,4,0,6,1,6,1,5,3,3,0,7,1,1,1,2,7,1,2,0,1,1,7,3,0,7,1,7,6,0,3,0,4,0,1,2]

theorem envBound31954 : H12AffineFastState.Bounded env31954 := by
  intro p hp
  have h : env31954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31953_31954 : H12AffineEnvironment.transform 2 0 env31953 = env31954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31953 == env31954) = true)

def env31955 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8460,65536,82198,9244,1025,8461,91418,4194304,17,3,8193,16,4195348,16400,77834,66582,75023,4194305,257,33,16385,513]

theorem envBound31955 : H12AffineFastState.Bounded env31955 := by
  intro p hp
  have h : env31955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31942_31955 : H12AffineEnvironment.transform 5 17 env31942 = env31955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31942 == env31955) = true)

theorem identity31955 : scanCanonicalize (H12AffineFastState.compose env31955 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound31955 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env31956 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8460,262,16400,9244,1025,8461,25628,4194304,17,3,8193,16,4195348,16400,12556,1296,9225,4194305,257,33,16385,513]

theorem envBound31956 : H12AffineFastState.Bounded env31956 := by
  intro p hp
  have h : env31956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31955_31956 : H12AffineEnvironment.transform 15 262 env31955 = env31956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env31955 == env31956) = true)

theorem identity31956 : scanCanonicalize (H12AffineFastState.compose env31956 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound31956 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env31957 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,16384,8460,262,16400,9244,1025,8461,25628,32,17,3,8193,16,1076,16400,12556,1296,9225,33,257,33,16385,513]

theorem envBound31957 : H12AffineFastState.Bounded env31957 := by
  intro p hp
  have h : env31957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31956_31957 : H12AffineEnvironment.transform 21 32 env31956 = env31957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env31956 == env31957) = true)

theorem identity31957 : scanCanonicalize (H12AffineFastState.compose env31957 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 9528) := by decide +kernel

theorem selectedBound31957 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31958 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,4096,8192,9528,8460,262,9512,9244,1025,8461,292,32,17,3,8193,16,1076,9512,12556,1296,9225,33,257,33,9529,513]

theorem envBound31958 : H12AffineFastState.Bounded env31958 := by
  intro p hp
  have h : env31958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31957_31958 : H12AffineEnvironment.transform 13 9528 env31957 = env31958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9528 env31957 == env31958) = true)

def env31959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,92374096,4294967296,525568,4308116845,620851225,25733062]

theorem envBound31959 : H12AffineFastState.Bounded env31959 := by
  intro p hp
  have h : env31959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9914_31959 : H12AffineEnvironment.transform 34 620851225 env9914 = env31959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 620851225 env9914 == env31959) = true)

def env31960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,536870912,1073741824,92374096,4294967296,525568,4308116845,620851225,25733062]

theorem envBound31960 : H12AffineFastState.Bounded env31960 := by
  intro p hp
  have h : env31960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31959_31960 : H12AffineEnvironment.transform 27 19497100 env31959 = env31960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497100 env31959 == env31960) = true)

def env31961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,4294967296,525568,4308116845,27337993,25733062]

theorem envBound31961 : H12AffineFastState.Bounded env31961 := by
  intro p hp
  have h : env31961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31960_31961 : H12AffineEnvironment.transform 28 77616400 env31960 = env31961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env31960 == env31961) = true)

def env31962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound31962 : H12AffineFastState.Bounded env31962 := by
  intro p hp
  have h : env31962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31961_31962 : H12AffineEnvironment.transform 31 145662400 env31961 = env31962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env31961 == env31962) = true)

def env31963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound31963 : H12AffineFastState.Bounded env31963 := by
  intro p hp
  have h : env31963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31962_31963 : H12AffineEnvironment.transform 29 155254784 env31962 = env31963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env31962 == env31963) = true)

def env31964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound31964 : H12AffineFastState.Bounded env31964 := by
  intro p hp
  have h : env31964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31963_31964 : H12AffineEnvironment.transform 25 64 env31963 = env31964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env31963 == env31964) = true)

def env31965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound31965 : H12AffineFastState.Bounded env31965 := by
  intro p hp
  have h : env31965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31964_31965 : H12AffineEnvironment.transform 26 30393344 env31964 = env31965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env31964 == env31965) = true)

def env31966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound31966 : H12AffineFastState.Bounded env31966 := by
  intro p hp
  have h : env31966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31965_31966 : H12AffineEnvironment.transform 18 1024 env31965 = env31966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env31965 == env31966) = true)

theorem identity31966 : scanCanonicalize (H12AffineFastState.compose env31966 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound31966 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env31967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21455181,18973836,2159645,418125,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound31967 : H12AffineFastState.Bounded env31967 := by
  intro p hp
  have h : env31967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31966_31967 : H12AffineEnvironment.transform 22 41293 env31966 = env31967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env31966 == env31967) = true)

def env31968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41293,16777216,8328,64,21331969,18973836,2159645,294913,16852317,23160256,256,18965984,18973764,16777867]

theorem envBound31968 : H12AffineFastState.Bounded env31968 := by
  intro p hp
  have h : env31968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31967_31968 : H12AffineEnvironment.transform 16 57676 env31967 = env31968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env31967 == env31968) = true)

theorem identity31968 : scanCanonicalize (H12AffineFastState.compose env31968 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound31968 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env31969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,262144,1024,32769,2097152,4194304,41293,138,8328,64,4554891,2196486,2159645,294913,75223,6382922,256,2188650,2196686,513]

theorem envBound31969 : H12AffineFastState.Bounded env31969 := by
  intro p hp
  have h : env31969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31968_31969 : H12AffineEnvironment.transform 23 138 env31968 = env31969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env31968 == env31969) = true)

def env31970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57676,10280,1024,32769,2097152,4194304,41293,138,8328,64,4303011,2196486,2159645,43049,75223,6382922,256,2188650,2196686,513]

theorem envBound31970 : H12AffineFastState.Bounded env31970 := by
  intro p hp
  have h : env31970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1