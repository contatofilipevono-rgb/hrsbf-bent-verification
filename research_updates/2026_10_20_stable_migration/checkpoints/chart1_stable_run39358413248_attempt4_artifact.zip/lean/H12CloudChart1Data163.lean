import H12CloudChart1Data162

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity41339 : scanCanonicalize (H12AffineFastState.compose env41339 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41339 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41340 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,1,34,5221,2048,1024,0,4160,113,16,3,40,64,2129,5220,4097,2049,1056,113,117,33,5156,513]

theorem envBound41340 : H12AffineFastState.Bounded env41340 := by
  intro p hp
  have h : env41340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41339_41340 : H12AffineEnvironment.transform 14 1 env41339 = env41340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41339 == env41340) = true)

theorem identity41340 : scanCanonicalize (H12AffineFastState.compose env41340 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound41340 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41341 : List Nat := [2,4,8,16,32,64,8,117,512,1024,512,4096,40,5237,1,34,5221,512,1024,0,4160,113,16,3,40,64,593,5220,4097,513,1056,113,117,33,5156,513]

theorem envBound41341 : H12AffineFastState.Bounded env41341 := by
  intro p hp
  have h : env41341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41340_41341 : H12AffineEnvironment.transform 10 512 env41340 = env41341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env41340 == env41341) = true)

theorem identity41341 : scanCanonicalize (H12AffineFastState.compose env41341 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound41341 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env41342 : List Nat := [2,4,8,16,32,64,8,117,512,613,512,4096,40,4624,1,34,4608,512,613,0,4160,113,16,3,40,64,593,4609,4097,513,581,113,117,33,4673,513]

theorem envBound41342 : H12AffineFastState.Bounded env41342 := by
  intro p hp
  have h : env41342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41341_41342 : H12AffineEnvironment.transform 9 613 env41341 = env41342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env41341 == env41342) = true)

theorem identity41342 : scanCanonicalize (H12AffineFastState.compose env41342 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41342 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41343 : List Nat := [2,4,8,16,32,64,8,117,512,613,512,16,40,512,1,34,528,512,613,0,80,113,16,3,40,64,593,529,17,513,581,113,117,33,593,513]

theorem envBound41343 : H12AffineFastState.Bounded env41343 := by
  intro p hp
  have h : env41343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41342_41343 : H12AffineEnvironment.transform 11 16 env41342 = env41343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41342 == env41343) = true)

theorem identity41343 : scanCanonicalize (H12AffineFastState.compose env41343 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound41343 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41344 : List Nat := [2,4,8,16,32,64,8,117,80,53,80,16,40,80,1,34,64,80,53,0,80,113,16,3,40,64,1,65,17,81,21,113,117,33,1,81]

theorem envBound41344 : H12AffineFastState.Bounded env41344 := by
  intro p hp
  have h : env41344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41343_41344 : H12AffineEnvironment.transform 8 80 env41343 = env41344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env41343 == env41344) = true)

theorem identity41344 : scanCanonicalize (H12AffineFastState.compose env41344 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41344 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41345 : List Nat := [2,4,8,16,32,17,8,36,1,53,1,16,40,1,1,34,17,1,53,0,1,32,16,3,40,17,1,16,17,0,21,32,36,33,1,0]

theorem envBound41345 : H12AffineFastState.Bounded env41345 := by
  intro p hp
  have h : env41345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41344_41345 : H12AffineEnvironment.transform 5 17 env41344 = env41345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41344 == env41345) = true)

theorem identity41345 : scanCanonicalize (H12AffineFastState.compose env41345 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41345 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41346 : List Nat := [2,4,8,0,32,1,8,36,1,37,1,0,40,1,1,34,1,1,37,0,1,32,0,3,40,1,1,0,1,0,5,32,36,33,1,0]

theorem envBound41346 : H12AffineFastState.Bounded env41346 := by
  intro p hp
  have h : env41346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41345_41346 : H12AffineEnvironment.transform 3 0 env41345 = env41346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41345 == env41346) = true)

theorem identity41346 : scanCanonicalize (H12AffineFastState.compose env41346 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41347 : List Nat := [2,4,8,0,10,1,8,14,1,15,1,0,2,1,1,8,1,1,15,0,1,10,0,3,2,1,1,0,1,0,5,10,14,11,1,0]

theorem envBound41347 : H12AffineFastState.Bounded env41347 := by
  intro p hp
  have h : env41347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41346_41347 : H12AffineEnvironment.transform 4 10 env41346 = env41347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41346 == env41347) = true)

def env41348 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56436,1024,32769,4161,4194304,16,98337,8192,64,4250709,5220,17525,23668,1057,4256860,117,21588,46093,74250]

theorem envBound41348 : H12AffineFastState.Bounded env41348 := by
  intro p hp
  have h : env41348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41334_41348 : H12AffineEnvironment.transform 20 4161 env41334 = env41348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env41334 == env41348) = true)

theorem identity41348 : scanCanonicalize (H12AffineFastState.compose env41348 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41348 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41349 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16400,56436,1024,32769,4161,4194304,16,41002,8192,64,4250709,5220,17525,23668,1057,4256860,117,21588,46093,513]

theorem envBound41349 : H12AffineFastState.Bounded env41349 := by
  intro p hp
  have h : env41349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41348_41349 : H12AffineEnvironment.transform 15 8203 env41348 = env41349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41348 == env41349) = true)

theorem identity41349 : scanCanonicalize (H12AffineFastState.compose env41349 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound41349 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41350 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34817,1024,32769,4161,4194304,16,41002,8192,64,4229152,5220,4096,2049,1057,4235305,117,33,46093,513]

theorem envBound41350 : H12AffineFastState.Bounded env41350 := by
  intro p hp
  have h : env41350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41349_41350 : H12AffineEnvironment.transform 13 5237 env41349 = env41350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env41349 == env41350) = true)

theorem identity41350 : scanCanonicalize (H12AffineFastState.compose env41350 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 3103) := by decide +kernel

theorem selectedBound41350 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env41351 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5237,32768,8203,5221,34817,1024,32769,4161,3103,16,41002,8192,64,33855,5220,4096,2049,1057,44086,117,33,46093,513]

theorem envBound41351 : H12AffineFastState.Bounded env41351 := by
  intro p hp
  have h : env41351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41350_41351 : H12AffineEnvironment.transform 21 3103 env41350 = env41351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3103 env41350 == env41351) = true)

theorem identity41351 : scanCanonicalize (H12AffineFastState.compose env41351 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41351 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env41352 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,32768,35,5221,34817,1024,32769,4161,3103,16,32770,40,64,33855,5220,4096,2049,1057,35870,117,33,37925,513]

theorem envBound41352 : H12AffineFastState.Bounded env41352 := by
  intro p hp
  have h : env41352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41351_41352 : H12AffineEnvironment.transform 12 40 env41351 = env41352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41351 == env41352) = true)

theorem identity41352 : scanCanonicalize (H12AffineFastState.compose env41352 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound41352 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41353 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5237,32768,35,5221,33903,1024,32769,4161,113,16,32770,40,64,33855,5220,4096,1135,1057,32880,117,33,37925,513]

theorem envBound41353 : H12AffineFastState.Bounded env41353 := by
  intro p hp
  have h : env41353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41352_41353 : H12AffineEnvironment.transform 10 1134 env41352 = env41353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env41352 == env41353) = true)

theorem identity41353 : scanCanonicalize (H12AffineFastState.compose env41353 (packedSelected [0,4,5,7,8,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41353 : packedSelected [0,4,5,7,8,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env41354 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1134,4096,40,5237,0,35,5221,1135,1024,1,4161,113,16,2,40,64,1087,5220,4096,1135,1057,112,117,33,5157,513]

theorem envBound41354 : H12AffineFastState.Bounded env41354 := by
  intro p hp
  have h : env41354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41353_41354 : H12AffineEnvironment.transform 14 0 env41353 = env41354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41353 == env41354) = true)

theorem identity41354 : scanCanonicalize (H12AffineFastState.compose env41354 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41354 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41355 : List Nat := [2,4,8,16,32,64,8,117,512,101,11,4096,40,4112,0,35,4096,10,101,1,4161,113,16,2,40,64,90,4097,4096,10,68,112,117,33,4160,513]

theorem envBound41355 : H12AffineFastState.Bounded env41355 := by
  intro p hp
  have h : env41355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41354_41355 : H12AffineEnvironment.transform 9 101 env41354 = env41355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41354 == env41355) = true)

theorem identity41355 : scanCanonicalize (H12AffineFastState.compose env41355 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound41355 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41356 : List Nat := [2,4,8,16,32,64,8,117,21,101,11,4096,40,4112,0,35,4096,10,101,1,4161,113,16,2,40,64,90,4097,4096,10,68,112,117,33,4160,20]

theorem envBound41356 : H12AffineFastState.Bounded env41356 := by
  intro p hp
  have h : env41356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41355_41356 : H12AffineEnvironment.transform 8 21 env41355 = env41356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env41355 == env41356) = true)

theorem identity41356 : scanCanonicalize (H12AffineFastState.compose env41356 (packedSelected [0,1,7] rootPS)) = affineNative (2^(11+1) ^^^ 12) := by decide +kernel

theorem selectedBound41356 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env41357 : List Nat := [2,4,8,16,32,64,8,117,21,101,11,12,40,28,0,35,12,10,101,1,77,113,16,2,40,64,90,13,12,10,68,112,117,33,76,20]

theorem envBound41357 : H12AffineFastState.Bounded env41357 := by
  intro p hp
  have h : env41357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41356_41357 : H12AffineEnvironment.transform 11 12 env41356 = env41357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 12 env41356 == env41357) = true)

theorem identity41357 : scanCanonicalize (H12AffineFastState.compose env41357 (packedSelected [1,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41357 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env41358 : List Nat := [2,4,4,16,32,64,4,117,21,101,7,0,36,16,0,35,0,6,101,1,65,113,16,2,36,64,86,1,0,6,68,112,117,33,64,20]

theorem envBound41358 : H12AffineFastState.Bounded env41358 := by
  intro p hp
  have h : env41358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41357_41358 : H12AffineEnvironment.transform 2 4 env41357 = env41358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41357 == env41358) = true)

theorem identity41358 : scanCanonicalize (H12AffineFastState.compose env41358 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41358 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41359 : List Nat := [2,4,4,16,0,64,4,85,21,69,7,0,4,16,0,3,0,6,69,1,65,81,16,2,4,64,86,1,0,6,68,80,85,1,64,20]

theorem envBound41359 : H12AffineFastState.Bounded env41359 := by
  intro p hp
  have h : env41359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41358_41359 : H12AffineEnvironment.transform 4 0 env41358 = env41359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41358 == env41359) = true)

theorem identity41359 : scanCanonicalize (H12AffineFastState.compose env41359 (packedSelected [1,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41359 : packedSelected [1,11] rootPS < 2^1333 := by decide +kernel

def env41360 : List Nat := [2,3,3,16,0,64,3,82,18,66,0,0,3,16,0,3,0,1,66,1,65,81,16,2,3,64,81,1,0,1,67,80,82,1,64,19]

theorem envBound41360 : H12AffineFastState.Bounded env41360 := by
  intro p hp
  have h : env41360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41359_41360 : H12AffineEnvironment.transform 1 3 env41359 = env41360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41359 == env41360) = true)

theorem identity41360 : scanCanonicalize (H12AffineFastState.compose env41360 (packedSelected [3,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41360 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env41361 : List Nat := [2,3,3,1,0,64,3,67,3,66,0,0,3,1,0,3,0,1,66,1,65,64,1,2,3,64,64,1,0,1,67,65,67,1,64,2]

theorem envBound41361 : H12AffineFastState.Bounded env41361 := by
  intro p hp
  have h : env41361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41360_41361 : H12AffineEnvironment.transform 3 1 env41360 = env41361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41360 == env41361) = true)

def env41362 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,2097152,4194304,16,2199649,8192,64,6343700,5221,2118708,23669,2102369,4256861,117,21589,46092,2175562]

theorem envBound41362 : H12AffineFastState.Bounded env41362 := by
  intro p hp
  have h : env41362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41333_41362 : H12AffineEnvironment.transform 17 56437 env41333 = env41362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env41333 == env41362) = true)

theorem identity41362 : scanCanonicalize (H12AffineFastState.compose env41362 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound41362 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env41363 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,56437,1024,32769,77899,4194304,16,41002,8192,64,4324447,5221,91263,23669,74794,4256861,117,21589,46092,513]

theorem envBound41363 : H12AffineFastState.Bounded env41363 := by
  intro p hp
  have h : env41363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41362_41363 : H12AffineEnvironment.transform 20 77899 env41362 = env41363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env41362 == env41363) = true)

theorem identity41363 : scanCanonicalize (H12AffineFastState.compose env41363 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41363 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env41364 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,65536,16400,10280,1024,29788,77899,4194304,16,21623,8192,64,4261890,5221,91263,23669,74794,4194304,117,21589,16465,513]

theorem envBound41364 : H12AffineFastState.Bounded env41364 := by
  intro p hp
  have h : env41364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41363_41364 : H12AffineEnvironment.transform 14 29789 env41363 = env41364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41363 == env41364) = true)

theorem identity41364 : scanCanonicalize (H12AffineFastState.compose env41364 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound41364 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env41365 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,8283,16400,10280,1024,29788,4112,4194304,16,21623,8192,64,4204633,5221,17444,23669,1137,4194304,117,21589,16465,513]

theorem envBound41365 : H12AffineFastState.Bounded env41365 := by
  intro p hp
  have h : env41365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41364_41365 : H12AffineEnvironment.transform 15 8283 env41364 = env41365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env41364 == env41365) = true)

theorem identity41365 : scanCanonicalize (H12AffineFastState.compose env41365 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(21+1) ^^^ 29741) := by decide +kernel

theorem selectedBound41365 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41366 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,29789,8283,16400,10280,1024,29788,4112,29741,16,21623,8192,64,23668,5221,17444,23669,1137,29741,117,21589,16465,513]

theorem envBound41366 : H12AffineFastState.Bounded env41366 := by
  intro p hp
  have h : env41366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41365_41366 : H12AffineEnvironment.transform 21 29741 env41365 = env41366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29741 env41365 == env41366) = true)

theorem identity41366 : scanCanonicalize (H12AffineFastState.compose env41366 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41366 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41367 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,16384,21621,115,16400,2048,1024,21620,4112,21509,16,21623,40,64,23668,5221,17444,23669,1137,21509,117,21589,16465,513]

theorem envBound41367 : H12AffineFastState.Bounded env41367 := by
  intro p hp
  have h : env41367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41366_41367 : H12AffineEnvironment.transform 12 40 env41366 = env41367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41366 == env41367) = true)

theorem identity41367 : scanCanonicalize (H12AffineFastState.compose env41367 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41367 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41368 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,16384,21540,34,16400,2048,1024,21541,4112,21509,16,21542,40,17,23589,5172,17444,23588,1056,21509,36,21508,16384,513]

theorem envBound41368 : H12AffineFastState.Bounded env41368 := by
  intro p hp
  have h : env41368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41367_41368 : H12AffineEnvironment.transform 5 17 env41367 = env41368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41367 == env41368) = true)

theorem identity41368 : scanCanonicalize (H12AffineFastState.compose env41368 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound41368 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41369 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,34,5173,2048,1024,0,4112,32,16,3,40,17,2048,5172,4097,2049,1056,32,36,33,5157,513]

theorem envBound41369 : H12AffineFastState.Bounded env41369 := by
  intro p hp
  have h : env41369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41368_41369 : H12AffineEnvironment.transform 13 5157 env41368 = env41369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env41368 == env41369) = true)

theorem identity41369 : scanCanonicalize (H12AffineFastState.compose env41369 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41370 : List Nat := [2,4,8,1,32,0,8,36,512,1024,2048,4096,40,5157,1,34,5156,2048,1024,0,4097,32,1,3,40,0,2048,5157,4097,2049,1056,32,36,33,5157,513]

theorem envBound41370 : H12AffineFastState.Bounded env41370 := by
  intro p hp
  have h : env41370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41369_41370 : H12AffineEnvironment.transform 3 1 env41369 = env41370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41369 == env41370) = true)

theorem identity41370 : scanCanonicalize (H12AffineFastState.compose env41370 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound41370 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41371 : List Nat := [2,4,8,1,32,0,8,36,512,1024,2048,513,40,1572,1,34,1573,2048,1024,0,512,32,1,3,40,0,2048,1572,512,2049,1056,32,36,33,1572,513]

theorem envBound41371 : H12AffineFastState.Bounded env41371 := by
  intro p hp
  have h : env41371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41370_41371 : H12AffineEnvironment.transform 11 513 env41370 = env41371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env41370 == env41371) = true)

theorem identity41371 : scanCanonicalize (H12AffineFastState.compose env41371 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41371 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41372 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1,513,40,1572,1,34,1573,1,1024,0,512,32,1,3,40,0,1,1572,512,0,1056,32,36,33,1572,513]

theorem envBound41372 : H12AffineFastState.Bounded env41372 := by
  intro p hp
  have h : env41372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41371_41372 : H12AffineEnvironment.transform 10 1 env41371 = env41372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41371 == env41372) = true)

theorem identity41372 : scanCanonicalize (H12AffineFastState.compose env41372 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound41372 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41373 : List Nat := [2,4,8,1,32,0,8,36,512,36,1,513,40,512,1,34,513,1,36,0,512,32,1,3,40,0,1,512,512,0,4,32,36,33,512,513]

theorem envBound41373 : H12AffineFastState.Bounded env41373 := by
  intro p hp
  have h : env41373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41372_41373 : H12AffineEnvironment.transform 9 36 env41372 = env41373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env41372 == env41373) = true)

theorem identity41373 : scanCanonicalize (H12AffineFastState.compose env41373 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41373 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41374 : List Nat := [2,4,8,1,0,0,8,4,512,4,1,513,8,512,1,2,513,1,4,0,512,0,1,3,8,0,1,512,512,0,4,0,4,1,512,513]

theorem envBound41374 : H12AffineFastState.Bounded env41374 := by
  intro p hp
  have h : env41374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41373_41374 : H12AffineEnvironment.transform 4 0 env41373 = env41374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41373 == env41374) = true)

theorem identity41374 : scanCanonicalize (H12AffineFastState.compose env41374 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41375 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,8,1,1,2,0,1,4,0,1,0,1,3,8,0,1,1,1,0,4,0,4,1,1,0]

theorem envBound41375 : H12AffineFastState.Bounded env41375 := by
  intro p hp
  have h : env41375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41374_41375 : H12AffineEnvironment.transform 8 1 env41374 = env41375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41374 == env41375) = true)

def env41376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,17,16777216,8192,64,21331968,18973700,2118976,294912,16876545,23160137,256,18990133,18949401,16819039]

theorem envBound41376 : H12AffineFastState.Bounded env41376 := by
  intro p hp
  have h : env41376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41289_41376 : H12AffineEnvironment.transform 16 16401 env41289 = env41376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41289 == env41376) = true)

theorem identity41376 : scanCanonicalize (H12AffineFastState.compose env41376 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41376 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env41377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080104,18973700,2118976,43048,16876545,23160137,256,18990133,18949401,16819039]

theorem envBound41377 : H12AffineFastState.Bounded env41377 := by
  intro p hp
  have h : env41377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41376_41377 : H12AffineEnvironment.transform 17 10280 env41376 = env41377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41376 == env41377) = true)

def env41378 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080104,18973700,2118708,43048,16876545,23159869,116,18990133,18949229,16818731]

theorem envBound41378 : H12AffineFastState.Bounded env41378 := by
  intro p hp
  have h : env41378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41377_41378 : H12AffineEnvironment.transform 7 116 env41377 = env41378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41377 == env41378) = true)

theorem identity41378 : scanCanonicalize (H12AffineFastState.compose env41378 (packedSelected [3,4,9,10,14,16,17,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 2212918) := by decide +kernel

theorem selectedBound41378 : packedSelected [3,4,9,10,14,16,17,24,26] rootPS < 2^1333 := by decide +kernel

def env41379 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,2212918,17,16777216,8192,64,18902046,18973700,2118708,43048,16876545,16818187,116,18990133,18949229,16818731]

theorem envBound41379 : H12AffineFastState.Bounded env41379 := by
  intro p hp
  have h : env41379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41378_41379 : H12AffineEnvironment.transform 21 2212918 env41378 = env41379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2212918 env41378 == env41379) = true)

theorem identity41379 : scanCanonicalize (H12AffineFastState.compose env41379 (packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41379 : packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env41380 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,2155581,17,16777216,8192,64,18902046,18916367,2118708,43048,16819210,16818187,116,18932798,18875494,16818731]

theorem envBound41380 : H12AffineFastState.Bounded env41380 := by
  intro p hp
  have h : env41380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41379_41380 : H12AffineEnvironment.transform 15 8203 env41379 = env41380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41379 == env41380) = true)

theorem identity41380 : scanCanonicalize (H12AffineFastState.compose env41380 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 2155599) := by decide +kernel

theorem selectedBound41380 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env41381 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,2155581,17,2155599,8192,64,34897,16448,2118708,43048,2113605,2114628,116,113,57385,2115172]

theorem envBound41381 : H12AffineFastState.Bounded env41381 := by
  intro p hp
  have h : env41381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41380_41381 : H12AffineEnvironment.transform 23 2155599 env41380 = env41381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2155599 env41380 == env41381) = true)

theorem identity41381 : scanCanonicalize (H12AffineFastState.compose env41381 (packedSelected [0,1,2,5,6,7,8,11,16,17,18,24] rootPS)) = affineNative (2^(20+1) ^^^ 58445) := by decide +kernel

theorem selectedBound41381 : packedSelected [0,1,2,5,6,7,8,11,16,17,18,24] rootPS < 2^1333 := by decide +kernel

def env41382 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,58445,112,17,2,8192,64,34897,16448,45177,43048,41992,40969,116,113,57385,41513]

theorem envBound41382 : H12AffineFastState.Bounded env41382 := by
  intro p hp
  have h : env41382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41381_41382 : H12AffineEnvironment.transform 20 58445 env41381 = env41382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58445 env41381 == env41382) = true)

theorem identity41382 : scanCanonicalize (H12AffineFastState.compose env41382 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41382 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41383 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,1,8203,16401,10280,1024,0,25676,112,17,2,8192,64,2128,16448,12408,10281,9225,8200,116,113,24616,8744]

theorem envBound41383 : H12AffineFastState.Bounded env41383 := by
  intro p hp
  have h : env41383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41382_41383 : H12AffineEnvironment.transform 14 1 env41382 = env41383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41382 == env41383) = true)

def env41384 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,16777216,8192,64,21080104,18973700,2118709,43048,16876545,23159868,117,18990133,18949228,16818730]

theorem envBound41384 : H12AffineFastState.Bounded env41384 := by
  intro p hp
  have h : env41384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41377_41384 : H12AffineEnvironment.transform 7 117 env41377 = env41384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41377 == env41384) = true)

theorem identity41384 : scanCanonicalize (H12AffineFastState.compose env41384 (packedSelected [3,4,9,10,14,16,17,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 6382621) := by decide +kernel

theorem selectedBound41384 : packedSelected [3,4,9,10,14,16,17,24,26] rootPS < 2^1333 := by decide +kernel

def env41385 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,2097152,4194304,17,6382621,8192,64,2149429,4251673,2118709,43048,6348828,33,117,4235304,4210801,6407735]

theorem envBound41385 : H12AffineFastState.Bounded env41385 := by
  intro p hp
  have h : env41385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41384_41385 : H12AffineEnvironment.transform 23 6382621 env41384 = env41385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6382621 env41384 == env41385) = true)

theorem identity41385 : scanCanonicalize (H12AffineFastState.compose env41385 (packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41385 : packedSelected [0,1,3,4,5,7,8,10,11,16,17,18,19,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env41386 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,4194304,17,6308886,8192,64,2149429,4251673,2118709,43048,6348828,33,117,4235304,4210801,6350396]

theorem envBound41386 : H12AffineFastState.Bounded env41386 := by
  intro p hp
  have h : env41386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41385_41386 : H12AffineEnvironment.transform 15 8203 env41385 = env41386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41385 == env41386) = true)

theorem identity41386 : scanCanonicalize (H12AffineFastState.compose env41386 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41049) := by decide +kernel

theorem selectedBound41386 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env41387 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,2097152,41049,17,2155599,8192,64,2149429,16448,2118709,43048,2113605,33,117,113,57384,2115173]

theorem envBound41387 : H12AffineFastState.Bounded env41387 := by
  intro p hp
  have h : env41387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41386_41387 : H12AffineEnvironment.transform 21 41049 env41386 = env41387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41049 env41386 == env41387) = true)

theorem identity41387 : scanCanonicalize (H12AffineFastState.compose env41387 (packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS)) = affineNative (2^(20+1) ^^^ 58445) := by decide +kernel

theorem selectedBound41387 : packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS < 2^1333 := by decide +kernel

def env41388 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1024,32769,58445,41049,17,2,8192,64,10360,16448,45176,43048,41992,33,117,113,57384,41512]

theorem envBound41388 : H12AffineFastState.Bounded env41388 := by
  intro p hp
  have h : env41388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41387_41388 : H12AffineEnvironment.transform 20 58445 env41387 = env41388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58445 env41387 == env41388) = true)

theorem identity41388 : scanCanonicalize (H12AffineFastState.compose env41388 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41388 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41389 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,1,8203,16401,10280,1024,0,25676,8280,17,2,8192,64,10360,16448,12409,10281,9225,33,117,113,24617,8745]

theorem envBound41389 : H12AffineFastState.Bounded env41389 := by
  intro p hp
  have h : env41389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41388_41389 : H12AffineEnvironment.transform 14 1 env41388 = env41389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41388 == env41389) = true)

theorem identity41389 : scanCanonicalize (H12AffineFastState.compose env41389 (packedSelected [3,4,5,9,10,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41389 : packedSelected [3,4,5,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41390 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,41,16384,1,34,16401,2049,1024,0,17509,113,17,2,41,64,2129,16448,4176,2048,1056,33,117,113,16384,512]

theorem envBound41390 : H12AffineFastState.Bounded env41390 := by
  intro p hp
  have h : env41390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41389_41390 : H12AffineEnvironment.transform 12 41 env41389 = env41390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41389 == env41390) = true)

theorem identity41390 : scanCanonicalize (H12AffineFastState.compose env41390 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound41390 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41391 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,41,16384,1,34,16401,2049,1024,0,17429,1,17,2,41,48,2081,16432,4128,2048,1056,33,5,1,16384,512]

theorem envBound41391 : H12AffineFastState.Bounded env41391 := by
  intro p hp
  have h : env41391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41390_41391 : H12AffineEnvironment.transform 5 48 env41390 = env41391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env41390 == env41391) = true)

theorem identity41391 : scanCanonicalize (H12AffineFastState.compose env41391 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6714) := by decide +kernel

theorem selectedBound41391 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41392 : List Nat := [2,4,8,16,32,48,8,5,512,1024,2048,4096,41,6714,1,34,6699,2049,1024,0,7727,1,17,2,41,48,2081,6666,4128,2048,1056,33,5,1,6714,512]

theorem envBound41392 : H12AffineFastState.Bounded env41392 := by
  intro p hp
  have h : env41392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41391_41392 : H12AffineEnvironment.transform 13 6714 env41391 = env41392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6714 env41391 == env41392) = true)

theorem identity41392 : scanCanonicalize (H12AffineFastState.compose env41392 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound41392 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41393 : List Nat := [2,4,8,16,32,48,8,5,512,1024,1566,4096,41,5156,1,34,5173,1567,1024,0,4145,1,17,2,41,48,1599,5140,4128,1566,1056,33,5,1,5156,512]

theorem envBound41393 : H12AffineFastState.Bounded env41393 := by
  intro p hp
  have h : env41393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41392_41393 : H12AffineEnvironment.transform 10 1566 env41392 = env41393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env41392 == env41393) = true)

theorem identity41393 : scanCanonicalize (H12AffineFastState.compose env41393 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41394 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1566,4096,8,5125,1,3,5140,1567,1024,0,4112,1,17,2,8,17,1566,5140,4097,1566,1025,0,5,1,5125,512]

theorem envBound41394 : H12AffineFastState.Bounded env41394 := by
  intro p hp
  have h : env41394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41393_41394 : H12AffineEnvironment.transform 4 1 env41393 = env41394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41393 == env41394) = true)

theorem identity41394 : scanCanonicalize (H12AffineFastState.compose env41394 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound41394 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41395 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1566,16,8,1045,1,3,1028,1567,1024,0,0,1,17,2,8,17,1566,1028,17,1566,1025,0,5,1,1045,512]

theorem envBound41395 : H12AffineFastState.Bounded env41395 := by
  intro p hp
  have h : env41395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41394_41395 : H12AffineEnvironment.transform 11 16 env41394 = env41395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env41394 == env41395) = true)

theorem identity41395 : scanCanonicalize (H12AffineFastState.compose env41395 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 26) := by decide +kernel

theorem selectedBound41395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41396 : List Nat := [2,4,8,16,1,17,8,5,512,26,516,16,8,15,1,3,30,517,26,0,0,1,17,2,8,17,516,30,17,516,27,0,5,1,15,512]

theorem envBound41396 : H12AffineFastState.Bounded env41396 := by
  intro p hp
  have h : env41396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41395_41396 : H12AffineEnvironment.transform 9 26 env41395 = env41396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 26 env41395 == env41396) = true)

theorem identity41396 : scanCanonicalize (H12AffineFastState.compose env41396 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound41396 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41397 : List Nat := [2,4,8,16,1,17,8,5,14,26,10,16,8,15,1,3,30,11,26,0,0,1,17,2,8,17,10,30,17,10,27,0,5,1,15,14]

theorem envBound41397 : H12AffineFastState.Bounded env41397 := by
  intro p hp
  have h : env41397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41396_41397 : H12AffineEnvironment.transform 8 14 env41396 = env41397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env41396 == env41397) = true)

theorem identity41397 : scanCanonicalize (H12AffineFastState.compose env41397 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound41397 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41398 : List Nat := [2,4,8,4,1,5,8,5,14,14,10,4,8,15,1,3,10,11,14,0,0,1,5,2,8,5,10,10,5,10,15,0,5,1,15,14]

theorem envBound41398 : H12AffineFastState.Bounded env41398 := by
  intro p hp
  have h : env41398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41397_41398 : H12AffineEnvironment.transform 3 4 env41397 = env41398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env41397 == env41398) = true)

theorem identity41398 : scanCanonicalize (H12AffineFastState.compose env41398 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41398 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env41399 : List Nat := [2,0,8,0,1,1,8,1,10,10,10,0,8,11,1,3,10,11,10,0,0,1,1,2,8,1,10,10,1,10,11,0,1,1,11,10]

theorem envBound41399 : H12AffineFastState.Bounded env41399 := by
  intro p hp
  have h : env41399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41398_41399 : H12AffineEnvironment.transform 1 0 env41398 = env41399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41398 == env41399) = true)

theorem identity41399 : scanCanonicalize (H12AffineFastState.compose env41399 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41400 : List Nat := [1,0,8,0,1,1,8,1,9,9,9,0,8,8,1,0,9,8,9,0,0,1,1,1,8,1,9,9,1,9,8,0,1,1,8,9]

theorem envBound41400 : H12AffineFastState.Bounded env41400 := by
  intro p hp
  have h : env41400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41399_41400 : H12AffineEnvironment.transform 0 1 env41399 = env41400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41399 == env41400) = true)

def env41401 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,16777216,8192,64,21331969,18973700,2233680,294913,17024017,23160137,256,19104805,19096841,16966479]

theorem envBound41401 : H12AffineFastState.Bounded env41401 := by
  intro p hp
  have h : env41401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41288_41401 : H12AffineEnvironment.transform 22 147457 env41288 = env41401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env41288 == env41401) = true)

theorem identity41401 : scanCanonicalize (H12AffineFastState.compose env41401 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188750) := by decide +kernel

theorem selectedBound41401 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env41402 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,188750,8192,64,4677967,2319690,2233680,294913,75103,6521863,256,2188651,2196551,513]

theorem envBound41402 : H12AffineFastState.Bounded env41402 := by
  intro p hp
  have h : env41402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41401_41402 : H12AffineEnvironment.transform 23 188750 env41401 = env41402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188750 env41401 == env41402) = true)

def env41403 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,41310,8192,64,4530527,2172250,2118976,294913,75103,6407191,256,2188651,2196551,513]

theorem envBound41403 : H12AffineFastState.Bounded env41403 := by
  intro p hp
  have h : env41403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41402_41403 : H12AffineEnvironment.transform 16 16400 env41402 = env41403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41402 == env41403) = true)

theorem identity41403 : scanCanonicalize (H12AffineFastState.compose env41403 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41403 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2098512,2118976,294913,1365,6349853,256,2114913,2139213,513]

theorem envBound41404 : H12AffineFastState.Bounded env41404 := by
  intro p hp
  have h : env41404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41403_41404 : H12AffineEnvironment.transform 15 8202 env41403 = env41404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41403 == env41404) = true)

theorem identity41404 : scanCanonicalize (H12AffineFastState.compose env41404 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound41404 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,2097152,32,17,41310,8192,64,262517,2098512,2118976,294913,1365,2155581,256,2114913,2139213,513]

theorem envBound41405 : H12AffineFastState.Bounded env41405 := by
  intro p hp
  have h : env41405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41404_41405 : H12AffineEnvironment.transform 21 32 env41404 = env41405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env41404 == env41405) = true)

theorem identity41405 : scanCanonicalize (H12AffineFastState.compose env41405 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41405 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,262144,1024,8541,2097152,32,17,2,8192,64,262517,2098512,2118976,270685,1365,2114913,256,2114913,2098449,513]

theorem envBound41406 : H12AffineFastState.Bounded env41406 := by
  intro p hp
  have h : env41406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41405_41406 : H12AffineEnvironment.transform 14 8540 env41405 = env41406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41405 == env41406) = true)

theorem identity41406 : scanCanonicalize (H12AffineFastState.compose env41406 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41406 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41407 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,262144,1024,8460,2097152,32,17,2,8192,17,262436,2098433,2118929,270604,1284,2114864,256,2114864,2098449,513]

theorem envBound41407 : H12AffineFastState.Bounded env41407 := by
  intro p hp
  have h : env41407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41406_41407 : H12AffineEnvironment.transform 5 17 env41406 = env41407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41406 == env41407) = true)

theorem identity41407 : scanCanonicalize (H12AffineFastState.compose env41407 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound41407 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41408 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10280,1024,8460,2097152,32,17,2,8192,17,10508,2098433,2118929,2340,1284,2114864,256,2114864,2098449,513]

theorem envBound41408 : H12AffineFastState.Bounded env41408 := by
  intro p hp
  have h : env41408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41407_41408 : H12AffineEnvironment.transform 17 10280 env41407 = env41408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41407 == env41408) = true)

theorem identity41408 : scanCanonicalize (H12AffineFastState.compose env41408 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 26665) := by decide +kernel

theorem selectedBound41408 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41409 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,10280,1024,8460,26665,32,17,2,8192,17,10508,27944,15672,2340,1284,11545,256,11545,27960,513]

theorem envBound41409 : H12AffineFastState.Bounded env41409 := by
  intro p hp
  have h : env41409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41408_41409 : H12AffineEnvironment.transform 20 26665 env41408 = env41409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26665 env41408 == env41409) = true)

theorem identity41409 : scanCanonicalize (H12AffineFastState.compose env41409 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound41409 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41410 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,8192,16384,8461,8202,16400,9528,1024,8460,25913,32,17,2,8192,17,9244,24632,12328,1076,1284,8201,256,8201,24616,513]

theorem envBound41410 : H12AffineFastState.Bounded env41410 := by
  intro p hp
  have h : env41410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41409_41410 : H12AffineEnvironment.transform 10 1296 env41409 = env41410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env41409 == env41410) = true)

theorem identity41410 : scanCanonicalize (H12AffineFastState.compose env41410 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41410 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41411 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,40,16384,293,34,16400,1296,1024,292,17681,32,17,2,40,17,1076,16400,4096,1076,1284,33,256,33,16384,513]

theorem envBound41411 : H12AffineFastState.Bounded env41411 := by
  intro p hp
  have h : env41411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41410_41411 : H12AffineEnvironment.transform 12 40 env41410 = env41411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41410 == env41411) = true)

theorem identity41411 : scanCanonicalize (H12AffineFastState.compose env41411 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound41411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41412 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,40,1297,293,34,1281,1296,1024,292,0,32,17,2,40,17,1076,1281,4096,1076,1284,33,256,33,1297,513]

theorem envBound41412 : H12AffineFastState.Bounded env41412 := by
  intro p hp
  have h : env41412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41411_41412 : H12AffineEnvironment.transform 13 1297 env41411 = env41412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41411 == env41412) = true)

theorem identity41412 : scanCanonicalize (H12AffineFastState.compose env41412 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound41412 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41413 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,309,40,1297,293,34,1281,1296,1024,292,0,32,17,2,40,17,1076,1281,309,1076,1284,33,256,33,1297,513]

theorem envBound41413 : H12AffineFastState.Bounded env41413 := by
  intro p hp
  have h : env41413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41412_41413 : H12AffineEnvironment.transform 11 309 env41412 = env41413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env41412 == env41413) = true)

theorem identity41413 : scanCanonicalize (H12AffineFastState.compose env41413 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41413 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41414 : List Nat := [2,4,8,16,32,17,8,256,512,273,1,309,40,0,293,34,16,1,273,292,0,32,17,2,40,17,293,16,309,293,21,33,256,33,0,513]

theorem envBound41414 : H12AffineFastState.Bounded env41414 := by
  intro p hp
  have h : env41414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41413_41414 : H12AffineEnvironment.transform 9 273 env41413 = env41414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41413 == env41414) = true)

def env41415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41311,8192,64,4530526,2172251,2118977,294913,75103,6407190,256,2188651,2196551,513]

theorem envBound41415 : H12AffineFastState.Bounded env41415 := by
  intro p hp
  have h : env41415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41402_41415 : H12AffineEnvironment.transform 16 16401 env41402 = env41415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env41402 == env41415) = true)

def env41416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41311,8192,64,4530526,115015,45405,294913,75103,4268042,256,98679,90203,513]

theorem envBound41416 : H12AffineFastState.Bounded env41416 := by
  intro p hp
  have h : env41416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41415_41416 : H12AffineEnvironment.transform 20 58396 env41415 = env41416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env41415 == env41416) = true)

def env41417 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41231,8192,16,4530446,114967,45325,294913,75023,4268042,256,98599,90123,513]

theorem envBound41417 : H12AffineFastState.Bounded env41417 := by
  intro p hp
  have h : env41417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41416_41417 : H12AffineEnvironment.transform 5 16 env41416 = env41417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41416 == env41417) = true)

theorem identity41417 : scanCanonicalize (H12AffineFastState.compose env41417 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272392) := by decide +kernel

theorem selectedBound41417 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env41418 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,272392,16,41231,8192,16,67846,114967,45325,294913,75023,329730,256,98599,90123,513]

theorem envBound41418 : H12AffineFastState.Bounded env41418 := by
  intro p hp
  have h : env41418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41417_41418 : H12AffineEnvironment.transform 21 272392 env41417 = env41418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272392 env41417 == env41418) = true)

theorem identity41418 : scanCanonicalize (H12AffineFastState.compose env41418 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound41418 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env41419 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16401,262144,1024,32769,58396,272392,16,41231,8192,16,34817,16400,45325,294913,41992,297221,256,32,57612,513]

theorem envBound41419 : H12AffineFastState.Bounded env41419 := by
  intro p hp
  have h : env41419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41418_41419 : H12AffineEnvironment.transform 15 33031 env41418 = env41419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env41418 == env41419) = true)

theorem identity41419 : scanCanonicalize (H12AffineFastState.compose env41419 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound41419 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41420 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,16401,2341,1024,32769,58396,8493,16,41231,8192,16,34817,16400,45325,35108,41992,32800,256,32,57612,513]

theorem envBound41420 : H12AffineFastState.Bounded env41420 := by
  intro p hp
  have h : env41420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41419_41420 : H12AffineEnvironment.transform 17 2341 env41419 = env41420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env41419 == env41420) = true)

theorem identity41420 : scanCanonicalize (H12AffineFastState.compose env41420 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41420 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41421 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,33031,16401,2341,1024,32769,50449,32,16,32770,269,16,34817,16400,36864,35108,34053,32800,256,32,49153,513]

theorem envBound41421 : H12AffineFastState.Bounded env41421 := by
  intro p hp
  have h : env41421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41420_41421 : H12AffineEnvironment.transform 12 269 env41420 = env41421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41420 == env41421) = true)

def env41422 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,4194304,16,41230,8192,17,4530447,114966,45324,294913,75022,4268042,256,98598,90122,513]

theorem envBound41422 : H12AffineFastState.Bounded env41422 := by
  intro p hp
  have h : env41422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41416_41422 : H12AffineEnvironment.transform 5 17 env41416 = env41422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41416 == env41422) = true)

theorem identity41422 : scanCanonicalize (H12AffineFastState.compose env41422 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329730) := by decide +kernel

theorem selectedBound41422 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env41423 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58396,329730,16,41230,8192,17,10509,114966,45324,294913,75022,272392,256,98598,90122,513]

theorem envBound41423 : H12AffineFastState.Bounded env41423 := by
  intro p hp
  have h : env41423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41422_41423 : H12AffineEnvironment.transform 21 329730 env41422 = env41423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329730 env41422 == env41423) = true)

theorem identity41423 : scanCanonicalize (H12AffineFastState.compose env41423 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound41423 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env41424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,43049,1024,32769,58396,106539,16,41230,8192,17,10509,114966,45324,10280,75022,32801,256,98598,90122,513]

theorem envBound41424 : H12AffineFastState.Bounded env41424 := by
  intro p hp
  have h : env41424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41423_41424 : H12AffineEnvironment.transform 17 43049 env41423 = env41424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env41423 == env41424) = true)

theorem identity41424 : scanCanonicalize (H12AffineFastState.compose env41424 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound41424 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env41425 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,43049,1024,32769,58396,33,16,41230,8192,17,10509,24860,45324,10280,34052,32801,256,8492,49152,513]

theorem envBound41425 : H12AffineFastState.Bounded env41425 := by
  intro p hp
  have h : env41425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41424_41425 : H12AffineEnvironment.transform 15 40970 env41424 = env41425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env41424 == env41425) = true)

theorem identity41425 : scanCanonicalize (H12AffineFastState.compose env41425 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound41425 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41426 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,33031,16401,35108,1024,32769,50449,33,16,32771,269,17,2048,16401,36865,2341,34052,32801,256,33,49152,513]

theorem envBound41426 : H12AffineFastState.Bounded env41426 := by
  intro p hp
  have h : env41426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41425_41426 : H12AffineEnvironment.transform 12 269 env41425 = env41426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env41425 == env41426) = true)

theorem identity41426 : scanCanonicalize (H12AffineFastState.compose env41426 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 18725) := by decide +kernel

theorem selectedBound41426 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41427 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,18725,18466,16401,16385,1024,18724,3124,33,16,18726,269,17,2048,16401,22820,2341,19489,18692,256,33,2341,513]

theorem envBound41427 : H12AffineFastState.Bounded env41427 := by
  intro p hp
  have h : env41427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41426_41427 : H12AffineEnvironment.transform 14 18725 env41426 = env41427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18725 env41426 == env41427) = true)

theorem identity41427 : scanCanonicalize (H12AffineFastState.compose env41427 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41427 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env41428 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,16384,18432,18466,16401,16385,1024,18433,3124,33,16,18435,40,17,2048,16401,22529,2048,19489,18465,37,33,2048,513]

theorem envBound41428 : H12AffineFastState.Bounded env41428 := by
  intro p hp
  have h : env41428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41427_41428 : H12AffineEnvironment.transform 7 37 env41427 = env41428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41427 == env41428) = true)

theorem identity41428 : scanCanonicalize (H12AffineFastState.compose env41428 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41428 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env41429 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,16384,18432,18466,16401,16385,53,18433,2049,33,16,18435,40,17,2048,16401,22529,2048,18452,18465,37,33,2048,513]

theorem envBound41429 : H12AffineFastState.Bounded env41429 := by
  intro p hp
  have h : env41429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41428_41429 : H12AffineEnvironment.transform 9 53 env41428 = env41429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41428 == env41429) = true)

theorem identity41429 : scanCanonicalize (H12AffineFastState.compose env41429 (packedSelected [2,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound41429 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env41430 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,2048,0,34,2065,2049,53,1,2049,33,16,3,40,17,2048,2065,4097,2048,20,33,37,33,2048,513]

theorem envBound41430 : H12AffineFastState.Bounded env41430 := by
  intro p hp
  have h : env41430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41429_41430 : H12AffineEnvironment.transform 13 2048 env41429 = env41430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env41429 == env41430) = true)

theorem identity41430 : scanCanonicalize (H12AffineFastState.compose env41430 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41430 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41431 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,4096,40,1,0,34,16,0,53,1,0,33,16,3,40,17,1,16,4097,1,20,33,37,33,1,513]

theorem envBound41431 : H12AffineFastState.Bounded env41431 := by
  intro p hp
  have h : env41431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41430_41431 : H12AffineEnvironment.transform 10 1 env41430 = env41431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41430 == env41431) = true)

theorem identity41431 : scanCanonicalize (H12AffineFastState.compose env41431 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41431 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41432 : List Nat := [2,4,8,16,32,17,8,37,10,53,1,4096,40,1,0,34,16,0,53,1,0,33,16,3,40,17,1,16,4097,1,20,33,37,33,1,11]

theorem envBound41432 : H12AffineFastState.Bounded env41432 := by
  intro p hp
  have h : env41432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41431_41432 : H12AffineEnvironment.transform 8 10 env41431 = env41432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41431 == env41432) = true)

theorem identity41432 : scanCanonicalize (H12AffineFastState.compose env41432 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41432 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41433 : List Nat := [2,4,8,16,1,17,8,4,10,20,1,4096,9,1,0,3,16,0,20,1,0,0,16,3,9,17,1,16,4097,1,20,0,4,0,1,11]

theorem envBound41433 : H12AffineFastState.Bounded env41433 := by
  intro p hp
  have h : env41433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41432_41433 : H12AffineEnvironment.transform 4 1 env41432 = env41433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41432 == env41433) = true)

theorem identity41433 : scanCanonicalize (H12AffineFastState.compose env41433 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41433 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41434 : List Nat := [2,4,8,16,1,17,8,4,10,20,1,17,9,1,0,3,16,0,20,1,0,0,16,3,9,17,1,16,16,1,20,0,4,0,1,11]

theorem envBound41434 : H12AffineFastState.Bounded env41434 := by
  intro p hp
  have h : env41434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41433_41434 : H12AffineEnvironment.transform 11 17 env41433 = env41434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41433 == env41434) = true)

theorem identity41434 : scanCanonicalize (H12AffineFastState.compose env41434 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound41434 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41435 : List Nat := [2,4,7,16,1,17,7,4,5,20,1,17,6,1,0,3,16,0,20,1,0,0,16,3,6,17,1,16,16,1,20,0,4,0,1,4]

theorem envBound41435 : H12AffineFastState.Bounded env41435 := by
  intro p hp
  have h : env41435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41434_41435 : H12AffineEnvironment.transform 2 7 env41434 = env41435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env41434 == env41435) = true)

theorem identity41435 : scanCanonicalize (H12AffineFastState.compose env41435 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound41435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41436 : List Nat := [2,4,7,2,1,3,7,4,5,6,1,3,6,1,0,3,2,0,6,1,0,0,2,3,6,3,1,2,2,1,6,0,4,0,1,4]

theorem envBound41436 : H12AffineFastState.Bounded env41436 := by
  intro p hp
  have h : env41436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41435_41436 : H12AffineEnvironment.transform 3 2 env41435 = env41436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env41435 == env41436) = true)

def env41437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,58397,4194304,16,41311,8192,64,4530526,115014,45404,294913,75103,4268043,256,98678,90202,513]

theorem envBound41437 : H12AffineFastState.Bounded env41437 := by
  intro p hp
  have h : env41437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41415_41437 : H12AffineEnvironment.transform 20 58397 env41415 = env41437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env41415 == env41437) = true)

theorem identity41437 : scanCanonicalize (H12AffineFastState.compose env41437 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41437 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58397,4194304,16,41311,8192,64,4456789,57677,45404,294913,1364,4194304,256,41341,16465,513]

theorem envBound41438 : H12AffineFastState.Bounded env41438 := by
  intro p hp
  have h : env41438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41437_41438 : H12AffineEnvironment.transform 15 8203 env41437 = env41438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41437 == env41438) = true)

theorem identity41438 : scanCanonicalize (H12AffineFastState.compose env41438 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272472) := by decide +kernel

theorem selectedBound41438 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env41439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,58397,272472,16,41311,8192,64,10509,57677,45404,294913,1364,272472,256,41341,16465,513]

theorem envBound41439 : H12AffineFastState.Bounded env41439 := by
  intro p hp
  have h : env41439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41438_41439 : H12AffineEnvironment.transform 21 272472 env41438 = env41439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272472 env41438 == env41439) = true)

theorem identity41439 : scanCanonicalize (H12AffineFastState.compose env41439 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41439 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env41440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16401,262144,1024,32769,50497,264452,16,32771,348,64,2129,49169,36864,294913,1364,264452,256,32801,16465,513]

theorem envBound41440 : H12AffineFastState.Bounded env41440 := by
  intro p hp
  have h : env41440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41439_41440 : H12AffineEnvironment.transform 12 348 env41439 = env41440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41439 == env41440) = true)

theorem identity41440 : scanCanonicalize (H12AffineFastState.compose env41440 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41440 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41441 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16401,262144,1024,32769,50448,264452,16,32771,269,17,2048,49169,36864,294913,1285,264452,256,32801,16384,513]

theorem envBound41441 : H12AffineFastState.Bounded env41441 := by
  intro p hp
  have h : env41441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41440_41441 : H12AffineEnvironment.transform 5 17 env41440 = env41441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41440 == env41441) = true)

theorem identity41441 : scanCanonicalize (H12AffineFastState.compose env41441 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound41441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41442 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16401,35108,1024,32769,50448,32800,16,32771,269,17,2048,49169,36864,2341,1285,32800,256,32801,16384,513]

theorem envBound41442 : H12AffineFastState.Bounded env41442 := by
  intro p hp
  have h : env41442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41441_41442 : H12AffineEnvironment.transform 17 35108 env41441 = env41442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env41441 == env41442) = true)

theorem identity41442 : scanCanonicalize (H12AffineFastState.compose env41442 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41442 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41443 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1024,0,17681,33,16,2,269,17,2048,16400,4097,2341,1285,33,256,32,16384,513]

theorem envBound41443 : H12AffineFastState.Bounded env41443 := by
  intro p hp
  have h : env41443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41442_41443 : H12AffineEnvironment.transform 14 1 env41442 = env41443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41442 == env41443) = true)

theorem identity41443 : scanCanonicalize (H12AffineFastState.compose env41443 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound41443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41444 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5157,1,262,5172,2341,1024,0,4404,33,16,2,269,17,2048,5173,4097,2341,1285,33,256,32,5157,513]

theorem envBound41444 : H12AffineFastState.Bounded env41444 := by
  intro p hp
  have h : env41444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41443_41444 : H12AffineEnvironment.transform 13 5157 env41443 = env41444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env41443 == env41444) = true)

def env41445 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2837,1,262,2820,2341,1024,0,3588,33,16,2,269,17,2048,2821,3889,2341,1285,33,256,32,2837,513]

theorem envBound41445 : H12AffineFastState.Bounded env41445 := by
  intro p hp
  have h : env41445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41444_41445 : H12AffineEnvironment.transform 11 3888 env41444 = env41445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env41444 == env41445) = true)

def env41446 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1045,1,262,1028,1573,1024,0,260,33,16,2,269,17,1792,1029,49,1573,1285,33,256,32,1045,513]

theorem envBound41446 : H12AffineFastState.Bounded env41446 := by
  intro p hp
  have h : env41446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41445_41446 : H12AffineEnvironment.transform 10 1792 env41445 = env41446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41445 == env41446) = true)

theorem identity41446 : scanCanonicalize (H12AffineFastState.compose env41446 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound41446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41447 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1077,48,269,1045,1,262,1028,1296,1024,0,260,33,16,2,269,17,1077,1029,49,1296,1285,33,256,32,1045,308]

theorem envBound41447 : H12AffineFastState.Bounded env41447 := by
  intro p hp
  have h : env41447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41446_41447 : H12AffineEnvironment.transform 8 309 env41446 = env41447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41446 == env41447) = true)

def env41448 : List Nat := [2,4,8,16,32,17,8,256,309,52,1,48,269,33,1,262,48,292,52,0,260,33,16,2,269,17,1,49,49,292,305,33,256,32,33,308]

theorem envBound41448 : H12AffineFastState.Bounded env41448 := by
  intro p hp
  have h : env41448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41447_41448 : H12AffineEnvironment.transform 9 52 env41447 = env41448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41447 == env41448) = true)

theorem identity41448 : scanCanonicalize (H12AffineFastState.compose env41448 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41449 : List Nat := [2,4,8,16,1,17,8,256,276,21,1,17,269,0,1,262,17,261,21,0,260,0,16,2,269,17,1,16,16,261,272,0,256,1,0,277]

theorem envBound41449 : H12AffineFastState.Bounded env41449 := by
  intro p hp
  have h : env41449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41448_41449 : H12AffineEnvironment.transform 4 1 env41448 = env41449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41448 == env41449) = true)

def leafEnv41449 : List Nat := [2,4,8,16,1,17,8,256,276,21,1,17,269,0,1,262,17,261,21,0,260,0,16,2,272,269,1,17,1,16,16,261,272,0,256,1,4,262,0,277,1,260,0]

def active41449 : List Nat := [0,1,2,3,7]

def tree41449 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41449 : H12WitnessSearch.Good tree41449 := H12GlobalWitnessIndex.good

theorem leafIdentity41449 : H12AffineFastState.composeSystem env41449 rootObs = leafEnv41449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41449 rootObs == leafEnv41449) = true)

theorem terminalChecked41449 : H12PackedTerminal.terminalCheckFast leafEnv41449 active41449 tree41449 = true := by decide +kernel

def env41450 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,48,269,32,1,262,49,293,53,0,260,33,16,2,269,17,0,48,49,293,304,33,256,32,32,308]

theorem envBound41450 : H12AffineFastState.Bounded env41450 := by
  intro p hp
  have h : env41450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41447_41450 : H12AffineEnvironment.transform 9 53 env41447 = env41450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41447 == env41450) = true)

theorem identity41450 : scanCanonicalize (H12AffineFastState.compose env41450 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41451 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,269,32,1,262,42,293,46,0,260,33,11,2,269,10,0,43,42,293,299,33,256,32,32,303]

theorem envBound41451 : H12AffineFastState.Bounded env41451 := by
  intro p hp
  have h : env41451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41450_41451 : H12AffineEnvironment.transform 3 11 env41450 = env41451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41450 == env41451) = true)

def leafEnv41451 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,43,269,32,1,262,42,293,46,0,260,33,11,2,299,269,1,10,0,43,42,293,299,33,256,32,4,262,32,303,1,260,0]

def active41451 : List Nat := [0,1,2,4,7]

def tree41451 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41451 : H12WitnessSearch.Good tree41451 := H12GlobalWitnessIndex.good

theorem leafIdentity41451 : H12AffineFastState.composeSystem env41451 rootObs = leafEnv41451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41451 rootObs == leafEnv41451) = true)

theorem terminalChecked41451 : H12PackedTerminal.terminalCheckFast leafEnv41451 active41451 tree41451 = true := by decide +kernel

def env41452 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1044,1,262,1029,1572,1024,0,261,33,16,2,269,17,1793,1028,48,1572,1285,33,256,32,1044,513]

theorem envBound41452 : H12AffineFastState.Bounded env41452 := by
  intro p hp
  have h : env41452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41445_41452 : H12AffineEnvironment.transform 10 1793 env41445 = env41452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41445 == env41452) = true)

theorem identity41452 : scanCanonicalize (H12AffineFastState.compose env41452 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound41452 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41453 : List Nat := [2,4,8,16,32,17,8,256,512,548,293,49,269,560,1,262,545,0,548,0,261,33,16,2,269,17,293,544,48,0,801,33,256,32,560,513]

theorem envBound41453 : H12AffineFastState.Bounded env41453 := by
  intro p hp
  have h : env41453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41452_41453 : H12AffineEnvironment.transform 9 548 env41452 = env41453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env41452 == env41453) = true)

def env41454 : List Nat := [2,4,8,16,32,17,8,256,16,52,293,49,269,32,1,262,49,0,52,0,261,33,16,2,269,17,293,48,48,0,305,33,256,32,32,17]

theorem envBound41454 : H12AffineFastState.Bounded env41454 := by
  intro p hp
  have h : env41454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41453_41454 : H12AffineEnvironment.transform 8 16 env41453 = env41454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41453 == env41454) = true)

theorem identity41454 : scanCanonicalize (H12AffineFastState.compose env41454 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41455 : List Nat := [2,4,8,16,32,17,8,4,16,52,33,49,9,32,1,2,49,0,52,0,1,33,16,2,9,17,33,48,48,0,53,33,4,32,32,17]

theorem envBound41455 : H12AffineFastState.Bounded env41455 := by
  intro p hp
  have h : env41455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41454_41455 : H12AffineEnvironment.transform 7 4 env41454 = env41455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41454 == env41455) = true)

def leafEnv41455 : List Nat := [2,4,8,16,32,17,8,4,16,52,33,49,9,32,1,2,49,0,52,0,1,33,16,2,53,9,1,17,33,48,48,0,53,33,4,32,4,2,32,17,1,1,0]

def active41455 : List Nat := [0,1,2,3,4]

def tree41455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41455 : H12WitnessSearch.Good tree41455 := H12GlobalWitnessIndex.good

theorem leafIdentity41455 : H12AffineFastState.composeSystem env41455 rootObs = leafEnv41455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41455 rootObs == leafEnv41455) = true)

theorem terminalChecked41455 : H12PackedTerminal.terminalCheckFast leafEnv41455 active41455 tree41455 = true := by decide +kernel

def env41456 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,49,269,33,1,262,48,0,53,0,261,33,16,2,269,17,293,49,48,0,304,33,256,32,33,16]

theorem envBound41456 : H12AffineFastState.Bounded env41456 := by
  intro p hp
  have h : env41456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41453_41456 : H12AffineEnvironment.transform 8 17 env41453 = env41456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41453 == env41456) = true)

theorem identity41456 : scanCanonicalize (H12AffineFastState.compose env41456 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41457 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,269,33,1,262,42,0,47,0,261,33,10,2,269,11,293,43,42,0,298,33,256,32,33,10]

theorem envBound41457 : H12AffineFastState.Bounded env41457 := by
  intro p hp
  have h : env41457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41456_41457 : H12AffineEnvironment.transform 3 10 env41456 = env41457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41456 == env41457) = true)

def leafEnv41457 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,43,269,33,1,262,42,0,47,0,261,33,10,2,298,269,1,11,293,43,42,0,298,33,256,32,4,262,33,10,1,261,0]

def active41457 : List Nat := [0,1,2,4,7]

def tree41457 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41457 : H12WitnessSearch.Good tree41457 := H12GlobalWitnessIndex.good

theorem leafIdentity41457 : H12AffineFastState.composeSystem env41457 rootObs = leafEnv41457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41457 rootObs == leafEnv41457) = true)

theorem terminalChecked41457 : H12PackedTerminal.terminalCheckFast leafEnv41457 active41457 tree41457 = true := by decide +kernel

def env41458 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2836,1,262,2821,2341,1024,0,3589,33,16,2,269,17,2048,2820,3888,2341,1285,33,256,32,2836,513]

theorem envBound41458 : H12AffineFastState.Bounded env41458 := by
  intro p hp
  have h : env41458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41444_41458 : H12AffineEnvironment.transform 11 3889 env41444 = env41458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env41444 == env41458) = true)

def env41459 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1044,1,262,1029,1573,1024,0,261,33,16,2,269,17,1792,1028,48,1573,1285,33,256,32,1044,513]

theorem envBound41459 : H12AffineFastState.Bounded env41459 := by
  intro p hp
  have h : env41459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41458_41459 : H12AffineEnvironment.transform 10 1792 env41458 = env41459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env41458 == env41459) = true)

theorem identity41459 : scanCanonicalize (H12AffineFastState.compose env41459 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound41459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41460 : List Nat := [2,4,8,16,32,17,8,256,512,768,0,49,269,788,1,262,773,293,768,0,261,33,16,2,269,17,0,772,48,293,517,33,256,32,788,513]

theorem envBound41460 : H12AffineFastState.Bounded env41460 := by
  intro p hp
  have h : env41460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41459_41460 : H12AffineEnvironment.transform 9 768 env41459 = env41460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env41459 == env41460) = true)

def env41461 : List Nat := [2,4,8,16,32,17,8,256,308,52,0,49,269,32,1,262,49,293,52,0,261,33,16,2,269,17,0,48,48,293,305,33,256,32,32,309]

theorem envBound41461 : H12AffineFastState.Bounded env41461 := by
  intro p hp
  have h : env41461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41460_41461 : H12AffineEnvironment.transform 8 308 env41460 = env41461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env41460 == env41461) = true)

theorem identity41461 : scanCanonicalize (H12AffineFastState.compose env41461 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41461 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41462 : List Nat := [2,4,8,16,1,17,8,256,277,21,0,16,269,1,1,262,16,260,21,0,261,0,16,2,269,17,0,17,17,260,272,0,256,1,1,276]

theorem envBound41462 : H12AffineFastState.Bounded env41462 := by
  intro p hp
  have h : env41462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41461_41462 : H12AffineEnvironment.transform 4 1 env41461 = env41462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41461 == env41462) = true)

def leafEnv41462 : List Nat := [2,4,8,16,1,17,8,256,277,21,0,16,269,1,1,262,16,260,21,0,261,0,16,2,272,269,1,17,0,17,17,260,272,0,256,1,4,262,1,276,1,261,0]

def active41462 : List Nat := [0,1,2,3,7]

def tree41462 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41462 : H12WitnessSearch.Good tree41462 := H12GlobalWitnessIndex.good

theorem leafIdentity41462 : H12AffineFastState.composeSystem env41462 rootObs = leafEnv41462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41462 rootObs == leafEnv41462) = true)

theorem terminalChecked41462 : H12PackedTerminal.terminalCheckFast leafEnv41462 active41462 tree41462 = true := by decide +kernel

def env41463 : List Nat := [2,4,8,16,32,17,8,256,309,53,0,49,269,33,1,262,48,293,53,0,261,33,16,2,269,17,0,49,48,293,304,33,256,32,33,308]

theorem envBound41463 : H12AffineFastState.Bounded env41463 := by
  intro p hp
  have h : env41463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41460_41463 : H12AffineEnvironment.transform 8 309 env41460 = env41463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41460 == env41463) = true)

theorem identity41463 : scanCanonicalize (H12AffineFastState.compose env41463 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41464 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,269,33,1,262,43,293,46,0,261,33,11,2,269,10,0,42,43,293,299,33,256,32,33,303]

theorem envBound41464 : H12AffineFastState.Bounded env41464 := by
  intro p hp
  have h : env41464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41463_41464 : H12AffineEnvironment.transform 3 11 env41463 = env41464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41463 == env41464) = true)

def leafEnv41464 : List Nat := [2,4,8,11,32,10,8,256,302,46,0,42,269,33,1,262,43,293,46,0,261,33,11,2,299,269,1,10,0,42,43,293,299,33,256,32,4,262,33,303,1,261,0]

def active41464 : List Nat := [0,1,2,4,7]

def tree41464 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41464 : H12WitnessSearch.Good tree41464 := H12GlobalWitnessIndex.good

theorem leafIdentity41464 : H12AffineFastState.composeSystem env41464 rootObs = leafEnv41464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41464 rootObs == leafEnv41464) = true)

theorem terminalChecked41464 : H12PackedTerminal.terminalCheckFast leafEnv41464 active41464 tree41464 = true := by decide +kernel

def env41465 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1045,1,262,1028,1572,1024,0,260,33,16,2,269,17,1793,1029,49,1572,1285,33,256,32,1045,513]

theorem envBound41465 : H12AffineFastState.Bounded env41465 := by
  intro p hp
  have h : env41465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41458_41465 : H12AffineEnvironment.transform 10 1793 env41458 = env41465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env41458 == env41465) = true)

theorem identity41465 : scanCanonicalize (H12AffineFastState.compose env41465 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound41465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41466 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1296,48,269,1045,1,262,1028,1077,1024,0,260,33,16,2,269,17,1296,1029,49,1077,1285,33,256,32,1045,16]

theorem envBound41466 : H12AffineFastState.Bounded env41466 := by
  intro p hp
  have h : env41466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41465_41466 : H12AffineEnvironment.transform 8 17 env41465 = env41466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env41465 == env41466) = true)

def env41467 : List Nat := [2,4,8,16,32,17,8,256,17,52,292,48,269,33,1,262,48,1,52,0,260,33,16,2,269,17,292,49,49,1,305,33,256,32,33,16]

theorem envBound41467 : H12AffineFastState.Bounded env41467 := by
  intro p hp
  have h : env41467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41466_41467 : H12AffineEnvironment.transform 9 52 env41466 = env41467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41466 == env41467) = true)

theorem identity41467 : scanCanonicalize (H12AffineFastState.compose env41467 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41468 : List Nat := [2,4,8,16,32,17,8,4,17,52,32,48,9,33,1,2,48,1,52,0,0,33,16,2,9,17,32,49,49,1,53,33,4,32,33,16]

theorem envBound41468 : H12AffineFastState.Bounded env41468 := by
  intro p hp
  have h : env41468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41467_41468 : H12AffineEnvironment.transform 7 4 env41467 = env41468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41467 == env41468) = true)

def leafEnv41468 : List Nat := [2,4,8,16,32,17,8,4,17,52,32,48,9,33,1,2,48,1,52,0,0,33,16,2,53,9,1,17,32,49,49,1,53,33,4,32,4,2,33,16,1,0,0]

def active41468 : List Nat := [0,1,2,3,4]

def tree41468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41468 : H12WitnessSearch.Good tree41468 := H12GlobalWitnessIndex.good

theorem leafIdentity41468 : H12AffineFastState.composeSystem env41468 rootObs = leafEnv41468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41468 rootObs == leafEnv41468) = true)

theorem terminalChecked41468 : H12PackedTerminal.terminalCheckFast leafEnv41468 active41468 tree41468 = true := by decide +kernel

def env41469 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,269,32,1,262,49,0,53,0,260,33,16,2,269,17,293,48,49,0,304,33,256,32,32,16]

theorem envBound41469 : H12AffineFastState.Bounded env41469 := by
  intro p hp
  have h : env41469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41466_41469 : H12AffineEnvironment.transform 9 53 env41466 = env41469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41466 == env41469) = true)

theorem identity41469 : scanCanonicalize (H12AffineFastState.compose env41469 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41470 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,269,32,1,262,43,0,47,0,260,33,10,2,269,11,293,42,43,0,298,33,256,32,32,10]

theorem envBound41470 : H12AffineFastState.Bounded env41470 := by
  intro p hp
  have h : env41470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41469_41470 : H12AffineEnvironment.transform 3 10 env41469 = env41470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41469 == env41470) = true)

def leafEnv41470 : List Nat := [2,4,8,10,32,11,8,256,11,47,293,42,269,32,1,262,43,0,47,0,260,33,10,2,298,269,1,11,293,42,43,0,298,33,256,32,4,262,32,10,1,260,0]

def active41470 : List Nat := [0,1,2,4,7]

def tree41470 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41470 : H12WitnessSearch.Good tree41470 := H12GlobalWitnessIndex.good

theorem leafIdentity41470 : H12AffineFastState.composeSystem env41470 rootObs = leafEnv41470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41470 rootObs == leafEnv41470) = true)

theorem terminalChecked41470 : H12PackedTerminal.terminalCheckFast leafEnv41470 active41470 tree41470 = true := by decide +kernel

def env41471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound41471 : H12AffineFastState.Bounded env41471 := by
  intro p hp
  have h : env41471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41286_41471 : H12AffineEnvironment.transform 18 1025 env41286 = env41471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env41286 == env41471) = true)

theorem identity41471 : scanCanonicalize (H12AffineFastState.compose env41471 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642569) := by decide +kernel

theorem selectedBound41471 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642569,8328,64,4464648,10642564,10507601,8830977,156697,14845384,257,2237604,2278657,213966]

theorem envBound41472 : H12AffineFastState.Bounded env41472 := by
  intro p hp
  have h : env41472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41471_41472 : H12AffineEnvironment.transform 23 8642569 env41471 = env41472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642569 env41471 == env41472) = true)

def env41473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,8388608,8642569,8328,64,4464648,8393984,8529109,8830977,156697,12645452,257,21792,46213,213966]

theorem envBound41473 : H12AffineFastState.Bounded env41473 := by
  intro p hp
  have h : env41473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41472_41473 : H12AffineEnvironment.transform 20 160132 env41472 = env41473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160132 env41472 == env41473) = true)

def env41474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169216,95497,8328,64,4464648,163840,45525,283905,156697,4350284,257,21792,46213,213966]

theorem envBound41474 : H12AffineFastState.Bounded env41474 := by
  intro p hp
  have h : env41474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41473_41474 : H12AffineEnvironment.transform 22 169216 env41473 = env41474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env41473 == env41474) = true)

def env41475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169216,95497,8328,64,2184,163840,45525,283905,156697,412108,257,21792,46213,213966]

theorem envBound41475 : H12AffineFastState.Bounded env41475 := by
  intro p hp
  have h : env41475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41474_41475 : H12AffineEnvironment.transform 21 272512 env41474 = env41475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41474 == env41475) = true)

theorem identity41475 : scanCanonicalize (H12AffineFastState.compose env41475 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound41475 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,115870,272512,73754,95497,8328,64,2184,79130,45525,283905,119043,392406,257,21792,46213,63188]

theorem envBound41476 : H12AffineFastState.Bounded env41476 := by
  intro p hp
  have h : env41476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41475_41476 : H12AffineEnvironment.transform 16 111898 env41475 = env41476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env41475 == env41476) = true)

def env41477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,115870,32,73754,95497,8328,64,2184,79130,45525,32161,119043,119926,257,21792,46213,63188]

theorem envBound41477 : H12AffineFastState.Bounded env41477 := by
  intro p hp
  have h : env41477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41476_41477 : H12AffineEnvironment.transform 17 10400 env41476 = env41477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env41476 == env41477) = true)

theorem identity41477 : scanCanonicalize (H12AffineFastState.compose env41477 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound41477 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,13388,10400,1025,32769,17864,32,41292,62559,8328,64,2184,46156,45525,32161,20565,21792,257,21792,46213,63188]

theorem envBound41478 : H12AffineFastState.Bounded env41478 := by
  intro p hp
  have h : env41478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41477_41478 : H12AffineEnvironment.transform 15 33110 env41477 = env41478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env41477 == env41478) = true)

theorem identity41478 : scanCanonicalize (H12AffineFastState.compose env41478 (packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 508) := by decide +kernel

theorem selectedBound41478 : packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env41479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,508,170,13388,10400,1025,509,17864,32,8368,30115,8328,64,2184,13744,12329,32161,20565,21792,257,21792,13689,30504]

theorem envBound41479 : H12AffineFastState.Bounded env41479 := by
  intro p hp
  have h : env41479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41478_41479 : H12AffineEnvironment.transform 14 508 env41478 = env41479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 508 env41478 == env41479) = true)

theorem identity41479 : scanCanonicalize (H12AffineFastState.compose env41479 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41479 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env41480 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,137,170,13388,10400,1025,136,17597,32,8368,29910,8328,64,2184,13509,12329,31956,20565,21589,116,21589,13324,30301]

theorem envBound41480 : H12AffineFastState.Bounded env41480 := by
  intro p hp
  have h : env41480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41479_41480 : H12AffineEnvironment.transform 7 117 env41479 = env41480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41479 == env41480) = true)

theorem identity41480 : scanCanonicalize (H12AffineFastState.compose env41480 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound41480 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env41481 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,160,16384,137,170,5356,2048,1025,136,17597,32,16,21622,40,64,2184,5221,4233,23668,20565,21589,116,21589,5292,22269]

theorem envBound41481 : H12AffineFastState.Bounded env41481 := by
  intro p hp
  have h : env41481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41480_41481 : H12AffineEnvironment.transform 12 160 env41480 = env41481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env41480 == env41481) = true)

theorem identity41481 : scanCanonicalize (H12AffineFastState.compose env41481 (packedSelected [2,5,6,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound41481 : packedSelected [2,5,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env41482 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,160,16384,137,170,4232,2048,101,136,16601,32,16,20498,40,64,2184,4097,4233,22544,20565,20529,116,20529,4296,21145]

theorem envBound41482 : H12AffineFastState.Bounded env41482 := by
  intro p hp
  have h : env41482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41481_41482 : H12AffineEnvironment.transform 9 100 env41481 = env41482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env41481 == env41482) = true)

theorem identity41482 : scanCanonicalize (H12AffineFastState.compose env41482 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4249) := by decide +kernel

theorem selectedBound41482 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41483 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,160,4249,137,170,4232,2048,101,136,4160,32,16,139,40,64,2184,4097,4233,2185,204,168,116,168,4296,512]

theorem envBound41483 : H12AffineFastState.Bounded env41483 := by
  intro p hp
  have h : env41483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41482_41483 : H12AffineEnvironment.transform 13 4249 env41482 = env41483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4249 env41482 == env41483) = true)

theorem identity41483 : scanCanonicalize (H12AffineFastState.compose env41483 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound41483 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41484 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,152,160,1,137,170,16,2048,101,136,216,32,16,139,40,64,2184,153,17,2185,204,168,116,168,80,512]

theorem envBound41484 : H12AffineFastState.Bounded env41484 := by
  intro p hp
  have h : env41484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41483_41484 : H12AffineEnvironment.transform 11 152 env41483 = env41484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env41483 == env41484) = true)

theorem identity41484 : scanCanonicalize (H12AffineFastState.compose env41484 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41484 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41485 : List Nat := [2,4,8,16,1,64,128,84,512,69,2048,152,129,1,137,139,16,2048,68,136,216,1,16,139,9,64,2184,153,17,2185,204,137,85,137,80,512]

theorem envBound41485 : H12AffineFastState.Bounded env41485 := by
  intro p hp
  have h : env41485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41484_41485 : H12AffineEnvironment.transform 4 1 env41484 = env41485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41484 == env41485) = true)

theorem identity41485 : scanCanonicalize (H12AffineFastState.compose env41485 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 216) := by decide +kernel

theorem selectedBound41485 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41486 : List Nat := [2,4,8,16,1,64,128,84,512,69,216,152,129,1,137,139,16,216,68,136,216,1,16,139,9,64,80,153,17,81,204,137,85,137,80,512]

theorem envBound41486 : H12AffineFastState.Bounded env41486 := by
  intro p hp
  have h : env41486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41485_41486 : H12AffineEnvironment.transform 10 216 env41485 = env41486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 216 env41485 == env41486) = true)

theorem identity41486 : scanCanonicalize (H12AffineFastState.compose env41486 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41486 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41487 : List Nat := [2,4,8,16,1,17,128,5,512,20,137,152,129,1,137,139,16,137,21,136,137,1,16,139,9,17,1,153,17,0,157,137,4,137,1,512]

theorem envBound41487 : H12AffineFastState.Bounded env41487 := by
  intro p hp
  have h : env41487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41486_41487 : H12AffineEnvironment.transform 5 17 env41486 = env41487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41486 == env41487) = true)

def env41488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,115870,33,73754,95497,8328,64,2184,79130,45525,32160,119043,119927,257,21792,46213,63188]

theorem envBound41488 : H12AffineFastState.Bounded env41488 := by
  intro p hp
  have h : env41488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41476_41488 : H12AffineEnvironment.transform 17 10401 env41476 = env41488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env41476 == env41488) = true)

theorem identity41488 : scanCanonicalize (H12AffineFastState.compose env41488 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41488 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env41489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10401,1025,32769,58517,33,17,21762,8328,64,2184,5393,45525,32160,61704,62588,257,21792,46213,63188]

theorem envBound41489 : H12AffineFastState.Bounded env41489 := by
  intro p hp
  have h : env41489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41488_41489 : H12AffineEnvironment.transform 15 8203 env41488 = env41489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41488 == env41489) = true)

theorem identity41489 : scanCanonicalize (H12AffineFastState.compose env41489 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41489 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env41490 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10280,1025,32769,58396,33,17,21762,8193,64,2049,5393,45404,32041,61704,62588,257,21792,46092,63069]

theorem envBound41490 : H12AffineFastState.Bounded env41490 := by
  intro p hp
  have h : env41490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41489_41490 : H12AffineEnvironment.transform 6 9 env41489 = env41490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41489 == env41490) = true)

theorem identity41490 : scanCanonicalize (H12AffineFastState.compose env41490 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound41490 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24909,10280,1025,29789,4160,33,17,21762,8193,64,2049,5393,17664,32041,1364,32,257,21792,16464,513]

theorem envBound41491 : H12AffineFastState.Bounded env41491 := by
  intro p hp
  have h : env41491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41490_41491 : H12AffineEnvironment.transform 14 29788 env41490 = env41491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env41490 == env41491) = true)

theorem identity41491 : scanCanonicalize (H12AffineFastState.compose env41491 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41491 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41492 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29708,8203,24861,10280,1025,29709,4112,33,17,21762,8193,16,2049,5393,17664,32041,1284,32,257,21792,16384,513]

theorem envBound41492 : H12AffineFastState.Bounded env41492 := by
  intro p hp
  have h : env41492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41491_41492 : H12AffineEnvironment.transform 5 16 env41491 = env41492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41491 == env41492) = true)

theorem identity41492 : scanCanonicalize (H12AffineFastState.compose env41492 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41492 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41493 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21760,263,16401,2340,1025,21761,4112,33,17,21762,269,16,2049,5393,17664,23589,1284,32,257,21792,16384,513]

theorem envBound41493 : H12AffineFastState.Bounded env41493 := by
  intro p hp
  have h : env41493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41492_41493 : H12AffineEnvironment.transform 12 268 env41492 = env41493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41492 == env41493) = true)

theorem identity41493 : scanCanonicalize (H12AffineFastState.compose env41493 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 5684) := by decide +kernel

theorem selectedBound41493 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41494 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5684,820,263,5669,2340,1025,821,4112,33,17,822,269,16,2049,5393,4916,2577,1284,32,257,788,5684,513]

theorem envBound41494 : H12AffineFastState.Bounded env41494 := by
  intro p hp
  have h : env41494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41493_41494 : H12AffineEnvironment.transform 13 5684 env41493 = env41494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5684 env41493 == env41494) = true)

theorem identity41494 : scanCanonicalize (H12AffineFastState.compose env41494 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound41494 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env41495 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3889,268,2309,820,263,2324,2340,1025,821,3873,33,17,822,269,16,2049,2592,3077,2577,1284,32,257,788,2309,513]

theorem envBound41495 : H12AffineFastState.Bounded env41495 := by
  intro p hp
  have h : env41495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41494_41495 : H12AffineEnvironment.transform 11 3889 env41494 = env41495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env41494 == env41495) = true)

theorem identity41495 : scanCanonicalize (H12AffineFastState.compose env41495 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound41495 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env41496 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1028,821,268,1281,820,263,1296,1312,1025,821,805,33,17,822,269,16,1029,1572,1,1557,1284,32,257,788,1281,513]

theorem envBound41496 : H12AffineFastState.Bounded env41496 := by
  intro p hp
  have h : env41496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41495_41496 : H12AffineEnvironment.transform 10 1028 env41495 = env41496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env41495 == env41496) = true)

theorem identity41496 : scanCanonicalize (H12AffineFastState.compose env41496 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound41496 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env41497 : List Nat := [2,4,8,16,32,16,9,256,309,1024,1028,0,268,1281,1,263,1296,1312,1025,0,16,33,17,3,269,16,1029,1297,1,1312,1284,32,257,33,1281,308]

theorem envBound41497 : H12AffineFastState.Bounded env41497 := by
  intro p hp
  have h : env41497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41496_41497 : H12AffineEnvironment.transform 8 309 env41496 = env41497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41496 == env41497) = true)

theorem identity41497 : scanCanonicalize (H12AffineFastState.compose env41497 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41498 : List Nat := [2,4,8,16,32,16,9,20,33,1024,1028,0,24,1045,1,19,1028,1076,1025,0,16,33,17,3,25,16,1029,1029,1,1076,1040,32,21,33,1045,32]

theorem envBound41498 : H12AffineFastState.Bounded env41498 := by
  intro p hp
  have h : env41498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41497_41498 : H12AffineEnvironment.transform 7 20 env41497 = env41498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41497 == env41498) = true)

theorem identity41498 : scanCanonicalize (H12AffineFastState.compose env41498 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41499 : List Nat := [2,4,8,16,32,16,9,20,33,20,16,0,24,1,1,19,16,32,21,0,16,33,17,3,25,16,17,17,1,32,4,32,21,33,1,32]

theorem envBound41499 : H12AffineFastState.Bounded env41499 := by
  intro p hp
  have h : env41499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41498_41499 : H12AffineEnvironment.transform 9 20 env41498 = env41499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41498 == env41499) = true)

theorem identity41499 : scanCanonicalize (H12AffineFastState.compose env41499 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41500 : List Nat := [2,4,8,16,1,16,9,20,0,20,16,0,24,1,1,19,16,1,21,0,16,0,17,3,25,16,17,17,1,1,4,1,21,0,1,1]

theorem envBound41500 : H12AffineFastState.Bounded env41500 := by
  intro p hp
  have h : env41500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41499_41500 : H12AffineEnvironment.transform 4 1 env41499 = env41500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41499 == env41500) = true)

theorem identity41500 : scanCanonicalize (H12AffineFastState.compose env41500 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41500 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41501 : List Nat := [2,4,8,0,1,0,9,4,0,4,0,0,8,1,1,3,0,1,5,0,0,0,1,3,9,0,1,1,1,1,4,1,5,0,1,1]

theorem envBound41501 : H12AffineFastState.Bounded env41501 := by
  intro p hp
  have h : env41501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41500_41501 : H12AffineEnvironment.transform 3 0 env41500 = env41501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41500 == env41501) = true)

def env41502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169216,95497,8328,64,2185,163840,45525,283905,156697,412109,257,21792,46213,213966]

theorem envBound41502 : H12AffineFastState.Bounded env41502 := by
  intro p hp
  have h : env41502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41474_41502 : H12AffineEnvironment.transform 21 272513 env41474 = env41502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41474 == env41502) = true)

theorem identity41502 : scanCanonicalize (H12AffineFastState.compose env41502 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound41502 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160132,272513,169216,21762,8328,64,2185,163840,45525,283905,156697,412109,257,21792,46213,156613]

theorem envBound41503 : H12AffineFastState.Bounded env41503 := by
  intro p hp
  have h : env41503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41502_41503 : H12AffineEnvironment.transform 15 8203 env41502 = env41503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env41502 == env41503) = true)

def env41504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160012,272393,169216,21762,8192,64,2049,163840,45405,283905,156697,411973,257,21792,46093,156493]

theorem envBound41504 : H12AffineFastState.Bounded env41504 := by
  intro p hp
  have h : env41504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41503_41504 : H12AffineEnvironment.transform 6 8 env41503 = env41504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41503 == env41504) = true)

theorem identity41504 : scanCanonicalize (H12AffineFastState.compose env41504 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41504 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env41505 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,159865,272393,169077,21623,8192,64,2049,163840,45096,283764,156697,411696,116,21589,46093,156216]

theorem envBound41505 : H12AffineFastState.Bounded env41505 := by
  intro p hp
  have h : env41505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41504_41505 : H12AffineEnvironment.transform 7 117 env41504 = env41505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41504 == env41505) = true)

theorem identity41505 : scanCanonicalize (H12AffineFastState.compose env41505 (packedSelected [0,4,14,20,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound41505 : packedSelected [0,4,14,20,22,27] rootPS < 2^1333 := by decide +kernel

def env41506 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8203,131072,10281,1025,32769,159865,32,169077,21623,8192,64,2049,163840,45096,31837,156697,155673,116,21589,46093,156216]

theorem envBound41506 : H12AffineFastState.Bounded env41506 := by
  intro p hp
  have h : env41506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41505_41506 : H12AffineEnvironment.transform 17 10281 env41505 = env41506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41505 == env41506) = true)

theorem identity41506 : scanCanonicalize (H12AffineFastState.compose env41506 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound41506 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41507 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,32768,8203,131072,10281,1025,32769,139368,32,169077,1126,8192,64,2049,163840,45096,11340,144392,143368,116,1092,46093,143913]

theorem envBound41507 : H12AffineFastState.Bounded env41507 := by
  intro p hp
  have h : env41507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41506_41507 : H12AffineEnvironment.transform 13 4113 env41506 = env41507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env41506 == env41507) = true)

theorem identity41507 : scanCanonicalize (H12AffineFastState.compose env41507 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound41507 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41508 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4113,8233,8203,131072,10281,1025,8232,139368,32,144476,1126,8192,64,2049,139305,4097,11340,144392,143368,116,1092,5156,143913]

theorem envBound41508 : H12AffineFastState.Bounded env41508 := by
  intro p hp
  have h : env41508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41507_41508 : H12AffineEnvironment.transform 14 8233 env41507 = env41508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env41507 == env41508) = true)

def env41509 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160013,272392,169216,21762,8193,64,2048,163840,45404,283905,156697,411972,257,21792,46092,156492]

theorem envBound41509 : H12AffineFastState.Bounded env41509 := by
  intro p hp
  have h : env41509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41503_41509 : H12AffineEnvironment.transform 6 9 env41503 = env41509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41503 == env41509) = true)

theorem identity41509 : scanCanonicalize (H12AffineFastState.compose env41509 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound41509 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env41510 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,171108,1025,32769,160013,177260,169216,21762,8193,64,2048,163840,45404,182629,156697,54560,257,21792,46092,156492]

theorem envBound41510 : H12AffineFastState.Bounded env41510 := by
  intro p hp
  have h : env41510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41509_41510 : H12AffineEnvironment.transform 17 171108 env41509 = env41510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env41509 == env41510) = true)

theorem identity41510 : scanCanonicalize (H12AffineFastState.compose env41510 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound41510 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env41511 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,23668,1025,32769,45341,29820,21776,21762,8193,64,2048,16400,45404,2421,41993,54560,257,21792,46092,41820]

theorem envBound41511 : H12AffineFastState.Bounded env41511 := by
  intro p hp
  have h : env41511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41510_41511 : H12AffineEnvironment.transform 16 49168 env41510 = env41511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env41510 == env41511) = true)

theorem identity41511 : scanCanonicalize (H12AffineFastState.compose env41511 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41511 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env41512 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,24909,23668,1025,8540,4160,29820,21776,21762,8193,64,2048,16400,4097,2421,1364,29821,257,21792,5457,513]

theorem envBound41512 : H12AffineFastState.Bounded env41512 := by
  intro p hp
  have h : env41512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41511_41512 : H12AffineEnvironment.transform 14 8541 env41511 = env41512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41511 == env41512) = true)

def env41513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169217,95496,8328,64,4464648,163841,45524,283904,156697,4350285,257,21792,46213,213966]

theorem envBound41513 : H12AffineFastState.Bounded env41513 := by
  intro p hp
  have h : env41513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41473_41513 : H12AffineEnvironment.transform 22 169217 env41473 = env41513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env41473 == env41513) = true)

def env41514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169217,95496,8328,64,2184,163841,45524,283904,156697,412109,257,21792,46213,213966]

theorem envBound41514 : H12AffineFastState.Bounded env41514 := by
  intro p hp
  have h : env41514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41513_41514 : H12AffineEnvironment.transform 21 272512 env41513 = env41514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41513 == env41514) = true)

theorem identity41514 : scanCanonicalize (H12AffineFastState.compose env41514 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound41514 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,77899,272512,120014,95496,8328,64,2184,115150,45524,283904,75222,329730,257,21792,46213,513]

theorem envBound41515 : H12AffineFastState.Bounded env41515 := by
  intro p hp
  have h : env41515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41514_41515 : H12AffineEnvironment.transform 16 82383 env41514 = env41515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env41514 == env41515) = true)

def env41516 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77899,272392,119878,95496,8192,64,2048,115014,45404,283904,75102,329730,257,21792,46093,513]

theorem envBound41516 : H12AffineFastState.Bounded env41516 := by
  intro p hp
  have h : env41516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41515_41516 : H12AffineEnvironment.transform 6 8 env41515 = env41516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41515 == env41516) = true)

theorem identity41516 : scanCanonicalize (H12AffineFastState.compose env41516 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41516 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41517 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,262144,1025,32769,69910,264533,119878,87125,349,64,2048,115014,36865,283904,66563,329730,257,21792,38224,513]

theorem envBound41517 : H12AffineFastState.Bounded env41517 := by
  intro p hp
  have h : env41517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41516_41517 : H12AffineEnvironment.transform 12 349 env41516 = env41517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41516 == env41517) = true)

theorem identity41517 : scanCanonicalize (H12AffineFastState.compose env41517 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound41517 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env41518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82247,56356,1025,32769,69910,54641,119878,87125,349,64,2048,115014,36865,35108,66563,119846,257,21792,38224,513]

theorem envBound41518 : H12AffineFastState.Bounded env41518 := by
  intro p hp
  have h : env41518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41517_41518 : H12AffineEnvironment.transform 17 56356 env41517 = env41518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env41517 == env41518) = true)

theorem identity41518 : scanCanonicalize (H12AffineFastState.compose env41518 (packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41518 : packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env41519 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,32768,65536,82019,56356,1025,32769,69682,54357,119878,87125,121,64,2048,114786,36865,34816,66563,119846,37,21508,38004,513]

theorem envBound41519 : H12AffineFastState.Bounded env41519 := by
  intro p hp
  have h : env41519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41518_41519 : H12AffineEnvironment.transform 7 36 env41518 = env41519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41518 == env41519) = true)

theorem identity41519 : scanCanonicalize (H12AffineFastState.compose env41519 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound41519 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41520 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,32768,21510,5221,56356,1025,32769,17460,54357,32832,83,121,64,2048,37988,36865,34816,20485,32800,37,21508,38004,513]

theorem envBound41520 : H12AffineFastState.Bounded env41520 := by
  intro p hp
  have h : env41520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41519_41520 : H12AffineEnvironment.transform 15 21510 env41519 = env41520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env41519 == env41520) = true)

theorem identity41520 : scanCanonicalize (H12AffineFastState.compose env41520 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound41520 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41521 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,21621,21510,5221,2129,1025,21620,17460,32,21557,83,121,64,2048,16401,17524,23669,20485,21589,37,21508,16385,513]

theorem envBound41521 : H12AffineFastState.Bounded env41521 := by
  intro p hp
  have h : env41521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41520_41521 : H12AffineEnvironment.transform 14 21621 env41520 = env41521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env41520 == env41521) = true)

theorem identity41521 : scanCanonicalize (H12AffineFastState.compose env41521 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound41521 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env41522 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1060,121,16384,16465,16418,65,2129,1025,16464,17460,32,16401,83,121,64,2048,16401,17524,18513,17441,16497,37,16416,16385,513]

theorem envBound41522 : H12AffineFastState.Bounded env41522 := by
  intro p hp
  have h : env41522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41521_41522 : H12AffineEnvironment.transform 11 1060 env41521 = env41522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env41521 == env41522) = true)

theorem identity41522 : scanCanonicalize (H12AffineFastState.compose env41522 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41522 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41523 : List Nat := [2,4,8,16,32,64,8,36,512,1024,0,1060,121,16384,16465,16418,65,81,1025,16464,17460,32,16401,83,121,64,0,16401,17524,16465,17441,16497,37,16416,16385,513]

theorem envBound41523 : H12AffineFastState.Bounded env41523 := by
  intro p hp
  have h : env41523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41522_41523 : H12AffineEnvironment.transform 10 0 env41522 = env41523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41522 == env41523) = true)

theorem identity41523 : scanCanonicalize (H12AffineFastState.compose env41523 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound41523 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41524 : List Nat := [2,4,8,16,32,64,8,36,512,100,0,64,121,16384,16465,16418,65,81,101,16464,16464,32,16401,83,121,64,0,16401,16400,16465,16453,16497,37,16416,16385,513]

theorem envBound41524 : H12AffineFastState.Bounded env41524 := by
  intro p hp
  have h : env41524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41523_41524 : H12AffineEnvironment.transform 9 100 env41523 = env41524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env41523 == env41524) = true)

def env41525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,119879,95496,8193,64,2049,115015,45405,283904,75103,329730,257,21792,46092,513]

theorem envBound41525 : H12AffineFastState.Bounded env41525 := by
  intro p hp
  have h : env41525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41515_41525 : H12AffineEnvironment.transform 6 9 env41515 = env41525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41515 == env41525) = true)

def env41526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,77899,33,119879,95496,8193,64,2049,115015,45405,32040,75103,73770,257,21792,46092,513]

theorem envBound41526 : H12AffineFastState.Bounded env41526 := by
  intro p hp
  have h : env41526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41525_41526 : H12AffineEnvironment.transform 17 10280 env41525 = env41526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41525 == env41526) = true)

theorem identity41526 : scanCanonicalize (H12AffineFastState.compose env41526 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound41526 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env41527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,65536,82246,10280,1025,1,77899,33,87111,95496,8193,64,2049,82247,12637,32040,75103,73770,257,21792,13324,513]

theorem envBound41527 : H12AffineFastState.Bounded env41527 := by
  intro p hp
  have h : env41527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41526_41527 : H12AffineEnvironment.transform 14 0 env41526 = env41527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env41526 == env41527) = true)

theorem identity41527 : scanCanonicalize (H12AffineFastState.compose env41527 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound41527 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,65536,82246,2421,1025,1,69910,33,87111,87125,348,64,2049,82247,4096,23669,66562,65911,257,21792,5457,513]

theorem envBound41528 : H12AffineFastState.Bounded env41528 := by
  intro p hp
  have h : env41528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41527_41528 : H12AffineEnvironment.transform 12 349 env41527 = env41528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env41527 == env41528) = true)

theorem identity41528 : scanCanonicalize (H12AffineFastState.compose env41528 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound41528 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,21510,5440,2421,1025,1,17680,33,65,83,348,64,2049,5441,4096,23669,20484,21873,257,21792,5457,513]

theorem envBound41529 : H12AffineFastState.Bounded env41529 := by
  intro p hp
  have h : env41529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41528_41529 : H12AffineEnvironment.transform 15 21510 env41528 = env41529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env41528 == env41529) = true)

theorem identity41529 : scanCanonicalize (H12AffineFastState.compose env41529 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41529 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,263,5440,2421,1025,1,4113,33,65,83,348,64,2049,5441,4096,2420,1285,112,257,33,5457,513]

theorem envBound41530 : H12AffineFastState.Bounded env41530 := by
  intro p hp
  have h : env41530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41529_41530 : H12AffineEnvironment.transform 13 5377 env41529 = env41530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41529 == env41530) = true)

theorem identity41530 : scanCanonicalize (H12AffineFastState.compose env41530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41531 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5392,2341,1025,1,4113,33,17,3,268,16,2049,5393,4096,2340,1285,32,257,33,5377,513]

theorem envBound41531 : H12AffineFastState.Bounded env41531 := by
  intro p hp
  have h : env41531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41530_41531 : H12AffineEnvironment.transform 5 16 env41530 = env41531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41530 == env41531) = true)

theorem identity41531 : scanCanonicalize (H12AffineFastState.compose env41531 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41532 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,4405,0,263,4388,2341,53,1,4113,33,17,3,268,16,2049,4389,4096,2340,305,32,257,33,4405,513]

theorem envBound41532 : H12AffineFastState.Bounded env41532 := by
  intro p hp
  have h : env41532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41531_41532 : H12AffineEnvironment.transform 9 52 env41531 = env41532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41531 == env41532) = true)

theorem identity41532 : scanCanonicalize (H12AffineFastState.compose env41532 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound41532 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41533 : List Nat := [2,4,8,16,32,16,9,256,512,52,522,4096,269,4405,0,263,4388,815,53,1,4113,33,17,3,268,16,523,4389,4096,814,305,32,257,33,4405,513]

theorem envBound41533 : H12AffineFastState.Bounded env41533 := by
  intro p hp
  have h : env41533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41532_41533 : H12AffineEnvironment.transform 10 522 env41532 = env41533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env41532 == env41533) = true)

theorem identity41533 : scanCanonicalize (H12AffineFastState.compose env41533 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 799) := by decide +kernel

theorem selectedBound41533 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41534 : List Nat := [2,4,8,16,32,16,9,256,512,52,522,799,269,554,0,263,571,815,53,1,782,33,17,3,268,16,523,570,799,814,305,32,257,33,554,513]

theorem envBound41534 : H12AffineFastState.Bounded env41534 := by
  intro p hp
  have h : env41534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41533_41534 : H12AffineEnvironment.transform 11 799 env41533 = env41534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 799 env41533 == env41534) = true)

def env41535 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,77899,32,119879,95496,8193,64,2049,115015,45405,32041,75103,73771,257,21792,46092,513]

theorem envBound41535 : H12AffineFastState.Bounded env41535 := by
  intro p hp
  have h : env41535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41525_41535 : H12AffineEnvironment.transform 17 10281 env41525 = env41535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41525 == env41535) = true)

theorem identity41535 : scanCanonicalize (H12AffineFastState.compose env41535 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound41535 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41536 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1025,32769,58396,32,16,41311,8193,64,2049,5392,45405,32041,61704,62588,257,21792,46092,513]

theorem envBound41536 : H12AffineFastState.Bounded env41536 := by
  intro p hp
  have h : env41536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41535_41536 : H12AffineEnvironment.transform 15 54359 env41535 = env41536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env41535 == env41536) = true)

theorem identity41536 : scanCanonicalize (H12AffineFastState.compose env41536 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound41536 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env41537 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,7425,18774,2064,10281,1025,7424,31005,32,16,15454,8193,64,2049,5392,11356,32041,27657,27005,257,21792,10509,513]

theorem envBound41537 : H12AffineFastState.Bounded env41537 := by
  intro p hp
  have h : env41537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41536_41537 : H12AffineEnvironment.transform 14 7425 env41536 = env41537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env41536 == env41537) = true)

theorem identity41537 : scanCanonicalize (H12AffineFastState.compose env41537 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound41537 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env41538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,7425,18774,2064,2421,1025,7424,22593,32,16,7426,349,64,2049,5392,3328,23669,19797,18465,257,21792,2129,513]

theorem envBound41538 : H12AffineFastState.Bounded env41538 := by
  intro p hp
  have h : env41538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41537_41538 : H12AffineEnvironment.transform 12 348 env41537 = env41538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env41537 == env41538) = true)

theorem identity41538 : scanCanonicalize (H12AffineFastState.compose env41538 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound41538 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,1296,7425,3142,2064,2421,1025,7424,7505,32,16,7426,349,64,2049,5392,3328,6501,2117,3377,257,4144,2129,513]

theorem envBound41539 : H12AffineFastState.Bounded env41539 := by
  intro p hp
  have h : env41539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41538_41539 : H12AffineEnvironment.transform 13 1296 env41538 = env41539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41538 == env41539) = true)

theorem identity41539 : scanCanonicalize (H12AffineFastState.compose env41539 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41539 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env41540 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,0,6161,2390,2064,2421,273,6160,6209,32,16,6162,349,64,2049,4096,2064,6501,2117,2081,257,4144,2129,513]

theorem envBound41540 : H12AffineFastState.Bounded env41540 := by
  intro p hp
  have h : env41540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41539_41540 : H12AffineEnvironment.transform 9 272 env41539 = env41540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41539 == env41540) = true)

theorem identity41540 : scanCanonicalize (H12AffineFastState.compose env41540 (packedSelected [3,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound41540 : packedSelected [3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env41541 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,4096,348,0,4404,115,309,80,273,4405,4452,32,16,4407,349,64,292,4096,309,4160,352,260,257,4144,372,513]

theorem envBound41541 : H12AffineFastState.Bounded env41541 := by
  intro p hp
  have h : env41541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41540_41541 : H12AffineEnvironment.transform 10 293 env41540 = env41541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env41540 == env41541) = true)

theorem identity41541 : scanCanonicalize (H12AffineFastState.compose env41541 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound41541 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env41542 : List Nat := [2,4,8,16,32,64,9,256,512,272,293,17,348,0,293,115,309,80,273,292,373,32,16,294,349,64,292,17,309,81,352,260,257,33,372,513]

theorem envBound41542 : H12AffineFastState.Bounded env41542 := by
  intro p hp
  have h : env41542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41541_41542 : H12AffineEnvironment.transform 11 17 env41541 = env41542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env41541 == env41542) = true)

theorem identity41542 : scanCanonicalize (H12AffineFastState.compose env41542 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41542 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41543 : List Nat := [2,4,8,16,32,64,9,37,512,53,0,17,121,0,0,115,16,80,52,1,80,32,16,3,120,64,1,17,16,81,69,33,36,33,81,513]

theorem envBound41543 : H12AffineFastState.Bounded env41543 := by
  intro p hp
  have h : env41543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41542_41543 : H12AffineEnvironment.transform 7 37 env41542 = env41543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41542 == env41543) = true)

theorem identity41543 : scanCanonicalize (H12AffineFastState.compose env41543 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41544 : List Nat := [2,4,8,16,32,17,9,37,512,53,0,17,40,0,0,34,16,1,52,1,1,32,16,3,41,17,1,17,16,0,20,33,36,33,0,513]

theorem envBound41544 : H12AffineFastState.Bounded env41544 := by
  intro p hp
  have h : env41544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41543_41544 : H12AffineEnvironment.transform 5 17 env41543 = env41544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41543 == env41544) = true)

theorem identity41544 : scanCanonicalize (H12AffineFastState.compose env41544 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound41544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41545 : List Nat := [2,4,8,16,32,17,9,37,32,53,0,17,40,0,0,34,16,1,52,1,1,32,16,3,41,17,1,17,16,0,20,33,36,33,0,33]

theorem envBound41545 : H12AffineFastState.Bounded env41545 := by
  intro p hp
  have h : env41545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41544_41545 : H12AffineEnvironment.transform 8 32 env41544 = env41545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env41544 == env41545) = true)

theorem identity41545 : scanCanonicalize (H12AffineFastState.compose env41545 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41546 : List Nat := [2,4,8,16,17,17,9,20,17,4,0,17,25,0,0,19,16,1,5,1,1,17,16,3,24,17,1,17,16,0,20,16,21,16,0,16]

theorem envBound41546 : H12AffineFastState.Bounded env41546 := by
  intro p hp
  have h : env41546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41545_41546 : H12AffineEnvironment.transform 4 17 env41545 = env41546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41545 == env41546) = true)

def env41547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169217,95496,8328,64,2185,163841,45524,283904,156697,412108,257,21792,46213,213966]

theorem envBound41547 : H12AffineFastState.Bounded env41547 := by
  intro p hp
  have h : env41547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41513_41547 : H12AffineEnvironment.transform 21 272513 env41513 = env41547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41513 == env41547) = true)

theorem identity41547 : scanCanonicalize (H12AffineFastState.compose env41547 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound41547 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,160132,272513,169217,41431,8328,64,2185,163841,45524,283904,156697,412108,257,21792,46213,169745]

theorem envBound41548 : H12AffineFastState.Bounded env41548 := by
  intro p hp
  have h : env41548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41547_41548 : H12AffineEnvironment.transform 15 54495 env41547 = env41548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env41547 == env41548) = true)

def env41549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160012,272393,169217,41311,8192,64,2049,163841,45404,283904,156697,411972,257,21792,46093,169745]

theorem envBound41549 : H12AffineFastState.Bounded env41549 := by
  intro p hp
  have h : env41549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41548_41549 : H12AffineEnvironment.transform 6 8 env41548 = env41549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41548 == env41549) = true)

theorem identity41549 : scanCanonicalize (H12AffineFastState.compose env41549 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(16+1) ^^^ 37988) := by decide +kernel

theorem selectedBound41549 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env41550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,37988,262144,1025,32769,58728,272393,357,41311,8192,64,2049,5221,45404,283904,61565,318752,257,21792,46093,885]

theorem envBound41550 : H12AffineFastState.Bounded env41550 := by
  intro p hp
  have h : env41550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41549_41550 : H12AffineEnvironment.transform 16 37988 env41549 = env41550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37988 env41549 == env41550) = true)

theorem identity41550 : scanCanonicalize (H12AffineFastState.compose env41550 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 34817) := by decide +kernel

theorem selectedBound41550 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,37988,34817,1025,32769,58728,40968,357,41311,8192,64,2049,5221,45404,56577,61565,21793,257,21792,46093,885]

theorem envBound41551 : H12AffineFastState.Bounded env41551 := by
  intro p hp
  have h : env41551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41550_41551 : H12AffineEnvironment.transform 17 34817 env41550 = env41551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34817 env41550 == env41551) = true)

theorem identity41551 : scanCanonicalize (H12AffineFastState.compose env41551 (packedSelected [0,2,5,6,11,12,14,15,23,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound41551 : packedSelected [0,2,5,6,11,12,14,15,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,293,21874,5441,2340,1025,292,25677,8493,357,8314,8192,64,2049,5221,12409,23588,29016,21793,257,21792,13608,885]

theorem envBound41552 : H12AffineFastState.Bounded env41552 := by
  intro p hp
  have h : env41552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41551_41552 : H12AffineEnvironment.transform 14 293 env41551 = env41552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env41551 == env41552) = true)

theorem identity41552 : scanCanonicalize (H12AffineFastState.compose env41552 (packedSelected [2,3,4,5,6,10,11,12,15,16,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound41552 : packedSelected [2,3,4,5,6,10,11,12,15,16,22,23] rootPS < 2^1333 := by decide +kernel

def env41553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,293,8202,5441,2340,1025,292,4405,8493,357,8314,8192,64,2049,5221,12409,10588,1056,8281,257,8280,13608,885]

theorem envBound41553 : H12AffineFastState.Bounded env41553 := by
  intro p hp
  have h : env41553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41552_41553 : H12AffineEnvironment.transform 13 13688 env41552 = env41553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env41552 == env41553) = true)

theorem identity41553 : scanCanonicalize (H12AffineFastState.compose env41553 (packedSelected [1,2,3,4,5,7,8,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound41553 : packedSelected [1,2,3,4,5,7,8,10,14,16] rootPS < 2^1333 := by decide +kernel

def env41554 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3629,6997,293,3623,5441,2340,1025,292,4405,3840,357,3671,3629,64,2049,5221,7764,1905,1056,3700,257,3701,6917,885]

theorem envBound41554 : H12AffineFastState.Bounded env41554 := by
  intro p hp
  have h : env41554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41553_41554 : H12AffineEnvironment.transform 12 3629 env41553 = env41554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env41553 == env41554) = true)

theorem identity41554 : scanCanonicalize (H12AffineFastState.compose env41554 (packedSelected [0,1,4,6,8,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41554 : packedSelected [0,1,4,6,8,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env41555 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,3629,6768,0,3623,5220,2049,1025,1,4112,3621,64,3671,3629,64,2049,5221,7764,1620,1056,3700,36,3701,6688,592]

theorem envBound41555 : H12AffineFastState.Bounded env41555 := by
  intro p hp
  have h : env41555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41554_41555 : H12AffineEnvironment.transform 7 37 env41554 = env41555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41554 == env41555) = true)

theorem identity41555 : scanCanonicalize (H12AffineFastState.compose env41555 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound41555 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41556 : List Nat := [2,4,8,16,32,49,8,37,512,1024,2048,4096,3629,6657,0,3623,5141,2049,1025,1,4112,3621,49,3622,3629,49,2049,5140,7717,1573,1056,3589,36,3588,6688,545]

theorem envBound41556 : H12AffineFastState.Bounded env41556 := by
  intro p hp
  have h : env41556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41555_41556 : H12AffineEnvironment.transform 5 49 env41555 = env41556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env41555 == env41556) = true)

theorem identity41556 : scanCanonicalize (H12AffineFastState.compose env41556 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound41556 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41557 : List Nat := [2,4,8,16,32,49,8,37,512,1024,1541,4096,40,5124,0,34,5141,1540,1025,1,4112,32,49,35,40,49,1540,5140,4128,1573,1056,0,36,1,5157,545]

theorem envBound41557 : H12AffineFastState.Bounded env41557 := by
  intro p hp
  have h : env41557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41556_41557 : H12AffineEnvironment.transform 10 1541 env41556 = env41557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env41556 == env41557) = true)

theorem identity41557 : scanCanonicalize (H12AffineFastState.compose env41557 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound41557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41558 : List Nat := [2,4,8,16,32,49,8,37,512,21,528,4096,40,4113,0,34,4096,529,20,1,4112,32,49,35,40,49,529,4097,4128,560,53,0,36,1,4144,545]

theorem envBound41558 : H12AffineFastState.Bounded env41558 := by
  intro p hp
  have h : env41558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41557_41558 : H12AffineEnvironment.transform 9 21 env41557 = env41558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41557 == env41558) = true)

theorem identity41558 : scanCanonicalize (H12AffineFastState.compose env41558 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41558 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41559 : List Nat := [2,4,8,16,16,1,8,21,512,21,528,4096,24,4113,0,18,4096,529,20,1,4112,16,1,19,24,1,529,4097,4112,512,5,0,20,1,4096,529]

theorem envBound41559 : H12AffineFastState.Bounded env41559 := by
  intro p hp
  have h : env41559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41558_41559 : H12AffineEnvironment.transform 4 16 env41558 = env41559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41558 == env41559) = true)

theorem identity41559 : scanCanonicalize (H12AffineFastState.compose env41559 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41559 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41560 : List Nat := [2,4,8,1,1,1,8,4,512,4,513,4096,9,4096,0,3,4096,512,5,1,4097,1,1,2,9,1,512,4097,4097,512,5,0,5,1,4096,512]

theorem envBound41560 : H12AffineFastState.Bounded env41560 := by
  intro p hp
  have h : env41560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41559_41560 : H12AffineEnvironment.transform 3 1 env41559 = env41560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41559 == env41560) = true)

theorem identity41560 : scanCanonicalize (H12AffineFastState.compose env41560 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41561 : List Nat := [2,4,8,1,1,1,8,4,512,4,513,0,9,0,0,3,0,512,5,1,1,1,1,2,9,1,512,1,1,512,5,0,5,1,0,512]

theorem envBound41561 : H12AffineFastState.Bounded env41561 := by
  intro p hp
  have h : env41561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41560_41561 : H12AffineEnvironment.transform 11 0 env41560 = env41561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41560 == env41561) = true)

theorem identity41561 : scanCanonicalize (H12AffineFastState.compose env41561 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound41561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41562 : List Nat := [2,4,8,1,1,1,8,4,15,4,14,0,9,0,0,3,0,15,5,1,1,1,1,2,9,1,15,1,1,15,5,0,5,1,0,15]

theorem envBound41562 : H12AffineFastState.Bounded env41562 := by
  intro p hp
  have h : env41562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41561_41562 : H12AffineEnvironment.transform 8 15 env41561 = env41562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env41561 == env41562) = true)

def env41563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272392,169217,41310,8193,64,2048,163841,45405,283904,156697,411973,257,21792,46092,169745]

theorem envBound41563 : H12AffineFastState.Bounded env41563 := by
  intro p hp
  have h : env41563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41548_41563 : H12AffineEnvironment.transform 6 9 env41548 = env41563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41548 == env41563) = true)

theorem identity41563 : scanCanonicalize (H12AffineFastState.compose env41563 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound41563 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env41564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,160013,21792,169217,41310,8193,64,2048,163841,45405,10280,156697,144493,257,21792,46092,169745]

theorem envBound41564 : H12AffineFastState.Bounded env41564 := by
  intro p hp
  have h : env41564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41563_41564 : H12AffineEnvironment.transform 17 32040 env41563 = env41564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env41563 == env41564) = true)

theorem identity41564 : scanCanonicalize (H12AffineFastState.compose env41564 (packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound41564 : packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env41565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,160013,21792,155996,21763,8193,64,2048,160860,17664,10280,156697,144493,257,21792,16465,156492]

theorem envBound41565 : H12AffineFastState.Bounded env41565 := by
  intro p hp
  have h : env41565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41564_41565 : H12AffineEnvironment.transform 14 29789 env41564 = env41565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env41564 == env41565) = true)

theorem identity41565 : scanCanonicalize (H12AffineFastState.compose env41565 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41565 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env41566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,21620,34,131072,23809,1025,21621,151844,21792,147829,21763,40,64,2048,152693,17664,2049,148528,136260,257,21792,16465,148325]

theorem envBound41566 : H12AffineFastState.Bounded env41566 := by
  intro p hp
  have h : env41566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41565_41566 : H12AffineEnvironment.transform 12 41 env41565 = env41566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41565 == env41566) = true)

theorem identity41566 : scanCanonicalize (H12AffineFastState.compose env41566 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41566 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env41567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,373,34,131072,2048,1025,372,132133,33,136308,2,40,64,2048,131444,4097,2049,135473,136260,257,33,5456,136804]

theorem envBound41567 : H12AffineFastState.Bounded env41567 := by
  intro p hp
  have h : env41567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41566_41567 : H12AffineEnvironment.transform 13 5377 env41566 = env41567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41566 == env41567) = true)

theorem identity41567 : scanCanonicalize (H12AffineFastState.compose env41567 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4469) := by decide +kernel

theorem selectedBound41567 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5377,373,34,4469,2048,1025,372,5456,33,1281,2,40,64,2048,4097,4097,2049,68,1329,257,33,5456,1809]

theorem envBound41568 : H12AffineFastState.Bounded env41568 := by
  intro p hp
  have h : env41568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41567_41568 : H12AffineEnvironment.transform 16 4469 env41567 = env41568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4469 env41567 == env41568) = true)

theorem identity41568 : scanCanonicalize (H12AffineFastState.compose env41568 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound41568 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env41569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,41,3392,373,34,2356,2048,1025,372,3345,33,1281,2,40,64,2048,2112,2112,2049,68,1329,257,33,3345,1809]

theorem envBound41569 : H12AffineFastState.Bounded env41569 := by
  intro p hp
  have h : env41569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41568_41569 : H12AffineEnvironment.transform 11 2113 env41568 = env41569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env41568 == env41569) = true)

theorem identity41569 : scanCanonicalize (H12AffineFastState.compose env41569 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41569 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41570 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2113,41,2421,373,34,2356,2048,52,372,2340,33,308,2,40,64,2048,2112,2112,2049,68,260,257,33,2340,804]

theorem envBound41570 : H12AffineFastState.Bounded env41570 := by
  intro p hp
  have h : env41570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41569_41570 : H12AffineEnvironment.transform 9 53 env41569 = env41570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41569 == env41570) = true)

theorem identity41570 : scanCanonicalize (H12AffineFastState.compose env41570 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41570 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env41571 : List Nat := [2,4,8,16,32,64,9,116,512,53,2048,2113,41,2049,1,34,2112,2048,52,0,2128,33,64,2,40,64,2048,2112,2112,2049,68,112,117,33,2128,592]

theorem envBound41571 : H12AffineFastState.Bounded env41571 := by
  intro p hp
  have h : env41571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41570_41571 : H12AffineEnvironment.transform 7 116 env41570 = env41571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41570 == env41571) = true)

theorem identity41571 : scanCanonicalize (H12AffineFastState.compose env41571 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound41571 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41572 : List Nat := [2,4,8,16,32,48,9,4,512,53,2048,2097,41,2049,1,34,2096,2048,52,0,2080,33,48,2,40,48,2048,2096,2096,2049,52,0,5,33,2080,544]

theorem envBound41572 : H12AffineFastState.Bounded env41572 := by
  intro p hp
  have h : env41572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41571_41572 : H12AffineEnvironment.transform 5 48 env41571 = env41572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env41571 == env41572) = true)

theorem identity41572 : scanCanonicalize (H12AffineFastState.compose env41572 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41572 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41573 : List Nat := [2,4,8,16,1,17,9,4,512,20,2048,2064,8,2049,1,3,2065,2048,21,0,2049,0,17,2,9,17,2048,2065,2065,2049,21,0,5,0,2049,513]

theorem envBound41573 : H12AffineFastState.Bounded env41573 := by
  intro p hp
  have h : env41573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41572_41573 : H12AffineEnvironment.transform 4 1 env41572 = env41573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41572 == env41573) = true)

theorem identity41573 : scanCanonicalize (H12AffineFastState.compose env41573 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound41573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41574 : List Nat := [2,4,8,16,1,17,9,4,5,20,2048,2064,8,2049,1,3,2065,2048,21,0,2049,0,17,2,9,17,2048,2065,2065,2049,21,0,5,0,2049,4]

theorem envBound41574 : H12AffineFastState.Bounded env41574 := by
  intro p hp
  have h : env41574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41573_41574 : H12AffineEnvironment.transform 8 5 env41573 = env41574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env41573 == env41574) = true)

theorem identity41574 : scanCanonicalize (H12AffineFastState.compose env41574 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound41574 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41575 : List Nat := [2,4,8,2,1,3,9,4,5,6,2048,2050,8,2049,1,3,2051,2048,7,0,2049,0,3,2,9,3,2048,2051,2051,2049,7,0,5,0,2049,4]

theorem envBound41575 : H12AffineFastState.Bounded env41575 := by
  intro p hp
  have h : env41575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41574_41575 : H12AffineEnvironment.transform 3 2 env41574 = env41575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env41574 == env41575) = true)

theorem identity41575 : scanCanonicalize (H12AffineFastState.compose env41575 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41575 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41576 : List Nat := [0,4,8,0,1,1,9,4,5,4,2048,2048,8,2049,1,1,2049,2048,5,0,2049,0,1,0,9,1,2048,2049,2049,2049,5,0,5,0,2049,4]

theorem envBound41576 : H12AffineFastState.Bounded env41576 := by
  intro p hp
  have h : env41576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41575_41576 : H12AffineEnvironment.transform 0 0 env41575 = env41576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41575 == env41576) = true)

theorem identity41576 : scanCanonicalize (H12AffineFastState.compose env41576 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41576 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41577 : List Nat := [0,4,1,0,1,1,0,4,5,4,2048,2048,1,2049,1,1,2049,2048,5,0,2049,0,1,0,0,1,2048,2049,2049,2049,5,0,5,0,2049,4]

theorem envBound41577 : H12AffineFastState.Bounded env41577 := by
  intro p hp
  have h : env41577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41576_41577 : H12AffineEnvironment.transform 2 1 env41576 = env41577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41576 == env41577) = true)

def env41578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,8388608,8642569,8328,64,4464648,8393985,8529108,8830977,156697,12645453,257,21793,46212,213966]

theorem envBound41578 : H12AffineFastState.Bounded env41578 := by
  intro p hp
  have h : env41578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41472_41578 : H12AffineEnvironment.transform 20 160133 env41472 = env41578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160133 env41472 == env41578) = true)

def env41579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,4194304,169216,95497,8328,64,4464648,163841,45524,283905,156697,4350285,257,21793,46212,213966]

theorem envBound41579 : H12AffineFastState.Bounded env41579 := by
  intro p hp
  have h : env41579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41578_41579 : H12AffineEnvironment.transform 22 169216 env41578 = env41579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env41578 == env41579) = true)

def env41580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160133,272512,169216,95497,8328,64,2184,163841,45524,283905,156697,412109,257,21793,46212,213966]

theorem envBound41580 : H12AffineFastState.Bounded env41580 := by
  intro p hp
  have h : env41580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41579_41580 : H12AffineEnvironment.transform 21 272512 env41579 = env41580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41579 == env41580) = true)

def env41581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272392,169216,95497,8192,64,2048,163841,45404,283905,156697,411973,257,21793,46092,213830]

theorem envBound41581 : H12AffineFastState.Bounded env41581 := by
  intro p hp
  have h : env41581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41580_41581 : H12AffineEnvironment.transform 6 8 env41580 = env41581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41580 == env41581) = true)

def env41582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,58397,272392,16,95497,8192,64,2048,5393,45404,283905,61705,318549,257,21793,46092,120406]

theorem envBound41582 : H12AffineFastState.Bounded env41582 := by
  intro p hp
  have h : env41582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41581_41582 : H12AffineEnvironment.transform 16 38160 env41581 = env41582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env41581 == env41582) = true)

theorem identity41582 : scanCanonicalize (H12AffineFastState.compose env41582 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41582 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13388,262144,1025,8541,17729,272392,16,95497,8192,64,2048,5393,4096,283905,20565,294153,257,21793,5456,96010]

theorem envBound41583 : H12AffineFastState.Bounded env41583 := by
  intro p hp
  have h : env41583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41582_41583 : H12AffineEnvironment.transform 14 8540 env41582 = env41583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41582 == env41583) = true)

theorem identity41583 : scanCanonicalize (H12AffineFastState.compose env41583 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound41583 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env41584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13388,89379,1025,8541,17729,95531,16,95497,8192,64,2048,5393,4096,67618,20565,73770,257,21793,5456,96010]

theorem envBound41584 : H12AffineFastState.Bounded env41584 := by
  intro p hp
  have h : env41584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41583_41584 : H12AffineEnvironment.transform 17 89379 env41583 = env41584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env41583 == env41584) = true)

theorem identity41584 : scanCanonicalize (H12AffineFastState.compose env41584 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 28747) := by decide +kernel

theorem selectedBound41584 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env41585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,28747,13388,11624,1025,8541,17729,1376,16,1346,8192,64,2048,5393,4096,30825,20565,20577,257,21793,5456,1857]

theorem envBound41585 : H12AffineFastState.Bounded env41585 := by
  intro p hp
  have h : env41585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41584_41585 : H12AffineEnvironment.transform 15 28747 env41584 = env41585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28747 env41584 == env41585) = true)

theorem identity41585 : scanCanonicalize (H12AffineFastState.compose env41585 (packedSelected [0,3,5,7,11,12,14,19] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound41585 : packedSelected [0,3,5,7,11,12,14,19] rootPS < 2^1333 := by decide +kernel

def env41586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,8192,16384,8540,26927,11560,11624,1025,8541,17729,1376,16,1346,8192,64,2048,3189,2404,24845,18737,18693,257,19525,3124,1857]

theorem envBound41586 : H12AffineFastState.Bounded env41586 := by
  intro p hp
  have h : env41586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41585_41586 : H12AffineEnvironment.transform 11 2404 env41585 = env41586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env41585 == env41586) = true)

theorem identity41586 : scanCanonicalize (H12AffineFastState.compose env41586 (packedSelected [1,4,8,9,10,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 8313) := by decide +kernel

theorem selectedBound41586 : packedSelected [1,4,8,9,10,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2404,8192,8313,8540,2390,11560,11624,1025,8541,9528,1376,16,1346,8192,64,2048,3189,2404,372,10568,10620,257,11324,3124,1857]

theorem envBound41587 : H12AffineFastState.Bounded env41587 := by
  intro p hp
  have h : env41587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41586_41587 : H12AffineEnvironment.transform 13 8313 env41586 = env41587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8313 env41586 == env41587) = true)

theorem identity41587 : scanCanonicalize (H12AffineFastState.compose env41587 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,23] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound41587 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,23] rootPS < 2^1333 := by decide +kernel

def env41588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,308,8192,8313,8540,262,9592,9528,1025,8541,9528,1376,16,1346,8192,64,80,1061,308,372,8472,8492,257,9324,1124,1857]

theorem envBound41588 : H12AffineFastState.Bounded env41588 := by
  intro p hp
  have h : env41588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41587_41588 : H12AffineEnvironment.transform 10 80 env41587 = env41588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env41587 == env41588) = true)

theorem identity41588 : scanCanonicalize (H12AffineFastState.compose env41588 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41588 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41589 : List Nat := [2,4,8,16,32,64,8,116,512,1024,80,64,8192,8313,8232,114,9228,9292,1025,8233,9292,1044,16,1078,8192,64,80,1061,64,0,8300,8280,117,9324,1124,1589]

theorem envBound41589 : H12AffineFastState.Bounded env41589 := by
  intro p hp
  have h : env41589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41588_41589 : H12AffineEnvironment.transform 7 116 env41588 = env41589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41588 == env41589) = true)

end H12CloudChart1