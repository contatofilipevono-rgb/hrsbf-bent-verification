import H12CloudChart1Data190

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound48382 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env48383 : List Nat := [0,1,1,0,0,1,0,0,0,0,0,0,1,1,1,0,1,0,1,0,1,0,1,0,0,1,0,0,0,0,0,0,1,0,1,0]

theorem envBound48383 : H12AffineFastState.Bounded env48383 := by
  intro p hp
  have h : env48383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48382_48383 : H12AffineEnvironment.transform 0 0 env48382 = env48383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48382 == env48383) = true)

def env48384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253962,242968,8328,64,97666,139733,238875,335882,119042,272393,257,98815,90202,63189]

theorem envBound48384 : H12AffineFastState.Bounded env48384 := by
  intro p hp
  have h : env48384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48324_48384 : H12AffineEnvironment.transform 20 4161 env48324 = env48384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48324 == env48384) = true)

theorem identity48384 : scanCanonicalize (H12AffineFastState.compose env48384 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound48384 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272513,73755,95497,8328,64,97666,57796,91402,335882,119042,272393,257,98815,90202,63189]

theorem envBound48385 : H12AffineFastState.Bounded env48385 := by
  intro p hp
  have h : env48385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48384_48385 : H12AffineEnvironment.transform 16 49169 env48384 = env48385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env48384 == env48385) = true)

def env48386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1025,32769,4161,33,73755,95497,8328,64,97666,57796,91402,67754,119042,169,257,98815,90202,63189]

theorem envBound48386 : H12AffineFastState.Bounded env48386 := by
  intro p hp
  have h : env48386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48385_48386 : H12AffineEnvironment.transform 17 10400 env48385 = env48386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env48385 == env48386) = true)

theorem identity48386 : scanCanonicalize (H12AffineFastState.compose env48386 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound48386 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env48387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49169,10400,1025,32769,4161,33,153,21899,8328,64,23808,57796,17800,10280,61824,169,257,41341,16600,63189]

theorem envBound48387 : H12AffineFastState.Bounded env48387 := by
  intro p hp
  have h : env48387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48386_48387 : H12AffineEnvironment.transform 15 8322 env48386 = env48387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env48386 == env48387) = true)

theorem identity48387 : scanCanonicalize (H12AffineFastState.compose env48387 (packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound48387 : packedSelected [1,2,3,4,5,6,7,11,12,14,15,16,17,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env48388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8322,13509,10400,1025,29909,4161,33,153,21899,8328,64,23808,5392,17800,10280,1364,169,257,21929,16600,513]

theorem envBound48388 : H12AffineFastState.Bounded env48388 := by
  intro p hp
  have h : env48388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48387_48388 : H12AffineEnvironment.transform 14 29908 env48387 = env48388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env48387 == env48388) = true)

theorem identity48388 : scanCanonicalize (H12AffineFastState.compose env48388 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48388 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8322,13509,10400,1025,8660,4161,33,153,138,8328,64,2049,5392,4233,10280,1364,169,257,168,5593,513]

theorem envBound48389 : H12AffineFastState.Bounded env48389 := by
  intro p hp
  have h : env48389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48388_48389 : H12AffineEnvironment.transform 13 5377 env48388 = env48389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48388 == env48389) = true)

theorem identity48389 : scanCanonicalize (H12AffineFastState.compose env48389 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound48389 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env48390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5377,0,343,5392,2421,1025,1,4161,33,153,138,349,64,2049,5392,4233,2557,1364,169,257,168,5593,513]

theorem envBound48390 : H12AffineFastState.Bounded env48390 := by
  intro p hp
  have h : env48390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48389_48390 : H12AffineEnvironment.transform 12 469 env48389 = env48390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env48389 == env48390) = true)

theorem identity48390 : scanCanonicalize (H12AffineFastState.compose env48390 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48390 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env48391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,0,263,5392,2341,1025,1,4113,33,153,138,269,16,2049,5392,4233,2477,1284,169,257,168,5513,513]

theorem envBound48391 : H12AffineFastState.Bounded env48391 := by
  intro p hp
  have h : env48391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48390_48391 : H12AffineEnvironment.transform 5 16 env48390 = env48391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48390 == env48391) = true)

theorem identity48391 : scanCanonicalize (H12AffineFastState.compose env48391 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound48391 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env48392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3329,389,2048,0,263,2065,2341,1025,1,3344,33,153,138,269,16,2049,2065,3464,2477,1284,169,257,168,2184,513]

theorem envBound48392 : H12AffineFastState.Bounded env48392 := by
  intro p hp
  have h : env48392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48391_48392 : H12AffineEnvironment.transform 11 3329 env48391 = env48392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env48391 == env48392) = true)

theorem identity48392 : scanCanonicalize (H12AffineFastState.compose env48392 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48392 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48393 : List Nat := [2,4,8,16,32,16,128,256,512,52,2048,2357,389,2048,0,263,2065,2341,53,1,2340,33,153,138,269,16,2049,2065,2492,2477,304,169,257,168,2184,513]

theorem envBound48393 : H12AffineFastState.Bounded env48393 := by
  intro p hp
  have h : env48393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48392_48393 : H12AffineEnvironment.transform 9 52 env48392 = env48393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48392 == env48393) = true)

theorem identity48393 : scanCanonicalize (H12AffineFastState.compose env48393 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound48393 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env48394 : List Nat := [2,4,8,16,32,16,128,173,512,52,2048,2200,40,2048,0,170,2065,2184,53,1,2185,33,153,138,160,16,2049,2065,2065,2048,157,169,172,168,2184,513]

theorem envBound48394 : H12AffineFastState.Bounded env48394 := by
  intro p hp
  have h : env48394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48393_48394 : H12AffineEnvironment.transform 7 173 env48393 = env48394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env48393 == env48394) = true)

theorem identity48394 : scanCanonicalize (H12AffineFastState.compose env48394 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48394 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48395 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2065,40,2048,0,35,2065,2049,53,1,2048,33,16,3,41,16,2049,2065,2065,2048,20,32,37,33,2049,513]

theorem envBound48395 : H12AffineFastState.Bounded env48395 := by
  intro p hp
  have h : env48395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48394_48395 : H12AffineEnvironment.transform 6 9 env48394 = env48395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48394 == env48395) = true)

theorem identity48395 : scanCanonicalize (H12AffineFastState.compose env48395 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound48395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48396 : List Nat := [2,4,8,16,32,16,9,36,0,52,2048,2065,40,2048,0,35,2065,2049,53,1,2048,33,16,3,41,16,2049,2065,2065,2048,20,32,37,33,2049,1]

theorem envBound48396 : H12AffineFastState.Bounded env48396 := by
  intro p hp
  have h : env48396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48395_48396 : H12AffineEnvironment.transform 8 0 env48395 = env48396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env48395 == env48396) = true)

theorem identity48396 : scanCanonicalize (H12AffineFastState.compose env48396 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound48396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48397 : List Nat := [2,4,8,16,32,16,9,36,0,52,10,27,40,10,0,35,27,11,53,1,10,33,16,3,41,16,11,27,27,10,20,32,37,33,11,1]

theorem envBound48397 : H12AffineFastState.Bounded env48397 := by
  intro p hp
  have h : env48397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48396_48397 : H12AffineEnvironment.transform 10 10 env48396 = env48397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env48396 == env48397) = true)

def env48398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1025,32769,4161,32,73755,95497,8328,64,97666,57796,91402,67755,119042,168,257,98815,90202,63189]

theorem envBound48398 : H12AffineFastState.Bounded env48398 := by
  intro p hp
  have h : env48398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48385_48398 : H12AffineEnvironment.transform 17 10401 env48385 = env48398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env48385 == env48398) = true)

theorem identity48398 : scanCanonicalize (H12AffineFastState.compose env48398 (packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48398 : packedSelected [1,2,3,4,5,6,7,12,14,15,16,18,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env48399 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1025,32769,4161,32,73755,95277,8328,64,97446,57568,91182,67755,118822,168,37,98523,90202,63189]

theorem envBound48399 : H12AffineFastState.Bounded env48399 := by
  intro p hp
  have h : env48399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48398_48399 : H12AffineEnvironment.transform 7 36 env48398 = env48399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48398 == env48399) = true)

def env48400 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8432,65536,24801,10401,1025,8433,4161,32,73755,95277,8328,64,97446,16400,91182,67755,94422,168,37,73771,90202,22053]

theorem envBound48400 : H12AffineFastState.Bounded env48400 := by
  intro p hp
  have h : env48400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48399_48400 : H12AffineEnvironment.transform 14 8432 env48399 = env48400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env48399 == env48400) = true)

theorem identity48400 : scanCanonicalize (H12AffineFastState.compose env48400 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound48400 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48401 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8432,8323,24801,10401,1025,8433,4161,32,152,21678,8328,64,23589,16400,17581,10280,20565,168,37,168,16601,22053]

theorem envBound48401 : H12AffineFastState.Bounded env48401 := by
  intro p hp
  have h : env48401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48400_48401 : H12AffineEnvironment.transform 15 8323 env48400 = env48401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env48400 == env48401) = true)

theorem identity48401 : scanCanonicalize (H12AffineFastState.compose env48401 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48401 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env48402 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,13404,8432,8323,5309,10401,1025,8433,4161,32,152,8434,8328,64,10361,13388,12529,10280,9225,168,37,168,13445,8825]

theorem envBound48402 : H12AffineFastState.Bounded env48402 := by
  intro p hp
  have h : env48402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48401_48402 : H12AffineEnvironment.transform 13 13404 env48401 = env48402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48401 == env48402) = true)

theorem identity48402 : scanCanonicalize (H12AffineFastState.compose env48402 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound48402 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48403 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,240,5292,0,115,5309,2129,1025,1,4161,32,152,2,120,64,2185,5308,4097,2264,1273,168,37,168,5237,649]

theorem envBound48403 : H12AffineFastState.Bounded env48403 := by
  intro p hp
  have h : env48403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48402_48403 : H12AffineEnvironment.transform 12 240 env48402 = env48403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env48402 == env48403) = true)

theorem identity48403 : scanCanonicalize (H12AffineFastState.compose env48403 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48404 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,160,5292,0,35,5309,2049,1025,1,4113,32,152,2,40,16,2185,5308,4097,2184,1193,168,37,168,5157,649]

theorem envBound48404 : H12AffineFastState.Bounded env48404 := by
  intro p hp
  have h : env48404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48403_48404 : H12AffineEnvironment.transform 5 16 env48403 = env48404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48403 == env48404) = true)

def env48405 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8433,65536,24800,10401,1025,8432,4161,32,73755,95277,8328,64,97446,16401,91182,67755,94423,168,37,73770,90202,22052]

theorem envBound48405 : H12AffineFastState.Bounded env48405 := by
  intro p hp
  have h : env48405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48399_48405 : H12AffineEnvironment.transform 14 8433 env48399 = env48405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env48399 == env48405) = true)

theorem identity48405 : scanCanonicalize (H12AffineFastState.compose env48405 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound48405 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48406 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8433,8203,24800,10401,1025,8432,4161,32,16,21542,8328,64,23725,16401,17445,10400,20700,168,37,33,16465,22052]

theorem envBound48406 : H12AffineFastState.Bounded env48406 := by
  intro p hp
  have h : env48406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48405_48406 : H12AffineEnvironment.transform 15 8203 env48405 = env48406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env48405 == env48406) = true)

theorem identity48406 : scanCanonicalize (H12AffineFastState.compose env48406 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48406 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48407 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,13404,8433,8203,5308,10401,1025,8432,4161,32,16,8314,8328,64,10481,13389,12409,10400,9344,168,37,33,13325,8824]

theorem envBound48407 : H12AffineFastState.Bounded env48407 := by
  intro p hp
  have h : env48407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48406_48407 : H12AffineEnvironment.transform 13 13404 env48406 = env48407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48406 == env48407) = true)

theorem identity48407 : scanCanonicalize (H12AffineFastState.compose env48407 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48407 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env48408 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,13404,8312,8203,5173,10280,1025,8313,4161,32,16,8314,8193,64,10360,13389,12409,10281,9225,33,37,33,13325,8824]

theorem envBound48408 : H12AffineFastState.Bounded env48408 := by
  intro p hp
  have h : env48408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48407_48408 : H12AffineEnvironment.transform 6 9 env48407 = env48408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48407 == env48408) = true)

theorem identity48408 : scanCanonicalize (H12AffineFastState.compose env48408 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound48408 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48409 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,1,114,5173,2129,1025,0,4161,32,16,3,120,64,2049,5172,4096,2128,1136,33,37,33,5236,513]

theorem envBound48409 : H12AffineFastState.Bounded env48409 := by
  intro p hp
  have h : env48409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48408_48409 : H12AffineEnvironment.transform 12 121 env48408 = env48409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env48408 == env48409) = true)

theorem identity48409 : scanCanonicalize (H12AffineFastState.compose env48409 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound48409 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48410 : List Nat := [2,4,8,16,32,64,9,36,512,1024,90,4096,121,5157,1,114,5173,11,1025,0,4161,32,16,3,120,64,91,5172,4096,10,1136,33,37,33,5236,513]

theorem envBound48410 : H12AffineFastState.Bounded env48410 := by
  intro p hp
  have h : env48410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48409_48410 : H12AffineEnvironment.transform 10 90 env48409 = env48410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env48409 == env48410) = true)

theorem identity48410 : scanCanonicalize (H12AffineFastState.compose env48410 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound48410 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48411 : List Nat := [2,4,8,16,32,64,9,36,512,1024,90,81,121,1140,1,114,1124,11,1025,0,16,32,16,3,120,64,91,1125,81,10,1136,33,37,33,1061,513]

theorem envBound48411 : H12AffineFastState.Bounded env48411 := by
  intro p hp
  have h : env48411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48410_48411 : H12AffineEnvironment.transform 11 81 env48410 = env48411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env48410 == env48411) = true)

theorem identity48411 : scanCanonicalize (H12AffineFastState.compose env48411 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48411 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48412 : List Nat := [2,4,8,16,32,64,9,36,512,100,90,81,121,16,1,114,0,11,101,0,16,32,16,3,120,64,91,1,81,10,20,33,37,33,65,513]

theorem envBound48412 : H12AffineFastState.Bounded env48412 := by
  intro p hp
  have h : env48412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48411_48412 : H12AffineEnvironment.transform 9 100 env48411 = env48412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48411 == env48412) = true)

theorem identity48412 : scanCanonicalize (H12AffineFastState.compose env48412 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48413 : List Nat := [2,4,8,16,32,17,9,36,512,53,11,0,40,16,1,35,0,11,52,0,16,32,16,3,41,17,10,1,0,10,20,33,37,33,16,513]

theorem envBound48413 : H12AffineFastState.Bounded env48413 := by
  intro p hp
  have h : env48413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48412_48413 : H12AffineEnvironment.transform 5 17 env48412 = env48413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48412 == env48413) = true)

theorem identity48413 : scanCanonicalize (H12AffineFastState.compose env48413 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48414 : List Nat := [2,4,8,5,32,4,9,36,512,32,11,0,40,5,1,35,0,11,33,0,5,32,5,3,41,4,10,1,0,10,1,33,37,33,5,513]

theorem envBound48414 : H12AffineFastState.Bounded env48414 := by
  intro p hp
  have h : env48414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48413_48414 : H12AffineEnvironment.transform 3 5 env48413 = env48414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48413 == env48414) = true)

theorem identity48414 : scanCanonicalize (H12AffineFastState.compose env48414 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound48414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48415 : List Nat := [2,4,8,5,32,4,9,36,2,32,11,0,40,5,1,35,0,11,33,0,5,32,5,3,41,4,10,1,0,10,1,33,37,33,5,3]

theorem envBound48415 : H12AffineFastState.Bounded env48415 := by
  intro p hp
  have h : env48415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48414_48415 : H12AffineEnvironment.transform 8 2 env48414 = env48415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env48414 == env48415) = true)

theorem identity48415 : scanCanonicalize (H12AffineFastState.compose env48415 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound48415 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48416 : List Nat := [2,4,8,5,15,4,9,11,2,15,11,0,7,5,1,12,0,11,14,0,5,15,5,3,6,4,10,1,0,10,1,14,10,14,5,3]

theorem envBound48416 : H12AffineFastState.Bounded env48416 := by
  intro p hp
  have h : env48416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48415_48416 : H12AffineEnvironment.transform 4 15 env48415 = env48416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env48415 == env48416) = true)

theorem identity48416 : scanCanonicalize (H12AffineFastState.compose env48416 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48416 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env48417 : List Nat := [2,0,8,1,11,0,9,11,2,11,11,0,3,1,1,8,0,11,10,0,1,11,1,3,2,0,10,1,0,10,1,10,10,10,1,3]

theorem envBound48417 : H12AffineFastState.Bounded env48417 := by
  intro p hp
  have h : env48417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48416_48417 : H12AffineEnvironment.transform 1 0 env48416 = env48417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48416 == env48417) = true)

theorem identity48417 : scanCanonicalize (H12AffineFastState.compose env48417 (packedSelected [12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48417 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env48418 : List Nat := [2,0,3,1,0,0,2,0,2,0,0,0,3,1,1,3,0,0,1,0,1,0,1,3,2,0,1,1,0,1,1,1,1,1,1,3]

theorem envBound48418 : H12AffineFastState.Bounded env48418 := by
  intro p hp
  have h : env48418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48417_48418 : H12AffineEnvironment.transform 2 3 env48417 = env48418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48417 == env48418) = true)

def env48419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,253962,242969,8328,64,97667,2240917,2340186,335882,119043,2373705,257,2199999,2191386,63188]

theorem envBound48419 : H12AffineFastState.Bounded env48419 := by
  intro p hp
  have h : env48419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48323_48419 : H12AffineEnvironment.transform 23 242969 env48323 = env48419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env48323 == env48419) = true)

def env48420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,253962,242969,8328,64,97667,139733,238874,335882,119043,272393,257,98815,90202,63188]

theorem envBound48420 : H12AffineFastState.Bounded env48420 := by
  intro p hp
  have h : env48420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48419_48420 : H12AffineEnvironment.transform 20 4160 env48419 = env48420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48419 == env48420) = true)

theorem identity48420 : scanCanonicalize (H12AffineFastState.compose env48420 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound48420 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,318548,120014,98781,8328,64,97667,5393,102878,335882,119043,272393,257,98815,90202,63188]

theorem envBound48421 : H12AffineFastState.Bounded env48421 := by
  intro p hp
  have h : env48421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48420_48421 : H12AffineEnvironment.transform 16 13508 env48420 = env48421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env48420 == env48421) = true)

def env48422 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,119878,98645,8192,64,97547,5393,102742,335882,119043,272393,257,98679,90202,63068]

theorem envBound48422 : H12AffineFastState.Bounded env48422 := by
  intro p hp
  have h : env48422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48421_48422 : H12AffineEnvironment.transform 6 8 env48421 = env48422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48421 == env48422) = true)

theorem identity48422 : scanCanonicalize (H12AffineFastState.compose env48422 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound48422 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env48423 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35188,1025,32769,4160,21792,119878,98645,8192,64,97547,5393,102742,108926,119043,41341,257,98679,90202,63068]

theorem envBound48423 : H12AffineFastState.Bounded env48423 := by
  intro p hp
  have h : env48423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48422_48423 : H12AffineEnvironment.transform 17 35188 env48422 = env48423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env48422 == env48423) = true)

theorem identity48423 : scanCanonicalize (H12AffineFastState.compose env48423 (packedSelected [16,17,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound48423 : packedSelected [16,17,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env48424 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,13388,2420,1025,1,4160,21792,87110,65877,8192,64,97547,5393,69974,76158,86275,8573,257,65911,90202,30300]

theorem envBound48424 : H12AffineFastState.Bounded env48424 := by
  intro p hp
  have h : env48424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48423_48424 : H12AffineEnvironment.transform 14 0 env48423 = env48424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env48423 == env48424) = true)

theorem identity48424 : scanCanonicalize (H12AffineFastState.compose env48424 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound48424 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48425 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,65536,13388,2420,1025,1,4160,8573,73755,65877,8192,64,67926,5393,69974,76158,75102,8573,257,65911,70663,513]

theorem envBound48425 : H12AffineFastState.Bounded env48425 := by
  intro p hp
  have h : env48425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48424_48425 : H12AffineEnvironment.transform 13 13405 env48424 = env48425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env48424 == env48425) = true)

theorem identity48425 : scanCanonicalize (H12AffineFastState.compose env48425 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48425 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13388,2420,1025,1,4160,8573,17,8543,8192,64,10588,5393,12636,2420,1364,8573,257,8573,13325,513]

theorem envBound48426 : H12AffineFastState.Bounded env48426 := by
  intro p hp
  have h : env48426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48425_48426 : H12AffineEnvironment.transform 15 8202 env48425 = env48426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48425 == env48426) = true)

theorem identity48426 : scanCanonicalize (H12AffineFastState.compose env48426 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48426 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1025,1,4160,33,17,3,348,64,2048,5393,4096,2420,1364,33,257,33,5457,513]

theorem envBound48427 : H12AffineFastState.Bounded env48427 := by
  intro p hp
  have h : env48427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48426_48427 : H12AffineEnvironment.transform 12 348 env48426 = env48427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48426 == env48427) = true)

theorem identity48427 : scanCanonicalize (H12AffineFastState.compose env48427 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1134) := by decide +kernel

theorem selectedBound48427 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48428 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1134,4096,348,5377,0,342,5392,1306,1025,1,4160,33,17,3,348,64,1134,5393,4096,1306,1364,33,257,33,5457,513]

theorem envBound48428 : H12AffineFastState.Bounded env48428 := by
  intro p hp
  have h : env48428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48427_48428 : H12AffineEnvironment.transform 10 1134 env48427 = env48428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1134 env48427 == env48428) = true)

theorem identity48428 : scanCanonicalize (H12AffineFastState.compose env48428 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound48428 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48429 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1134,1125,348,356,0,342,373,1306,1025,1,1061,33,17,3,348,64,1134,372,1125,1306,1364,33,257,33,308,513]

theorem envBound48429 : H12AffineFastState.Bounded env48429 := by
  intro p hp
  have h : env48429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48428_48429 : H12AffineEnvironment.transform 11 1125 env48428 = env48429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env48428 == env48429) = true)

theorem identity48429 : scanCanonicalize (H12AffineFastState.compose env48429 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound48429 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env48430 : List Nat := [2,4,8,16,32,64,8,84,512,1024,1134,1125,8,48,0,2,33,1102,1025,1,1061,33,17,3,8,64,1134,32,1125,1102,1024,33,85,33,96,513]

theorem envBound48430 : H12AffineFastState.Bounded env48430 := by
  intro p hp
  have h : env48430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48429_48430 : H12AffineEnvironment.transform 7 84 env48429 = env48430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env48429 == env48430) = true)

def env48431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4160,318548,119879,98644,8193,64,97546,5393,102743,335882,119043,272393,257,98678,90202,63069]

theorem envBound48431 : H12AffineFastState.Bounded env48431 := by
  intro p hp
  have h : env48431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48421_48431 : H12AffineEnvironment.transform 6 9 env48421 = env48431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48421 == env48431) = true)

theorem identity48431 : scanCanonicalize (H12AffineFastState.compose env48431 (packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS)) = affineNative (2^(17+1) ^^^ 130395) := by decide +kernel

theorem selectedBound48431 : packedSelected [0,1,7,8,9,12,14,16,18,22,23,26,38] rootPS < 2^1333 := by decide +kernel

def env48432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130395,1025,32769,4160,73999,119879,98644,8193,64,97546,5393,102743,56657,119043,120146,257,98678,90202,63069]

theorem envBound48432 : H12AffineFastState.Bounded env48432 := by
  intro p hp
  have h : env48432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48431_48432 : H12AffineEnvironment.transform 17 130395 env48431 = env48432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130395 env48431 == env48432) = true)

theorem identity48432 : scanCanonicalize (H12AffineFastState.compose env48432 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,18,19,20,24,26,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound48432 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,16,18,19,20,24,26,28,32,35] rootPS < 2^1333 := by decide +kernel

def env48433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21874,13389,43049,1025,32769,4160,29821,33077,54310,8193,64,10360,5393,50213,56657,33905,32800,257,54276,13608,63069]

theorem envBound48433 : H12AffineFastState.Bounded env48433 := by
  intro p hp
  have h : env48433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48432_48433 : H12AffineEnvironment.transform 15 21874 env48432 = env48433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env48432 == env48433) = true)

theorem identity48433 : scanCanonicalize (H12AffineFastState.compose env48433 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48433 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env48434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21874,5393,35189,1025,32769,4160,21793,33077,54310,349,64,2340,5393,50213,56657,33905,32800,257,54276,5236,55041]

theorem envBound48434 : H12AffineFastState.Bounded env48434 := by
  intro p hp
  have h : env48434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48433_48434 : H12AffineEnvironment.transform 12 348 env48433 = env48434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48433 == env48434) = true)

theorem identity48434 : scanCanonicalize (H12AffineFastState.compose env48434 (packedSelected [1,8,12,15,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound48434 : packedSelected [1,8,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env48435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,293,21874,5393,2128,1025,292,4160,21793,16,21763,349,64,2340,5393,17664,23668,1364,261,257,21793,5236,22052]

theorem envBound48435 : H12AffineFastState.Bounded env48435 := by
  intro p hp
  have h : env48435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48434_48435 : H12AffineEnvironment.transform 14 293 env48434 = env48435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env48434 == env48435) = true)

theorem identity48435 : scanCanonicalize (H12AffineFastState.compose env48435 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48435 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,293,114,5393,2128,1025,292,4160,33,16,3,349,64,2340,5393,4096,2420,1364,261,257,33,5236,804]

theorem envBound48436 : H12AffineFastState.Bounded env48436 := by
  intro p hp
  have h : env48436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48435_48436 : H12AffineEnvironment.transform 13 5376 env48435 = env48436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48435 == env48436) = true)

theorem identity48436 : scanCanonicalize (H12AffineFastState.compose env48436 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound48436 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48437 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,80,114,5220,2128,1025,81,4160,33,16,3,40,64,2129,5220,4096,2049,1057,112,116,33,5236,593]

theorem envBound48437 : H12AffineFastState.Bounded env48437 := by
  intro p hp
  have h : env48437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48436_48437 : H12AffineEnvironment.transform 7 117 env48436 = env48437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48436 == env48437) = true)

theorem identity48437 : scanCanonicalize (H12AffineFastState.compose env48437 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48437 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48438 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5173,2049,1025,0,4113,33,16,3,40,17,2048,5173,4096,2049,1057,33,37,33,5157,512]

theorem envBound48438 : H12AffineFastState.Bounded env48438 := by
  intro p hp
  have h : env48438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48437_48438 : H12AffineEnvironment.transform 5 17 env48437 = env48438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48437 == env48438) = true)

theorem identity48438 : scanCanonicalize (H12AffineFastState.compose env48438 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48438 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48439 : List Nat := [2,4,8,16,32,17,9,36,512,4,2048,4096,41,4128,1,35,4145,2049,5,0,4113,33,16,3,40,17,2048,4145,4096,2049,37,33,37,33,4129,512]

theorem envBound48439 : H12AffineFastState.Bounded env48439 := by
  intro p hp
  have h : env48439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48438_48439 : H12AffineEnvironment.transform 9 4 env48438 = env48439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48438 == env48439) = true)

theorem identity48439 : scanCanonicalize (H12AffineFastState.compose env48439 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48439 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48440 : List Nat := [2,4,8,16,32,17,9,36,33,4,2048,4096,41,4128,1,35,4145,2049,5,0,4113,33,16,3,40,17,2048,4145,4096,2049,37,33,37,33,4129,33]

theorem envBound48440 : H12AffineFastState.Bounded env48440 := by
  intro p hp
  have h : env48440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48439_48440 : H12AffineEnvironment.transform 8 33 env48439 = env48440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48439 == env48440) = true)

theorem identity48440 : scanCanonicalize (H12AffineFastState.compose env48440 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound48440 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48441 : List Nat := [2,4,8,16,32,17,9,36,33,4,2048,2048,41,2080,1,35,2097,2049,5,0,2065,33,16,3,40,17,2048,2097,2048,2049,37,33,37,33,2081,33]

theorem envBound48441 : H12AffineFastState.Bounded env48441 := by
  intro p hp
  have h : env48441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48440_48441 : H12AffineEnvironment.transform 11 2048 env48440 = env48441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env48440 == env48441) = true)

theorem identity48441 : scanCanonicalize (H12AffineFastState.compose env48441 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound48441 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48442 : List Nat := [2,4,8,16,32,17,9,36,33,4,16,16,41,48,1,35,33,17,5,0,1,33,16,3,40,17,16,33,16,17,37,33,37,33,49,33]

theorem envBound48442 : H12AffineFastState.Bounded env48442 := by
  intro p hp
  have h : env48442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48441_48442 : H12AffineEnvironment.transform 10 16 env48441 = env48442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env48441 == env48442) = true)

theorem identity48442 : scanCanonicalize (H12AffineFastState.compose env48442 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48443 : List Nat := [2,4,8,16,0,17,9,4,1,4,16,16,9,16,1,3,1,17,5,0,1,1,16,3,8,17,16,1,16,17,5,1,5,1,17,1]

theorem envBound48443 : H12AffineFastState.Bounded env48443 := by
  intro p hp
  have h : env48443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48442_48443 : H12AffineEnvironment.transform 4 0 env48442 = env48443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48442 == env48443) = true)

def env48444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,253962,242969,8328,64,97667,139732,238875,335882,119043,272392,257,98814,90203,63188]

theorem envBound48444 : H12AffineFastState.Bounded env48444 := by
  intro p hp
  have h : env48444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48419_48444 : H12AffineEnvironment.transform 20 4161 env48419 = env48444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48419 == env48444) = true)

theorem identity48444 : scanCanonicalize (H12AffineFastState.compose env48444 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48444 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,400453,201951,213452,8328,64,97667,139732,217550,335882,75222,272392,257,95531,90203,513]

theorem envBound48445 : H12AffineFastState.Bounded env48445 := by
  intro p hp
  have h : env48445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48444_48445 : H12AffineEnvironment.transform 14 29909 env48444 = env48445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48444 == env48445) = true)

def env48446 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4161,400453,201815,213316,8192,64,97547,139612,217414,335882,75102,272392,257,95531,90203,513]

theorem envBound48446 : H12AffineFastState.Bounded env48446 := by
  intro p hp
  have h : env48446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48445_48446 : H12AffineEnvironment.transform 6 8 env48445 = env48446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48445 == env48446) = true)

theorem identity48446 : scanCanonicalize (H12AffineFastState.compose env48446 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound48446 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48447 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1025,29788,4161,156012,201815,213316,8192,64,97547,139612,217414,89379,75102,21793,257,95531,90203,513]

theorem envBound48447 : H12AffineFastState.Bounded env48447 := by
  intro p hp
  have h : env48447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48446_48447 : H12AffineEnvironment.transform 17 32041 env48446 = env48447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env48446 == env48447) = true)

theorem identity48447 : scanCanonicalize (H12AffineFastState.compose env48447 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound48447 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env48448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,131072,32041,1025,29788,4161,156012,136449,147474,8192,64,31837,139612,151568,23669,9224,21793,257,29821,24845,513]

theorem envBound48448 : H12AffineFastState.Bounded env48448 := by
  intro p hp
  have h : env48448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48447_48448 : H12AffineEnvironment.transform 15 342 env48447 = env48448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env48447 == env48448) = true)

theorem identity48448 : scanCanonicalize (H12AffineFastState.compose env48448 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound48448 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env48449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,342,131072,2421,1025,0,4161,136496,136449,144462,8192,64,2049,139612,140364,10281,9224,8573,257,33,5457,513]

theorem envBound48449 : H12AffineFastState.Bounded env48449 := by
  intro p hp
  have h : env48449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48448_48449 : H12AffineEnvironment.transform 13 13404 env48448 = env48449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env48448 == env48449) = true)

theorem identity48449 : scanCanonicalize (H12AffineFastState.compose env48449 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound48449 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,131072,2421,1025,0,4161,136496,136449,136467,349,64,2049,131073,132369,2420,1365,32,257,33,5457,513]

theorem envBound48450 : H12AffineFastState.Bounded env48450 := by
  intro p hp
  have h : env48450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48449_48450 : H12AffineEnvironment.transform 12 349 env48449 = env48450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env48449 == env48450) = true)

theorem identity48450 : scanCanonicalize (H12AffineFastState.compose env48450 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48450 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1025,0,4161,32,17,3,349,64,2049,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound48451 : H12AffineFastState.Bounded env48451 := by
  intro p hp
  have h : env48451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48450_48451 : H12AffineEnvironment.transform 16 5392 env48450 = env48451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48450 == env48451) = true)

theorem identity48451 : scanCanonicalize (H12AffineFastState.compose env48451 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound48451 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48452 : List Nat := [2,4,8,16,32,64,8,256,512,833,2048,4096,349,4672,1,342,4689,2421,832,0,4161,32,17,3,349,64,2049,4688,4097,2420,532,32,257,33,4624,513]

theorem envBound48452 : H12AffineFastState.Bounded env48452 := by
  intro p hp
  have h : env48452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48451_48452 : H12AffineEnvironment.transform 9 833 env48451 = env48452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env48451 == env48452) = true)

theorem identity48452 : scanCanonicalize (H12AffineFastState.compose env48452 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48452 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48453 : List Nat := [2,4,8,16,32,16,8,256,512,785,2048,4096,269,4624,1,262,4609,2341,784,0,4113,32,17,3,269,16,2049,4608,4097,2340,532,32,257,33,4624,513]

theorem envBound48453 : H12AffineFastState.Bounded env48453 := by
  intro p hp
  have h : env48453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48452_48453 : H12AffineEnvironment.transform 5 16 env48452 = env48453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48452 == env48453) = true)

theorem identity48453 : scanCanonicalize (H12AffineFastState.compose env48453 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 260) := by decide +kernel

theorem selectedBound48453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48454 : List Nat := [2,4,8,16,32,16,8,256,512,785,2048,260,269,788,1,262,773,2341,784,0,277,32,17,3,269,16,2049,772,261,2340,532,32,257,33,788,513]

theorem envBound48454 : H12AffineFastState.Bounded env48454 := by
  intro p hp
  have h : env48454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48453_48454 : H12AffineEnvironment.transform 11 260 env48453 = env48454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 260 env48453 == env48454) = true)

theorem identity48454 : scanCanonicalize (H12AffineFastState.compose env48454 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound48454 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48455 : List Nat := [2,4,8,16,32,16,8,256,512,785,292,260,269,788,1,262,773,1,784,0,277,32,17,3,269,16,293,772,261,0,532,32,257,33,788,513]

theorem envBound48455 : H12AffineFastState.Bounded env48455 := by
  intro p hp
  have h : env48455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48454_48455 : H12AffineEnvironment.transform 10 292 env48454 = env48455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env48454 == env48455) = true)

theorem identity48455 : scanCanonicalize (H12AffineFastState.compose env48455 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48455 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48456 : List Nat := [2,4,8,1,32,1,8,256,512,768,292,260,269,773,1,262,773,1,769,0,260,32,0,3,269,1,293,772,261,0,517,32,257,33,773,513]

theorem envBound48456 : H12AffineFastState.Bounded env48456 := by
  intro p hp
  have h : env48456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48455_48456 : H12AffineEnvironment.transform 3 1 env48455 = env48456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48455 == env48456) = true)

theorem identity48456 : scanCanonicalize (H12AffineFastState.compose env48456 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound48456 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48457 : List Nat := [2,4,8,1,32,1,8,256,261,5,292,260,269,0,1,262,0,1,4,0,260,32,0,3,269,1,293,1,261,0,256,32,257,33,0,260]

theorem envBound48457 : H12AffineFastState.Bounded env48457 := by
  intro p hp
  have h : env48457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48456_48457 : H12AffineEnvironment.transform 8 261 env48456 = env48457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env48456 == env48457) = true)

def env48458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4161,400453,201814,213317,8193,64,97546,139613,217415,335882,75103,272392,257,95531,90203,513]

theorem envBound48458 : H12AffineFastState.Bounded env48458 := by
  intro p hp
  have h : env48458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48445_48458 : H12AffineEnvironment.transform 6 9 env48445 = env48458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48445 == env48458) = true)

theorem identity48458 : scanCanonicalize (H12AffineFastState.compose env48458 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound48458 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,262144,1025,29789,4161,359519,29772,8543,8193,64,97546,82247,12637,335882,75103,272392,257,95531,90203,513]

theorem envBound48459 : H12AffineFastState.Bounded env48459 := by
  intro p hp
  have h : env48459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48458_48459 : H12AffineEnvironment.transform 16 90138 env48458 = env48459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env48458 == env48459) = true)

theorem identity48459 : scanCanonicalize (H12AffineFastState.compose env48459 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 22884) := by decide +kernel

theorem selectedBound48459 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48460 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,22884,1025,29789,4161,75067,29772,8543,8193,64,97546,82247,12637,96622,75103,29036,257,95531,90203,513]

theorem envBound48460 : H12AffineFastState.Bounded env48460 := by
  intro p hp
  have h : env48460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48459_48460 : H12AffineEnvironment.transform 17 22884 env48459 = env48460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 22884 env48459 == env48460) = true)

theorem identity48460 : scanCanonicalize (H12AffineFastState.compose env48460 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound48460 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48461 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,20759,12557,22884,1025,29789,4161,29740,29772,8543,8193,64,11293,4176,12637,10361,29768,29036,257,9276,12620,513]

theorem envBound48461 : H12AffineFastState.Bounded env48461 := by
  intro p hp
  have h : env48461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48460_48461 : H12AffineEnvironment.transform 15 20759 env48460 = env48461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env48460 == env48461) = true)

theorem identity48461 : scanCanonicalize (H12AffineFastState.compose env48461 (packedSelected [0,2,6,7,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48461 : packedSelected [0,2,6,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env48462 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21841,20759,4096,22884,1025,21840,4161,21793,21825,82,268,64,3344,4176,4176,2420,21829,20577,257,1329,4161,513]

theorem envBound48462 : H12AffineFastState.Bounded env48462 := by
  intro p hp
  have h : env48462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48461_48462 : H12AffineEnvironment.transform 12 269 env48461 = env48462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48461 == env48462) = true)

theorem identity48462 : scanCanonicalize (H12AffineFastState.compose env48462 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound48462 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,4452,1077,115,4096,2048,1025,1076,4161,1093,1061,82,268,64,3344,4176,4176,2420,1057,261,257,1329,4161,513]

theorem envBound48463 : H12AffineFastState.Bounded env48463 := by
  intro p hp
  have h : env48463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48462_48463 : H12AffineEnvironment.transform 13 4452 env48462 = env48463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env48462 == env48463) = true)

theorem identity48463 : scanCanonicalize (H12AffineFastState.compose env48463 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound48463 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env48464 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,269,4452,81,115,4096,2048,101,80,4161,33,65,82,268,64,2420,4176,4176,2420,69,261,257,341,4161,513]

theorem envBound48464 : H12AffineFastState.Bounded env48464 := by
  intro p hp
  have h : env48464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48463_48464 : H12AffineEnvironment.transform 9 100 env48463 = env48464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env48463 == env48464) = true)

theorem identity48464 : scanCanonicalize (H12AffineFastState.compose env48464 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48464 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48465 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,41,4160,81,115,4096,2048,101,80,4161,33,65,82,40,64,2128,4176,4176,2128,69,33,37,113,4161,513]

theorem envBound48465 : H12AffineFastState.Bounded env48465 := by
  intro p hp
  have h : env48465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48464_48465 : H12AffineEnvironment.transform 7 36 env48464 = env48465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48464 == env48465) = true)

theorem identity48465 : scanCanonicalize (H12AffineFastState.compose env48465 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48465 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48466 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4113,0,34,4096,2048,52,1,4112,33,16,3,40,17,2049,4097,4097,2049,20,33,37,32,4112,513]

theorem envBound48466 : H12AffineFastState.Bounded env48466 := by
  intro p hp
  have h : env48466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48465_48466 : H12AffineEnvironment.transform 5 17 env48465 = env48466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48465 == env48466) = true)

theorem identity48466 : scanCanonicalize (H12AffineFastState.compose env48466 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound48466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48467 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,1,41,16,0,34,1,2048,52,1,17,33,16,3,40,17,2049,0,0,2049,20,33,37,32,17,513]

theorem envBound48467 : H12AffineFastState.Bounded env48467 := by
  intro p hp
  have h : env48467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48466_48467 : H12AffineEnvironment.transform 11 1 env48466 = env48467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env48466 == env48467) = true)

theorem identity48467 : scanCanonicalize (H12AffineFastState.compose env48467 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound48467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48468 : List Nat := [2,4,8,16,32,17,9,36,512,53,555,1,41,16,0,34,1,555,52,1,17,33,16,3,40,17,554,0,0,554,20,33,37,32,17,513]

theorem envBound48468 : H12AffineFastState.Bounded env48468 := by
  intro p hp
  have h : env48468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48467_48468 : H12AffineEnvironment.transform 10 555 env48467 = env48468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env48467 == env48468) = true)

def env48469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,16777216,8328,64,16959643,18973836,2340186,335882,16933914,19369297,257,19014822,19055875,16991181]

theorem envBound48469 : H12AffineFastState.Bounded env48469 := by
  intro p hp
  have h : env48469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48322_48469 : H12AffineEnvironment.transform 21 452753 env48322 = env48469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env48322 == env48469) = true)

def env48470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,242968,8328,64,97667,2240916,2340186,335882,119042,2373705,257,2199998,2191387,63189]

theorem envBound48470 : H12AffineFastState.Bounded env48470 := by
  intro p hp
  have h : env48470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48469_48470 : H12AffineEnvironment.transform 23 242968 env48469 = env48470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env48469 == env48470) = true)

def env48471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253962,242968,8328,64,97667,139732,238874,335882,119042,272393,257,98814,90203,63189]

theorem envBound48471 : H12AffineFastState.Bounded env48471 := by
  intro p hp
  have h : env48471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48470_48471 : H12AffineEnvironment.transform 20 4160 env48470 = env48471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48470 == env48471) = true)

theorem identity48471 : scanCanonicalize (H12AffineFastState.compose env48471 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound48471 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329866,17,21763,8328,64,97667,115151,17665,335882,119042,272393,257,98814,90203,63189]

theorem envBound48472 : H12AffineFastState.Bounded env48472 := by
  intro p hp
  have h : env48472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48471_48472 : H12AffineEnvironment.transform 16 122907 env48471 = env48472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env48471 == env48472) = true)

def env48473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329730,17,21763,8192,64,97547,115015,17665,335882,119042,272393,257,98678,90203,63069]

theorem envBound48473 : H12AffineFastState.Bounded env48473 := by
  intro p hp
  have h : env48473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48472_48473 : H12AffineEnvironment.transform 6 8 env48472 = env48473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48472 == env48473) = true)

theorem identity48473 : scanCanonicalize (H12AffineFastState.compose env48473 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48473 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4160,73770,17,21763,8192,64,97547,115015,17665,67618,119042,33,257,98678,90203,63069]

theorem envBound48474 : H12AffineFastState.Bounded env48474 := by
  intro p hp
  have h : env48474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48473_48474 : H12AffineEnvironment.transform 17 10280 env48473 = env48474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48473 == env48474) = true)

theorem identity48474 : scanCanonicalize (H12AffineFastState.compose env48474 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound48474 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env48475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,46157,10280,1025,32769,4160,29820,17,21763,8192,64,10589,38161,17665,23668,34132,33,257,54560,13325,63069]

theorem envBound48475 : H12AffineFastState.Bounded env48475 := by
  intro p hp
  have h : env48475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48474_48475 : H12AffineEnvironment.transform 15 21590 env48474 = env48475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env48474 == env48475) = true)

theorem identity48475 : scanCanonicalize (H12AffineFastState.compose env48475 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound48475 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env48476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8203,46157,10280,1025,32769,4160,33,17,8542,8192,64,10589,38161,12636,10281,34132,33,257,41341,13325,33280]

theorem envBound48476 : H12AffineFastState.Bounded env48476 := by
  intro p hp
  have h : env48476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48475_48476 : H12AffineEnvironment.transform 13 13405 env48475 = env48476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env48475 == env48476) = true)

theorem identity48476 : scanCanonicalize (H12AffineFastState.compose env48476 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48476 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48477 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,32768,8203,46108,10280,1025,32769,4113,33,17,8463,8192,17,10508,38161,12557,10281,34053,33,257,41260,13325,33280]

theorem envBound48477 : H12AffineFastState.Bounded env48477 := by
  intro p hp
  have h : env48477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48476_48477 : H12AffineEnvironment.transform 5 17 env48476 = env48477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48476 == env48477) = true)

theorem identity48477 : scanCanonicalize (H12AffineFastState.compose env48477 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound48477 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48478 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2065,8192,11293,32768,8203,44045,10280,1025,32769,2048,33,17,8463,8192,17,10508,36096,10524,10281,34053,33,257,41260,11292,33280]

theorem envBound48478 : H12AffineFastState.Bounded env48478 := by
  intro p hp
  have h : env48478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48477_48478 : H12AffineEnvironment.transform 11 2065 env48477 = env48478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env48477 == env48478) = true)

theorem identity48478 : scanCanonicalize (H12AffineFastState.compose env48478 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound48478 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48479 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1281,1296,8192,8476,32768,8203,41228,9513,1025,32769,1281,33,17,8463,8192,17,9229,32769,9245,9512,34053,33,257,41260,8477,33280]

theorem envBound48479 : H12AffineFastState.Bounded env48479 := by
  intro p hp
  have h : env48479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48478_48479 : H12AffineEnvironment.transform 10 1281 env48478 = env48479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env48478 == env48479) = true)

theorem identity48479 : scanCanonicalize (H12AffineFastState.compose env48479 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound48479 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env48480 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1281,1296,1564,1792,32768,1559,34576,821,1025,32769,1281,33,17,1811,1564,17,529,32769,513,820,34053,33,257,34608,1793,33280]

theorem envBound48480 : H12AffineFastState.Bounded env48480 := by
  intro p hp
  have h : env48480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48479_48480 : H12AffineEnvironment.transform 12 1564 env48479 = env48480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env48479 == env48480) = true)

theorem identity48480 : scanCanonicalize (H12AffineFastState.compose env48480 (packedSelected [2,3,5,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound48480 : packedSelected [2,3,5,12,14] rootPS < 2^1333 := by decide +kernel

def env48481 : List Nat := [2,4,8,16,32,17,8,256,512,785,528,513,269,17,32768,262,32769,821,784,32769,528,33,17,2,269,17,529,32769,513,820,33300,33,257,32801,16,33280]

theorem envBound48481 : H12AffineFastState.Bounded env48481 := by
  intro p hp
  have h : env48481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48480_48481 : H12AffineEnvironment.transform 9 785 env48480 = env48481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env48480 == env48481) = true)

theorem identity48481 : scanCanonicalize (H12AffineFastState.compose env48481 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48481 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env48482 : List Nat := [2,4,8,16,32,17,8,37,512,564,528,513,40,17,32768,35,32769,528,565,32769,528,33,17,2,40,17,529,32769,513,529,33300,33,36,32801,16,33280]

theorem envBound48482 : H12AffineFastState.Bounded env48482 := by
  intro p hp
  have h : env48482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48481_48482 : H12AffineEnvironment.transform 7 37 env48481 = env48482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48481 == env48482) = true)

def env48483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,329731,17,21763,8193,64,97546,115014,17665,335882,119042,272393,257,98679,90203,63068]

theorem envBound48483 : H12AffineFastState.Bounded env48483 := by
  intro p hp
  have h : env48483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48472_48483 : H12AffineEnvironment.transform 6 9 env48472 = env48483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48472 == env48483) = true)

theorem identity48483 : scanCanonicalize (H12AffineFastState.compose env48483 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48483 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,35189,1025,32769,4160,98678,17,21763,8193,64,97546,115014,17665,108927,119042,41340,257,98679,90203,63068]

theorem envBound48484 : H12AffineFastState.Bounded env48484 := by
  intro p hp
  have h : env48484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48483_48484 : H12AffineEnvironment.transform 17 35189 env48483 = env48484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48483 == env48484) = true)

theorem identity48484 : scanCanonicalize (H12AffineFastState.compose env48484 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound48484 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env48485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,65536,90186,2340,1025,80,4160,65831,17,21763,8193,64,97546,82199,17665,76078,86355,8493,257,65830,90203,30221]

theorem envBound48485 : H12AffineFastState.Bounded env48485 := by
  intro p hp
  have h : env48485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48484_48485 : H12AffineEnvironment.transform 14 81 env48484 = env48485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env48484 == env48485) = true)

theorem identity48485 : scanCanonicalize (H12AffineFastState.compose env48485 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48485 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env48486 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,65536,79179,2340,1025,80,4160,65831,17,2,8193,64,75787,70678,4096,76078,66642,8493,257,65830,79194,8972]

theorem envBound48486 : H12AffineFastState.Bounded env48486 := by
  intro p hp
  have h : env48486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48485_48486 : H12AffineEnvironment.transform 13 5377 env48485 = env48486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48485 == env48486) = true)

theorem identity48486 : scanCanonicalize (H12AffineFastState.compose env48486 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48486 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env48487 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,81,65536,78959,2048,1025,80,4160,65539,17,2,8193,64,75787,70678,4096,75786,66642,8201,37,65538,78974,8744]

theorem envBound48487 : H12AffineFastState.Bounded env48487 := by
  intro p hp
  have h : env48487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48486_48487 : H12AffineEnvironment.transform 7 36 env48486 = env48487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48486 == env48487) = true)

theorem identity48487 : scanCanonicalize (H12AffineFastState.compose env48487 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48487 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env48488 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5157,81,8202,5221,2048,1025,80,4160,8201,17,2,8193,64,2049,13340,4096,2048,9304,8201,37,8200,5236,8744]

theorem envBound48488 : H12AffineFastState.Bounded env48488 := by
  intro p hp
  have h : env48488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48487_48488 : H12AffineEnvironment.transform 15 8202 env48487 = env48488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48487 == env48488) = true)

theorem identity48488 : scanCanonicalize (H12AffineFastState.compose env48488 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound48488 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48489 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,81,115,5221,2048,1025,80,4160,112,17,2,120,64,2049,5221,4096,2048,1057,112,37,113,5236,593]

theorem envBound48489 : H12AffineFastState.Bounded env48489 := by
  intro p hp
  have h : env48489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48488_48489 : H12AffineEnvironment.transform 12 121 env48488 = env48489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env48488 == env48489) = true)

theorem identity48489 : scanCanonicalize (H12AffineFastState.compose env48489 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound48489 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env48490 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,64,121,1125,81,115,1061,2048,1025,80,0,112,17,2,120,64,2049,1061,64,2048,1057,112,37,113,1076,593]

theorem envBound48490 : H12AffineFastState.Bounded env48490 := by
  intro p hp
  have h : env48490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48489_48490 : H12AffineEnvironment.transform 11 64 env48489 = env48490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env48489 == env48490) = true)

theorem identity48490 : scanCanonicalize (H12AffineFastState.compose env48490 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound48490 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env48491 : List Nat := [2,4,8,16,32,64,9,36,512,1024,81,64,121,1125,81,115,1061,81,1025,80,0,112,17,2,120,64,80,1061,64,81,1057,112,37,113,1076,593]

theorem envBound48491 : H12AffineFastState.Bounded env48491 := by
  intro p hp
  have h : env48491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48490_48491 : H12AffineEnvironment.transform 10 81 env48490 = env48491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env48490 == env48491) = true)

theorem identity48491 : scanCanonicalize (H12AffineFastState.compose env48491 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48491 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48492 : List Nat := [2,4,8,16,32,64,9,36,512,53,81,64,121,80,81,115,16,81,52,80,0,112,17,2,120,64,80,16,64,81,20,112,37,113,1,593]

theorem envBound48492 : H12AffineFastState.Bounded env48492 := by
  intro p hp
  have h : env48492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48491_48492 : H12AffineEnvironment.transform 9 53 env48491 = env48492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48491 == env48492) = true)

theorem identity48492 : scanCanonicalize (H12AffineFastState.compose env48492 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48492 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env48493 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,16,41,0,1,35,16,1,52,0,0,32,17,2,40,16,0,16,16,1,20,32,37,33,1,513]

theorem envBound48493 : H12AffineFastState.Bounded env48493 := by
  intro p hp
  have h : env48493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48492_48493 : H12AffineEnvironment.transform 5 16 env48492 = env48493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48492 == env48493) = true)

theorem identity48493 : scanCanonicalize (H12AffineFastState.compose env48493 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48494 : List Nat := [2,4,8,16,17,16,9,21,512,4,1,16,24,0,1,18,16,1,5,0,0,17,17,2,25,16,0,16,16,1,20,17,20,16,1,513]

theorem envBound48494 : H12AffineFastState.Bounded env48494 := by
  intro p hp
  have h : env48494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48493_48494 : H12AffineEnvironment.transform 4 17 env48493 = env48494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48493 == env48494) = true)

theorem identity48494 : scanCanonicalize (H12AffineFastState.compose env48494 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound48494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48495 : List Nat := [2,4,8,16,17,16,9,21,17,4,1,16,24,0,1,18,16,1,5,0,0,17,17,2,25,16,0,16,16,1,20,17,20,16,1,16]

theorem envBound48495 : H12AffineFastState.Bounded env48495 := by
  intro p hp
  have h : env48495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48494_48495 : H12AffineEnvironment.transform 8 17 env48494 = env48495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env48494 == env48495) = true)

def env48496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253962,242968,8328,64,97667,139733,238875,335882,119042,272392,257,98815,90202,63189]

theorem envBound48496 : H12AffineFastState.Bounded env48496 := by
  intro p hp
  have h : env48496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48470_48496 : H12AffineEnvironment.transform 20 4161 env48470 = env48496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48470 == env48496) = true)

theorem identity48496 : scanCanonicalize (H12AffineFastState.compose env48496 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48496 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452753,180224,169234,8328,64,23945,139733,165137,262144,61704,272392,257,41461,16464,63189]

theorem envBound48497 : H12AffineFastState.Bounded env48497 := by
  intro p hp
  have h : env48497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48496_48497 : H12AffineEnvironment.transform 15 8202 env48496 = env48497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48496 == env48497) = true)

def env48498 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452681,180224,169234,8272,64,23889,139533,165137,262144,61704,272392,257,41261,16464,62989]

theorem envBound48498 : H12AffineFastState.Bounded env48498 := by
  intro p hp
  have h : env48498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48497_48498 : H12AffineEnvironment.transform 6 88 env48497 = env48498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48497 == env48498) = true)

theorem identity48498 : scanCanonicalize (H12AffineFastState.compose env48498 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound48498 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48499 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57676,262144,1025,32769,4161,264453,8524,29790,8272,64,23889,49217,25693,262144,61704,272392,257,41261,16464,62989]

theorem envBound48499 : H12AffineFastState.Bounded env48499 := by
  intro p hp
  have h : env48499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48498_48499 : H12AffineEnvironment.transform 16 57676 env48498 = env48499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env48498 == env48499) = true)

theorem identity48499 : scanCanonicalize (H12AffineFastState.compose env48499 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48499 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env48500 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,8202,57676,10280,1025,32769,4161,8493,8524,29790,8272,64,23889,49217,25693,10280,61704,32,257,41261,16464,62989]

theorem envBound48500 : H12AffineFastState.Bounded env48500 := by
  intro p hp
  have h : env48500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48499_48500 : H12AffineEnvironment.transform 17 10280 env48499 = env48500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48499 == env48500) = true)

theorem identity48500 : scanCanonicalize (H12AffineFastState.compose env48500 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound48500 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48501 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21840,8202,13340,10280,1025,21841,4161,8493,8524,29790,8272,64,23889,5393,25693,10280,9304,32,257,29821,16464,9053]

theorem envBound48501 : H12AffineFastState.Bounded env48501 := by
  intro p hp
  have h : env48501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48500_48501 : H12AffineEnvironment.transform 14 21840 env48500 = env48501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env48500 == env48501) = true)

theorem identity48501 : scanCanonicalize (H12AffineFastState.compose env48501 (packedSelected [1,8,16,17,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48501 : packedSelected [1,8,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48502 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,8202,13340,10280,1025,21760,4112,8493,8477,29711,8193,17,23808,5393,25612,10280,9225,32,257,29740,16385,8972]

theorem envBound48502 : H12AffineFastState.Bounded env48502 := by
  intro p hp
  have h : env48502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48501_48502 : H12AffineEnvironment.transform 5 17 env48501 = env48502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48501 == env48502) = true)

theorem identity48502 : scanCanonicalize (H12AffineFastState.compose env48502 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound48502 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48503 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13609,8232,8202,13340,10280,1025,8233,4112,8493,8477,294,8193,17,10281,5393,4389,10280,9225,32,257,261,13608,8972]

theorem envBound48503 : H12AffineFastState.Bounded env48503 := by
  intro p hp
  have h : env48503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48502_48503 : H12AffineEnvironment.transform 13 13609 env48502 = env48503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env48502 == env48503) = true)

theorem identity48503 : scanCanonicalize (H12AffineFastState.compose env48503 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48503 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48504 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,8192,13576,8201,8202,13340,10249,1025,8200,4112,8460,8477,263,8193,17,10248,5393,4356,10249,9225,1,257,261,13577,8972]

theorem envBound48504 : H12AffineFastState.Bounded env48504 := by
  intro p hp
  have h : env48504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48503_48504 : H12AffineEnvironment.transform 4 1 env48503 = env48504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48503 == env48504) = true)

theorem identity48504 : scanCanonicalize (H12AffineFastState.compose env48504 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound48504 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env48505 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8192,13324,8201,8202,13340,10249,1025,8200,4112,8200,8217,3,8193,17,10248,5141,4096,10249,9225,1,5,1,13325,8712]

theorem envBound48505 : H12AffineFastState.Bounded env48505 := by
  intro p hp
  have h : env48505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48504_48505 : H12AffineEnvironment.transform 7 4 env48504 = env48505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env48504 == env48505) = true)

theorem identity48505 : scanCanonicalize (H12AffineFastState.compose env48505 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound48505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48506 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,25,5141,16,19,5125,2064,1025,17,4112,17,0,3,24,17,2065,5141,4096,2064,1040,1,5,1,5140,529]

theorem envBound48506 : H12AffineFastState.Bounded env48506 := by
  intro p hp
  have h : env48506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48505_48506 : H12AffineEnvironment.transform 12 25 env48505 = env48506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48505 == env48506) = true)

theorem identity48506 : scanCanonicalize (H12AffineFastState.compose env48506 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48506 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env48507 : List Nat := [2,4,8,0,1,1,9,4,512,1024,2048,4096,9,5125,0,3,5125,2048,1025,1,4096,1,0,3,8,1,2049,5125,4096,2048,1024,1,5,1,5124,513]

theorem envBound48507 : H12AffineFastState.Bounded env48507 := by
  intro p hp
  have h : env48507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48506_48507 : H12AffineEnvironment.transform 3 0 env48506 = env48507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48506 == env48507) = true)

theorem identity48507 : scanCanonicalize (H12AffineFastState.compose env48507 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound48507 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48508 : List Nat := [2,4,8,0,1,1,9,4,512,1024,2048,512,9,1541,0,3,1541,2048,1025,1,512,1,0,3,8,1,2049,1541,512,2048,1024,1,5,1,1540,513]

theorem envBound48508 : H12AffineFastState.Bounded env48508 := by
  intro p hp
  have h : env48508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48507_48508 : H12AffineEnvironment.transform 11 512 env48507 = env48508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env48507 == env48508) = true)

theorem identity48508 : scanCanonicalize (H12AffineFastState.compose env48508 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48508 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48509 : List Nat := [2,4,8,0,1,1,9,4,512,4,2048,512,9,513,0,3,513,2048,5,1,512,1,0,3,8,1,2049,513,512,2048,4,1,5,1,512,513]

theorem envBound48509 : H12AffineFastState.Bounded env48509 := by
  intro p hp
  have h : env48509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48508_48509 : H12AffineEnvironment.transform 9 4 env48508 = env48509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48508 == env48509) = true)

theorem identity48509 : scanCanonicalize (H12AffineFastState.compose env48509 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48510 : List Nat := [2,4,8,0,1,1,9,4,512,4,1,512,9,513,0,3,513,1,5,1,512,1,0,3,8,1,0,513,512,1,4,1,5,1,512,513]

theorem envBound48510 : H12AffineFastState.Bounded env48510 := by
  intro p hp
  have h : env48510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48509_48510 : H12AffineEnvironment.transform 10 1 env48509 = env48510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48509 == env48510) = true)

theorem identity48510 : scanCanonicalize (H12AffineFastState.compose env48510 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound48510 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48511 : List Nat := [2,4,8,0,1,1,9,4,1,4,1,1,9,0,0,3,0,1,5,1,1,1,0,3,8,1,0,0,1,1,4,1,5,1,1,0]

theorem envBound48511 : H12AffineFastState.Bounded env48511 := by
  intro p hp
  have h : env48511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48510_48511 : H12AffineEnvironment.transform 8 1 env48510 = env48511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env48510 == env48511) = true)

def env48512 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452680,180224,169234,8273,64,23888,139532,165137,262144,61704,272392,257,41260,16464,62988]

theorem envBound48512 : H12AffineFastState.Bounded env48512 := by
  intro p hp
  have h : env48512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48497_48512 : H12AffineEnvironment.transform 6 89 env48497 = env48512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env48497 == env48512) = true)

theorem identity48512 : scanCanonicalize (H12AffineFastState.compose env48512 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound48512 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48513 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,262144,1025,32769,4161,327000,54544,32770,8273,64,23888,13340,36865,262144,61704,272392,257,41260,16464,62988]

theorem envBound48513 : H12AffineFastState.Bounded env48513 := by
  intro p hp
  have h : env48513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48512_48513 : H12AffineEnvironment.transform 16 5392 env48512 = env48513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env48512 == env48513) = true)

theorem identity48513 : scanCanonicalize (H12AffineFastState.compose env48513 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48513 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env48514 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8202,5392,10280,1025,32769,4161,54640,54544,32770,8273,64,23888,13340,36865,10280,61704,32,257,41260,16464,62988]

theorem envBound48514 : H12AffineFastState.Bounded env48514 := by
  intro p hp
  have h : env48514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48513_48514 : H12AffineEnvironment.transform 17 10280 env48513 = env48514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48513 == env48514) = true)

theorem identity48514 : scanCanonicalize (H12AffineFastState.compose env48514 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound48514 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48515 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21841,8202,5392,10280,1025,21840,4161,33,65,21843,8273,64,23888,13340,17744,10280,9305,32,257,29821,16464,9053]

theorem envBound48515 : H12AffineFastState.Bounded env48515 := by
  intro p hp
  have h : env48515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48514_48515 : H12AffineEnvironment.transform 14 21841 env48514 = env48515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env48514 == env48515) = true)

theorem identity48515 : scanCanonicalize (H12AffineFastState.compose env48515 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48515 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48516 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21841,342,5392,2420,1025,21840,4161,33,65,21843,269,64,23888,5440,17744,2420,1285,32,257,21793,16464,513]

theorem envBound48516 : H12AffineFastState.Bounded env48516 := by
  intro p hp
  have h : env48516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48515_48516 : H12AffineEnvironment.transform 12 348 env48515 = env48516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48515 == env48516) = true)

theorem identity48516 : scanCanonicalize (H12AffineFastState.compose env48516 (packedSelected [2,6,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound48516 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env48517 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5376,81,342,5392,2420,1025,80,4161,33,65,83,269,64,2128,5440,4176,2420,1285,32,257,33,5456,513]

theorem envBound48517 : H12AffineFastState.Bounded env48517 := by
  intro p hp
  have h : env48517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48516_48517 : H12AffineEnvironment.transform 13 5376 env48516 = env48517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env48516 == env48517) = true)

def env48518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,253962,242969,8328,64,97666,2240917,2340186,335882,119043,2373704,257,2199999,2191386,63188]

theorem envBound48518 : H12AffineFastState.Bounded env48518 := by
  intro p hp
  have h : env48518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48469_48518 : H12AffineEnvironment.transform 23 242969 env48469 = env48518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env48469 == env48518) = true)

def env48519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,253962,242969,8328,64,97666,139733,238874,335882,119043,272392,257,98815,90202,63188]

theorem envBound48519 : H12AffineFastState.Bounded env48519 := by
  intro p hp
  have h : env48519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48518_48519 : H12AffineEnvironment.transform 20 4160 env48518 = env48519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env48518 == env48519) = true)

theorem identity48519 : scanCanonicalize (H12AffineFastState.compose env48519 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound48519 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4160,452753,144597,156102,8328,64,43357,139733,160197,324821,1500,272392,257,21792,46213,63188]

theorem envBound48520 : H12AffineFastState.Bounded env48520 := by
  intro p hp
  have h : env48520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48519_48520 : H12AffineEnvironment.transform 15 54495 env48519 = env48520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env48519 == env48520) = true)

def env48521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1025,32769,4160,305361,29845,8582,8328,64,43357,24981,12677,324821,1500,272392,257,21792,46213,63188]

theorem envBound48521 : H12AffineFastState.Bounded env48521 := by
  intro p hp
  have h : env48521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48520_48521 : H12AffineEnvironment.transform 16 16448 env48520 = env48521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env48520 == env48521) = true)

theorem identity48521 : scanCanonicalize (H12AffineFastState.compose env48521 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound48521 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33166,5393,262144,1025,32769,4160,305361,8644,8582,8328,64,43357,13508,12677,303492,1500,272392,257,113,46213,41861]

theorem envBound48522 : H12AffineFastState.Bounded env48522 := by
  intro p hp
  have h : env48522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48521_48522 : H12AffineEnvironment.transform 13 5457 env48521 = env48522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env48521 == env48522) = true)

theorem identity48522 : scanCanonicalize (H12AffineFastState.compose env48522 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48522 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env48523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33166,5393,10280,1025,32769,4160,33017,8644,8582,8328,64,43357,13508,12677,35244,1500,32,257,113,46213,41861]

theorem envBound48523 : H12AffineFastState.Bounded env48523 := by
  intro p hp
  have h : env48523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48522_48523 : H12AffineEnvironment.transform 17 10280 env48522 = env48523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48522 == env48523) = true)

theorem identity48523 : scanCanonicalize (H12AffineFastState.compose env48523 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48523 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env48524 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,33166,5393,10280,1025,32769,4113,32936,8597,8582,8328,17,43276,13461,12677,35244,1421,32,257,32,46213,41861]

theorem envBound48524 : H12AffineFastState.Bounded env48524 := by
  intro p hp
  have h : env48524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48523_48524 : H12AffineEnvironment.transform 5 17 env48523 = env48524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48523 == env48524) = true)

theorem identity48524 : scanCanonicalize (H12AffineFastState.compose env48524 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound48524 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,32768,33166,5393,2476,1025,32769,4113,32936,17,2,268,17,34952,5393,4097,35244,1421,32,257,32,38145,33281]

theorem envBound48525 : H12AffineFastState.Bounded env48525 := by
  intro p hp
  have h : env48525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48524_48525 : H12AffineEnvironment.transform 12 388 env48524 = env48525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env48524 == env48525) = true)

theorem identity48525 : scanCanonicalize (H12AffineFastState.compose env48525 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound48525 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env48526 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,429,35,5393,2476,1025,428,4113,261,17,2,268,17,2341,5393,4097,2049,1421,32,257,32,5292,940]

theorem envBound48526 : H12AffineFastState.Bounded env48526 := by
  intro p hp
  have h : env48526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48525_48526 : H12AffineEnvironment.transform 14 429 env48525 = env48526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env48525 == env48526) = true)

theorem identity48526 : scanCanonicalize (H12AffineFastState.compose env48526 (packedSelected [2,3,4,5,6,7,11,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound48526 : packedSelected [2,3,4,5,6,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env48527 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,4096,388,5376,429,35,5393,1,1025,428,4113,261,17,2,268,17,136,5393,4097,428,1421,32,257,32,5292,940]

theorem envBound48527 : H12AffineFastState.Bounded env48527 := by
  intro p hp
  have h : env48527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48526_48527 : H12AffineEnvironment.transform 10 429 env48526 = env48527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env48526 == env48527) = true)

theorem identity48527 : scanCanonicalize (H12AffineFastState.compose env48527 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound48527 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env48528 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,48,388,1328,429,35,1313,1,1025,428,33,261,17,2,268,17,136,1313,49,428,1421,32,257,32,1180,940]

theorem envBound48528 : H12AffineFastState.Bounded env48528 := by
  intro p hp
  have h : env48528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48527_48528 : H12AffineEnvironment.transform 11 48 env48527 = env48528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48527 == env48528) = true)

theorem identity48528 : scanCanonicalize (H12AffineFastState.compose env48528 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound48528 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48529 : List Nat := [2,4,8,16,32,17,128,256,512,305,429,48,388,1,429,35,16,1,304,428,33,261,17,2,268,17,136,16,49,428,188,32,257,32,429,940]

theorem envBound48529 : H12AffineFastState.Bounded env48529 := by
  intro p hp
  have h : env48529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48528_48529 : H12AffineEnvironment.transform 9 305 env48528 = env48529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env48528 == env48529) = true)

theorem identity48529 : scanCanonicalize (H12AffineFastState.compose env48529 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48529 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48530 : List Nat := [2,4,8,16,32,17,128,37,512,20,136,48,161,1,136,35,16,1,21,137,33,32,17,2,41,17,136,16,49,137,188,32,36,32,136,649]

theorem envBound48530 : H12AffineFastState.Bounded env48530 := by
  intro p hp
  have h : env48530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48529_48530 : H12AffineEnvironment.transform 7 37 env48529 = env48530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48529 == env48530) = true)

theorem identity48530 : scanCanonicalize (H12AffineFastState.compose env48530 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 156) := by decide +kernel

theorem selectedBound48530 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48531 : List Nat := [2,4,8,16,32,17,128,37,156,20,136,48,161,1,136,35,16,1,21,137,33,32,17,2,41,17,136,16,49,137,188,32,36,32,136,21]

theorem envBound48531 : H12AffineFastState.Bounded env48531 := by
  intro p hp
  have h : env48531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48530_48531 : H12AffineEnvironment.transform 8 156 env48530 = env48531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 156 env48530 == env48531) = true)

def env48532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16449,262144,1025,32769,4160,305360,29844,8583,8328,64,43357,24980,12676,324821,1500,272392,257,21792,46213,63188]

theorem envBound48532 : H12AffineFastState.Bounded env48532 := by
  intro p hp
  have h : env48532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48520_48532 : H12AffineEnvironment.transform 16 16449 env48520 = env48532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env48520 == env48532) = true)

theorem identity48532 : scanCanonicalize (H12AffineFastState.compose env48532 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound48532 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,32768,33031,5529,262144,1025,32769,4160,305360,8524,8583,8328,64,43357,13388,12676,303373,1500,272392,257,248,46213,41740]

theorem envBound48533 : H12AffineFastState.Bounded env48533 := by
  intro p hp
  have h : env48533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48532_48533 : H12AffineEnvironment.transform 13 5592 env48532 = env48533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env48532 == env48533) = true)

theorem identity48533 : scanCanonicalize (H12AffineFastState.compose env48533 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound48533 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env48534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,32768,33031,5529,35245,1025,32769,4160,8573,8524,8583,8328,64,43357,13388,12676,10400,1500,41381,257,248,46213,41740]

theorem envBound48534 : H12AffineFastState.Bounded env48534 := by
  intro p hp
  have h : env48534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48533_48534 : H12AffineEnvironment.transform 17 35245 env48533 = env48534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env48533 == env48534) = true)

theorem identity48534 : scanCanonicalize (H12AffineFastState.compose env48534 (packedSelected [0,1,2,6,7,8,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound48534 : packedSelected [0,1,2,6,7,8,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8660,8403,5529,10361,1025,8661,4160,8573,8524,8583,8328,64,2185,13388,12676,10400,1500,113,257,248,5457,728]

theorem envBound48535 : H12AffineFastState.Bounded env48535 := by
  intro p hp
  have h : env48535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48534_48535 : H12AffineEnvironment.transform 14 8660 env48534 = env48535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env48534 == env48535) = true)

theorem identity48535 : scanCanonicalize (H12AffineFastState.compose env48535 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound48535 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env48536 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5376,8460,8203,5441,10361,1025,8461,4160,8573,8524,8543,8272,64,2129,13388,12636,10360,1284,113,257,32,5457,512]

theorem envBound48536 : H12AffineFastState.Bounded env48536 := by
  intro p hp
  have h : env48536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48535_48536 : H12AffineEnvironment.transform 6 88 env48535 = env48536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48535 == env48536) = true)

theorem identity48536 : scanCanonicalize (H12AffineFastState.compose env48536 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2373) := by decide +kernel

theorem selectedBound48536 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48537 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,2373,8192,3141,8460,8203,3076,10361,1025,8461,2309,8573,8524,8543,8272,64,2129,11529,10265,10360,1284,113,257,32,3092,512]

theorem envBound48537 : H12AffineFastState.Bounded env48537 := by
  intro p hp
  have h : env48537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48536_48537 : H12AffineEnvironment.transform 11 2373 env48536 = env48537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2373 env48536 == env48537) = true)

theorem identity48537 : scanCanonicalize (H12AffineFastState.compose env48537 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48537 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env48538 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,2144,8192,3141,8233,8203,3076,10361,1025,8232,2080,8280,8297,8314,8272,64,2129,11308,10265,10360,1057,113,36,32,3092,512]

theorem envBound48538 : H12AffineFastState.Bounded env48538 := by
  intro p hp
  have h : env48538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48537_48538 : H12AffineEnvironment.transform 7 37 env48537 = env48538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48537 == env48538) = true)

theorem identity48538 : scanCanonicalize (H12AffineFastState.compose env48538 (packedSelected [4,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound48538 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env48539 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,2144,8,3141,33,3,3076,2161,1025,32,2080,80,97,114,88,64,2129,3108,2065,2160,1057,113,36,32,3092,512]

theorem envBound48539 : H12AffineFastState.Bounded env48539 := by
  intro p hp
  have h : env48539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48538_48539 : H12AffineEnvironment.transform 12 8 env48538 = env48539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env48538 == env48539) = true)

theorem identity48539 : scanCanonicalize (H12AffineFastState.compose env48539 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48539 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env48540 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,2096,8,3093,33,3,3076,2081,1025,32,2080,0,49,34,8,16,2049,3108,2065,2080,1057,33,36,32,3092,512]

theorem envBound48540 : H12AffineFastState.Bounded env48540 := by
  intro p hp
  have h : env48540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48539_48540 : H12AffineEnvironment.transform 5 16 env48539 = env48540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48539 == env48540) = true)

theorem identity48540 : scanCanonicalize (H12AffineFastState.compose env48540 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound48540 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48541 : List Nat := [2,4,8,16,32,16,8,37,512,1024,555,539,8,1598,33,3,1583,522,1025,32,523,0,49,34,8,16,554,1551,570,523,1057,33,36,32,1599,512]

theorem envBound48541 : H12AffineFastState.Bounded env48541 := by
  intro p hp
  have h : env48541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48540_48541 : H12AffineEnvironment.transform 10 555 env48540 = env48541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env48540 == env48541) = true)

theorem identity48541 : scanCanonicalize (H12AffineFastState.compose env48541 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound48541 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env48542 : List Nat := [2,4,8,3,32,3,8,37,512,1024,555,520,8,1581,33,3,1583,522,1025,32,523,0,34,34,8,3,554,1551,553,523,1057,33,36,32,1580,512]

theorem envBound48542 : H12AffineFastState.Bounded env48542 := by
  intro p hp
  have h : env48542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48541_48542 : H12AffineEnvironment.transform 3 3 env48541 = env48542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env48541 == env48542) = true)

theorem identity48542 : scanCanonicalize (H12AffineFastState.compose env48542 (packedSelected [0,1,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48542 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env48543 : List Nat := [2,4,8,3,0,3,8,5,512,1024,523,520,8,1549,1,3,1551,522,1025,0,523,0,2,2,8,3,522,1551,521,523,1025,1,4,0,1548,512]

theorem envBound48543 : H12AffineFastState.Bounded env48543 := by
  intro p hp
  have h : env48543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48542_48543 : H12AffineEnvironment.transform 4 0 env48542 = env48543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48542 == env48543) = true)

theorem identity48543 : scanCanonicalize (H12AffineFastState.compose env48543 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 7) := by decide +kernel

theorem selectedBound48543 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48544 : List Nat := [2,4,8,3,0,3,8,5,512,7,523,520,8,522,1,3,520,522,6,0,523,0,2,2,8,3,522,520,521,523,6,1,4,0,523,512]

theorem envBound48544 : H12AffineFastState.Bounded env48544 := by
  intro p hp
  have h : env48544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48543_48544 : H12AffineEnvironment.transform 9 7 env48543 = env48544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 7 env48543 == env48544) = true)

theorem identity48544 : scanCanonicalize (H12AffineFastState.compose env48544 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound48544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48545 : List Nat := [2,4,8,3,0,3,8,5,12,7,7,4,8,6,1,3,4,6,6,0,7,0,2,2,8,3,6,4,5,7,6,1,4,0,7,12]

theorem envBound48545 : H12AffineFastState.Bounded env48545 := by
  intro p hp
  have h : env48545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48544_48545 : H12AffineEnvironment.transform 8 12 env48544 = env48545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env48544 == env48545) = true)

def env48546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,253962,242969,8328,64,97666,139732,238875,335882,119043,272393,257,98814,90203,63188]

theorem envBound48546 : H12AffineFastState.Bounded env48546 := by
  intro p hp
  have h : env48546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48518_48546 : H12AffineEnvironment.transform 20 4161 env48518 = env48546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env48518 == env48546) = true)

theorem identity48546 : scanCanonicalize (H12AffineFastState.compose env48546 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound48546 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,4161,392287,62660,41431,8328,64,97666,79130,45525,335882,119043,272393,257,98814,90203,63188]

theorem envBound48547 : H12AffineFastState.Bounded env48547 := by
  intro p hp
  have h : env48547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48546_48547 : H12AffineEnvironment.transform 16 70862 env48546 = env48547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env48546 == env48547) = true)

theorem identity48547 : scanCanonicalize (H12AffineFastState.compose env48547 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound48547 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70862,262144,1025,29908,4161,329866,17,21762,8328,64,97666,79130,17664,335882,75222,272393,257,95531,90203,513]

theorem envBound48548 : H12AffineFastState.Bounded env48548 := by
  intro p hp
  have h : env48548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48547_48548 : H12AffineEnvironment.transform 14 29909 env48547 = env48548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env48547 == env48548) = true)

theorem identity48548 : scanCanonicalize (H12AffineFastState.compose env48548 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48548 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env48549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,262144,1025,29788,4161,329730,17,21762,8192,64,97546,79130,17664,335882,75102,272393,257,95531,90203,513]

theorem envBound48549 : H12AffineFastState.Bounded env48549 := by
  intro p hp
  have h : env48549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48548_48549 : H12AffineEnvironment.transform 6 8 env48548 = env48549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48548 == env48549) = true)

theorem identity48549 : scanCanonicalize (H12AffineFastState.compose env48549 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound48549 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env48550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,10280,1025,29788,4161,73770,17,21762,8192,64,97546,79130,17664,67618,75102,33,257,95531,90203,513]

theorem envBound48550 : H12AffineFastState.Bounded env48550 := by
  intro p hp
  have h : env48550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48549_48550 : H12AffineEnvironment.transform 17 10280 env48549 = env48550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env48549 == env48550) = true)

theorem identity48550 : scanCanonicalize (H12AffineFastState.compose env48550 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound48550 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env48551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,65536,70726,10280,1025,81,4161,73770,17,8463,8192,64,67847,79130,12557,67618,75102,33,257,65830,70742,513]

theorem envBound48551 : H12AffineFastState.Bounded env48551 := by
  intro p hp
  have h : env48551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48550_48551 : H12AffineEnvironment.transform 13 13325 env48550 = env48551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env48550 == env48551) = true)

theorem identity48551 : scanCanonicalize (H12AffineFastState.compose env48551 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48551 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env48552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,80,65536,70726,2420,1025,81,4161,65910,17,83,348,64,67847,70726,4177,67618,66562,33,257,65830,70742,513]

theorem envBound48552 : H12AffineFastState.Bounded env48552 := by
  intro p hp
  have h : env48552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48551_48552 : H12AffineEnvironment.transform 12 348 env48551 = env48552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48551 == env48552) = true)

theorem identity48552 : scanCanonicalize (H12AffineFastState.compose env48552 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound48552 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,80,262,5440,2420,1025,81,4161,112,17,83,348,64,2049,5440,4177,2340,1284,33,257,32,5456,513]

theorem envBound48553 : H12AffineFastState.Bounded env48553 := by
  intro p hp
  have h : env48553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48552_48553 : H12AffineEnvironment.transform 15 262 env48552 = env48553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env48552 == env48553) = true)

def env48554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound48554 : H12AffineFastState.Bounded env48554 := by
  intro p hp
  have h : env48554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47756_48554 : H12AffineEnvironment.transform 25 65 env47756 = env48554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env47756 == env48554) = true)

def env48555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound48555 : H12AffineFastState.Bounded env48555 := by
  intro p hp
  have h : env48555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48554_48555 : H12AffineEnvironment.transform 26 30393344 env48554 = env48555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env48554 == env48555) = true)

def env48556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound48556 : H12AffineFastState.Bounded env48556 := by
  intro p hp
  have h : env48556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48555_48556 : H12AffineEnvironment.transform 18 1024 env48555 = env48556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env48555 == env48556) = true)

theorem identity48556 : scanCanonicalize (H12AffineFastState.compose env48556 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10923371) := by decide +kernel

theorem selectedBound48556 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env48557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10923371,8328,65,6385003,8858086,10507601,8830976,2566522,13093034,256,485831,493666,2494125]

theorem envBound48557 : H12AffineFastState.Bounded env48557 := by
  intro p hp
  have h : env48557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48556_48557 : H12AffineEnvironment.transform 23 10923371 env48556 = env48557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10923371 env48556 == env48557) = true)

def env48558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,452648,2114883,8328,65,6385003,115150,2538873,10280,2566522,4268162,256,485831,493666,2494125]

theorem envBound48558 : H12AffineFastState.Bounded env48558 := by
  intro p hp
  have h : env48558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48557_48558 : H12AffineEnvironment.transform 22 452648 env48557 = env48558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env48557 == env48558) = true)

def env48559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,441659,8328,65,4691219,115150,17665,10280,119042,4268162,256,485831,493666,63189]

theorem envBound48559 : H12AffineFastState.Bounded env48559 := by
  intro p hp
  have h : env48559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48558_48559 : H12AffineEnvironment.transform 20 456824 env48558 = env48559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env48558 == env48559) = true)

def env48560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,441659,8328,65,245139,115150,17665,10280,119042,329730,256,485831,493666,63189]

theorem envBound48560 : H12AffineFastState.Bounded env48560 := by
  intro p hp
  have h : env48560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48559_48560 : H12AffineEnvironment.transform 21 272512 env48559 = env48560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48559 == env48560) = true)

theorem identity48560 : scanCanonicalize (H12AffineFastState.compose env48560 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound48560 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48561 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456824,272512,452648,441659,8328,65,158029,5392,17665,10280,1500,318684,256,441625,416956,63189]

theorem envBound48561 : H12AffineFastState.Bounded env48561 := by
  intro p hp
  have h : env48561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48560_48561 : H12AffineEnvironment.transform 15 54494 env48560 = env48561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env48560 == env48561) = true)

theorem identity48561 : scanCanonicalize (H12AffineFastState.compose env48561 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound48561 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env48562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,262144,1024,29909,396460,272512,400636,412143,8328,65,158029,5392,17665,10280,1500,272392,256,412109,416956,513]

theorem envBound48562 : H12AffineFastState.Bounded env48562 := by
  intro p hp
  have h : env48562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48561_48562 : H12AffineEnvironment.transform 14 29908 env48561 = env48562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env48561 == env48562) = true)

theorem identity48562 : scanCanonicalize (H12AffineFastState.compose env48562 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound48562 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env48563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,2421,1024,29909,132569,8693,136585,147610,8328,65,158029,5392,17665,10280,1500,8573,256,147640,153033,513]

theorem envBound48563 : H12AffineFastState.Bounded env48563 := by
  intro p hp
  have h : env48563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48562_48563 : H12AffineEnvironment.transform 17 2421 env48562 = env48563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env48562 == env48563) = true)

theorem identity48563 : scanCanonicalize (H12AffineFastState.compose env48563 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound48563 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env48564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,478,131072,2421,1024,21761,132569,33,136585,147610,348,65,149657,5392,17665,2556,1500,169,256,147640,153033,513]

theorem envBound48564 : H12AffineFastState.Bounded env48564 := by
  intro p hp
  have h : env48564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48563_48564 : H12AffineEnvironment.transform 12 468 env48563 = env48564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env48563 == env48564) = true)

theorem identity48564 : scanCanonicalize (H12AffineFastState.compose env48564 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48564 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env48565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1297,478,131072,2421,1024,1296,132569,33,136585,135307,348,65,137352,5392,5392,2556,1500,169,256,135337,132568,513]

theorem envBound48565 : H12AffineFastState.Bounded env48565 := by
  intro p hp
  have h : env48565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48564_48565 : H12AffineEnvironment.transform 13 4113 env48564 = env48565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48564 == env48565) = true)

theorem identity48565 : scanCanonicalize (H12AffineFastState.compose env48565 (packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS)) = affineNative (2^(16+1) ^^^ 3329) := by decide +kernel

theorem selectedBound48565 : packedSelected [1,2,4,6,8,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env48566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,4113,1297,478,3329,2421,1024,1296,2264,33,6280,7562,348,65,5513,5392,5392,2556,1500,169,256,7592,2265,513]

theorem envBound48566 : H12AffineFastState.Bounded env48566 := by
  intro p hp
  have h : env48566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48565_48566 : H12AffineEnvironment.transform 16 3329 env48565 = env48566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3329 env48565 == env48566) = true)

theorem identity48566 : scanCanonicalize (H12AffineFastState.compose env48566 (packedSelected [0,1,3,4,5,6,8,10,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48566 : packedSelected [0,1,3,4,5,6,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env48567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,4113,1297,342,3329,2421,1024,1296,2128,33,6144,7426,348,65,5377,5392,5392,2420,1364,33,256,7456,2129,513]

theorem envBound48567 : H12AffineFastState.Bounded env48567 := by
  intro p hp
  have h : env48567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48566_48567 : H12AffineEnvironment.transform 6 8 env48566 = env48567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48566 == env48567) = true)

theorem identity48567 : scanCanonicalize (H12AffineFastState.compose env48567 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound48567 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,348,3344,1297,342,3329,2421,1024,1296,2128,33,1281,3,348,65,2048,2065,2065,2420,1364,33,256,33,2129,513]

theorem envBound48568 : H12AffineFastState.Bounded env48568 := by
  intro p hp
  have h : env48568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48567_48568 : H12AffineEnvironment.transform 11 3329 env48567 = env48568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env48567 == env48568) = true)

def env48569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,441659,8328,65,245138,115150,17665,10280,119042,329731,256,485831,493666,63189]

theorem envBound48569 : H12AffineFastState.Bounded env48569 := by
  intro p hp
  have h : env48569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48559_48569 : H12AffineEnvironment.transform 21 272513 env48559 = env48569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48559 == env48569) = true)

theorem identity48569 : scanCanonicalize (H12AffineFastState.compose env48569 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound48569 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115870,201831,120014,98781,8328,65,245138,115150,17665,10280,119042,144613,256,21793,46212,63189]

theorem envBound48570 : H12AffineFastState.Bounded env48570 := by
  intro p hp
  have h : env48570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48569_48570 : H12AffineEnvironment.transform 17 212198 env48569 = env48570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env48569 == env48570) = true)

def env48571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115870,201783,119966,98701,8328,17,245138,115102,17665,10280,119042,144565,256,21793,46212,63109]

theorem envBound48571 : H12AffineFastState.Bounded env48571 := by
  intro p hp
  have h : env48571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48570_48571 : H12AffineEnvironment.transform 5 16 env48570 = env48571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48570 == env48571) = true)

theorem identity48571 : scanCanonicalize (H12AffineFastState.compose env48571 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound48571 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env48572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76078,1024,32769,115870,65967,119966,98701,8328,17,108554,115102,17665,10280,119042,8493,256,21793,46212,63109]

theorem envBound48572 : H12AffineFastState.Bounded env48572 := by
  intro p hp
  have h : env48572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48571_48572 : H12AffineEnvironment.transform 16 5528 env48571 = env48572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env48571 == env48572) = true)

theorem identity48572 : scanCanonicalize (H12AffineFastState.compose env48572 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound48572 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env48573 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,5528,64929,1024,32769,4113,54560,17,21762,8328,17,31877,5393,17665,10280,1421,8493,256,21793,46212,63109]

theorem envBound48573 : H12AffineFastState.Bounded env48573 := by
  intro p hp
  have h : env48573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48572_48573 : H12AffineEnvironment.transform 15 54415 env48572 = env48573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env48572 == env48573) = true)

theorem identity48573 : scanCanonicalize (H12AffineFastState.compose env48573 (packedSelected [0,1,4,5,7,8,16,17,18,19,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound48573 : packedSelected [0,1,4,5,7,8,16,17,18,19,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48574 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,30083,5528,23725,1024,8461,4113,29740,17,21762,8328,17,31877,5393,17665,10280,1421,8493,256,21793,5512,22409]

theorem envBound48574 : H12AffineFastState.Bounded env48574 := by
  intro p hp
  have h : env48574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48573_48574 : H12AffineEnvironment.transform 14 8460 env48573 = env48574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env48573 == env48574) = true)

theorem identity48574 : scanCanonicalize (H12AffineFastState.compose env48574 (packedSelected [0,2,3,5,7,10,12,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound48574 : packedSelected [0,2,3,5,7,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env48575 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,8203,5528,2341,1024,8461,4113,8612,17,138,8328,17,10509,5393,4233,10280,1421,8493,256,169,5512,513]

theorem envBound48575 : H12AffineFastState.Bounded env48575 := by
  intro p hp
  have h : env48575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48574_48575 : H12AffineEnvironment.transform 13 5512 env48574 = env48575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env48574 == env48575) = true)

theorem identity48575 : scanCanonicalize (H12AffineFastState.compose env48575 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound48575 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48576 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,160,5512,428,171,5528,2341,1024,429,4113,260,17,138,40,17,2477,5393,4233,2184,1421,397,256,169,5512,513]

theorem envBound48576 : H12AffineFastState.Bounded env48576 := by
  intro p hp
  have h : env48576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48575_48576 : H12AffineEnvironment.transform 12 160 env48575 = env48576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env48575 == env48576) = true)

theorem identity48576 : scanCanonicalize (H12AffineFastState.compose env48576 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound48576 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48577 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,160,5157,1,171,5173,2184,1024,0,4113,169,17,138,40,17,2048,5308,4233,2184,1056,32,173,169,5157,513]

theorem envBound48577 : H12AffineFastState.Bounded env48577 := by
  intro p hp
  have h : env48577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48576_48577 : H12AffineEnvironment.transform 7 173 env48576 = env48577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env48576 == env48577) = true)

theorem identity48577 : scanCanonicalize (H12AffineFastState.compose env48577 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48577 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48578 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,1,35,5173,2048,1024,0,4113,33,17,2,40,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound48578 : H12AffineFastState.Bounded env48578 := by
  intro p hp
  have h : env48578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48577_48578 : H12AffineEnvironment.transform 6 8 env48577 = env48578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48577 == env48578) = true)

def env48579 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,1,35,1029,2048,1024,0,33,33,17,2,40,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound48579 : H12AffineFastState.Bounded env48579 := by
  intro p hp
  have h : env48579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48578_48579 : H12AffineEnvironment.transform 11 48 env48578 = env48579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48578 == env48579) = true)

theorem identity48579 : scanCanonicalize (H12AffineFastState.compose env48579 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound48579 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48580 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,48,40,1045,1,35,1029,1044,1024,0,33,33,17,2,40,17,1044,1028,49,1044,1056,32,37,33,1045,513]

theorem envBound48580 : H12AffineFastState.Bounded env48580 := by
  intro p hp
  have h : env48580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48579_48580 : H12AffineEnvironment.transform 10 1044 env48579 = env48580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env48579 == env48580) = true)

def env48581 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,40,33,1,35,49,32,52,0,33,33,17,2,40,17,32,48,49,32,20,32,37,33,33,513]

theorem envBound48581 : H12AffineFastState.Bounded env48581 := by
  intro p hp
  have h : env48581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48580_48581 : H12AffineEnvironment.transform 9 52 env48580 = env48581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48580 == env48581) = true)

def env48582 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,40,32,1,35,48,33,53,0,33,33,17,2,40,17,33,49,49,33,21,32,37,33,32,513]

theorem envBound48582 : H12AffineFastState.Bounded env48582 := by
  intro p hp
  have h : env48582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48580_48582 : H12AffineEnvironment.transform 9 53 env48580 = env48582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48580 == env48582) = true)

theorem identity48582 : scanCanonicalize (H12AffineFastState.compose env48582 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound48582 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48583 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,48,40,32,1,35,48,33,53,0,33,33,17,2,40,17,33,49,49,33,21,32,37,33,32,43]

theorem envBound48583 : H12AffineFastState.Bounded env48583 := by
  intro p hp
  have h : env48583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48582_48583 : H12AffineEnvironment.transform 8 42 env48582 = env48583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env48582 == env48583) = true)

def leafEnv48583 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,48,40,32,1,35,48,33,53,0,33,33,17,2,21,40,1,17,33,49,49,33,21,32,37,33,4,35,32,43,1,33,0]

def active48583 : List Nat := [0,1,2,3,4]

def tree48583 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48583 : H12WitnessSearch.Good tree48583 := H12GlobalWitnessIndex.good

theorem leafIdentity48583 : H12AffineFastState.composeSystem env48583 rootObs = leafEnv48583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48583 rootObs == leafEnv48583) = true)

theorem terminalChecked48583 : H12PackedTerminal.terminalCheckFast leafEnv48583 active48583 tree48583 = true := by decide +kernel

def env48584 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,1,35,1028,2048,1024,0,32,33,17,2,40,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound48584 : H12AffineFastState.Bounded env48584 := by
  intro p hp
  have h : env48584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48578_48584 : H12AffineEnvironment.transform 11 49 env48578 = env48584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48578 == env48584) = true)

theorem identity48584 : scanCanonicalize (H12AffineFastState.compose env48584 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound48584 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48585 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,49,40,1044,1,35,1028,32,1024,0,32,33,17,2,40,17,32,1029,48,32,1056,32,37,33,1044,513]

theorem envBound48585 : H12AffineFastState.Bounded env48585 := by
  intro p hp
  have h : env48585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48584_48585 : H12AffineEnvironment.transform 10 32 env48584 = env48585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env48584 == env48585) = true)

def env48586 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,40,32,1,35,48,32,52,0,32,33,17,2,40,17,32,49,48,32,20,32,37,33,32,513]

theorem envBound48586 : H12AffineFastState.Bounded env48586 := by
  intro p hp
  have h : env48586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48585_48586 : H12AffineEnvironment.transform 9 52 env48585 = env48586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48585 == env48586) = true)

def env48587 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,40,33,1,35,49,32,53,0,32,33,17,2,40,17,32,48,48,32,21,32,37,33,33,513]

theorem envBound48587 : H12AffineFastState.Bounded env48587 := by
  intro p hp
  have h : env48587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48585_48587 : H12AffineEnvironment.transform 9 53 env48585 = env48587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48585 == env48587) = true)

theorem identity48587 : scanCanonicalize (H12AffineFastState.compose env48587 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound48587 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48588 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,49,40,33,1,35,49,32,53,0,32,33,17,2,40,17,32,48,48,32,21,32,37,33,33,42]

theorem envBound48588 : H12AffineFastState.Bounded env48588 := by
  intro p hp
  have h : env48588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48587_48588 : H12AffineEnvironment.transform 8 43 env48587 = env48588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env48587 == env48588) = true)

def leafEnv48588 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,49,40,33,1,35,49,32,53,0,32,33,17,2,21,40,1,17,32,48,48,32,21,32,37,33,4,35,33,42,1,32,0]

def active48588 : List Nat := [0,1,2,3,4]

def tree48588 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48588 : H12WitnessSearch.Good tree48588 := H12GlobalWitnessIndex.good

theorem leafIdentity48588 : H12AffineFastState.composeSystem env48588 rootObs = leafEnv48588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48588 rootObs == leafEnv48588) = true)

theorem terminalChecked48588 : H12PackedTerminal.terminalCheckFast leafEnv48588 active48588 tree48588 = true := by decide +kernel

def env48589 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115870,201782,119967,98700,8328,16,245138,115103,17665,10280,119042,144564,256,21793,46212,63108]

theorem envBound48589 : H12AffineFastState.Bounded env48589 := by
  intro p hp
  have h : env48589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48570_48589 : H12AffineEnvironment.transform 5 17 env48570 = env48589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48570 == env48589) = true)

theorem identity48589 : scanCanonicalize (H12AffineFastState.compose env48589 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115103) := by decide +kernel

theorem selectedBound48589 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env48590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,115103,64808,1024,32769,115870,54697,119967,98700,8328,16,31757,115103,17665,10280,119042,128299,256,21793,46212,63108]

theorem envBound48590 : H12AffineFastState.Bounded env48590 := by
  intro p hp
  have h : env48590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48589_48590 : H12AffineEnvironment.transform 16 115103 env48589 = env48590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115103 env48589 == env48590) = true)

theorem identity48590 : scanCanonicalize (H12AffineFastState.compose env48590 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound48590 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env48591 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54279,5528,64808,1024,32769,4249,54697,152,21899,8328,16,31757,5528,17665,10280,1285,8492,256,21793,46212,63108]

theorem envBound48591 : H12AffineFastState.Bounded env48591 := by
  intro p hp
  have h : env48591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48590_48591 : H12AffineEnvironment.transform 15 54279 env48590 = env48591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env48590 == env48591) = true)

theorem identity48591 : scanCanonicalize (H12AffineFastState.compose env48591 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound48591 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env48592 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,8322,5528,2477,1024,29828,4249,8492,152,21899,8328,16,31757,5528,17665,10280,1285,8492,256,21793,16385,513]

theorem envBound48592 : H12AffineFastState.Bounded env48592 := by
  intro p hp
  have h : env48592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48591_48592 : H12AffineEnvironment.transform 14 29829 env48591 = env48592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env48591 == env48592) = true)

theorem identity48592 : scanCanonicalize (H12AffineFastState.compose env48592 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound48592 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48593 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,262,5528,2477,1024,21760,4249,168,152,21899,268,16,23945,5528,17665,2476,1285,168,256,21793,16385,513]

theorem envBound48593 : H12AffineFastState.Bounded env48593 := by
  intro p hp
  have h : env48593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48592_48593 : H12AffineEnvironment.transform 12 388 env48592 = env48593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env48592 == env48593) = true)

theorem identity48593 : scanCanonicalize (H12AffineFastState.compose env48593 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48593 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env48594 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,388,16384,20497,262,4232,2477,272,20496,4249,168,152,20635,268,16,22681,4232,16401,2476,21,168,256,20529,16385,513]

theorem envBound48594 : H12AffineFastState.Bounded env48594 := by
  intro p hp
  have h : env48594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48593_48594 : H12AffineEnvironment.transform 9 272 env48593 = env48594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48593 == env48594) = true)

theorem identity48594 : scanCanonicalize (H12AffineFastState.compose env48594 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48594 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48595 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,269,16384,20497,262,4097,2340,272,20496,4112,33,17,20498,268,16,22544,4097,16401,2341,21,33,256,20529,16385,513]

theorem envBound48595 : H12AffineFastState.Bounded env48595 := by
  intro p hp
  have h : env48595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48594_48595 : H12AffineEnvironment.transform 6 9 env48594 = env48595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48594 == env48595) = true)

theorem identity48595 : scanCanonicalize (H12AffineFastState.compose env48595 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48595 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48596 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,16384,20497,34,4097,2048,52,20496,4112,33,17,20498,40,16,22544,4097,16401,2049,21,33,36,20529,16385,513]

theorem envBound48596 : H12AffineFastState.Bounded env48596 := by
  intro p hp
  have h : env48596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48595_48596 : H12AffineEnvironment.transform 7 36 env48595 = env48596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48595 == env48596) = true)

theorem identity48596 : scanCanonicalize (H12AffineFastState.compose env48596 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound48596 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env48597 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,41,4113,0,34,4097,2048,52,1,4112,33,17,3,40,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound48597 : H12AffineFastState.Bounded env48597 := by
  intro p hp
  have h : env48597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48596_48597 : H12AffineEnvironment.transform 13 4113 env48596 = env48597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env48596 == env48597) = true)

theorem identity48597 : scanCanonicalize (H12AffineFastState.compose env48597 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound48597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48598 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,33,41,48,0,34,32,2048,52,1,49,33,17,3,40,16,2049,32,33,2049,21,33,36,32,49,513]

theorem envBound48598 : H12AffineFastState.Bounded env48598 := by
  intro p hp
  have h : env48598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48597_48598 : H12AffineEnvironment.transform 11 33 env48597 = env48598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env48597 == env48598) = true)

theorem identity48598 : scanCanonicalize (H12AffineFastState.compose env48598 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound48598 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48599 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,41,48,0,34,32,49,52,1,49,33,17,3,40,16,48,32,33,48,21,33,36,32,49,513]

theorem envBound48599 : H12AffineFastState.Bounded env48599 := by
  intro p hp
  have h : env48599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48598_48599 : H12AffineEnvironment.transform 10 49 env48598 = env48599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env48598 == env48599) = true)

def leafEnv48599 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,41,48,0,34,32,49,52,1,49,33,17,3,21,40,1,16,48,32,33,48,21,33,36,32,4,35,49,513,1,48,0]

def active48599 : List Nat := [0,1,2,3,4,8]

def tree48599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48599 : H12WitnessSearch.Good tree48599 := H12GlobalWitnessIndex.good

theorem leafIdentity48599 : H12AffineFastState.composeSystem env48599 rootObs = leafEnv48599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48599 rootObs == leafEnv48599) = true)

theorem terminalChecked48599 : H12PackedTerminal.terminalCheckFast leafEnv48599 active48599 tree48599 = true := by decide +kernel

def env48600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,441658,8328,65,4691218,115150,17664,10280,119043,4268162,256,485831,493666,63188]

theorem envBound48600 : H12AffineFastState.Bounded env48600 := by
  intro p hp
  have h : env48600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48558_48600 : H12AffineEnvironment.transform 20 456825 env48558 = env48600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env48558 == env48600) = true)

def env48601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,441658,8328,65,245138,115150,17664,10280,119043,329730,256,485831,493666,63188]

theorem envBound48601 : H12AffineFastState.Bounded env48601 := by
  intro p hp
  have h : env48601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48600_48601 : H12AffineEnvironment.transform 21 272512 env48600 = env48601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env48600 == env48601) = true)

theorem identity48601 : scanCanonicalize (H12AffineFastState.compose env48601 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound48601 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272512,452648,441658,8328,65,171416,57796,17664,10280,61705,272392,256,412109,436328,63188]

theorem envBound48602 : H12AffineFastState.Bounded env48602 := by
  intro p hp
  have h : env48602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48601_48602 : H12AffineEnvironment.transform 15 8202 env48601 = env48602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env48601 == env48602) = true)

def env48603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272392,452648,441658,8192,65,171280,57676,17664,10280,61705,272392,256,411973,436328,63068]

theorem envBound48603 : H12AffineFastState.Bounded env48603 := by
  intro p hp
  have h : env48603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48602_48603 : H12AffineEnvironment.transform 6 8 env48602 = env48603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48602 == env48603) = true)

theorem identity48603 : scanCanonicalize (H12AffineFastState.compose env48603 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound48603 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env48604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,262144,1024,32769,281652,272392,285797,264567,8192,65,10589,57676,17664,10280,61705,272392,256,326920,269349,63068]

theorem envBound48604 : H12AffineFastState.Bounded env48604 := by
  intro p hp
  have h : env48604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48603_48604 : H12AffineEnvironment.transform 16 46157 env48603 = env48604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env48603 == env48604) = true)

theorem identity48604 : scanCanonicalize (H12AffineFastState.compose env48604 (packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound48604 : packedSelected [0,1,3,4,5,12,14,15,17,18,19,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env48605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,46157,35189,1024,32769,50497,41341,54544,32770,8192,65,10589,57676,17664,10280,61705,41341,256,29821,38224,63068]

theorem envBound48605 : H12AffineFastState.Bounded env48605 := by
  intro p hp
  have h : env48605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48604_48605 : H12AffineEnvironment.transform 17 35189 env48604 = env48605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env48604 == env48605) = true)

theorem identity48605 : scanCanonicalize (H12AffineFastState.compose env48605 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound48605 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env48606 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,38161,35189,1024,32769,50497,32801,54544,32770,348,65,2049,49168,17664,2420,53333,32801,256,21793,38224,55040]

theorem envBound48606 : H12AffineFastState.Bounded env48606 := by
  intro p hp
  have h : env48606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48605_48606 : H12AffineEnvironment.transform 12 348 env48605 = env48606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env48605 == env48606) = true)

theorem identity48606 : scanCanonicalize (H12AffineFastState.compose env48606 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound48606 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env48607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21841,342,16448,23588,1024,21840,4112,21872,65,21843,348,65,2049,5441,17664,2420,1284,21872,256,21793,16385,593]

theorem envBound48607 : H12AffineFastState.Bounded env48607 := by
  intro p hp
  have h : env48607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48606_48607 : H12AffineEnvironment.transform 14 21841 env48606 = env48607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env48606 == env48607) = true)

theorem identity48607 : scanCanonicalize (H12AffineFastState.compose env48607 (packedSelected [4,6,7,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound48607 : packedSelected [4,6,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env48608 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,16384,20496,342,16448,22885,321,20497,4112,20529,65,20498,348,65,2049,4096,16449,2420,69,20529,256,20576,16385,593]

theorem envBound48608 : H12AffineFastState.Bounded env48608 := by
  intro p hp
  have h : env48608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48607_48608 : H12AffineEnvironment.transform 9 321 env48607 = env48608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48607 == env48608) = true)

theorem identity48608 : scanCanonicalize (H12AffineFastState.compose env48608 (packedSelected [0,2,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 4420) := by decide +kernel

theorem selectedBound48608 : packedSelected [0,2,6,9,12] rootPS < 2^1333 := by decide +kernel

def env48609 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,4420,340,342,4356,2081,321,341,4112,373,65,342,348,65,2049,4096,4357,2420,69,373,256,292,4421,593]

theorem envBound48609 : H12AffineFastState.Bounded env48609 := by
  intro p hp
  have h : env48609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48608_48609 : H12AffineEnvironment.transform 13 4420 env48608 = env48609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4420 env48608 == env48609) = true)

theorem identity48609 : scanCanonicalize (H12AffineFastState.compose env48609 (packedSelected [0,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound48609 : packedSelected [0,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env48610 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,4096,9,4113,1,3,4177,2081,20,0,4112,32,65,3,9,65,2049,4096,4176,2081,69,32,85,113,4112,593]

theorem envBound48610 : H12AffineFastState.Bounded env48610 := by
  intro p hp
  have h : env48610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48609_48610 : H12AffineEnvironment.transform 7 85 env48609 = env48610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env48609 == env48610) = true)

theorem identity48610 : scanCanonicalize (H12AffineFastState.compose env48610 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound48610 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env48611 : List Nat := [2,4,8,16,32,64,8,85,512,20,2048,2144,9,2161,1,3,2097,2081,20,0,2160,32,65,3,9,65,2049,2144,2096,2081,69,32,85,113,2160,593]

theorem envBound48611 : H12AffineFastState.Bounded env48611 := by
  intro p hp
  have h : env48611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48610_48611 : H12AffineEnvironment.transform 11 2144 env48610 = env48611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env48610 == env48611) = true)

def env48612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272393,452648,441658,8193,65,171281,57677,17664,10280,61705,272392,256,411972,436328,63069]

theorem envBound48612 : H12AffineFastState.Bounded env48612 := by
  intro p hp
  have h : env48612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48602_48612 : H12AffineEnvironment.transform 6 9 env48602 = env48612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48602 == env48612) = true)

theorem identity48612 : scanCanonicalize (H12AffineFastState.compose env48612 (packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 182336) := by decide +kernel

theorem selectedBound48612 : packedSelected [0,1,7,8,9,10,11,12,14,15,17,19,20,22,31,32] rootPS < 2^1333 := by decide +kernel

def env48613 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,182336,1024,32769,12345,188489,8296,30074,8193,65,171281,57677,17664,10280,61705,188488,256,33028,24616,63069]

theorem envBound48613 : H12AffineFastState.Bounded env48613 := by
  intro p hp
  have h : env48613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48612_48613 : H12AffineEnvironment.transform 17 182336 env48612 = env48613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182336 env48612 == env48613) = true)

theorem identity48613 : scanCanonicalize (H12AffineFastState.compose env48613 (packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound48613 : packedSelected [2,7,8,11,12,15,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env48614 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,13624,64888,1024,32769,12345,54641,8296,30074,8193,65,43049,57677,17664,10280,61705,54640,256,33028,24616,63069]

theorem envBound48614 : H12AffineFastState.Bounded env48614 := by
  intro p hp
  have h : env48614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48613_48614 : H12AffineEnvironment.transform 16 13624 env48613 = env48614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env48613 == env48614) = true)

theorem identity48614 : scanCanonicalize (H12AffineFastState.compose env48614 (packedSelected [1,2,4,8,9,11,12,15,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound48614 : packedSelected [1,2,4,8,9,11,12,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env48615 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,32768,34,5392,56656,1024,32769,4113,54641,64,21842,41,65,34817,49509,17664,2048,53537,54640,256,33028,16384,54901]

theorem envBound48615 : H12AffineFastState.Bounded env48615 := by
  intro p hp
  have h : env48615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48614_48615 : H12AffineEnvironment.transform 12 40 env48614 = env48615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env48614 == env48615) = true)

theorem identity48615 : scanCanonicalize (H12AffineFastState.compose env48615 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound48615 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env48616 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,292,34,5392,23668,1024,293,4113,21589,64,21842,41,65,2341,16449,17664,2048,20485,21588,256,32,16384,22353]

theorem envBound48616 : H12AffineFastState.Bounded env48616 := by
  intro p hp
  have h : env48616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48615_48616 : H12AffineEnvironment.transform 14 292 env48615 = env48616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env48615 == env48616) = true)

def env48617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,441658,8328,65,245139,115150,17664,10280,119043,329731,256,485831,493666,63188]

theorem envBound48617 : H12AffineFastState.Bounded env48617 := by
  intro p hp
  have h : env48617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48600_48617 : H12AffineEnvironment.transform 21 272513 env48600 = env48617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env48600 == env48617) = true)

theorem identity48617 : scanCanonicalize (H12AffineFastState.compose env48617 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound48617 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env48618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254131,73754,95496,8328,65,245139,115150,17664,10280,119043,180273,256,41461,16464,63188]

theorem envBound48618 : H12AffineFastState.Bounded env48618 := by
  intro p hp
  have h : env48618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48617_48618 : H12AffineEnvironment.transform 17 247858 env48617 = env48618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env48617 == env48618) = true)

def env48619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77851,254131,73754,95496,8328,17,245139,115102,17664,10280,119043,180273,256,41381,16384,63108]

theorem envBound48619 : H12AffineFastState.Bounded env48619 := by
  intro p hp
  have h : env48619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48618_48619 : H12AffineEnvironment.transform 5 16 env48618 = env48619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48618 == env48619) = true)

theorem identity48619 : scanCanonicalize (H12AffineFastState.compose env48619 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48619 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env48620 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77851,254011,73754,95496,8192,17,245019,114966,17664,10280,119043,180273,256,41261,16384,62988]

theorem envBound48620 : H12AffineFastState.Bounded env48620 := by
  intro p hp
  have h : env48620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48619_48620 : H12AffineEnvironment.transform 6 8 env48619 = env48620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48619 == env48620) = true)

theorem identity48620 : scanCanonicalize (H12AffineFastState.compose env48620 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound48620 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,18,19,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env48621 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54278,131072,138292,1024,32769,58397,144445,62492,41230,8192,17,157981,5392,17664,10280,1285,180273,256,41261,16384,62988]

theorem envBound48621 : H12AffineFastState.Bounded env48621 := by
  intro p hp
  have h : env48621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48620_48621 : H12AffineEnvironment.transform 15 54278 env48620 = env48621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env48620 == env48621) = true)

theorem identity48621 : scanCanonicalize (H12AffineFastState.compose env48621 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound48621 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env48622 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,131072,138292,1024,29708,4112,144445,17,21763,8192,17,157981,5392,17664,10280,1285,144444,256,21792,16384,513]

theorem envBound48622 : H12AffineFastState.Bounded env48622 := by
  intro p hp
  have h : env48622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48621_48622 : H12AffineEnvironment.transform 14 29709 env48621 = env48622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env48621 == env48622) = true)

theorem identity48622 : scanCanonicalize (H12AffineFastState.compose env48622 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound48622 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env48623 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8203,5393,2341,1024,29708,4112,8492,17,21763,8192,17,31756,5392,17664,10280,1285,8493,256,21792,16384,513]

theorem envBound48623 : H12AffineFastState.Bounded env48623 := by
  intro p hp
  have h : env48623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48622_48623 : H12AffineEnvironment.transform 16 5393 env48622 = env48623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env48622 == env48623) = true)

theorem identity48623 : scanCanonicalize (H12AffineFastState.compose env48623 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound48623 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48624 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,5393,2341,1024,8461,4112,8492,17,2,8192,17,10509,5392,4097,10280,1285,8493,256,33,5377,513]

theorem envBound48624 : H12AffineFastState.Bounded env48624 := by
  intro p hp
  have h : env48624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48623_48624 : H12AffineEnvironment.transform 13 5377 env48623 = env48624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env48623 == env48624) = true)

theorem identity48624 : scanCanonicalize (H12AffineFastState.compose env48624 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48625 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8232,8203,5173,2049,1024,8233,4112,8200,17,2,8192,17,10281,5172,4097,10280,1057,8201,36,33,5157,513]

theorem envBound48625 : H12AffineFastState.Bounded env48625 := by
  intro p hp
  have h : env48625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48624_48625 : H12AffineEnvironment.transform 7 36 env48624 = env48625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48624 == env48625) = true)

theorem identity48625 : scanCanonicalize (H12AffineFastState.compose env48625 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound48625 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48626 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5173,2049,1024,0,4112,33,17,2,41,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound48626 : H12AffineFastState.Bounded env48626 := by
  intro p hp
  have h : env48626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48625_48626 : H12AffineEnvironment.transform 12 41 env48625 = env48626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env48625 == env48626) = true)

def env48627 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,1,34,1029,2049,1024,0,32,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound48627 : H12AffineFastState.Bounded env48627 := by
  intro p hp
  have h : env48627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48626_48627 : H12AffineEnvironment.transform 11 48 env48626 = env48627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env48626 == env48627) = true)

theorem identity48627 : scanCanonicalize (H12AffineFastState.compose env48627 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound48627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48628 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,48,41,1045,1,34,1029,2049,1024,0,32,33,17,2,41,17,2048,1028,49,2049,1057,32,36,33,1045,48]

theorem envBound48628 : H12AffineFastState.Bounded env48628 := by
  intro p hp
  have h : env48628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48627_48628 : H12AffineEnvironment.transform 8 49 env48627 = env48628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48627 == env48628) = true)

def env48629 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,48,41,33,1,34,49,2049,52,0,32,33,17,2,41,17,2048,48,49,2049,21,32,36,33,33,48]

theorem envBound48629 : H12AffineFastState.Bounded env48629 := by
  intro p hp
  have h : env48629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48628_48629 : H12AffineEnvironment.transform 9 52 env48628 = env48629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48628 == env48629) = true)

def env48630 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,41,32,1,34,48,2049,53,0,32,33,17,2,41,17,2048,49,49,2049,20,32,36,33,32,48]

theorem envBound48630 : H12AffineFastState.Bounded env48630 := by
  intro p hp
  have h : env48630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48628_48630 : H12AffineEnvironment.transform 9 53 env48628 = env48630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48628 == env48630) = true)

theorem identity48630 : scanCanonicalize (H12AffineFastState.compose env48630 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48631 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,42,41,32,1,34,42,2049,47,0,32,33,11,2,41,11,2048,43,43,2049,14,32,36,33,32,42]

theorem envBound48631 : H12AffineFastState.Bounded env48631 := by
  intro p hp
  have h : env48631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48630_48631 : H12AffineEnvironment.transform 3 10 env48630 = env48631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48630 == env48631) = true)

def leafEnv48631 : List Nat := [2,4,8,10,32,10,8,36,43,47,2048,42,41,32,1,34,42,2049,47,0,32,33,11,2,14,41,1,11,2048,43,43,2049,14,32,36,33,4,34,32,42,1,32,0]

def active48631 : List Nat := [0,1,2,4,10]

def tree48631 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48631 : H12WitnessSearch.Good tree48631 := H12GlobalWitnessIndex.good

theorem leafIdentity48631 : H12AffineFastState.composeSystem env48631 rootObs = leafEnv48631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48631 rootObs == leafEnv48631) = true)

theorem terminalChecked48631 : H12PackedTerminal.terminalCheckFast leafEnv48631 active48631 tree48631 = true := by decide +kernel

def env48632 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,1,34,1028,2049,1024,0,33,33,17,2,41,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound48632 : H12AffineFastState.Bounded env48632 := by
  intro p hp
  have h : env48632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48626_48632 : H12AffineEnvironment.transform 11 49 env48626 = env48632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env48626 == env48632) = true)

theorem identity48632 : scanCanonicalize (H12AffineFastState.compose env48632 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound48632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48633 : List Nat := [2,4,8,16,32,16,8,36,512,517,2048,49,41,529,1,34,513,2049,517,0,33,33,17,2,41,17,2048,512,48,2049,548,32,36,33,529,513]

theorem envBound48633 : H12AffineFastState.Bounded env48633 := by
  intro p hp
  have h : env48633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48632_48633 : H12AffineEnvironment.transform 9 517 env48632 = env48633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env48632 == env48633) = true)

def env48634 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,49,41,33,1,34,49,2049,53,0,33,33,17,2,41,17,2048,48,48,2049,20,32,36,33,33,49]

theorem envBound48634 : H12AffineFastState.Bounded env48634 := by
  intro p hp
  have h : env48634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48633_48634 : H12AffineEnvironment.transform 8 48 env48633 = env48634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env48633 == env48634) = true)

theorem identity48634 : scanCanonicalize (H12AffineFastState.compose env48634 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48634 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48635 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,43,41,33,1,34,43,2049,47,0,33,33,11,2,41,11,2048,42,42,2049,14,32,36,33,33,43]

theorem envBound48635 : H12AffineFastState.Bounded env48635 := by
  intro p hp
  have h : env48635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48634_48635 : H12AffineEnvironment.transform 3 10 env48634 = env48635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48634 == env48635) = true)

def leafEnv48635 : List Nat := [2,4,8,10,32,10,8,36,42,47,2048,43,41,33,1,34,43,2049,47,0,33,33,11,2,14,41,1,11,2048,42,42,2049,14,32,36,33,4,34,33,43,1,33,0]

def active48635 : List Nat := [0,1,2,4,10]

def tree48635 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood48635 : H12WitnessSearch.Good tree48635 := H12GlobalWitnessIndex.good

theorem leafIdentity48635 : H12AffineFastState.composeSystem env48635 rootObs = leafEnv48635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env48635 rootObs == leafEnv48635) = true)

theorem terminalChecked48635 : H12PackedTerminal.terminalCheckFast leafEnv48635 active48635 tree48635 = true := by decide +kernel

def env48636 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,41,32,1,34,48,2049,52,0,33,33,17,2,41,17,2048,49,48,2049,21,32,36,33,32,48]

theorem envBound48636 : H12AffineFastState.Bounded env48636 := by
  intro p hp
  have h : env48636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48633_48636 : H12AffineEnvironment.transform 8 49 env48633 = env48636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env48633 == env48636) = true)

def env48637 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77850,254131,73754,95496,8328,16,245139,115103,17664,10280,119043,180273,256,41380,16385,63109]

theorem envBound48637 : H12AffineFastState.Bounded env48637 := by
  intro p hp
  have h : env48637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48618_48637 : H12AffineEnvironment.transform 5 17 env48618 = env48637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48618 == env48637) = true)

theorem identity48637 : scanCanonicalize (H12AffineFastState.compose env48637 (packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound48637 : packedSelected [1,3,4,7,9,10,12,15,17,18,19,23,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1