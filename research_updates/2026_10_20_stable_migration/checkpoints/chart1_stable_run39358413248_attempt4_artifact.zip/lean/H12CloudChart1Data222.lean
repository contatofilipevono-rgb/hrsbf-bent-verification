import H12CloudChart1Data221

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound56216 : packedSelected [1,2,3,4,8,10,12,14,15,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env56217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13556,32,34,13540,10708,1024,33,12393,8573,16,8694,8328,65,10589,5392,4573,10741,9717,8693,256,8661,13477,512]

theorem envBound56217 : H12AffineFastState.Bounded env56217 := by
  intro p hp
  have h : env56217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56216_56217 : H12AffineEnvironment.transform 13 13556 env56216 = env56217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13556 env56216 == env56217) = true)

theorem identity56217 : scanCanonicalize (H12AffineFastState.compose env56217 (packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound56217 : packedSelected [2,4,6,7,11,14,17,18,22,27] rootPS < 2^1333 := by decide +kernel

def env56218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,380,5512,32,34,5528,2216,1024,33,4373,1,16,138,500,65,2081,5392,4573,2185,1161,137,256,169,5593,512]

theorem envBound56218 : H12AffineFastState.Bounded env56218 := by
  intro p hp
  have h : env56218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56217_56218 : H12AffineEnvironment.transform 12 380 env56217 = env56218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env56217 == env56218) = true)

theorem identity56218 : scanCanonicalize (H12AffineFastState.compose env56218 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound56218 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56219 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,380,4588,32,34,4604,2216,100,33,4373,1,16,138,500,65,2081,4468,4573,2185,237,137,256,169,4541,512]

theorem envBound56219 : H12AffineFastState.Bounded env56219 := by
  intro p hp
  have h : env56219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56218_56219 : H12AffineEnvironment.transform 9 100 env56218 = env56219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env56218 == env56219) = true)

theorem identity56219 : scanCanonicalize (H12AffineFastState.compose env56219 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56219 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56220 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,8,4248,32,34,4232,2216,100,33,4193,1,16,138,128,65,2081,4096,4265,2185,237,137,116,169,4297,512]

theorem envBound56220 : H12AffineFastState.Bounded env56220 := by
  intro p hp
  have h : env56220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56219_56220 : H12AffineEnvironment.transform 7 116 env56219 = env56220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56219 == env56220) = true)

def env56221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,322920,8572,338407,362528,8328,65,327850,57797,102879,109047,75222,8693,256,362499,354727,513]

theorem envBound56221 : H12AffineFastState.Bounded env56221 := by
  intro p hp
  have h : env56221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56212_56221 : H12AffineEnvironment.transform 16 16401 env56212 = env56221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56212 == env56221) = true)

theorem identity56221 : scanCanonicalize (H12AffineFastState.compose env56221 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56221 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,322920,8572,264684,305195,8328,65,270497,57797,45524,35324,1501,8693,256,305160,281004,513]

theorem envBound56222 : H12AffineFastState.Bounded env56222 := by
  intro p hp
  have h : env56222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56221_56222 : H12AffineEnvironment.transform 15 8203 env56221 = env56222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56221 == env56222) = true)

theorem identity56222 : scanCanonicalize (H12AffineFastState.compose env56222 (packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound56222 : packedSelected [4,7,9,11,12,15,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env56223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10400,1024,32769,50632,8572,8524,32907,8328,65,2049,57797,45524,35324,1501,8693,256,32936,24844,513]

theorem envBound56223 : H12AffineFastState.Bounded env56223 := by
  intro p hp
  have h : env56223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56222_56223 : H12AffineEnvironment.transform 17 10400 env56222 = env56223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env56222 == env56223) = true)

theorem identity56223 : scanCanonicalize (H12AffineFastState.compose env56223 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound56223 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env56224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,16401,10400,1024,1,17864,8572,8524,139,8328,65,2049,25029,12756,2556,1501,8693,256,168,24844,513]

theorem envBound56224 : H12AffineFastState.Bounded env56224 := by
  intro p hp
  have h : env56224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56223_56224 : H12AffineEnvironment.transform 14 0 env56223 = env56224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env56223 == env56224) = true)

theorem identity56224 : scanCanonicalize (H12AffineFastState.compose env56224 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56224 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env56225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,0,262,16401,2477,1024,1,17864,113,65,139,389,65,2049,16584,4313,2556,1501,248,256,168,16385,513]

theorem envBound56225 : H12AffineFastState.Bounded env56225 := by
  intro p hp
  have h : env56225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56224_56225 : H12AffineEnvironment.transform 12 269 env56224 = env56225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56224 == env56225) = true)

theorem identity56225 : scanCanonicalize (H12AffineFastState.compose env56225 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56225 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env56226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1024,1,17728,113,65,3,269,65,2049,16448,4177,2420,1365,112,256,32,16385,513]

theorem envBound56226 : H12AffineFastState.Bounded env56226 := by
  intro p hp
  have h : env56226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56225_56226 : H12AffineEnvironment.transform 6 8 env56225 = env56226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56225 == env56226) = true)

theorem identity56226 : scanCanonicalize (H12AffineFastState.compose env56226 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56226 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56227 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1024,1,17681,32,16,3,269,16,2049,16401,4096,2341,1284,33,256,32,16385,513]

theorem envBound56227 : H12AffineFastState.Bounded env56227 := by
  intro p hp
  have h : env56227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56226_56227 : H12AffineEnvironment.transform 5 17 env56226 = env56227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56226 == env56227) = true)

theorem identity56227 : scanCanonicalize (H12AffineFastState.compose env56227 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound56227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56228 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,1297,0,262,1280,2341,1024,1,0,32,16,3,269,16,2049,1280,4096,2341,1284,33,256,32,1296,513]

theorem envBound56228 : H12AffineFastState.Bounded env56228 := by
  intro p hp
  have h : env56228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56227_56228 : H12AffineEnvironment.transform 13 1297 env56227 = env56228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56227 == env56228) = true)

theorem identity56228 : scanCanonicalize (H12AffineFastState.compose env56228 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound56228 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56229 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,308,269,1297,0,262,1280,2341,1024,1,0,32,16,3,269,16,2049,1280,308,2341,1284,33,256,32,1296,513]

theorem envBound56229 : H12AffineFastState.Bounded env56229 := by
  intro p hp
  have h : env56229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56228_56229 : H12AffineEnvironment.transform 11 308 env56228 = env56229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env56228 == env56229) = true)

theorem identity56229 : scanCanonicalize (H12AffineFastState.compose env56229 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound56229 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56230 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,308,269,1297,0,262,1280,1077,1024,1,0,32,16,3,269,16,1297,1280,308,1077,1284,33,256,32,1296,513]

theorem envBound56230 : H12AffineFastState.Bounded env56230 := by
  intro p hp
  have h : env56230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56229_56230 : H12AffineEnvironment.transform 10 1296 env56229 = env56230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env56229 == env56230) = true)

theorem identity56230 : scanCanonicalize (H12AffineFastState.compose env56230 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56230 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env56231 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,308,269,293,0,262,308,1,52,1,0,32,16,3,269,16,293,308,308,1,304,33,256,32,292,513]

theorem envBound56231 : H12AffineFastState.Bounded env56231 := by
  intro p hp
  have h : env56231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56230_56231 : H12AffineEnvironment.transform 9 52 env56230 = env56231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56230 == env56231) = true)

theorem identity56231 : scanCanonicalize (H12AffineFastState.compose env56231 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound56231 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56232 : List Nat := [2,4,8,16,32,17,8,256,260,52,292,308,269,293,0,262,308,1,52,1,0,32,16,3,269,16,293,308,308,1,304,33,256,32,292,261]

theorem envBound56232 : H12AffineFastState.Bounded env56232 := by
  intro p hp
  have h : env56232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56231_56232 : H12AffineEnvironment.transform 8 260 env56231 = env56232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env56231 == env56232) = true)

def env56233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound56233 : H12AffineFastState.Bounded env56233 := by
  intro p hp
  have h : env56233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56074_56233 : H12AffineEnvironment.transform 18 1025 env56074 = env56233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env56074 == env56233) = true)

theorem identity56233 : scanCanonicalize (H12AffineFastState.compose env56233 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 297334) := by decide +kernel

theorem selectedBound56233 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8328,65,12798327,2428410,10507600,8830976,8719719,6679735,257,10833371,10857598,8661681]

theorem envBound56234 : H12AffineFastState.Bounded env56234 := by
  intro p hp
  have h : env56234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56233_56234 : H12AffineEnvironment.transform 23 297334 env56233 = env56234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297334 env56233 == env56234) = true)

def env56235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12798327,2428274,10507600,8830976,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound56235 : H12AffineFastState.Bounded env56235 := by
  intro p hp
  have h : env56235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56234_56235 : H12AffineEnvironment.transform 6 8 env56234 = env56235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56234 == env56235) = true)

def env56236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650855,2428274,10507600,8683536,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound56236 : H12AffineFastState.Bounded env56236 := by
  intro p hp
  have h : env56236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56235_56236 : H12AffineEnvironment.transform 16 16400 env56235 = env56236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env56235 == env56236) = true)

theorem identity56236 : scanCanonicalize (H12AffineFastState.compose env56236 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound56236 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env56237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,17,297334,8192,65,4262262,2428274,2118977,294913,331126,6679615,257,2444610,2468975,272936]

theorem envBound56237 : H12AffineFastState.Bounded env56237 := by
  intro p hp
  have h : env56237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56236_56237 : H12AffineEnvironment.transform 22 17 env56236 = env56237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56236 == env56237) = true)

def env56238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,17,41310,8192,65,4262262,2172250,2118977,43049,75102,6407191,257,2188650,2196551,512]

theorem envBound56238 : H12AffineFastState.Bounded env56238 := by
  intro p hp
  have h : env56238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56237_56238 : H12AffineEnvironment.transform 17 10280 env56237 = env56238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env56237 == env56238) = true)

theorem identity56238 : scanCanonicalize (H12AffineFastState.compose env56238 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 116067) := by decide +kernel

theorem selectedBound56238 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,116067,4194304,17,41310,8192,65,4262262,57401,102434,43049,75102,4194676,257,40969,16676,512]

theorem envBound56239 : H12AffineFastState.Bounded env56239 := by
  intro p hp
  have h : env56239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56238_56239 : H12AffineEnvironment.transform 20 116067 env56238 = env56239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 116067 env56238 == env56239) = true)

theorem identity56239 : scanCanonicalize (H12AffineFastState.compose env56239 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound56239 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env56240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,10280,1025,32769,17460,4194304,17,41310,8192,65,4229153,57401,4469,43049,41993,4194676,257,40969,16676,512]

theorem envBound56240 : H12AffineFastState.Bounded env56240 := by
  intro p hp
  have h : env56240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56239_56240 : H12AffineEnvironment.transform 15 33111 env56239 = env56240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env56239 == env56240) = true)

theorem identity56240 : scanCanonicalize (H12AffineFastState.compose env56240 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 26665) := by decide +kernel

theorem selectedBound56240 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,16400,10280,1025,32769,17460,26665,17,41310,8192,65,57352,57401,4469,43049,41993,26973,257,40969,16676,512]

theorem envBound56241 : H12AffineFastState.Bounded env56241 := by
  intro p hp
  have h : env56241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56240_56241 : H12AffineEnvironment.transform 21 26665 env56240 = env56241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 26665 env56240 == env56241) = true)

theorem identity56241 : scanCanonicalize (H12AffineFastState.compose env56241 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13437) := by decide +kernel

theorem selectedBound56241 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env56242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,32768,33111,13421,10280,1025,32769,12361,7252,17,41310,8192,65,38005,37956,4469,43049,41993,7456,257,40969,13657,512]

theorem envBound56242 : H12AffineFastState.Bounded env56242 := by
  intro p hp
  have h : env56242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56241_56242 : H12AffineEnvironment.transform 13 13437 env56241 = env56242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13437 env56241 == env56242) = true)

theorem identity56242 : scanCanonicalize (H12AffineFastState.compose env56242 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 6160) := by decide +kernel

theorem selectedBound56242 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56243 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13437,6160,6471,13421,10280,1025,6161,12361,7252,17,14670,8192,65,3173,3156,4469,12345,15385,7456,257,14361,13657,512]

theorem envBound56243 : H12AffineFastState.Bounded env56243 := by
  intro p hp
  have h : env56243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56242_56243 : H12AffineEnvironment.transform 14 6160 env56242 = env56243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6160 env56242 == env56243) = true)

theorem identity56243 : scanCanonicalize (H12AffineFastState.compose env56243 (packedSelected [9,14,22] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound56243 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env56244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10249,1124,1331,10265,10280,1025,1125,11325,32,17,9530,8192,65,3173,3156,3329,11341,8301,340,257,9325,10541,512]

theorem envBound56244 : H12AffineFastState.Bounded env56244 := by
  intro p hp
  have h : env56244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56243_56244 : H12AffineEnvironment.transform 11 3188 env56243 = env56244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env56243 == env56244) = true)

theorem identity56244 : scanCanonicalize (H12AffineFastState.compose env56244 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound56244 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env56245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,1352,3393,1124,1331,3409,3424,1025,1125,2421,32,17,114,1352,65,3173,3156,3329,2309,1317,340,257,293,3173,512]

theorem envBound56245 : H12AffineFastState.Bounded env56245 := by
  intro p hp
  have h : env56245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56244_56245 : H12AffineEnvironment.transform 12 1352 env56244 = env56245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env56244 == env56245) = true)

theorem identity56245 : scanCanonicalize (H12AffineFastState.compose env56245 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound56245 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env56246 : List Nat := [2,4,8,16,32,64,8,256,512,68,2048,2096,268,2309,32,375,2325,2340,69,33,2421,32,17,114,268,65,2081,2064,2373,2309,353,340,257,293,2081,512]

theorem envBound56246 : H12AffineFastState.Bounded env56246 := by
  intro p hp
  have h : env56246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56245_56246 : H12AffineEnvironment.transform 9 68 env56245 = env56246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env56245 == env56246) = true)

theorem identity56246 : scanCanonicalize (H12AffineFastState.compose env56246 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound56246 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56247 : List Nat := [2,4,8,16,32,48,8,256,512,52,2048,2096,268,2309,32,263,2325,2340,53,33,2309,32,17,2,268,49,2081,2064,2357,2309,273,292,257,293,2081,512]

theorem envBound56247 : H12AffineFastState.Bounded env56247 := by
  intro p hp
  have h : env56247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56246_56247 : H12AffineEnvironment.transform 5 48 env56246 = env56247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56246 == env56247) = true)

theorem identity56247 : scanCanonicalize (H12AffineFastState.compose env56247 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56247 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env56248 : List Nat := [2,4,8,16,32,48,8,4,512,52,2048,2096,8,2049,32,3,2065,2080,53,33,2049,32,17,2,8,49,2081,2064,2097,2049,21,32,5,33,2081,512]

theorem envBound56248 : H12AffineFastState.Bounded env56248 := by
  intro p hp
  have h : env56248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56247_56248 : H12AffineEnvironment.transform 7 4 env56247 = env56248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56247 == env56248) = true)

theorem identity56248 : scanCanonicalize (H12AffineFastState.compose env56248 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound56248 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56249 : List Nat := [2,4,8,16,32,48,8,4,33,52,2048,2096,8,2049,32,3,2065,2080,53,33,2049,32,17,2,8,49,2081,2064,2097,2049,21,32,5,33,2081,33]

theorem envBound56249 : H12AffineFastState.Bounded env56249 := by
  intro p hp
  have h : env56249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56248_56249 : H12AffineEnvironment.transform 8 33 env56248 = env56249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env56248 == env56249) = true)

theorem identity56249 : scanCanonicalize (H12AffineFastState.compose env56249 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56249 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56250 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,2065,8,2049,1,3,2065,2049,20,0,2049,1,17,2,8,16,2048,2064,2064,2049,21,1,5,0,2048,0]

theorem envBound56250 : H12AffineFastState.Bounded env56250 := by
  intro p hp
  have h : env56250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56249_56250 : H12AffineEnvironment.transform 4 1 env56249 = env56250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56249 == env56250) = true)

theorem identity56250 : scanCanonicalize (H12AffineFastState.compose env56250 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound56250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56251 : List Nat := [2,4,8,4,1,5,8,4,0,1,2048,2053,8,2049,1,3,2053,2049,0,0,2049,1,5,2,8,4,2048,2052,2052,2049,1,1,5,0,2048,0]

theorem envBound56251 : H12AffineFastState.Bounded env56251 := by
  intro p hp
  have h : env56251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56250_56251 : H12AffineEnvironment.transform 3 4 env56250 = env56251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env56250 == env56251) = true)

def leafEnv56251 : List Nat := [2,4,8,4,1,5,8,4,0,1,2048,2053,8,2049,1,3,2053,2049,0,0,2049,1,5,2,0,8,1,4,2048,2052,2052,2049,1,1,5,0,5,3,2048,0,1,2048,0]

def active56251 : List Nat := [0,1,2,10]

def tree56251 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56251 : H12WitnessSearch.Good tree56251 := H12GlobalWitnessIndex.good

theorem leafIdentity56251 : H12AffineFastState.composeSystem env56251 rootObs = leafEnv56251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56251 rootObs == leafEnv56251) = true)

theorem terminalChecked56251 : H12PackedTerminal.terminalCheckFast leafEnv56251 active56251 tree56251 = true := by decide +kernel

def env56252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41311,8192,65,4262262,2172251,2118977,43048,75103,6407190,257,2188651,2196550,513]

theorem envBound56252 : H12AffineFastState.Bounded env56252 := by
  intro p hp
  have h : env56252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56237_56252 : H12AffineEnvironment.transform 17 10281 env56237 = env56252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56237 == env56252) = true)

theorem identity56252 : scanCanonicalize (H12AffineFastState.compose env56252 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound56252 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env56253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115734,4194304,17,41311,8192,65,4262262,57677,102743,43048,75103,4194304,257,41341,16464,513]

theorem envBound56253 : H12AffineFastState.Bounded env56253 := by
  intro p hp
  have h : env56253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56252_56253 : H12AffineEnvironment.transform 20 115734 env56252 = env56253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env56252 == env56253) = true)

theorem identity56253 : scanCanonicalize (H12AffineFastState.compose env56253 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound56253 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env56254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115734,8573,17,41311,8192,65,75787,57677,102743,43048,75103,8573,257,41341,16464,513]

theorem envBound56254 : H12AffineFastState.Bounded env56254 := by
  intro p hp
  have h : env56254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56253_56254 : H12AffineEnvironment.transform 21 8573 env56253 = env56254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env56253 == env56254) = true)

theorem identity56254 : scanCanonicalize (H12AffineFastState.compose env56254 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound56254 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env56255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10281,1025,32769,25629,8573,17,41311,8192,65,34816,57677,12636,43048,34132,8573,257,41341,16464,513]

theorem envBound56255 : H12AffineFastState.Bounded env56255 := by
  intro p hp
  have h : env56255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56254_56255 : H12AffineEnvironment.transform 15 40971 env56254 = env56255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env56254 == env56255) = true)

theorem identity56255 : scanCanonicalize (H12AffineFastState.compose env56255 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56255 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env56256 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10281,1025,32769,25629,8492,17,41230,8192,16,34816,57628,12557,43048,34053,8492,257,41260,16385,513]

theorem envBound56256 : H12AffineFastState.Bounded env56256 := by
  intro p hp
  have h : env56256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56255_56256 : H12AffineEnvironment.transform 5 17 env56255 = env56256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56255 == env56256) = true)

theorem identity56256 : scanCanonicalize (H12AffineFastState.compose env56256 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56257 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,33031,16400,2341,1025,32769,17681,32,17,32770,268,16,34816,49168,4097,35108,34053,32,257,32800,16385,513]

theorem envBound56257 : H12AffineFastState.Bounded env56257 := by
  intro p hp
  have h : env56257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56256_56257 : H12AffineEnvironment.transform 12 268 env56256 = env56257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56256 == env56257) = true)

theorem identity56257 : scanCanonicalize (H12AffineFastState.compose env56257 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56257 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56258 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,262,16400,2341,1025,0,17681,32,17,3,268,16,2049,16401,4097,2341,1284,32,257,33,16385,513]

theorem envBound56258 : H12AffineFastState.Bounded env56258 := by
  intro p hp
  have h : env56258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56257_56258 : H12AffineEnvironment.transform 14 1 env56257 = env56258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56257 == env56258) = true)

theorem identity56258 : scanCanonicalize (H12AffineFastState.compose env56258 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4389) := by decide +kernel

theorem selectedBound56258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56259 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,4389,1,262,4405,2341,1025,0,5172,32,17,3,268,16,2049,4404,4097,2341,1284,32,257,33,4388,513]

theorem envBound56259 : H12AffineFastState.Bounded env56259 := by
  intro p hp
  have h : env56259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56258_56259 : H12AffineEnvironment.transform 13 4389 env56258 = env56259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4389 env56258 == env56259) = true)

theorem identity56259 : scanCanonicalize (H12AffineFastState.compose env56259 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound56259 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56260 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,513,268,804,1,262,820,2341,1025,0,1589,32,17,3,268,16,2049,821,512,2341,1284,32,257,33,805,513]

theorem envBound56260 : H12AffineFastState.Bounded env56260 := by
  intro p hp
  have h : env56260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56259_56260 : H12AffineEnvironment.transform 11 513 env56259 = env56260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env56259 == env56260) = true)

theorem identity56260 : scanCanonicalize (H12AffineFastState.compose env56260 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound56260 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56261 : List Nat := [2,4,8,16,32,17,8,256,512,769,2048,513,268,804,1,262,820,2341,768,0,308,32,17,3,268,16,2049,821,512,2341,517,32,257,33,805,513]

theorem envBound56261 : H12AffineFastState.Bounded env56261 := by
  intro p hp
  have h : env56261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56260_56261 : H12AffineEnvironment.transform 9 769 env56260 = env56261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env56260 == env56261) = true)

theorem identity56261 : scanCanonicalize (H12AffineFastState.compose env56261 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound56261 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56262 : List Nat := [2,4,8,16,32,17,8,53,512,564,2048,513,57,529,1,51,513,2064,565,0,1,32,17,3,57,16,2049,512,512,2064,517,32,52,33,528,513]

theorem envBound56262 : H12AffineFastState.Bounded env56262 := by
  intro p hp
  have h : env56262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56261_56262 : H12AffineEnvironment.transform 7 53 env56261 = env56262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env56261 == env56262) = true)

theorem identity56262 : scanCanonicalize (H12AffineFastState.compose env56262 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound56262 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56263 : List Nat := [2,4,8,16,32,17,8,53,512,564,17,513,57,529,1,51,513,1,565,0,1,32,17,3,57,16,16,512,512,1,517,32,52,33,528,513]

theorem envBound56263 : H12AffineFastState.Bounded env56263 := by
  intro p hp
  have h : env56263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56262_56263 : H12AffineEnvironment.transform 10 17 env56262 = env56263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env56262 == env56263) = true)

theorem identity56263 : scanCanonicalize (H12AffineFastState.compose env56263 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56263 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56264 : List Nat := [2,4,8,16,0,17,8,21,512,532,17,513,25,529,1,19,513,1,533,0,1,0,17,3,25,16,16,512,512,1,517,0,20,1,528,513]

theorem envBound56264 : H12AffineFastState.Bounded env56264 := by
  intro p hp
  have h : env56264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56263_56264 : H12AffineEnvironment.transform 4 0 env56263 = env56264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56263 == env56264) = true)

theorem identity56264 : scanCanonicalize (H12AffineFastState.compose env56264 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56264 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56265 : List Nat := [2,4,8,16,0,17,8,21,0,20,17,1,25,17,1,19,1,1,21,0,1,0,17,3,25,16,16,0,0,1,5,0,20,1,16,1]

theorem envBound56265 : H12AffineFastState.Bounded env56265 := by
  intro p hp
  have h : env56265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56264_56265 : H12AffineEnvironment.transform 8 0 env56264 = env56265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56264 == env56265) = true)

def env56266 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8192,65,12650854,2428274,10507600,8683537,8719719,6679615,257,10833235,10857598,8661561]

theorem envBound56266 : H12AffineFastState.Bounded env56266 := by
  intro p hp
  have h : env56266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56235_56266 : H12AffineEnvironment.transform 16 16401 env56235 = env56266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56235 == env56266) = true)

theorem identity56266 : scanCanonicalize (H12AffineFastState.compose env56266 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound56266 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env56267 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,8388608,41311,8192,65,12650854,2172251,10507600,8431672,8463694,6407190,257,10577274,10585175,8389136]

theorem envBound56267 : H12AffineFastState.Bounded env56267 := by
  intro p hp
  have h : env56267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56266_56267 : H12AffineEnvironment.transform 17 10281 env56266 = env56267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56266 == env56267) = true)

def env56268 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,16,41311,8192,65,4262262,2172251,2118976,43048,75102,6407190,257,2188650,2196551,512]

theorem envBound56268 : H12AffineFastState.Bounded env56268 := by
  intro p hp
  have h : env56268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56267_56268 : H12AffineEnvironment.transform 22 16 env56267 = env56268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env56267 == env56268) = true)

theorem identity56268 : scanCanonicalize (H12AffineFastState.compose env56268 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58728) := by decide +kernel

theorem selectedBound56268 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env56269 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58728,4194304,16,41311,8192,65,4262262,114739,45096,43048,75102,4268414,257,98306,90415,512]

theorem envBound56269 : H12AffineFastState.Bounded env56269 := by
  intro p hp
  have h : env56269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56268_56269 : H12AffineEnvironment.transform 20 58728 env56268 = env56269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58728 env56268 == env56269) = true)

theorem identity56269 : scanCanonicalize (H12AffineFastState.compose env56269 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound56269 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env56270 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58728,98679,16,41311,8192,65,34817,114739,45096,43048,75102,40969,257,98306,90415,512]

theorem envBound56270 : H12AffineFastState.Bounded env56270 := by
  intro p hp
  have h : env56270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56269_56270 : H12AffineEnvironment.transform 21 98679 env56269 = env56270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env56269 == env56270) = true)

theorem identity56270 : scanCanonicalize (H12AffineFastState.compose env56270 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 61499) := by decide +kernel

theorem selectedBound56270 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,61499,16401,10281,1025,32769,58728,29004,16,41311,8192,65,34817,12296,45096,43048,54629,40969,257,28729,37140,512]

theorem envBound56271 : H12AffineFastState.Bounded env56271 := by
  intro p hp
  have h : env56271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56270_56271 : H12AffineEnvironment.transform 15 61499 env56270 = env56271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61499 env56270 == env56271) = true)

theorem identity56271 : scanCanonicalize (H12AffineFastState.compose env56271 (packedSelected [12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56271 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env56272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,42299,5393,10281,1025,32769,45160,9292,16,41311,8192,65,34817,12296,45096,43048,32869,40969,257,9529,37140,512]

theorem envBound56272 : H12AffineFastState.Bounded env56272 := by
  intro p hp
  have h : env56272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56271_56272 : H12AffineEnvironment.transform 13 5376 env56271 = env56272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56271 == env56272) = true)

theorem identity56272 : scanCanonicalize (H12AffineFastState.compose env56272 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound56272 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env56273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1076,8463,5393,10281,1025,1077,13404,9292,16,9579,8192,65,3125,12296,13340,11292,1105,9277,257,9529,5408,512]

theorem envBound56273 : H12AffineFastState.Bounded env56273 := by
  intro p hp
  have h : env56273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56272_56273 : H12AffineEnvironment.transform 14 1076 env56272 = env56273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env56272 == env56273) = true)

theorem identity56273 : scanCanonicalize (H12AffineFastState.compose env56273 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound56273 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env56274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5376,1076,1126,5393,3392,1025,1077,4405,293,16,2,1385,65,3125,5473,4469,2421,1105,340,257,80,5408,512]

theorem envBound56274 : H12AffineFastState.Bounded env56274 := by
  intro p hp
  have h : env56274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56273_56274 : H12AffineEnvironment.transform 12 1385 env56273 = env56274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env56273 == env56274) = true)

theorem identity56274 : scanCanonicalize (H12AffineFastState.compose env56274 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound56274 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56275 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,40,4161,373,295,4176,2049,320,372,4405,293,16,2,40,65,2420,4128,4469,2421,272,340,257,80,4193,512]

theorem envBound56275 : H12AffineFastState.Bounded env56275 := by
  intro p hp
  have h : env56275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56274_56275 : H12AffineEnvironment.transform 9 321 env56274 = env56275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56274 == env56275) = true)

theorem identity56275 : scanCanonicalize (H12AffineFastState.compose env56275 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound56275 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56276 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,40,4161,1,83,4176,2049,52,0,4161,81,16,2,40,65,2048,4128,4097,2049,100,32,117,80,4193,512]

theorem envBound56276 : H12AffineFastState.Bounded env56276 := by
  intro p hp
  have h : env56276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56275_56276 : H12AffineEnvironment.transform 7 116 env56275 = env56276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env56275 == env56276) = true)

theorem identity56276 : scanCanonicalize (H12AffineFastState.compose env56276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound56276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56277 : List Nat := [2,4,8,16,32,49,8,5,512,53,2048,4096,40,4144,1,34,4129,2049,52,0,4144,32,16,2,40,48,2048,4128,4097,2049,21,32,4,33,4112,512]

theorem envBound56277 : H12AffineFastState.Bounded env56277 := by
  intro p hp
  have h : env56277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56276_56277 : H12AffineEnvironment.transform 5 49 env56276 = env56277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env56276 == env56277) = true)

theorem identity56277 : scanCanonicalize (H12AffineFastState.compose env56277 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound56277 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56278 : List Nat := [2,4,8,16,32,49,8,5,33,53,2048,4096,40,4144,1,34,4129,2049,52,0,4144,32,16,2,40,48,2048,4128,4097,2049,21,32,4,33,4112,33]

theorem envBound56278 : H12AffineFastState.Bounded env56278 := by
  intro p hp
  have h : env56278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56277_56278 : H12AffineEnvironment.transform 8 33 env56277 = env56278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env56277 == env56278) = true)

theorem identity56278 : scanCanonicalize (H12AffineFastState.compose env56278 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound56278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56279 : List Nat := [2,4,8,16,32,49,8,5,33,53,2048,17,40,33,1,34,48,2049,52,0,33,32,16,2,40,48,2048,49,16,2049,21,32,4,33,1,33]

theorem envBound56279 : H12AffineFastState.Bounded env56279 := by
  intro p hp
  have h : env56279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56278_56279 : H12AffineEnvironment.transform 11 17 env56278 = env56279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env56278 == env56279) = true)

theorem identity56279 : scanCanonicalize (H12AffineFastState.compose env56279 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound56279 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56280 : List Nat := [2,4,8,16,1,16,8,5,0,20,2048,17,9,0,1,3,17,2049,21,0,0,1,16,2,9,17,2048,16,16,2049,21,1,4,0,1,0]

theorem envBound56280 : H12AffineFastState.Bounded env56280 := by
  intro p hp
  have h : env56280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56279_56280 : H12AffineEnvironment.transform 4 1 env56279 = env56280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env56279 == env56280) = true)

theorem identity56280 : scanCanonicalize (H12AffineFastState.compose env56280 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound56280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56281 : List Nat := [2,4,6,16,1,16,6,5,0,20,2048,17,7,0,1,3,17,2049,21,0,0,1,16,2,7,17,2048,16,16,2049,21,1,4,0,1,0]

theorem envBound56281 : H12AffineFastState.Bounded env56281 := by
  intro p hp
  have h : env56281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56280_56281 : H12AffineEnvironment.transform 2 6 env56280 = env56281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env56280 == env56281) = true)

theorem identity56281 : scanCanonicalize (H12AffineFastState.compose env56281 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound56281 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56282 : List Nat := [2,4,6,16,1,16,6,5,0,20,0,17,7,0,1,3,17,1,21,0,0,1,16,2,7,17,0,16,16,1,21,1,4,0,1,0]

theorem envBound56282 : H12AffineFastState.Bounded env56282 := by
  intro p hp
  have h : env56282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56281_56282 : H12AffineEnvironment.transform 10 0 env56281 = env56282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env56281 == env56282) = true)

def env56283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41311,8192,65,4262263,2172251,2118977,43049,75103,6407190,257,2188651,2196550,513]

theorem envBound56283 : H12AffineFastState.Bounded env56283 := by
  intro p hp
  have h : env56283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56267_56283 : H12AffineEnvironment.transform 22 17 env56267 = env56283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env56267 == env56283) = true)

def env56284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41311,8192,65,4262263,115015,45405,43049,75103,4268042,257,98679,90202,513]

theorem envBound56284 : H12AffineFastState.Bounded env56284 := by
  intro p hp
  have h : env56284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56283_56284 : H12AffineEnvironment.transform 20 58396 env56283 = env56284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env56283 == env56284) = true)

theorem identity56284 : scanCanonicalize (H12AffineFastState.compose env56284 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound56284 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env56285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,41341,17,41311,8192,65,108554,115015,45405,43049,75103,98679,257,98679,90202,513]

theorem envBound56285 : H12AffineFastState.Bounded env56285 := by
  intro p hp
  have h : env56285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56284_56285 : H12AffineEnvironment.transform 21 41341 env56284 = env56285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env56284 == env56285) = true)

theorem identity56285 : scanCanonicalize (H12AffineFastState.compose env56285 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56285 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env56286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10281,1025,32769,58396,41341,17,41311,8192,65,34816,57677,45405,43049,1365,41341,257,41341,16464,513]

theorem envBound56286 : H12AffineFastState.Bounded env56286 := by
  intro p hp
  have h : env56286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56285_56286 : H12AffineEnvironment.transform 15 8202 env56285 = env56286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56285 == env56286) = true)

theorem identity56286 : scanCanonicalize (H12AffineFastState.compose env56286 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56286 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,16401,2421,1025,32769,50496,32801,17,32771,348,65,34816,49169,36865,35189,1365,32801,257,32801,16464,513]

theorem envBound56287 : H12AffineFastState.Bounded env56287 := by
  intro p hp
  have h : env56287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56286_56287 : H12AffineEnvironment.transform 12 348 env56286 = env56287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56286 == env56287) = true)

theorem identity56287 : scanCanonicalize (H12AffineFastState.compose env56287 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound56287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,342,16401,2421,1025,0,17729,32,17,2,348,65,2049,16400,4096,2420,1365,32,257,32,16464,513]

theorem envBound56288 : H12AffineFastState.Bounded env56288 := by
  intro p hp
  have h : env56288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56287_56288 : H12AffineEnvironment.transform 14 1 env56287 = env56288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env56287 == env56288) = true)

theorem identity56288 : scanCanonicalize (H12AffineFastState.compose env56288 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 602) := by decide +kernel

theorem selectedBound56288 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,602,4096,348,16384,1,342,16401,815,1025,0,17729,32,17,2,348,65,603,16400,4096,814,1365,32,257,32,16464,513]

theorem envBound56289 : H12AffineFastState.Bounded env56289 := by
  intro p hp
  have h : env56289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56288_56289 : H12AffineEnvironment.transform 10 602 env56288 = env56289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 602 env56288 == env56289) = true)

theorem identity56289 : scanCanonicalize (H12AffineFastState.compose env56289 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56289 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,602,4096,348,5376,1,342,5393,815,1025,0,4161,32,17,2,348,65,603,5392,4096,814,1365,32,257,32,5456,513]

theorem envBound56290 : H12AffineFastState.Bounded env56290 := by
  intro p hp
  have h : env56290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56289_56290 : H12AffineEnvironment.transform 13 5376 env56289 = env56290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56289 == env56290) = true)

theorem identity56290 : scanCanonicalize (H12AffineFastState.compose env56290 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound56290 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56291 : List Nat := [2,4,8,16,32,64,8,117,512,1024,602,4096,41,5237,1,35,5220,602,1025,0,4161,32,17,2,41,65,603,5221,4096,603,1056,32,116,32,5157,513]

theorem envBound56291 : H12AffineFastState.Bounded env56291 := by
  intro p hp
  have h : env56291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56290_56291 : H12AffineEnvironment.transform 7 117 env56290 = env56291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env56290 == env56291) = true)

theorem identity56291 : scanCanonicalize (H12AffineFastState.compose env56291 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound56291 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56292 : List Nat := [2,4,8,16,32,64,8,117,512,575,602,4096,41,4682,1,35,4699,602,574,0,4161,32,17,2,41,65,603,4698,4096,603,543,32,116,32,4634,513]

theorem envBound56292 : H12AffineFastState.Bounded env56292 := by
  intro p hp
  have h : env56292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56291_56292 : H12AffineEnvironment.transform 9 575 env56291 = env56292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env56291 == env56292) = true)

theorem identity56292 : scanCanonicalize (H12AffineFastState.compose env56292 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound56292 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56293 : List Nat := [2,4,8,16,32,64,8,117,123,68,33,4096,41,4145,1,35,4128,33,69,0,4161,32,17,2,41,65,32,4129,4096,32,100,32,116,32,4193,122]

theorem envBound56293 : H12AffineFastState.Bounded env56293 := by
  intro p hp
  have h : env56293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56292_56293 : H12AffineEnvironment.transform 8 123 env56292 = env56293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env56292 == env56293) = true)

theorem identity56293 : scanCanonicalize (H12AffineFastState.compose env56293 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound56293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56294 : List Nat := [2,4,8,16,8,64,8,93,83,68,9,4096,1,4121,1,11,4104,9,69,0,4161,8,17,2,1,65,8,4105,4096,8,76,8,92,8,4169,82]

theorem envBound56294 : H12AffineFastState.Bounded env56294 := by
  intro p hp
  have h : env56294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56293_56294 : H12AffineEnvironment.transform 4 8 env56293 = env56294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env56293 == env56294) = true)

theorem identity56294 : scanCanonicalize (H12AffineFastState.compose env56294 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56294 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env56295 : List Nat := [2,4,8,16,8,16,8,13,3,20,9,4096,1,4121,1,11,4104,9,21,0,4113,8,17,2,1,17,8,4105,4096,8,28,8,12,8,4121,2]

theorem envBound56295 : H12AffineFastState.Bounded env56295 := by
  intro p hp
  have h : env56295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56294_56295 : H12AffineEnvironment.transform 5 16 env56294 = env56295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56294 == env56295) = true)

theorem identity56295 : scanCanonicalize (H12AffineFastState.compose env56295 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 24) := by decide +kernel

theorem selectedBound56295 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56296 : List Nat := [2,4,8,16,8,16,8,13,3,20,9,24,1,1,1,11,16,9,21,0,9,8,17,2,1,17,8,17,24,8,28,8,12,8,1,2]

theorem envBound56296 : H12AffineFastState.Bounded env56296 := by
  intro p hp
  have h : env56296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56295_56296 : H12AffineEnvironment.transform 11 24 env56295 = env56296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 24 env56295 == env56296) = true)

theorem identity56296 : scanCanonicalize (H12AffineFastState.compose env56296 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound56296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56297 : List Nat := [2,4,6,16,6,16,6,3,3,20,7,22,1,1,1,5,16,7,21,0,7,6,17,2,1,17,6,17,22,6,18,6,2,6,1,2]

theorem envBound56297 : H12AffineFastState.Bounded env56297 := by
  intro p hp
  have h : env56297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56296_56297 : H12AffineEnvironment.transform 2 6 env56296 = env56297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env56296 == env56297) = true)

theorem identity56297 : scanCanonicalize (H12AffineFastState.compose env56297 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56297 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56298 : List Nat := [2,3,1,16,1,16,1,3,3,19,0,17,1,1,1,2,16,0,18,0,0,1,17,2,1,17,1,17,17,1,18,1,2,1,1,2]

theorem envBound56298 : H12AffineFastState.Bounded env56298 := by
  intro p hp
  have h : env56298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56297_56298 : H12AffineEnvironment.transform 1 3 env56297 = env56298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56297 == env56298) = true)

def env56299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41311,8192,65,4262263,115014,45404,43049,75103,4268043,257,98678,90203,513]

theorem envBound56299 : H12AffineFastState.Bounded env56299 := by
  intro p hp
  have h : env56299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56283_56299 : H12AffineEnvironment.transform 20 58397 env56283 = env56299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env56283 == env56299) = true)

theorem identity56299 : scanCanonicalize (H12AffineFastState.compose env56299 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56299 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58397,4194304,17,41311,8192,65,4204924,57677,45404,43049,1364,4194304,257,41341,16464,513]

theorem envBound56300 : H12AffineFastState.Bounded env56300 := by
  intro p hp
  have h : env56300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56299_56300 : H12AffineEnvironment.transform 15 8203 env56299 = env56300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56299 == env56300) = true)

theorem identity56300 : scanCanonicalize (H12AffineFastState.compose env56300 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound56300 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58397,33,17,41311,8192,65,10589,57677,45404,43049,1364,33,257,41341,16464,513]

theorem envBound56301 : H12AffineFastState.Bounded env56301 := by
  intro p hp
  have h : env56301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56300_56301 : H12AffineEnvironment.transform 21 33 env56300 = env56301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env56300 == env56301) = true)

theorem identity56301 : scanCanonicalize (H12AffineFastState.compose env56301 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56301 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env56302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2340,1025,32769,50448,33,17,32850,269,65,2128,49216,36945,35108,1364,33,257,32880,16464,513]

theorem envBound56302 : H12AffineFastState.Bounded env56302 := by
  intro p hp
  have h : env56302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56301_56302 : H12AffineEnvironment.transform 12 269 env56301 = env56302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56301 == env56302) = true)

theorem identity56302 : scanCanonicalize (H12AffineFastState.compose env56302 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound56302 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,80,262,16401,2340,1025,81,17728,33,17,2,269,65,2128,16400,4097,2420,1364,33,257,32,16464,513]

theorem envBound56303 : H12AffineFastState.Bounded env56303 := by
  intro p hp
  have h : env56303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56302_56303 : H12AffineEnvironment.transform 14 80 env56302 = env56303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env56302 == env56303) = true)

theorem identity56303 : scanCanonicalize (H12AffineFastState.compose env56303 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56303 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env56304 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16401,2340,1025,1,17680,33,17,2,269,17,2048,16400,4097,2340,1284,33,257,32,16384,513]

theorem envBound56304 : H12AffineFastState.Bounded env56304 := by
  intro p hp
  have h : env56304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56303_56304 : H12AffineEnvironment.transform 5 16 env56303 = env56304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56303 == env56304) = true)

theorem identity56304 : scanCanonicalize (H12AffineFastState.compose env56304 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound56304 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56305 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5156,0,262,5173,2340,1025,1,4404,33,17,2,269,17,2048,5172,4097,2340,1284,33,257,32,5156,513]

theorem envBound56305 : H12AffineFastState.Bounded env56305 := by
  intro p hp
  have h : env56305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56304_56305 : H12AffineEnvironment.transform 13 5156 env56304 = env56305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env56304 == env56305) = true)

def env56306 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,269,2836,0,262,2821,2340,1025,1,3588,33,17,2,269,17,2048,2820,3889,2340,1284,33,257,32,2836,513]

theorem envBound56306 : H12AffineFastState.Bounded env56306 := by
  intro p hp
  have h : env56306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56305_56306 : H12AffineEnvironment.transform 11 3888 env56305 = env56306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env56305 == env56306) = true)

def env56307 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,269,1044,0,262,1029,1572,1025,1,260,33,17,2,269,17,1792,1028,49,1572,1284,33,257,32,1044,513]

theorem envBound56307 : H12AffineFastState.Bounded env56307 := by
  intro p hp
  have h : env56307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56306_56307 : H12AffineEnvironment.transform 10 1792 env56306 = env56307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env56306 == env56307) = true)

theorem identity56307 : scanCanonicalize (H12AffineFastState.compose env56307 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound56307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56308 : List Nat := [2,4,8,16,32,16,8,256,512,801,33,48,269,821,0,262,804,261,800,1,260,33,17,2,269,17,33,805,49,261,549,33,257,32,821,513]

theorem envBound56308 : H12AffineFastState.Bounded env56308 := by
  intro p hp
  have h : env56308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56307_56308 : H12AffineEnvironment.transform 9 801 env56307 = env56308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env56307 == env56308) = true)

def env56309 : List Nat := [2,4,8,16,32,16,8,256,276,53,33,48,269,33,0,262,48,261,52,1,260,33,17,2,269,17,33,49,49,261,305,33,257,32,33,277]

theorem envBound56309 : H12AffineFastState.Bounded env56309 := by
  intro p hp
  have h : env56309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56308_56309 : H12AffineEnvironment.transform 8 276 env56308 = env56309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env56308 == env56309) = true)

def env56310 : List Nat := [2,4,8,16,32,16,8,256,277,52,33,48,269,32,0,262,49,261,53,1,260,33,17,2,269,17,33,48,49,261,304,33,257,32,32,276]

theorem envBound56310 : H12AffineFastState.Bounded env56310 := by
  intro p hp
  have h : env56310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56308_56310 : H12AffineEnvironment.transform 8 277 env56308 = env56310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env56308 == env56310) = true)

theorem identity56310 : scanCanonicalize (H12AffineFastState.compose env56310 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56310 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56311 : List Nat := [2,4,8,10,32,10,8,256,271,46,33,42,269,32,0,262,43,261,47,1,260,33,11,2,269,11,33,42,43,261,298,33,257,32,32,270]

theorem envBound56311 : H12AffineFastState.Bounded env56311 := by
  intro p hp
  have h : env56311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56310_56311 : H12AffineEnvironment.transform 3 10 env56310 = env56311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56310 == env56311) = true)

def leafEnv56311 : List Nat := [2,4,8,10,32,10,8,256,271,46,33,42,269,32,0,262,43,261,47,1,260,33,11,2,299,269,1,11,33,42,43,261,298,33,257,32,5,262,32,270,1,260,0]

def active56311 : List Nat := [0,1,2,4,7]

def tree56311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56311 : H12WitnessSearch.Good tree56311 := H12GlobalWitnessIndex.good

theorem leafIdentity56311 : H12AffineFastState.composeSystem env56311 rootObs = leafEnv56311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56311 rootObs == leafEnv56311) = true)

theorem terminalChecked56311 : H12PackedTerminal.terminalCheckFast leafEnv56311 active56311 tree56311 = true := by decide +kernel

def env56312 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,269,1045,0,262,1028,1573,1025,1,261,33,17,2,269,17,1793,1029,48,1573,1284,33,257,32,1045,513]

theorem envBound56312 : H12AffineFastState.Bounded env56312 := by
  intro p hp
  have h : env56312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56306_56312 : H12AffineEnvironment.transform 10 1793 env56306 = env56312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env56306 == env56312) = true)

theorem identity56312 : scanCanonicalize (H12AffineFastState.compose env56312 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56313 : List Nat := [2,4,8,16,32,16,8,256,49,1024,1328,49,269,1045,0,262,1028,1044,1025,1,261,33,17,2,269,17,1328,1029,48,1044,1284,33,257,32,1045,48]

theorem envBound56313 : H12AffineFastState.Bounded env56313 := by
  intro p hp
  have h : env56313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56312_56313 : H12AffineEnvironment.transform 8 49 env56312 = env56313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56312 == env56313) = true)

def env56314 : List Nat := [2,4,8,16,32,16,8,256,49,52,260,49,269,33,0,262,48,32,53,1,261,33,17,2,269,17,260,49,48,32,304,33,257,32,33,48]

theorem envBound56314 : H12AffineFastState.Bounded env56314 := by
  intro p hp
  have h : env56314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56313_56314 : H12AffineEnvironment.transform 9 52 env56313 = env56314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56313 == env56314) = true)

theorem identity56314 : scanCanonicalize (H12AffineFastState.compose env56314 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound56314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56315 : List Nat := [2,4,8,16,32,16,8,63,49,52,59,49,50,33,0,57,48,32,53,1,58,33,17,2,50,17,59,49,48,32,15,33,62,32,33,48]

theorem envBound56315 : H12AffineFastState.Bounded env56315 := by
  intro p hp
  have h : env56315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56314_56315 : H12AffineEnvironment.transform 7 63 env56314 = env56315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env56314 == env56315) = true)

def leafEnv56315 : List Nat := [2,4,8,16,32,16,8,63,49,52,59,49,50,33,0,57,48,32,53,1,58,33,17,2,14,50,1,17,59,49,48,32,15,33,62,32,5,57,33,48,1,58,0]

def active56315 : List Nat := [0,1,2,3,4]

def tree56315 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56315 : H12WitnessSearch.Good tree56315 := H12GlobalWitnessIndex.good

theorem leafIdentity56315 : H12AffineFastState.composeSystem env56315 rootObs = leafEnv56315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56315 rootObs == leafEnv56315) = true)

theorem terminalChecked56315 : H12PackedTerminal.terminalCheckFast leafEnv56315 active56315 tree56315 = true := by decide +kernel

def env56316 : List Nat := [2,4,8,16,32,16,8,256,49,53,261,49,269,32,0,262,49,33,52,1,261,33,17,2,269,17,261,48,48,33,305,33,257,32,32,48]

theorem envBound56316 : H12AffineFastState.Bounded env56316 := by
  intro p hp
  have h : env56316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56313_56316 : H12AffineEnvironment.transform 9 53 env56313 = env56316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56313 == env56316) = true)

def env56317 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,269,2837,0,262,2820,2340,1025,1,3589,33,17,2,269,17,2048,2821,3888,2340,1284,33,257,32,2837,513]

theorem envBound56317 : H12AffineFastState.Bounded env56317 := by
  intro p hp
  have h : env56317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56305_56317 : H12AffineEnvironment.transform 11 3889 env56305 = env56317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env56305 == env56317) = true)

def env56318 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,269,1045,0,262,1028,1572,1025,1,261,33,17,2,269,17,1792,1029,48,1572,1284,33,257,32,1045,513]

theorem envBound56318 : H12AffineFastState.Bounded env56318 := by
  intro p hp
  have h : env56318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56317_56318 : H12AffineEnvironment.transform 10 1792 env56317 = env56318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env56317 == env56318) = true)

theorem identity56318 : scanCanonicalize (H12AffineFastState.compose env56318 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound56318 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56319 : List Nat := [2,4,8,16,32,16,8,256,276,1024,1044,49,269,1045,0,262,1028,1328,1025,1,261,33,17,2,269,17,1044,1029,48,1328,1284,33,257,32,1045,277]

theorem envBound56319 : H12AffineFastState.Bounded env56319 := by
  intro p hp
  have h : env56319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56318_56319 : H12AffineEnvironment.transform 8 276 env56318 = env56319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env56318 == env56319) = true)

def env56320 : List Nat := [2,4,8,16,32,16,8,256,276,52,32,49,269,33,0,262,48,260,53,1,261,33,17,2,269,17,32,49,48,260,304,33,257,32,33,277]

theorem envBound56320 : H12AffineFastState.Bounded env56320 := by
  intro p hp
  have h : env56320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56319_56320 : H12AffineEnvironment.transform 9 52 env56319 = env56320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56319 == env56320) = true)

theorem identity56320 : scanCanonicalize (H12AffineFastState.compose env56320 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56320 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56321 : List Nat := [2,4,8,10,32,10,8,256,270,46,32,43,269,33,0,262,42,260,47,1,261,33,11,2,269,11,32,43,42,260,298,33,257,32,33,271]

theorem envBound56321 : H12AffineFastState.Bounded env56321 := by
  intro p hp
  have h : env56321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56320_56321 : H12AffineEnvironment.transform 3 10 env56320 = env56321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56320 == env56321) = true)

def leafEnv56321 : List Nat := [2,4,8,10,32,10,8,256,270,46,32,43,269,33,0,262,42,260,47,1,261,33,11,2,299,269,1,11,32,43,42,260,298,33,257,32,5,262,33,271,1,261,0]

def active56321 : List Nat := [0,1,2,4,7]

def tree56321 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56321 : H12WitnessSearch.Good tree56321 := H12GlobalWitnessIndex.good

theorem leafIdentity56321 : H12AffineFastState.composeSystem env56321 rootObs = leafEnv56321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56321 rootObs == leafEnv56321) = true)

theorem terminalChecked56321 : H12PackedTerminal.terminalCheckFast leafEnv56321 active56321 tree56321 = true := by decide +kernel

def env56322 : List Nat := [2,4,8,16,32,16,8,256,276,53,33,49,269,32,0,262,49,261,52,1,261,33,17,2,269,17,33,48,48,261,305,33,257,32,32,277]

theorem envBound56322 : H12AffineFastState.Bounded env56322 := by
  intro p hp
  have h : env56322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56319_56322 : H12AffineEnvironment.transform 9 53 env56319 = env56322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56319 == env56322) = true)

def env56323 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,269,1044,0,262,1029,1573,1025,1,260,33,17,2,269,17,1793,1028,49,1573,1284,33,257,32,1044,513]

theorem envBound56323 : H12AffineFastState.Bounded env56323 := by
  intro p hp
  have h : env56323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56317_56323 : H12AffineEnvironment.transform 10 1793 env56317 = env56323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env56317 == env56323) = true)

theorem identity56323 : scanCanonicalize (H12AffineFastState.compose env56323 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound56323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56324 : List Nat := [2,4,8,16,32,16,8,256,512,516,261,48,269,528,0,262,513,33,517,1,260,33,17,2,269,17,261,512,49,33,768,33,257,32,528,513]

theorem envBound56324 : H12AffineFastState.Bounded env56324 := by
  intro p hp
  have h : env56324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56323_56324 : H12AffineEnvironment.transform 9 516 env56323 = env56324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env56323 == env56324) = true)

def env56325 : List Nat := [2,4,8,16,32,16,8,256,48,52,261,48,269,32,0,262,49,33,53,1,260,33,17,2,269,17,261,48,49,33,304,33,257,32,32,49]

theorem envBound56325 : H12AffineFastState.Bounded env56325 := by
  intro p hp
  have h : env56325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56324_56325 : H12AffineEnvironment.transform 8 48 env56324 = env56325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env56324 == env56325) = true)

theorem identity56325 : scanCanonicalize (H12AffineFastState.compose env56325 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound56325 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56326 : List Nat := [2,4,8,16,32,16,8,63,48,52,58,48,50,32,0,57,49,33,53,1,59,33,17,2,50,17,58,48,49,33,15,33,62,32,32,49]

theorem envBound56326 : H12AffineFastState.Bounded env56326 := by
  intro p hp
  have h : env56326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56325_56326 : H12AffineEnvironment.transform 7 63 env56325 = env56326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env56325 == env56326) = true)

def leafEnv56326 : List Nat := [2,4,8,16,32,16,8,63,48,52,58,48,50,32,0,57,49,33,53,1,59,33,17,2,14,50,1,17,58,48,49,33,15,33,62,32,5,57,32,49,1,59,0]

def active56326 : List Nat := [0,1,2,3,4]

def tree56326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56326 : H12WitnessSearch.Good tree56326 := H12GlobalWitnessIndex.good

theorem leafIdentity56326 : H12AffineFastState.composeSystem env56326 rootObs = leafEnv56326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56326 rootObs == leafEnv56326) = true)

theorem terminalChecked56326 : H12PackedTerminal.terminalCheckFast leafEnv56326 active56326 tree56326 = true := by decide +kernel

def env56327 : List Nat := [2,4,8,16,32,16,8,256,49,53,261,48,269,33,0,262,48,33,52,1,260,33,17,2,269,17,261,49,49,33,305,33,257,32,33,48]

theorem envBound56327 : H12AffineFastState.Bounded env56327 := by
  intro p hp
  have h : env56327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56324_56327 : H12AffineEnvironment.transform 8 49 env56324 = env56327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56324 == env56327) = true)

def env56328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12798327,2428275,10507600,8830976,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound56328 : H12AffineFastState.Bounded env56328 := by
  intro p hp
  have h : env56328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56234_56328 : H12AffineEnvironment.transform 6 9 env56234 = env56328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56234 == env56328) = true)

def env56329 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650855,2428275,10507600,8683536,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound56329 : H12AffineFastState.Bounded env56329 := by
  intro p hp
  have h : env56329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56328_56329 : H12AffineEnvironment.transform 16 16400 env56328 = env56329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env56328 == env56329) = true)

theorem identity56329 : scanCanonicalize (H12AffineFastState.compose env56329 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 41292) := by decide +kernel

theorem selectedBound56329 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env56330 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,41292,297334,8193,65,4302891,2428275,2159644,270684,371755,6679614,257,2485278,2428210,297844]

theorem envBound56330 : H12AffineFastState.Bounded env56330 := by
  intro p hp
  have h : env56330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56329_56330 : H12AffineEnvironment.transform 22 41292 env56329 = env56330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41292 env56329 == env56330) = true)

theorem identity56330 : scanCanonicalize (H12AffineFastState.compose env56330 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound56330 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env56331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,2097152,4194304,41292,297334,8193,65,4229153,2370937,2159644,270684,298017,6605876,257,2411540,2370872,297844]

theorem envBound56331 : H12AffineFastState.Bounded env56331 := by
  intro p hp
  have h : env56331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56330_56331 : H12AffineEnvironment.transform 15 8202 env56330 = env56331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env56330 == env56331) = true)

theorem identity56331 : scanCanonicalize (H12AffineFastState.compose env56331 (packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound56331 : packedSelected [0,1,3,5,8,9,10,11,18,19,21,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env56332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,2097152,4194304,41292,3,8193,65,4229153,2139148,2159644,43049,1364,6309185,257,2114913,2139213,513]

theorem envBound56332 : H12AffineFastState.Bounded env56332 := by
  intro p hp
  have h : env56332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56331_56332 : H12AffineEnvironment.transform 17 35189 env56331 = env56332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env56331 == env56332) = true)

theorem identity56332 : scanCanonicalize (H12AffineFastState.compose env56332 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound56332 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env56333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,2097152,20529,41292,3,8193,65,55312,2139148,2159644,43049,1364,2102640,257,2114913,2139213,513]

theorem envBound56333 : H12AffineFastState.Bounded env56333 := by
  intro p hp
  have h : env56333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56332_56333 : H12AffineEnvironment.transform 21 20529 env56332 = env56333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env56332 == env56333) = true)

theorem identity56333 : scanCanonicalize (H12AffineFastState.compose env56333 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound56333 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1025,32769,17728,20529,41292,3,8193,65,55312,57676,45404,43049,1364,20528,257,33,57613,513]

theorem envBound56334 : H12AffineFastState.Bounded env56334 := by
  intro p hp
  have h : env56334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56333_56334 : H12AffineEnvironment.transform 20 17728 env56333 = env56334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env56333 == env56334) = true)

theorem identity56334 : scanCanonicalize (H12AffineFastState.compose env56334 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound56334 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8202,16400,30776,1025,29004,17728,20529,20481,3,8193,65,10589,4097,16401,22884,1364,20528,257,33,4160,513]

theorem envBound56335 : H12AffineFastState.Bounded env56335 := by
  intro p hp
  have h : env56335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56334_56335 : H12AffineEnvironment.transform 14 29005 env56334 = env56335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env56334 == env56335) = true)

theorem identity56335 : scanCanonicalize (H12AffineFastState.compose env56335 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound56335 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8202,4096,10280,1025,8540,5456,33,17,3,8193,65,10589,4097,4097,2420,1364,32,257,33,4160,513]

theorem envBound56336 : H12AffineFastState.Bounded env56336 := by
  intro p hp
  have h : env56336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56335_56336 : H12AffineEnvironment.transform 13 4112 env56335 = env56336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env56335 == env56336) = true)

theorem identity56336 : scanCanonicalize (H12AffineFastState.compose env56336 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound56336 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env56337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1305,4112,1092,1299,4096,3377,1025,1093,5456,33,17,3,1304,65,3140,4097,4097,2420,1364,32,257,33,4160,513]

theorem envBound56337 : H12AffineFastState.Bounded env56337 := by
  intro p hp
  have h : env56337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56336_56337 : H12AffineEnvironment.transform 12 1305 env56336 = env56337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env56336 == env56337) = true)

theorem identity56337 : scanCanonicalize (H12AffineFastState.compose env56337 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound56337 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env56338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,1305,2048,1092,1299,2064,3377,1025,1093,3392,33,17,3,1304,65,3140,2065,2065,2420,1364,32,257,33,2128,513]

theorem envBound56338 : H12AffineFastState.Bounded env56338 := by
  intro p hp
  have h : env56338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56337_56338 : H12AffineEnvironment.transform 11 2064 env56337 = env56338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env56337 == env56338) = true)

theorem identity56338 : scanCanonicalize (H12AffineFastState.compose env56338 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound56338 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env56339 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,2064,349,2048,0,343,2064,2421,69,1,2308,33,17,3,348,65,2048,2065,2065,2420,272,32,257,33,2128,513]

theorem envBound56339 : H12AffineFastState.Bounded env56339 := by
  intro p hp
  have h : env56339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56338_56339 : H12AffineEnvironment.transform 9 68 env56338 = env56339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env56338 == env56339) = true)

theorem identity56339 : scanCanonicalize (H12AffineFastState.compose env56339 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound56339 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56340 : List Nat := [2,4,8,16,32,64,9,256,512,68,544,560,349,544,0,343,560,853,69,1,804,33,17,3,348,65,544,561,561,852,272,32,257,33,624,513]

theorem envBound56340 : H12AffineFastState.Bounded env56340 := by
  intro p hp
  have h : env56340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56339_56340 : H12AffineEnvironment.transform 10 544 env56339 = env56340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env56339 == env56340) = true)

theorem identity56340 : scanCanonicalize (H12AffineFastState.compose env56340 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56340 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56341 : List Nat := [2,4,8,16,16,64,9,256,512,68,528,512,349,528,0,343,512,853,69,1,788,17,17,3,348,65,528,513,513,852,272,16,257,17,576,513]

theorem envBound56341 : H12AffineFastState.Bounded env56341 := by
  intro p hp
  have h : env56341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56340_56341 : H12AffineEnvironment.transform 4 16 env56340 = env56341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56340 == env56341) = true)

theorem identity56341 : scanCanonicalize (H12AffineFastState.compose env56341 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound56341 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env56342 : List Nat := [2,4,8,16,16,64,9,256,81,68,65,81,349,65,0,343,81,260,69,1,325,17,17,3,348,65,65,80,80,261,272,16,257,17,17,80]

theorem envBound56342 : H12AffineFastState.Bounded env56342 := by
  intro p hp
  have h : env56342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56341_56342 : H12AffineEnvironment.transform 8 81 env56341 = env56342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env56341 == env56342) = true)

theorem identity56342 : scanCanonicalize (H12AffineFastState.compose env56342 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56342 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56343 : List Nat := [2,4,8,1,1,64,9,256,64,68,65,64,332,65,0,326,64,260,69,1,325,0,0,3,333,65,65,65,65,261,257,1,257,0,0,65]

theorem envBound56343 : H12AffineFastState.Bounded env56343 := by
  intro p hp
  have h : env56343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56342_56343 : H12AffineEnvironment.transform 3 1 env56342 = env56343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56342 == env56343) = true)

def env56344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,297334,8193,65,12650854,2428275,10507600,8683537,8719719,6679614,257,10833234,10857598,8661560]

theorem envBound56344 : H12AffineFastState.Bounded env56344 := by
  intro p hp
  have h : env56344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56328_56344 : H12AffineEnvironment.transform 16 16401 env56328 = env56344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env56328 == env56344) = true)

theorem identity56344 : scanCanonicalize (H12AffineFastState.compose env56344 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound56344 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env56345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,8388608,3,8193,65,12650854,2196486,10507600,8391012,8487954,6382923,257,10601511,10560779,8430413]

theorem envBound56345 : H12AffineFastState.Bounded env56345 := by
  intro p hp
  have h : env56345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56344_56345 : H12AffineEnvironment.transform 17 35189 env56344 = env56345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env56344 == env56345) = true)

theorem identity56345 : scanCanonicalize (H12AffineFastState.compose env56345 (packedSelected [0,9,14,17,21,22,27,35] rootPS)) = affineNative (2^(22+1) ^^^ 98631) := by decide +kernel

theorem selectedBound56345 : packedSelected [0,9,14,17,21,22,27,35] rootPS < 2^1333 := by decide +kernel

def env56346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,98631,3,8193,65,4229153,2196486,2216983,100387,1365,6382923,257,2114912,2139212,74250]

theorem envBound56346 : H12AffineFastState.Bounded env56346 := by
  intro p hp
  have h : env56346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56345_56346 : H12AffineEnvironment.transform 22 98631 env56345 = env56346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98631 env56345 == env56346) = true)

theorem identity56346 : scanCanonicalize (H12AffineFastState.compose env56346 (packedSelected [1,5,8,17,19,21,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56346 : packedSelected [1,5,8,17,19,21,24,26] rootPS < 2^1333 := by decide +kernel

def env56347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,4194304,41292,3,8193,65,4229153,2139149,2159644,43048,1365,6309184,257,2114912,2139212,513]

theorem envBound56347 : H12AffineFastState.Bounded env56347 := by
  intro p hp
  have h : env56347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56346_56347 : H12AffineEnvironment.transform 15 8203 env56346 = env56347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56346 == env56347) = true)

theorem identity56347 : scanCanonicalize (H12AffineFastState.compose env56347 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 61756) := by decide +kernel

theorem selectedBound56347 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env56348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,2097152,61756,41292,3,8193,65,31005,2139149,2159644,43048,1365,2143356,257,2114912,2139212,513]

theorem envBound56348 : H12AffineFastState.Bounded env56348 := by
  intro p hp
  have h : env56348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56347_56348 : H12AffineEnvironment.transform 21 61756 env56347 = env56348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61756 env56347 == env56348) = true)

theorem identity56348 : scanCanonicalize (H12AffineFastState.compose env56348 (packedSelected [0,7,11,17,18,20,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound56348 : packedSelected [0,7,11,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env56349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,35189,1025,32769,17680,61756,41292,3,8193,65,31005,57629,45324,43048,1365,61804,257,112,57692,513]

theorem envBound56349 : H12AffineFastState.Bounded env56349 := by
  intro p hp
  have h : env56349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56348_56349 : H12AffineEnvironment.transform 20 17680 env56348 = env56349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env56348 == env56349) = true)

theorem identity56349 : scanCanonicalize (H12AffineFastState.compose env56349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound56349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30777,1025,29005,17680,112,20480,3,8193,65,31005,4177,16448,22884,1365,32,257,112,4112,513]

theorem envBound56350 : H12AffineFastState.Bounded env56350 := by
  intro p hp
  have h : env56350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56349_56350 : H12AffineEnvironment.transform 14 29004 env56349 = env56350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env56349 == env56350) = true)

theorem identity56350 : scanCanonicalize (H12AffineFastState.compose env56350 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56350 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56351 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,28957,8203,16401,30777,1025,28956,17680,33,20480,3,8193,16,31005,4096,16401,22837,1284,32,257,33,4112,513]

theorem envBound56351 : H12AffineFastState.Bounded env56351 := by
  intro p hp
  have h : env56351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56350_56351 : H12AffineEnvironment.transform 5 17 env56350 = env56351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56350 == env56351) = true)

theorem identity56351 : scanCanonicalize (H12AffineFastState.compose env56351 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound56351 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56352 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,4113,8460,8203,4096,10280,1025,8461,5377,33,17,3,8193,16,10508,4096,4096,2340,1284,32,257,33,4112,513]

theorem envBound56352 : H12AffineFastState.Bounded env56352 := by
  intro p hp
  have h : env56352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56351_56352 : H12AffineEnvironment.transform 13 4113 env56351 = env56352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env56351 == env56352) = true)

theorem identity56352 : scanCanonicalize (H12AffineFastState.compose env56352 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56352 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56353 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,8192,4113,8460,8203,4096,10280,273,8461,4113,33,17,3,8193,16,10508,4096,4096,2340,20,32,257,33,4112,513]

theorem envBound56353 : H12AffineFastState.Bounded env56353 := by
  intro p hp
  have h : env56353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56352_56353 : H12AffineEnvironment.transform 9 272 env56352 = env56353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56352 == env56353) = true)

theorem identity56353 : scanCanonicalize (H12AffineFastState.compose env56353 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56353 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56354 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,8192,4113,8233,8203,4096,10280,52,8232,4113,33,17,3,8193,16,10281,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound56354 : H12AffineFastState.Bounded env56354 := by
  intro p hp
  have h : env56354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56353_56354 : H12AffineEnvironment.transform 7 37 env56353 = env56354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56353 == env56354) = true)

theorem identity56354 : scanCanonicalize (H12AffineFastState.compose env56354 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 4105) := by decide +kernel

theorem selectedBound56354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56355 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,4105,4113,4128,4098,4096,6177,52,4129,4113,33,17,3,4104,16,6176,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound56355 : H12AffineFastState.Bounded env56355 := by
  intro p hp
  have h : env56355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56354_56355 : H12AffineEnvironment.transform 12 4105 env56354 = env56355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4105 env56354 == env56355) = true)

theorem identity56355 : scanCanonicalize (H12AffineFastState.compose env56355 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound56355 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56356 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,4096,4105,4113,4128,4098,4096,4113,52,4129,4113,33,17,3,4104,16,4112,4096,4096,49,20,32,36,33,4112,513]

theorem envBound56356 : H12AffineFastState.Bounded env56356 := by
  intro p hp
  have h : env56356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56355_56356 : H12AffineEnvironment.transform 10 48 env56355 = env56356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env56355 == env56356) = true)

theorem identity56356 : scanCanonicalize (H12AffineFastState.compose env56356 (packedSelected [1,9] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound56356 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env56357 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,40,48,1,35,33,48,52,0,48,33,17,3,41,16,49,33,33,49,20,32,36,33,49,513]

theorem envBound56357 : H12AffineFastState.Bounded env56357 := by
  intro p hp
  have h : env56357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56356_56357 : H12AffineEnvironment.transform 11 33 env56356 = env56357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env56356 == env56357) = true)

def leafEnv56357 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,40,48,1,35,33,48,52,0,48,33,17,3,21,41,1,16,49,33,33,49,20,32,36,33,5,34,49,513,1,49,0]

def active56357 : List Nat := [0,1,2,3,4,8]

def tree56357 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood56357 : H12WitnessSearch.Good tree56357 := H12GlobalWitnessIndex.good

theorem leafIdentity56357 : H12AffineFastState.composeSystem env56357 rootObs = leafEnv56357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env56357 rootObs == leafEnv56357) = true)

theorem terminalChecked56357 : H12PackedTerminal.terminalCheckFast leafEnv56357 active56357 tree56357 = true := by decide +kernel

def env56358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound56358 : H12AffineFastState.Bounded env56358 := by
  intro p hp
  have h : env56358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56073_56358 : H12AffineEnvironment.transform 26 30393345 env56073 = env56358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env56073 == env56358) = true)

def env56359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound56359 : H12AffineFastState.Bounded env56359 := by
  intro p hp
  have h : env56359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56358_56359 : H12AffineEnvironment.transform 18 1024 env56358 = env56359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env56358 == env56359) = true)

theorem identity56359 : scanCanonicalize (H12AffineFastState.compose env56359 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882103) := by decide +kernel

theorem selectedBound56359 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882103,8328,65,6409270,8882362,10507600,8830976,2590758,13068791,256,510106,469311,2535409]

theorem envBound56360 : H12AffineFastState.Bounded env56360 := by
  intro p hp
  have h : env56360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56359_56360 : H12AffineEnvironment.transform 23 10882103 env56359 = env56360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882103 env56359 == env56360) = true)

def env56361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412020,2114883,8328,65,6409270,115150,2497572,35188,2590758,4268163,256,510106,469311,2535409]

theorem envBound56361 : H12AffineFastState.Bounded env56361 := by
  intro p hp
  have h : env56361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56360_56361 : H12AffineEnvironment.transform 22 412020 env56360 = env56361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412020 env56360 == env56361) = true)

def env56362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412020,2114883,8328,65,215366,115150,2497572,35188,2590758,2336243,256,510106,469311,2535409]

theorem envBound56362 : H12AffineFastState.Bounded env56362 := by
  intro p hp
  have h : env56362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56361_56362 : H12AffineEnvironment.transform 21 2262384 env56361 = env56362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env56361 == env56362) = true)

def env56363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,21763,8328,65,215366,115150,396388,35188,497766,243123,256,510106,469311,442289]

theorem envBound56363 : H12AffineFastState.Bounded env56363 := by
  intro p hp
  have h : env56363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56362_56363 : H12AffineEnvironment.transform 20 4160 env56362 = env56363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56362 == env56363) = true)

theorem identity56363 : scanCanonicalize (H12AffineFastState.compose env56363 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound56363 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,169264,62660,21763,8328,65,215366,115150,45524,35188,75222,243123,256,95530,103567,513]

theorem envBound56364 : H12AffineFastState.Bounded env56364 := by
  intro p hp
  have h : env56364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56363_56364 : H12AffineEnvironment.transform 17 179632 env56363 = env56364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env56363 == env56364) = true)

def env56365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169264,62540,21763,8192,65,215366,115014,45404,35188,75102,243003,256,95530,103431,513]

theorem envBound56365 : H12AffineFastState.Bounded env56365 := by
  intro p hp
  have h : env56365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56364_56365 : H12AffineEnvironment.transform 6 8 env56364 = env56365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56364 == env56365) = true)

theorem identity56365 : scanCanonicalize (H12AffineFastState.compose env56365 (packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound56365 : packedSelected [4,7,9,11,12,15,17,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env56366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,33,62540,21763,8192,65,121943,115014,45404,35188,75102,73770,256,95530,103431,513]

theorem envBound56366 : H12AffineFastState.Bounded env56366 := by
  intro p hp
  have h : env56366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56365_56366 : H12AffineEnvironment.transform 16 38161 env56365 = env56366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env56365 == env56366) = true)

theorem identity56366 : scanCanonicalize (H12AffineFastState.compose env56366 (packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound56366 : packedSelected [1,2,3,4,5,6,8,9,11,12,14,18,20] rootPS < 2^1333 := by decide +kernel

def env56367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,13340,10281,1024,8460,4160,33,21825,21763,8192,65,97626,90187,4177,10361,75102,73770,256,95530,79114,513]

theorem envBound56367 : H12AffineFastState.Bounded env56367 := by
  intro p hp
  have h : env56367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56366_56367 : H12AffineEnvironment.transform 14 8461 env56366 = env56367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env56366 == env56367) = true)

theorem identity56367 : scanCanonicalize (H12AffineFastState.compose env56367 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound56367 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env56368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30043,13340,10281,1024,8460,4160,33,21825,21763,8192,65,2049,5392,4177,10361,20485,21873,256,113,16465,513]

theorem envBound56368 : H12AffineFastState.Bounded env56368 := by
  intro p hp
  have h : env56368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56367_56368 : H12AffineEnvironment.transform 15 30043 env56367 = env56368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env56367 == env56368) = true)

theorem identity56368 : scanCanonicalize (H12AffineFastState.compose env56368 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56368 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env56369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,1,21591,5392,2341,1024,0,4160,33,21825,21763,268,65,2049,5392,4177,2421,20485,21873,256,113,16465,513]

theorem envBound56369 : H12AffineFastState.Bounded env56369 := by
  intro p hp
  have h : env56369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56368_56369 : H12AffineEnvironment.transform 12 268 env56368 = env56369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56368 == env56369) = true)

theorem identity56369 : scanCanonicalize (H12AffineFastState.compose env56369 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound56369 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env56370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,1,343,5392,2341,1024,0,4160,33,65,3,268,65,2049,5392,4177,2421,1285,113,256,113,5457,513]

theorem envBound56370 : H12AffineFastState.Bounded env56370 := by
  intro p hp
  have h : env56370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56369_56370 : H12AffineEnvironment.transform 13 5376 env56369 = env56370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env56369 == env56370) = true)

theorem identity56370 : scanCanonicalize (H12AffineFastState.compose env56370 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56370 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56371 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,1,263,5392,2341,1024,0,4112,33,17,3,268,17,2049,5392,4097,2341,1285,33,256,33,5377,513]

theorem envBound56371 : H12AffineFastState.Bounded env56371 := by
  intro p hp
  have h : env56371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56370_56371 : H12AffineEnvironment.transform 5 16 env56370 = env56371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56370 == env56371) = true)

theorem identity56371 : scanCanonicalize (H12AffineFastState.compose env56371 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound56371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56372 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,0,268,1280,1,263,1296,2341,1024,0,16,33,17,3,268,17,2049,1296,1,2341,1285,33,256,33,1281,513]

theorem envBound56372 : H12AffineFastState.Bounded env56372 := by
  intro p hp
  have h : env56372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56371_56372 : H12AffineEnvironment.transform 11 0 env56371 = env56372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56371 == env56372) = true)

theorem identity56372 : scanCanonicalize (H12AffineFastState.compose env56372 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound56372 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56373 : List Nat := [2,4,8,16,32,16,8,256,512,1024,318,0,268,1280,1,263,1296,27,1024,0,16,33,17,3,268,17,319,1296,1,27,1285,33,256,33,1281,513]

theorem envBound56373 : H12AffineFastState.Bounded env56373 := by
  intro p hp
  have h : env56373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56372_56373 : H12AffineEnvironment.transform 10 318 env56372 = env56373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env56372 == env56373) = true)

theorem identity56373 : scanCanonicalize (H12AffineFastState.compose env56373 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56373 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56374 : List Nat := [2,4,8,16,32,16,8,256,512,20,318,0,268,276,1,263,260,27,20,0,16,33,17,3,268,17,319,260,1,27,273,33,256,33,277,513]

theorem envBound56374 : H12AffineFastState.Bounded env56374 := by
  intro p hp
  have h : env56374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56373_56374 : H12AffineEnvironment.transform 9 20 env56373 = env56374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56373 == env56374) = true)

theorem identity56374 : scanCanonicalize (H12AffineFastState.compose env56374 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound56374 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56375 : List Nat := [2,4,8,16,32,16,8,52,512,20,10,0,56,32,1,51,48,27,20,0,16,33,17,3,56,17,11,48,1,27,37,33,52,33,33,513]

theorem envBound56375 : H12AffineFastState.Bounded env56375 := by
  intro p hp
  have h : env56375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56374_56375 : H12AffineEnvironment.transform 7 52 env56374 = env56375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env56374 == env56375) = true)

theorem identity56375 : scanCanonicalize (H12AffineFastState.compose env56375 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound56375 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56376 : List Nat := [2,4,8,16,27,16,8,15,512,20,10,0,3,27,1,8,11,27,20,0,16,26,17,3,3,17,11,11,1,27,30,26,15,26,26,513]

theorem envBound56376 : H12AffineFastState.Bounded env56376 := by
  intro p hp
  have h : env56376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56375_56376 : H12AffineEnvironment.transform 4 27 env56375 = env56376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env56375 == env56376) = true)

theorem identity56376 : scanCanonicalize (H12AffineFastState.compose env56376 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56376 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56377 : List Nat := [2,4,2,16,17,16,2,5,512,20,0,0,3,17,1,2,1,17,20,0,16,16,17,3,3,17,1,1,1,17,20,16,5,16,16,513]

theorem envBound56377 : H12AffineFastState.Bounded env56377 := by
  intro p hp
  have h : env56377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56376_56377 : H12AffineEnvironment.transform 2 2 env56376 = env56377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56376 == env56377) = true)

theorem identity56377 : scanCanonicalize (H12AffineFastState.compose env56377 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56378 : List Nat := [1,4,1,16,17,16,1,5,512,20,0,0,0,17,1,1,1,17,20,0,16,16,17,0,0,17,1,1,1,17,20,16,5,16,16,513]

theorem envBound56378 : H12AffineFastState.Bounded env56378 := by
  intro p hp
  have h : env56378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56377_56378 : H12AffineEnvironment.transform 0 1 env56377 = env56378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56377 == env56378) = true)

theorem identity56378 : scanCanonicalize (H12AffineFastState.compose env56378 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56378 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env56379 : List Nat := [1,4,1,1,0,1,1,5,512,5,0,0,0,0,1,1,1,0,5,0,1,1,0,0,0,0,1,1,1,0,5,1,5,1,1,513]

theorem envBound56379 : H12AffineFastState.Bounded env56379 := by
  intro p hp
  have h : env56379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56378_56379 : H12AffineEnvironment.transform 3 1 env56378 = env56379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56378 == env56379) = true)

theorem identity56379 : scanCanonicalize (H12AffineFastState.compose env56379 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound56379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56380 : List Nat := [1,4,1,1,0,1,1,5,5,5,0,0,0,0,1,1,1,0,5,0,1,1,0,0,0,0,1,1,1,0,5,1,5,1,1,4]

theorem envBound56380 : H12AffineFastState.Bounded env56380 := by
  intro p hp
  have h : env56380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56379_56380 : H12AffineEnvironment.transform 8 5 env56379 = env56380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env56379 == env56380) = true)

def env56381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,169264,62541,21763,8193,65,215366,115015,45405,35188,75103,243002,256,95530,103430,513]

theorem envBound56381 : H12AffineFastState.Bounded env56381 := by
  intro p hp
  have h : env56381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56364_56381 : H12AffineEnvironment.transform 6 9 env56364 = env56381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56364 == env56381) = true)

theorem identity56381 : scanCanonicalize (H12AffineFastState.compose env56381 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound56381 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,122147,1024,32769,4160,128298,62541,21763,8193,65,10588,115015,45405,35188,75103,54560,256,95530,103430,513]

theorem envBound56382 : H12AffineFastState.Bounded env56382 := by
  intro p hp
  have h : env56382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56381_56382 : H12AffineEnvironment.transform 16 90138 env56381 = env56382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env56381 == env56382) = true)

theorem identity56382 : scanCanonicalize (H12AffineFastState.compose env56382 (packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS)) = affineNative (2^(15+1) ^^^ 34147) := by decide +kernel

theorem selectedBound56382 : packedSelected [0,3,5,10,12,14,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env56383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,34147,58745,22592,1024,32769,4160,28745,62541,21763,8193,65,10588,17444,45405,35188,41020,54560,256,61513,4453,513]

theorem envBound56383 : H12AffineFastState.Bounded env56383 := by
  intro p hp
  have h : env56383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56382_56383 : H12AffineEnvironment.transform 15 34147 env56382 = env56383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34147 env56382 == env56383) = true)

theorem identity56383 : scanCanonicalize (H12AffineFastState.compose env56383 (packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound56383 : packedSelected [4,8,9,10,14,17,18,20,28,32] rootPS < 2^1333 := by decide +kernel

def env56384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21541,20806,12636,22592,1024,21540,4160,28745,8296,21763,8193,65,10588,17444,25976,23889,29721,261,256,9324,4453,513]

theorem envBound56384 : H12AffineFastState.Bounded env56384 := by
  intro p hp
  have h : env56384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56383_56384 : H12AffineEnvironment.transform 14 21541 env56383 = env56384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env56383 == env56384) = true)

theorem identity56384 : scanCanonicalize (H12AffineFastState.compose env56384 (packedSelected [0,1,2,4,5,6,7,8,9,12,14,15,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound56384 : packedSelected [0,1,2,4,5,6,7,8,9,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env56385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,292,1095,12636,3393,1024,293,4160,9544,8296,2,8193,65,10588,4389,12409,2128,8472,261,256,9324,4453,513]

theorem envBound56385 : H12AffineFastState.Bounded env56385 := by
  intro p hp
  have h : env56385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56384_56385 : H12AffineEnvironment.transform 13 5377 env56384 = env56385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env56384 == env56385) = true)

theorem identity56385 : scanCanonicalize (H12AffineFastState.compose env56385 (packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound56385 : packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env56386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5377,292,1095,3109,3393,1024,293,4160,6193,7441,2,7544,65,5157,4389,3328,2128,7265,261,256,6421,4453,513]

theorem envBound56386 : H12AffineFastState.Bounded env56386 := by
  intro p hp
  have h : env56386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56385_56386 : H12AffineEnvironment.transform 12 7545 env56385 = env56386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env56385 == env56386) = true)

theorem identity56386 : scanCanonicalize (H12AffineFastState.compose env56386 (packedSelected [3,5,10,11,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56386 : packedSelected [3,5,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env56387 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7464,5377,292,1046,3109,3344,1024,293,4113,6193,7441,2,7465,16,5157,4389,3328,2049,7216,261,256,6421,4404,513]

theorem envBound56387 : H12AffineFastState.Bounded env56387 := by
  intro p hp
  have h : env56387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56386_56387 : H12AffineEnvironment.transform 5 17 env56386 = env56387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56386 == env56387) = true)

theorem identity56387 : scanCanonicalize (H12AffineFastState.compose env56387 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56387 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56388 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,4096,5417,5377,292,1046,1060,1297,1024,293,4113,4144,5392,2,5416,16,5157,4389,1281,0,5169,261,256,4372,4404,513]

theorem envBound56388 : H12AffineFastState.Bounded env56388 := by
  intro p hp
  have h : env56388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56387_56388 : H12AffineEnvironment.transform 10 1 env56387 = env56388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56387 == env56388) = true)

theorem identity56388 : scanCanonicalize (H12AffineFastState.compose env56388 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound56388 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env56389 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,4096,4380,4404,292,35,17,292,53,293,4113,4144,4389,2,4381,16,4112,4389,308,0,4100,261,256,4372,4404,513]

theorem envBound56389 : H12AffineFastState.Bounded env56389 := by
  intro p hp
  have h : env56389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56388_56389 : H12AffineEnvironment.transform 9 53 env56388 = env56389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env56388 == env56389) = true)

theorem identity56389 : scanCanonicalize (H12AffineFastState.compose env56389 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound56389 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56390 : List Nat := [2,4,8,16,32,17,9,256,512,53,1,308,40,0,292,35,17,292,53,293,293,260,17,2,41,16,292,17,308,0,304,261,256,32,0,513]

theorem envBound56390 : H12AffineFastState.Bounded env56390 := by
  intro p hp
  have h : env56390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56389_56390 : H12AffineEnvironment.transform 11 308 env56389 = env56390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env56389 == env56390) = true)

theorem identity56390 : scanCanonicalize (H12AffineFastState.compose env56390 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56390 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56391 : List Nat := [2,4,8,16,32,17,9,37,512,53,1,17,40,0,1,35,17,1,53,0,0,33,17,2,41,16,1,17,17,0,21,32,37,32,0,513]

theorem envBound56391 : H12AffineFastState.Bounded env56391 := by
  intro p hp
  have h : env56391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56390_56391 : H12AffineEnvironment.transform 7 37 env56390 = env56391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56390 == env56391) = true)

theorem identity56391 : scanCanonicalize (H12AffineFastState.compose env56391 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound56391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56392 : List Nat := [2,4,8,16,32,17,9,37,17,53,1,17,40,0,1,35,17,1,53,0,0,33,17,2,41,16,1,17,17,0,21,32,37,32,0,16]

theorem envBound56392 : H12AffineFastState.Bounded env56392 := by
  intro p hp
  have h : env56392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56391_56392 : H12AffineEnvironment.transform 8 17 env56391 = env56392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env56391 == env56392) = true)

theorem identity56392 : scanCanonicalize (H12AffineFastState.compose env56392 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56393 : List Nat := [2,4,8,11,32,10,9,37,10,46,1,10,40,0,1,35,10,1,46,0,0,33,10,2,41,11,1,10,10,0,14,32,37,32,0,11]

theorem envBound56393 : H12AffineFastState.Bounded env56393 := by
  intro p hp
  have h : env56393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56392_56393 : H12AffineEnvironment.transform 3 11 env56392 = env56393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56392 == env56393) = true)

def env56394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,21762,8328,65,215366,115150,396389,35188,497767,243122,256,510106,469311,442288]

theorem envBound56394 : H12AffineFastState.Bounded env56394 := by
  intro p hp
  have h : env56394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56362_56394 : H12AffineEnvironment.transform 20 4161 env56362 = env56394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env56362 == env56394) = true)

def env56395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169265,155996,21762,8328,65,215366,115150,140365,35188,241743,243122,256,254130,196887,169880]

theorem envBound56395 : H12AffineFastState.Bounded env56395 := by
  intro p hp
  have h : env56395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56394_56395 : H12AffineEnvironment.transform 17 10280 env56394 = env56395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env56394 == env56395) = true)

def env56396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21793,41292,21762,8328,65,100694,115150,58461,35188,94303,95650,256,73890,114951,22408]

theorem envBound56396 : H12AffineFastState.Bounded env56396 := by
  intro p hp
  have h : env56396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56395_56396 : H12AffineEnvironment.transform 16 49168 env56395 = env56396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env56395 == env56396) = true)

theorem identity56396 : scanCanonicalize (H12AffineFastState.compose env56396 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound56396 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10280,1024,8660,4161,21793,153,21762,8328,65,75907,90139,17800,10401,94303,95650,256,73890,90322,22408]

theorem envBound56397 : H12AffineFastState.Bounded env56397 := by
  intro p hp
  have h : env56397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56396_56397 : H12AffineEnvironment.transform 14 8661 env56396 = env56397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env56396 == env56397) = true)

theorem identity56397 : scanCanonicalize (H12AffineFastState.compose env56397 (packedSelected [2,4,6,11,19,20,22,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 22010) := by decide +kernel

theorem selectedBound56397 : packedSelected [2,4,6,11,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env56398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,22010,25029,10280,1024,8660,4161,21793,153,21762,8328,65,32121,13793,17800,10401,9637,8280,256,30040,13608,22408]

theorem envBound56398 : H12AffineFastState.Bounded env56398 := by
  intro p hp
  have h : env56398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56397_56398 : H12AffineEnvironment.transform 15 22010 env56397 = env56398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 22010 env56397 == env56398) = true)

theorem identity56398 : scanCanonicalize (H12AffineFastState.compose env56398 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound56398 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,23,27] rootPS < 2^1333 := by decide +kernel

def env56399 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8433,21726,24801,10280,1024,8432,4161,21509,153,21542,8328,65,31837,13509,17580,10401,9345,8280,36,29820,13324,22188]

theorem envBound56399 : H12AffineFastState.Bounded env56399 := by
  intro p hp
  have h : env56399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56398_56399 : H12AffineEnvironment.transform 7 36 env56398 = env56399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env56398 == env56399) = true)

theorem identity56399 : scanCanonicalize (H12AffineFastState.compose env56399 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound56399 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env56400 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5157,8433,251,13508,10280,1024,8432,4161,32,153,3,8328,65,10360,13509,4233,10401,9345,8280,36,8281,13324,649]

theorem envBound56400 : H12AffineFastState.Bounded env56400 := by
  intro p hp
  have h : env56400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56399_56400 : H12AffineEnvironment.transform 13 5157 env56399 = env56400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env56399 == env56400) = true)

theorem identity56400 : scanCanonicalize (H12AffineFastState.compose env56400 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound56400 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56401 : List Nat := [2,4,8,16,32,64,128,36,512,52,2048,4096,8192,4113,8433,251,12528,10280,52,8432,4161,32,153,3,8328,65,10360,12529,4233,10401,8373,8280,36,8281,12344,649]

theorem envBound56401 : H12AffineFastState.Bounded env56401 := by
  intro p hp
  have h : env56401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56400_56401 : H12AffineEnvironment.transform 9 52 env56400 = env56401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env56400 == env56401) = true)

theorem identity56401 : scanCanonicalize (H12AffineFastState.compose env56401 (packedSelected [4,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound56401 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env56402 : List Nat := [2,4,8,16,32,64,128,36,512,52,136,4096,8192,4113,8433,251,12528,8352,52,8432,4161,32,153,3,8328,65,8432,12529,4233,8233,8373,8280,36,8281,12344,649]

theorem envBound56402 : H12AffineFastState.Bounded env56402 := by
  intro p hp
  have h : env56402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56401_56402 : H12AffineEnvironment.transform 10 136 env56401 = env56402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env56401 == env56402) = true)

theorem identity56402 : scanCanonicalize (H12AffineFastState.compose env56402 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound56402 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env56403 : List Nat := [2,4,8,16,32,64,128,36,512,52,136,65,8192,80,8433,251,8369,8352,52,8432,0,32,153,3,8328,65,8432,8368,200,8233,8373,8280,36,8281,8313,649]

theorem envBound56403 : H12AffineFastState.Bounded env56403 := by
  intro p hp
  have h : env56403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56402_56403 : H12AffineEnvironment.transform 11 65 env56402 = env56403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env56402 == env56403) = true)

theorem identity56403 : scanCanonicalize (H12AffineFastState.compose env56403 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56403 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env56404 : List Nat := [2,4,8,16,32,64,8,36,512,52,0,65,8192,80,8313,115,8249,8232,52,8312,0,32,17,3,8192,65,8312,8248,64,8233,8253,8280,36,8281,8313,513]

theorem envBound56404 : H12AffineFastState.Bounded env56404 := by
  intro p hp
  have h : env56404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56403_56404 : H12AffineEnvironment.transform 6 8 env56403 = env56404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56403 == env56404) = true)

theorem identity56404 : scanCanonicalize (H12AffineFastState.compose env56404 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound56404 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env56405 : List Nat := [2,4,8,16,32,64,8,36,512,52,0,65,120,80,1,115,65,80,52,0,0,32,17,3,120,65,0,64,64,81,69,32,36,33,1,513]

theorem envBound56405 : H12AffineFastState.Bounded env56405 := by
  intro p hp
  have h : env56405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56404_56405 : H12AffineEnvironment.transform 12 120 env56404 = env56405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env56404 == env56405) = true)

def env56406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21792,41293,21762,8328,65,100695,115150,58460,35188,94302,95651,256,73891,114950,22409]

theorem envBound56406 : H12AffineFastState.Bounded env56406 := by
  intro p hp
  have h : env56406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56395_56406 : H12AffineEnvironment.transform 16 49169 env56395 = env56406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env56395 == env56406) = true)

theorem identity56406 : scanCanonicalize (H12AffineFastState.compose env56406 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56406 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1024,8541,4161,21792,17,21762,8328,65,75787,90258,17664,10280,94302,95651,256,73891,90202,22409]

theorem envBound56407 : H12AffineFastState.Bounded env56407 := by
  intro p hp
  have h : env56407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56406_56407 : H12AffineEnvironment.transform 14 8540 env56406 = env56407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56406 == env56407) = true)

theorem identity56407 : scanCanonicalize (H12AffineFastState.compose env56407 (packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 1457) := by decide +kernel

theorem selectedBound56407 : packedSelected [2,5,6,7,9,11,16,18,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1457,16384,1261,65536,17660,3481,1024,1260,4161,21792,17,21762,1337,65,69050,83235,17664,3481,87535,86034,256,66834,83435,22409]

theorem envBound56408 : H12AffineFastState.Bounded env56408 := by
  intro p hp
  have h : env56408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56407_56408 : H12AffineEnvironment.transform 12 1457 env56407 = env56408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env56407 == env56408) = true)

theorem identity56408 : scanCanonicalize (H12AffineFastState.compose env56408 (packedSelected [1,3,5,8,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56408 : packedSelected [1,3,5,8,14,16] rootPS < 2^1333 := by decide +kernel

def env56409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,16384,1124,65536,17525,3344,1024,1125,4161,21792,17,21762,1337,65,68915,83235,17664,3344,87398,86034,256,66834,83298,22272]

theorem envBound56409 : H12AffineFastState.Bounded env56409 := by
  intro p hp
  have h : env56409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56408_56409 : H12AffineEnvironment.transform 6 9 env56408 = env56409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56408 == env56409) = true)

theorem identity56409 : scanCanonicalize (H12AffineFastState.compose env56409 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound56409 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,16384,1124,1331,17525,3344,1024,1125,4161,21792,17,21762,1337,65,2048,16400,17664,3344,20565,21793,256,33,16465,22272]

theorem envBound56410 : H12AffineFastState.Bounded env56410 := by
  intro p hp
  have h : env56410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56409_56410 : H12AffineEnvironment.transform 15 1331 env56409 = env56410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env56409 == env56410) = true)

theorem identity56410 : scanCanonicalize (H12AffineFastState.compose env56410 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound56410 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env56411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4404,1124,1331,5441,3344,1024,1125,4161,1044,17,1078,1337,65,2048,4388,5172,3344,353,1045,256,33,4453,1588]

theorem envBound56411 : H12AffineFastState.Bounded env56411 := by
  intro p hp
  have h : env56411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56410_56411 : H12AffineEnvironment.transform 13 4404 env56410 = env56411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env56410 == env56411) = true)

theorem identity56411 : scanCanonicalize (H12AffineFastState.compose env56411 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56411 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env56412 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,1053,4113,1124,1046,5220,3125,1024,1125,4161,1044,17,1078,1052,65,2048,4097,5172,3125,68,1045,37,33,4160,1588]

theorem envBound56412 : H12AffineFastState.Bounded env56412 := by
  intro p hp
  have h : env56412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56411_56412 : H12AffineEnvironment.transform 7 37 env56411 = env56412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56411 == env56412) = true)

theorem identity56412 : scanCanonicalize (H12AffineFastState.compose env56412 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound56412 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56413 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,4096,121,4113,0,114,4096,2129,100,1,4161,112,17,82,120,65,2048,4097,4176,2129,68,113,37,33,4160,592]

theorem envBound56413 : H12AffineFastState.Bounded env56413 := by
  intro p hp
  have h : env56413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56412_56413 : H12AffineEnvironment.transform 9 100 env56412 = env56413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env56412 == env56413) = true)

theorem identity56413 : scanCanonicalize (H12AffineFastState.compose env56413 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56413 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env56414 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,40,4113,0,35,4096,2048,53,1,4112,33,17,3,41,16,2048,4097,4097,2048,21,32,37,33,4113,513]

theorem envBound56414 : H12AffineFastState.Bounded env56414 := by
  intro p hp
  have h : env56414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56413_56414 : H12AffineEnvironment.transform 5 17 env56413 = env56414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56413 == env56414) = true)

theorem identity56414 : scanCanonicalize (H12AffineFastState.compose env56414 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound56414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56415 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2560,40,2577,0,35,2560,2048,53,1,2576,33,17,3,41,16,2048,2561,2561,2048,21,32,37,33,2577,513]

theorem envBound56415 : H12AffineFastState.Bounded env56415 := by
  intro p hp
  have h : env56415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56414_56415 : H12AffineEnvironment.transform 11 2560 env56414 = env56415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env56414 == env56415) = true)

theorem identity56415 : scanCanonicalize (H12AffineFastState.compose env56415 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound56415 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56416 : List Nat := [2,4,8,16,32,17,9,37,512,53,555,43,40,58,0,35,43,555,53,1,59,33,17,3,41,16,555,42,42,555,21,32,37,33,58,513]

theorem envBound56416 : H12AffineFastState.Bounded env56416 := by
  intro p hp
  have h : env56416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56415_56416 : H12AffineEnvironment.transform 10 555 env56415 = env56416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env56415 == env56416) = true)

def env56417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169265,155997,21762,8328,65,215366,115150,140364,35188,241742,243122,256,254131,196886,169881]

theorem envBound56417 : H12AffineFastState.Bounded env56417 := by
  intro p hp
  have h : env56417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56394_56417 : H12AffineEnvironment.transform 17 10281 env56394 = env56417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env56394 == env56417) = true)

def env56418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21793,41293,21762,8328,65,100694,115150,58460,35188,94302,95650,256,73891,114950,22409]

theorem envBound56418 : H12AffineFastState.Bounded env56418 := by
  intro p hp
  have h : env56418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56417_56418 : H12AffineEnvironment.transform 16 49168 env56417 = env56418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env56417 == env56418) = true)

theorem identity56418 : scanCanonicalize (H12AffineFastState.compose env56418 (packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound56418 : packedSelected [0,3,8,9,16,19,20,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env56419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21511,49168,10281,1024,32769,4161,21793,41293,21762,8328,65,56657,38345,58460,35188,9305,8613,256,29860,38145,22409]

theorem envBound56419 : H12AffineFastState.Bounded env56419 := by
  intro p hp
  have h : env56419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56418_56419 : H12AffineEnvironment.transform 15 21511 env56418 = env56419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env56418 == env56419) = true)

theorem identity56419 : scanCanonicalize (H12AffineFastState.compose env56419 (packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound56419 : packedSelected [0,2,5,6,7,16,18,24,26,32] rootPS < 2^1333 := by decide +kernel

def env56420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,21511,16536,10281,1024,137,4161,21793,8645,21762,8328,65,24025,5441,25812,2556,9305,8613,256,29860,5513,22409]

theorem envBound56420 : H12AffineFastState.Bounded env56420 := by
  intro p hp
  have h : env56420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56419_56420 : H12AffineEnvironment.transform 14 136 env56419 = env56420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env56419 == env56420) = true)

theorem identity56420 : scanCanonicalize (H12AffineFastState.compose env56420 (packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound56420 : packedSelected [0,2,3,6,7,10,11,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env56421 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,81,21511,16449,10281,1024,80,4161,21793,8476,21762,8273,65,23808,5441,25613,2341,9305,8572,256,29821,5456,22352]

theorem envBound56421 : H12AffineFastState.Bounded env56421 := by
  intro p hp
  have h : env56421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56420_56421 : H12AffineEnvironment.transform 6 89 env56420 = env56421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env56420 == env56421) = true)

theorem identity56421 : scanCanonicalize (H12AffineFastState.compose env56421 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound56421 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env56422 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,16384,81,21511,16449,2341,1024,80,4161,21793,16,21762,349,65,23808,5441,17665,2341,1365,112,256,21873,5456,22352]

theorem envBound56422 : H12AffineFastState.Bounded env56422 := by
  intro p hp
  have h : env56422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56421_56422 : H12AffineEnvironment.transform 12 268 env56421 = env56422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env56421 == env56422) = true)

theorem identity56422 : scanCanonicalize (H12AffineFastState.compose env56422 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound56422 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env56423 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5236,81,115,5173,2341,1024,80,4161,341,16,374,349,65,2420,5441,4469,2341,1365,112,256,261,5456,804]

theorem envBound56423 : H12AffineFastState.Bounded env56423 := by
  intro p hp
  have h : env56423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56422_56423 : H12AffineEnvironment.transform 13 5236 env56422 = env56423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env56422 == env56423) = true)

theorem identity56423 : scanCanonicalize (H12AffineFastState.compose env56423 (packedSelected [0,7,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56423 : packedSelected [0,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env56424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5157,0,34,5173,2341,1024,1,4112,260,16,295,268,16,2341,5392,4388,2341,1284,33,256,261,5377,804]

theorem envBound56424 : H12AffineFastState.Bounded env56424 := by
  intro p hp
  have h : env56424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56423_56424 : H12AffineEnvironment.transform 5 17 env56423 = env56424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56423 == env56424) = true)

theorem identity56424 : scanCanonicalize (H12AffineFastState.compose env56424 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56424 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env56425 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,268,5125,0,2,5141,2309,1024,1,4112,260,16,263,268,16,2309,5392,4356,2309,1284,1,256,261,5377,772]

theorem envBound56425 : H12AffineFastState.Bounded env56425 := by
  intro p hp
  have h : env56425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56424_56425 : H12AffineEnvironment.transform 4 0 env56424 = env56425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56424 == env56425) = true)

theorem identity56425 : scanCanonicalize (H12AffineFastState.compose env56425 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56425 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56426 : List Nat := [2,4,8,16,0,17,8,4,512,1024,2048,4096,8,5125,0,2,5141,2049,1024,1,4112,0,16,3,8,16,2049,5140,4096,2049,1024,1,4,1,5125,512]

theorem envBound56426 : H12AffineFastState.Bounded env56426 := by
  intro p hp
  have h : env56426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56425_56426 : H12AffineEnvironment.transform 7 4 env56425 = env56426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56425 == env56426) = true)

theorem identity56426 : scanCanonicalize (H12AffineFastState.compose env56426 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56427 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,4096,8,5125,0,2,5125,2049,1024,1,4096,0,0,3,8,0,2049,5124,4096,2049,1024,1,4,1,5125,512]

theorem envBound56427 : H12AffineFastState.Bounded env56427 := by
  intro p hp
  have h : env56427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56426_56427 : H12AffineEnvironment.transform 3 0 env56426 = env56427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56426 == env56427) = true)

theorem identity56427 : scanCanonicalize (H12AffineFastState.compose env56427 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3086) := by decide +kernel

theorem selectedBound56427 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56428 : List Nat := [2,4,8,0,0,1,8,4,512,1024,2048,3086,8,2059,0,2,2059,2049,1024,1,3086,0,0,3,8,0,2049,2058,3086,2049,1024,1,4,1,2059,512]

theorem envBound56428 : H12AffineFastState.Bounded env56428 := by
  intro p hp
  have h : env56428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56427_56428 : H12AffineEnvironment.transform 11 3086 env56427 = env56428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3086 env56427 == env56428) = true)

theorem identity56428 : scanCanonicalize (H12AffineFastState.compose env56428 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56428 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56429 : List Nat := [2,4,3,0,0,1,3,4,512,1024,2048,3077,3,2048,0,2,2048,2049,1024,1,3077,0,0,3,3,0,2049,2049,3077,2049,1024,1,4,1,2048,512]

theorem envBound56429 : H12AffineFastState.Bounded env56429 := by
  intro p hp
  have h : env56429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56428_56429 : H12AffineEnvironment.transform 2 3 env56428 = env56429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56428 == env56429) = true)

theorem identity56429 : scanCanonicalize (H12AffineFastState.compose env56429 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56429 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56430 : List Nat := [2,4,3,0,0,1,3,4,512,4,2048,2049,3,2048,0,2,2048,2049,4,1,2049,0,0,3,3,0,2049,2049,2049,2049,4,1,4,1,2048,512]

theorem envBound56430 : H12AffineFastState.Bounded env56430 := by
  intro p hp
  have h : env56430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56429_56430 : H12AffineEnvironment.transform 9 4 env56429 = env56430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56429 == env56430) = true)

theorem identity56430 : scanCanonicalize (H12AffineFastState.compose env56430 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56431 : List Nat := [2,0,3,0,0,1,3,0,512,0,2048,2049,3,2048,0,2,2048,2049,0,1,2049,0,0,3,3,0,2049,2049,2049,2049,0,1,0,1,2048,512]

theorem envBound56431 : H12AffineFastState.Bounded env56431 := by
  intro p hp
  have h : env56431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56430_56431 : H12AffineEnvironment.transform 1 0 env56430 = env56431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56430 == env56431) = true)

theorem identity56431 : scanCanonicalize (H12AffineFastState.compose env56431 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound56431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56432 : List Nat := [2,0,3,0,0,1,3,0,512,0,2,3,3,2,0,2,2,3,0,1,3,0,0,3,3,0,3,3,3,3,0,1,0,1,2,512]

theorem envBound56432 : H12AffineFastState.Bounded env56432 := by
  intro p hp
  have h : env56432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56431_56432 : H12AffineEnvironment.transform 10 2 env56431 = env56432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env56431 == env56432) = true)

theorem identity56432 : scanCanonicalize (H12AffineFastState.compose env56432 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56432 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56433 : List Nat := [0,0,1,0,0,1,1,0,512,0,0,1,1,0,0,0,0,1,0,1,1,0,0,1,1,0,1,1,1,1,0,1,0,1,0,512]

theorem envBound56433 : H12AffineFastState.Bounded env56433 := by
  intro p hp
  have h : env56433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56432_56433 : H12AffineEnvironment.transform 0 0 env56432 = env56433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56432 == env56433) = true)

def env56434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21792,41292,21762,8328,65,100695,115150,58461,35188,94303,95651,256,73890,114951,22408]

theorem envBound56434 : H12AffineFastState.Bounded env56434 := by
  intro p hp
  have h : env56434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56417_56434 : H12AffineEnvironment.transform 16 49169 env56417 = env56434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env56417 == env56434) = true)

theorem identity56434 : scanCanonicalize (H12AffineFastState.compose env56434 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env56435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21792,41292,21762,8192,65,100695,115014,58461,35188,94303,95531,256,73770,114951,22272]

theorem envBound56435 : H12AffineFastState.Bounded env56435 := by
  intro p hp
  have h : env56435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56434_56435 : H12AffineEnvironment.transform 6 8 env56434 = env56435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56434 == env56435) = true)

theorem identity56435 : scanCanonicalize (H12AffineFastState.compose env56435 (packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56435 : packedSelected [0,3,4,10,12,14,15,16,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,24908,10281,1024,8540,4161,21792,17,21762,8192,65,75786,90139,17664,10281,94303,95531,256,73770,90202,22272]

theorem envBound56436 : H12AffineFastState.Bounded env56436 := by
  intro p hp
  have h : env56436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56435_56436 : H12AffineEnvironment.transform 14 8541 env56435 = env56436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56435 == env56436) = true)

theorem identity56436 : scanCanonicalize (H12AffineFastState.compose env56436 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound56436 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env56437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,65536,5393,10281,1024,8540,4161,8573,17,8543,8192,65,75786,70726,12637,10281,66562,65910,256,73770,70663,9053]

theorem envBound56437 : H12AffineFastState.Bounded env56437 := by
  intro p hp
  have h : env56437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56436_56437 : H12AffineEnvironment.transform 13 13405 env56436 = env56437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env56436 == env56437) = true)

theorem identity56437 : scanCanonicalize (H12AffineFastState.compose env56437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound56437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,5393,2421,1024,0,4161,33,17,3,348,65,67926,70726,4097,2421,66562,65910,256,65910,70663,513]

theorem envBound56438 : H12AffineFastState.Bounded env56438 := by
  intro p hp
  have h : env56438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56437_56438 : H12AffineEnvironment.transform 12 348 env56437 = env56438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env56437 == env56438) = true)

theorem identity56438 : scanCanonicalize (H12AffineFastState.compose env56438 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound56438 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env56439 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5393,2421,1024,0,4161,33,17,3,348,65,2049,5393,4097,2421,1365,33,256,33,5456,513]

theorem envBound56439 : H12AffineFastState.Bounded env56439 := by
  intro p hp
  have h : env56439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56438_56439 : H12AffineEnvironment.transform 15 343 env56438 = env56439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env56438 == env56439) = true)

theorem identity56439 : scanCanonicalize (H12AffineFastState.compose env56439 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2366) := by decide +kernel

theorem selectedBound56439 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56440 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2366,348,3135,1,343,3119,2421,1024,0,2431,33,17,3,348,65,2049,3119,2367,2421,1365,33,256,33,3182,513]

theorem envBound56440 : H12AffineFastState.Bounded env56440 := by
  intro p hp
  have h : env56440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56439_56440 : H12AffineEnvironment.transform 11 2366 env56439 = env56440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2366 env56439 == env56440) = true)

theorem identity56440 : scanCanonicalize (H12AffineFastState.compose env56440 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound56440 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env56441 : List Nat := [2,4,8,16,32,64,8,256,512,126,2048,2366,348,2113,1,343,2129,2421,126,0,2431,33,17,3,348,65,2049,2129,2367,2421,299,33,256,33,2064,513]

theorem envBound56441 : H12AffineFastState.Bounded env56441 := by
  intro p hp
  have h : env56441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56440_56441 : H12AffineEnvironment.transform 9 126 env56440 = env56441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env56440 == env56441) = true)

theorem identity56441 : scanCanonicalize (H12AffineFastState.compose env56441 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56441 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56442 : List Nat := [2,4,8,16,32,64,8,37,512,126,2048,2075,121,2113,1,114,2129,2128,126,0,2138,33,17,3,121,65,2049,2129,2074,2128,14,33,37,33,2064,513]

theorem envBound56442 : H12AffineFastState.Bounded env56442 := by
  intro p hp
  have h : env56442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56441_56442 : H12AffineEnvironment.transform 7 37 env56441 = env56442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56441 == env56442) = true)

theorem identity56442 : scanCanonicalize (H12AffineFastState.compose env56442 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound56442 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56443 : List Nat := [2,4,8,16,32,64,8,37,512,126,16,11,121,81,1,114,65,64,126,0,74,33,17,3,121,65,17,65,10,64,14,33,37,33,0,513]

theorem envBound56443 : H12AffineFastState.Bounded env56443 := by
  intro p hp
  have h : env56443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56442_56443 : H12AffineEnvironment.transform 10 16 env56442 = env56443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env56442 == env56443) = true)

theorem identity56443 : scanCanonicalize (H12AffineFastState.compose env56443 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound56443 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56444 : List Nat := [2,4,8,16,32,43,8,37,512,21,16,11,18,58,1,25,42,43,21,0,33,33,17,3,18,42,17,42,10,43,14,33,37,33,0,513]

theorem envBound56444 : H12AffineFastState.Bounded env56444 := by
  intro p hp
  have h : env56444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56443_56444 : H12AffineEnvironment.transform 5 43 env56443 = env56444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env56443 == env56444) = true)

def env56445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412020,2114883,8328,65,215367,115150,2497572,35188,2590758,2336242,256,510106,469311,2535409]

theorem envBound56445 : H12AffineFastState.Bounded env56445 := by
  intro p hp
  have h : env56445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56361_56445 : H12AffineEnvironment.transform 21 2262385 env56361 = env56445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env56361 == env56445) = true)

def env56446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,21763,8328,65,215367,115150,396388,35188,497766,243122,256,510106,469311,442289]

theorem envBound56446 : H12AffineFastState.Bounded env56446 := by
  intro p hp
  have h : env56446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56445_56446 : H12AffineEnvironment.transform 20 4160 env56445 = env56446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env56445 == env56446) = true)

theorem identity56446 : scanCanonicalize (H12AffineFastState.compose env56446 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound56446 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env56447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,156133,412020,21763,8328,65,215367,79130,396388,32160,486578,213350,256,474190,469311,412517]

theorem envBound56447 : H12AffineFastState.Bounded env56447 := by
  intro p hp
  have h : env56447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56446_56447 : H12AffineEnvironment.transform 14 29908 env56446 = env56447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env56446 == env56447) = true)

def env56448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,4160,156133,156116,21763,8328,65,215367,79130,140484,32160,214034,213350,256,201966,197023,156613]

theorem envBound56448 : H12AffineFastState.Bounded env56448 := by
  intro p hp
  have h : env56448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56447_56448 : H12AffineEnvironment.transform 17 10400 env56447 = env56448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env56447 == env56448) = true)

theorem identity56448 : scanCanonicalize (H12AffineFastState.compose env56448 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound56448 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env56449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,131072,10400,1024,137,4160,136633,136584,8543,8328,65,212251,79130,140484,2556,208974,210234,256,201966,197023,137113]

theorem envBound56449 : H12AffineFastState.Bounded env56449 := by
  intro p hp
  have h : env56449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56448_56449 : H12AffineEnvironment.transform 13 13404 env56448 = env56449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env56448 == env56449) = true)

theorem identity56449 : scanCanonicalize (H12AffineFastState.compose env56449 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 70963) := by decide +kernel

theorem selectedBound56449 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env56450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,65536,70963,10400,1024,137,4160,65674,65723,8543,8328,65,10280,79130,78327,2556,9597,8201,256,477,5292,66218]

theorem envBound56450 : H12AffineFastState.Bounded env56450 := by
  intro p hp
  have h : env56450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56449_56450 : H12AffineEnvironment.transform 16 70963 env56449 = env56450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70963 env56449 == env56450) = true)

theorem identity56450 : scanCanonicalize (H12AffineFastState.compose env56450 (packedSelected [0,3,4,5,10,12,14,15,16,17,19,22,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound56450 : packedSelected [0,3,4,5,10,12,14,15,16,17,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env56451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,136,8203,13624,10400,1024,137,4160,8321,8368,8543,8328,65,10280,5393,4604,2556,9597,8201,256,477,5292,8865]

theorem envBound56451 : H12AffineFastState.Bounded env56451 := by
  intro p hp
  have h : env56451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56450_56451 : H12AffineEnvironment.transform 15 8203 env56450 = env56451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env56450 == env56451) = true)

theorem identity56451 : scanCanonicalize (H12AffineFastState.compose env56451 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound56451 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env56452 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,13404,136,8203,13460,10400,1024,137,4160,8321,8368,8435,8328,65,10280,5309,4176,2128,9425,8201,172,113,5292,8865]

theorem envBound56452 : H12AffineFastState.Bounded env56452 := by
  intro p hp
  have h : env56452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56451_56452 : H12AffineEnvironment.transform 7 172 env56451 = env56452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56451 == env56452) = true)

theorem identity56452 : scanCanonicalize (H12AffineFastState.compose env56452 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound56452 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56453 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,241,5293,136,250,5221,2129,1024,137,4160,112,65,2,121,65,2265,5309,4176,2128,1056,248,172,113,5292,592]

theorem envBound56453 : H12AffineFastState.Bounded env56453 := by
  intro p hp
  have h : env56453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56452_56453 : H12AffineEnvironment.transform 12 241 env56452 = env56453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env56452 == env56453) = true)

theorem identity56453 : scanCanonicalize (H12AffineFastState.compose env56453 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound56453 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env56454 : List Nat := [2,4,8,16,32,48,128,172,512,1024,2048,4096,129,5293,136,138,5141,2081,1024,137,4144,0,49,2,9,49,2217,5309,4128,2080,1056,136,172,1,5292,544]

theorem envBound56454 : H12AffineFastState.Bounded env56454 := by
  intro p hp
  have h : env56454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56453_56454 : H12AffineEnvironment.transform 5 48 env56453 = env56454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56453 == env56454) = true)

theorem identity56454 : scanCanonicalize (H12AffineFastState.compose env56454 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56454 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env56455 : List Nat := [2,4,8,16,0,16,128,140,512,1024,2048,4096,129,5261,136,138,5141,2049,1024,137,4112,0,17,2,9,17,2185,5277,4096,2048,1024,136,140,1,5260,512]

theorem envBound56455 : H12AffineFastState.Bounded env56455 := by
  intro p hp
  have h : env56455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56454_56455 : H12AffineEnvironment.transform 4 0 env56454 = env56455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56454 == env56455) = true)

theorem identity56455 : scanCanonicalize (H12AffineFastState.compose env56455 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56455 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env56456 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,8,5124,1,3,5141,2049,1024,0,4112,0,17,2,9,17,2048,5140,4096,2048,1024,1,5,1,5125,512]

theorem envBound56456 : H12AffineFastState.Bounded env56456 := by
  intro p hp
  have h : env56456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56455_56456 : H12AffineEnvironment.transform 6 9 env56455 = env56456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56455 == env56456) = true)

theorem identity56456 : scanCanonicalize (H12AffineFastState.compose env56456 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound56456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56457 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,1045,8,17,1,3,0,2049,1024,0,1029,0,17,2,9,17,2048,1,1045,2048,1024,1,5,1,16,512]

theorem envBound56457 : H12AffineFastState.Bounded env56457 := by
  intro p hp
  have h : env56457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56456_56457 : H12AffineEnvironment.transform 11 1045 env56456 = env56457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env56456 == env56457) = true)

theorem identity56457 : scanCanonicalize (H12AffineFastState.compose env56457 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound56457 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56458 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1038,1045,8,17,1,3,0,1039,1024,0,1029,0,17,2,9,17,1038,1,1045,1038,1024,1,5,1,16,512]

theorem envBound56458 : H12AffineFastState.Bounded env56458 := by
  intro p hp
  have h : env56458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56457_56458 : H12AffineEnvironment.transform 10 1038 env56457 = env56458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env56457 == env56458) = true)

theorem identity56458 : scanCanonicalize (H12AffineFastState.compose env56458 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56458 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56459 : List Nat := [2,4,8,1,0,1,9,5,512,1024,1038,1028,8,0,1,3,0,1039,1024,0,1029,0,0,2,9,0,1038,1,1028,1038,1024,1,5,1,1,512]

theorem envBound56459 : H12AffineFastState.Bounded env56459 := by
  intro p hp
  have h : env56459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56458_56459 : H12AffineEnvironment.transform 3 1 env56458 = env56459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56458 == env56459) = true)

theorem identity56459 : scanCanonicalize (H12AffineFastState.compose env56459 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound56459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56460 : List Nat := [2,4,8,1,0,1,9,5,512,10,4,14,8,0,1,3,0,5,10,0,15,0,0,2,9,0,4,1,14,4,10,1,5,1,1,512]

theorem envBound56460 : H12AffineFastState.Bounded env56460 := by
  intro p hp
  have h : env56460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56459_56460 : H12AffineEnvironment.transform 9 10 env56459 = env56460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env56459 == env56460) = true)

theorem identity56460 : scanCanonicalize (H12AffineFastState.compose env56460 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56460 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56461 : List Nat := [2,4,2,1,0,1,3,5,512,0,4,4,2,0,1,3,0,5,0,0,5,0,0,2,3,0,4,1,4,4,0,1,5,1,1,512]

theorem envBound56461 : H12AffineFastState.Bounded env56461 := by
  intro p hp
  have h : env56461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56460_56461 : H12AffineEnvironment.transform 2 2 env56460 = env56461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56460 == env56461) = true)

def env56462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,4160,156133,156117,21763,8328,65,215367,79130,140485,32160,214035,213350,256,201967,197022,156612]

theorem envBound56462 : H12AffineFastState.Bounded env56462 := by
  intro p hp
  have h : env56462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56447_56462 : H12AffineEnvironment.transform 17 10401 env56447 = env56462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env56447 == env56462) = true)

theorem identity56462 : scanCanonicalize (H12AffineFastState.compose env56462 (packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound56462 : packedSelected [0,1,4,5,7,8,11,16,17,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env56463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,25029,10401,1024,29909,4160,32,16,21763,8328,65,75906,79130,17664,32160,75222,73891,256,95530,90203,513]

theorem envBound56463 : H12AffineFastState.Bounded env56463 := by
  intro p hp
  have h : env56463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56462_56463 : H12AffineEnvironment.transform 16 25029 env56462 = env56463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env56462 == env56463) = true)

theorem identity56463 : scanCanonicalize (H12AffineFastState.compose env56463 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound56463 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env56464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,13388,10401,1024,8540,4160,32,16,138,8328,65,75906,79130,4233,10281,75222,73891,256,73891,79314,513]

theorem envBound56464 : H12AffineFastState.Bounded env56464 := by
  intro p hp
  have h : env56464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56463_56464 : H12AffineEnvironment.transform 13 5513 env56463 = env56464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env56463 == env56464) = true)

theorem identity56464 : scanCanonicalize (H12AffineFastState.compose env56464 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound56464 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env56465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,217,65536,5576,2341,1024,216,4160,32,16,138,268,65,67846,70814,4233,2477,66642,65831,256,65831,70742,513]

theorem envBound56465 : H12AffineFastState.Bounded env56465 := by
  intro p hp
  have h : env56465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56464_56465 : H12AffineEnvironment.transform 12 388 env56464 = env56465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env56464 == env56465) = true)

theorem identity56465 : scanCanonicalize (H12AffineFastState.compose env56465 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound56465 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env56466 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,136,65536,5529,2341,1024,137,4113,32,16,138,268,16,67846,70814,4233,2477,66563,65831,256,65831,70663,513]

theorem envBound56466 : H12AffineFastState.Bounded env56466 := by
  intro p hp
  have h : env56466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56465_56466 : H12AffineEnvironment.transform 5 17 env56465 = env56466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56465 == env56466) = true)

theorem identity56466 : scanCanonicalize (H12AffineFastState.compose env56466 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 6422) := by decide +kernel

theorem selectedBound56466 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env56467 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,136,6422,5529,2341,1024,137,4113,32,16,138,268,16,4112,3464,4233,2477,7445,6193,256,6193,3345,513]

theorem envBound56467 : H12AffineFastState.Bounded env56467 := by
  intro p hp
  have h : env56467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56466_56467 : H12AffineEnvironment.transform 15 6422 env56466 = env56467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6422 env56466 == env56467) = true)

def env56468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,21762,8328,65,215367,115150,396389,35188,497767,243123,256,510106,469311,442288]

theorem envBound56468 : H12AffineFastState.Bounded env56468 := by
  intro p hp
  have h : env56468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1