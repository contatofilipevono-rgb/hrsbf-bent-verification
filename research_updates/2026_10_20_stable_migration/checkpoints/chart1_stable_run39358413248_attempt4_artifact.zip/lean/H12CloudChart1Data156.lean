import H12CloudChart1Data155

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity39557 : scanCanonicalize (H12AffineFastState.compose env39557 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39558 : List Nat := [2,4,8,0,32,64,9,68,512,68,1,32,72,33,65,2,96,97,68,64,97,32,0,67,73,65,1,32,32,96,69,33,68,33,96,577]

theorem envBound39558 : H12AffineFastState.Bounded env39558 := by
  intro p hp
  have h : env39558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39557_39558 : H12AffineEnvironment.transform 3 0 env39557 = env39558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39557 == env39558) = true)

def env39559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound39559 : H12AffineFastState.Bounded env39559 := by
  intro p hp
  have h : env39559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39332_39559 : H12AffineEnvironment.transform 18 1025 env39332 = env39559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env39332 == env39559) = true)

theorem identity39559 : scanCanonicalize (H12AffineFastState.compose env39559 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound39559 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,2097152,4194304,8388608,16777216,8328,65,29616288,18973837,10507600,8579232,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound39560 : H12AffineFastState.Bounded env39560 := by
  intro p hp
  have h : env39560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39559_39560 : H12AffineEnvironment.transform 17 10400 env39559 = env39560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env39559 == env39560) = true)

def env39561 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,8388608,16777216,8192,65,29616168,18973701,10507600,8579112,25265169,23160137,257,27378725,27337992,25207631]

theorem envBound39561 : H12AffineFastState.Bounded env39561 := by
  intro p hp
  have h : env39561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39560_39561 : H12AffineEnvironment.transform 6 8 env39560 = env39561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39560 == env39561) = true)

def env39562 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,16777216,8192,65,21080104,18973701,2233680,43048,17024017,23160137,257,19104805,19096840,16966479]

theorem envBound39562 : H12AffineFastState.Bounded env39562 := by
  intro p hp
  have h : env39562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39561_39562 : H12AffineEnvironment.transform 22 147456 env39561 = env39562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env39561 == env39562) = true)

def env39563 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,2347268,8192,65,6453548,152833,2233680,43048,2102549,4371533,257,21793,46092,2175563]

theorem envBound39563 : H12AffineFastState.Bounded env39563 := by
  intro p hp
  have h : env39563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39562_39563 : H12AffineEnvironment.transform 23 2347268 env39562 = env39563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347268 env39562 == env39563) = true)

def env39564 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147456,98644,8192,65,4204924,152833,17664,43048,148805,4371533,257,21793,46092,221723]

theorem envBound39564 : H12AffineFastState.Bounded env39564 := by
  intro p hp
  have h : env39564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39563_39564 : H12AffineEnvironment.transform 20 151632 env39563 = env39564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env39563 == env39564) = true)

def env39565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,32,147456,98644,8192,65,10588,152833,17664,43048,148805,177261,257,21793,46092,221723]

theorem envBound39565 : H12AffineFastState.Bounded env39565 := by
  intro p hp
  have h : env39565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39564_39565 : H12AffineEnvironment.transform 21 32 env39564 = env39565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39564 == env39565) = true)

theorem identity39565 : scanCanonicalize (H12AffineFastState.compose env39565 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound39565 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39566 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77898,32,73754,98644,8192,65,10588,79131,17664,43048,75103,119927,257,21793,46092,513]

theorem envBound39566 : H12AffineFastState.Bounded env39566 := by
  intro p hp
  have h : env39566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39565_39566 : H12AffineEnvironment.transform 16 90138 env39565 = env39566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env39565 == env39566) = true)

theorem identity39566 : scanCanonicalize (H12AffineFastState.compose env39566 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39566 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4161,32,17,41311,8192,65,10588,5392,17664,43048,1364,62588,257,21793,46092,513]

theorem envBound39567 : H12AffineFastState.Bounded env39567 := by
  intro p hp
  have h : env39567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39566_39567 : H12AffineEnvironment.transform 15 8203 env39566 = env39567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39566 == env39567) = true)

theorem identity39567 : scanCanonicalize (H12AffineFastState.compose env39567 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39567 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2341,1025,32769,4161,32,17,32850,269,65,2129,5392,17664,35109,1364,54641,257,21793,38145,513]

theorem envBound39568 : H12AffineFastState.Bounded env39568 := by
  intro p hp
  have h : env39568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39567_39568 : H12AffineEnvironment.transform 12 269 env39567 = env39568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39567 == env39568) = true)

theorem identity39568 : scanCanonicalize (H12AffineFastState.compose env39568 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound39568 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,262,16401,2341,1025,21841,4161,32,17,21762,269,65,2129,5392,17664,23669,1364,33,257,21793,16465,513]

theorem envBound39569 : H12AffineFastState.Bounded env39569 := by
  intro p hp
  have h : env39569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39568_39569 : H12AffineEnvironment.transform 14 21840 env39568 = env39569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env39568 == env39569) = true)

theorem identity39569 : scanCanonicalize (H12AffineFastState.compose env39569 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound39569 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39570 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,1,262,5440,2341,1025,0,4161,32,17,83,269,65,2129,5392,4177,2340,1364,33,257,112,5376,513]

theorem envBound39570 : H12AffineFastState.Bounded env39570 := by
  intro p hp
  have h : env39570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39569_39570 : H12AffineEnvironment.transform 13 5457 env39569 = env39570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env39569 == env39570) = true)

theorem identity39570 : scanCanonicalize (H12AffineFastState.compose env39570 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound39570 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39571 : List Nat := [2,4,8,16,32,64,8,256,271,1024,2048,4096,269,5457,1,262,5440,2341,1025,0,4161,32,17,83,269,65,2129,5392,4177,2340,1364,33,257,112,5376,270]

theorem envBound39571 : H12AffineFastState.Bounded env39571 := by
  intro p hp
  have h : env39571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39570_39571 : H12AffineEnvironment.transform 8 271 env39570 = env39571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env39570 == env39571) = true)

theorem identity39571 : scanCanonicalize (H12AffineFastState.compose env39571 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39571 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39572 : List Nat := [2,4,8,16,32,17,8,256,271,1024,2048,4096,269,5376,1,262,5393,2341,1025,0,4112,32,17,2,269,16,2048,5392,4096,2340,1285,33,257,33,5376,270]

theorem envBound39572 : H12AffineFastState.Bounded env39572 := by
  intro p hp
  have h : env39572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39571_39572 : H12AffineEnvironment.transform 5 17 env39571 = env39572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39571 == env39572) = true)

theorem identity39572 : scanCanonicalize (H12AffineFastState.compose env39572 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound39572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39573 : List Nat := [2,4,8,16,32,17,8,256,271,1024,2048,33,269,1313,1,262,1328,2341,1025,0,49,32,17,2,269,16,2048,1329,33,2340,1285,33,257,33,1313,270]

theorem envBound39573 : H12AffineFastState.Bounded env39573 := by
  intro p hp
  have h : env39573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39572_39573 : H12AffineEnvironment.transform 11 33 env39572 = env39573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env39572 == env39573) = true)

theorem identity39573 : scanCanonicalize (H12AffineFastState.compose env39573 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound39573 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39574 : List Nat := [2,4,8,16,32,17,8,256,271,1024,1323,33,269,1313,1,262,1328,1038,1025,0,49,32,17,2,269,16,1323,1329,33,1039,1285,33,257,33,1313,270]

theorem envBound39574 : H12AffineFastState.Bounded env39574 := by
  intro p hp
  have h : env39574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39573_39574 : H12AffineEnvironment.transform 10 1323 env39573 = env39574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env39573 == env39574) = true)

theorem identity39574 : scanCanonicalize (H12AffineFastState.compose env39574 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound39574 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39575 : List Nat := [2,4,8,16,32,17,8,30,17,1024,1077,33,19,1087,1,24,1070,1038,1025,0,49,32,17,2,19,16,1077,1071,33,1039,1051,33,31,33,1087,16]

theorem envBound39575 : H12AffineFastState.Bounded env39575 := by
  intro p hp
  have h : env39575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39574_39575 : H12AffineEnvironment.transform 7 30 env39574 = env39575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env39574 == env39575) = true)

theorem identity39575 : scanCanonicalize (H12AffineFastState.compose env39575 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound39575 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39576 : List Nat := [2,4,8,16,32,17,8,30,17,47,26,33,19,16,1,24,1,33,46,0,49,32,17,2,19,16,26,0,33,32,52,33,31,33,16,16]

theorem envBound39576 : H12AffineFastState.Bounded env39576 := by
  intro p hp
  have h : env39576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39575_39576 : H12AffineEnvironment.transform 9 47 env39575 = env39576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env39575 == env39576) = true)

theorem identity39576 : scanCanonicalize (H12AffineFastState.compose env39576 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39576 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39577 : List Nat := [2,4,8,1,32,0,8,15,0,47,11,33,2,1,1,9,1,33,46,0,32,32,0,2,2,1,11,0,33,32,37,33,14,33,1,1]

theorem envBound39577 : H12AffineFastState.Bounded env39577 := by
  intro p hp
  have h : env39577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39576_39577 : H12AffineEnvironment.transform 3 1 env39576 = env39577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39576 == env39577) = true)

theorem identity39577 : scanCanonicalize (H12AffineFastState.compose env39577 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound39577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39578 : List Nat := [2,4,8,1,15,0,8,15,0,0,11,14,2,1,1,9,1,14,1,0,15,15,0,2,2,1,11,0,14,15,10,14,14,14,1,1]

theorem envBound39578 : H12AffineFastState.Bounded env39578 := by
  intro p hp
  have h : env39578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39577_39578 : H12AffineEnvironment.transform 4 15 env39577 = env39578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env39577 == env39578) = true)

theorem identity39578 : scanCanonicalize (H12AffineFastState.compose env39578 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39578 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env39579 : List Nat := [2,4,3,1,4,0,3,4,0,0,0,5,2,1,1,2,1,5,1,0,4,4,0,2,2,1,0,0,5,4,1,5,5,5,1,1]

theorem envBound39579 : H12AffineFastState.Bounded env39579 := by
  intro p hp
  have h : env39579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39578_39579 : H12AffineEnvironment.transform 2 3 env39578 = env39579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39578 == env39579) = true)

theorem identity39579 : scanCanonicalize (H12AffineFastState.compose env39579 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39580 : List Nat := [2,3,3,1,3,0,3,3,0,0,0,2,2,1,1,2,1,2,1,0,3,3,0,2,2,1,0,0,2,3,1,2,2,2,1,1]

theorem envBound39580 : H12AffineFastState.Bounded env39580 := by
  intro p hp
  have h : env39580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39579_39580 : H12AffineEnvironment.transform 1 3 env39579 = env39580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39579 == env39580) = true)

def env39581 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,33,147456,98644,8192,65,10589,152833,17664,43048,148805,177260,257,21793,46092,221723]

theorem envBound39581 : H12AffineFastState.Bounded env39581 := by
  intro p hp
  have h : env39581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39564_39581 : H12AffineEnvironment.transform 21 33 env39564 = env39581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39564 == env39581) = true)

theorem identity39581 : scanCanonicalize (H12AffineFastState.compose env39581 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound39581 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39582 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,4161,33,17,98644,8192,65,10589,5392,17664,43048,1364,62589,257,21793,46092,74250]

theorem envBound39582 : H12AffineFastState.Bounded env39582 := by
  intro p hp
  have h : env39582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39581_39582 : H12AffineEnvironment.transform 16 16401 env39581 = env39582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39581 == env39582) = true)

theorem identity39582 : scanCanonicalize (H12AffineFastState.compose env39582 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound39582 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env39583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,16401,10280,1025,32769,4161,33,17,21842,8192,65,10589,5392,17664,43048,1364,62589,257,21793,46092,62988]

theorem envBound39583 : H12AffineFastState.Bounded env39583 := by
  intro p hp
  have h : env39583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39582_39583 : H12AffineEnvironment.transform 15 54278 env39582 = env39583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env39582 == env39583) = true)

theorem identity39583 : scanCanonicalize (H12AffineFastState.compose env39583 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39583 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env39584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54278,16401,2421,1025,32769,4161,33,17,21842,349,65,2048,5392,17664,35189,1364,54560,257,21793,38225,55121]

theorem envBound39584 : H12AffineFastState.Bounded env39584 := by
  intro p hp
  have h : env39584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39583_39584 : H12AffineEnvironment.transform 12 349 env39583 = env39584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39583 == env39584) = true)

theorem identity39584 : scanCanonicalize (H12AffineFastState.compose env39584 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39584 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env39585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21511,16401,2421,1025,0,4161,33,17,21842,349,65,2048,5392,17664,2420,1364,21793,257,21793,5456,22352]

theorem envBound39585 : H12AffineFastState.Bounded env39585 := by
  intro p hp
  have h : env39585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39584_39585 : H12AffineEnvironment.transform 14 1 env39584 = env39585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39584 == env39585) = true)

theorem identity39585 : scanCanonicalize (H12AffineFastState.compose env39585 (packedSelected [0,2,3,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3182) := by decide +kernel

theorem selectedBound39585 : packedSelected [0,2,3,8,9] rootPS < 2^1333 := by decide +kernel

def env39586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3182,349,16384,1,18537,16401,2421,1025,0,3119,33,17,18748,349,65,2048,2430,17664,2420,1364,18767,257,18767,2366,19262]

theorem envBound39586 : H12AffineFastState.Bounded env39586 := by
  intro p hp
  have h : env39586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39585_39586 : H12AffineEnvironment.transform 11 3182 env39585 = env39586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3182 env39585 == env39586) = true)

theorem identity39586 : scanCanonicalize (H12AffineFastState.compose env39586 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39586 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env39587 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3182,41,16384,1,18537,16401,2049,1025,0,3119,33,17,18504,41,65,2048,2058,17524,2048,1056,18491,117,18491,2122,19018]

theorem envBound39587 : H12AffineFastState.Bounded env39587 := by
  intro p hp
  have h : env39587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39586_39587 : H12AffineEnvironment.transform 7 116 env39586 = env39587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39586 == env39587) = true)

theorem identity39587 : scanCanonicalize (H12AffineFastState.compose env39587 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound39587 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env39588 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3182,41,1028,1,3181,1045,2049,1025,0,3119,33,17,3148,41,65,2048,2058,112,2048,1056,3135,117,3135,2122,3662]

theorem envBound39588 : H12AffineFastState.Bounded env39588 := by
  intro p hp
  have h : env39588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39587_39588 : H12AffineEnvironment.transform 13 1028 env39587 = env39588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env39587 == env39588) = true)

theorem identity39588 : scanCanonicalize (H12AffineFastState.compose env39588 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound39588 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env39589 : List Nat := [2,4,8,16,32,27,8,47,512,1024,2048,3125,41,1028,1,3126,1045,2049,1025,0,3119,33,17,3095,41,26,2048,2058,43,2048,1056,3135,46,3135,2065,3605]

theorem envBound39589 : H12AffineFastState.Bounded env39589 := by
  intro p hp
  have h : env39589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39588_39589 : H12AffineEnvironment.transform 5 27 env39588 = env39589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env39588 == env39589) = true)

theorem identity39589 : scanCanonicalize (H12AffineFastState.compose env39589 (packedSelected [1,2,3,4,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound39589 : packedSelected [1,2,3,4,7,11] rootPS < 2^1333 := by decide +kernel

def env39590 : List Nat := [2,4,8,16,32,27,8,47,512,1024,1038,59,41,1028,1,56,1045,1039,1025,0,33,33,17,25,41,26,1038,1028,43,1038,1056,49,46,49,1055,539]

theorem envBound39590 : H12AffineFastState.Bounded env39590 := by
  intro p hp
  have h : env39590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39589_39590 : H12AffineEnvironment.transform 10 1038 env39589 = env39590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env39589 == env39590) = true)

theorem identity39590 : scanCanonicalize (H12AffineFastState.compose env39590 (packedSelected [0,6] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound39590 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env39591 : List Nat := [2,4,8,16,32,27,8,47,512,522,516,59,41,526,1,56,543,517,523,0,33,33,17,25,41,26,516,526,43,516,554,49,46,49,533,539]

theorem envBound39591 : H12AffineFastState.Bounded env39591 := by
  intro p hp
  have h : env39591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39590_39591 : H12AffineEnvironment.transform 9 522 env39590 = env39591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env39590 == env39591) = true)

theorem identity39591 : scanCanonicalize (H12AffineFastState.compose env39591 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39591 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39592 : List Nat := [2,4,8,16,16,27,8,31,512,522,516,11,25,526,1,8,543,517,523,0,17,17,17,25,25,26,516,526,27,516,538,1,30,1,533,539]

theorem envBound39592 : H12AffineFastState.Bounded env39592 := by
  intro p hp
  have h : env39592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39591_39592 : H12AffineEnvironment.transform 4 16 env39591 = env39592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39591 == env39592) = true)

theorem identity39592 : scanCanonicalize (H12AffineFastState.compose env39592 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39592 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39593 : List Nat := [2,4,8,0,0,11,8,15,512,522,516,11,9,526,1,8,527,517,523,0,1,1,1,9,9,10,516,526,11,516,522,1,14,1,517,523]

theorem envBound39593 : H12AffineFastState.Bounded env39593 := by
  intro p hp
  have h : env39593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39592_39593 : H12AffineEnvironment.transform 3 0 env39592 = env39593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39592 == env39593) = true)

def env39594 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147456,98645,8192,65,4204925,152833,17665,43048,148804,4371533,257,21793,46092,221722]

theorem envBound39594 : H12AffineFastState.Bounded env39594 := by
  intro p hp
  have h : env39594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39563_39594 : H12AffineEnvironment.transform 20 151633 env39563 = env39594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env39563 == env39594) = true)

theorem identity39594 : scanCanonicalize (H12AffineFastState.compose env39594 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound39594 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env39595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77898,4194304,73755,98645,8192,65,4204925,79130,17665,43048,75103,4314198,257,21793,46092,513]

theorem envBound39595 : H12AffineFastState.Bounded env39595 := by
  intro p hp
  have h : env39595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39594_39595 : H12AffineEnvironment.transform 16 90139 env39594 = env39595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env39594 == env39595) = true)

theorem identity39595 : scanCanonicalize (H12AffineFastState.compose env39595 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound39595 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env39596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,4194304,73755,95497,8192,65,4204925,79130,17665,23668,75103,4268042,257,21793,16464,513]

theorem envBound39596 : H12AffineFastState.Bounded env39596 := by
  intro p hp
  have h : env39596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39595_39596 : H12AffineEnvironment.transform 14 29788 env39595 = env39596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39595 == env39596) = true)

def env39597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,32,73755,95497,8192,65,10589,79130,17665,23668,75103,73770,257,21793,16464,513]

theorem envBound39597 : H12AffineFastState.Bounded env39597 := by
  intro p hp
  have h : env39597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39596_39597 : H12AffineEnvironment.transform 21 32 env39596 = env39597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39596 == env39597) = true)

theorem identity39597 : scanCanonicalize (H12AffineFastState.compose env39597 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound39597 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env39598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8282,16449,10280,1025,29789,4112,32,65,21843,8192,65,10589,5440,17665,23668,1285,112,257,21793,16464,513]

theorem envBound39598 : H12AffineFastState.Bounded env39598 := by
  intro p hp
  have h : env39598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39597_39598 : H12AffineEnvironment.transform 15 8282 env39597 = env39598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env39597 == env39598) = true)

theorem identity39598 : scanCanonicalize (H12AffineFastState.compose env39598 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39598 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env39599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,343,16449,2341,1025,21840,4112,32,65,21843,269,65,2128,5440,17665,23668,1285,112,257,21793,16464,513]

theorem envBound39599 : H12AffineFastState.Bounded env39599 := by
  intro p hp
  have h : env39599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39598_39599 : H12AffineEnvironment.transform 12 269 env39598 = env39599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39598 == env39599) = true)

theorem identity39599 : scanCanonicalize (H12AffineFastState.compose env39599 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39599 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,1,343,5393,2341,1025,0,4112,32,65,3,269,65,2128,5440,4177,2340,1285,112,257,113,5376,513]

theorem envBound39600 : H12AffineFastState.Bounded env39600 := by
  intro p hp
  have h : env39600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39599_39600 : H12AffineEnvironment.transform 13 5456 env39599 = env39600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env39599 == env39600) = true)

theorem identity39600 : scanCanonicalize (H12AffineFastState.compose env39600 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound39600 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,513,269,1873,1,343,1808,2341,1025,0,529,32,65,3,269,65,2128,1857,592,2340,1285,112,257,113,1793,513]

theorem envBound39601 : H12AffineFastState.Bounded env39601 := by
  intro p hp
  have h : env39601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39600_39601 : H12AffineEnvironment.transform 11 513 env39600 = env39601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env39600 == env39601) = true)

def env39602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90139,10280,1025,29789,77898,33,73755,95497,8192,65,10588,79130,17665,23668,75103,73771,257,21793,16464,513]

theorem envBound39602 : H12AffineFastState.Bounded env39602 := by
  intro p hp
  have h : env39602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39596_39602 : H12AffineEnvironment.transform 21 33 env39596 = env39602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39596 == env39602) = true)

theorem identity39602 : scanCanonicalize (H12AffineFastState.compose env39602 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound39602 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env39603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21510,13341,10280,1025,29789,25676,33,29725,8463,8192,65,10588,24860,17665,23668,29017,29741,257,21793,16464,513]

theorem envBound39603 : H12AffineFastState.Bounded env39603 := by
  intro p hp
  have h : env39603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39602_39603 : H12AffineEnvironment.transform 15 21510 env39602 = env39603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env39602 == env39603) = true)

theorem identity39603 : scanCanonicalize (H12AffineFastState.compose env39603 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound39603 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,80,8202,13341,10280,1025,81,4160,33,17,8463,8192,65,10588,5392,12557,10360,1365,33,257,8493,13404,513]

theorem envBound39604 : H12AffineFastState.Bounded env39604 := by
  intro p hp
  have h : env39604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39603_39604 : H12AffineEnvironment.transform 13 13324 env39603 = env39604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env39603 == env39604) = true)

theorem identity39604 : scanCanonicalize (H12AffineFastState.compose env39604 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39604 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,80,343,5440,2421,1025,81,4160,33,17,82,349,65,2049,5392,4176,2341,1365,33,257,112,5377,513]

theorem envBound39605 : H12AffineFastState.Bounded env39605 := by
  intro p hp
  have h : env39605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39604_39605 : H12AffineEnvironment.transform 12 349 env39604 = env39605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39604 == env39605) = true)

theorem identity39605 : scanCanonicalize (H12AffineFastState.compose env39605 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39605 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39606 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1025,0,4113,33,17,3,268,16,2049,5392,4097,2341,1284,33,257,33,5377,513]

theorem envBound39606 : H12AffineFastState.Bounded env39606 := by
  intro p hp
  have h : env39606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39605_39606 : H12AffineEnvironment.transform 5 17 env39605 = env39606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39605 == env39606) = true)

theorem identity39606 : scanCanonicalize (H12AffineFastState.compose env39606 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound39606 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39607 : List Nat := [2,4,8,16,32,17,8,256,512,289,2048,4096,268,4129,1,262,4144,2340,288,0,4113,33,17,3,268,16,2049,4145,4097,2341,37,33,257,33,4128,513]

theorem envBound39607 : H12AffineFastState.Bounded env39607 := by
  intro p hp
  have h : env39607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39606_39607 : H12AffineEnvironment.transform 9 289 env39606 = env39607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env39606 == env39607) = true)

theorem identity39607 : scanCanonicalize (H12AffineFastState.compose env39607 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound39607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39608 : List Nat := [2,4,8,16,32,17,8,256,293,289,2048,4096,268,4129,1,262,4144,2340,288,0,4113,33,17,3,268,16,2049,4145,4097,2341,37,33,257,33,4128,292]

theorem envBound39608 : H12AffineFastState.Bounded env39608 := by
  intro p hp
  have h : env39608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39607_39608 : H12AffineEnvironment.transform 8 293 env39607 = env39608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env39607 == env39608) = true)

theorem identity39608 : scanCanonicalize (H12AffineFastState.compose env39608 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2081) := by decide +kernel

theorem selectedBound39608 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39609 : List Nat := [2,4,8,16,32,17,8,256,293,289,2048,2081,268,2048,1,262,2065,2340,288,0,2096,33,17,3,268,16,2049,2064,2080,2341,37,33,257,33,2049,292]

theorem envBound39609 : H12AffineFastState.Bounded env39609 := by
  intro p hp
  have h : env39609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39608_39609 : H12AffineEnvironment.transform 11 2081 env39608 = env39609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2081 env39608 == env39609) = true)

theorem identity39609 : scanCanonicalize (H12AffineFastState.compose env39609 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39609 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39610 : List Nat := [2,4,8,16,0,17,8,256,261,257,2048,2049,268,2048,1,262,2065,2308,256,0,2064,1,17,3,268,16,2049,2064,2048,2309,5,1,257,1,2049,260]

theorem envBound39610 : H12AffineFastState.Bounded env39610 := by
  intro p hp
  have h : env39610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39609_39610 : H12AffineEnvironment.transform 4 0 env39609 = env39610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39609 == env39610) = true)

theorem identity39610 : scanCanonicalize (H12AffineFastState.compose env39610 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound39610 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39611 : List Nat := [2,4,8,16,0,17,8,256,261,257,17,16,268,17,1,262,0,277,256,0,1,1,17,3,268,16,16,1,17,276,5,1,257,1,16,260]

theorem envBound39611 : H12AffineFastState.Bounded env39611 := by
  intro p hp
  have h : env39611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39610_39611 : H12AffineEnvironment.transform 10 17 env39610 = env39611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env39610 == env39611) = true)

theorem identity39611 : scanCanonicalize (H12AffineFastState.compose env39611 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39611 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39612 : List Nat := [2,4,8,16,0,17,8,20,17,21,17,16,24,17,1,18,0,1,20,0,1,1,17,3,24,16,16,1,17,0,5,1,21,1,16,16]

theorem envBound39612 : H12AffineFastState.Bounded env39612 := by
  intro p hp
  have h : env39612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39611_39612 : H12AffineEnvironment.transform 7 20 env39611 = env39612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39611 == env39612) = true)

def env39613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147456,2347269,8192,65,6453549,152832,2233680,43048,2102548,4371532,257,21792,46093,2175562]

theorem envBound39613 : H12AffineFastState.Bounded env39613 := by
  intro p hp
  have h : env39613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39562_39613 : H12AffineEnvironment.transform 23 2347269 env39562 = env39613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2347269 env39562 == env39613) = true)

def env39614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151632,4194304,147456,98645,8192,65,4204925,152832,17664,43048,148804,4371532,257,21792,46093,221722]

theorem envBound39614 : H12AffineFastState.Bounded env39614 := by
  intro p hp
  have h : env39614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39613_39614 : H12AffineEnvironment.transform 20 151632 env39613 = env39614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151632 env39613 == env39614) = true)

theorem identity39614 : scanCanonicalize (H12AffineFastState.compose env39614 (packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound39614 : packedSelected [0,1,5,8,9,11,14,18,19,22,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env39615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1025,32769,77899,4194304,73755,98645,8192,65,4204925,79131,17664,43048,75103,4314199,257,21792,46093,513]

theorem envBound39615 : H12AffineFastState.Bounded env39615 := by
  intro p hp
  have h : env39615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39614_39615 : H12AffineEnvironment.transform 16 90139 env39614 = env39615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env39614 == env39615) = true)

theorem identity39615 : scanCanonicalize (H12AffineFastState.compose env39615 (packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound39615 : packedSelected [0,1,3,7,11,12,15,17,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env39616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,4194304,73755,95496,8192,65,4204925,79131,17664,23669,75103,4268042,257,21792,16464,513]

theorem envBound39616 : H12AffineFastState.Bounded env39616 := by
  intro p hp
  have h : env39616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39615_39616 : H12AffineEnvironment.transform 14 29789 env39615 = env39616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env39615 == env39616) = true)

def env39617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,32,73755,95496,8192,65,10589,79131,17664,23669,75103,73770,257,21792,16464,513]

theorem envBound39617 : H12AffineFastState.Bounded env39617 := by
  intro p hp
  have h : env39617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39616_39617 : H12AffineEnvironment.transform 21 32 env39616 = env39617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39616 == env39617) = true)

theorem identity39617 : scanCanonicalize (H12AffineFastState.compose env39617 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound39617 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env39618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8282,16449,10280,1025,29788,4113,32,65,21842,8192,65,10589,5441,17664,23669,1285,112,257,21792,16464,513]

theorem envBound39618 : H12AffineFastState.Bounded env39618 := by
  intro p hp
  have h : env39618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39617_39618 : H12AffineEnvironment.transform 15 8282 env39617 = env39618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env39617 == env39618) = true)

theorem identity39618 : scanCanonicalize (H12AffineFastState.compose env39618 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39618 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env39619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21840,343,16449,2341,1025,21841,4113,32,65,21842,269,65,2128,5441,17664,23669,1285,112,257,21792,16464,513]

theorem envBound39619 : H12AffineFastState.Bounded env39619 := by
  intro p hp
  have h : env39619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39618_39619 : H12AffineEnvironment.transform 12 269 env39618 = env39619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39618 == env39619) = true)

theorem identity39619 : scanCanonicalize (H12AffineFastState.compose env39619 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound39619 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,1,343,5392,2341,1025,0,4113,32,65,3,269,65,2128,5441,4177,2340,1285,112,257,113,5377,513]

theorem envBound39620 : H12AffineFastState.Bounded env39620 := by
  intro p hp
  have h : env39620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39619_39620 : H12AffineEnvironment.transform 13 5457 env39619 = env39620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env39619 == env39620) = true)

theorem identity39620 : scanCanonicalize (H12AffineFastState.compose env39620 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound39620 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,513,269,1872,1,343,1809,2341,1025,0,528,32,65,3,269,65,2128,1856,592,2340,1285,112,257,113,1792,513]

theorem envBound39621 : H12AffineFastState.Bounded env39621 := by
  intro p hp
  have h : env39621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39620_39621 : H12AffineEnvironment.transform 11 513 env39620 = env39621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env39620 == env39621) = true)

def env39622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,10280,1025,29788,77899,33,73755,95496,8192,65,10588,79131,17664,23669,75103,73771,257,21792,16464,513]

theorem envBound39622 : H12AffineFastState.Bounded env39622 := by
  intro p hp
  have h : env39622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39616_39622 : H12AffineEnvironment.transform 21 33 env39616 = env39622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39616 == env39622) = true)

theorem identity39622 : scanCanonicalize (H12AffineFastState.compose env39622 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound39622 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env39623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21511,13340,10280,1025,29788,25676,33,29724,8463,8192,65,10588,24860,17664,23669,29016,29740,257,21792,16464,513]

theorem envBound39623 : H12AffineFastState.Bounded env39623 := by
  intro p hp
  have h : env39623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39622_39623 : H12AffineEnvironment.transform 15 21511 env39622 = env39623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env39622 == env39623) = true)

theorem identity39623 : scanCanonicalize (H12AffineFastState.compose env39623 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound39623 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env39624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,8202,13340,10280,1025,81,4161,33,17,8463,8192,65,10588,5393,12557,10360,1365,33,257,8493,13405,513]

theorem envBound39624 : H12AffineFastState.Bounded env39624 := by
  intro p hp
  have h : env39624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39623_39624 : H12AffineEnvironment.transform 13 13325 env39623 = env39624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env39623 == env39624) = true)

theorem identity39624 : scanCanonicalize (H12AffineFastState.compose env39624 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39624 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,343,5441,2421,1025,81,4161,33,17,82,349,65,2049,5393,4176,2341,1365,33,257,112,5376,513]

theorem envBound39625 : H12AffineFastState.Bounded env39625 := by
  intro p hp
  have h : env39625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39624_39625 : H12AffineEnvironment.transform 12 349 env39624 = env39625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39624 == env39625) = true)

theorem identity39625 : scanCanonicalize (H12AffineFastState.compose env39625 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39625 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39626 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5392,2340,1025,0,4112,33,17,3,268,16,2049,5393,4097,2341,1284,33,257,33,5376,513]

theorem envBound39626 : H12AffineFastState.Bounded env39626 := by
  intro p hp
  have h : env39626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39625_39626 : H12AffineEnvironment.transform 5 17 env39625 = env39626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39625 == env39626) = true)

theorem identity39626 : scanCanonicalize (H12AffineFastState.compose env39626 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound39626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39627 : List Nat := [2,4,8,16,32,17,8,256,512,288,2048,4096,268,4129,1,262,4144,2340,289,0,4112,33,17,3,268,16,2049,4145,4097,2341,36,33,257,33,4128,513]

theorem envBound39627 : H12AffineFastState.Bounded env39627 := by
  intro p hp
  have h : env39627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39626_39627 : H12AffineEnvironment.transform 9 288 env39626 = env39627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env39626 == env39627) = true)

theorem identity39627 : scanCanonicalize (H12AffineFastState.compose env39627 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound39627 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39628 : List Nat := [2,4,8,16,32,17,8,256,293,288,2048,4096,268,4129,1,262,4144,2340,289,0,4112,33,17,3,268,16,2049,4145,4097,2341,36,33,257,33,4128,292]

theorem envBound39628 : H12AffineFastState.Bounded env39628 := by
  intro p hp
  have h : env39628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39627_39628 : H12AffineEnvironment.transform 8 293 env39627 = env39628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env39627 == env39628) = true)

theorem identity39628 : scanCanonicalize (H12AffineFastState.compose env39628 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound39628 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39629 : List Nat := [2,4,8,16,32,17,8,256,293,288,2048,2080,268,2049,1,262,2064,2340,289,0,2096,33,17,3,268,16,2049,2065,2081,2341,36,33,257,33,2048,292]

theorem envBound39629 : H12AffineFastState.Bounded env39629 := by
  intro p hp
  have h : env39629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39628_39629 : H12AffineEnvironment.transform 11 2080 env39628 = env39629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env39628 == env39629) = true)

theorem identity39629 : scanCanonicalize (H12AffineFastState.compose env39629 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39629 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39630 : List Nat := [2,4,8,16,0,17,8,256,261,256,2048,2048,268,2049,1,262,2064,2308,257,0,2064,1,17,3,268,16,2049,2065,2049,2309,4,1,257,1,2048,260]

theorem envBound39630 : H12AffineFastState.Bounded env39630 := by
  intro p hp
  have h : env39630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39629_39630 : H12AffineEnvironment.transform 4 0 env39629 = env39630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39629 == env39630) = true)

theorem identity39630 : scanCanonicalize (H12AffineFastState.compose env39630 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound39630 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39631 : List Nat := [2,4,8,16,0,17,8,256,261,256,17,17,268,16,1,262,1,277,257,0,1,1,17,3,268,16,16,0,16,276,4,1,257,1,17,260]

theorem envBound39631 : H12AffineFastState.Bounded env39631 := by
  intro p hp
  have h : env39631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39630_39631 : H12AffineEnvironment.transform 10 17 env39630 = env39631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env39630 == env39631) = true)

theorem identity39631 : scanCanonicalize (H12AffineFastState.compose env39631 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39631 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39632 : List Nat := [2,4,8,16,0,17,8,20,17,20,17,17,24,16,1,18,1,1,21,0,1,1,17,3,24,16,16,0,16,0,4,1,21,1,17,16]

theorem envBound39632 : H12AffineFastState.Bounded env39632 := by
  intro p hp
  have h : env39632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39631_39632 : H12AffineEnvironment.transform 7 20 env39631 = env39632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39631 == env39632) = true)

theorem identity39632 : scanCanonicalize (H12AffineFastState.compose env39632 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39632 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env39633 : List Nat := [2,4,8,1,0,0,8,5,0,5,0,0,9,1,1,3,1,1,4,0,1,1,0,3,9,1,1,0,1,0,4,1,4,1,0,1]

theorem envBound39633 : H12AffineFastState.Bounded env39633 := by
  intro p hp
  have h : env39633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39632_39633 : H12AffineEnvironment.transform 3 1 env39632 = env39633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39632 == env39633) = true)

theorem identity39633 : scanCanonicalize (H12AffineFastState.compose env39633 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39634 : List Nat := [2,4,3,1,0,0,3,5,0,5,0,0,2,1,1,3,1,1,4,0,1,1,0,3,2,1,1,0,1,0,4,1,4,1,0,1]

theorem envBound39634 : H12AffineFastState.Bounded env39634 := by
  intro p hp
  have h : env39634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39633_39634 : H12AffineEnvironment.transform 2 3 env39633 = env39634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39633 == env39634) = true)

def env39635 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,4194304,147456,98644,8192,65,4204924,152832,17665,43048,148805,4371532,257,21792,46093,221723]

theorem envBound39635 : H12AffineFastState.Bounded env39635 := by
  intro p hp
  have h : env39635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39613_39635 : H12AffineEnvironment.transform 20 151633 env39613 = env39635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151633 env39613 == env39635) = true)

def env39636 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,32,147456,98644,8192,65,10588,152832,17665,43048,148805,177260,257,21792,46093,221723]

theorem envBound39636 : H12AffineFastState.Bounded env39636 := by
  intro p hp
  have h : env39636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39635_39636 : H12AffineEnvironment.transform 21 32 env39635 = env39636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39635 == env39636) = true)

theorem identity39636 : scanCanonicalize (H12AffineFastState.compose env39636 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound39636 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39637 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1025,32769,77899,32,73754,98644,8192,65,10588,79130,17665,43048,75103,119926,257,21792,46093,513]

theorem envBound39637 : H12AffineFastState.Bounded env39637 := by
  intro p hp
  have h : env39637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39636_39637 : H12AffineEnvironment.transform 16 90138 env39636 = env39637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env39636 == env39637) = true)

theorem identity39637 : scanCanonicalize (H12AffineFastState.compose env39637 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39637 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10280,1025,32769,4160,32,17,41311,8192,65,10588,5393,17665,43048,1364,62589,257,21792,46093,513]

theorem envBound39638 : H12AffineFastState.Bounded env39638 := by
  intro p hp
  have h : env39638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39637_39638 : H12AffineEnvironment.transform 15 8203 env39637 = env39638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39637 == env39638) = true)

theorem identity39638 : scanCanonicalize (H12AffineFastState.compose env39638 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39638 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env39639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,262,16401,2341,1025,32769,4160,32,17,32850,269,65,2129,5393,17665,35109,1364,54640,257,21792,38144,513]

theorem envBound39639 : H12AffineFastState.Bounded env39639 := by
  intro p hp
  have h : env39639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39638_39639 : H12AffineEnvironment.transform 12 269 env39638 = env39639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39638 == env39639) = true)

theorem identity39639 : scanCanonicalize (H12AffineFastState.compose env39639 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound39639 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,21841,262,16401,2341,1025,21840,4160,32,17,21763,269,65,2129,5393,17665,23668,1364,33,257,21792,16465,513]

theorem envBound39640 : H12AffineFastState.Bounded env39640 := by
  intro p hp
  have h : env39640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39639_39640 : H12AffineEnvironment.transform 14 21841 env39639 = env39640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env39639 == env39640) = true)

theorem identity39640 : scanCanonicalize (H12AffineFastState.compose env39640 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound39640 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,1,262,5441,2341,1025,0,4160,32,17,83,269,65,2129,5393,4177,2340,1364,33,257,112,5377,513]

theorem envBound39641 : H12AffineFastState.Bounded env39641 := by
  intro p hp
  have h : env39641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39640_39641 : H12AffineEnvironment.transform 13 5456 env39640 = env39641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env39640 == env39641) = true)

theorem identity39641 : scanCanonicalize (H12AffineFastState.compose env39641 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 351) := by decide +kernel

theorem selectedBound39641 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39642 : List Nat := [2,4,8,16,32,64,8,256,351,1024,2048,4096,269,5456,1,262,5441,2341,1025,0,4160,32,17,83,269,65,2129,5393,4177,2340,1364,33,257,112,5377,350]

theorem envBound39642 : H12AffineFastState.Bounded env39642 := by
  intro p hp
  have h : env39642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39641_39642 : H12AffineEnvironment.transform 8 351 env39641 = env39642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 351 env39641 == env39642) = true)

theorem identity39642 : scanCanonicalize (H12AffineFastState.compose env39642 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39642 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39643 : List Nat := [2,4,8,16,32,17,8,256,270,1024,2048,4096,269,5377,1,262,5392,2341,1025,0,4113,32,17,2,269,16,2048,5393,4096,2340,1285,33,257,33,5377,271]

theorem envBound39643 : H12AffineFastState.Bounded env39643 := by
  intro p hp
  have h : env39643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39642_39643 : H12AffineEnvironment.transform 5 17 env39642 = env39643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39642 == env39643) = true)

theorem identity39643 : scanCanonicalize (H12AffineFastState.compose env39643 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound39643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39644 : List Nat := [2,4,8,16,32,17,8,256,270,1024,2048,33,269,1312,1,262,1329,2341,1025,0,48,32,17,2,269,16,2048,1328,33,2340,1285,33,257,33,1312,271]

theorem envBound39644 : H12AffineFastState.Bounded env39644 := by
  intro p hp
  have h : env39644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39643_39644 : H12AffineEnvironment.transform 11 33 env39643 = env39644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env39643 == env39644) = true)

theorem identity39644 : scanCanonicalize (H12AffineFastState.compose env39644 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1323) := by decide +kernel

theorem selectedBound39644 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39645 : List Nat := [2,4,8,16,32,17,8,256,270,1024,1323,33,269,1312,1,262,1329,1038,1025,0,48,32,17,2,269,16,1323,1328,33,1039,1285,33,257,33,1312,271]

theorem envBound39645 : H12AffineFastState.Bounded env39645 := by
  intro p hp
  have h : env39645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39644_39645 : H12AffineEnvironment.transform 10 1323 env39644 = env39645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1323 env39644 == env39645) = true)

theorem identity39645 : scanCanonicalize (H12AffineFastState.compose env39645 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound39645 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39646 : List Nat := [2,4,8,16,32,17,8,31,17,1024,1076,33,18,1087,1,25,1070,1038,1025,0,48,32,17,2,18,16,1076,1071,33,1039,1050,33,30,33,1087,16]

theorem envBound39646 : H12AffineFastState.Bounded env39646 := by
  intro p hp
  have h : env39646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39645_39646 : H12AffineEnvironment.transform 7 31 env39645 = env39646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env39645 == env39646) = true)

theorem identity39646 : scanCanonicalize (H12AffineFastState.compose env39646 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound39646 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39647 : List Nat := [2,4,8,16,32,17,8,31,17,46,26,33,18,17,1,25,0,32,47,0,48,32,17,2,18,16,26,1,33,33,52,33,30,33,17,16]

theorem envBound39647 : H12AffineFastState.Bounded env39647 := by
  intro p hp
  have h : env39647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39646_39647 : H12AffineEnvironment.transform 9 46 env39646 = env39647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env39646 == env39647) = true)

theorem identity39647 : scanCanonicalize (H12AffineFastState.compose env39647 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39647 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39648 : List Nat := [2,4,8,0,32,1,8,15,1,46,10,33,2,1,1,9,0,32,47,0,32,32,1,2,2,0,10,1,33,33,36,33,14,33,1,0]

theorem envBound39648 : H12AffineFastState.Bounded env39648 := by
  intro p hp
  have h : env39648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39647_39648 : H12AffineEnvironment.transform 3 0 env39647 = env39648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39647 == env39648) = true)

theorem identity39648 : scanCanonicalize (H12AffineFastState.compose env39648 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound39648 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39649 : List Nat := [2,4,8,0,4,1,8,15,1,10,10,5,2,1,1,9,0,4,11,0,4,4,1,2,2,0,10,1,5,5,0,5,14,5,1,0]

theorem envBound39649 : H12AffineFastState.Bounded env39649 := by
  intro p hp
  have h : env39649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39648_39649 : H12AffineEnvironment.transform 4 4 env39648 = env39649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env39648 == env39649) = true)

theorem identity39649 : scanCanonicalize (H12AffineFastState.compose env39649 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39649 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env39650 : List Nat := [2,4,2,0,4,1,2,5,1,0,0,5,2,1,1,3,0,4,1,0,4,4,1,2,2,0,0,1,5,5,0,5,4,5,1,0]

theorem envBound39650 : H12AffineFastState.Bounded env39650 := by
  intro p hp
  have h : env39650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39649_39650 : H12AffineEnvironment.transform 2 2 env39649 = env39650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39649 == env39650) = true)

theorem identity39650 : scanCanonicalize (H12AffineFastState.compose env39650 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39651 : List Nat := [2,3,2,0,3,1,2,2,1,0,0,2,2,1,1,3,0,3,1,0,3,3,1,2,2,0,0,1,2,2,0,2,3,2,1,0]

theorem envBound39651 : H12AffineFastState.Bounded env39651 := by
  intro p hp
  have h : env39651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39650_39651 : H12AffineEnvironment.transform 1 3 env39650 = env39651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39650 == env39651) = true)

def env39652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,151633,33,147456,98644,8192,65,10589,152832,17665,43048,148805,177261,257,21792,46093,221723]

theorem envBound39652 : H12AffineFastState.Bounded env39652 := by
  intro p hp
  have h : env39652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39635_39652 : H12AffineEnvironment.transform 21 33 env39635 = env39652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39635 == env39652) = true)

theorem identity39652 : scanCanonicalize (H12AffineFastState.compose env39652 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39652 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,10280,1025,32769,151633,33,147456,41311,8192,65,10589,152832,17665,43048,148805,177261,257,21792,46093,147984]

theorem envBound39653 : H12AffineFastState.Bounded env39653 := by
  intro p hp
  have h : env39653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39652_39653 : H12AffineEnvironment.transform 15 8203 env39652 = env39653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39652 == env39653) = true)

theorem identity39653 : scanCanonicalize (H12AffineFastState.compose env39653 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39653 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env39654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,131072,2340,1025,32769,151633,33,147456,32851,268,65,2129,152832,17665,35108,148805,169313,257,21792,38145,147984]

theorem envBound39654 : H12AffineFastState.Bounded env39654 := by
  intro p hp
  have h : env39654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39653_39654 : H12AffineEnvironment.transform 12 268 env39653 = env39654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39653 == env39654) = true)

theorem identity39654 : scanCanonicalize (H12AffineFastState.compose env39654 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound39654 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,263,131072,2340,1025,80,151633,33,147456,2,268,65,2129,152832,17665,2421,148805,136496,257,21792,5456,147984]

theorem envBound39655 : H12AffineFastState.Bounded env39655 := by
  intro p hp
  have h : env39655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39654_39655 : H12AffineEnvironment.transform 14 81 env39654 = env39655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env39654 == env39655) = true)

theorem identity39655 : scanCanonicalize (H12AffineFastState.compose env39655 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39655 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env39656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,131072,2340,1025,80,132432,33,136449,2,268,65,2129,131073,4096,2421,135236,136496,257,33,5456,136977]

theorem envBound39656 : H12AffineFastState.Bounded env39656 := by
  intro p hp
  have h : env39656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39655_39656 : H12AffineEnvironment.transform 13 5377 env39655 = env39656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39655 == env39656) = true)

theorem identity39656 : scanCanonicalize (H12AffineFastState.compose env39656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39657 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,131072,2340,1025,0,132352,33,136449,2,268,17,2049,131073,4096,2341,135188,136496,257,33,5376,136977]

theorem envBound39657 : H12AffineFastState.Bounded env39657 := by
  intro p hp
  have h : env39657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39656_39657 : H12AffineEnvironment.transform 5 16 env39656 = env39657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39656 == env39657) = true)

theorem identity39657 : scanCanonicalize (H12AffineFastState.compose env39657 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound39657 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env39658 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,1,263,5392,2340,1025,0,4112,33,17,2,268,17,2049,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound39658 : H12AffineFastState.Bounded env39658 := by
  intro p hp
  have h : env39658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39657_39658 : H12AffineEnvironment.transform 16 5392 env39657 = env39658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39657 == env39658) = true)

theorem identity39658 : scanCanonicalize (H12AffineFastState.compose env39658 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound39658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39659 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1076,268,309,1,263,292,2340,1025,0,1060,33,17,2,268,17,2049,293,1076,2341,1284,32,257,33,308,513]

theorem envBound39659 : H12AffineFastState.Bounded env39659 := by
  intro p hp
  have h : env39659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39658_39659 : H12AffineEnvironment.transform 11 1076 env39658 = env39659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env39658 == env39659) = true)

theorem identity39659 : scanCanonicalize (H12AffineFastState.compose env39659 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1306) := by decide +kernel

theorem selectedBound39659 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39660 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1306,1076,268,309,1,263,292,1086,1025,0,1060,33,17,2,268,17,1307,293,1076,1087,1284,32,257,33,308,513]

theorem envBound39660 : H12AffineFastState.Bounded env39660 := by
  intro p hp
  have h : env39660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39659_39660 : H12AffineEnvironment.transform 10 1306 env39659 = env39660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1306 env39659 == env39660) = true)

theorem identity39660 : scanCanonicalize (H12AffineFastState.compose env39660 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 315) := by decide +kernel

theorem selectedBound39660 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39661 : List Nat := [2,4,8,16,32,16,8,256,512,315,33,271,268,309,1,263,292,261,314,0,287,33,17,2,268,17,32,293,271,260,63,32,257,33,308,513]

theorem envBound39661 : H12AffineFastState.Bounded env39661 := by
  intro p hp
  have h : env39661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39660_39661 : H12AffineEnvironment.transform 9 315 env39660 = env39661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 315 env39660 == env39661) = true)

theorem identity39661 : scanCanonicalize (H12AffineFastState.compose env39661 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39661 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39662 : List Nat := [2,4,8,16,16,16,8,256,512,267,17,271,268,261,1,263,276,261,266,0,287,17,17,2,268,17,16,277,271,260,15,16,257,17,260,513]

theorem envBound39662 : H12AffineFastState.Bounded env39662 := by
  intro p hp
  have h : env39662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39661_39662 : H12AffineEnvironment.transform 4 16 env39661 = env39662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39661 == env39662) = true)

theorem identity39662 : scanCanonicalize (H12AffineFastState.compose env39662 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound39662 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39663 : List Nat := [2,4,8,16,16,16,8,15,512,4,17,0,3,10,1,8,27,10,5,0,16,17,17,2,3,17,16,26,0,11,15,16,14,17,11,513]

theorem envBound39663 : H12AffineFastState.Bounded env39663 := by
  intro p hp
  have h : env39663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39662_39663 : H12AffineEnvironment.transform 7 15 env39662 = env39663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env39662 == env39663) = true)

theorem identity39663 : scanCanonicalize (H12AffineFastState.compose env39663 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound39663 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39664 : List Nat := [2,4,8,7,7,7,8,15,512,4,6,0,3,10,1,8,12,10,5,0,7,6,6,2,3,6,7,13,0,11,15,7,14,6,11,513]

theorem envBound39664 : H12AffineFastState.Bounded env39664 := by
  intro p hp
  have h : env39664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39663_39664 : H12AffineEnvironment.transform 3 7 env39663 = env39664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env39663 == env39664) = true)

def env39665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,16777216,8192,65,21080105,18973701,2233681,43049,17024016,23160137,257,19104804,19096841,16966478]

theorem envBound39665 : H12AffineFastState.Bounded env39665 := by
  intro p hp
  have h : env39665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39561_39665 : H12AffineEnvironment.transform 22 147457 env39561 = env39665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env39561 == env39665) = true)

theorem identity39665 : scanCanonicalize (H12AffineFastState.compose env39665 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound39665 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188751,8192,65,4409702,2319690,2233681,43049,75103,6521862,257,2188651,2196550,513]

theorem envBound39666 : H12AffineFastState.Bounded env39666 := by
  intro p hp
  have h : env39666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39665_39666 : H12AffineEnvironment.transform 23 188751 env39665 = env39666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env39665 == env39666) = true)

def env39667 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188703,8192,17,4409654,2319642,2233601,43049,75023,6521862,257,2188603,2196502,513]

theorem envBound39667 : H12AffineFastState.Bounded env39667 := by
  intro p hp
  have h : env39667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39666_39667 : H12AffineEnvironment.transform 5 16 env39666 = env39667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39666 == env39667) = true)

theorem identity39667 : scanCanonicalize (H12AffineFastState.compose env39667 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound39667 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env39668 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115734,4194304,147457,188703,8192,17,4409654,172300,250135,43049,75023,4341776,257,41261,16384,513]

theorem envBound39668 : H12AffineFastState.Bounded env39668 := by
  intro p hp
  have h : env39668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39667_39668 : H12AffineEnvironment.transform 20 115734 env39667 = env39668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env39667 == env39668) = true)

theorem identity39668 : scanCanonicalize (H12AffineFastState.compose env39668 (packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39668 : packedSelected [1,2,4,5,6,8,9,11,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env39669 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115734,4194304,147457,180243,268,17,4409654,163840,250135,35109,66563,4341776,257,32801,16384,513]

theorem envBound39669 : H12AffineFastState.Bounded env39669 := by
  intro p hp
  have h : env39669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39668_39669 : H12AffineEnvironment.transform 12 268 env39668 = env39669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39668 == env39669) = true)

theorem identity39669 : scanCanonicalize (H12AffineFastState.compose env39669 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound39669 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env39670 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,131072,2340,1025,32769,115734,32800,147457,180243,268,17,248086,163840,250135,35109,66563,180272,257,32801,16384,513]

theorem envBound39670 : H12AffineFastState.Bounded env39670 := by
  intro p hp
  have h : env39670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39669_39670 : H12AffineEnvironment.transform 21 32800 env39669 = env39670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env39669 == env39670) = true)

theorem identity39670 : scanCanonicalize (H12AffineFastState.compose env39670 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound39670 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39671 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,82199,2340,1025,32769,115734,32800,65814,98564,268,17,34817,114967,36864,35109,66563,98599,257,32801,16384,513]

theorem envBound39671 : H12AffineFastState.Bounded env39671 := by
  intro p hp
  have h : env39671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39670_39671 : H12AffineEnvironment.transform 16 82199 env39670 = env39671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env39670 == env39671) = true)

theorem identity39671 : scanCanonicalize (H12AffineFastState.compose env39671 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound39671 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39672 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2340,1025,32769,50449,32800,17,32771,268,17,34817,49168,36864,35109,1284,32800,257,32801,16384,513]

theorem envBound39672 : H12AffineFastState.Bounded env39672 := by
  intro p hp
  have h : env39672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39671_39672 : H12AffineEnvironment.transform 15 263 env39671 = env39672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env39671 == env39672) = true)

theorem identity39672 : scanCanonicalize (H12AffineFastState.compose env39672 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39672 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env39673 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16400,2340,1025,0,17680,33,17,2,268,17,2048,16401,4097,2340,1284,33,257,32,16384,513]

theorem envBound39673 : H12AffineFastState.Bounded env39673 := by
  intro p hp
  have h : env39673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39672_39673 : H12AffineEnvironment.transform 14 1 env39672 = env39673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39672 == env39673) = true)

theorem identity39673 : scanCanonicalize (H12AffineFastState.compose env39673 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound39673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39674 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5157,1,263,5173,2340,1025,0,4405,33,17,2,268,17,2048,5172,4097,2340,1284,33,257,32,5157,513]

theorem envBound39674 : H12AffineFastState.Bounded env39674 := by
  intro p hp
  have h : env39674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39673_39674 : H12AffineEnvironment.transform 13 5157 env39673 = env39674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env39673 == env39674) = true)

def env39675 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,268,2837,1,263,2821,2340,1025,0,3589,33,17,2,268,17,2048,2820,3889,2340,1284,33,257,32,2837,513]

theorem envBound39675 : H12AffineFastState.Bounded env39675 := by
  intro p hp
  have h : env39675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39674_39675 : H12AffineEnvironment.transform 11 3888 env39674 = env39675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env39674 == env39675) = true)

def env39676 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,268,1045,1,263,1029,1572,1025,0,261,33,17,2,268,17,1792,1028,49,1572,1284,33,257,32,1045,513]

theorem envBound39676 : H12AffineFastState.Bounded env39676 := by
  intro p hp
  have h : env39676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39675_39676 : H12AffineEnvironment.transform 10 1792 env39675 = env39676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env39675 == env39676) = true)

theorem identity39676 : scanCanonicalize (H12AffineFastState.compose env39676 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound39676 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39677 : List Nat := [2,4,8,16,32,16,8,256,512,800,32,48,268,821,1,263,805,260,801,0,261,33,17,2,268,17,32,804,49,260,548,33,257,32,821,513]

theorem envBound39677 : H12AffineFastState.Bounded env39677 := by
  intro p hp
  have h : env39677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39676_39677 : H12AffineEnvironment.transform 9 800 env39676 = env39677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env39676 == env39677) = true)

def env39678 : List Nat := [2,4,8,16,32,16,8,256,276,52,32,48,268,33,1,263,49,260,53,0,261,33,17,2,268,17,32,48,49,260,304,33,257,32,33,277]

theorem envBound39678 : H12AffineFastState.Bounded env39678 := by
  intro p hp
  have h : env39678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39677_39678 : H12AffineEnvironment.transform 8 276 env39677 = env39678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env39677 == env39678) = true)

theorem identity39678 : scanCanonicalize (H12AffineFastState.compose env39678 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39678 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39679 : List Nat := [2,4,8,11,32,11,8,256,271,47,32,43,268,33,1,263,42,260,46,0,261,33,10,2,268,10,32,43,42,260,299,33,257,32,33,270]

theorem envBound39679 : H12AffineFastState.Bounded env39679 := by
  intro p hp
  have h : env39679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39678_39679 : H12AffineEnvironment.transform 3 11 env39678 = env39679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39678 == env39679) = true)

def leafEnv39679 : List Nat := [2,4,8,11,32,11,8,256,271,47,32,43,268,33,1,263,42,260,46,0,261,33,10,2,298,268,1,10,32,43,42,260,299,33,257,32,5,263,33,270,1,261,0]

def active39679 : List Nat := [0,1,2,4,7]

def tree39679 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39679 : H12WitnessSearch.Good tree39679 := H12GlobalWitnessIndex.good

theorem leafIdentity39679 : H12AffineFastState.composeSystem env39679 rootObs = leafEnv39679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39679 rootObs == leafEnv39679) = true)

theorem terminalChecked39679 : H12PackedTerminal.terminalCheckFast leafEnv39679 active39679 tree39679 = true := by decide +kernel

def env39680 : List Nat := [2,4,8,16,32,16,8,256,277,53,32,48,268,32,1,263,48,260,52,0,261,33,17,2,268,17,32,49,49,260,305,33,257,32,32,276]

theorem envBound39680 : H12AffineFastState.Bounded env39680 := by
  intro p hp
  have h : env39680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39677_39680 : H12AffineEnvironment.transform 8 277 env39677 = env39680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env39677 == env39680) = true)

def env39681 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,268,1044,1,263,1028,1573,1025,0,260,33,17,2,268,17,1793,1029,48,1573,1284,33,257,32,1044,513]

theorem envBound39681 : H12AffineFastState.Bounded env39681 := by
  intro p hp
  have h : env39681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39675_39681 : H12AffineEnvironment.transform 10 1793 env39675 = env39681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env39675 == env39681) = true)

theorem identity39681 : scanCanonicalize (H12AffineFastState.compose env39681 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound39681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39682 : List Nat := [2,4,8,16,32,16,8,256,48,1024,1329,49,268,1044,1,263,1028,1045,1025,0,260,33,17,2,268,17,1329,1029,48,1045,1284,33,257,32,1044,49]

theorem envBound39682 : H12AffineFastState.Bounded env39682 := by
  intro p hp
  have h : env39682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39681_39682 : H12AffineEnvironment.transform 8 48 env39681 = env39682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39681 == env39682) = true)

def env39683 : List Nat := [2,4,8,16,32,16,8,256,48,52,261,49,268,32,1,263,48,33,53,0,260,33,17,2,268,17,261,49,48,33,304,33,257,32,32,49]

theorem envBound39683 : H12AffineFastState.Bounded env39683 := by
  intro p hp
  have h : env39683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39682_39683 : H12AffineEnvironment.transform 9 52 env39682 = env39683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39682 == env39683) = true)

theorem identity39683 : scanCanonicalize (H12AffineFastState.compose env39683 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound39683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39684 : List Nat := [2,4,8,16,32,16,8,62,48,52,59,49,50,32,1,57,48,33,53,0,58,33,17,2,50,17,59,49,48,33,14,33,63,32,32,49]

theorem envBound39684 : H12AffineFastState.Bounded env39684 := by
  intro p hp
  have h : env39684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39683_39684 : H12AffineEnvironment.transform 7 62 env39683 = env39684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env39683 == env39684) = true)

def leafEnv39684 : List Nat := [2,4,8,16,32,16,8,62,48,52,59,49,50,32,1,57,48,33,53,0,58,33,17,2,15,50,1,17,59,49,48,33,14,33,63,32,5,57,32,49,1,58,0]

def active39684 : List Nat := [0,1,2,3,4]

def tree39684 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39684 : H12WitnessSearch.Good tree39684 := H12GlobalWitnessIndex.good

theorem leafIdentity39684 : H12AffineFastState.composeSystem env39684 rootObs = leafEnv39684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39684 rootObs == leafEnv39684) = true)

theorem terminalChecked39684 : H12PackedTerminal.terminalCheckFast leafEnv39684 active39684 tree39684 = true := by decide +kernel

def env39685 : List Nat := [2,4,8,16,32,16,8,256,48,53,260,49,268,33,1,263,49,32,52,0,260,33,17,2,268,17,260,48,48,32,305,33,257,32,33,49]

theorem envBound39685 : H12AffineFastState.Bounded env39685 := by
  intro p hp
  have h : env39685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39682_39685 : H12AffineEnvironment.transform 9 53 env39682 = env39685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39682 == env39685) = true)

def env39686 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,268,2836,1,263,2820,2340,1025,0,3588,33,17,2,268,17,2048,2821,3888,2340,1284,33,257,32,2836,513]

theorem envBound39686 : H12AffineFastState.Bounded env39686 := by
  intro p hp
  have h : env39686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39674_39686 : H12AffineEnvironment.transform 11 3889 env39674 = env39686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env39674 == env39686) = true)

def env39687 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,268,1044,1,263,1028,1572,1025,0,260,33,17,2,268,17,1792,1029,48,1572,1284,33,257,32,1044,513]

theorem envBound39687 : H12AffineFastState.Bounded env39687 := by
  intro p hp
  have h : env39687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39686_39687 : H12AffineEnvironment.transform 10 1792 env39686 = env39687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env39686 == env39687) = true)

theorem identity39687 : scanCanonicalize (H12AffineFastState.compose env39687 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound39687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39688 : List Nat := [2,4,8,16,32,16,8,256,277,1024,1045,49,268,1044,1,263,1028,1329,1025,0,260,33,17,2,268,17,1045,1029,48,1329,1284,33,257,32,1044,276]

theorem envBound39688 : H12AffineFastState.Bounded env39688 := by
  intro p hp
  have h : env39688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39687_39688 : H12AffineEnvironment.transform 8 277 env39687 = env39688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env39687 == env39688) = true)

def env39689 : List Nat := [2,4,8,16,32,16,8,256,277,52,33,49,268,32,1,263,48,261,53,0,260,33,17,2,268,17,33,49,48,261,304,33,257,32,32,276]

theorem envBound39689 : H12AffineFastState.Bounded env39689 := by
  intro p hp
  have h : env39689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39688_39689 : H12AffineEnvironment.transform 9 52 env39688 = env39689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39688 == env39689) = true)

theorem identity39689 : scanCanonicalize (H12AffineFastState.compose env39689 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39690 : List Nat := [2,4,8,11,32,11,8,256,270,47,33,42,268,32,1,263,43,261,46,0,260,33,10,2,268,10,33,42,43,261,299,33,257,32,32,271]

theorem envBound39690 : H12AffineFastState.Bounded env39690 := by
  intro p hp
  have h : env39690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39689_39690 : H12AffineEnvironment.transform 3 11 env39689 = env39690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39689 == env39690) = true)

def leafEnv39690 : List Nat := [2,4,8,11,32,11,8,256,270,47,33,42,268,32,1,263,43,261,46,0,260,33,10,2,298,268,1,10,33,42,43,261,299,33,257,32,5,263,32,271,1,260,0]

def active39690 : List Nat := [0,1,2,4,7]

def tree39690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39690 : H12WitnessSearch.Good tree39690 := H12GlobalWitnessIndex.good

theorem leafIdentity39690 : H12AffineFastState.composeSystem env39690 rootObs = leafEnv39690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39690 rootObs == leafEnv39690) = true)

theorem terminalChecked39690 : H12PackedTerminal.terminalCheckFast leafEnv39690 active39690 tree39690 = true := by decide +kernel

def env39691 : List Nat := [2,4,8,16,32,16,8,256,277,53,32,49,268,33,1,263,49,260,52,0,260,33,17,2,268,17,32,48,48,260,305,33,257,32,33,276]

theorem envBound39691 : H12AffineFastState.Bounded env39691 := by
  intro p hp
  have h : env39691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39688_39691 : H12AffineEnvironment.transform 9 53 env39688 = env39691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39688 == env39691) = true)

def env39692 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,268,1045,1,263,1029,1573,1025,0,261,33,17,2,268,17,1793,1028,49,1573,1284,33,257,32,1045,513]

theorem envBound39692 : H12AffineFastState.Bounded env39692 := by
  intro p hp
  have h : env39692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39686_39692 : H12AffineEnvironment.transform 10 1793 env39686 = env39692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env39686 == env39692) = true)

theorem identity39692 : scanCanonicalize (H12AffineFastState.compose env39692 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound39692 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39693 : List Nat := [2,4,8,16,32,16,8,256,512,517,260,48,268,528,1,263,512,32,516,0,261,33,17,2,268,17,260,513,49,32,769,33,257,32,528,513]

theorem envBound39693 : H12AffineFastState.Bounded env39693 := by
  intro p hp
  have h : env39693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39692_39693 : H12AffineEnvironment.transform 9 517 env39692 = env39693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env39692 == env39693) = true)

def env39694 : List Nat := [2,4,8,16,32,16,8,256,48,53,260,48,268,32,1,263,48,32,52,0,261,33,17,2,268,17,260,49,49,32,305,33,257,32,32,49]

theorem envBound39694 : H12AffineFastState.Bounded env39694 := by
  intro p hp
  have h : env39694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39693_39694 : H12AffineEnvironment.transform 8 48 env39693 = env39694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env39693 == env39694) = true)

def env39695 : List Nat := [2,4,8,16,32,16,8,256,49,52,260,48,268,33,1,263,49,32,53,0,261,33,17,2,268,17,260,48,49,32,304,33,257,32,33,48]

theorem envBound39695 : H12AffineFastState.Bounded env39695 := by
  intro p hp
  have h : env39695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39693_39695 : H12AffineEnvironment.transform 8 49 env39693 = env39695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env39693 == env39695) = true)

theorem identity39695 : scanCanonicalize (H12AffineFastState.compose env39695 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound39695 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39696 : List Nat := [2,4,8,16,32,16,8,62,49,52,58,48,50,33,1,57,49,32,53,0,59,33,17,2,50,17,58,48,49,32,14,33,63,32,33,48]

theorem envBound39696 : H12AffineFastState.Bounded env39696 := by
  intro p hp
  have h : env39696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39695_39696 : H12AffineEnvironment.transform 7 62 env39695 = env39696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env39695 == env39696) = true)

def leafEnv39696 : List Nat := [2,4,8,16,32,16,8,62,49,52,58,48,50,33,1,57,49,32,53,0,59,33,17,2,15,50,1,17,58,48,49,32,14,33,63,32,5,57,33,48,1,59,0]

def active39696 : List Nat := [0,1,2,3,4]

def tree39696 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39696 : H12WitnessSearch.Good tree39696 := H12GlobalWitnessIndex.good

theorem leafIdentity39696 : H12AffineFastState.composeSystem env39696 rootObs = leafEnv39696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39696 rootObs == leafEnv39696) = true)

theorem terminalChecked39696 : H12PackedTerminal.terminalCheckFast leafEnv39696 active39696 tree39696 = true := by decide +kernel

def env39697 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,4194304,147457,188702,8192,16,4409655,2319643,2233600,43049,75022,6521862,257,2188602,2196503,513]

theorem envBound39697 : H12AffineFastState.Bounded env39697 := by
  intro p hp
  have h : env39697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39666_39697 : H12AffineEnvironment.transform 5 17 env39666 = env39697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39666 == env39697) = true)

theorem identity39697 : scanCanonicalize (H12AffineFastState.compose env39697 (packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 2270253) := by decide +kernel

theorem selectedBound39697 : packedSelected [1,2,6,8,12,14,15,18,19,20] rootPS < 2^1333 := by decide +kernel

def env39698 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2270253,147457,188702,8192,16,2223386,2319643,2233600,43049,75022,73771,257,2188602,2196503,513]

theorem envBound39698 : H12AffineFastState.Bounded env39698 := by
  intro p hp
  have h : env39698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39697_39698 : H12AffineEnvironment.transform 21 2270253 env39697 = env39698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2270253 env39697 == env39698) = true)

theorem identity39698 : scanCanonicalize (H12AffineFastState.compose env39698 (packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound39698 : packedSelected [0,4,7,9,10,11,12,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39699 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,115735,221242,147457,188702,8192,16,10509,172300,250135,43049,75022,73771,257,41261,16384,513]

theorem envBound39699 : H12AffineFastState.Bounded env39699 := by
  intro p hp
  have h : env39699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39698_39699 : H12AffineEnvironment.transform 20 115735 env39698 = env39699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env39698 == env39699) = true)

theorem identity39699 : scanCanonicalize (H12AffineFastState.compose env39699 (packedSelected [0,1,4,7,8,9,10,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound39699 : packedSelected [0,1,4,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env39700 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10280,1025,8460,91418,221242,147457,147475,8192,16,10509,131073,225306,2340,75022,73771,257,32,16384,513]

theorem envBound39700 : H12AffineFastState.Bounded env39700 := by
  intro p hp
  have h : env39700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39699_39700 : H12AffineEnvironment.transform 14 8461 env39699 = env39700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env39699 == env39700) = true)

theorem identity39700 : scanCanonicalize (H12AffineFastState.compose env39700 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound39700 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39701 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,65536,90138,10280,1025,8460,91418,32,73755,73737,8192,16,10509,90139,4096,2340,75022,73771,257,32,16384,513]

theorem envBound39701 : H12AffineFastState.Bounded env39701 := by
  intro p hp
  have h : env39701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39700_39701 : H12AffineEnvironment.transform 16 90138 env39700 = env39701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env39700 == env39701) = true)

theorem identity39701 : scanCanonicalize (H12AffineFastState.compose env39701 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound39701 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39702 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,262,24860,10280,1025,8460,25628,32,8477,8463,8192,16,10509,24861,4096,2340,9224,8493,257,32,16384,513]

theorem envBound39702 : H12AffineFastState.Bounded env39702 := by
  intro p hp
  have h : env39702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39701_39702 : H12AffineEnvironment.transform 15 262 env39701 = env39702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env39701 == env39702) = true)

theorem identity39702 : scanCanonicalize (H12AffineFastState.compose env39702 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39702 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39703 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1025,1,17681,32,16,2,269,16,2048,16400,4096,2340,1285,32,257,32,16384,513]

theorem envBound39703 : H12AffineFastState.Bounded env39703 := by
  intro p hp
  have h : env39703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39702_39703 : H12AffineEnvironment.transform 12 269 env39702 = env39703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39702 == env39703) = true)

theorem identity39703 : scanCanonicalize (H12AffineFastState.compose env39703 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound39703 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39704 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,4144,0,262,4129,2341,1025,1,5409,32,16,2,269,16,2048,4128,4096,2340,1285,32,257,32,4144,513]

theorem envBound39704 : H12AffineFastState.Bounded env39704 := by
  intro p hp
  have h : env39704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39703_39704 : H12AffineEnvironment.transform 13 4144 env39703 = env39704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env39703 == env39704) = true)

theorem identity39704 : scanCanonicalize (H12AffineFastState.compose env39704 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3631) := by decide +kernel

theorem selectedBound39704 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39705 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3631,269,3615,0,262,3598,2341,1025,1,2830,32,16,2,269,16,2048,3599,3631,2340,1285,32,257,32,3615,513]

theorem envBound39705 : H12AffineFastState.Bounded env39705 := by
  intro p hp
  have h : env39705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39704_39705 : H12AffineEnvironment.transform 11 3631 env39704 = env39705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3631 env39704 == env39705) = true)

theorem identity39705 : scanCanonicalize (H12AffineFastState.compose env39705 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39705 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39706 : List Nat := [2,4,8,16,10,17,8,256,512,1024,2048,3589,269,3615,0,262,3598,2319,1025,1,2830,10,16,2,269,16,2048,3599,3589,2318,1285,10,257,10,3615,513]

theorem envBound39706 : H12AffineFastState.Bounded env39706 := by
  intro p hp
  have h : env39706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39705_39706 : H12AffineEnvironment.transform 4 10 env39705 = env39706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39705 == env39706) = true)

theorem identity39706 : scanCanonicalize (H12AffineFastState.compose env39706 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound39706 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39707 : List Nat := [2,4,8,16,10,17,8,256,512,516,2048,2049,269,2075,0,262,2058,2319,517,1,2830,10,16,2,269,16,2048,2059,2049,2318,769,10,257,10,2075,513]

theorem envBound39707 : H12AffineFastState.Bounded env39707 := by
  intro p hp
  have h : env39707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39706_39707 : H12AffineEnvironment.transform 9 516 env39706 = env39707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env39706 == env39707) = true)

theorem identity39707 : scanCanonicalize (H12AffineFastState.compose env39707 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound39707 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39708 : List Nat := [2,4,8,16,10,17,8,256,512,516,270,271,269,277,0,262,260,1,517,1,512,10,16,2,269,16,270,261,271,0,769,10,257,10,277,513]

theorem envBound39708 : H12AffineFastState.Bounded env39708 := by
  intro p hp
  have h : env39708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39707_39708 : H12AffineEnvironment.transform 10 270 env39707 = env39708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env39707 == env39708) = true)

theorem identity39708 : scanCanonicalize (H12AffineFastState.compose env39708 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound39708 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39709 : List Nat := [2,4,8,16,10,17,8,21,512,516,27,26,24,0,0,19,17,1,517,1,512,10,16,2,24,16,27,16,26,0,532,10,20,10,0,513]

theorem envBound39709 : H12AffineFastState.Bounded env39709 := by
  intro p hp
  have h : env39709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39708_39709 : H12AffineEnvironment.transform 7 21 env39708 = env39709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env39708 == env39709) = true)

theorem identity39709 : scanCanonicalize (H12AffineFastState.compose env39709 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39709 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env39710 : List Nat := [2,4,8,1,10,0,8,4,512,516,10,11,9,0,0,2,0,1,517,1,512,10,1,2,9,1,10,1,11,0,517,10,5,10,0,513]

theorem envBound39710 : H12AffineFastState.Bounded env39710 := by
  intro p hp
  have h : env39710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39709_39710 : H12AffineEnvironment.transform 3 1 env39709 = env39710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39709 == env39710) = true)

theorem identity39710 : scanCanonicalize (H12AffineFastState.compose env39710 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39710 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39711 : List Nat := [2,3,8,1,10,0,8,3,512,515,10,11,9,0,0,2,0,1,514,1,512,10,1,2,9,1,10,1,11,0,514,10,2,10,0,513]

theorem envBound39711 : H12AffineFastState.Bounded env39711 := by
  intro p hp
  have h : env39711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39710_39711 : H12AffineEnvironment.transform 1 3 env39710 = env39711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39710 == env39711) = true)

def env39712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,2097152,4194304,8388608,16777216,8193,65,29616169,18973700,10507600,8579113,25265169,23160136,257,27378724,27337992,25207630]

theorem envBound39712 : H12AffineFastState.Bounded env39712 := by
  intro p hp
  have h : env39712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39560_39712 : H12AffineEnvironment.transform 6 9 env39560 = env39712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39560 == env39712) = true)

theorem identity39712 : scanCanonicalize (H12AffineFastState.compose env39712 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound39712 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env39713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,4194304,8388608,16777216,8193,65,29575540,18949465,10507600,8538484,25240908,23160136,257,27354489,27337992,25166355]

theorem envBound39713 : H12AffineFastState.Bounded env39713 := by
  intro p hp
  have h : env39713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39712_39713 : H12AffineEnvironment.transform 14 8541 env39712 = env39713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env39712 == env39713) = true)

theorem identity39713 : scanCanonicalize (H12AffineFastState.compose env39713 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 8609801) := by decide +kernel

theorem selectedBound39713 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env39714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,4194304,8388608,8609801,8193,65,4204925,10634576,10507600,8538484,148805,14812481,257,2229616,2245889,221722]

theorem envBound39714 : H12AffineFastState.Bounded env39714 := by
  intro p hp
  have h : env39714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39713_39714 : H12AffineEnvironment.transform 23 8609801 env39713 = env39714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8609801 env39713 == env39714) = true)

theorem identity39714 : scanCanonicalize (H12AffineFastState.compose env39714 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 4415531) := by decide +kernel

theorem selectedBound39714 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env39715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,2097152,4194304,4415531,4194338,8193,65,4204925,6366587,6501755,4270431,148805,2188650,257,2229616,2245889,221722]

theorem envBound39715 : H12AffineFastState.Bounded env39715 := by
  intro p hp
  have h : env39715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39714_39715 : H12AffineEnvironment.transform 22 4415531 env39714 = env39715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415531 env39714 == env39715) = true)

theorem identity39715 : scanCanonicalize (H12AffineFastState.compose env39715 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound39715 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10281,1025,8540,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6313312,4270431,75102,2188650,257,2188651,2172186,513]

theorem envBound39716 : H12AffineFastState.Bounded env39716 := by
  intro p hp
  have h : env39716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39715_39716 : H12AffineEnvironment.transform 16 90139 env39715 = env39716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env39715 == env39716) = true)

theorem identity39716 : scanCanonicalize (H12AffineFastState.compose env39716 (packedSelected [2,4,6,9,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 3173) := by decide +kernel

theorem selectedBound39716 : packedSelected [2,4,6,9,17,18] rootPS < 2^1333 := by decide +kernel

def env39717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8541,65536,76926,10281,1025,8540,2097152,4194304,4194352,4194338,8193,65,4204925,6366587,6297861,4270431,75102,2173199,257,2173198,2172186,513]

theorem envBound39717 : H12AffineFastState.Bounded env39717 := by
  intro p hp
  have h : env39717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39716_39717 : H12AffineEnvironment.transform 13 3173 env39716 = env39717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3173 env39716 == env39717) = true)

theorem identity39717 : scanCanonicalize (H12AffineFastState.compose env39717 (packedSelected [3,5,10,11,12,14,15,20] rootPS)) = affineNative (2^(20+1) ^^^ 79194) := by decide +kernel

theorem selectedBound39717 : packedSelected [3,5,10,11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env39718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8541,65536,76926,10281,1025,8540,79194,4194304,4194352,4194338,8193,65,4204925,4198433,4271199,4270431,75102,7253,257,7252,4160,513]

theorem envBound39718 : H12AffineFastState.Bounded env39718 := by
  intro p hp
  have h : env39718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39717_39718 : H12AffineEnvironment.transform 20 79194 env39717 = env39718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79194 env39717 == env39718) = true)

theorem identity39718 : scanCanonicalize (H12AffineFastState.compose env39718 (packedSelected [2,6,7,17,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 15704) := by decide +kernel

theorem selectedBound39718 : packedSelected [2,6,7,17,23,27] rootPS < 2^1333 := by decide +kernel

def env39719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8541,65536,76926,10281,1025,8540,79194,15704,15720,15738,8193,65,5157,11641,69895,70663,75102,7253,257,7252,4160,513]

theorem envBound39719 : H12AffineFastState.Bounded env39719 := by
  intro p hp
  have h : env39719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39718_39719 : H12AffineEnvironment.transform 21 15704 env39718 = env39719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 15704 env39718 == env39719) = true)

theorem identity39719 : scanCanonicalize (H12AffineFastState.compose env39719 (packedSelected [5,7,8,9,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 7538) := by decide +kernel

theorem selectedBound39719 : packedSelected [5,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,3173,8541,7538,12556,10281,1025,8540,10280,15704,15720,15738,8193,65,5157,11641,3189,2421,14380,7253,257,7252,4160,513]

theorem envBound39720 : H12AffineFastState.Bounded env39720 := by
  intro p hp
  have h : env39720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39719_39720 : H12AffineEnvironment.transform 15 7538 env39719 = env39720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7538 env39719 == env39720) = true)

theorem identity39720 : scanCanonicalize (H12AffineFastState.compose env39720 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39720 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,3173,81,7538,4096,2341,1025,80,2340,7252,7268,7286,269,65,5157,3189,3189,2421,6432,7253,257,7252,4160,513]

theorem envBound39721 : H12AffineFastState.Bounded env39721 := by
  intro p hp
  have h : env39721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39720_39721 : H12AffineEnvironment.transform 12 268 env39720 = env39721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39720 == env39721) = true)

theorem identity39721 : scanCanonicalize (H12AffineFastState.compose env39721 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound39721 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2065,268,3173,81,1379,2065,2341,1025,80,2340,1093,1141,1127,269,65,3124,3189,3189,2421,305,1092,257,1093,2129,513]

theorem envBound39722 : H12AffineFastState.Bounded env39722 := by
  intro p hp
  have h : env39722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39721_39722 : H12AffineEnvironment.transform 11 2065 env39721 = env39722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env39721 == env39722) = true)

theorem identity39722 : scanCanonicalize (H12AffineFastState.compose env39722 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39722 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39723 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,268,3124,0,1330,2065,2341,1025,1,2340,1044,1060,1078,269,16,3124,3108,3108,2340,305,1045,257,1044,2048,513]

theorem envBound39723 : H12AffineFastState.Bounded env39723 := by
  intro p hp
  have h : env39723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39722_39723 : H12AffineEnvironment.transform 5 17 env39722 = env39723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39722 == env39723) = true)

theorem identity39723 : scanCanonicalize (H12AffineFastState.compose env39723 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39723 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39724 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,2065,268,2049,0,263,2065,2341,52,1,2340,33,17,3,269,16,2049,2065,2065,2340,305,32,257,33,2048,513]

theorem envBound39724 : H12AffineFastState.Bounded env39724 := by
  intro p hp
  have h : env39724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39723_39724 : H12AffineEnvironment.transform 9 53 env39723 = env39724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39723 == env39724) = true)

theorem identity39724 : scanCanonicalize (H12AffineFastState.compose env39724 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39724 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39725 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2065,41,2049,0,34,2065,2048,52,1,2049,33,17,3,40,16,2049,2065,2065,2049,20,32,36,33,2048,513]

theorem envBound39725 : H12AffineFastState.Bounded env39725 := by
  intro p hp
  have h : env39725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39724_39725 : H12AffineEnvironment.transform 7 37 env39724 = env39725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39724 == env39725) = true)

theorem identity39725 : scanCanonicalize (H12AffineFastState.compose env39725 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39726 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,41,49,0,34,33,48,52,1,49,33,17,3,40,16,49,33,33,49,20,32,36,33,48,513]

theorem envBound39726 : H12AffineFastState.Bounded env39726 := by
  intro p hp
  have h : env39726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39725_39726 : H12AffineEnvironment.transform 10 48 env39725 = env39726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39725 == env39726) = true)

def leafEnv39726 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,33,41,49,0,34,33,48,52,1,49,33,17,3,21,40,1,16,49,33,33,49,20,32,36,33,5,35,48,513,1,48,0]

def active39726 : List Nat := [0,1,2,3,4,8]

def tree39726 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39726 : H12WitnessSearch.Good tree39726 := H12GlobalWitnessIndex.good

theorem leafIdentity39726 : H12AffineFastState.composeSystem env39726 rootObs = leafEnv39726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39726 rootObs == leafEnv39726) = true)

theorem terminalChecked39726 : H12PackedTerminal.terminalCheckFast leafEnv39726 active39726 tree39726 = true := by decide +kernel

def env39727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616401,155254785,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound39727 : H12AffineFastState.Bounded env39727 := by
  intro p hp
  have h : env39727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37894_39727 : H12AffineEnvironment.transform 29 155254785 env37894 = env39727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env37894 == env39727) = true)

def env39728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507601,155254785,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound39728 : H12AffineFastState.Bounded env39728 := by
  intro p hp
  have h : env39728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39727_39728 : H12AffineEnvironment.transform 25 64 env39727 = env39728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env39727 == env39728) = true)

def env39729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507601,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound39729 : H12AffineFastState.Bounded env39729 := by
  intro p hp
  have h : env39729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39728_39729 : H12AffineEnvironment.transform 26 30393344 env39728 = env39729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env39728 == env39729) = true)

def env39730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound39730 : H12AffineFastState.Bounded env39730 := by
  intro p hp
  have h : env39730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39729_39730 : H12AffineEnvironment.transform 18 1024 env39729 = env39730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env39729 == env39730) = true)

theorem identity39730 : scanCanonicalize (H12AffineFastState.compose env39730 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10577360) := by decide +kernel

theorem selectedBound39730 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10577360,8328,64,6727120,8446300,10507601,8830977,2154944,12582928,256,41341,16600,2213398]

theorem envBound39731 : H12AffineFastState.Bounded env39731 := by
  intro p hp
  have h : env39731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39730_39731 : H12AffineEnvironment.transform 23 10577360 env39730 = env39731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10577360 env39730 == env39731) = true)

def env39732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,8388608,10577360,8328,64,6705548,8393984,10507601,8795229,2102684,12582928,256,21793,16600,2175562]

theorem envBound39732 : H12AffineFastState.Bounded env39732 := by
  intro p hp
  have h : env39732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39731_39732 : H12AffineEnvironment.transform 14 29788 env39731 = env39732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env39731 == env39732) = true)

def env39733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114896,73856,8328,64,6705548,2117712,4097,2519309,2102684,6309184,256,21793,16600,2175562]

theorem envBound39733 : H12AffineFastState.Bounded env39733 := by
  intro p hp
  have h : env39733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39732_39733 : H12AffineEnvironment.transform 22 2114896 env39732 = env39733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env39732 == env39733) = true)

def env39734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,16,73856,8328,64,4592844,5392,4097,406605,20700,4194304,256,21793,16600,96010]

theorem envBound39734 : H12AffineFastState.Bounded env39734 := by
  intro p hp
  have h : env39734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39733_39734 : H12AffineEnvironment.transform 20 17728 env39733 = env39734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env39733 == env39734) = true)

theorem identity39734 : scanCanonicalize (H12AffineFastState.compose env39734 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound39734 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,30083,131072,262144,1024,29789,17728,4194304,16,21763,8328,64,4592844,5392,4097,406605,20700,4194304,256,21793,16600,649]

theorem envBound39735 : H12AffineFastState.Bounded env39735 := by
  intro p hp
  have h : env39735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39734_39735 : H12AffineEnvironment.transform 15 30083 env39734 = env39735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env39734 == env39735) = true)

def env39736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8323,131072,262144,1024,8541,4160,4194304,16,3,8328,64,4592844,5392,4097,406605,1500,4194304,256,33,5592,649]

theorem envBound39736 : H12AffineFastState.Bounded env39736 := by
  intro p hp
  have h : env39736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39735_39736 : H12AffineEnvironment.transform 13 5376 env39735 = env39736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39735 == env39736) = true)

theorem identity39736 : scanCanonicalize (H12AffineFastState.compose env39736 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39736 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,4194304,16,3,8192,64,4592708,5392,4097,406605,1364,4194304,256,33,5456,513]

theorem envBound39737 : H12AffineFastState.Bounded env39737 := by
  intro p hp
  have h : env39737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39736_39737 : H12AffineEnvironment.transform 6 8 env39736 = env39737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39736 == env39737) = true)

theorem identity39737 : scanCanonicalize (H12AffineFastState.compose env39737 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound39737 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,262144,1024,8541,4160,8492,16,3,8192,64,406888,5392,4097,406605,1364,8492,256,33,5456,513]

theorem envBound39738 : H12AffineFastState.Bounded env39738 := by
  intro p hp
  have h : env39738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39737_39738 : H12AffineEnvironment.transform 21 8492 env39737 = env39738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env39737 == env39738) = true)

theorem identity39738 : scanCanonicalize (H12AffineFastState.compose env39738 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound39738 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env39739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,131072,2420,1024,8541,4160,8492,16,3,8192,64,146460,5392,4097,146745,1364,8492,256,33,5456,513]

theorem envBound39739 : H12AffineFastState.Bounded env39739 := by
  intro p hp
  have h : env39739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39738_39739 : H12AffineEnvironment.transform 17 2420 env39738 = env39739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env39738 == env39739) = true)

theorem identity39739 : scanCanonicalize (H12AffineFastState.compose env39739 (packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39739 : packedSelected [0,1,3,4,5,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,131072,2420,1024,0,4160,113,16,3,349,64,138561,5392,4097,138340,1364,113,256,33,5456,513]

theorem envBound39740 : H12AffineFastState.Bounded env39740 := by
  intro p hp
  have h : env39740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39739_39740 : H12AffineEnvironment.transform 12 349 env39739 = env39740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39739 == env39740) = true)

theorem identity39740 : scanCanonicalize (H12AffineFastState.compose env39740 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39740 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,342,5393,2420,1024,0,4160,113,16,3,349,64,2128,5392,4097,2421,1364,113,256,33,5456,513]

theorem envBound39741 : H12AffineFastState.Bounded env39741 := by
  intro p hp
  have h : env39741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39740_39741 : H12AffineEnvironment.transform 16 5393 env39740 = env39741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39740 == env39741) = true)

theorem identity39741 : scanCanonicalize (H12AffineFastState.compose env39741 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39741 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39742 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5393,2341,1024,0,4113,32,16,3,268,17,2049,5392,4097,2340,1285,32,256,33,5377,513]

theorem envBound39742 : H12AffineFastState.Bounded env39742 := by
  intro p hp
  have h : env39742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39741_39742 : H12AffineEnvironment.transform 5 17 env39741 = env39742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39741 == env39742) = true)

theorem identity39742 : scanCanonicalize (H12AffineFastState.compose env39742 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39742 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39743 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,9,5125,1,2,5140,2080,1024,0,4113,32,16,3,9,17,2049,5141,4097,2081,1024,32,5,33,5124,513]

theorem envBound39743 : H12AffineFastState.Bounded env39743 := by
  intro p hp
  have h : env39743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39742_39743 : H12AffineEnvironment.transform 7 5 env39742 = env39743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39742 == env39743) = true)

theorem identity39743 : scanCanonicalize (H12AffineFastState.compose env39743 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39743 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39744 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,4096,9,4144,1,2,4129,2080,53,0,4113,32,16,3,9,17,2049,4128,4097,2081,53,32,5,33,4145,513]

theorem envBound39744 : H12AffineFastState.Bounded env39744 := by
  intro p hp
  have h : env39744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39743_39744 : H12AffineEnvironment.transform 9 53 env39743 = env39744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39743 == env39744) = true)

theorem identity39744 : scanCanonicalize (H12AffineFastState.compose env39744 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound39744 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39745 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2608,9,2560,1,2,2577,2080,53,0,2593,32,16,3,9,17,2049,2576,2609,2081,53,32,5,33,2561,513]

theorem envBound39745 : H12AffineFastState.Bounded env39745 := by
  intro p hp
  have h : env39745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39744_39745 : H12AffineEnvironment.transform 11 2608 env39744 = env39745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env39744 == env39745) = true)

theorem identity39745 : scanCanonicalize (H12AffineFastState.compose env39745 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39746 : List Nat := [2,4,8,16,32,17,8,5,1,53,2048,2097,9,2049,1,2,2064,2080,53,0,2080,32,16,3,9,17,2049,2065,2096,2081,53,32,5,33,2048,0]

theorem envBound39746 : H12AffineFastState.Bounded env39746 := by
  intro p hp
  have h : env39746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39745_39746 : H12AffineEnvironment.transform 8 1 env39745 = env39746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39745 == env39746) = true)

theorem identity39746 : scanCanonicalize (H12AffineFastState.compose env39746 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39746 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39747 : List Nat := [2,4,8,16,32,17,8,5,1,53,49,0,9,48,1,2,33,17,53,0,17,32,16,3,9,17,48,32,1,16,53,32,5,33,49,0]

theorem envBound39747 : H12AffineFastState.Bounded env39747 := by
  intro p hp
  have h : env39747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39746_39747 : H12AffineEnvironment.transform 10 49 env39746 = env39747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39746 == env39747) = true)

theorem identity39747 : scanCanonicalize (H12AffineFastState.compose env39747 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39747 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39748 : List Nat := [2,4,8,16,1,17,8,5,1,20,16,0,9,17,1,2,0,17,20,0,17,1,16,3,9,17,17,1,1,16,20,1,5,0,16,0]

theorem envBound39748 : H12AffineFastState.Bounded env39748 := by
  intro p hp
  have h : env39748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39747_39748 : H12AffineEnvironment.transform 4 1 env39747 = env39748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39747 == env39748) = true)

theorem identity39748 : scanCanonicalize (H12AffineFastState.compose env39748 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound39748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39749 : List Nat := [2,4,8,0,1,1,8,5,1,4,0,0,9,1,1,2,0,1,4,0,1,1,0,3,9,1,1,1,1,0,4,1,5,0,0,0]

theorem envBound39749 : H12AffineFastState.Bounded env39749 := by
  intro p hp
  have h : env39749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39748_39749 : H12AffineEnvironment.transform 3 0 env39748 = env39749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39748 == env39749) = true)

def env39750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,262144,1024,8540,4161,4194304,16,2,8328,64,4592844,5392,4097,406605,1501,4194304,256,32,5593,649]

theorem envBound39750 : H12AffineFastState.Bounded env39750 := by
  intro p hp
  have h : env39750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39735_39750 : H12AffineEnvironment.transform 13 5377 env39735 = env39750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39735 == env39750) = true)

theorem identity39750 : scanCanonicalize (H12AffineFastState.compose env39750 (packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound39750 : packedSelected [0,3,9,10,12,14,15,22,24,26,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env39751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,10401,1024,8540,4161,4194304,16,2,8328,64,4340845,5392,4097,138476,1501,4194304,256,32,5593,649]

theorem envBound39751 : H12AffineFastState.Bounded env39751 := by
  intro p hp
  have h : env39751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39750_39751 : H12AffineEnvironment.transform 17 10401 env39750 = env39751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env39750 == env39751) = true)

theorem identity39751 : scanCanonicalize (H12AffineFastState.compose env39751 (packedSelected [4,9,11,14,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 8692) := by decide +kernel

theorem selectedBound39751 : packedSelected [4,9,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env39752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,131072,10401,1024,8540,4161,8692,16,2,8328,64,138649,5392,4097,138476,1501,8692,256,32,5593,649]

theorem envBound39752 : H12AffineFastState.Bounded env39752 := by
  intro p hp
  have h : env39752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39751_39752 : H12AffineEnvironment.transform 21 8692 env39751 = env39752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8692 env39751 == env39752) = true)

theorem identity39752 : scanCanonicalize (H12AffineFastState.compose env39752 (packedSelected [2,6,9,11,14,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound39752 : packedSelected [2,6,9,11,14,22,23] rootPS < 2^1333 := by decide +kernel

def env39753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8322,5392,10401,1024,8540,4161,8692,16,2,8328,64,2185,5392,4097,2556,1501,8692,256,32,5593,649]

theorem envBound39753 : H12AffineFastState.Bounded env39753 := by
  intro p hp
  have h : env39753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39752_39753 : H12AffineEnvironment.transform 16 5392 env39752 = env39753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39752 == env39753) = true)

theorem identity39753 : scanCanonicalize (H12AffineFastState.compose env39753 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39753 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env39754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,0,479,5392,2556,1024,1,4161,169,16,2,469,64,2185,5392,4097,2556,1501,169,256,32,5593,649]

theorem envBound39754 : H12AffineFastState.Bounded env39754 := by
  intro p hp
  have h : env39754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39753_39754 : H12AffineEnvironment.transform 12 349 env39753 = env39754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39753 == env39754) = true)

theorem identity39754 : scanCanonicalize (H12AffineFastState.compose env39754 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39754 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39755 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,0,399,5392,2476,1024,1,4113,169,16,2,389,16,2185,5392,4097,2476,1421,169,256,32,5513,649]

theorem envBound39755 : H12AffineFastState.Bounded env39755 := by
  intro p hp
  have h : env39755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39754_39755 : H12AffineEnvironment.transform 5 16 env39754 = env39755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39754 == env39755) = true)

theorem identity39755 : scanCanonicalize (H12AffineFastState.compose env39755 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound39755 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env39756 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1808,4096,269,5377,0,399,5392,1724,1024,1,4113,169,16,2,389,16,1945,5392,4097,1724,1421,169,256,32,5513,649]

theorem envBound39756 : H12AffineFastState.Bounded env39756 := by
  intro p hp
  have h : env39756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39755_39756 : H12AffineEnvironment.transform 10 1808 env39755 = env39756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env39755 == env39756) = true)

theorem identity39756 : scanCanonicalize (H12AffineFastState.compose env39756 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39756 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env39757 : List Nat := [2,4,8,1,32,1,128,256,512,1024,1793,4096,269,5377,0,399,5377,1709,1024,1,4096,169,1,2,389,1,1928,5377,4097,1709,1421,169,256,32,5513,649]

theorem envBound39757 : H12AffineFastState.Bounded env39757 := by
  intro p hp
  have h : env39757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39756_39757 : H12AffineEnvironment.transform 3 1 env39756 = env39757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39756 == env39757) = true)

theorem identity39757 : scanCanonicalize (H12AffineFastState.compose env39757 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound39757 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env39758 : List Nat := [2,4,8,1,32,1,128,256,512,1024,1793,0,269,1281,0,399,1281,1709,1024,1,0,169,1,2,389,1,1928,1281,1,1709,1421,169,256,32,1417,649]

theorem envBound39758 : H12AffineFastState.Bounded env39758 := by
  intro p hp
  have h : env39758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39757_39758 : H12AffineEnvironment.transform 11 0 env39757 = env39758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39757 == env39758) = true)

theorem identity39758 : scanCanonicalize (H12AffineFastState.compose env39758 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39758 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env39759 : List Nat := [2,4,8,1,0,1,128,256,512,1024,1793,0,269,1281,0,399,1281,1677,1024,1,0,137,1,2,389,1,1928,1281,1,1677,1421,137,256,0,1417,649]

theorem envBound39759 : H12AffineFastState.Bounded env39759 := by
  intro p hp
  have h : env39759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39758_39759 : H12AffineEnvironment.transform 4 0 env39758 = env39759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39758 == env39759) = true)

theorem identity39759 : scanCanonicalize (H12AffineFastState.compose env39759 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 136) := by decide +kernel

theorem selectedBound39759 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39760 : List Nat := [2,4,8,1,0,1,128,136,512,1024,1673,0,133,1161,0,7,1161,1677,1024,1,0,137,1,2,13,1,1536,1161,1,1677,1029,137,136,0,1025,649]

theorem envBound39760 : H12AffineFastState.Bounded env39760 := by
  intro p hp
  have h : env39760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39759_39760 : H12AffineEnvironment.transform 7 136 env39759 = env39760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 136 env39759 == env39760) = true)

def env39761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,17,73856,8328,64,4592845,5393,4097,406604,20701,4194305,256,21793,16600,96011]

theorem envBound39761 : H12AffineFastState.Bounded env39761 := by
  intro p hp
  have h : env39761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39733_39761 : H12AffineEnvironment.transform 20 17729 env39733 = env39761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env39733 == env39761) = true)

theorem identity39761 : scanCanonicalize (H12AffineFastState.compose env39761 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound39761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,95650,17,73856,8328,64,483695,5393,4097,406604,20701,95651,256,21793,16600,96011]

theorem envBound39762 : H12AffineFastState.Bounded env39762 := by
  intro p hp
  have h : env39762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39761_39762 : H12AffineEnvironment.transform 21 95650 env39761 = env39762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env39761 == env39762) = true)

theorem identity39762 : scanCanonicalize (H12AffineFastState.compose env39762 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound39762 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env39763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,5392,262144,1024,29789,17729,95650,17,73856,8328,64,357503,5393,4097,270684,20701,95651,256,21793,16600,96011]

theorem envBound39763 : H12AffineFastState.Bounded env39763 := by
  intro p hp
  have h : env39763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39762_39763 : H12AffineEnvironment.transform 16 5392 env39762 = env39763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39762 == env39763) = true)

theorem identity39763 : scanCanonicalize (H12AffineFastState.compose env39763 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39763 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,29962,5392,262144,1024,29789,17729,168,17,21898,8328,64,262517,5393,4097,270684,20701,169,256,21793,16600,513]

theorem envBound39764 : H12AffineFastState.Bounded env39764 := by
  intro p hp
  have h : env39764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39763_39764 : H12AffineEnvironment.transform 15 29962 env39763 = env39764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39763 == env39764) = true)

theorem identity39764 : scanCanonicalize (H12AffineFastState.compose env39764 (packedSelected [11,18,21,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39764 : packedSelected [11,18,21,23,32] rootPS < 2^1333 := by decide +kernel

def env39765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,262144,1024,29789,17729,32,17,21762,8192,64,262517,5393,4097,270684,20565,33,256,21793,16464,513]

theorem envBound39765 : H12AffineFastState.Bounded env39765 := by
  intro p hp
  have h : env39765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39764_39765 : H12AffineEnvironment.transform 6 8 env39764 = env39765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39764 == env39765) = true)

theorem identity39765 : scanCanonicalize (H12AffineFastState.compose env39765 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound39765 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29962,5392,2420,1024,29789,17729,32,17,21762,8192,64,2049,5393,4097,10280,20565,33,256,21793,16464,513]

theorem envBound39766 : H12AffineFastState.Bounded env39766 := by
  intro p hp
  have h : env39766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39765_39766 : H12AffineEnvironment.transform 17 2420 env39765 = env39766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env39765 == env39766) = true)

theorem identity39766 : scanCanonicalize (H12AffineFastState.compose env39766 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39766 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5392,2420,1024,8541,4161,32,17,2,8192,64,2049,5393,4097,10280,1365,33,256,33,5456,513]

theorem envBound39767 : H12AffineFastState.Bounded env39767 := by
  intro p hp
  have h : env39767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39766_39767 : H12AffineEnvironment.transform 13 5376 env39766 = env39767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39766 == env39767) = true)

theorem identity39767 : scanCanonicalize (H12AffineFastState.compose env39767 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39767 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39768 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,8202,5392,2341,1024,8460,4112,32,17,2,8192,17,2049,5393,4097,10280,1284,33,256,33,5377,513]

theorem envBound39768 : H12AffineFastState.Bounded env39768 := by
  intro p hp
  have h : env39768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39767_39768 : H12AffineEnvironment.transform 5 17 env39767 = env39768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39767 == env39768) = true)

theorem identity39768 : scanCanonicalize (H12AffineFastState.compose env39768 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound39768 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39769 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,5376,8461,8202,5392,1296,1024,8460,4112,32,17,2,8192,17,1076,5393,4097,9245,1284,33,256,33,5377,513]

theorem envBound39769 : H12AffineFastState.Bounded env39769 := by
  intro p hp
  have h : env39769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39768_39769 : H12AffineEnvironment.transform 10 1077 env39768 = env39769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env39768 == env39769) = true)

theorem identity39769 : scanCanonicalize (H12AffineFastState.compose env39769 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound39769 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39770 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,5416,5376,5157,5410,5392,1296,1024,5156,4112,32,17,2,5416,17,1076,5393,4097,4405,1284,33,256,33,5377,513]

theorem envBound39770 : H12AffineFastState.Bounded env39770 := by
  intro p hp
  have h : env39770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39769_39770 : H12AffineEnvironment.transform 12 5416 env39769 = env39770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env39769 == env39770) = true)

theorem identity39770 : scanCanonicalize (H12AffineFastState.compose env39770 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound39770 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env39771 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,1061,269,293,0,263,309,1296,1024,1,1077,32,17,2,269,17,1076,308,1060,1296,1284,33,256,33,292,513]

theorem envBound39771 : H12AffineFastState.Bounded env39771 := by
  intro p hp
  have h : env39771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39770_39771 : H12AffineEnvironment.transform 11 1061 env39770 = env39771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env39770 == env39771) = true)

theorem identity39771 : scanCanonicalize (H12AffineFastState.compose env39771 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39771 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39772 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1044,1028,269,260,0,263,276,1296,1024,1,1044,1,17,2,269,17,1045,277,1029,1296,1284,0,256,0,261,513]

theorem envBound39772 : H12AffineFastState.Bounded env39772 := by
  intro p hp
  have h : env39772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39771_39772 : H12AffineEnvironment.transform 4 1 env39771 = env39772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39771 == env39772) = true)

theorem identity39772 : scanCanonicalize (H12AffineFastState.compose env39772 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39772 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39773 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1044,1028,8,1,0,2,17,1045,1024,1,1044,1,17,2,8,17,1045,16,1029,1045,1025,0,5,0,0,513]

theorem envBound39773 : H12AffineFastState.Bounded env39773 := by
  intro p hp
  have h : env39773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39772_39773 : H12AffineEnvironment.transform 7 5 env39772 = env39773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39772 == env39773) = true)

theorem identity39773 : scanCanonicalize (H12AffineFastState.compose env39773 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39774 : List Nat := [2,4,8,1,1,0,8,5,512,1024,1029,1028,8,1,0,2,0,1028,1024,1,1029,1,0,2,8,0,1028,1,1029,1028,1025,0,5,0,0,513]

theorem envBound39774 : H12AffineFastState.Bounded env39774 := by
  intro p hp
  have h : env39774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39773_39774 : H12AffineEnvironment.transform 3 1 env39773 = env39774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39773 == env39774) = true)

theorem identity39774 : scanCanonicalize (H12AffineFastState.compose env39774 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound39774 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39775 : List Nat := [2,4,8,1,1,0,8,5,512,516,513,512,8,1,0,2,0,512,516,1,513,1,0,2,8,0,512,1,513,512,517,0,5,0,0,513]

theorem envBound39775 : H12AffineFastState.Bounded env39775 := by
  intro p hp
  have h : env39775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39774_39775 : H12AffineEnvironment.transform 9 516 env39774 = env39775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env39774 == env39775) = true)

theorem identity39775 : scanCanonicalize (H12AffineFastState.compose env39775 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound39775 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env39776 : List Nat := [2,4,8,1,1,0,8,5,1,5,0,1,8,1,0,2,0,1,5,1,0,1,0,2,8,0,1,1,0,1,4,0,5,0,0,0]

theorem envBound39776 : H12AffineFastState.Bounded env39776 := by
  intro p hp
  have h : env39776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39775_39776 : H12AffineEnvironment.transform 8 1 env39775 = env39776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env39775 == env39776) = true)

def env39777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,2097152,4194304,2114897,73857,8328,64,6705548,2117713,4096,2519308,2102684,6309185,256,21793,16600,2175562]

theorem envBound39777 : H12AffineFastState.Bounded env39777 := by
  intro p hp
  have h : env39777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39732_39777 : H12AffineEnvironment.transform 22 2114897 env39732 = env39777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env39732 == env39777) = true)

def env39778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,4194304,17,73857,8328,64,4592844,5393,4096,406604,20700,4194305,256,21793,16600,96010]

theorem envBound39778 : H12AffineFastState.Bounded env39778 := by
  intro p hp
  have h : env39778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39777_39778 : H12AffineEnvironment.transform 20 17728 env39777 = env39778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env39777 == env39778) = true)

theorem identity39778 : scanCanonicalize (H12AffineFastState.compose env39778 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 95531) := by decide +kernel

theorem selectedBound39778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17728,95531,17,73857,8328,64,483815,5393,4096,406604,20700,95530,256,21793,16600,96010]

theorem envBound39779 : H12AffineFastState.Bounded env39779 := by
  intro p hp
  have h : env39779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39778_39779 : H12AffineEnvironment.transform 21 95531 env39778 = env39779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95531 env39778 == env39779) = true)

def env39780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,262144,1024,8541,4160,73771,17,73857,8328,64,472295,5393,4096,406604,1500,73770,256,33,5592,74250]

theorem envBound39780 : H12AffineFastState.Bounded env39780 := by
  intro p hp
  have h : env39780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39779_39780 : H12AffineEnvironment.transform 13 5376 env39779 = env39780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39779 == env39780) = true)

theorem identity39780 : scanCanonicalize (H12AffineFastState.compose env39780 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39780 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,10281,1024,8541,4160,73771,17,73857,8328,64,203982,5393,4096,138341,1500,73770,256,33,5592,74250]

theorem envBound39781 : H12AffineFastState.Bounded env39781 := by
  intro p hp
  have h : env39781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39780_39781 : H12AffineEnvironment.transform 17 10281 env39780 = env39781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39780 == env39781) = true)

theorem identity39781 : scanCanonicalize (H12AffineFastState.compose env39781 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39781 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,5393,10281,1024,8541,4160,73771,17,73857,8328,64,68063,5393,4096,2420,1500,73770,256,33,5592,74250]

theorem envBound39782 : H12AffineFastState.Bounded env39782 := by
  intro p hp
  have h : env39782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39781_39782 : H12AffineEnvironment.transform 16 5393 env39781 = env39782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39781 == env39782) = true)

theorem identity39782 : scanCanonicalize (H12AffineFastState.compose env39782 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound39782 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env39783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8323,5393,10281,1024,8541,4160,168,17,2,8328,64,10588,5393,4096,2420,1500,169,256,33,5592,649]

theorem envBound39783 : H12AffineFastState.Bounded env39783 := by
  intro p hp
  have h : env39783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39782_39783 : H12AffineEnvironment.transform 15 8323 env39782 = env39783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env39782 == env39783) = true)

theorem identity39783 : scanCanonicalize (H12AffineFastState.compose env39783 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39783 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env39784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5393,10281,1024,8541,4160,33,17,2,8193,64,10588,5393,4096,2420,1365,32,256,33,5457,512]

theorem envBound39784 : H12AffineFastState.Bounded env39784 := by
  intro p hp
  have h : env39784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39783_39784 : H12AffineEnvironment.transform 6 9 env39783 = env39784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39783 == env39784) = true)

theorem identity39784 : scanCanonicalize (H12AffineFastState.compose env39784 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound39784 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5376,113,295,5393,2308,1024,112,4160,33,17,2,300,64,2161,5393,4096,2420,1365,32,256,33,5457,512]

theorem envBound39785 : H12AffineFastState.Bounded env39785 := by
  intro p hp
  have h : env39785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39784_39785 : H12AffineEnvironment.transform 12 301 env39784 = env39785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env39784 == env39785) = true)

theorem identity39785 : scanCanonicalize (H12AffineFastState.compose env39785 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39785 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env39786 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5376,80,262,5393,2308,1024,81,4160,0,17,2,269,64,2128,5393,4096,2389,1365,1,256,0,5457,512]

theorem envBound39786 : H12AffineFastState.Bounded env39786 := by
  intro p hp
  have h : env39786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39785_39786 : H12AffineEnvironment.transform 4 1 env39785 = env39786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39785 == env39786) = true)

theorem identity39786 : scanCanonicalize (H12AffineFastState.compose env39786 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39786 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env39787 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5204,80,82,5189,2128,1024,81,4160,0,17,2,89,64,2128,5189,4096,2049,1025,1,84,0,5125,512]

theorem envBound39787 : H12AffineFastState.Bounded env39787 := by
  intro p hp
  have h : env39787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39786_39787 : H12AffineEnvironment.transform 7 84 env39786 = env39787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39786 == env39787) = true)

theorem identity39787 : scanCanonicalize (H12AffineFastState.compose env39787 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39787 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39788 : List Nat := [2,4,8,16,1,64,9,84,512,1024,1,4096,88,5204,80,82,5189,81,1024,81,4160,0,17,2,89,64,81,5189,4096,0,1025,1,84,0,5125,512]

theorem envBound39788 : H12AffineFastState.Bounded env39788 := by
  intro p hp
  have h : env39788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39787_39788 : H12AffineEnvironment.transform 10 1 env39787 = env39788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39787 == env39788) = true)

def env39789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,4161,73770,17,73857,8328,64,472294,5393,4096,406604,1501,73771,256,32,5593,74251]

theorem envBound39789 : H12AffineFastState.Bounded env39789 := by
  intro p hp
  have h : env39789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39779_39789 : H12AffineEnvironment.transform 13 5377 env39779 = env39789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39779 == env39789) = true)

theorem identity39789 : scanCanonicalize (H12AffineFastState.compose env39789 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound39789 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10401,1024,8540,4161,73770,17,73857,8328,64,203847,5393,4096,138477,1501,73771,256,32,5593,74251]

theorem envBound39790 : H12AffineFastState.Bounded env39790 := by
  intro p hp
  have h : env39790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39789_39790 : H12AffineEnvironment.transform 17 10401 env39789 = env39790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env39789 == env39790) = true)

theorem identity39790 : scanCanonicalize (H12AffineFastState.compose env39790 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39790 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env39791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10401,1024,8540,4161,32,17,139,8328,64,146509,5393,4096,138477,1501,33,256,32,5593,513]

theorem envBound39791 : H12AffineFastState.Bounded env39791 := by
  intro p hp
  have h : env39791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39790_39791 : H12AffineEnvironment.transform 15 8202 env39790 = env39791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39790 == env39791) = true)

theorem identity39791 : scanCanonicalize (H12AffineFastState.compose env39791 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound39791 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8202,13461,10401,1024,8540,4161,32,17,139,8328,64,2264,5393,4096,10360,1501,33,256,32,5593,513]

theorem envBound39792 : H12AffineFastState.Bounded env39792 := by
  intro p hp
  have h : env39792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39791_39792 : H12AffineEnvironment.transform 16 13461 env39791 = env39792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env39791 == env39792) = true)

theorem identity39792 : scanCanonicalize (H12AffineFastState.compose env39792 (packedSelected [11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39792 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env39793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,13340,10280,1024,8540,4161,32,17,2,8193,64,2129,5393,4096,10360,1364,33,256,32,5456,513]

theorem envBound39793 : H12AffineFastState.Bounded env39793 := by
  intro p hp
  have h : env39793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39792_39793 : H12AffineEnvironment.transform 6 9 env39792 = env39793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39792 == env39793) = true)

theorem identity39793 : scanCanonicalize (H12AffineFastState.compose env39793 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound39793 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,293,114,5220,2128,1024,292,4161,32,17,2,121,64,2129,5393,4096,2048,1364,33,256,32,5456,513]

theorem envBound39794 : H12AffineFastState.Bounded env39794 := by
  intro p hp
  have h : env39794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39793_39794 : H12AffineEnvironment.transform 12 120 env39793 = env39794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env39793 == env39794) = true)

theorem identity39794 : scanCanonicalize (H12AffineFastState.compose env39794 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound39794 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env39795 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,120,4453,293,114,4096,2128,100,292,4161,32,17,2,121,64,2129,4469,4096,2048,304,33,256,32,4404,513]

theorem envBound39795 : H12AffineFastState.Bounded env39795 := by
  intro p hp
  have h : env39795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39794_39795 : H12AffineEnvironment.transform 9 100 env39794 = env39795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env39794 == env39795) = true)

theorem identity39795 : scanCanonicalize (H12AffineFastState.compose env39795 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound39795 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39796 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,120,2340,293,114,2113,2128,100,292,2048,32,17,2,121,64,2129,2356,2113,2048,304,33,256,32,2421,513]

theorem envBound39796 : H12AffineFastState.Bounded env39796 := by
  intro p hp
  have h : env39796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39795_39796 : H12AffineEnvironment.transform 11 2113 env39795 = env39796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env39795 == env39796) = true)

theorem identity39796 : scanCanonicalize (H12AffineFastState.compose env39796 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound39796 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env39797 : List Nat := [2,4,8,16,32,64,9,116,512,100,2048,2113,120,2128,81,114,2113,2128,100,80,2048,32,17,2,121,64,2129,2112,2113,2048,68,33,116,32,2049,513]

theorem envBound39797 : H12AffineFastState.Bounded env39797 := by
  intro p hp
  have h : env39797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39796_39797 : H12AffineEnvironment.transform 7 116 env39796 = env39797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env39796 == env39797) = true)

theorem identity39797 : scanCanonicalize (H12AffineFastState.compose env39797 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 50) := by decide +kernel

theorem selectedBound39797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39798 : List Nat := [2,4,8,16,32,64,9,116,512,100,50,115,120,98,81,114,115,98,100,80,50,32,17,2,121,64,99,114,115,50,68,33,116,32,51,513]

theorem envBound39798 : H12AffineFastState.Bounded env39798 := by
  intro p hp
  have h : env39798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39797_39798 : H12AffineEnvironment.transform 10 50 env39797 = env39798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 50 env39797 == env39798) = true)

theorem identity39798 : scanCanonicalize (H12AffineFastState.compose env39798 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound39798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39799 : List Nat := [2,4,8,16,32,1,9,53,512,37,50,50,57,35,16,51,50,35,37,17,50,32,17,2,56,1,34,51,50,50,5,33,53,32,51,513]

theorem envBound39799 : H12AffineFastState.Bounded env39799 := by
  intro p hp
  have h : env39799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39798_39799 : H12AffineEnvironment.transform 5 1 env39798 = env39799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env39798 == env39799) = true)

theorem identity39799 : scanCanonicalize (H12AffineFastState.compose env39799 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39799 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39800 : List Nat := [2,4,2,16,32,1,3,53,512,37,50,50,51,35,16,51,50,35,37,17,50,32,17,2,50,1,34,51,50,50,5,33,53,32,51,513]

theorem envBound39800 : H12AffineFastState.Bounded env39800 := by
  intro p hp
  have h : env39800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39799_39800 : H12AffineEnvironment.transform 2 2 env39799 = env39800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39799 == env39800) = true)

theorem identity39800 : scanCanonicalize (H12AffineFastState.compose env39800 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39800 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39801 : List Nat := [2,4,2,16,0,1,3,21,512,5,18,18,19,3,16,19,18,3,5,17,18,0,17,2,18,1,2,19,18,18,5,1,21,0,19,513]

theorem envBound39801 : H12AffineFastState.Bounded env39801 := by
  intro p hp
  have h : env39801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39800_39801 : H12AffineEnvironment.transform 4 0 env39800 = env39801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39800 == env39801) = true)

theorem identity39801 : scanCanonicalize (H12AffineFastState.compose env39801 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39801 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39802 : List Nat := [2,4,2,1,0,1,3,4,512,5,3,3,2,3,1,2,3,3,5,0,3,0,0,2,3,1,2,2,3,3,5,1,4,0,2,513]

theorem envBound39802 : H12AffineFastState.Bounded env39802 := by
  intro p hp
  have h : env39802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39801_39802 : H12AffineEnvironment.transform 3 1 env39801 = env39802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39801 == env39802) = true)

theorem identity39802 : scanCanonicalize (H12AffineFastState.compose env39802 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39803 : List Nat := [2,1,2,1,0,1,3,1,512,0,3,3,2,3,1,2,3,3,0,0,3,0,0,2,3,1,2,2,3,3,0,1,1,0,2,513]

theorem envBound39803 : H12AffineFastState.Bounded env39803 := by
  intro p hp
  have h : env39803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39802_39803 : H12AffineEnvironment.transform 1 1 env39802 = env39803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39802 == env39803) = true)

def env39804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,17729,4194304,16,73857,8328,64,4592845,5392,4096,406605,20701,4194304,256,21793,16600,96011]

theorem envBound39804 : H12AffineFastState.Bounded env39804 := by
  intro p hp
  have h : env39804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39777_39804 : H12AffineEnvironment.transform 20 17729 env39777 = env39804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env39777 == env39804) = true)

theorem identity39804 : scanCanonicalize (H12AffineFastState.compose env39804 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39804 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,29962,131072,262144,1024,29789,17729,4194304,16,21899,8328,64,4592845,5392,4096,406605,20701,4194304,256,21793,16600,513]

theorem envBound39805 : H12AffineFastState.Bounded env39805 := by
  intro p hp
  have h : env39805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39804_39805 : H12AffineEnvironment.transform 15 29962 env39804 = env39805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39804 == env39805) = true)

def env39806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,131072,262144,1024,8541,4161,4194304,16,139,8328,64,4592845,5392,4096,406605,1501,4194304,256,33,5592,513]

theorem envBound39806 : H12AffineFastState.Bounded env39806 := by
  intro p hp
  have h : env39806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39805_39806 : H12AffineEnvironment.transform 13 5376 env39805 = env39806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39805 == env39806) = true)

theorem identity39806 : scanCanonicalize (H12AffineFastState.compose env39806 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound39806 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,8202,131072,138477,1024,8541,4161,4194304,16,139,8328,64,4196384,5392,4096,10400,1501,4194304,256,33,5592,513]

theorem envBound39807 : H12AffineFastState.Bounded env39807 := by
  intro p hp
  have h : env39807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39806_39807 : H12AffineEnvironment.transform 17 138477 env39806 = env39807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env39806 == env39807) = true)

theorem identity39807 : scanCanonicalize (H12AffineFastState.compose env39807 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39807 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,138341,1024,8541,4161,4194304,16,3,8192,64,4196384,5392,4096,10280,1365,4194304,256,33,5456,513]

theorem envBound39808 : H12AffineFastState.Bounded env39808 := by
  intro p hp
  have h : env39808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39807_39808 : H12AffineEnvironment.transform 6 8 env39807 = env39808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39807 == env39808) = true)

theorem identity39808 : scanCanonicalize (H12AffineFastState.compose env39808 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 136497) := by decide +kernel

theorem selectedBound39808 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env39809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,131072,138341,1024,8541,4161,136497,16,3,8192,64,138513,5392,4096,10280,1365,136497,256,33,5456,513]

theorem envBound39809 : H12AffineFastState.Bounded env39809 := by
  intro p hp
  have h : env39809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39808_39809 : H12AffineEnvironment.transform 21 136497 env39808 = env39809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136497 env39808 == env39809) = true)

theorem identity39809 : scanCanonicalize (H12AffineFastState.compose env39809 (packedSelected [0,14,27] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound39809 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env39810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,13388,10281,1024,8541,4161,8573,16,3,8192,64,10589,5392,4096,10280,1365,8573,256,33,5456,513]

theorem envBound39810 : H12AffineFastState.Bounded env39810 := by
  intro p hp
  have h : env39810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39809_39810 : H12AffineEnvironment.transform 16 13388 env39809 = env39810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env39809 == env39810) = true)

theorem identity39810 : scanCanonicalize (H12AffineFastState.compose env39810 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39810 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2421,1024,1,4161,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5456,513]

theorem envBound39811 : H12AffineFastState.Bounded env39811 := by
  intro p hp
  have h : env39811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39810_39811 : H12AffineEnvironment.transform 12 348 env39810 = env39811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39810 == env39811) = true)

theorem identity39811 : scanCanonicalize (H12AffineFastState.compose env39811 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound39811 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1