import H12CloudChart1Data096

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5392,2420,1024,8541,4160,8572,17,3,8193,65,10588,5392,4096,10280,1364,8573,256,33,5457,513]

theorem envBound24564 : H12AffineFastState.Bounded env24564 := by
  intro p hp
  have h : env24564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24563_24564 : H12AffineEnvironment.transform 15 8203 env24563 = env24564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24563 == env24564) = true)

theorem identity24564 : scanCanonicalize (H12AffineFastState.compose env24564 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24565 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8461,8203,5392,2341,1024,8460,4113,8493,17,3,8193,16,10509,5392,4096,10280,1285,8492,256,33,5376,513]

theorem envBound24565 : H12AffineFastState.Bounded env24565 := by
  intro p hp
  have h : env24565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24564_24565 : H12AffineEnvironment.transform 5 17 env24564 = env24565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24564 == env24565) = true)

theorem identity24565 : scanCanonicalize (H12AffineFastState.compose env24565 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 285) := by decide +kernel

theorem selectedBound24565 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24566 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,285,5376,16,278,5392,2341,1024,17,4113,48,17,3,284,16,2064,5392,4096,2357,1285,49,256,33,5376,513]

theorem envBound24566 : H12AffineFastState.Bounded env24566 := by
  intro p hp
  have h : env24566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24565_24566 : H12AffineEnvironment.transform 12 285 env24565 = env24566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 285 env24565 == env24566) = true)

theorem identity24566 : scanCanonicalize (H12AffineFastState.compose env24566 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1793) := by decide +kernel

theorem selectedBound24566 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24567 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,4096,285,5376,16,278,5392,1572,1024,17,4113,48,17,3,284,16,1809,5392,4096,1588,1285,49,256,33,5376,513]

theorem envBound24567 : H12AffineFastState.Bounded env24567 := by
  intro p hp
  have h : env24567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24566_24567 : H12AffineEnvironment.transform 10 1793 env24566 = env24567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env24566 == env24567) = true)

theorem identity24567 : scanCanonicalize (H12AffineFastState.compose env24567 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24567 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24568 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,4096,56,5157,16,51,5173,1572,1024,17,4113,48,17,3,57,16,1588,5173,4096,1588,1056,49,37,33,5157,513]

theorem envBound24568 : H12AffineFastState.Bounded env24568 := by
  intro p hp
  have h : env24568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24567_24568 : H12AffineEnvironment.transform 7 37 env24567 = env24568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24567 == env24568) = true)

theorem identity24568 : scanCanonicalize (H12AffineFastState.compose env24568 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24568 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24569 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1572,1077,56,16,16,51,0,1572,1024,17,1060,48,17,3,57,16,1588,0,1077,1588,1056,49,37,33,16,513]

theorem envBound24569 : H12AffineFastState.Bounded env24569 := by
  intro p hp
  have h : env24569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24568_24569 : H12AffineEnvironment.transform 11 1077 env24568 = env24569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env24568 == env24569) = true)

theorem identity24569 : scanCanonicalize (H12AffineFastState.compose env24569 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24569 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24570 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,1,56,16,16,51,0,528,52,17,16,48,17,3,57,16,512,0,1,512,20,49,37,33,16,513]

theorem envBound24570 : H12AffineFastState.Bounded env24570 := by
  intro p hp
  have h : env24570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24569_24570 : H12AffineEnvironment.transform 9 52 env24569 = env24570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24569 == env24570) = true)

theorem identity24570 : scanCanonicalize (H12AffineFastState.compose env24570 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24571 : List Nat := [2,4,8,16,0,17,9,5,512,20,528,1,24,16,16,19,0,528,20,17,16,16,17,3,25,16,512,0,1,512,20,17,5,1,16,513]

theorem envBound24571 : H12AffineFastState.Bounded env24571 := by
  intro p hp
  have h : env24571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24570_24571 : H12AffineEnvironment.transform 4 0 env24570 = env24571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24570 == env24571) = true)

theorem identity24571 : scanCanonicalize (H12AffineFastState.compose env24571 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24571 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24572 : List Nat := [2,4,8,16,0,17,9,5,16,20,0,1,24,16,16,19,0,0,20,17,16,16,17,3,25,16,16,0,1,16,20,17,5,1,16,17]

theorem envBound24572 : H12AffineFastState.Bounded env24572 := by
  intro p hp
  have h : env24572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24571_24572 : H12AffineEnvironment.transform 8 16 env24571 = env24572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24571 == env24572) = true)

theorem identity24572 : scanCanonicalize (H12AffineFastState.compose env24572 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24572 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24573 : List Nat := [2,4,8,1,0,0,9,5,1,5,0,1,9,1,1,2,0,0,5,0,1,1,0,3,8,1,1,0,1,1,5,0,5,1,1,0]

theorem envBound24573 : H12AffineFastState.Bounded env24573 := by
  intro p hp
  have h : env24573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24572_24573 : H12AffineEnvironment.transform 3 1 env24572 = env24573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24572 == env24573) = true)

def env24574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,79130,76278,1024,8661,4160,8572,17,2,8328,65,67927,79131,4097,10281,75222,66047,256,73771,79195,513]

theorem envBound24574 : H12AffineFastState.Bounded env24574 := by
  intro p hp
  have h : env24574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24561_24574 : H12AffineEnvironment.transform 13 5377 env24561 = env24574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env24561 == env24574) = true)

theorem identity24574 : scanCanonicalize (H12AffineFastState.compose env24574 (packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound24574 : packedSelected [1,2,3,4,6,9,14,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env24575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,65536,70726,67754,1024,137,4160,32,17,2,468,65,67927,70727,4097,2421,66698,66047,256,65911,70663,513]

theorem envBound24575 : H12AffineFastState.Bounded env24575 := by
  intro p hp
  have h : env24575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24574_24575 : H12AffineEnvironment.transform 12 348 env24574 = env24575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env24574 == env24575) = true)

theorem identity24575 : scanCanonicalize (H12AffineFastState.compose env24575 (packedSelected [1,3,6,8,10,11,12,14,15,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24575 : packedSelected [1,3,6,8,10,11,12,14,15,23,24] rootPS < 2^1333 := by decide +kernel

def env24576 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5377,80,65536,70726,67698,1024,81,4160,32,17,2,268,65,67927,70727,4097,2421,66642,65831,256,65911,70663,513]

theorem envBound24576 : H12AffineFastState.Bounded env24576 := by
  intro p hp
  have h : env24576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24575_24576 : H12AffineEnvironment.transform 6 88 env24575 = env24576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24575 == env24576) = true)

theorem identity24576 : scanCanonicalize (H12AffineFastState.compose env24576 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound24576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24577 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,5377,80,262,5440,2420,1024,81,4160,32,17,2,268,65,2129,5441,4097,2421,1364,33,256,113,5377,513]

theorem envBound24577 : H12AffineFastState.Bounded env24577 := by
  intro p hp
  have h : env24577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24576_24577 : H12AffineEnvironment.transform 15 262 env24576 = env24577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env24576 == env24577) = true)

theorem identity24577 : scanCanonicalize (H12AffineFastState.compose env24577 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound24577 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24578 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,64,348,1345,80,262,1280,2420,1024,81,0,32,17,2,268,65,2129,1281,65,2421,1364,33,256,113,1345,513]

theorem envBound24578 : H12AffineFastState.Bounded env24578 := by
  intro p hp
  have h : env24578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24577_24578 : H12AffineEnvironment.transform 11 64 env24577 = env24578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env24577 == env24578) = true)

theorem identity24578 : scanCanonicalize (H12AffineFastState.compose env24578 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24578 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24579 : List Nat := [2,4,8,16,32,64,88,256,512,273,2048,64,348,80,80,262,17,2420,273,81,0,32,17,2,268,65,2129,16,65,2421,69,33,256,113,80,513]

theorem envBound24579 : H12AffineFastState.Bounded env24579 := by
  intro p hp
  have h : env24579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24578_24579 : H12AffineEnvironment.transform 9 273 env24578 = env24579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24578 == env24579) = true)

theorem identity24579 : scanCanonicalize (H12AffineFastState.compose env24579 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound24579 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env24580 : List Nat := [2,4,8,16,32,64,88,256,512,273,80,64,348,80,80,262,17,292,273,81,0,32,17,2,268,65,1,16,65,293,69,33,256,113,80,513]

theorem envBound24580 : H12AffineFastState.Bounded env24580 := by
  intro p hp
  have h : env24580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24579_24580 : H12AffineEnvironment.transform 10 80 env24579 = env24580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24579 == env24580) = true)

def env24581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,8388608,21762,8328,65,12705006,115150,8406288,8423916,8507667,4268163,256,8487406,8478795,8451780]

theorem envBound24581 : H12AffineFastState.Bounded env24581 := by
  intro p hp
  have h : env24581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24546_24581 : H12AffineEnvironment.transform 20 4161 env24546 = env24581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env24546 == env24581) = true)

def env24582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,16,21762,8328,65,4316414,115150,17664,35324,119043,4268163,256,98814,90203,63188]

theorem envBound24582 : H12AffineFastState.Bounded env24582 := by
  intro p hp
  have h : env24582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24581_24582 : H12AffineEnvironment.transform 22 16 env24581 = env24582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24581 == env24582) = true)

theorem identity24582 : scanCanonicalize (H12AffineFastState.compose env24582 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound24582 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149997,1024,32769,4161,4194304,16,21762,8328,65,4196384,5392,17664,35324,1501,4256861,256,21792,46213,63188]

theorem envBound24583 : H12AffineFastState.Bounded env24583 := by
  intro p hp
  have h : env24583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24582_24583 : H12AffineEnvironment.transform 15 54494 env24582 = env24583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env24582 == env24583) = true)

def env24584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,149861,1024,32769,4161,4194304,16,21762,8192,65,4196384,5392,17664,35188,1365,4256861,256,21792,46093,63068]

theorem envBound24584 : H12AffineFastState.Bounded env24584 := by
  intro p hp
  have h : env24584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24583_24584 : H12AffineEnvironment.transform 6 8 env24583 = env24584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24583 == env24584) = true)

theorem identity24584 : scanCanonicalize (H12AffineFastState.compose env24584 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound24584 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,32040,1024,32769,4161,4194304,16,21762,8192,65,4196384,5392,17664,35188,1365,4256861,256,21792,46093,63068]

theorem envBound24585 : H12AffineFastState.Bounded env24585 := by
  intro p hp
  have h : env24585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24584_24585 : H12AffineEnvironment.transform 16 13389 env24584 = env24585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env24584 == env24585) = true)

theorem identity24585 : scanCanonicalize (H12AffineFastState.compose env24585 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound24585 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env24586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33031,13389,10361,1024,32769,4161,4194304,16,83,8192,65,4196384,5392,4177,35188,1365,4235532,256,113,46093,41741]

theorem envBound24586 : H12AffineFastState.Bounded env24586 := by
  intro p hp
  have h : env24586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24585_24586 : H12AffineEnvironment.transform 13 5457 env24585 = env24586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env24585 == env24586) = true)

theorem identity24586 : scanCanonicalize (H12AffineFastState.compose env24586 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41049) := by decide +kernel

theorem selectedBound24586 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env24587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,33031,13389,10361,1024,32769,4161,41049,16,83,8192,65,43129,5392,4177,35188,1365,341,256,113,46093,41741]

theorem envBound24587 : H12AffineFastState.Bounded env24587 := by
  intro p hp
  have h : env24587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24586_24587 : H12AffineEnvironment.transform 21 41049 env24586 = env24587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41049 env24586 == env24587) = true)

theorem identity24587 : scanCanonicalize (H12AffineFastState.compose env24587 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound24587 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,0,263,13389,10361,1024,1,4161,8281,16,83,8192,65,10361,5392,4177,2420,1365,341,256,113,13325,8973]

theorem envBound24588 : H12AffineFastState.Bounded env24588 := by
  intro p hp
  have h : env24588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24587_24588 : H12AffineEnvironment.transform 14 0 env24587 = env24588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env24587 == env24588) = true)

theorem identity24588 : scanCanonicalize (H12AffineFastState.compose env24588 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,18,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24588 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,18,24] rootPS < 2^1333 := by decide +kernel

def env24589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,0,263,5392,2340,1024,1,4161,260,16,83,349,65,2340,5392,4177,2420,1365,341,256,113,5456,592]

theorem envBound24589 : H12AffineFastState.Bounded env24589 := by
  intro p hp
  have h : env24589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24588_24589 : H12AffineEnvironment.transform 12 349 env24588 = env24589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24588 == env24589) = true)

theorem identity24589 : scanCanonicalize (H12AffineFastState.compose env24589 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound24589 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3329,349,2128,0,263,2065,2340,1024,1,3392,260,16,83,349,65,2340,2065,3408,2420,1365,341,256,113,2129,592]

theorem envBound24590 : H12AffineFastState.Bounded env24590 := by
  intro p hp
  have h : env24590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24589_24590 : H12AffineEnvironment.transform 11 3329 env24589 = env24590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env24589 == env24590) = true)

theorem identity24590 : scanCanonicalize (H12AffineFastState.compose env24590 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24590 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1280,349,81,0,263,16,293,1024,1,1345,260,16,83,349,65,293,16,1361,373,1365,341,256,113,80,592]

theorem envBound24591 : H12AffineFastState.Bounded env24591 := by
  intro p hp
  have h : env24591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24590_24591 : H12AffineEnvironment.transform 10 1 env24590 = env24591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24590 == env24591) = true)

theorem identity24591 : scanCanonicalize (H12AffineFastState.compose env24591 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound24591 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24592 : List Nat := [2,4,8,16,32,64,8,256,512,320,1,64,349,81,0,263,16,293,320,1,1,260,16,83,349,65,293,16,17,373,21,341,256,113,80,592]

theorem envBound24592 : H12AffineFastState.Bounded env24592 := by
  intro p hp
  have h : env24592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24591_24592 : H12AffineEnvironment.transform 9 320 env24591 = env24592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env24591 == env24592) = true)

theorem identity24592 : scanCanonicalize (H12AffineFastState.compose env24592 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound24592 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env24593 : List Nat := [2,4,8,16,32,64,8,117,512,53,1,64,40,81,0,114,16,80,53,1,1,113,16,83,40,65,80,16,17,0,21,32,117,113,80,592]

theorem envBound24593 : H12AffineFastState.Bounded env24593 := by
  intro p hp
  have h : env24593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24592_24593 : H12AffineEnvironment.transform 7 117 env24592 = env24593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env24592 == env24593) = true)

theorem identity24593 : scanCanonicalize (H12AffineFastState.compose env24593 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24594 : List Nat := [2,4,8,16,32,49,8,4,512,53,1,49,40,32,0,3,16,33,53,1,1,0,16,34,40,48,33,16,17,0,21,32,4,0,33,545]

theorem envBound24594 : H12AffineFastState.Bounded env24594 := by
  intro p hp
  have h : env24594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24593_24594 : H12AffineEnvironment.transform 5 49 env24593 = env24594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24593 == env24594) = true)

theorem identity24594 : scanCanonicalize (H12AffineFastState.compose env24594 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24594 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24595 : List Nat := [2,4,8,16,1,16,8,4,512,20,1,16,9,1,0,3,16,0,20,1,1,0,16,3,9,17,0,16,17,0,21,1,4,0,0,512]

theorem envBound24595 : H12AffineFastState.Bounded env24595 := by
  intro p hp
  have h : env24595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24594_24595 : H12AffineEnvironment.transform 4 1 env24594 = env24595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24594 == env24595) = true)

theorem identity24595 : scanCanonicalize (H12AffineFastState.compose env24595 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24596 : List Nat := [2,0,8,16,1,16,8,0,512,16,1,16,9,1,0,3,16,0,16,1,1,0,16,3,9,17,0,16,17,0,17,1,0,0,0,512]

theorem envBound24596 : H12AffineFastState.Bounded env24596 := by
  intro p hp
  have h : env24596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24595_24596 : H12AffineEnvironment.transform 1 0 env24595 = env24596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24595 == env24596) = true)

theorem identity24596 : scanCanonicalize (H12AffineFastState.compose env24596 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound24596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24597 : List Nat := [2,0,8,16,1,16,8,0,9,16,1,16,9,1,0,3,16,0,16,1,1,0,16,3,9,17,0,16,17,0,17,1,0,0,0,9]

theorem envBound24597 : H12AffineFastState.Bounded env24597 := by
  intro p hp
  have h : env24597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24596_24597 : H12AffineEnvironment.transform 8 9 env24596 = env24597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env24596 == env24597) = true)

theorem identity24597 : scanCanonicalize (H12AffineFastState.compose env24597 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24597 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24598 : List Nat := [0,0,8,16,1,16,8,0,9,16,1,16,9,1,0,1,16,0,16,1,1,0,16,1,9,17,0,16,17,0,17,1,0,0,0,9]

theorem envBound24598 : H12AffineFastState.Bounded env24598 := by
  intro p hp
  have h : env24598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24597_24598 : H12AffineEnvironment.transform 0 0 env24597 = env24598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24597 == env24598) = true)

def env24599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149860,1024,32769,4161,4194304,16,21762,8193,65,4196384,5392,17664,35189,1364,4256861,256,21792,46092,63069]

theorem envBound24599 : H12AffineFastState.Bounded env24599 := by
  intro p hp
  have h : env24599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24583_24599 : H12AffineEnvironment.transform 6 9 env24583 = env24599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24583 == env24599) = true)

theorem identity24599 : scanCanonicalize (H12AffineFastState.compose env24599 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound24599 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38160,56436,1024,32769,4161,4194304,16,21762,8193,65,4196384,5392,17664,35189,1364,4256861,256,21792,46092,63069]

theorem envBound24600 : H12AffineFastState.Bounded env24600 := by
  intro p hp
  have h : env24600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24599_24600 : H12AffineEnvironment.transform 16 38160 env24599 = env24600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env24599 == env24600) = true)

theorem identity24600 : scanCanonicalize (H12AffineFastState.compose env24600 (packedSelected [0,3,5,7,9,10,11,14,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24600 : packedSelected [0,3,5,7,9,10,11,14,18,20,22] rootPS < 2^1333 := by decide +kernel

def env24601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,38160,35188,1024,32769,4161,4194304,16,2,8193,65,4196384,5392,4096,35189,1364,4235613,256,32,46092,41821]

theorem envBound24601 : H12AffineFastState.Bounded env24601 := by
  intro p hp
  have h : env24601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24600_24601 : H12AffineEnvironment.transform 13 5376 env24600 = env24601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24600 == env24601) = true)

theorem identity24601 : scanCanonicalize (H12AffineFastState.compose env24601 (packedSelected [1,4,8,9,11,14,18,19,20] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound24601 : packedSelected [1,4,8,9,11,14,18,19,20] rootPS < 2^1333 := by decide +kernel

def env24602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,38160,35188,1024,32769,4161,8573,16,2,8193,65,10589,5392,4096,35189,1364,32800,256,32,46092,41821]

theorem envBound24602 : H12AffineFastState.Bounded env24602 := by
  intro p hp
  have h : env24602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24601_24602 : H12AffineEnvironment.transform 21 8573 env24601 = env24602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env24601 == env24602) = true)

theorem identity24602 : scanCanonicalize (H12AffineFastState.compose env24602 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound24602 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env24603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,80,263,5440,2340,1024,81,4161,8573,16,2,8193,65,10589,5392,4096,2341,1364,112,256,32,13404,8973]

theorem envBound24603 : H12AffineFastState.Bounded env24603 := by
  intro p hp
  have h : env24603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24602_24603 : H12AffineEnvironment.transform 14 80 env24602 = env24603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env24602 == env24603) = true)

theorem identity24603 : scanCanonicalize (H12AffineFastState.compose env24603 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24603 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24604 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,0,263,5392,2340,1024,1,4113,8493,16,2,8193,17,10509,5392,4096,2341,1284,32,256,32,13324,8973]

theorem envBound24604 : H12AffineFastState.Bounded env24604 := by
  intro p hp
  have h : env24604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24603_24604 : H12AffineEnvironment.transform 5 16 env24603 = env24604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24603 == env24604) = true)

theorem identity24604 : scanCanonicalize (H12AffineFastState.compose env24604 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 797) := by decide +kernel

theorem selectedBound24604 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env24605 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,797,5376,0,263,5392,2340,1024,1,4113,560,16,2,796,17,2576,5392,4096,2341,1284,32,256,32,5905,16]

theorem envBound24605 : H12AffineFastState.Bounded env24605 := by
  intro p hp
  have h : env24605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24604_24605 : H12AffineEnvironment.transform 12 797 env24604 = env24605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 797 env24604 == env24605) = true)

theorem identity24605 : scanCanonicalize (H12AffineFastState.compose env24605 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1792) := by decide +kernel

theorem selectedBound24605 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env24606 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1792,797,512,0,263,528,2340,1024,1,1809,560,16,2,796,17,2576,528,1792,2341,1284,32,256,32,17,16]

theorem envBound24606 : H12AffineFastState.Bounded env24606 := by
  intro p hp
  have h : env24606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24605_24606 : H12AffineEnvironment.transform 11 1792 env24605 = env24606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1792 env24605 == env24606) = true)

theorem identity24606 : scanCanonicalize (H12AffineFastState.compose env24606 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24606 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env24607 : List Nat := [2,4,8,16,0,16,9,256,512,1024,2048,1792,797,512,0,263,528,2308,1024,1,1809,528,16,2,796,17,2576,528,1792,2309,1284,0,256,0,17,16]

theorem envBound24607 : H12AffineFastState.Bounded env24607 := by
  intro p hp
  have h : env24607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24606_24607 : H12AffineEnvironment.transform 4 0 env24606 = env24607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24606 == env24607) = true)

theorem identity24607 : scanCanonicalize (H12AffineFastState.compose env24607 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24607 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24608 : List Nat := [2,4,8,16,0,16,9,256,16,1024,2048,1296,269,16,0,263,0,2308,1024,1,1281,0,16,2,268,17,2048,0,1296,2309,1284,0,256,0,17,16]

theorem envBound24608 : H12AffineFastState.Bounded env24608 := by
  intro p hp
  have h : env24608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24607_24608 : H12AffineEnvironment.transform 8 16 env24607 = env24608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24607 == env24608) = true)

def env24609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,4194304,17,21762,8328,65,4316415,115150,17665,35325,119042,4268163,256,98815,90202,63189]

theorem envBound24609 : H12AffineFastState.Bounded env24609 := by
  intro p hp
  have h : env24609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24581_24609 : H12AffineEnvironment.transform 22 17 env24581 = env24609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24581 == env24609) = true)

theorem identity24609 : scanCanonicalize (H12AffineFastState.compose env24609 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213351) := by decide +kernel

theorem selectedBound24609 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,213351,17,21762,8328,65,171416,115150,17665,35325,119042,156132,256,98815,90202,63189]

theorem envBound24610 : H12AffineFastState.Bounded env24610 := by
  intro p hp
  have h : env24610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24609_24610 : H12AffineEnvironment.transform 21 213351 env24609 = env24610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213351 env24609 == env24610) = true)

def env24611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,213351,17,21762,8192,65,171280,115014,17665,35189,119042,156012,256,98679,90202,63069]

theorem envBound24611 : H12AffineFastState.Bounded env24611 := by
  intro p hp
  have h : env24611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24610_24611 : H12AffineEnvironment.transform 6 8 env24610 = env24611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24610 == env24611) = true)

theorem identity24611 : scanCanonicalize (H12AffineFastState.compose env24611 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound24611 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138341,1024,32769,4161,201831,17,2,8192,65,171280,103494,4097,35189,99330,144492,256,98679,79194,41821]

theorem envBound24612 : H12AffineFastState.Bounded env24612 := by
  intro p hp
  have h : env24612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24611_24612 : H12AffineEnvironment.transform 13 5376 env24611 = env24612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env24611 == env24612) = true)

theorem identity24612 : scanCanonicalize (H12AffineFastState.compose env24612 (packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound24612 : packedSelected [3,4,8,9,12,14,15,20,24,26,28] rootPS < 2^1333 := by decide +kernel

def env24613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,115,131072,138341,1024,32769,4161,136212,17,2,8192,65,171280,37941,4097,35189,33905,144492,256,33028,13609,41821]

theorem envBound24613 : H12AffineFastState.Bounded env24613 := by
  intro p hp
  have h : env24613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24612_24613 : H12AffineEnvironment.transform 15 115 env24612 = env24613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env24612 == env24613) = true)

theorem identity24613 : scanCanonicalize (H12AffineFastState.compose env24613 (packedSelected [0,2,3,4,6,7,9,10,11,14,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound24613 : packedSelected [0,2,3,4,6,7,9,10,11,14,19,23,24] rootPS < 2^1333 := by decide +kernel

def env24614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,293,115,131072,138341,1024,292,4161,136212,17,2,8192,65,138293,5392,4097,2128,1364,144492,256,33,13609,8824]

theorem envBound24614 : H12AffineFastState.Bounded env24614 := by
  intro p hp
  have h : env24614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24613_24614 : H12AffineEnvironment.transform 14 293 env24613 = env24614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env24613 == env24614) = true)

theorem identity24614 : scanCanonicalize (H12AffineFastState.compose env24614 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound24614 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env24615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,293,115,13388,10281,1024,292,4161,8280,17,2,8192,65,10361,5392,4097,2128,1364,32,256,33,13609,8824]

theorem envBound24615 : H12AffineFastState.Bounded env24615 := by
  intro p hp
  have h : env24615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24614_24615 : H12AffineEnvironment.transform 16 13388 env24614 = env24615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env24614 == env24615) = true)

theorem identity24615 : scanCanonicalize (H12AffineFastState.compose env24615 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound24615 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24616 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4113,293,115,12637,10281,273,292,4161,8280,17,2,8192,65,10361,4097,4097,2128,69,32,256,33,12344,8824]

theorem envBound24616 : H12AffineFastState.Bounded env24616 := by
  intro p hp
  have h : env24616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24615_24616 : H12AffineEnvironment.transform 9 273 env24615 = env24616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env24615 == env24616) = true)

theorem identity24616 : scanCanonicalize (H12AffineFastState.compose env24616 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound24616 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env24617 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,6429,4113,293,115,2112,4404,273,292,4161,6469,17,2,6429,65,4452,4097,4097,2128,69,32,256,33,2341,7013]

theorem envBound24617 : H12AffineFastState.Bounded env24617 := by
  intro p hp
  have h : env24617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24616_24617 : H12AffineEnvironment.transform 12 6429 env24616 = env24617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env24616 == env24617) = true)

theorem identity24617 : scanCanonicalize (H12AffineFastState.compose env24617 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound24617 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24618 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,4096,6201,4113,1,115,2112,4112,53,0,4161,6241,17,2,6201,65,4160,4097,4097,2128,69,32,36,33,2049,6721]

theorem envBound24618 : H12AffineFastState.Bounded env24618 := by
  intro p hp
  have h : env24618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24617_24618 : H12AffineEnvironment.transform 7 36 env24617 = env24618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env24617 == env24618) = true)

theorem identity24618 : scanCanonicalize (H12AffineFastState.compose env24618 (packedSelected [4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound24618 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env24619 : List Nat := [2,4,8,16,32,64,8,36,512,53,2048,2113,120,2128,1,115,2112,2129,53,0,2048,32,17,2,120,65,2049,2112,2112,2128,69,32,36,33,2049,512]

theorem envBound24619 : H12AffineFastState.Bounded env24619 := by
  intro p hp
  have h : env24619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24618_24619 : H12AffineEnvironment.transform 11 2113 env24618 = env24619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env24618 == env24619) = true)

theorem identity24619 : scanCanonicalize (H12AffineFastState.compose env24619 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound24619 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24620 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,96,120,113,1,115,97,112,53,0,33,32,17,2,120,65,32,97,97,113,69,32,36,33,32,512]

theorem envBound24620 : H12AffineFastState.Bounded env24620 := by
  intro p hp
  have h : env24620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24619_24620 : H12AffineEnvironment.transform 10 33 env24619 = env24620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24619 == env24620) = true)

theorem identity24620 : scanCanonicalize (H12AffineFastState.compose env24620 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound24620 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24621 : List Nat := [2,4,8,16,32,64,8,36,10,53,33,96,120,113,1,115,97,112,53,0,33,32,17,2,120,65,32,97,97,113,69,32,36,33,32,10]

theorem envBound24621 : H12AffineFastState.Bounded env24621 := by
  intro p hp
  have h : env24621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24620_24621 : H12AffineEnvironment.transform 8 10 env24620 = env24621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env24620 == env24621) = true)

theorem identity24621 : scanCanonicalize (H12AffineFastState.compose env24621 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24621 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24622 : List Nat := [2,4,8,16,32,16,8,36,10,53,33,48,40,33,1,35,49,32,53,0,33,32,17,2,40,17,32,49,49,33,21,32,36,33,32,10]

theorem envBound24622 : H12AffineFastState.Bounded env24622 := by
  intro p hp
  have h : env24622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24621_24622 : H12AffineEnvironment.transform 5 16 env24621 = env24622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24621 == env24622) = true)

theorem identity24622 : scanCanonicalize (H12AffineFastState.compose env24622 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound24622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24623 : List Nat := [2,4,8,16,5,16,8,1,10,16,4,21,13,4,1,6,20,5,16,0,4,5,17,2,13,17,5,20,20,4,21,5,1,4,5,10]

theorem envBound24623 : H12AffineFastState.Bounded env24623 := by
  intro p hp
  have h : env24623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24622_24623 : H12AffineEnvironment.transform 4 5 env24622 = env24623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env24622 == env24623) = true)

theorem identity24623 : scanCanonicalize (H12AffineFastState.compose env24623 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound24623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24624 : List Nat := [2,4,1,16,5,16,1,1,3,16,4,21,4,4,1,6,20,5,16,0,4,5,17,2,4,17,5,20,20,4,21,5,1,4,5,3]

theorem envBound24624 : H12AffineFastState.Bounded env24624 := by
  intro p hp
  have h : env24624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24623_24624 : H12AffineEnvironment.transform 2 1 env24623 = env24624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env24623 == env24624) = true)

theorem identity24624 : scanCanonicalize (H12AffineFastState.compose env24624 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24624 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24625 : List Nat := [2,0,1,16,1,16,1,1,3,16,0,17,0,0,1,2,16,1,16,0,0,1,17,2,0,17,1,16,16,0,17,1,1,0,1,3]

theorem envBound24625 : H12AffineFastState.Bounded env24625 := by
  intro p hp
  have h : env24625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24624_24625 : H12AffineEnvironment.transform 1 0 env24624 = env24625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24624 == env24625) = true)

def env24626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,213351,17,21762,8193,65,171281,115015,17665,35188,119042,156013,256,98678,90202,63068]

theorem envBound24626 : H12AffineFastState.Bounded env24626 := by
  intro p hp
  have h : env24626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24610_24626 : H12AffineEnvironment.transform 6 9 env24610 = env24626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24610 == env24626) = true)

theorem identity24626 : scanCanonicalize (H12AffineFastState.compose env24626 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound24626 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149860,1024,29788,4161,213351,17,21762,8193,65,158028,79130,17665,32041,75103,156013,256,95531,90202,513]

theorem envBound24627 : H12AffineFastState.Bounded env24627 := by
  intro p hp
  have h : env24627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24626_24627 : H12AffineEnvironment.transform 14 29789 env24626 = env24627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env24626 == env24627) = true)

theorem identity24627 : scanCanonicalize (H12AffineFastState.compose env24627 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24627 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90139,76159,1024,29788,4161,8572,17,21762,8193,65,67927,79130,17665,32041,75103,65910,256,95531,90202,513]

theorem envBound24628 : H12AffineFastState.Bounded env24628 := by
  intro p hp
  have h : env24628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24627_24628 : H12AffineEnvironment.transform 16 90139 env24627 = env24628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24627 == env24628) = true)

theorem identity24628 : scanCanonicalize (H12AffineFastState.compose env24628 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound24628 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,5393,23669,1024,29788,4161,8572,17,21762,8193,65,31837,16400,17665,32041,20565,29820,256,33,5456,513]

theorem envBound24629 : H12AffineFastState.Bounded env24629 := by
  intro p hp
  have h : env24629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24628_24629 : H12AffineEnvironment.transform 15 29962 env24628 = env24629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env24628 == env24629) = true)

theorem identity24629 : scanCanonicalize (H12AffineFastState.compose env24629 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound24629 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env24630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5156,8313,8494,5393,2129,1024,8312,4161,8572,17,294,8193,65,10361,5172,4389,10509,1137,8280,256,33,5456,513]

theorem envBound24630 : H12AffineFastState.Bounded env24630 := by
  intro p hp
  have h : env24630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24629_24630 : H12AffineEnvironment.transform 13 5156 env24629 = env24630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env24629 == env24630) = true)

theorem identity24630 : scanCanonicalize (H12AffineFastState.compose env24630 (packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24630 : packedSelected [0,3,4,5,6,7,9,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24631 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5156,0,343,5393,2129,1024,1,4161,261,17,294,120,65,2048,5172,4389,2420,1137,33,256,33,5456,513]

theorem envBound24631 : H12AffineFastState.Bounded env24631 := by
  intro p hp
  have h : env24631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24630_24631 : H12AffineEnvironment.transform 12 121 env24630 = env24631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24630 == env24631) = true)

theorem identity24631 : scanCanonicalize (H12AffineFastState.compose env24631 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24631 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24632 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5156,0,114,5172,2129,1024,1,4161,32,17,3,120,65,2048,5172,4096,2129,1137,33,37,33,5237,513]

theorem envBound24632 : H12AffineFastState.Bounded env24632 := by
  intro p hp
  have h : env24632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24631_24632 : H12AffineEnvironment.transform 7 37 env24631 = env24632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24631 == env24632) = true)

theorem identity24632 : scanCanonicalize (H12AffineFastState.compose env24632 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound24632 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24633 : List Nat := [2,4,8,16,32,64,9,37,512,564,2048,4096,121,4624,0,114,4608,2129,564,1,4161,32,17,3,120,65,2048,4608,4096,2129,581,33,37,33,4673,513]

theorem envBound24633 : H12AffineFastState.Bounded env24633 := by
  intro p hp
  have h : env24633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24632_24633 : H12AffineEnvironment.transform 9 564 env24632 = env24633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env24632 == env24633) = true)

theorem identity24633 : scanCanonicalize (H12AffineFastState.compose env24633 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24633 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24634 : List Nat := [2,4,8,16,32,17,9,37,512,564,2048,4096,40,4624,0,35,4608,2048,564,1,4112,32,17,3,41,16,2048,4608,4096,2048,532,33,37,33,4624,513]

theorem envBound24634 : H12AffineFastState.Bounded env24634 := by
  intro p hp
  have h : env24634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24633_24634 : H12AffineEnvironment.transform 5 17 env24633 = env24634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24633 == env24634) = true)

theorem identity24634 : scanCanonicalize (H12AffineFastState.compose env24634 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24634 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24635 : List Nat := [2,4,8,0,32,1,9,37,512,548,2048,4096,40,4608,0,35,4608,2048,548,1,4096,32,1,3,41,0,2048,4608,4096,2048,516,33,37,33,4608,513]

theorem envBound24635 : H12AffineFastState.Bounded env24635 := by
  intro p hp
  have h : env24635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24634_24635 : H12AffineEnvironment.transform 3 0 env24634 = env24635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24634 == env24635) = true)

theorem identity24635 : scanCanonicalize (H12AffineFastState.compose env24635 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound24635 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24636 : List Nat := [2,4,8,0,32,1,9,37,512,548,512,4096,40,4608,0,35,4608,512,548,1,4096,32,1,3,41,0,512,4608,4096,512,516,33,37,33,4608,513]

theorem envBound24636 : H12AffineFastState.Bounded env24636 := by
  intro p hp
  have h : env24636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24635_24636 : H12AffineEnvironment.transform 10 512 env24635 = env24636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env24635 == env24636) = true)

theorem identity24636 : scanCanonicalize (H12AffineFastState.compose env24636 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound24636 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24637 : List Nat := [2,4,8,0,32,1,9,37,512,548,512,512,40,0,0,35,0,512,548,1,512,32,1,3,41,0,512,0,512,512,516,33,37,33,0,513]

theorem envBound24637 : H12AffineFastState.Bounded env24637 := by
  intro p hp
  have h : env24637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24636_24637 : H12AffineEnvironment.transform 11 512 env24636 = env24637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env24636 == env24637) = true)

theorem identity24637 : scanCanonicalize (H12AffineFastState.compose env24637 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound24637 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24638 : List Nat := [2,4,8,0,32,1,9,37,0,36,0,0,40,0,0,35,0,0,36,1,0,32,1,3,41,0,0,0,0,0,4,33,37,33,0,1]

theorem envBound24638 : H12AffineFastState.Bounded env24638 := by
  intro p hp
  have h : env24638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24637_24638 : H12AffineEnvironment.transform 8 0 env24637 = env24638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env24637 == env24638) = true)

def env24639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound24639 : H12AffineFastState.Bounded env24639 := by
  intro p hp
  have h : env24639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24458_24639 : H12AffineEnvironment.transform 18 1025 env24458 = env24639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env24458 == env24639) = true)

theorem identity24639 : scanCanonicalize (H12AffineFastState.compose env24639 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485294) := by decide +kernel

theorem selectedBound24639 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485294,16777216,8328,65,23211054,18973836,375167,2305070,19163199,23160256,257,17049730,17090854,19222505]

theorem envBound24640 : H12AffineFastState.Bounded env24640 := by
  intro p hp
  have h : env24640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24639_24640 : H12AffineEnvironment.transform 22 2485294 env24639 = env24640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485294 env24639 == env24640) = true)

def env24641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,16777216,8328,65,16959642,18973836,375167,2305070,19163199,16875892,257,17049730,17090854,19222505]

theorem envBound24641 : H12AffineFastState.Bounded env24641 := by
  intro p hp
  have h : env24641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24640_24641 : H12AffineEnvironment.transform 21 2155700 env24640 = env24641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155700 env24640 == env24641) = true)

def env24642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,2559344,8328,65,2475498,428540,375167,2305070,222543,2526212,257,2303474,2344022,148121]

theorem envBound24642 : H12AffineFastState.Bounded env24642 := by
  intro p hp
  have h : env24642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24641_24642 : H12AffineEnvironment.transform 23 2559344 env24641 = env24642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env24641 == env24642) = true)

def env24643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,2559344,8192,65,2475362,428404,375167,2305070,222543,2526212,257,2303354,2344022,147985]

theorem envBound24643 : H12AffineFastState.Bounded env24643 := by
  intro p hp
  have h : env24643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24642_24643 : H12AffineEnvironment.transform 6 8 env24642 = env24643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24642 == env24643) = true)

theorem identity24643 : scanCanonicalize (H12AffineFastState.compose env24643 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24643 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env24644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,2155580,2485294,2444640,8192,65,2475362,313700,375167,2190398,75103,2411540,257,2188650,2196550,513]

theorem envBound24644 : H12AffineFastState.Bounded env24644 := by
  intro p hp
  have h : env24644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24643_24644 : H12AffineEnvironment.transform 16 16400 env24643 = env24644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24643 == env24644) = true)

def env24645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,2155580,2212870,2188616,8192,65,2223434,57676,102743,2190398,75103,2155580,257,2188650,2196550,513]

theorem envBound24645 : H12AffineFastState.Bounded env24645 := by
  intro p hp
  have h : env24645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24644_24645 : H12AffineEnvironment.transform 17 10280 env24644 = env24645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24644 == env24645) = true)

theorem identity24645 : scanCanonicalize (H12AffineFastState.compose env24645 (packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound24645 : packedSelected [0,3,4,5,7,9,10,11,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env24646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,2097152,2155580,2122764,2147650,8192,65,2116928,57676,12637,2149428,34133,2155580,257,2147680,2106444,513]

theorem envBound24646 : H12AffineFastState.Bounded env24646 := by
  intro p hp
  have h : env24646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24645_24646 : H12AffineEnvironment.transform 15 40970 env24645 = env24646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env24645 == env24646) = true)

theorem identity24646 : scanCanonicalize (H12AffineFastState.compose env24646 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound24646 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,25676,32880,64,41230,8192,65,10508,57676,12637,43128,34133,32880,257,41260,16384,513]

theorem envBound24647 : H12AffineFastState.Bounded env24647 := by
  intro p hp
  have h : env24647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24646_24647 : H12AffineEnvironment.transform 20 25676 env24646 = env24647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env24646 == env24647) = true)

theorem identity24647 : scanCanonicalize (H12AffineFastState.compose env24647 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24647 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33111,16400,2421,1025,32769,17681,32880,64,32851,349,65,2129,49169,4096,35109,34133,32880,257,32881,16384,513]

theorem envBound24648 : H12AffineFastState.Bounded env24648 := by
  intro p hp
  have h : env24648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24647_24648 : H12AffineEnvironment.transform 12 349 env24647 = env24648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24647 == env24648) = true)

theorem identity24648 : scanCanonicalize (H12AffineFastState.compose env24648 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound24648 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,263,16400,2421,1025,81,17681,32,64,3,349,65,2129,16449,4096,2421,1285,32,257,33,16384,513]

theorem envBound24649 : H12AffineFastState.Bounded env24649 := by
  intro p hp
  have h : env24649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24648_24649 : H12AffineEnvironment.transform 14 80 env24648 = env24649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env24648 == env24649) = true)

theorem identity24649 : scanCanonicalize (H12AffineFastState.compose env24649 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24649 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24650 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16400,2340,1025,0,17681,32,17,3,268,16,2048,16400,4096,2340,1285,32,257,33,16384,513]

theorem envBound24650 : H12AffineFastState.Bounded env24650 := by
  intro p hp
  have h : env24650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24649_24650 : H12AffineEnvironment.transform 5 17 env24649 = env24650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24649 == env24650) = true)

theorem identity24650 : scanCanonicalize (H12AffineFastState.compose env24650 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24650 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24651 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,16384,1,3,16400,2080,1025,0,17429,32,17,3,8,16,2048,16400,4096,2080,1025,32,5,33,16384,513]

theorem envBound24651 : H12AffineFastState.Bounded env24651 := by
  intro p hp
  have h : env24651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24650_24651 : H12AffineEnvironment.transform 7 4 env24650 = env24651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24650 == env24651) = true)

theorem identity24651 : scanCanonicalize (H12AffineFastState.compose env24651 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound24651 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24652 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8,5124,1,3,5140,2080,1025,0,4113,32,17,3,8,16,2048,5140,4096,2080,1025,32,5,33,5124,513]

theorem envBound24652 : H12AffineFastState.Bounded env24652 := by
  intro p hp
  have h : env24652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24651_24652 : H12AffineEnvironment.transform 13 5124 env24651 = env24652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env24651 == env24652) = true)

theorem identity24652 : scanCanonicalize (H12AffineFastState.compose env24652 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound24652 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24653 : List Nat := [2,4,8,16,32,17,8,4,33,1024,2048,4096,8,5124,1,3,5140,2080,1025,0,4113,32,17,3,8,16,2048,5140,4096,2080,1025,32,5,33,5124,32]

theorem envBound24653 : H12AffineFastState.Bounded env24653 := by
  intro p hp
  have h : env24653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24652_24653 : H12AffineEnvironment.transform 8 33 env24652 = env24653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env24652 == env24653) = true)

theorem identity24653 : scanCanonicalize (H12AffineFastState.compose env24653 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24653 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24654 : List Nat := [2,4,8,16,32,17,8,4,33,1024,2048,1045,8,17,1,3,1,2080,1025,0,1028,32,17,3,8,16,2048,1,1045,2080,1025,32,5,33,17,32]

theorem envBound24654 : H12AffineFastState.Bounded env24654 := by
  intro p hp
  have h : env24654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24653_24654 : H12AffineEnvironment.transform 11 1045 env24653 = env24654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24653 == env24654) = true)

theorem identity24654 : scanCanonicalize (H12AffineFastState.compose env24654 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24654 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24655 : List Nat := [2,4,8,16,0,17,8,4,1,1024,2048,1045,8,17,1,3,1,2048,1025,0,1028,0,17,3,8,16,2048,1,1045,2048,1025,0,5,1,17,0]

theorem envBound24655 : H12AffineFastState.Bounded env24655 := by
  intro p hp
  have h : env24655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24654_24655 : H12AffineEnvironment.transform 4 0 env24654 = env24655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24654 == env24655) = true)

theorem identity24655 : scanCanonicalize (H12AffineFastState.compose env24655 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24655 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24656 : List Nat := [2,4,8,16,0,17,8,4,1,20,2048,1,8,17,1,3,1,2048,21,0,16,0,17,3,8,16,2048,1,1,2048,21,0,5,1,17,0]

theorem envBound24656 : H12AffineFastState.Bounded env24656 := by
  intro p hp
  have h : env24656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24655_24656 : H12AffineEnvironment.transform 9 20 env24655 = env24656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24655 == env24656) = true)

theorem identity24656 : scanCanonicalize (H12AffineFastState.compose env24656 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound24656 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24657 : List Nat := [2,4,8,16,0,17,8,4,1,20,0,1,8,17,1,3,1,0,21,0,16,0,17,3,8,16,0,1,1,0,21,0,5,1,17,0]

theorem envBound24657 : H12AffineFastState.Bounded env24657 := by
  intro p hp
  have h : env24657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24656_24657 : H12AffineEnvironment.transform 10 0 env24656 = env24657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24656 == env24657) = true)

def env24658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,2155580,2212871,2188617,8192,65,2223435,57677,102742,2190398,75103,2155581,257,2188650,2196550,513]

theorem envBound24658 : H12AffineFastState.Bounded env24658 := by
  intro p hp
  have h : env24658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24644_24658 : H12AffineEnvironment.transform 17 10281 env24644 = env24658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24644 == env24658) = true)

theorem identity24658 : scanCanonicalize (H12AffineFastState.compose env24658 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24658 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1025,32769,2097152,2155580,2155532,2114882,8192,65,2149696,57677,45405,2116661,1364,2155581,257,2114913,2139213,513]

theorem envBound24659 : H12AffineFastState.Bounded env24659 := by
  intro p hp
  have h : env24659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24658_24659 : H12AffineEnvironment.transform 15 8203 env24658 = env24659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24658 == env24659) = true)

theorem identity24659 : scanCanonicalize (H12AffineFastState.compose env24659 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound24659 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24660 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,10281,1025,29004,2097152,2102641,2102593,2114882,8192,65,2112525,4096,16400,2116661,1364,2102640,257,2114913,2118912,513]

theorem envBound24660 : H12AffineFastState.Bounded env24660 := by
  intro p hp
  have h : env24660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24659_24660 : H12AffineEnvironment.transform 14 29005 env24659 = env24660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env24659 == env24660) = true)

theorem identity24660 : scanCanonicalize (H12AffineFastState.compose env24660 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(20+1) ^^^ 11625) := by decide +kernel

theorem selectedBound24660 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env24661 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,10281,1025,29004,11625,14360,14376,26667,8192,65,4452,4096,16400,24924,1364,14361,257,26632,30825,513]

theorem envBound24661 : H12AffineFastState.Bounded env24661 := by
  intro p hp
  have h : env24661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24660_24661 : H12AffineEnvironment.transform 20 11625 env24660 = env24661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11625 env24660 == env24661) = true)

theorem identity24661 : scanCanonicalize (H12AffineFastState.compose env24661 (packedSelected [11,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound24661 : packedSelected [11,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env24662 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,23809,3143,16400,1125,1025,23808,293,5204,5220,17511,3148,65,4452,4096,16400,19728,1364,5205,257,17476,21541,513]

theorem envBound24662 : H12AffineFastState.Bounded env24662 := by
  intro p hp
  have h : env24662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24661_24662 : H12AffineEnvironment.transform 12 3148 env24661 = env24662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env24661 == env24662) = true)

theorem identity24662 : scanCanonicalize (H12AffineFastState.compose env24662 (packedSelected [21] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound24662 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env24663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,16384,18804,3143,16400,1125,1025,18805,293,33,17,17511,3148,65,1297,1141,16400,19728,1364,32,257,17476,16464,513]

theorem envBound24663 : H12AffineFastState.Bounded env24663 := by
  intro p hp
  have h : env24663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24662_24663 : H12AffineEnvironment.transform 11 1141 env24662 = env24663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env24662 == env24663) = true)

theorem identity24663 : scanCanonicalize (H12AffineFastState.compose env24663 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 2129) := by decide +kernel

theorem selectedBound24663 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,3148,2129,293,3143,2113,1125,1025,292,293,33,17,3126,3148,65,1297,1141,2113,1345,1364,32,257,3093,2049,513]

theorem envBound24664 : H12AffineFastState.Bounded env24664 := by
  intro p hp
  have h : env24664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24663_24664 : H12AffineEnvironment.transform 13 2129 env24663 = env24664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2129 env24663 == env24664) = true)

theorem identity24664 : scanCanonicalize (H12AffineFastState.compose env24664 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound24664 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,560,1141,1660,609,293,1655,625,1125,1025,292,293,33,17,1542,1660,65,1297,1141,625,1345,1364,32,257,1573,561,513]

theorem envBound24665 : H12AffineFastState.Bounded env24665 := by
  intro p hp
  have h : env24665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24664_24665 : H12AffineEnvironment.transform 10 560 env24664 = env24665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env24664 == env24665) = true)

theorem identity24665 : scanCanonicalize (H12AffineFastState.compose env24665 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound24665 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env24666 : List Nat := [2,4,8,16,32,64,8,256,512,336,560,293,812,609,293,807,625,309,337,292,293,33,17,854,812,65,65,293,625,17,4,32,257,885,561,513]

theorem envBound24666 : H12AffineFastState.Bounded env24666 := by
  intro p hp
  have h : env24666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24665_24666 : H12AffineEnvironment.transform 9 336 env24665 = env24666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env24665 == env24666) = true)

theorem identity24666 : scanCanonicalize (H12AffineFastState.compose env24666 (packedSelected [0,1,3,4,5,6,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound24666 : packedSelected [0,1,3,4,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env24667 : List Nat := [2,4,8,16,32,64,8,100,512,52,560,65,584,609,65,579,625,81,53,64,65,33,17,562,584,65,65,65,625,17,4,32,101,529,561,513]

theorem envBound24667 : H12AffineFastState.Bounded env24667 := by
  intro p hp
  have h : env24667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24666_24667 : H12AffineEnvironment.transform 7 100 env24666 = env24667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env24666 == env24667) = true)

theorem identity24667 : scanCanonicalize (H12AffineFastState.compose env24667 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24667 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24668 : List Nat := [2,4,8,16,32,16,8,52,512,52,560,17,536,561,17,531,545,1,53,16,17,33,17,562,536,17,17,17,545,17,4,32,53,529,561,513]

theorem envBound24668 : H12AffineFastState.Bounded env24668 := by
  intro p hp
  have h : env24668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24667_24668 : H12AffineEnvironment.transform 5 16 env24667 = env24668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24667 == env24668) = true)

theorem identity24668 : scanCanonicalize (H12AffineFastState.compose env24668 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound24668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24669 : List Nat := [2,4,8,16,32,16,8,52,16,52,32,17,8,33,17,3,49,1,53,16,17,33,17,34,8,17,17,17,49,17,4,32,53,1,33,17]

theorem envBound24669 : H12AffineFastState.Bounded env24669 := by
  intro p hp
  have h : env24669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24668_24669 : H12AffineEnvironment.transform 8 16 env24668 = env24669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env24668 == env24669) = true)

theorem identity24669 : scanCanonicalize (H12AffineFastState.compose env24669 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24669 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env24670 : List Nat := [2,4,8,1,32,1,8,37,1,37,32,0,8,33,0,3,32,1,36,1,0,33,0,34,8,0,0,0,32,0,4,32,36,1,33,0]

theorem envBound24670 : H12AffineFastState.Bounded env24670 := by
  intro p hp
  have h : env24670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24669_24670 : H12AffineEnvironment.transform 3 1 env24669 = env24670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24669 == env24670) = true)

theorem identity24670 : scanCanonicalize (H12AffineFastState.compose env24670 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24671 : List Nat := [2,4,8,1,0,1,8,5,1,5,0,0,8,1,0,3,0,1,4,1,0,1,0,2,8,0,0,0,0,0,4,0,4,1,1,0]

theorem envBound24671 : H12AffineFastState.Bounded env24671 := by
  intro p hp
  have h : env24671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24670_24671 : H12AffineEnvironment.transform 4 0 env24670 = env24671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24670 == env24671) = true)

def env24672 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155581,2485294,2559344,8193,65,2475363,428405,375167,2305070,222543,2526212,257,2303355,2344022,147984]

theorem envBound24672 : H12AffineFastState.Bounded env24672 := by
  intro p hp
  have h : env24672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24642_24672 : H12AffineEnvironment.transform 6 9 env24642 = env24672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24642 == env24672) = true)

theorem identity24672 : scanCanonicalize (H12AffineFastState.compose env24672 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182629) := by decide +kernel

theorem selectedBound24672 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env24673 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182629,1025,32769,2097152,2155581,2303307,2212885,8193,65,2296838,16400,225306,2305070,222543,2114913,257,2303355,2344022,147984]

theorem envBound24673 : H12AffineFastState.Bounded env24673 := by
  intro p hp
  have h : env24673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24672_24673 : H12AffineEnvironment.transform 17 182629 env24672 = env24673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182629 env24672 == env24673) = true)

theorem identity24673 : scanCanonicalize (H12AffineFastState.compose env24673 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound24673 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env24674 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,108926,1025,32769,2097152,2155581,2114896,2212885,8193,65,2124829,16400,4097,2116661,1364,2114913,257,2114912,2139213,74251]

theorem envBound24674 : H12AffineFastState.Bounded env24674 := by
  intro p hp
  have h : env24674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24673_24674 : H12AffineEnvironment.transform 16 90139 env24673 = env24674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env24673 == env24674) = true)

theorem identity24674 : scanCanonicalize (H12AffineFastState.compose env24674 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound24674 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env24675 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,90139,76078,1025,81,2097152,2122861,2114896,2180165,8193,65,2124829,16400,4097,2116661,1364,2114913,257,2114912,2106397,74251]

theorem envBound24675 : H12AffineFastState.Bounded env24675 := by
  intro p hp
  have h : env24675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24674_24675 : H12AffineEnvironment.transform 14 80 env24674 = env24675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env24674 == env24675) = true)

theorem identity24675 : scanCanonicalize (H12AffineFastState.compose env24675 (packedSelected [3,10,16,19,20,21,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24675 : packedSelected [3,10,16,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env24676 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,65536,82198,67619,1025,81,2097152,2114912,2114896,2180165,268,65,2116880,16400,4097,2116661,1364,2114913,257,2114912,2098448,66310]

theorem envBound24676 : H12AffineFastState.Bounded env24676 := by
  intro p hp
  have h : env24676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24675_24676 : H12AffineEnvironment.transform 12 269 env24675 = env24676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24675 == env24676) = true)

theorem identity24676 : scanCanonicalize (H12AffineFastState.compose env24676 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(20+1) ^^^ 69682) := by decide +kernel

theorem selectedBound24676 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env24677 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,65536,82198,67619,1025,81,69682,87378,87394,21623,268,65,89378,16400,4097,89095,1364,87379,257,87378,70946,66310]

theorem envBound24677 : H12AffineFastState.Bounded env24677 := by
  intro p hp
  have h : env24677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24676_24677 : H12AffineEnvironment.transform 20 69682 env24676 = env24677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69682 env24676 == env24677) = true)

theorem identity24677 : scanCanonicalize (H12AffineFastState.compose env24677 (packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 21874) := by decide +kernel

theorem selectedBound24677 : packedSelected [0,1,3,4,5,7,8,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env24678 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,80,21874,5220,23889,1025,81,17728,32,16,21623,268,65,2128,16400,4097,2421,1364,33,257,32,16464,22132]

theorem envBound24678 : H12AffineFastState.Bounded env24678 := by
  intro p hp
  have h : env24678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24677_24678 : H12AffineEnvironment.transform 15 21874 env24677 = env24678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21874 env24677 == env24678) = true)

theorem identity24678 : scanCanonicalize (H12AffineFastState.compose env24678 (packedSelected [1,2,8,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24678 : packedSelected [1,2,8,10,16] rootPS < 2^1333 := by decide +kernel

def env24679 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,121,16384,80,21510,5220,23589,1025,81,17460,32,16,21623,120,65,2128,16400,4097,2049,1056,33,117,32,16464,22132]

theorem envBound24679 : H12AffineFastState.Bounded env24679 := by
  intro p hp
  have h : env24679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24678_24679 : H12AffineEnvironment.transform 7 116 env24678 = env24679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24678 == env24679) = true)

def env24680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155700,2485294,2559345,8328,65,2475499,428541,375167,2305070,222542,2526213,257,2303475,2344023,148120]

theorem envBound24680 : H12AffineFastState.Bounded env24680 := by
  intro p hp
  have h : env24680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24641_24680 : H12AffineEnvironment.transform 23 2559345 env24641 = env24680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env24641 == env24680) = true)

theorem identity24680 : scanCanonicalize (H12AffineFastState.compose env24680 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24680 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,2559345,8192,65,2475363,428405,375167,2305070,222542,2526213,257,2303355,2344023,147984]

theorem envBound24681 : H12AffineFastState.Bounded env24681 := by
  intro p hp
  have h : env24681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24680_24681 : H12AffineEnvironment.transform 6 8 env24680 = env24681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24680 == env24681) = true)

theorem identity24681 : scanCanonicalize (H12AffineFastState.compose env24681 (packedSelected [1,17,19,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound24681 : packedSelected [1,17,19,28,31] rootPS < 2^1333 := by decide +kernel

def env24682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,2097152,2155580,2327575,2188616,8192,65,2338138,57676,250182,2305070,222542,2155580,257,2303355,2344023,147984]

theorem envBound24682 : H12AffineFastState.Bounded env24682 := by
  intro p hp
  have h : env24682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24681_24682 : H12AffineEnvironment.transform 17 157753 env24681 = env24682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env24681 == env24682) = true)

theorem identity24682 : scanCanonicalize (H12AffineFastState.compose env24682 (packedSelected [0,2,3,6,7,8,11,12,15,16,17,19,23,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound24682 : packedSelected [0,2,3,6,7,8,11,12,15,16,17,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env24683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,115734,73770,147457,41310,8192,65,158028,57676,250182,190520,222542,73770,257,188781,131137,147984]

theorem envBound24683 : H12AffineFastState.Bounded env24683 := by
  intro p hp
  have h : env24683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24682_24683 : H12AffineEnvironment.transform 20 115734 env24682 = env24683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env24682 == env24683) = true)

theorem identity24683 : scanCanonicalize (H12AffineFastState.compose env24683 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24683 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115734,73770,16,41310,8192,65,10589,57676,102743,43049,75103,73770,257,41340,16464,513]

theorem envBound24684 : H12AffineFastState.Bounded env24684 := by
  intro p hp
  have h : env24684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24683_24684 : H12AffineEnvironment.transform 16 16401 env24683 = env24684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24683 == env24684) = true)

theorem identity24684 : scanCanonicalize (H12AffineFastState.compose env24684 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound24684 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8283,16401,10280,1025,32769,58445,113,16,41310,8192,65,10589,57676,45324,43049,1284,113,257,41340,16464,513]

theorem envBound24685 : H12AffineFastState.Bounded env24685 := by
  intro p hp
  have h : env24685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24684_24685 : H12AffineEnvironment.transform 15 8283 env24684 = env24685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env24684 == env24685) = true)

theorem identity24685 : scanCanonicalize (H12AffineFastState.compose env24685 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound24685 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24686 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,8283,16401,10280,1025,81,25629,113,16,8462,8192,65,10589,24860,12636,10361,1284,113,257,8492,16464,513]

theorem envBound24686 : H12AffineFastState.Bounded env24686 := by
  intro p hp
  have h : env24686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24685_24686 : H12AffineEnvironment.transform 14 80 env24685 = env24686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env24685 == env24686) = true)

theorem identity24686 : scanCanonicalize (H12AffineFastState.compose env24686 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24686 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env24687 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,0,8203,16401,10280,1025,1,25629,33,16,8462,8192,17,10509,24860,12556,10281,1284,33,257,8492,16384,513]

theorem envBound24687 : H12AffineFastState.Bounded env24687 := by
  intro p hp
  have h : env24687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24686_24687 : H12AffineEnvironment.transform 5 16 env24686 = env24687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24686 == env24687) = true)

theorem identity24687 : scanCanonicalize (H12AffineFastState.compose env24687 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24687 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24688 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16401,2341,1025,1,17680,33,16,3,269,17,2048,16401,4097,2340,1284,33,257,33,16384,513]

theorem envBound24688 : H12AffineFastState.Bounded env24688 := by
  intro p hp
  have h : env24688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24687_24688 : H12AffineEnvironment.transform 12 269 env24687 = env24688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24687 == env24688) = true)

theorem identity24688 : scanCanonicalize (H12AffineFastState.compose env24688 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24688 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24689 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,16384,0,262,16401,2341,273,1,16384,33,16,3,269,17,2048,16401,4097,2340,20,33,257,33,16384,513]

theorem envBound24689 : H12AffineFastState.Bounded env24689 := by
  intro p hp
  have h : env24689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24688_24689 : H12AffineEnvironment.transform 9 272 env24688 = env24689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24688 == env24689) = true)

theorem identity24689 : scanCanonicalize (H12AffineFastState.compose env24689 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound24689 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24690 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2587,269,16384,0,262,16401,2341,273,1,16384,33,16,3,269,17,2048,16401,2586,2340,20,33,257,33,16384,513]

theorem envBound24690 : H12AffineFastState.Bounded env24690 := by
  intro p hp
  have h : env24690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24689_24690 : H12AffineEnvironment.transform 11 2587 env24689 = env24690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env24689 == env24690) = true)

theorem identity24690 : scanCanonicalize (H12AffineFastState.compose env24690 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound24690 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24691 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,2587,269,2308,0,262,2325,2341,273,1,2308,33,16,3,269,17,2048,2325,2586,2340,20,33,257,33,2308,513]

theorem envBound24691 : H12AffineFastState.Bounded env24691 := by
  intro p hp
  have h : env24691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24690_24691 : H12AffineEnvironment.transform 13 2308 env24690 = env24691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env24690 == env24691) = true)

theorem identity24691 : scanCanonicalize (H12AffineFastState.compose env24691 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound24691 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24692 : List Nat := [2,4,8,16,32,16,8,256,512,272,260,799,269,0,0,262,17,33,273,1,0,33,16,3,269,17,260,17,798,32,20,33,257,33,0,513]

theorem envBound24692 : H12AffineFastState.Bounded env24692 := by
  intro p hp
  have h : env24692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24691_24692 : H12AffineEnvironment.transform 10 260 env24691 = env24692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env24691 == env24692) = true)

theorem identity24692 : scanCanonicalize (H12AffineFastState.compose env24692 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound24692 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24693 : List Nat := [2,4,8,16,32,16,8,256,302,272,260,49,269,0,0,262,17,33,273,1,0,33,16,3,269,17,260,17,48,32,20,33,257,33,0,303]

theorem envBound24693 : H12AffineFastState.Bounded env24693 := by
  intro p hp
  have h : env24693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24692_24693 : H12AffineEnvironment.transform 8 302 env24692 = env24693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env24692 == env24693) = true)

theorem identity24693 : scanCanonicalize (H12AffineFastState.compose env24693 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24693 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24694 : List Nat := [2,4,8,16,0,16,8,256,270,272,260,17,269,0,0,262,17,1,273,1,0,1,16,3,269,17,260,17,16,0,20,1,257,1,0,271]

theorem envBound24694 : H12AffineFastState.Bounded env24694 := by
  intro p hp
  have h : env24694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24693_24694 : H12AffineEnvironment.transform 4 0 env24693 = env24694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24693 == env24694) = true)

theorem identity24694 : scanCanonicalize (H12AffineFastState.compose env24694 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24694 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env24695 : List Nat := [2,4,8,16,0,16,8,5,11,21,1,17,8,0,0,3,17,1,20,1,0,1,16,3,8,17,1,17,16,0,20,1,4,1,0,10]

theorem envBound24695 : H12AffineFastState.Bounded env24695 := by
  intro p hp
  have h : env24695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24694_24695 : H12AffineEnvironment.transform 7 5 env24694 = env24695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24694 == env24695) = true)

theorem identity24695 : scanCanonicalize (H12AffineFastState.compose env24695 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24696 : List Nat := [2,0,8,16,0,16,8,1,11,17,1,17,8,0,0,3,17,1,16,1,0,1,16,3,8,17,1,17,16,0,16,1,0,1,0,10]

theorem envBound24696 : H12AffineFastState.Bounded env24696 := by
  intro p hp
  have h : env24696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24695_24696 : H12AffineEnvironment.transform 1 0 env24695 = env24696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24695 == env24696) = true)

theorem identity24696 : scanCanonicalize (H12AffineFastState.compose env24696 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound24696 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24697 : List Nat := [2,0,8,8,0,8,8,1,11,9,1,9,8,0,0,3,9,1,8,1,0,1,8,3,8,9,1,9,8,0,8,1,0,1,0,10]

theorem envBound24697 : H12AffineFastState.Bounded env24697 := by
  intro p hp
  have h : env24697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24696_24697 : H12AffineEnvironment.transform 3 8 env24696 = env24697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env24696 == env24697) = true)

def env24698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,16777216,8328,65,16959643,18973836,375167,2305070,19163199,16875893,257,17049730,17090854,19222505]

theorem envBound24698 : H12AffineFastState.Bounded env24698 := by
  intro p hp
  have h : env24698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24640_24698 : H12AffineEnvironment.transform 21 2155701 env24640 = env24698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155701 env24640 == env24698) = true)

def env24699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,2559344,8328,65,2475499,428540,375167,2305070,222543,2526213,257,2303474,2344022,148121]

theorem envBound24699 : H12AffineFastState.Bounded env24699 := by
  intro p hp
  have h : env24699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24698_24699 : H12AffineEnvironment.transform 23 2559344 env24698 = env24699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559344 env24698 == env24699) = true)

theorem identity24699 : scanCanonicalize (H12AffineFastState.compose env24699 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388279) := by decide +kernel

theorem selectedBound24699 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388279,329730,153,188871,8328,65,10588,428540,375167,442521,222543,221362,257,444741,403681,148121]

theorem envBound24700 : H12AffineFastState.Bounded env24700 := by
  intro p hp
  have h : env24700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24699_24700 : H12AffineEnvironment.transform 20 388279 env24699 = env24700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388279 env24699 == env24700) = true)

theorem identity24700 : scanCanonicalize (H12AffineFastState.compose env24700 (packedSelected [3,10,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound24700 : packedSelected [3,10,21,24,26] rootPS < 2^1333 := by decide +kernel

def env24701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,17,188751,8192,65,10588,428404,375167,442385,222543,221242,257,444741,403561,147985]

theorem envBound24701 : H12AffineFastState.Bounded env24701 := by
  intro p hp
  have h : env24701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24700_24701 : H12AffineEnvironment.transform 6 8 env24700 = env24701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24700 == env24701) = true)

theorem identity24701 : scanCanonicalize (H12AffineFastState.compose env24701 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24701 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,388159,329730,17,41311,8192,65,10588,313700,375167,294913,75103,73770,257,297301,288889,513]

theorem envBound24702 : H12AffineFastState.Bounded env24702 := by
  intro p hp
  have h : env24702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24701_24702 : H12AffineEnvironment.transform 16 16400 env24701 = env24702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24701 == env24702) = true)

theorem identity24702 : scanCanonicalize (H12AffineFastState.compose env24702 (packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24702 : packedSelected [2,4,6,7,9,11,17,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env24703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,16400,262144,1025,32769,380258,329730,17,32770,349,65,2049,313700,366626,294913,66562,65911,257,297301,280868,513]

theorem envBound24703 : H12AffineFastState.Bounded env24703 := by
  intro p hp
  have h : env24703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24702_24703 : H12AffineEnvironment.transform 12 349 env24702 = env24703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24702 == env24703) = true)

def env24704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155701,2485294,2559345,8328,65,2475498,428541,375167,2305070,222542,2526212,257,2303475,2344023,148120]

theorem envBound24704 : H12AffineFastState.Bounded env24704 := by
  intro p hp
  have h : env24704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24698_24704 : H12AffineEnvironment.transform 23 2559345 env24698 = env24704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2559345 env24698 == env24704) = true)

theorem identity24704 : scanCanonicalize (H12AffineFastState.compose env24704 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388159) := by decide +kernel

theorem selectedBound24704 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env24705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329866,17,188750,8328,65,10709,428541,375167,442385,222542,221243,257,444876,403560,148120]

theorem envBound24705 : H12AffineFastState.Bounded env24705 := by
  intro p hp
  have h : env24705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24704_24705 : H12AffineEnvironment.transform 20 388159 env24704 = env24705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388159 env24704 == env24705) = true)

def env24706 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329730,17,188750,8192,65,10589,428405,375167,442385,222542,221243,257,444740,403560,147984]

theorem envBound24706 : H12AffineFastState.Bounded env24706 := by
  intro p hp
  have h : env24706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24705_24706 : H12AffineEnvironment.transform 6 8 env24705 = env24706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24705 == env24706) = true)

theorem identity24706 : scanCanonicalize (H12AffineFastState.compose env24706 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound24706 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,388159,329730,17,41311,8192,65,10589,313700,375167,294912,75103,73770,257,297301,288889,513]

theorem envBound24707 : H12AffineFastState.Bounded env24707 := by
  intro p hp
  have h : env24707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24706_24707 : H12AffineEnvironment.transform 16 16401 env24706 = env24707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env24706 == env24707) = true)

theorem identity24707 : scanCanonicalize (H12AffineFastState.compose env24707 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24707 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env24708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,115735,73770,17,41311,8192,65,10589,57676,102743,43048,75103,73770,257,41341,16465,513]

theorem envBound24708 : H12AffineFastState.Bounded env24708 := by
  intro p hp
  have h : env24708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24707_24708 : H12AffineEnvironment.transform 17 10280 env24707 = env24708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24707 == env24708) = true)

theorem identity24708 : scanCanonicalize (H12AffineFastState.compose env24708 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound24708 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1025,32769,25628,32801,17,41311,8192,65,10589,57676,12636,43048,34132,32801,257,41341,16465,513]

theorem envBound24709 : H12AffineFastState.Bounded env24709 := by
  intro p hp
  have h : env24709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24708_24709 : H12AffineEnvironment.transform 15 40971 env24708 = env24709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env24708 == env24709) = true)

theorem identity24709 : scanCanonicalize (H12AffineFastState.compose env24709 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24709 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env24710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,33110,16401,2421,1025,32769,17729,32801,17,32770,349,65,2048,49169,4097,35189,34132,32801,257,32800,16465,513]

theorem envBound24710 : H12AffineFastState.Bounded env24710 := by
  intro p hp
  have h : env24710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24709_24710 : H12AffineEnvironment.transform 12 349 env24709 = env24710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24709 == env24710) = true)

theorem identity24710 : scanCanonicalize (H12AffineFastState.compose env24710 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24710 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,343,16401,2421,1025,0,17729,32,17,3,349,65,2048,16400,4097,2420,1365,32,257,33,16465,513]

theorem envBound24711 : H12AffineFastState.Bounded env24711 := by
  intro p hp
  have h : env24711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24710_24711 : H12AffineEnvironment.transform 14 1 env24710 = env24711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24710 == env24711) = true)

theorem identity24711 : scanCanonicalize (H12AffineFastState.compose env24711 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1637) := by decide +kernel

theorem selectedBound24711 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1637,1,343,1652,2421,1025,0,804,32,17,3,349,65,2048,1653,4097,2420,1365,32,257,33,1588,513]

theorem envBound24712 : H12AffineFastState.Bounded env24712 := by
  intro p hp
  have h : env24712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24711_24712 : H12AffineEnvironment.transform 13 1637 env24711 = env24712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1637 env24711 == env24712) = true)

theorem identity24712 : scanCanonicalize (H12AffineFastState.compose env24712 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound24712 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,529,4096,349,1637,1,343,1652,868,1025,0,804,32,17,3,349,65,529,1653,4097,869,1365,32,257,33,1588,513]

theorem envBound24713 : H12AffineFastState.Bounded env24713 := by
  intro p hp
  have h : env24713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24712_24713 : H12AffineEnvironment.transform 10 529 env24712 = env24713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env24712 == env24713) = true)

theorem identity24713 : scanCanonicalize (H12AffineFastState.compose env24713 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 869) := by decide +kernel

theorem selectedBound24713 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env24714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,529,869,349,1637,1,343,1652,868,1025,0,804,32,17,3,349,65,529,1653,868,869,1365,32,257,33,1588,513]

theorem envBound24714 : H12AffineFastState.Bounded env24714 := by
  intro p hp
  have h : env24714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24713_24714 : H12AffineEnvironment.transform 11 869 env24713 = env24714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 869 env24713 == env24714) = true)

theorem identity24714 : scanCanonicalize (H12AffineFastState.compose env24714 (packedSelected [5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24714 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env24715 : List Nat := [2,4,8,16,32,17,8,256,512,1024,529,820,268,1588,1,262,1573,821,1025,0,804,32,17,3,268,16,529,1572,821,820,1284,32,257,33,1588,513]

theorem envBound24715 : H12AffineFastState.Bounded env24715 := by
  intro p hp
  have h : env24715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24714_24715 : H12AffineEnvironment.transform 5 17 env24714 = env24715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24714 == env24715) = true)

theorem identity24715 : scanCanonicalize (H12AffineFastState.compose env24715 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound24715 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24716 : List Nat := [2,4,8,16,32,17,8,256,512,37,529,820,268,529,1,262,512,821,36,0,804,32,17,3,268,16,529,513,821,820,289,32,257,33,529,513]

theorem envBound24716 : H12AffineFastState.Bounded env24716 := by
  intro p hp
  have h : env24716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24715_24716 : H12AffineEnvironment.transform 9 37 env24715 = env24716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env24715 == env24716) = true)

theorem identity24716 : scanCanonicalize (H12AffineFastState.compose env24716 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound24716 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24717 : List Nat := [2,4,8,16,32,17,8,256,292,37,309,16,268,309,1,262,292,17,36,0,0,32,17,3,268,16,309,293,17,16,289,32,257,33,309,293]

theorem envBound24717 : H12AffineFastState.Bounded env24717 := by
  intro p hp
  have h : env24717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24716_24717 : H12AffineEnvironment.transform 8 292 env24716 = env24717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env24716 == env24717) = true)

def env24718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388159,329731,17,188750,8193,65,10588,428404,375167,442385,222542,221243,257,444741,403560,147985]

theorem envBound24718 : H12AffineFastState.Bounded env24718 := by
  intro p hp
  have h : env24718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24705_24718 : H12AffineEnvironment.transform 6 9 env24705 = env24718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24705 == env24718) = true)

theorem identity24718 : scanCanonicalize (H12AffineFastState.compose env24718 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound24718 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,262144,1025,32769,388159,329731,17,3,8193,65,10588,288825,375167,270684,99331,98678,257,272392,313637,41820]

theorem envBound24719 : H12AffineFastState.Bounded env24719 := by
  intro p hp
  have h : env24719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24718_24719 : H12AffineEnvironment.transform 16 57677 env24718 = env24719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env24718 == env24719) = true)

theorem identity24719 : scanCanonicalize (H12AffineFastState.compose env24719 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24719 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env24720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,43049,1025,32769,82966,106538,17,3,8193,65,10588,49168,69974,35189,99331,98678,257,32801,24844,41820]

theorem envBound24720 : H12AffineFastState.Bounded env24720 := by
  intro p hp
  have h : env24720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24719_24720 : H12AffineEnvironment.transform 17 43049 env24719 = env24720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24719 == env24720) = true)

theorem identity24720 : scanCanonicalize (H12AffineFastState.compose env24720 (packedSelected [0,5,7,11,12,15,16,17,18,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24720 : packedSelected [0,5,7,11,12,15,16,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env24721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,65536,49168,35188,1025,32769,82966,98679,17,3,348,65,2049,49168,69974,35189,99331,98678,257,32801,16465,33281]

theorem envBound24721 : H12AffineFastState.Bounded env24721 := by
  intro p hp
  have h : env24721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24720_24721 : H12AffineEnvironment.transform 12 349 env24720 = env24721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24720 == env24721) = true)

theorem identity24721 : scanCanonicalize (H12AffineFastState.compose env24721 (packedSelected [1,3,4,5,8,9,11,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound24721 : packedSelected [1,3,4,5,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env24722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,33030,49168,35188,1025,32769,50448,113,17,3,348,65,2049,49168,36944,35189,1285,112,257,32801,16465,33281]

theorem envBound24722 : H12AffineFastState.Bounded env24722 := by
  intro p hp
  have h : env24722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24721_24722 : H12AffineEnvironment.transform 15 33030 env24721 = env24722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env24721 == env24722) = true)

theorem identity24722 : scanCanonicalize (H12AffineFastState.compose env24722 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound24722 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env24723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5156,32768,33030,37940,35188,1025,32769,37172,113,17,3,348,65,2049,37940,36944,35189,1285,112,257,32801,5237,33281]

theorem envBound24723 : H12AffineFastState.Bounded env24723 := by
  intro p hp
  have h : env24723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24722_24723 : H12AffineEnvironment.transform 13 5156 env24722 = env24723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env24722 == env24723) = true)

def env24724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound24724 : H12AffineFastState.Bounded env24724 := by
  intro p hp
  have h : env24724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23535_24724 : H12AffineEnvironment.transform 29 155254785 env23535 = env24724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env23535 == env24724) = true)

def env24725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound24725 : H12AffineFastState.Bounded env24725 := by
  intro p hp
  have h : env24725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24724_24725 : H12AffineEnvironment.transform 25 64 env24724 = env24725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env24724 == env24725) = true)

def env24726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound24726 : H12AffineFastState.Bounded env24726 := by
  intro p hp
  have h : env24726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24725_24726 : H12AffineEnvironment.transform 26 30393344 env24725 = env24726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env24725 == env24726) = true)

def env24727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound24727 : H12AffineFastState.Bounded env24727 := by
  intro p hp
  have h : env24727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24726_24727 : H12AffineEnvironment.transform 18 1024 env24726 = env24727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env24726 == env24727) = true)

theorem identity24727 : scanCanonicalize (H12AffineFastState.compose env24727 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound24727 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env24728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8328,64,13066591,2172370,10507600,8830977,8463695,6407326,256,10577395,10585175,8389273]

theorem envBound24728 : H12AffineFastState.Bounded env24728 := by
  intro p hp
  have h : env24728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24727_24728 : H12AffineEnvironment.transform 23 41311 env24727 = env24728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env24727 == env24728) = true)

def env24729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8192,64,13066591,2172250,10507600,8830977,8463695,6407190,256,10577275,10585175,8389137]

theorem envBound24729 : H12AffineFastState.Bounded env24729 := by
  intro p hp
  have h : env24729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24728_24729 : H12AffineEnvironment.transform 6 8 env24728 = env24729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env24728 == env24729) = true)

def env24730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8192,64,4677967,2172250,2118976,442385,75103,6407190,256,2188651,2196551,513]

theorem envBound24730 : H12AffineFastState.Bounded env24730 := by
  intro p hp
  have h : env24730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24729_24730 : H12AffineEnvironment.transform 22 16 env24729 = env24730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24729 == env24730) = true)

def env24731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41311,8192,64,4677967,115014,45404,442385,75103,4268042,256,98679,90203,513]

theorem envBound24731 : H12AffineFastState.Bounded env24731 := by
  intro p hp
  have h : env24731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24730_24731 : H12AffineEnvironment.transform 20 58396 env24730 = env24731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env24730 == env24731) = true)

def env24732 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41231,8192,16,4677919,114966,45324,442385,75023,4268042,256,98599,90123,513]

theorem envBound24732 : H12AffineFastState.Bounded env24732 := by
  intro p hp
  have h : env24732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24731_24732 : H12AffineEnvironment.transform 5 16 env24731 = env24732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24731 == env24732) = true)

def env24733 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,4194304,16,41231,8192,16,4409655,114966,45324,190521,75023,4268042,256,98599,90123,513]

theorem envBound24733 : H12AffineFastState.Bounded env24733 := by
  intro p hp
  have h : env24733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24732_24733 : H12AffineEnvironment.transform 17 10280 env24732 = env24733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24732 == env24733) = true)

theorem identity24733 : scanCanonicalize (H12AffineFastState.compose env24733 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 118035) := by decide +kernel

theorem selectedBound24733 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env24734 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58396,118035,16,41231,8192,16,164900,114966,45324,190521,75023,60697,256,98599,90123,513]

theorem envBound24734 : H12AffineFastState.Bounded env24734 := by
  intro p hp
  have h : env24734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24733_24734 : H12AffineEnvironment.transform 21 118035 env24733 = env24734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 118035 env24733 == env24734) = true)

theorem identity24734 : scanCanonicalize (H12AffineFastState.compose env24734 (packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound24734 : packedSelected [0,1,3,5,7,8,12,14,18,19,26] rootPS < 2^1333 := by decide +kernel

def env24735 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10280,1024,32769,58396,118035,16,41231,8192,16,123966,114966,45324,100387,75023,60697,256,98599,90123,513]

theorem envBound24735 : H12AffineFastState.Bounded env24735 := by
  intro p hp
  have h : env24735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24734_24735 : H12AffineEnvironment.transform 16 90138 env24734 = env24735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env24734 == env24735) = true)

theorem identity24735 : scanCanonicalize (H12AffineFastState.compose env24735 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 11292) := by decide +kernel

theorem selectedBound24735 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env24736 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11292,65536,90138,10280,1024,11293,18432,90383,16,3347,8192,16,84002,93450,7440,74815,75023,16645,256,77115,90123,513]

theorem envBound24736 : H12AffineFastState.Bounded env24736 := by
  intro p hp
  have h : env24736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24735_24736 : H12AffineEnvironment.transform 14 11292 env24735 = env24736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11292 env24735 == env24736) = true)

theorem identity24736 : scanCanonicalize (H12AffineFastState.compose env24736 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound24736 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24737 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,11292,8202,16400,10280,1024,11293,18432,16645,16,3347,8192,16,26664,19712,7440,1077,1285,16645,256,3377,16385,513]

theorem envBound24737 : H12AffineFastState.Bounded env24737 := by
  intro p hp
  have h : env24737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24736_24737 : H12AffineEnvironment.transform 15 8202 env24736 = env24737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env24736 == env24737) = true)

theorem identity24737 : scanCanonicalize (H12AffineFastState.compose env24737 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound24737 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24738 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,4112,11292,8202,4096,10280,1024,11293,6160,4373,16,3347,8192,16,14392,7440,7440,1077,1285,4373,256,3377,4113,513]

theorem envBound24738 : H12AffineFastState.Bounded env24738 := by
  intro p hp
  have h : env24738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24737_24738 : H12AffineEnvironment.transform 13 4112 env24737 = env24738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env24737 == env24738) = true)

theorem identity24738 : scanCanonicalize (H12AffineFastState.compose env24738 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5416) := by decide +kernel

theorem selectedBound24738 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env24739 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,5416,4112,6452,5410,4096,7424,1024,6453,6160,4373,16,3347,5416,16,3344,7440,7440,1077,1285,4373,256,3377,4113,513]

theorem envBound24739 : H12AffineFastState.Bounded env24739 := by
  intro p hp
  have h : env24739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24738_24739 : H12AffineEnvironment.transform 12 5416 env24738 = env24739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5416 env24738 == env24739) = true)

theorem identity24739 : scanCanonicalize (H12AffineFastState.compose env24739 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound24739 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24740 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3328,2088,3344,1076,2082,3328,0,1024,1077,1296,3093,16,3347,2088,16,3344,16,16,1077,1285,3093,256,3377,3345,513]

theorem envBound24740 : H12AffineFastState.Bounded env24740 := by
  intro p hp
  have h : env24740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24739_24740 : H12AffineEnvironment.transform 11 3328 env24739 = env24740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env24739 == env24740) = true)

theorem identity24740 : scanCanonicalize (H12AffineFastState.compose env24740 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound24740 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env24741 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1589,821,1565,805,1076,1559,821,0,1024,1077,1296,544,16,806,1565,16,805,16,16,1077,1285,544,256,772,804,513]

theorem envBound24741 : H12AffineFastState.Bounded env24741 := by
  intro p hp
  have h : env24741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24740_24741 : H12AffineEnvironment.transform 10 1589 env24740 = env24741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env24740 == env24741) = true)

theorem identity24741 : scanCanonicalize (H12AffineFastState.compose env24741 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound24741 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env24742 : List Nat := [2,4,8,16,32,16,8,256,512,52,513,821,553,805,0,547,821,0,52,1,292,544,16,806,553,16,805,16,16,1,305,544,256,772,804,513]

theorem envBound24742 : H12AffineFastState.Bounded env24742 := by
  intro p hp
  have h : env24742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24741_24742 : H12AffineEnvironment.transform 9 52 env24741 = env24742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24741 == env24742) = true)

theorem identity24742 : scanCanonicalize (H12AffineFastState.compose env24742 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24742 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env24743 : List Nat := [2,4,8,16,32,16,8,37,512,52,513,528,553,512,0,547,528,0,52,1,1,544,16,515,553,16,512,16,16,1,20,544,37,545,513,513]

theorem envBound24743 : H12AffineFastState.Bounded env24743 := by
  intro p hp
  have h : env24743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24742_24743 : H12AffineEnvironment.transform 7 37 env24742 = env24743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24742 == env24743) = true)

theorem identity24743 : scanCanonicalize (H12AffineFastState.compose env24743 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound24743 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24744 : List Nat := [2,4,8,16,17,16,8,20,512,5,513,528,536,512,0,530,528,0,5,1,1,529,16,515,536,16,512,16,16,1,20,529,20,528,513,513]

theorem envBound24744 : H12AffineFastState.Bounded env24744 := by
  intro p hp
  have h : env24744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24743_24744 : H12AffineEnvironment.transform 4 17 env24743 = env24744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env24743 == env24744) = true)

theorem identity24744 : scanCanonicalize (H12AffineFastState.compose env24744 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound24744 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24745 : List Nat := [2,4,8,16,17,16,8,20,1,5,0,17,25,1,0,19,17,0,5,1,1,16,16,2,25,16,1,16,16,1,20,16,20,17,0,0]

theorem envBound24745 : H12AffineFastState.Bounded env24745 := by
  intro p hp
  have h : env24745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24744_24745 : H12AffineEnvironment.transform 8 1 env24744 = env24745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env24744 == env24745) = true)

theorem identity24745 : scanCanonicalize (H12AffineFastState.compose env24745 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24746 : List Nat := [2,4,8,1,0,1,8,5,1,5,0,0,8,1,0,2,0,0,5,1,1,1,1,2,8,1,1,1,1,1,5,1,5,0,0,0]

theorem envBound24746 : H12AffineFastState.Bounded env24746 := by
  intro p hp
  have h : env24746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24745_24746 : H12AffineEnvironment.transform 3 1 env24745 = env24746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24745 == env24746) = true)

def env24747 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41231,8192,16,4409654,114966,45324,190520,75023,4268042,256,98599,90123,513]

theorem envBound24747 : H12AffineFastState.Bounded env24747 := by
  intro p hp
  have h : env24747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24732_24747 : H12AffineEnvironment.transform 17 10281 env24732 = env24747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24732 == env24747) = true)

theorem identity24747 : scanCanonicalize (H12AffineFastState.compose env24747 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound24747 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env24748 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,246071,16,41231,8192,16,34817,114966,45324,190520,75023,188733,256,98599,90123,513]

theorem envBound24748 : H12AffineFastState.Bounded env24748 := by
  intro p hp
  have h : env24748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24747_24748 : H12AffineEnvironment.transform 21 246071 env24747 = env24748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env24747 == env24748) = true)

theorem identity24748 : scanCanonicalize (H12AffineFastState.compose env24748 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound24748 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env24749 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,114966,10281,1024,32769,58396,33,16,41231,8192,16,34817,114966,45324,76078,75023,73771,256,98599,90123,513]

theorem envBound24749 : H12AffineFastState.Bounded env24749 := by
  intro p hp
  have h : env24749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24748_24749 : H12AffineEnvironment.transform 16 114966 env24748 = env24749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env24748 == env24749) = true)

theorem identity24749 : scanCanonicalize (H12AffineFastState.compose env24749 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound24749 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env24750 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,49169,10281,1024,32769,58396,33,16,41231,8192,16,34817,49169,45324,10281,9224,8492,256,32800,24844,513]

theorem envBound24750 : H12AffineFastState.Bounded env24750 := by
  intro p hp
  have h : env24750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24749_24750 : H12AffineEnvironment.transform 15 263 env24749 = env24750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env24749 == env24750) = true)

theorem identity24750 : scanCanonicalize (H12AffineFastState.compose env24750 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound24750 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24751 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,263,24861,10281,1024,8461,17680,33,16,3,8192,16,10509,24861,4096,10281,9224,8492,256,8492,24844,513]

theorem envBound24751 : H12AffineFastState.Bounded env24751 := by
  intro p hp
  have h : env24751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24750_24751 : H12AffineEnvironment.transform 14 8460 env24750 = env24751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env24750 == env24751) = true)

theorem identity24751 : scanCanonicalize (H12AffineFastState.compose env24751 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound24751 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24752 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1024,1,17680,33,16,3,268,16,2049,16401,4096,2341,1284,32,256,32,16384,513]

theorem envBound24752 : H12AffineFastState.Bounded env24752 := by
  intro p hp
  have h : env24752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24751_24752 : H12AffineEnvironment.transform 12 268 env24751 = env24752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env24751 == env24752) = true)

theorem identity24752 : scanCanonicalize (H12AffineFastState.compose env24752 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24752 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24753 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,17,268,16384,0,263,16401,2341,1024,1,17680,33,16,3,268,16,2049,16401,17,2341,1284,32,256,32,16384,513]

theorem envBound24753 : H12AffineFastState.Bounded env24753 := by
  intro p hp
  have h : env24753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24752_24753 : H12AffineEnvironment.transform 11 17 env24752 = env24753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24752 == env24753) = true)

theorem identity24753 : scanCanonicalize (H12AffineFastState.compose env24753 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound24753 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24754 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,17,268,16384,0,263,16401,2341,272,1,16384,33,16,3,268,16,2049,16401,17,2341,20,32,256,32,16384,513]

theorem envBound24754 : H12AffineFastState.Bounded env24754 := by
  intro p hp
  have h : env24754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24753_24754 : H12AffineEnvironment.transform 9 272 env24753 = env24754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env24753 == env24754) = true)

theorem identity24754 : scanCanonicalize (H12AffineFastState.compose env24754 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24754 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24755 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,268,16384,0,263,16401,292,272,1,16384,33,16,3,268,16,0,16401,17,292,20,32,256,32,16384,513]

theorem envBound24755 : H12AffineFastState.Bounded env24755 := by
  intro p hp
  have h : env24755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24754_24755 : H12AffineEnvironment.transform 10 1 env24754 = env24755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24754 == env24755) = true)

theorem identity24755 : scanCanonicalize (H12AffineFastState.compose env24755 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24755 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env24756 : List Nat := [2,4,8,16,32,16,8,37,512,53,1,17,41,16384,0,34,16401,1,53,1,16384,33,16,3,41,16,0,16401,17,1,20,32,37,32,16384,513]

theorem envBound24756 : H12AffineFastState.Bounded env24756 := by
  intro p hp
  have h : env24756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24755_24756 : H12AffineEnvironment.transform 7 37 env24755 = env24756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24755 == env24756) = true)

def env24757 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58396,4194304,16,41230,8192,17,4677918,114967,45325,442385,75022,4268042,256,98598,90122,513]

theorem envBound24757 : H12AffineFastState.Bounded env24757 := by
  intro p hp
  have h : env24757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24731_24757 : H12AffineEnvironment.transform 5 17 env24731 = env24757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24731 == env24757) = true)

theorem identity24757 : scanCanonicalize (H12AffineFastState.compose env24757 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound24757 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env24758 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4409655,114967,45325,190520,75022,4268042,256,98598,90122,513]

theorem envBound24758 : H12AffineFastState.Bounded env24758 := by
  intro p hp
  have h : env24758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24757_24758 : H12AffineEnvironment.transform 17 10281 env24757 = env24758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env24757 == env24758) = true)

theorem identity24758 : scanCanonicalize (H12AffineFastState.compose env24758 (packedSelected [0,3,7,12,14,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound24758 : packedSelected [0,3,7,12,14,18,24] rootPS < 2^1333 := by decide +kernel

def env24759 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,4194304,16,41230,8192,17,4385084,24860,45325,190520,34053,4227073,256,8493,49153,513]

theorem envBound24759 : H12AffineFastState.Bounded env24759 := by
  intro p hp
  have h : env24759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24758_24759 : H12AffineEnvironment.transform 15 40971 env24758 = env24759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env24758 == env24759) = true)

theorem identity24759 : scanCanonicalize (H12AffineFastState.compose env24759 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound24759 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env24760 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,131072,10281,1024,32769,58396,147504,16,41230,8192,17,43276,24860,45325,190520,34053,180273,256,8493,49153,513]

theorem envBound24760 : H12AffineFastState.Bounded env24760 := by
  intro p hp
  have h : env24760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24759_24760 : H12AffineEnvironment.transform 21 147504 env24759 = env24760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env24759 == env24760) = true)

theorem identity24760 : scanCanonicalize (H12AffineFastState.compose env24760 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound24760 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24761 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,40971,24860,10281,1024,32769,58396,8492,16,41230,8192,17,43276,24860,45325,35108,34053,41261,256,8493,49153,513]

theorem envBound24761 : H12AffineFastState.Bounded env24761 := by
  intro p hp
  have h : env24761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24760_24761 : H12AffineEnvironment.transform 16 24860 env24760 = env24761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env24760 == env24761) = true)

def env24762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4677967,115015,45405,442385,75103,4268043,256,98678,90202,513]

theorem envBound24762 : H12AffineFastState.Bounded env24762 := by
  intro p hp
  have h : env24762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24730_24762 : H12AffineEnvironment.transform 20 58397 env24730 = env24762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env24730 == env24762) = true)

theorem identity24762 : scanCanonicalize (H12AffineFastState.compose env24762 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound24762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env24763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,4194304,16,41311,8192,64,4604228,57676,45405,442385,1364,4194304,256,41341,16465,513]

theorem envBound24763 : H12AffineFastState.Bounded env24763 := by
  intro p hp
  have h : env24763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24762_24763 : H12AffineEnvironment.transform 15 8203 env24762 = env24763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env24762 == env24763) = true)

theorem identity24763 : scanCanonicalize (H12AffineFastState.compose env24763 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 419912) := by decide +kernel

theorem selectedBound24763 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env24764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,58397,419912,16,41311,8192,64,10508,57676,45405,442385,1364,419912,256,41341,16465,513]

theorem envBound24764 : H12AffineFastState.Bounded env24764 := by
  intro p hp
  have h : env24764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24763_24764 : H12AffineEnvironment.transform 21 419912 env24763 = env24764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 419912 env24763 == env24764) = true)

def env24765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16448,262144,1024,32769,58397,272392,16,41311,8192,64,10508,57676,45405,294993,1364,272392,256,41341,16465,513]

theorem envBound24765 : H12AffineFastState.Bounded env24765 := by
  intro p hp
  have h : env24765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24764_24765 : H12AffineEnvironment.transform 16 16448 env24764 = env24765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env24764 == env24765) = true)

theorem identity24765 : scanCanonicalize (H12AffineFastState.compose env24765 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound24765 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16448,262144,1024,0,25628,272392,16,8542,8192,64,10508,24909,12636,262224,1364,272392,256,8572,16465,513]

theorem envBound24766 : H12AffineFastState.Bounded env24766 := by
  intro p hp
  have h : env24766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24765_24766 : H12AffineEnvironment.transform 14 1 env24765 = env24766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env24765 == env24766) = true)

theorem identity24766 : scanCanonicalize (H12AffineFastState.compose env24766 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound24766 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8203,16448,10361,1024,0,25628,113,16,8542,8192,64,10508,24909,12636,10281,1364,113,256,8572,16465,513]

theorem envBound24767 : H12AffineFastState.Bounded env24767 := by
  intro p hp
  have h : env24767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24766_24767 : H12AffineEnvironment.transform 17 10361 env24766 = env24767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env24766 == env24767) = true)

theorem identity24767 : scanCanonicalize (H12AffineFastState.compose env24767 (packedSelected [11,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound24767 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env24768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,262,16448,2420,1024,0,17681,113,16,83,269,64,2049,16448,4177,2340,1364,113,256,113,16465,513]

theorem envBound24768 : H12AffineFastState.Bounded env24768 := by
  intro p hp
  have h : env24768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24767_24768 : H12AffineEnvironment.transform 12 269 env24767 = env24768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env24767 == env24768) = true)

theorem identity24768 : scanCanonicalize (H12AffineFastState.compose env24768 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound24768 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env24769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,0,1,262,64,2420,1024,0,1297,113,16,83,269,64,2049,64,4177,2340,1364,113,256,113,81,513]

theorem envBound24769 : H12AffineFastState.Bounded env24769 := by
  intro p hp
  have h : env24769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24768_24769 : H12AffineEnvironment.transform 13 0 env24768 = env24769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env24768 == env24769) = true)

theorem identity24769 : scanCanonicalize (H12AffineFastState.compose env24769 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24769 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env24770 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,0,1,262,16,2340,1024,0,1297,33,16,3,269,16,2049,16,4097,2340,1284,33,256,33,1,513]

theorem envBound24770 : H12AffineFastState.Bounded env24770 := by
  intro p hp
  have h : env24770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24769_24770 : H12AffineEnvironment.transform 5 16 env24769 = env24770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24769 == env24770) = true)

theorem identity24770 : scanCanonicalize (H12AffineFastState.compose env24770 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24770 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24771 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,4096,269,0,1,262,1,2340,1024,0,1280,33,1,3,269,1,2049,1,4097,2340,1284,33,256,33,1,513]

theorem envBound24771 : H12AffineFastState.Bounded env24771 := by
  intro p hp
  have h : env24771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24770_24771 : H12AffineEnvironment.transform 3 1 env24770 = env24771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24770 == env24771) = true)

theorem identity24771 : scanCanonicalize (H12AffineFastState.compose env24771 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2350) := by decide +kernel

theorem selectedBound24771 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24772 : List Nat := [2,4,8,1,32,1,8,256,512,1024,2048,2350,269,0,1,262,1,2340,1024,0,1280,33,1,3,269,1,2049,1,2351,2340,1284,33,256,33,1,513]

theorem envBound24772 : H12AffineFastState.Bounded env24772 := by
  intro p hp
  have h : env24772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24771_24772 : H12AffineEnvironment.transform 11 2350 env24771 = env24772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2350 env24771 == env24772) = true)

theorem identity24772 : scanCanonicalize (H12AffineFastState.compose env24772 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound24772 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24773 : List Nat := [2,4,8,1,32,1,8,4,512,1024,2048,2090,9,0,1,2,1,2080,1024,0,1028,33,1,3,9,1,2049,1,2091,2080,1024,33,4,33,1,513]

theorem envBound24773 : H12AffineFastState.Bounded env24773 := by
  intro p hp
  have h : env24773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24772_24773 : H12AffineEnvironment.transform 7 4 env24772 = env24773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env24772 == env24773) = true)

theorem identity24773 : scanCanonicalize (H12AffineFastState.compose env24773 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound24773 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24774 : List Nat := [2,4,8,1,32,1,8,4,512,1024,1038,1060,9,0,1,2,1,1070,1024,0,1028,33,1,3,9,1,1039,1,1061,1070,1024,33,4,33,1,513]

theorem envBound24774 : H12AffineFastState.Bounded env24774 := by
  intro p hp
  have h : env24774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24773_24774 : H12AffineEnvironment.transform 10 1038 env24773 = env24774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env24773 == env24774) = true)

theorem identity24774 : scanCanonicalize (H12AffineFastState.compose env24774 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound24774 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24775 : List Nat := [2,4,8,1,10,1,8,4,512,1024,1038,1038,9,0,1,2,1,1028,1024,0,1028,11,1,3,9,1,1039,1,1039,1028,1024,11,4,11,1,513]

theorem envBound24775 : H12AffineFastState.Bounded env24775 := by
  intro p hp
  have h : env24775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24774_24775 : H12AffineEnvironment.transform 4 10 env24774 = env24775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env24774 == env24775) = true)

def env24776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16449,262144,1024,32769,58397,272393,16,41311,8192,64,10508,57676,45405,294992,1364,272393,256,41341,16465,513]

theorem envBound24776 : H12AffineFastState.Bounded env24776 := by
  intro p hp
  have h : env24776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24764_24776 : H12AffineEnvironment.transform 16 16449 env24764 = env24776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env24764 == env24776) = true)

theorem identity24776 : scanCanonicalize (H12AffineFastState.compose env24776 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound24776 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env24777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,8203,16449,262144,1024,8460,17680,272393,16,82,8192,64,10508,16449,4176,270685,1364,272393,256,112,16465,513]

theorem envBound24777 : H12AffineFastState.Bounded env24777 := by
  intro p hp
  have h : env24777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24776_24777 : H12AffineEnvironment.transform 14 8461 env24776 = env24777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env24776 == env24777) = true)

theorem identity24777 : scanCanonicalize (H12AffineFastState.compose env24777 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound24777 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env24778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16449,262144,1024,81,17680,264532,16,82,349,64,2129,16449,4176,262144,1364,264532,256,112,16465,513]

theorem envBound24778 : H12AffineFastState.Bounded env24778 := by
  intro p hp
  have h : env24778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24777_24778 : H12AffineEnvironment.transform 12 349 env24777 = env24778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env24777 == env24778) = true)

theorem identity24778 : scanCanonicalize (H12AffineFastState.compose env24778 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound24778 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,80,342,16449,2420,1024,81,17680,32,16,82,349,64,2129,16449,4176,2420,1364,32,256,112,16465,513]

theorem envBound24779 : H12AffineFastState.Bounded env24779 := by
  intro p hp
  have h : env24779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24778_24779 : H12AffineEnvironment.transform 17 2420 env24778 = env24779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env24778 == env24779) = true)

theorem identity24779 : scanCanonicalize (H12AffineFastState.compose env24779 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24779 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24780 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16401,2340,1024,1,17680,32,16,2,269,16,2049,16401,4096,2340,1284,32,256,32,16385,513]

theorem envBound24780 : H12AffineFastState.Bounded env24780 := by
  intro p hp
  have h : env24780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24779_24780 : H12AffineEnvironment.transform 5 16 env24779 = env24780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24779 == env24780) = true)

theorem identity24780 : scanCanonicalize (H12AffineFastState.compose env24780 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24781 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,16384,0,262,16401,2308,1024,1,17680,0,16,2,269,16,2049,16401,4096,2308,1284,0,256,0,16385,513]

theorem envBound24781 : H12AffineFastState.Bounded env24781 := by
  intro p hp
  have h : env24781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24780_24781 : H12AffineEnvironment.transform 4 0 env24780 = env24781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24780 == env24781) = true)

theorem identity24781 : scanCanonicalize (H12AffineFastState.compose env24781 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound24781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24782 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,17,269,16384,0,262,16401,2308,1024,1,17680,0,16,2,269,16,2049,16401,17,2308,1284,0,256,0,16385,513]

theorem envBound24782 : H12AffineFastState.Bounded env24782 := by
  intro p hp
  have h : env24782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24781_24782 : H12AffineEnvironment.transform 11 17 env24781 = env24782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env24781 == env24782) = true)

theorem identity24782 : scanCanonicalize (H12AffineFastState.compose env24782 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 1809) := by decide +kernel

theorem selectedBound24782 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24783 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,17,269,1809,0,262,1792,2308,1024,1,513,0,16,2,269,16,2049,1792,17,2308,1284,0,256,0,1808,513]

theorem envBound24783 : H12AffineFastState.Bounded env24783 := by
  intro p hp
  have h : env24783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24782_24783 : H12AffineEnvironment.transform 13 1809 env24782 = env24783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1809 env24782 == env24783) = true)

theorem identity24783 : scanCanonicalize (H12AffineFastState.compose env24783 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound24783 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24784 : List Nat := [2,4,8,16,0,16,8,256,512,1024,528,17,269,1809,0,262,1792,788,1024,1,513,0,16,2,269,16,529,1792,17,788,1284,0,256,0,1808,513]

theorem envBound24784 : H12AffineFastState.Bounded env24784 := by
  intro p hp
  have h : env24784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24783_24784 : H12AffineEnvironment.transform 10 528 env24783 = env24784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env24783 == env24784) = true)

theorem identity24784 : scanCanonicalize (H12AffineFastState.compose env24784 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound24784 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24785 : List Nat := [2,4,8,16,0,16,8,256,512,256,528,17,269,529,0,262,512,788,256,1,513,0,16,2,269,16,529,512,17,788,4,0,256,0,528,513]

theorem envBound24785 : H12AffineFastState.Bounded env24785 := by
  intro p hp
  have h : env24785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24784_24785 : H12AffineEnvironment.transform 9 256 env24784 = env24785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env24784 == env24785) = true)

theorem identity24785 : scanCanonicalize (H12AffineFastState.compose env24785 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound24785 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env24786 : List Nat := [2,4,8,16,0,16,8,256,261,256,277,17,269,276,0,262,261,17,256,1,260,0,16,2,269,16,276,261,17,17,4,0,256,0,277,260]

theorem envBound24786 : H12AffineFastState.Bounded env24786 := by
  intro p hp
  have h : env24786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24785_24786 : H12AffineEnvironment.transform 8 261 env24785 = env24786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env24785 == env24786) = true)

def env24787 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,41311,8192,64,4677966,2172250,2118977,442384,75102,6407190,256,2188650,2196550,512]

theorem envBound24787 : H12AffineFastState.Bounded env24787 := by
  intro p hp
  have h : env24787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24729_24787 : H12AffineEnvironment.transform 22 17 env24729 = env24787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env24729 == env24787) = true)

theorem identity24787 : scanCanonicalize (H12AffineFastState.compose env24787 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 314689) := by decide +kernel

theorem selectedBound24787 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24788 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,314689,4194304,17,41311,8192,64,4677966,387099,301056,442384,75102,4524375,256,370731,346375,512]

theorem envBound24788 : H12AffineFastState.Bounded env24788 := by
  intro p hp
  have h : env24788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24787_24788 : H12AffineEnvironment.transform 20 314689 env24787 = env24788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 314689 env24787 == env24788) = true)

theorem identity24788 : scanCanonicalize (H12AffineFastState.compose env24788 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound24788 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58729,4194304,17,41311,8192,64,4409702,114739,45096,190520,75102,4268415,256,98307,90415,512]

theorem envBound24789 : H12AffineFastState.Bounded env24789 := by
  intro p hp
  have h : env24789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24788_24789 : H12AffineEnvironment.transform 17 10280 env24788 = env24789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env24788 == env24789) = true)

theorem identity24789 : scanCanonicalize (H12AffineFastState.compose env24789 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 246118) := by decide +kernel

theorem selectedBound24789 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env24790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,58729,246118,17,41311,8192,64,34816,114739,45096,190520,75102,188441,256,98307,90415,512]

theorem envBound24790 : H12AffineFastState.Bounded env24790 := by
  intro p hp
  have h : env24790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24789_24790 : H12AffineEnvironment.transform 21 246118 env24789 = env24790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246118 env24789 == env24790) = true)

theorem identity24790 : scanCanonicalize (H12AffineFastState.compose env24790 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound24790 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env24791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,131072,10280,1024,32769,58729,147504,17,41311,8192,64,34816,16741,45096,190520,41992,188441,256,341,57465,512]

theorem envBound24791 : H12AffineFastState.Bounded env24791 := by
  intro p hp
  have h : env24791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24790_24791 : H12AffineEnvironment.transform 15 33110 env24790 = env24791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env24790 == env24791) = true)

theorem identity24791 : scanCanonicalize (H12AffineFastState.compose env24791 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10328) := by decide +kernel

theorem selectedBound24791 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env24792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10328,32768,33110,131072,10280,1024,32769,36145,141416,17,41311,8192,64,34816,10557,45096,163936,41992,165953,256,341,34849,512]

theorem envBound24792 : H12AffineFastState.Bounded env24792 := by
  intro p hp
  have h : env24792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24791_24792 : H12AffineEnvironment.transform 13 10328 env24791 = env24792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10328 env24791 == env24792) = true)

theorem identity24792 : scanCanonicalize (H12AffineFastState.compose env24792 (packedSelected [0,1,3,5,7,8,10,14,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound24792 : packedSelected [0,1,3,5,7,8,10,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env24793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10328,32768,33110,131072,10280,1024,32769,36145,141416,17,41311,8192,64,34816,10557,44124,163936,41992,165953,256,341,34849,512]

theorem envBound24793 : H12AffineFastState.Bounded env24793 := by
  intro p hp
  have h : env24793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24792_24793 : H12AffineEnvironment.transform 11 3188 env24792 = env24793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env24792 == env24793) = true)

theorem identity24793 : scanCanonicalize (H12AffineFastState.compose env24793 (packedSelected [0,6,7,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound24793 : packedSelected [0,6,7,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,10328,80,262,131072,10280,1024,81,3425,141416,17,8463,8192,64,2128,10557,11276,131120,9304,133137,256,341,2161,512]

theorem envBound24794 : H12AffineFastState.Bounded env24794 := by
  intro p hp
  have h : env24794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24793_24794 : H12AffineEnvironment.transform 14 80 env24793 = env24794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env24793 == env24794) = true)

theorem identity24794 : scanCanonicalize (H12AffineFastState.compose env24794 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24794 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,120,2080,80,262,131072,2128,1024,81,3425,133136,17,375,120,64,2128,2373,3188,131120,1056,133137,256,341,2161,512]

theorem envBound24795 : H12AffineFastState.Bounded env24795 := by
  intro p hp
  have h : env24795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24794_24795 : H12AffineEnvironment.transform 12 120 env24794 = env24795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24794 == env24795) = true)

theorem identity24795 : scanCanonicalize (H12AffineFastState.compose env24795 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound24795 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env24796 : List Nat := [2,4,8,16,32,64,8,256,512,305,2048,2373,120,2080,80,262,131072,2128,305,81,2128,133136,17,375,120,64,2128,2373,2373,131120,273,133137,256,341,2161,512]

theorem envBound24796 : H12AffineFastState.Bounded env24796 := by
  intro p hp
  have h : env24796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24795_24796 : H12AffineEnvironment.transform 9 305 env24795 = env24796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env24795 == env24796) = true)

theorem identity24796 : scanCanonicalize (H12AffineFastState.compose env24796 (packedSelected [1,2,3,5,8,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound24796 : packedSelected [1,2,3,5,8,14,15] rootPS < 2^1333 := by decide +kernel

def env24797 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,2097,120,2080,80,114,131072,2128,69,81,2128,133136,17,3,120,64,2128,2097,2097,131120,101,133137,116,33,2161,512]

theorem envBound24797 : H12AffineFastState.Bounded env24797 := by
  intro p hp
  have h : env24797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24796_24797 : H12AffineEnvironment.transform 7 116 env24796 = env24797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env24796 == env24797) = true)

theorem identity24797 : scanCanonicalize (H12AffineFastState.compose env24797 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 2064) := by decide +kernel

theorem selectedBound24797 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env24798 : List Nat := [2,4,8,16,32,64,8,116,512,69,2048,2097,120,2080,80,114,2064,2128,69,81,2128,0,17,3,120,64,2128,2097,2097,2080,101,1,116,33,2161,512]

theorem envBound24798 : H12AffineFastState.Bounded env24798 := by
  intro p hp
  have h : env24798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24797_24798 : H12AffineEnvironment.transform 16 2064 env24797 = env24798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2064 env24797 == env24798) = true)

theorem identity24798 : scanCanonicalize (H12AffineFastState.compose env24798 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24798 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env24799 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,2065,88,2048,80,82,2064,2128,69,81,2128,0,17,3,88,64,2128,2065,2065,2048,69,1,84,1,2129,512]

theorem envBound24799 : H12AffineFastState.Bounded env24799 := by
  intro p hp
  have h : env24799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24798_24799 : H12AffineEnvironment.transform 4 0 env24798 = env24799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24798 == env24799) = true)

theorem identity24799 : scanCanonicalize (H12AffineFastState.compose env24799 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound24799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24800 : List Nat := [2,4,8,13,0,64,8,73,512,69,2048,2060,69,2048,77,79,2061,2125,69,76,2125,0,12,3,69,64,2125,2060,2060,2048,69,1,73,1,2124,512]

theorem envBound24800 : H12AffineFastState.Bounded env24800 := by
  intro p hp
  have h : env24800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24799_24800 : H12AffineEnvironment.transform 3 13 env24799 = env24800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env24799 == env24800) = true)

theorem identity24800 : scanCanonicalize (H12AffineFastState.compose env24800 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound24800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24801 : List Nat := [2,4,5,0,0,64,5,68,512,69,2048,2049,69,2048,64,66,2048,2112,69,65,2112,0,1,3,69,64,2112,2049,2049,2048,69,1,68,1,2113,512]

theorem envBound24801 : H12AffineFastState.Bounded env24801 := by
  intro p hp
  have h : env24801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24800_24801 : H12AffineEnvironment.transform 2 5 env24800 = env24801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env24800 == env24801) = true)

theorem identity24801 : scanCanonicalize (H12AffineFastState.compose env24801 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound24801 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24802 : List Nat := [2,4,5,0,0,64,5,68,512,69,70,71,69,70,64,66,70,6,69,65,6,0,1,3,69,64,6,71,71,70,69,1,68,1,7,512]

theorem envBound24802 : H12AffineFastState.Bounded env24802 := by
  intro p hp
  have h : env24802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24801_24802 : H12AffineEnvironment.transform 10 70 env24801 = env24802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env24801 == env24802) = true)

theorem identity24802 : scanCanonicalize (H12AffineFastState.compose env24802 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 70) := by decide +kernel

theorem selectedBound24802 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env24803 : List Nat := [2,4,5,0,0,64,5,68,70,69,70,71,69,70,64,66,70,6,69,65,6,0,1,3,69,64,6,71,71,70,69,1,68,1,7,70]

theorem envBound24803 : H12AffineFastState.Bounded env24803 := by
  intro p hp
  have h : env24803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24802_24803 : H12AffineEnvironment.transform 8 70 env24802 = env24803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 70 env24802 == env24803) = true)

theorem identity24803 : scanCanonicalize (H12AffineFastState.compose env24803 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound24803 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24804 : List Nat := [2,4,5,0,0,6,5,2,0,3,0,1,3,0,6,4,0,6,3,7,6,0,1,3,3,6,6,1,1,0,3,1,2,1,7,0]

theorem envBound24804 : H12AffineFastState.Bounded env24804 := by
  intro p hp
  have h : env24804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24803_24804 : H12AffineEnvironment.transform 5 6 env24803 = env24804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env24803 == env24804) = true)

theorem identity24804 : scanCanonicalize (H12AffineFastState.compose env24804 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound24804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24805 : List Nat := [2,0,1,0,0,2,1,2,0,3,0,1,3,0,2,0,0,2,3,3,2,0,1,3,3,2,2,1,1,0,3,1,2,1,3,0]

theorem envBound24805 : H12AffineFastState.Bounded env24805 := by
  intro p hp
  have h : env24805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24804_24805 : H12AffineEnvironment.transform 1 0 env24804 = env24805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env24804 == env24805) = true)

theorem identity24805 : scanCanonicalize (H12AffineFastState.compose env24805 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound24805 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env24806 : List Nat := [0,0,1,0,0,0,1,0,0,1,0,1,1,0,0,0,0,0,1,1,0,0,1,1,1,0,0,1,1,0,1,1,0,1,1,0]

theorem envBound24806 : H12AffineFastState.Bounded env24806 := by
  intro p hp
  have h : env24806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24805_24806 : H12AffineEnvironment.transform 0 0 env24805 = env24806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env24805 == env24806) = true)

def env24807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,41311,8193,64,13066591,2172251,10507600,8830977,8463695,6407191,256,10577274,10585175,8389136]

theorem envBound24807 : H12AffineFastState.Bounded env24807 := by
  intro p hp
  have h : env24807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24728_24807 : H12AffineEnvironment.transform 6 9 env24728 = env24807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env24728 == env24807) = true)

def env24808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,41311,8193,64,4677967,2172251,2118976,442385,75103,6407191,256,2188650,2196551,512]

theorem envBound24808 : H12AffineFastState.Bounded env24808 := by
  intro p hp
  have h : env24808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24807_24808 : H12AffineEnvironment.transform 22 16 env24807 = env24808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env24807 == env24808) = true)

theorem identity24808 : scanCanonicalize (H12AffineFastState.compose env24808 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 503131) := by decide +kernel

theorem selectedBound24808 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,503131,4194304,16,41311,8193,64,4677967,428032,522267,442385,75103,4614476,256,444465,403740,512]

theorem envBound24809 : H12AffineFastState.Bounded env24809 := by
  intro p hp
  have h : env24809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24808_24809 : H12AffineEnvironment.transform 20 503131 env24808 = env24809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 503131 env24808 == env24809) = true)

theorem identity24809 : scanCanonicalize (H12AffineFastState.compose env24809 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound24809 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env24810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,461831,4194304,16,3,8193,64,4677967,403804,481607,418125,75103,4614476,256,420205,403740,512]

theorem envBound24810 : H12AffineFastState.Bounded env24810 := by
  intro p hp
  have h : env24810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24809_24810 : H12AffineEnvironment.transform 14 8540 env24809 = env24810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env24809 == env24810) = true)

theorem identity24810 : scanCanonicalize (H12AffineFastState.compose env24810 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 420173) := by decide +kernel

theorem selectedBound24810 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env24811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,262144,1024,8541,461831,420173,16,3,8193,64,67586,403804,481607,418125,75103,1,256,420205,403740,512]

theorem envBound24811 : H12AffineFastState.Bounded env24811 := by
  intro p hp
  have h : env24811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24810_24811 : H12AffineEnvironment.transform 21 420173 env24810 = env24811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 420173 env24810 == env24811) = true)

theorem identity24811 : scanCanonicalize (H12AffineFastState.compose env24811 (packedSelected [9,14,22] rootPS)) = affineNative (2^(17+1) ^^^ 158061) := by decide +kernel

theorem selectedBound24811 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env24812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,158061,1024,8541,91498,32,16,3,8193,64,67586,16433,77866,2080,75103,1,256,0,16497,512]

theorem envBound24812 : H12AffineFastState.Bounded env24812 := by
  intro p hp
  have h : env24812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24811_24812 : H12AffineEnvironment.transform 17 158061 env24811 = env24812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 158061 env24811 == env24812) = true)

theorem identity24812 : scanCanonicalize (H12AffineFastState.compose env24812 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound24812 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env24813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,16400,10621,1024,8541,91498,32,16,3,8193,64,67586,16433,77866,2080,75103,1,256,0,16497,512]

theorem envBound24813 : H12AffineFastState.Bounded env24813 := by
  intro p hp
  have h : env24813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24812_24813 : H12AffineEnvironment.transform 16 16400 env24812 = env24813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env24812 == env24813) = true)

theorem identity24813 : scanCanonicalize (H12AffineFastState.compose env24813 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(15+1) ^^^ 21622) := by decide +kernel

theorem selectedBound24813 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env24814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21622,16400,10621,1024,8541,12572,32,16,3,8193,64,23668,16433,25692,2080,28969,1,256,0,16497,512]

theorem envBound24814 : H12AffineFastState.Bounded env24814 := by
  intro p hp
  have h : env24814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24813_24814 : H12AffineEnvironment.transform 15 21622 env24813 = env24814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21622 env24813 == env24814) = true)

theorem identity24814 : scanCanonicalize (H12AffineFastState.compose env24814 (packedSelected [2,3,5,6,10,11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24814 : packedSelected [2,3,5,6,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env24815 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,16384,8493,21511,16400,10508,1024,8492,12572,32,16,3,8193,49,23557,16433,25645,2080,28969,1,256,0,16384,512]

theorem envBound24815 : H12AffineFastState.Bounded env24815 := by
  intro p hp
  have h : env24815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24814_24815 : H12AffineEnvironment.transform 5 49 env24814 = env24815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24814 == env24815) = true)

theorem identity24815 : scanCanonicalize (H12AffineFastState.compose env24815 (packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound24815 : packedSelected [0,1,3,4,5,6,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env24816 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,8192,16384,8200,21511,16400,10281,1024,8201,12345,32,16,3,8193,49,23557,16433,25645,2080,28684,1,37,0,16384,512]

theorem envBound24816 : H12AffineFastState.Bounded env24816 := by
  intro p hp
  have h : env24816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24815_24816 : H12AffineEnvironment.transform 7 37 env24815 = env24816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env24815 == env24816) = true)

theorem identity24816 : scanCanonicalize (H12AffineFastState.compose env24816 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound24816 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env24817 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,41,16384,33,21511,16400,2048,1024,32,4112,32,16,3,40,49,23557,16433,17412,2080,20517,1,37,0,16384,512]

theorem envBound24817 : H12AffineFastState.Bounded env24817 := by
  intro p hp
  have h : env24817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24816_24817 : H12AffineEnvironment.transform 12 41 env24816 = env24817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env24816 == env24817) = true)

theorem identity24817 : scanCanonicalize (H12AffineFastState.compose env24817 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound24817 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env24818 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,41,5157,33,34,5173,2048,1024,32,4112,32,16,3,40,49,2080,5140,4129,2080,1024,1,37,0,5157,512]

theorem envBound24818 : H12AffineFastState.Bounded env24818 := by
  intro p hp
  have h : env24818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24817_24818 : H12AffineEnvironment.transform 13 5157 env24817 = env24818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env24817 == env24818) = true)

theorem identity24818 : scanCanonicalize (H12AffineFastState.compose env24818 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24819 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,0,3,5140,2048,1024,1,4112,1,16,3,9,16,2049,5140,4096,2049,1024,1,4,0,5124,512]

end H12CloudChart1