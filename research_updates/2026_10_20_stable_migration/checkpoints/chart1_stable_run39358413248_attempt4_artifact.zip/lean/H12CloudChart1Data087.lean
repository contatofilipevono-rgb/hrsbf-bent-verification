import H12CloudChart1Data086

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound22014 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,213350,17,98780,8328,65,158028,5392,17665,109046,1500,243002,256,21792,46212,74251]

theorem envBound22015 : H12AffineFastState.Bounded env22015 := by
  intro p hp
  have h : env22015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22014_22015 : H12AffineEnvironment.transform 21 213350 env22014 = env22015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213350 env22014 == env22015) = true)

theorem identity22015 : scanCanonicalize (H12AffineFastState.compose env22015 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22015 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149996,1024,32769,4161,156012,17,41430,8328,65,158028,5392,17665,35324,1500,169264,256,21792,46212,513]

theorem envBound22016 : H12AffineFastState.Bounded env22016 := by
  intro p hp
  have h : env22016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22015_22016 : H12AffineEnvironment.transform 15 8202 env22015 = env22016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22015 == env22016) = true)

theorem identity22016 : scanCanonicalize (H12AffineFastState.compose env22016 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound22016 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2557,1024,32769,4161,8573,17,41430,8328,65,10589,5392,17665,35324,1500,54561,256,21792,46212,513]

theorem envBound22017 : H12AffineFastState.Bounded env22017 := by
  intro p hp
  have h : env22017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22016_22017 : H12AffineEnvironment.transform 16 16401 env22016 = env22017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22016 == env22017) = true)

theorem identity22017 : scanCanonicalize (H12AffineFastState.compose env22017 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound22017 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env22018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16401,2557,1024,29708,4161,8573,17,21979,8328,65,10589,5392,17665,32241,1500,8492,256,21792,16521,513]

theorem envBound22018 : H12AffineFastState.Bounded env22018 := by
  intro p hp
  have h : env22018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22017_22018 : H12AffineEnvironment.transform 14 29709 env22017 = env22018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env22017 == env22018) = true)

theorem identity22018 : scanCanonicalize (H12AffineFastState.compose env22018 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22018 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env22019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,16401,2421,1024,29708,4161,8573,17,21843,8192,65,10589,5392,17665,32121,1364,8492,256,21792,16385,513]

theorem envBound22019 : H12AffineFastState.Bounded env22019 := by
  intro p hp
  have h : env22019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22018_22019 : H12AffineEnvironment.transform 6 8 env22018 = env22019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22018 == env22019) = true)

theorem identity22019 : scanCanonicalize (H12AffineFastState.compose env22019 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(13+1) ^^^ 4452) := by decide +kernel

theorem selectedBound22019 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env22020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4452,9577,8202,4469,2421,1024,9576,4161,8573,17,1079,8192,65,10589,5392,5221,11293,1364,8492,256,1092,4453,513]

theorem envBound22020 : H12AffineFastState.Bounded env22020 := by
  intro p hp
  have h : env22020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22019_22020 : H12AffineEnvironment.transform 13 4452 env22019 = env22020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4452 env22019 == env22020) = true)

theorem identity22020 : scanCanonicalize (H12AffineFastState.compose env22020 (packedSelected [0,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound22020 : packedSelected [0,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,4452,373,1046,4469,2421,1024,372,4161,1377,17,1079,1052,65,3393,5392,5221,2049,1364,1328,256,1092,4453,513]

theorem envBound22021 : H12AffineFastState.Bounded env22021 := by
  intro p hp
  have h : env22021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22020_22021 : H12AffineEnvironment.transform 12 1052 env22020 = env22021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env22020 == env22021) = true)

theorem identity22021 : scanCanonicalize (H12AffineFastState.compose env22021 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound22021 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env22022 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,4452,373,115,4469,2421,101,372,4161,260,17,82,121,65,2340,4469,4096,2049,305,341,256,33,4453,513]

theorem envBound22022 : H12AffineFastState.Bounded env22022 := by
  intro p hp
  have h : env22022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22021_22022 : H12AffineEnvironment.transform 9 101 env22021 = env22022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env22021 == env22022) = true)

theorem identity22022 : scanCanonicalize (H12AffineFastState.compose env22022 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22022 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22023 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,40,4405,292,34,4388,2340,52,293,4112,260,17,3,40,16,2340,4388,4096,2049,305,260,256,33,4404,513]

theorem envBound22023 : H12AffineFastState.Bounded env22023 := by
  intro p hp
  have h : env22023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22022_22023 : H12AffineEnvironment.transform 5 17 env22022 = env22023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22022 == env22023) = true)

def env22024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,2097152,4194304,2101329,2199965,8328,65,4270123,5392,17664,2210230,1501,4256860,256,2114912,2139332,74250]

theorem envBound22024 : H12AffineFastState.Bounded env22024 := by
  intro p hp
  have h : env22024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21987_22024 : H12AffineEnvironment.transform 22 2101329 env21987 = env22024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21987 == env22024) = true)

def env22025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,4194304,17,98781,8328,65,4270123,5392,17664,109046,1501,4256860,256,21792,46212,74250]

theorem envBound22025 : H12AffineFastState.Bounded env22025 := by
  intro p hp
  have h : env22025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22024_22025 : H12AffineEnvironment.transform 20 4160 env22024 = env22025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22024 == env22025) = true)

theorem identity22025 : scanCanonicalize (H12AffineFastState.compose env22025 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243123) := by decide +kernel

theorem selectedBound22025 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,243123,17,98781,8328,65,171416,5392,17664,109046,1501,213487,256,21792,46212,74250]

theorem envBound22026 : H12AffineFastState.Bounded env22026 := by
  intro p hp
  have h : env22026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22025_22026 : H12AffineEnvironment.transform 21 243123 env22025 = env22026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243123 env22025 == env22026) = true)

def env22027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,243003,17,98645,8192,65,171280,5392,17664,108926,1365,213351,256,21792,46092,74250]

theorem envBound22027 : H12AffineFastState.Bounded env22027 := by
  intro p hp
  have h : env22027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22026_22027 : H12AffineEnvironment.transform 6 8 env22026 = env22027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22026 == env22027) = true)

theorem identity22027 : scanCanonicalize (H12AffineFastState.compose env22027 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22027 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,131072,190521,1024,32769,4160,144492,17,2,8192,65,171280,5392,17664,10281,1365,180272,256,21792,46092,41821]

theorem envBound22028 : H12AffineFastState.Bounded env22028 := by
  intro p hp
  have h : env22028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22027_22028 : H12AffineEnvironment.transform 15 33111 env22027 = env22028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22027 == env22028) = true)

theorem identity22028 : scanCanonicalize (H12AffineFastState.compose env22028 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound22028 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env22029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,32768,33111,131072,171060,1024,32769,4160,144492,17,2,8192,65,171280,5392,12557,10281,1365,177213,256,8493,46092,41821]

theorem envBound22029 : H12AffineFastState.Bounded env22029 := by
  intro p hp
  have h : env22029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22028_22029 : H12AffineEnvironment.transform 13 13325 env22028 = env22029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env22028 == env22029) = true)

theorem identity22029 : scanCanonicalize (H12AffineFastState.compose env22029 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound22029 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env22030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,263,131072,138340,1024,81,4160,144492,17,2,8192,65,138560,5392,12557,10281,1365,144493,256,8493,13404,8973]

theorem envBound22030 : H12AffineFastState.Bounded env22030 := by
  intro p hp
  have h : env22030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22029_22030 : H12AffineEnvironment.transform 14 80 env22029 = env22030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env22029 == env22030) = true)

theorem identity22030 : scanCanonicalize (H12AffineFastState.compose env22030 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound22030 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,80,263,13625,10589,1024,81,4160,341,17,2,8192,65,10361,5392,12557,10281,1365,340,256,8493,13404,8973]

theorem envBound22031 : H12AffineFastState.Bounded env22031 := by
  intro p hp
  have h : env22031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22030_22031 : H12AffineEnvironment.transform 16 13625 env22030 = env22031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env22030 == env22031) = true)

theorem identity22031 : scanCanonicalize (H12AffineFastState.compose env22031 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound22031 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5488,80,263,5188,2080,1024,81,4160,341,17,2,381,65,2308,5392,4208,2388,1365,340,256,80,5409,624]

theorem envBound22032 : H12AffineFastState.Bounded env22032 := by
  intro p hp
  have h : env22032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22031_22032 : H12AffineEnvironment.transform 12 381 env22031 = env22032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env22031 == env22032) = true)

theorem identity22032 : scanCanonicalize (H12AffineFastState.compose env22032 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22032 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env22033 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,88,5205,80,34,5188,2080,1024,81,4160,112,17,2,88,65,2081,5173,4208,2161,1136,113,37,80,5124,624]

theorem envBound22033 : H12AffineFastState.Bounded env22033 := by
  intro p hp
  have h : env22033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22032_22033 : H12AffineEnvironment.transform 7 37 env22032 = env22033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22032 == env22033) = true)

theorem identity22033 : scanCanonicalize (H12AffineFastState.compose env22033 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound22033 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22034 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,4096,88,4160,80,34,4177,2080,21,81,4160,112,17,2,88,65,2081,4128,4208,2161,101,113,37,80,4113,624]

theorem envBound22034 : H12AffineFastState.Bounded env22034 := by
  intro p hp
  have h : env22034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22033_22034 : H12AffineEnvironment.transform 9 21 env22033 = env22034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22033 == env22034) = true)

theorem identity22034 : scanCanonicalize (H12AffineFastState.compose env22034 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound22034 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22035 : List Nat := [2,4,8,16,32,64,8,37,512,21,2048,2058,88,2122,80,34,2139,2080,21,81,2122,112,17,2,88,65,2081,2090,2170,2161,101,113,37,80,2075,624]

theorem envBound22035 : H12AffineFastState.Bounded env22035 := by
  intro p hp
  have h : env22035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22034_22035 : H12AffineEnvironment.transform 11 2058 env22034 = env22035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env22034 == env22035) = true)

theorem identity22035 : scanCanonicalize (H12AffineFastState.compose env22035 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound22035 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22036 : List Nat := [2,4,8,16,32,64,8,37,36,21,2048,2058,88,2122,80,34,2139,2080,21,81,2122,112,17,2,88,65,2081,2090,2170,2161,101,113,37,80,2075,84]

theorem envBound22036 : H12AffineFastState.Bounded env22036 := by
  intro p hp
  have h : env22036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22035_22036 : H12AffineEnvironment.transform 8 36 env22035 = env22036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env22035 == env22036) = true)

theorem identity22036 : scanCanonicalize (H12AffineFastState.compose env22036 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22036 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env22037 : List Nat := [2,4,8,16,32,17,8,37,36,21,2048,2058,9,2075,1,34,2058,2080,21,0,2075,33,17,2,9,16,2081,2090,2091,2080,52,32,37,1,2075,5]

theorem envBound22037 : H12AffineFastState.Bounded env22037 := by
  intro p hp
  have h : env22037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22036_22037 : H12AffineEnvironment.transform 5 17 env22036 = env22037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22036 == env22037) = true)

theorem identity22037 : scanCanonicalize (H12AffineFastState.compose env22037 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound22037 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env22038 : List Nat := [2,4,8,16,32,17,8,37,36,21,48,58,9,43,1,34,58,16,21,0,43,33,17,2,9,16,17,26,27,16,52,32,37,1,43,5]

theorem envBound22038 : H12AffineFastState.Bounded env22038 := by
  intro p hp
  have h : env22038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22037_22038 : H12AffineEnvironment.transform 10 48 env22037 = env22038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env22037 == env22038) = true)

theorem identity22038 : scanCanonicalize (H12AffineFastState.compose env22038 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound22038 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22039 : List Nat := [2,4,8,16,23,17,8,18,19,21,7,13,9,28,1,21,13,16,21,0,28,22,17,2,9,16,17,26,27,16,3,23,18,1,28,5]

theorem envBound22039 : H12AffineFastState.Bounded env22039 := by
  intro p hp
  have h : env22039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22038_22039 : H12AffineEnvironment.transform 4 23 env22038 = env22039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env22038 == env22039) = true)

theorem identity22039 : scanCanonicalize (H12AffineFastState.compose env22039 (packedSelected [2,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22039 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env22040 : List Nat := [2,4,2,16,23,17,2,18,19,21,7,7,3,22,1,21,7,16,21,0,22,22,17,2,3,16,17,16,17,16,3,23,18,1,22,5]

theorem envBound22040 : H12AffineFastState.Bounded env22040 := by
  intro p hp
  have h : env22040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22039_22040 : H12AffineEnvironment.transform 2 2 env22039 = env22040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22039 == env22040) = true)

theorem identity22040 : scanCanonicalize (H12AffineFastState.compose env22040 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound22040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22041 : List Nat := [2,2,2,16,17,17,2,18,19,19,1,1,3,16,1,19,1,16,19,0,16,16,17,2,3,16,17,16,17,16,3,17,18,1,16,3]

theorem envBound22041 : H12AffineFastState.Bounded env22041 := by
  intro p hp
  have h : env22041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22040_22041 : H12AffineEnvironment.transform 1 2 env22040 = env22041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env22040 == env22041) = true)

def env22042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4160,243002,17,98644,8193,65,171281,5392,17664,108927,1364,213350,256,21792,46093,74250]

theorem envBound22042 : H12AffineFastState.Bounded env22042 := by
  intro p hp
  have h : env22042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22026_22042 : H12AffineEnvironment.transform 6 9 env22026 = env22042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22026 == env22042) = true)

theorem identity22042 : scanCanonicalize (H12AffineFastState.compose env22042 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22042 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4160,169265,17,41311,8193,65,171281,5392,17664,35188,1364,156013,256,21792,46093,513]

theorem envBound22043 : H12AffineFastState.Bounded env22043 := by
  intro p hp
  have h : env22043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22042_22043 : H12AffineEnvironment.transform 15 8203 env22042 = env22043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22042 == env22043) = true)

theorem identity22043 : scanCanonicalize (H12AffineFastState.compose env22043 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound22043 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2420,1024,32769,4160,54561,17,41311,8193,65,56577,5392,17664,35188,1364,8573,256,21792,46093,513]

theorem envBound22044 : H12AffineFastState.Bounded env22044 := by
  intro p hp
  have h : env22044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22043_22044 : H12AffineEnvironment.transform 16 16400 env22043 = env22044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22043 == env22044) = true)

theorem identity22044 : scanCanonicalize (H12AffineFastState.compose env22044 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22044 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,2420,1024,8540,4160,29820,17,2,8193,65,31836,5392,17664,10281,1364,8573,256,21792,5456,513]

theorem envBound22045 : H12AffineFastState.Bounded env22045 := by
  intro p hp
  have h : env22045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22044_22045 : H12AffineEnvironment.transform 14 8541 env22044 = env22045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22044 == env22045) = true)

theorem identity22045 : scanCanonicalize (H12AffineFastState.compose env22045 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22045 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8541,8203,5441,2420,1024,8540,4160,8493,17,2,8193,65,10509,5392,4177,10281,1364,8573,256,113,5456,513]

theorem envBound22046 : H12AffineFastState.Bounded env22046 := by
  intro p hp
  have h : env22046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22045_22046 : H12AffineEnvironment.transform 13 5457 env22045 = env22046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22045 == env22046) = true)

theorem identity22046 : scanCanonicalize (H12AffineFastState.compose env22046 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound22046 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,57,5457,356,50,5441,2420,1024,357,4160,276,17,2,56,65,2356,5392,4177,2064,1364,324,256,113,5456,513]

theorem envBound22047 : H12AffineFastState.Bounded env22047 := by
  intro p hp
  have h : env22047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22046_22047 : H12AffineEnvironment.transform 12 57 env22046 = env22047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env22046 == env22047) = true)

theorem identity22047 : scanCanonicalize (H12AffineFastState.compose env22047 (packedSelected [1,2,6,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound22047 : packedSelected [1,2,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22048 : List Nat := [2,4,8,16,32,64,9,256,512,256,2048,4096,57,4177,356,50,4161,2420,256,357,4160,276,17,2,56,65,2356,4112,4177,2064,84,324,256,113,4176,513]

theorem envBound22048 : H12AffineFastState.Bounded env22048 := by
  intro p hp
  have h : env22048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22047_22048 : H12AffineEnvironment.transform 9 256 env22047 = env22048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env22047 == env22048) = true)

theorem identity22048 : scanCanonicalize (H12AffineFastState.compose env22048 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22048 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env22049 : List Nat := [2,4,8,16,32,17,9,256,512,256,2048,4096,57,4096,309,50,4112,2341,256,308,4113,276,17,2,56,16,2356,4112,4096,2064,5,277,256,32,4097,513]

theorem envBound22049 : H12AffineFastState.Bounded env22049 := by
  intro p hp
  have h : env22049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22048_22049 : H12AffineEnvironment.transform 5 17 env22048 = env22049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22048 == env22049) = true)

def env22050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4161,4194304,16,98780,8328,65,4270123,5392,17664,109047,1501,4256860,256,21793,46213,74250]

theorem envBound22050 : H12AffineFastState.Bounded env22050 := by
  intro p hp
  have h : env22050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22024_22050 : H12AffineEnvironment.transform 20 4161 env22024 = env22050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22024 == env22050) = true)

theorem identity22050 : scanCanonicalize (H12AffineFastState.compose env22050 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22050 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4161,4194304,16,41431,8328,65,4196384,5392,17664,35324,1501,4256860,256,21793,46213,513]

theorem envBound22051 : H12AffineFastState.Bounded env22051 := by
  intro p hp
  have h : env22051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22050_22051 : H12AffineEnvironment.transform 15 8203 env22050 = env22051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22050 == env22051) = true)

theorem identity22051 : scanCanonicalize (H12AffineFastState.compose env22051 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound22051 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149997,1024,32769,4161,8573,16,41431,8328,65,10589,5392,17664,35324,1501,54561,256,21793,46213,513]

theorem envBound22052 : H12AffineFastState.Bounded env22052 := by
  intro p hp
  have h : env22052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22051_22052 : H12AffineEnvironment.transform 21 8573 env22051 = env22052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env22051 == env22052) = true)

theorem identity22052 : scanCanonicalize (H12AffineFastState.compose env22052 (packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22052 : packedSelected [0,7,9,12,14,15,17,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env22053 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,149860,1024,32769,4161,8573,16,41310,8193,65,10589,5392,17664,35189,1364,54561,256,21793,46092,513]

theorem envBound22053 : H12AffineFastState.Bounded env22053 := by
  intro p hp
  have h : env22053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22052_22053 : H12AffineEnvironment.transform 6 9 env22052 = env22053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22052 == env22053) = true)

theorem identity22053 : scanCanonicalize (H12AffineFastState.compose env22053 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound22053 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22054 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24908,10280,1024,32769,4161,8573,16,41310,8193,65,10589,5392,17664,35189,1364,54561,256,21793,46092,513]

theorem envBound22054 : H12AffineFastState.Bounded env22054 := by
  intro p hp
  have h : env22054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22053_22054 : H12AffineEnvironment.transform 16 24908 env22053 = env22054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env22053 == env22054) = true)

theorem identity22054 : scanCanonicalize (H12AffineFastState.compose env22054 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound22054 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22055 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,24908,10280,1024,21761,4161,8573,16,29790,8193,65,10589,5392,17664,23669,1364,33,256,21793,24844,513]

theorem envBound22055 : H12AffineFastState.Bounded env22055 := by
  intro p hp
  have h : env22055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22054_22055 : H12AffineEnvironment.transform 14 21760 env22054 = env22055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22054 == env22055) = true)

theorem identity22055 : scanCanonicalize (H12AffineFastState.compose env22055 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22055 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22056 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21760,342,16401,2421,1024,21761,4161,32,16,21763,348,65,2048,5392,17664,23669,1364,33,256,21793,16465,513]

theorem envBound22056 : H12AffineFastState.Bounded env22056 := by
  intro p hp
  have h : env22056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22055_22056 : H12AffineEnvironment.transform 12 349 env22055 = env22056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22055 == env22056) = true)

def env22057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound22057 : H12AffineFastState.Bounded env22057 := by
  intro p hp
  have h : env22057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21885_22057 : H12AffineEnvironment.transform 18 1025 env21885 = env22057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21885 == env22057) = true)

theorem identity22057 : scanCanonicalize (H12AffineFastState.compose env22057 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8685926) := by decide +kernel

theorem selectedBound22057 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8328,65,4409702,10817002,10507601,8830976,331127,15068327,257,2444747,2468974,273057]

theorem envBound22058 : H12AffineFastState.Bounded env22058 := by
  intro p hp
  have h : env22058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22057_22058 : H12AffineEnvironment.transform 23 8685926 env22057 = env22058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8685926 env22057 == env22058) = true)

def env22059 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4409702,10816866,10507601,8830976,331127,15068207,257,2444611,2468974,272937]

theorem envBound22059 : H12AffineFastState.Bounded env22059 := by
  intro p hp
  have h : env22059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22058_22059 : H12AffineEnvironment.transform 6 8 env22058 = env22059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22058 == env22059) = true)

def env22060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4262262,10816866,10507601,8683536,331127,15068207,257,2444611,2468974,272937]

theorem envBound22060 : H12AffineFastState.Bounded env22060 := by
  intro p hp
  have h : env22060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22059_22060 : H12AffineEnvironment.transform 16 16400 env22059 = env22060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22059 == env22060) = true)

def env22061 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685878,8192,17,4262182,10816818,10507521,8683536,331047,15068207,257,2444563,2468926,272937]

theorem envBound22061 : H12AffineFastState.Bounded env22061 := by
  intro p hp
  have h : env22061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22060_22061 : H12AffineEnvironment.transform 5 16 env22060 = env22061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22060 == env22061) = true)

def env22062 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685878,8192,17,4262182,10815490,10506289,8683536,329751,15067423,257,2443299,2468110,272937]

theorem envBound22062 : H12AffineFastState.Bounded env22062 := by
  intro p hp
  have h : env22062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22061_22062 : H12AffineEnvironment.transform 9 304 env22061 = env22062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env22061 == env22062) = true)

theorem identity22062 : scanCanonicalize (H12AffineFastState.compose env22062 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4194352) := by decide +kernel

theorem selectedBound22062 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22063 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4194352,4491526,8192,17,4262182,6621234,6311937,4489248,329751,2484527,257,2443299,2468110,272937]

theorem envBound22063 : H12AffineFastState.Bounded env22063 := by
  intro p hp
  have h : env22063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22062_22063 : H12AffineEnvironment.transform 22 4194352 env22062 = env22063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194352 env22062 == env22063) = true)

theorem identity22063 : scanCanonicalize (H12AffineFastState.compose env22063 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22063 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22064 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4194352,4235566,8192,17,4262182,6365210,6311937,4237320,73791,2212103,257,2187275,2195750,513]

theorem envBound22064 : H12AffineFastState.Bounded env22064 := by
  intro p hp
  have h : env22064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22063_22064 : H12AffineEnvironment.transform 17 10280 env22063 = env22064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22063 == env22064) = true)

theorem identity22064 : scanCanonicalize (H12AffineFastState.compose env22064 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 106538) := by decide +kernel

theorem selectedBound22064 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env22065 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,106538,106522,65796,8192,17,43276,2129968,2224171,67618,73791,2212103,257,2187275,2195750,513]

theorem envBound22065 : H12AffineFastState.Bounded env22065 := by
  intro p hp
  have h : env22065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22064_22065 : H12AffineEnvironment.transform 21 106538 env22064 = env22065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 106538 env22064 == env22065) = true)

theorem identity22065 : scanCanonicalize (H12AffineFastState.compose env22065 (packedSelected [0,1,3,5,7,8,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22065 : packedSelected [0,1,3,5,7,8,15,16] rootPS < 2^1333 := by decide +kernel

def env22066 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,65536,16400,2341,305,32769,2097152,98599,98583,65796,269,17,34817,2129968,2216230,67618,65842,2212103,257,2179334,2195750,513]

theorem envBound22066 : H12AffineFastState.Bounded env22066 := by
  intro p hp
  have h : env22066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22065_22066 : H12AffineEnvironment.transform 12 269 env22065 = env22066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22065 == env22066) = true)

theorem identity22066 : scanCanonicalize (H12AffineFastState.compose env22066 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound22066 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22067 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,263,16400,2341,305,32769,2097152,32800,32784,3,269,17,34817,2129968,2150433,2341,53,2146304,257,2113537,2129953,513]

theorem envBound22067 : H12AffineFastState.Bounded env22067 := by
  intro p hp
  have h : env22067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22066_22067 : H12AffineEnvironment.transform 15 263 env22066 = env22067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env22066 == env22067) = true)

theorem identity22067 : scanCanonicalize (H12AffineFastState.compose env22067 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 16417) := by decide +kernel

theorem selectedBound22067 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22068 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,263,16400,2341,305,32769,16417,32800,32784,3,269,17,34817,49169,36864,2341,53,32801,257,32,49152,513]

theorem envBound22068 : H12AffineFastState.Bounded env22068 := by
  intro p hp
  have h : env22068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22067_22068 : H12AffineEnvironment.transform 20 16417 env22067 = env22068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16417 env22067 == env22068) = true)

theorem identity22068 : scanCanonicalize (H12AffineFastState.compose env22068 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 2059) := by decide +kernel

theorem selectedBound22068 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env22069 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,2059,263,16400,2341,305,2058,16417,2091,2075,3,269,17,10,18458,6155,2341,53,2090,257,32,18443,513]

theorem envBound22069 : H12AffineFastState.Bounded env22069 := by
  intro p hp
  have h : env22069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22068_22069 : H12AffineEnvironment.transform 14 2059 env22068 = env22069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2059 env22068 == env22069) = true)

def env22070 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685878,8192,17,4262182,10815491,10506288,8683536,329750,15067422,257,2443298,2468111,272937]

theorem envBound22070 : H12AffineFastState.Bounded env22070 := by
  intro p hp
  have h : env22070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22061_22070 : H12AffineEnvironment.transform 9 305 env22061 = env22070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env22061 == env22070) = true)

theorem identity22070 : scanCanonicalize (H12AffineFastState.compose env22070 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4466712) := by decide +kernel

theorem selectedBound22070 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22071 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4466712,4235566,8192,17,4262182,6365211,6584360,4237320,329750,2212102,257,2443298,2468111,272937]

theorem envBound22071 : H12AffineFastState.Bounded env22071 := by
  intro p hp
  have h : env22071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22070_22071 : H12AffineEnvironment.transform 22 4466712 env22070 = env22071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4466712 env22070 == env22071) = true)

def env22072 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,8192,16384,32768,65536,16400,262144,272,32769,2097152,4194304,4466712,4235534,8192,17,4262150,6365211,6584328,4237320,329750,2212102,257,2443266,2468111,272905]

theorem envBound22072 : H12AffineFastState.Bounded env22072 := by
  intro p hp
  have h : env22072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22071_22072 : H12AffineEnvironment.transform 4 0 env22071 = env22072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22071 == env22072) = true)

theorem identity22072 : scanCanonicalize (H12AffineFastState.compose env22072 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22072 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env22073 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,2097152,4194304,4458772,4227074,268,17,4262150,6357271,6576388,4229380,329750,2212102,257,2443266,2459651,264965]

theorem envBound22073 : H12AffineFastState.Bounded env22073 := by
  intro p hp
  have h : env22073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22072_22073 : H12AffineEnvironment.transform 12 268 env22072 = env22073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22072 == env22073) = true)

theorem identity22073 : scanCanonicalize (H12AffineFastState.compose env22073 (packedSelected [0,2,6,7,11,12,15,16,18] rootPS)) = affineNative (2^(20+1) ^^^ 280836) := by decide +kernel

theorem selectedBound22073 : packedSelected [0,2,6,7,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env22074 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,280836,4194304,4458772,4227074,268,17,4262150,4540435,4198400,4229380,329750,362498,257,65798,114951,264965]

theorem envBound22074 : H12AffineFastState.Bounded env22074 := by
  intro p hp
  have h : env22074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22073_22074 : H12AffineEnvironment.transform 20 280836 env22073 = env22074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 280836 env22073 == env22074) = true)

theorem identity22074 : scanCanonicalize (H12AffineFastState.compose env22074 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 362498) := by decide +kernel

theorem selectedBound22074 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env22075 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,262144,272,32769,280836,362498,98582,329728,268,17,295172,49169,366594,327942,329750,362498,257,65798,114951,264965]

theorem envBound22075 : H12AffineFastState.Bounded env22075 := by
  intro p hp
  have h : env22075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22074_22075 : H12AffineEnvironment.transform 21 362498 env22074 = env22075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362498 env22074 == env22075) = true)

theorem identity22075 : scanCanonicalize (H12AffineFastState.compose env22075 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound22075 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22076 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,65536,16400,2309,272,32769,16385,98567,98582,65797,268,17,34817,49169,102663,67587,65811,98567,257,65798,114951,512]

theorem envBound22076 : H12AffineFastState.Bounded env22076 := by
  intro p hp
  have h : env22076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22075_22076 : H12AffineEnvironment.transform 17 2309 env22075 = env22076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env22075 == env22076) = true)

theorem identity22076 : scanCanonicalize (H12AffineFastState.compose env22076 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound22076 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22077 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,32768,33030,16400,2309,272,32769,16385,1,16,32771,268,17,34817,49169,4097,35077,32789,1,257,32768,16385,512]

theorem envBound22077 : H12AffineFastState.Bounded env22077 := by
  intro p hp
  have h : env22077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22076_22077 : H12AffineEnvironment.transform 15 33030 env22076 = env22077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env22076 == env22077) = true)

theorem identity22077 : scanCanonicalize (H12AffineFastState.compose env22077 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22077 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22078 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,4096,268,16384,1,263,16400,2309,272,0,16385,1,16,2,268,17,2048,16400,4097,2308,20,1,257,1,16385,512]

theorem envBound22078 : H12AffineFastState.Bounded env22078 := by
  intro p hp
  have h : env22078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22077_22078 : H12AffineEnvironment.transform 14 1 env22077 = env22078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22077 == env22078) = true)

def env22079 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,262144,273,32769,2097152,4194304,4466712,4235535,8192,17,4262151,6365211,6584329,4237320,329750,2212102,257,2443267,2468111,272904]

theorem envBound22079 : H12AffineFastState.Bounded env22079 := by
  intro p hp
  have h : env22079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22071_22079 : H12AffineEnvironment.transform 4 1 env22071 = env22079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22071 == env22079) = true)

theorem identity22079 : scanCanonicalize (H12AffineFastState.compose env22079 (packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 2309) := by decide +kernel

theorem selectedBound22079 : packedSelected [0,7,9,14,16,17,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env22080 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,2309,273,32769,2097152,4194304,4202781,4235535,8192,17,4262151,6365211,6320396,4237320,65811,2212102,257,2179334,2203658,8973]

theorem envBound22080 : H12AffineFastState.Bounded env22080 := by
  intro p hp
  have h : env22080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22079_22080 : H12AffineEnvironment.transform 17 2309 env22079 = env22080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2309 env22079 == env22080) = true)

theorem identity22080 : scanCanonicalize (H12AffineFastState.compose env22080 (packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS)) = affineNative (2^(20+1) ^^^ 122891) := by decide +kernel

theorem selectedBound22080 : packedSelected [0,1,2,3,5,6,7,8,10,11,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env22081 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,32768,65536,16400,2309,273,32769,122891,4194304,4202781,4235535,8192,17,4262151,4243472,4296967,4237320,65811,8461,257,41229,16385,8973]

theorem envBound22081 : H12AffineFastState.Bounded env22081 := by
  intro p hp
  have h : env22081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22080_22081 : H12AffineEnvironment.transform 20 122891 env22080 = env22081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 122891 env22080 == env22081) = true)

theorem identity22081 : scanCanonicalize (H12AffineFastState.compose env22081 (packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22081 : packedSelected [1,3,4,5,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env22082 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,1,65536,16400,2309,273,0,90122,4194304,4202781,4202766,8192,17,4262151,4210705,4264198,4204553,65811,8461,257,8460,16385,8973]

theorem envBound22082 : H12AffineFastState.Bounded env22082 := by
  intro p hp
  have h : env22082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22081_22082 : H12AffineEnvironment.transform 14 1 env22081 = env22082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22081 == env22082) = true)

theorem identity22082 : scanCanonicalize (H12AffineFastState.compose env22082 (packedSelected [0,1,7,8,10,11,12,14] rootPS)) = affineNative (2^(21+1) ^^^ 65799) := by decide +kernel

theorem selectedBound22082 : packedSelected [0,1,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22083 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,16384,1,65536,16400,2309,273,0,90122,65799,73754,73737,8192,17,2048,82198,4097,76046,65811,8461,257,8460,16385,8973]

theorem envBound22083 : H12AffineFastState.Bounded env22083 := by
  intro p hp
  have h : env22083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22082_22083 : H12AffineEnvironment.transform 21 65799 env22082 = env22083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65799 env22082 == env22083) = true)

theorem identity22083 : scanCanonicalize (H12AffineFastState.compose env22083 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound22083 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env22084 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,4096,8192,4373,1,65536,4357,2309,273,0,78111,65799,73754,73737,8192,17,2048,69635,4097,76046,65811,8461,257,8460,4372,8973]

theorem envBound22084 : H12AffineFastState.Bounded env22084 := by
  intro p hp
  have h : env22084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22083_22084 : H12AffineEnvironment.transform 13 4373 env22083 = env22084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env22083 == env22084) = true)

theorem identity22084 : scanCanonicalize (H12AffineFastState.compose env22084 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound22084 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env22085 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,2325,8192,2048,1,65536,2064,2309,273,0,75786,65799,73754,73737,8192,17,2048,67862,2324,76046,65811,8461,257,8460,2049,8973]

theorem envBound22085 : H12AffineFastState.Bounded env22085 := by
  intro p hp
  have h : env22085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22084_22085 : H12AffineEnvironment.transform 11 2325 env22084 = env22085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env22084 == env22085) = true)

theorem identity22085 : scanCanonicalize (H12AffineFastState.compose env22085 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound22085 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env22086 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,2325,2056,2048,1,65536,2064,2309,273,0,65538,65799,67602,67585,2056,17,2048,67862,2324,65798,65811,2309,257,2308,2049,2821]

theorem envBound22086 : H12AffineFastState.Bounded env22086 := by
  intro p hp
  have h : env22086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22085_22086 : H12AffineEnvironment.transform 12 2056 env22085 = env22086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22085 == env22086) = true)

theorem identity22086 : scanCanonicalize (H12AffineFastState.compose env22086 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound22086 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22087 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,16,269,261,1,65536,277,0,273,0,65538,65799,65815,65796,269,17,261,65555,17,65798,65811,0,257,1,260,512]

theorem envBound22087 : H12AffineFastState.Bounded env22087 := by
  intro p hp
  have h : env22087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22086_22087 : H12AffineEnvironment.transform 10 261 env22086 = env22087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env22086 == env22087) = true)

theorem identity22087 : scanCanonicalize (H12AffineFastState.compose env22087 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound22087 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22088 : List Nat := [2,4,8,16,1,16,8,256,512,272,261,16,269,261,1,262,277,0,273,0,260,1,17,2,269,17,261,277,17,0,21,0,257,1,260,512]

theorem envBound22088 : H12AffineFastState.Bounded env22088 := by
  intro p hp
  have h : env22088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22087_22088 : H12AffineEnvironment.transform 15 262 env22087 = env22088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env22087 == env22088) = true)

theorem identity22088 : scanCanonicalize (H12AffineFastState.compose env22088 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22089 : List Nat := [2,4,8,1,1,1,8,256,512,257,261,1,269,261,1,262,260,0,256,0,260,1,0,2,269,0,261,260,0,0,4,0,257,1,260,512]

theorem envBound22089 : H12AffineFastState.Bounded env22089 := by
  intro p hp
  have h : env22089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22088_22089 : H12AffineEnvironment.transform 3 1 env22088 = env22089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22088 == env22089) = true)

theorem identity22089 : scanCanonicalize (H12AffineFastState.compose env22089 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22089 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22090 : List Nat := [2,4,2,1,1,1,2,256,512,257,261,1,263,261,1,262,260,0,256,0,260,1,0,2,263,0,261,260,0,0,4,0,257,1,260,512]

theorem envBound22090 : H12AffineFastState.Bounded env22090 := by
  intro p hp
  have h : env22090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22089_22090 : H12AffineEnvironment.transform 2 2 env22089 = env22090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22089 == env22090) = true)

theorem identity22090 : scanCanonicalize (H12AffineFastState.compose env22090 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound22090 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22091 : List Nat := [2,4,2,1,1,1,2,256,7,257,261,1,263,261,1,262,260,0,256,0,260,1,0,2,263,0,261,260,0,0,4,0,257,1,260,7]

theorem envBound22091 : H12AffineFastState.Bounded env22091 := by
  intro p hp
  have h : env22091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22090_22091 : H12AffineEnvironment.transform 8 7 env22090 = env22091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env22090 == env22091) = true)

theorem identity22091 : scanCanonicalize (H12AffineFastState.compose env22091 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22091 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22092 : List Nat := [2,4,2,1,1,1,2,4,7,5,1,1,3,1,1,2,0,0,4,0,0,1,0,2,3,0,1,0,0,0,4,0,5,1,0,7]

theorem envBound22092 : H12AffineFastState.Bounded env22092 := by
  intro p hp
  have h : env22092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22091_22092 : H12AffineEnvironment.transform 7 4 env22091 = env22092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22091 == env22092) = true)

theorem identity22092 : scanCanonicalize (H12AffineFastState.compose env22092 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22093 : List Nat := [0,4,0,1,1,1,0,4,5,5,1,1,1,1,1,0,0,0,4,0,0,1,0,0,1,0,1,0,0,0,4,0,5,1,0,5]

theorem envBound22093 : H12AffineFastState.Bounded env22093 := by
  intro p hp
  have h : env22093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22092_22093 : H12AffineEnvironment.transform 0 0 env22092 = env22093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22092 == env22093) = true)

def env22094 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685879,8192,16,4262183,10816819,10507520,8683536,331046,15068207,257,2444562,2468927,272937]

theorem envBound22094 : H12AffineFastState.Bounded env22094 := by
  intro p hp
  have h : env22094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22060_22094 : H12AffineEnvironment.transform 5 17 env22060 = env22094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22060 == env22094) = true)

def env22095 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685879,8192,16,4262183,10815491,10506288,8683536,329750,15067423,257,2443298,2468111,272937]

theorem envBound22095 : H12AffineFastState.Bounded env22095 := by
  intro p hp
  have h : env22095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22094_22095 : H12AffineEnvironment.transform 9 304 env22094 = env22095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env22094 == env22095) = true)

theorem identity22095 : scanCanonicalize (H12AffineFastState.compose env22095 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4268090) := by decide +kernel

theorem selectedBound22095 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22096 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4268090,4565261,8192,16,4262183,6563897,6385674,4562986,329750,2410789,257,2443298,2468111,272937]

theorem envBound22096 : H12AffineFastState.Bounded env22096 := by
  intro p hp
  have h : env22096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22095_22096 : H12AffineEnvironment.transform 22 4268090 env22095 = env22096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268090 env22095 == env22096) = true)

theorem identity22096 : scanCanonicalize (H12AffineFastState.compose env22096 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22096 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22097 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4268090,4292901,8192,16,4262183,6291473,6385674,4294658,73790,2154765,257,2187274,2195751,513]

theorem envBound22097 : H12AffineFastState.Bounded env22097 := by
  intro p hp
  have h : env22097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22096_22097 : H12AffineEnvironment.transform 17 10280 env22096 = env22097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22096 == env22097) = true)

theorem identity22097 : scanCanonicalize (H12AffineFastState.compose env22097 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22097 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env22098 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,1,65536,16400,10280,305,0,2097152,4194304,4268090,4260132,8192,16,4262183,6291473,6385674,4261891,73790,2121996,257,2187274,2162982,513]

theorem envBound22098 : H12AffineFastState.Bounded env22098 := by
  intro p hp
  have h : env22098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22097_22098 : H12AffineEnvironment.transform 14 1 env22097 = env22098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22097 == env22098) = true)

theorem identity22098 : scanCanonicalize (H12AffineFastState.compose env22098 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22098 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22099 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,1,8203,16400,10280,305,0,2097152,4194304,4194353,4202799,8192,16,4204844,6291473,6311937,4204552,53,2121996,257,2113537,2105645,513]

theorem envBound22099 : H12AffineFastState.Bounded env22099 := by
  intro p hp
  have h : env22099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22098_22099 : H12AffineEnvironment.transform 15 8203 env22098 = env22099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22098 == env22099) = true)

theorem identity22099 : scanCanonicalize (H12AffineFastState.compose env22099 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113537) := by decide +kernel

theorem selectedBound22099 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22100 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,1,8203,16400,10280,305,0,2097152,2113537,2113584,2122030,8192,16,2124077,16400,4096,2123785,53,2121996,257,2113537,2105645,513]

theorem envBound22100 : H12AffineFastState.Bounded env22100 := by
  intro p hp
  have h : env22100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22099_22100 : H12AffineEnvironment.transform 21 2113537 env22099 = env22100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113537 env22099 == env22100) = true)

theorem identity22100 : scanCanonicalize (H12AffineFastState.compose env22100 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24876) := by decide +kernel

theorem selectedBound22100 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22101 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,1,8203,16400,10280,305,0,24876,8493,8476,2,8192,16,2049,16400,4096,2341,53,32,257,8493,16385,513]

theorem envBound22101 : H12AffineFastState.Bounded env22101 := by
  intro p hp
  have h : env22101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22100_22101 : H12AffineEnvironment.transform 20 24876 env22100 = env22101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24876 env22100 == env22101) = true)

theorem identity22101 : scanCanonicalize (H12AffineFastState.compose env22101 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22101 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22102 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,269,16384,1,262,16400,2341,305,0,16417,32,17,2,269,16,2049,16400,4096,2341,53,32,257,32,16385,513]

theorem envBound22102 : H12AffineFastState.Bounded env22102 := by
  intro p hp
  have h : env22102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22101_22102 : H12AffineEnvironment.transform 12 269 env22101 = env22102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22101 == env22102) = true)

theorem identity22102 : scanCanonicalize (H12AffineFastState.compose env22102 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22103 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,4096,269,16384,1,262,16400,2309,273,0,16385,0,17,2,269,16,2049,16400,4096,2309,21,0,257,0,16385,513]

theorem envBound22103 : H12AffineFastState.Bounded env22103 := by
  intro p hp
  have h : env22103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22102_22103 : H12AffineEnvironment.transform 4 0 env22102 = env22103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22102 == env22103) = true)

theorem identity22103 : scanCanonicalize (H12AffineFastState.compose env22103 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound22103 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22104 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,17,269,16384,1,262,16400,2309,273,0,16385,0,17,2,269,16,2049,16400,17,2309,21,0,257,0,16385,513]

theorem envBound22104 : H12AffineFastState.Bounded env22104 := by
  intro p hp
  have h : env22104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22103_22104 : H12AffineEnvironment.transform 11 17 env22103 = env22104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22103 == env22104) = true)

theorem identity22104 : scanCanonicalize (H12AffineFastState.compose env22104 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 512) := by decide +kernel

theorem selectedBound22104 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22105 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,17,269,512,1,262,528,2309,273,0,513,0,17,2,269,16,2049,528,17,2309,21,0,257,0,513,513]

theorem envBound22105 : H12AffineFastState.Bounded env22105 := by
  intro p hp
  have h : env22105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22104_22105 : H12AffineEnvironment.transform 13 512 env22104 = env22105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 512 env22104 == env22105) = true)

theorem identity22105 : scanCanonicalize (H12AffineFastState.compose env22105 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound22105 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22106 : List Nat := [2,4,8,16,0,17,8,256,512,272,528,17,269,512,1,262,528,789,273,0,513,0,17,2,269,16,529,528,17,789,21,0,257,0,513,513]

theorem envBound22106 : H12AffineFastState.Bounded env22106 := by
  intro p hp
  have h : env22106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22105_22106 : H12AffineEnvironment.transform 10 528 env22105 = env22106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env22105 == env22106) = true)

theorem identity22106 : scanCanonicalize (H12AffineFastState.compose env22106 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22106 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22107 : List Nat := [2,4,8,0,0,1,8,256,512,256,512,1,269,512,1,262,512,773,257,0,513,0,1,2,269,0,513,512,1,773,5,0,257,0,513,513]

theorem envBound22107 : H12AffineFastState.Bounded env22107 := by
  intro p hp
  have h : env22107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22106_22107 : H12AffineEnvironment.transform 3 0 env22106 = env22107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22106 == env22107) = true)

theorem identity22107 : scanCanonicalize (H12AffineFastState.compose env22107 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound22107 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22108 : List Nat := [2,4,8,0,0,1,8,256,260,256,260,1,269,260,1,262,260,1,257,0,261,0,1,2,269,0,261,260,1,1,5,0,257,0,261,261]

theorem envBound22108 : H12AffineFastState.Bounded env22108 := by
  intro p hp
  have h : env22108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22107_22108 : H12AffineEnvironment.transform 8 260 env22107 = env22108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22107 == env22108) = true)

theorem identity22108 : scanCanonicalize (H12AffineFastState.compose env22108 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22109 : List Nat := [2,4,8,0,0,1,8,4,0,4,0,1,9,0,1,2,0,1,5,0,1,0,1,2,9,0,1,0,1,1,5,0,5,0,1,1]

theorem envBound22109 : H12AffineFastState.Bounded env22109 := by
  intro p hp
  have h : env22109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22108_22109 : H12AffineEnvironment.transform 7 4 env22108 = env22109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22108 == env22109) = true)

theorem identity22109 : scanCanonicalize (H12AffineFastState.compose env22109 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22110 : List Nat := [2,4,2,0,0,1,2,4,0,4,0,1,3,0,1,2,0,1,5,0,1,0,1,2,3,0,1,0,1,1,5,0,5,0,1,1]

theorem envBound22110 : H12AffineFastState.Bounded env22110 := by
  intro p hp
  have h : env22110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22109_22110 : H12AffineEnvironment.transform 2 2 env22109 = env22110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22109 == env22110) = true)

def env22111 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685879,8192,16,4262183,10815490,10506289,8683536,329751,15067422,257,2443299,2468110,272937]

theorem envBound22111 : H12AffineFastState.Bounded env22111 := by
  intro p hp
  have h : env22111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22094_22111 : H12AffineEnvironment.transform 9 305 env22094 = env22111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env22094 == env22111) = true)

theorem identity22111 : scanCanonicalize (H12AffineFastState.compose env22111 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4524050) := by decide +kernel

theorem selectedBound22111 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env22112 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4524050,4292901,8192,16,4262183,6291472,6641699,4294658,329751,2154764,257,2443299,2468110,272937]

theorem envBound22112 : H12AffineFastState.Bounded env22112 := by
  intro p hp
  have h : env22112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22111_22112 : H12AffineEnvironment.transform 22 4524050 env22111 = env22112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4524050 env22111 == env22112) = true)

def env22113 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4268090,4292901,8192,16,4262183,6291472,6385675,4294658,73791,2154764,257,2187275,2195750,513]

theorem envBound22113 : H12AffineFastState.Bounded env22113 := by
  intro p hp
  have h : env22113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22112_22113 : H12AffineEnvironment.transform 17 10280 env22112 = env22113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22112 == env22113) = true)

theorem identity22113 : scanCanonicalize (H12AffineFastState.compose env22113 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22113 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env22114 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,1,65536,16400,10280,304,0,2097152,4194304,4268090,4260132,8192,16,4262183,6291472,6385675,4261891,73791,2121997,257,2187275,2162983,513]

theorem envBound22114 : H12AffineFastState.Bounded env22114 := by
  intro p hp
  have h : env22114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22113_22114 : H12AffineEnvironment.transform 14 1 env22113 = env22114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22113 == env22114) = true)

theorem identity22114 : scanCanonicalize (H12AffineFastState.compose env22114 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22114 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22115 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,1,8203,16400,10280,304,0,2097152,4194304,4194353,4202799,8192,16,4204844,6291472,6311936,4204552,52,2121997,257,2113536,2105644,513]

theorem envBound22115 : H12AffineFastState.Bounded env22115 := by
  intro p hp
  have h : env22115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22114_22115 : H12AffineEnvironment.transform 15 8203 env22114 = env22115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22114 == env22115) = true)

theorem identity22115 : scanCanonicalize (H12AffineFastState.compose env22115 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 2113536) := by decide +kernel

theorem selectedBound22115 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env22116 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,1,8203,16400,10280,304,0,2097152,2113536,2113585,2122031,8192,16,2124076,16400,4096,2123784,52,2121997,257,2113536,2105644,513]

theorem envBound22116 : H12AffineFastState.Bounded env22116 := by
  intro p hp
  have h : env22116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22115_22116 : H12AffineEnvironment.transform 21 2113536 env22115 = env22116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2113536 env22115 == env22116) = true)

theorem identity22116 : scanCanonicalize (H12AffineFastState.compose env22116 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 24877) := by decide +kernel

theorem selectedBound22116 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22117 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,1,8203,16400,10280,304,0,24877,8493,8476,2,8192,16,2049,16400,4096,2341,52,32,257,8493,16385,513]

theorem envBound22117 : H12AffineFastState.Bounded env22117 := by
  intro p hp
  have h : env22117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22116_22117 : H12AffineEnvironment.transform 20 24877 env22116 = env22117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 24877 env22116 == env22117) = true)

theorem identity22117 : scanCanonicalize (H12AffineFastState.compose env22117 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22117 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22118 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,269,16384,1,262,16400,2341,304,0,16416,32,17,2,269,16,2049,16400,4096,2341,52,32,257,32,16385,513]

theorem envBound22118 : H12AffineFastState.Bounded env22118 := by
  intro p hp
  have h : env22118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22117_22118 : H12AffineEnvironment.transform 12 269 env22117 = env22118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22117 == env22118) = true)

theorem identity22118 : scanCanonicalize (H12AffineFastState.compose env22118 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22118 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22119 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,4096,269,16384,1,262,16400,2309,272,0,16384,0,17,2,269,16,2049,16400,4096,2309,20,0,257,0,16385,513]

theorem envBound22119 : H12AffineFastState.Bounded env22119 := by
  intro p hp
  have h : env22119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22118_22119 : H12AffineEnvironment.transform 4 0 env22118 = env22119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22118 == env22119) = true)

theorem identity22119 : scanCanonicalize (H12AffineFastState.compose env22119 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound22119 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22120 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,17,269,16384,1,262,16400,2309,272,0,16384,0,17,2,269,16,2049,16400,17,2309,20,0,257,0,16385,513]

theorem envBound22120 : H12AffineFastState.Bounded env22120 := by
  intro p hp
  have h : env22120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22119_22120 : H12AffineEnvironment.transform 11 17 env22119 = env22120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22119 == env22120) = true)

theorem identity22120 : scanCanonicalize (H12AffineFastState.compose env22120 (packedSelected [0,4] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound22120 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22121 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,17,269,513,1,262,529,2309,272,0,513,0,17,2,269,16,2049,529,17,2309,20,0,257,0,512,513]

theorem envBound22121 : H12AffineFastState.Bounded env22121 := by
  intro p hp
  have h : env22121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22120_22121 : H12AffineEnvironment.transform 13 513 env22120 = env22121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env22120 == env22121) = true)

theorem identity22121 : scanCanonicalize (H12AffineFastState.compose env22121 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound22121 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22122 : List Nat := [2,4,8,16,0,17,8,256,512,273,528,17,269,513,1,262,529,789,272,0,513,0,17,2,269,16,529,529,17,789,20,0,257,0,512,513]

theorem envBound22122 : H12AffineFastState.Bounded env22122 := by
  intro p hp
  have h : env22122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22121_22122 : H12AffineEnvironment.transform 10 528 env22121 = env22122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env22121 == env22122) = true)

theorem identity22122 : scanCanonicalize (H12AffineFastState.compose env22122 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22122 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22123 : List Nat := [2,4,8,1,0,0,8,256,512,256,513,0,269,513,1,262,512,772,257,0,513,0,0,2,269,1,512,512,0,772,5,0,257,0,512,513]

theorem envBound22123 : H12AffineFastState.Bounded env22123 := by
  intro p hp
  have h : env22123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22122_22123 : H12AffineEnvironment.transform 3 1 env22122 = env22123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22122 == env22123) = true)

theorem identity22123 : scanCanonicalize (H12AffineFastState.compose env22123 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound22123 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22124 : List Nat := [2,4,8,1,0,0,8,256,260,256,261,0,269,261,1,262,260,0,257,0,261,0,0,2,269,1,260,260,0,0,5,0,257,0,260,261]

theorem envBound22124 : H12AffineFastState.Bounded env22124 := by
  intro p hp
  have h : env22124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22123_22124 : H12AffineEnvironment.transform 8 260 env22123 = env22124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22123 == env22124) = true)

def env22125 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,4194304,4268091,4292901,8192,16,4262183,6291472,6385674,4294658,73790,2154764,257,2187274,2195751,512]

theorem envBound22125 : H12AffineFastState.Bounded env22125 := by
  intro p hp
  have h : env22125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22112_22125 : H12AffineEnvironment.transform 17 10281 env22112 = env22125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22112 == env22125) = true)

theorem identity22125 : scanCanonicalize (H12AffineFastState.compose env22125 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(21+1) ^^^ 2226234) := by decide +kernel

theorem selectedBound22125 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env22126 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,2226234,2152449,2128159,8192,16,2158877,129066,34864,2125880,73790,2154764,257,2187274,2195751,512]

theorem envBound22126 : H12AffineFastState.Bounded env22126 := by
  intro p hp
  have h : env22126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22125_22126 : H12AffineEnvironment.transform 21 2226234 env22125 = env22126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2226234 env22125 == env22126) = true)

theorem identity22126 : scanCanonicalize (H12AffineFastState.compose env22126 (packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 47130) := by decide +kernel

theorem selectedBound22126 : packedSelected [1,2,4,6,8,9,10,11,14,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env22127 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,47130,16400,10281,304,32769,2097152,2113568,2152449,2128159,8192,16,2158877,16432,34864,2125880,38948,2154764,257,2152464,2111805,512]

theorem envBound22127 : H12AffineFastState.Bounded env22127 := by
  intro p hp
  have h : env22127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22126_22127 : H12AffineEnvironment.transform 15 47130 env22126 = env22127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47130 env22126 == env22127) = true)

theorem identity22127 : scanCanonicalize (H12AffineFastState.compose env22127 (packedSelected [17,21] rootPS)) = affineNative (2^(20+1) ^^^ 55313) := by decide +kernel

theorem selectedBound22127 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22128 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,47130,16400,10281,304,32769,55313,38961,16,41230,8192,16,10508,16432,34864,43049,38948,14621,257,1,57644,512]

theorem envBound22128 : H12AffineFastState.Bounded env22128 := by
  intro p hp
  have h : env22128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22127_22128 : H12AffineEnvironment.transform 20 55313 env22127 = env22128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 55313 env22127 == env22128) = true)

theorem identity22128 : scanCanonicalize (H12AffineFastState.compose env22128 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 26664) := by decide +kernel

theorem selectedBound22128 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env22129 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,26664,20530,16400,10281,304,26665,12345,28697,16,18726,8192,16,10508,16432,24600,16385,28684,14621,257,1,2308,512]

theorem envBound22129 : H12AffineFastState.Bounded env22129 := by
  intro p hp
  have h : env22129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22128_22129 : H12AffineEnvironment.transform 14 26664 env22128 = env22129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26664 env22128 == env22129) = true)

theorem identity22129 : scanCanonicalize (H12AffineFastState.compose env22129 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 6168) := by decide +kernel

theorem selectedBound22129 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22130 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,6168,16384,20528,20530,16400,4145,304,20529,2081,18433,16,18726,6168,16,4372,16432,22528,16385,18452,261,257,1,2308,512]

theorem envBound22130 : H12AffineFastState.Bounded env22130 := by
  intro p hp
  have h : env22130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22129_22130 : H12AffineEnvironment.transform 12 6168 env22129 = env22130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6168 env22129 == env22130) = true)

theorem identity22130 : scanCanonicalize (H12AffineFastState.compose env22130 (packedSelected [2,14] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound22130 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env22131 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,6168,4405,261,263,4389,4145,304,260,2081,6452,16,6163,6168,16,4372,4357,2357,4404,6433,261,257,1,2308,512]

theorem envBound22131 : H12AffineFastState.Bounded env22131 := by
  intro p hp
  have h : env22131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22130_22131 : H12AffineEnvironment.transform 13 4405 env22130 = env22131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env22130 == env22131) = true)

theorem identity22131 : scanCanonicalize (H12AffineFastState.compose env22131 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22131 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22132 : List Nat := [2,4,8,16,32,17,8,37,512,20,2048,4096,6168,4112,32,34,4096,4145,21,33,2081,6161,16,6163,6168,16,4145,4128,2064,4113,6148,32,36,1,2081,512]

theorem envBound22132 : H12AffineFastState.Bounded env22132 := by
  intro p hp
  have h : env22132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22131_22132 : H12AffineEnvironment.transform 7 37 env22131 = env22132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22131 == env22132) = true)

theorem identity22132 : scanCanonicalize (H12AffineFastState.compose env22132 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22132 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env22133 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,4096,6168,4112,1,3,4096,4112,21,0,2048,6161,16,6163,6168,16,4112,4097,2064,4113,6148,1,5,1,2048,512]

theorem envBound22133 : H12AffineFastState.Bounded env22133 := by
  intro p hp
  have h : env22133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22132_22133 : H12AffineEnvironment.transform 4 1 env22132 = env22133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22132 == env22133) = true)

theorem identity22133 : scanCanonicalize (H12AffineFastState.compose env22133 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound22133 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22134 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,4096,4120,4112,1,3,4096,4112,21,0,0,4113,16,4115,4120,16,4112,4097,16,4113,4100,1,5,1,0,512]

theorem envBound22134 : H12AffineFastState.Bounded env22134 := by
  intro p hp
  have h : env22134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22133_22134 : H12AffineEnvironment.transform 10 0 env22133 = env22134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22133 == env22134) = true)

theorem identity22134 : scanCanonicalize (H12AffineFastState.compose env22134 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound22134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22135 : List Nat := [2,4,8,16,1,17,8,4,512,20,0,17,9,1,1,3,17,1,21,0,0,0,16,2,9,16,1,16,16,0,21,1,5,1,0,512]

theorem envBound22135 : H12AffineFastState.Bounded env22135 := by
  intro p hp
  have h : env22135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22134_22135 : H12AffineEnvironment.transform 11 17 env22134 = env22135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22134 == env22135) = true)

def env22136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4262263,10816866,10507601,8683537,331127,15068207,257,2444611,2468974,272937]

theorem envBound22136 : H12AffineFastState.Bounded env22136 := by
  intro p hp
  have h : env22136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22059_22136 : H12AffineEnvironment.transform 16 16401 env22059 = env22136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22059 == env22136) = true)

theorem identity22136 : scanCanonicalize (H12AffineFastState.compose env22136 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound22136 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429902,8192,65,4262263,10560842,10507601,8431673,75103,14795783,257,2188651,2196550,513]

theorem envBound22137 : H12AffineFastState.Bounded env22137 := by
  intro p hp
  have h : env22137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22136_22137 : H12AffineEnvironment.transform 17 10280 env22136 = env22137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22136 == env22137) = true)

def env22138 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429854,8192,17,4262183,10560794,10507521,8431673,75023,14795783,257,2188603,2196502,513]

theorem envBound22138 : H12AffineFastState.Bounded env22138 := by
  intro p hp
  have h : env22138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22137_22138 : H12AffineEnvironment.transform 5 16 env22137 = env22138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22137 == env22138) = true)

theorem identity22138 : scanCanonicalize (H12AffineFastState.compose env22138 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4292918) := by decide +kernel

theorem selectedBound22138 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env22139 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4292918,4268072,8192,17,4262183,6333484,6411319,4270351,75023,2114865,257,2188603,2196502,513]

theorem envBound22139 : H12AffineFastState.Bounded env22139 := by
  intro p hp
  have h : env22139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22138_22139 : H12AffineEnvironment.transform 22 4292918 env22138 = env22139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292918 env22138 == env22139) = true)

theorem identity22139 : scanCanonicalize (H12AffineFastState.compose env22139 (packedSelected [0,7,16] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound22139 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env22140 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,8492,106522,65796,8192,17,75787,2131200,2225435,67619,75023,2114865,257,2188603,2196502,513]

theorem envBound22140 : H12AffineFastState.Bounded env22140 := by
  intro p hp
  have h : env22140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22139_22140 : H12AffineEnvironment.transform 21 8492 env22139 = env22140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env22139 == env22140) = true)

theorem identity22140 : scanCanonicalize (H12AffineFastState.compose env22140 (packedSelected [0,4,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound22140 : packedSelected [0,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22141 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,50448,8492,106522,65796,8192,17,75787,16400,77835,67619,75023,32801,257,106539,82182,513]

theorem envBound22141 : H12AffineFastState.Bounded env22141 := by
  intro p hp
  have h : env22141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22140_22141 : H12AffineEnvironment.transform 20 50448 env22140 = env22141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env22140 == env22141) = true)

theorem identity22141 : scanCanonicalize (H12AffineFastState.compose env22141 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound22141 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22142 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10280,1025,32769,50448,8492,16,41230,8192,17,34817,16400,36865,43049,34053,32801,257,33,57612,513]

theorem envBound22142 : H12AffineFastState.Bounded env22142 := by
  intro p hp
  have h : env22142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22141_22142 : H12AffineEnvironment.transform 15 40970 env22141 = env22142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env22141 == env22142) = true)

theorem identity22142 : scanCanonicalize (H12AffineFastState.compose env22142 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22142 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22143 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,33031,16401,2341,1025,32769,50448,33,16,32771,269,17,34817,16400,36865,35108,34053,32801,257,33,49153,513]

theorem envBound22143 : H12AffineFastState.Bounded env22143 := by
  intro p hp
  have h : env22143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22142_22143 : H12AffineEnvironment.transform 12 269 env22142 = env22143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22142 == env22143) = true)

theorem identity22143 : scanCanonicalize (H12AffineFastState.compose env22143 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22143 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22144 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,17680,33,16,3,269,17,2049,16400,4097,2340,1285,33,257,33,16385,513]

theorem envBound22144 : H12AffineFastState.Bounded env22144 := by
  intro p hp
  have h : env22144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22143_22144 : H12AffineEnvironment.transform 14 0 env22143 = env22144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22143 == env22144) = true)

theorem identity22144 : scanCanonicalize (H12AffineFastState.compose env22144 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound22144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22145 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,269,16384,0,263,16401,2341,1025,1,17680,33,16,3,269,17,2049,16400,1313,2340,1285,33,257,33,16385,513]

theorem envBound22145 : H12AffineFastState.Bounded env22145 := by
  intro p hp
  have h : env22145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22144_22145 : H12AffineEnvironment.transform 11 1312 env22144 = env22145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env22144 == env22145) = true)

theorem identity22145 : scanCanonicalize (H12AffineFastState.compose env22145 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound22145 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22146 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1556,1312,269,16384,0,263,16401,1841,1025,1,17680,33,16,3,269,17,1557,16400,1313,1840,1285,33,257,33,16385,513]

theorem envBound22146 : H12AffineFastState.Bounded env22146 := by
  intro p hp
  have h : env22146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22145_22146 : H12AffineEnvironment.transform 10 1556 env22145 = env22146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env22145 == env22146) = true)

theorem identity22146 : scanCanonicalize (H12AffineFastState.compose env22146 (packedSelected [1,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound22146 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22147 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1556,1312,269,1028,0,263,1045,1841,1025,1,276,33,16,3,269,17,1557,1044,1313,1840,1285,33,257,33,1029,513]

theorem envBound22147 : H12AffineFastState.Bounded env22147 := by
  intro p hp
  have h : env22147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22146_22147 : H12AffineEnvironment.transform 13 1028 env22146 = env22147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env22146 == env22147) = true)

theorem identity22147 : scanCanonicalize (H12AffineFastState.compose env22147 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound22147 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22148 : List Nat := [2,4,8,16,32,16,8,256,276,1024,1280,1312,269,1028,0,263,1045,1061,1025,1,276,33,16,3,269,17,1281,1044,1313,1060,1285,33,257,33,1029,277]

theorem envBound22148 : H12AffineFastState.Bounded env22148 := by
  intro p hp
  have h : env22148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22147_22148 : H12AffineEnvironment.transform 8 276 env22147 = env22148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env22147 == env22148) = true)

theorem identity22148 : scanCanonicalize (H12AffineFastState.compose env22148 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22148 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env22149 : List Nat := [2,4,8,16,32,16,8,4,16,1024,1028,1060,9,1028,0,3,1045,1061,1025,1,16,33,16,3,9,17,1029,1044,1061,1060,1025,33,5,33,1029,17]

theorem envBound22149 : H12AffineFastState.Bounded env22149 := by
  intro p hp
  have h : env22149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22148_22149 : H12AffineEnvironment.transform 7 4 env22148 = env22149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22148 == env22149) = true)

theorem identity22149 : scanCanonicalize (H12AffineFastState.compose env22149 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound22149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22150 : List Nat := [2,4,8,16,32,16,8,4,16,5,1,33,9,1,0,3,16,32,4,1,16,33,16,3,9,17,0,17,32,33,4,33,5,33,0,17]

theorem envBound22150 : H12AffineFastState.Bounded env22150 := by
  intro p hp
  have h : env22150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22149_22150 : H12AffineEnvironment.transform 9 5 env22149 = env22150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env22149 == env22150) = true)

def env22151 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429855,8192,16,4262182,10560795,10507520,8431673,75022,14795783,257,2188602,2196503,513]

theorem envBound22151 : H12AffineFastState.Bounded env22151 := by
  intro p hp
  have h : env22151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22137_22151 : H12AffineEnvironment.transform 5 17 env22137 = env22151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22137 == env22151) = true)

theorem identity22151 : scanCanonicalize (H12AffineFastState.compose env22151 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4235581) := by decide +kernel

theorem selectedBound22151 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env22152 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4235581,4194338,8192,16,4262182,6390822,6353981,4196612,75022,2188602,257,2188602,2196503,513]

theorem envBound22152 : H12AffineFastState.Bounded env22152 := by
  intro p hp
  have h : env22152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22151_22152 : H12AffineEnvironment.transform 22 4235581 env22151 = env22152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235581 env22151 == env22152) = true)

theorem identity22152 : scanCanonicalize (H12AffineFastState.compose env22152 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound22152 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env22153 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,41261,16,41231,8192,16,108555,2172171,2118928,43049,75022,2188602,257,2188602,2196503,513]

theorem envBound22153 : H12AffineFastState.Bounded env22153 := by
  intro p hp
  have h : env22153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22152_22153 : H12AffineEnvironment.transform 21 41261 env22152 = env22153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env22152 == env22153) = true)

theorem identity22153 : scanCanonicalize (H12AffineFastState.compose env22153 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22153 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22154 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1025,32769,2097152,41261,16,41231,8192,16,34817,2098433,2118928,43049,1284,2114864,257,2114864,2139165,513]

theorem envBound22154 : H12AffineFastState.Bounded env22154 := by
  intro p hp
  have h : env22154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22153_22154 : H12AffineEnvironment.transform 15 8202 env22153 = env22154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22153 == env22154) = true)

theorem identity22154 : scanCanonicalize (H12AffineFastState.compose env22154 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22154 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22155 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,8202,16401,10280,1025,1,2097152,8493,16,8463,8192,16,2049,2098433,2118928,10281,1284,2114864,257,2114864,2106397,513]

theorem envBound22155 : H12AffineFastState.Bounded env22155 := by
  intro p hp
  have h : env22155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22154_22155 : H12AffineEnvironment.transform 14 0 env22154 = env22155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22154 == env22155) = true)

theorem identity22155 : scanCanonicalize (H12AffineFastState.compose env22155 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22155 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22156 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,2097152,32,16,2,269,16,2049,2098433,2118928,2340,1284,2114864,257,2114864,2098448,513]

theorem envBound22156 : H12AffineFastState.Bounded env22156 := by
  intro p hp
  have h : env22156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22155_22156 : H12AffineEnvironment.transform 12 269 env22155 = env22156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22155 == env22156) = true)

theorem identity22156 : scanCanonicalize (H12AffineFastState.compose env22156 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 18724) := by decide +kernel

theorem selectedBound22156 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22157 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,263,16401,2341,1025,1,18724,32,16,2,269,16,2049,19493,7220,2340,1284,3092,257,3092,19508,513]

theorem envBound22157 : H12AffineFastState.Bounded env22157 := by
  intro p hp
  have h : env22157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22156_22157 : H12AffineEnvironment.transform 20 18724 env22156 = env22157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 18724 env22156 == env22157) = true)

theorem identity22157 : scanCanonicalize (H12AffineFastState.compose env22157 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 7425) := by decide +kernel

theorem selectedBound22157 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env22158 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7425,0,263,7440,2341,1025,1,5157,32,16,2,269,16,2049,4388,7220,2340,1284,3092,257,3092,4405,513]

theorem envBound22158 : H12AffineFastState.Bounded env22158 := by
  intro p hp
  have h : env22158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22157_22158 : H12AffineEnvironment.transform 13 7425 env22157 = env22158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7425 env22157 == env22158) = true)

theorem identity22158 : scanCanonicalize (H12AffineFastState.compose env22158 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound22158 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22159 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,269,292,0,263,309,2341,1025,1,2048,32,16,2,269,16,2049,3329,17,2340,1284,3092,257,3092,3344,513]

theorem envBound22159 : H12AffineFastState.Bounded env22159 := by
  intro p hp
  have h : env22159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22158_22159 : H12AffineEnvironment.transform 11 3109 env22158 = env22159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env22158 == env22159) = true)

theorem identity22159 : scanCanonicalize (H12AffineFastState.compose env22159 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22159 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22160 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,2064,269,292,0,263,309,2341,52,1,2048,32,16,2,269,16,2049,2356,17,2340,305,2081,257,2081,2341,513]

theorem envBound22160 : H12AffineFastState.Bounded env22160 := by
  intro p hp
  have h : env22160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22159_22160 : H12AffineEnvironment.transform 9 53 env22159 = env22160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22159 == env22160) = true)

theorem identity22160 : scanCanonicalize (H12AffineFastState.compose env22160 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22160 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22161 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,40,1,0,34,16,2048,52,1,2048,32,16,2,40,16,2049,2065,17,2049,20,2081,36,2081,2048,513]

theorem envBound22161 : H12AffineFastState.Bounded env22161 := by
  intro p hp
  have h : env22161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22160_22161 : H12AffineEnvironment.transform 7 37 env22160 = env22161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22160 == env22161) = true)

def env22162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4409702,10816867,10507601,8830976,331127,15068206,257,2444610,2468974,272936]

theorem envBound22162 : H12AffineFastState.Bounded env22162 := by
  intro p hp
  have h : env22162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22058_22162 : H12AffineEnvironment.transform 6 9 env22058 = env22162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22058 == env22162) = true)

theorem identity22162 : scanCanonicalize (H12AffineFastState.compose env22162 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 4415531) := by decide +kernel

theorem selectedBound22162 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env22163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,4415531,4712781,8193,65,4409702,6712648,6501754,4562987,331127,2526213,257,2444610,2468974,272936]

theorem envBound22163 : H12AffineFastState.Bounded env22163 := by
  intro p hp
  have h : env22163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22162_22163 : H12AffineEnvironment.transform 22 4415531 env22162 = env22163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415531 env22162 == env22163) = true)

def env22164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,4268091,4565341,8193,65,4262262,6565208,6387050,4562987,331127,2411541,257,2444610,2468974,272936]

theorem envBound22164 : H12AffineFastState.Bounded env22164 := by
  intro p hp
  have h : env22164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22163_22164 : H12AffineEnvironment.transform 16 16400 env22163 = env22164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22163 == env22164) = true)

theorem identity22164 : scanCanonicalize (H12AffineFastState.compose env22164 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22164 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1025,8540,2097152,4194304,4268091,4524032,8193,65,4262262,6565208,6387050,4522358,331127,2387272,257,2444610,2428211,272936]

theorem envBound22165 : H12AffineFastState.Bounded env22165 := by
  intro p hp
  have h : env22165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22164_22165 : H12AffineEnvironment.transform 14 8541 env22164 = env22165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22164 == env22165) = true)

theorem identity22165 : scanCanonicalize (H12AffineFastState.compose env22165 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 76159) := by decide +kernel

theorem selectedBound22165 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env22166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,76159,1025,8540,2097152,4194304,4268091,4202879,8193,65,4262262,6358055,6387050,4204553,9224,2180151,257,2122813,2106444,66391]

theorem envBound22166 : H12AffineFastState.Bounded env22166 := by
  intro p hp
  have h : env22166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22165_22166 : H12AffineEnvironment.transform 17 76159 env22165 = env22166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76159 env22165 == env22166) = true)

theorem identity22166 : scanCanonicalize (H12AffineFastState.compose env22166 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22166 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,2420,1025,8540,2097152,4194304,4194352,4202879,8193,65,4204925,6300716,6313313,4204553,9224,2122812,257,2122813,2106444,9052]

theorem envBound22167 : H12AffineFastState.Bounded env22167 := by
  intro p hp
  have h : env22167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22166_22167 : H12AffineEnvironment.transform 15 8203 env22166 = env22167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22166 == env22167) = true)

theorem identity22167 : scanCanonicalize (H12AffineFastState.compose env22167 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 4453) := by decide +kernel

theorem selectedBound22167 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env22168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,2420,1025,8540,4453,4194304,4194352,4202879,8193,65,4204925,4207945,4211716,4204553,9224,30041,257,30040,13609,9052]

theorem envBound22168 : H12AffineFastState.Bounded env22168 := by
  intro p hp
  have h : env22168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22167_22168 : H12AffineEnvironment.transform 20 4453 env22167 = env22168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4453 env22167 == env22168) = true)

theorem identity22168 : scanCanonicalize (H12AffineFastState.compose env22168 (packedSelected [0,2,6,11,14,16,17,18,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound22168 : packedSelected [0,2,6,11,14,16,17,18,20,27] rootPS < 2^1333 := by decide +kernel

def env22169 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,2420,1025,8540,4453,21588,21604,29995,8193,65,32041,24861,4176,31837,9224,30041,257,30040,13609,9052]

theorem envBound22169 : H12AffineFastState.Bounded env22169 := by
  intro p hp
  have h : env22169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22168_22169 : H12AffineEnvironment.transform 21 21588 env22168 = env22169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env22168 == env22169) = true)

theorem identity22169 : scanCanonicalize (H12AffineFastState.compose env22169 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound22169 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env22170 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8541,8203,5173,2420,1025,8540,4453,113,65,8462,8193,65,10508,13624,4176,10360,9224,8572,257,8573,13609,9052]

theorem envBound22170 : H12AffineFastState.Bounded env22170 := by
  intro p hp
  have h : env22170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22169_22170 : H12AffineEnvironment.transform 13 5157 env22169 = env22170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env22169 == env22170) = true)

theorem identity22170 : scanCanonicalize (H12AffineFastState.compose env22170 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22170 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22171 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5157,8461,8203,5173,2340,1025,8460,4405,33,17,8462,8193,17,10508,13624,4096,10280,9224,8492,257,8493,13609,8972]

theorem envBound22171 : H12AffineFastState.Bounded env22171 := by
  intro p hp
  have h : env22171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22170_22171 : H12AffineEnvironment.transform 5 16 env22170 = env22171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22170 == env22171) = true)

theorem identity22171 : scanCanonicalize (H12AffineFastState.compose env22171 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22171 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env22172 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,8192,2049,8461,8203,2065,2340,1025,8460,3345,33,17,8462,8193,17,10508,10524,3108,10280,9224,8492,257,8493,10509,8972]

theorem envBound22172 : H12AffineFastState.Bounded env22172 := by
  intro p hp
  have h : env22172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22171_22172 : H12AffineEnvironment.transform 11 3108 env22171 = env22172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env22171 == env22172) = true)

theorem identity22172 : scanCanonicalize (H12AffineFastState.compose env22172 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22172 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22173 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3108,269,2049,0,262,2065,2340,1025,1,3345,33,17,3,268,17,2049,2065,3108,2341,1285,33,257,32,2048,513]

theorem envBound22173 : H12AffineFastState.Bounded env22173 := by
  intro p hp
  have h : env22173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22172_22173 : H12AffineEnvironment.transform 12 269 env22172 = env22173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22172 == env22173) = true)

def env22174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,4268090,4565340,8193,65,4262263,6565209,6387051,4562987,331127,2411540,257,2444610,2468974,272936]

theorem envBound22174 : H12AffineFastState.Bounded env22174 := by
  intro p hp
  have h : env22174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22163_22174 : H12AffineEnvironment.transform 16 16401 env22163 = env22174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22163 == env22174) = true)

theorem identity22174 : scanCanonicalize (H12AffineFastState.compose env22174 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound22174 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env22175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,4268090,4268072,8193,65,4262263,6333485,6387051,4270431,99331,2114912,257,2212918,2172186,41820]

theorem envBound22175 : H12AffineFastState.Bounded env22175 := by
  intro p hp
  have h : env22175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22174_22175 : H12AffineEnvironment.transform 17 35188 env22174 = env22175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env22174 == env22175) = true)

theorem identity22175 : scanCanonicalize (H12AffineFastState.compose env22175 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22175 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35188,1025,32769,2097152,4194304,4235629,4235647,8193,65,4229152,6333485,6353980,4237320,1364,2114912,257,2114913,2139213,41820]

theorem envBound22176 : H12AffineFastState.Bounded env22176 := by
  intro p hp
  have h : env22176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22175_22176 : H12AffineEnvironment.transform 15 33111 env22175 = env22176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22175 == env22176) = true)

theorem identity22176 : scanCanonicalize (H12AffineFastState.compose env22176 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2147632) := by decide +kernel

theorem selectedBound22176 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env22177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35188,1025,32769,2097152,2147632,2122845,2122831,8193,65,2116880,24861,12556,2125112,1364,2114912,257,2114913,2139213,41820]

theorem envBound22177 : H12AffineFastState.Bounded env22177 := by
  intro p hp
  have h : env22177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22176_22177 : H12AffineEnvironment.transform 21 2147632 env22176 = env22177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2147632 env22176 == env22177) = true)

theorem identity22177 : scanCanonicalize (H12AffineFastState.compose env22177 (packedSelected [0,4,5,8,10,12,16,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 25676) := by decide +kernel

theorem selectedBound22177 : packedSelected [0,4,5,8,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env22178 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,35188,1025,32769,25676,41340,17,3,8193,65,10588,24861,12556,2420,1364,8492,257,8493,49153,41820]

theorem envBound22178 : H12AffineFastState.Bounded env22178 := by
  intro p hp
  have h : env22178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22177_22178 : H12AffineEnvironment.transform 20 25676 env22177 = env22178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25676 env22177 == env22178) = true)

theorem identity22178 : scanCanonicalize (H12AffineFastState.compose env22178 (packedSelected [1,2,3,7,9,10,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8281) := by decide +kernel

theorem selectedBound22178 : packedSelected [1,2,3,7,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env22179 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8281,8462,16401,10541,1025,8280,25676,293,17,3,8193,65,10588,24861,12556,2420,1364,8492,257,8493,24664,773]

theorem envBound22179 : H12AffineFastState.Bounded env22179 := by
  intro p hp
  have h : env22179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22178_22179 : H12AffineEnvironment.transform 14 8281 env22178 = env22179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8281 env22178 == env22179) = true)

theorem identity22179 : scanCanonicalize (H12AffineFastState.compose env22179 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound22179 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env22180 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,16384,80,263,16401,2340,1025,81,17477,293,17,3,8,65,2389,16660,4357,2420,1364,293,257,292,16465,773]

theorem envBound22180 : H12AffineFastState.Bounded env22180 := by
  intro p hp
  have h : env22180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22179_22180 : H12AffineEnvironment.transform 12 9 env22179 = env22180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22179 == env22180) = true)

theorem identity22180 : scanCanonicalize (H12AffineFastState.compose env22180 (packedSelected [1,2,3,4,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22180 : packedSelected [1,2,3,4,7,10,16] rootPS < 2^1333 := by decide +kernel

def env22181 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,4096,9,16384,80,2,16401,2081,1025,81,17477,32,17,3,8,65,2128,16401,4096,2161,1105,32,4,33,16465,512]

theorem envBound22181 : H12AffineFastState.Bounded env22181 := by
  intro p hp
  have h : env22181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22180_22181 : H12AffineEnvironment.transform 7 5 env22180 = env22181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22180 == env22181) = true)

theorem identity22181 : scanCanonicalize (H12AffineFastState.compose env22181 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound22181 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22182 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,9,16384,32,2,16401,2081,1025,33,17461,32,17,3,8,49,2080,16401,4096,2049,1057,32,4,33,16417,512]

theorem envBound22182 : H12AffineFastState.Bounded env22182 := by
  intro p hp
  have h : env22182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22181_22182 : H12AffineEnvironment.transform 5 48 env22181 = env22182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env22181 == env22182) = true)

theorem identity22182 : scanCanonicalize (H12AffineFastState.compose env22182 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound22182 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22183 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,9,5124,32,2,5141,2081,1025,33,4145,32,17,3,8,49,2080,5141,4096,2049,1057,32,4,33,5157,512]

theorem envBound22183 : H12AffineFastState.Bounded env22183 := by
  intro p hp
  have h : env22183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22182_22183 : H12AffineEnvironment.transform 13 5124 env22182 = env22183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env22182 == env22183) = true)

theorem identity22183 : scanCanonicalize (H12AffineFastState.compose env22183 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22183 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env22184 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,4096,9,5124,1,2,5141,2048,1025,0,4112,1,17,3,8,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound22184 : H12AffineFastState.Bounded env22184 := by
  intro p hp
  have h : env22184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22183_22184 : H12AffineEnvironment.transform 4 1 env22183 = env22184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22183 == env22184) = true)

def env22185 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,16,9,1044,1,2,1029,2048,1025,0,0,1,17,3,8,16,2049,1029,16,2049,1024,1,4,0,1044,512]

theorem envBound22185 : H12AffineFastState.Bounded env22185 := by
  intro p hp
  have h : env22185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22184_22185 : H12AffineEnvironment.transform 11 16 env22184 = env22185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22184 == env22185) = true)

def env22186 : List Nat := [2,4,8,16,1,17,9,5,512,1024,2048,17,9,1045,1,2,1028,2048,1025,0,1,1,17,3,8,16,2049,1028,17,2049,1024,1,4,0,1045,512]

theorem envBound22186 : H12AffineFastState.Bounded env22186 := by
  intro p hp
  have h : env22186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22184_22186 : H12AffineEnvironment.transform 11 17 env22184 = env22186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22184 == env22186) = true)

theorem identity22186 : scanCanonicalize (H12AffineFastState.compose env22186 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22186 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22187 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,9,1,1,2,16,2048,21,0,1,1,17,3,8,16,2049,16,17,2049,20,1,4,0,1,512]

theorem envBound22187 : H12AffineFastState.Bounded env22187 := by
  intro p hp
  have h : env22187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22186_22187 : H12AffineEnvironment.transform 9 20 env22186 = env22187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22186 == env22187) = true)

theorem identity22187 : scanCanonicalize (H12AffineFastState.compose env22187 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 542) := by decide +kernel

theorem selectedBound22187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22188 : List Nat := [2,4,8,16,1,17,9,5,512,20,542,17,9,1,1,2,16,542,21,0,1,1,17,3,8,16,543,16,17,543,20,1,4,0,1,512]

theorem envBound22188 : H12AffineFastState.Bounded env22188 := by
  intro p hp
  have h : env22188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22187_22188 : H12AffineEnvironment.transform 10 542 env22187 = env22188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 542 env22187 == env22188) = true)

def leafEnv22188 : List Nat := [2,4,8,16,1,17,9,5,512,20,542,17,9,1,1,2,16,542,21,0,1,1,17,3,21,8,1,16,543,16,17,543,20,1,4,0,5,3,1,512,1,1,0]

def active22188 : List Nat := [0,1,2,3,8]

def tree22188 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22188 : H12WitnessSearch.Good tree22188 := H12GlobalWitnessIndex.good

theorem leafIdentity22188 : H12AffineFastState.composeSystem env22188 rootObs = leafEnv22188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22188 rootObs == leafEnv22188) = true)

theorem terminalChecked22188 : H12PackedTerminal.terminalCheckFast leafEnv22188 active22188 tree22188 = true := by decide +kernel

def env22189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound22189 : H12AffineFastState.Bounded env22189 := by
  intro p hp
  have h : env22189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21009_22189 : H12AffineEnvironment.transform 29 155254785 env21009 = env22189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env21009 == env22189) = true)

def env22190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound22190 : H12AffineFastState.Bounded env22190 := by
  intro p hp
  have h : env22190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22189_22190 : H12AffineEnvironment.transform 25 64 env22189 = env22190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env22189 == env22190) = true)

def env22191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound22191 : H12AffineFastState.Bounded env22191 := by
  intro p hp
  have h : env22191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22190_22191 : H12AffineEnvironment.transform 26 30393344 env22190 = env22191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env22190 == env22191) = true)

def env22192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound22192 : H12AffineFastState.Bounded env22192 := by
  intro p hp
  have h : env22192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22191_22192 : H12AffineEnvironment.transform 18 1024 env22191 = env22192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22191 == env22192) = true)

theorem identity22192 : scanCanonicalize (H12AffineFastState.compose env22192 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound22192 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,16777216,8328,64,29868032,16793754,8491335,8830977,25265168,21012951,256,25166010,25223455,25207750]

theorem envBound22193 : H12AffineFastState.Bounded env22193 := by
  intro p hp
  have h : env22193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22192_22193 : H12AffineEnvironment.transform 20 115735 env22192 = env22193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env22192 == env22193) = true)

def env22194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,95616,8328,64,13022592,79130,8491335,8830977,8450448,4314199,256,8484154,8492191,8508998]

theorem envBound22194 : H12AffineFastState.Bounded env22194 := by
  intro p hp
  have h : env22194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22193_22194 : H12AffineEnvironment.transform 23 95616 env22193 = env22194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95616 env22193 == env22194) = true)

def env22195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73856,8328,64,13022592,79130,8491335,8819969,8430736,4292951,256,8462394,8492191,8487750]

theorem envBound22195 : H12AffineFastState.Bounded env22195 := by
  intro p hp
  have h : env22195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22194_22195 : H12AffineEnvironment.transform 13 5376 env22194 = env22195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22194 == env22195) = true)

def env22196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73856,8328,64,8828320,79130,8491335,8819969,8430736,98679,256,8462394,8492191,8487750]

theorem envBound22196 : H12AffineFastState.Bounded env22196 := by
  intro p hp
  have h : env22196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22195_22196 : H12AffineEnvironment.transform 21 32 env22195 = env22196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22195 == env22196) = true)

theorem identity22196 : scanCanonicalize (H12AffineFastState.compose env22196 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound22196 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,98767,73856,8328,64,472175,79130,4232,464078,75103,98679,256,41461,5456,649]

theorem envBound22197 : H12AffineFastState.Bounded env22197 := by
  intro p hp
  have h : env22197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22196_22197 : H12AffineEnvironment.transform 22 98767 env22196 = env22197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env22196 == env22197) = true)

theorem identity22197 : scanCanonicalize (H12AffineFastState.compose env22197 (packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound22197 : packedSelected [0,9,11,14,18,22,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env22198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10401,1024,32769,102679,32,98767,73856,8328,64,203982,79130,4232,212079,75103,98679,256,41461,5456,649]

theorem envBound22198 : H12AffineFastState.Bounded env22198 := by
  intro p hp
  have h : env22198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22197_22198 : H12AffineEnvironment.transform 17 10401 env22197 = env22198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env22197 == env22198) = true)

theorem identity22198 : scanCanonicalize (H12AffineFastState.compose env22198 (packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22198 : packedSelected [0,1,4,5,7,8,16,19,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102679,32,98631,73736,8192,64,203846,79130,4096,212079,75103,98679,256,41341,5456,513]

theorem envBound22199 : H12AffineFastState.Bounded env22199 := by
  intro p hp
  have h : env22199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22198_22199 : H12AffineEnvironment.transform 6 8 env22198 = env22199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22198 == env22199) = true)

theorem identity22199 : scanCanonicalize (H12AffineFastState.compose env22199 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22199 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env22200 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,65536,131072,10281,1024,8460,77850,32,73802,73736,8192,64,203846,79130,4096,212079,75103,73850,256,112,5456,513]

theorem envBound22200 : H12AffineFastState.Bounded env22200 := by
  intro p hp
  have h : env22200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22199_22200 : H12AffineEnvironment.transform 14 8461 env22199 = env22200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env22199 == env22200) = true)

theorem identity22200 : scanCanonicalize (H12AffineFastState.compose env22200 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound22200 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22201 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,65536,13341,10281,1024,8460,77850,32,73802,73736,8192,64,75867,79130,4096,67698,75103,73850,256,112,5456,513]

theorem envBound22201 : H12AffineFastState.Bounded env22201 := by
  intro p hp
  have h : env22201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22200_22201 : H12AffineEnvironment.transform 16 13341 env22200 = env22201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env22200 == env22201) = true)

theorem identity22201 : scanCanonicalize (H12AffineFastState.compose env22201 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22201 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22202 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,81,65536,5441,2421,1024,80,69958,32,65814,65876,348,64,67847,70726,4096,67698,66563,65830,256,112,5456,513]

theorem envBound22202 : H12AffineFastState.Bounded env22202 := by
  intro p hp
  have h : env22202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22201_22202 : H12AffineEnvironment.transform 12 348 env22201 = env22202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22201 == env22202) = true)

def env22203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,8388608,73856,8328,64,8828321,79130,8491335,8819969,8430736,98678,256,8462394,8492191,8487750]

theorem envBound22203 : H12AffineFastState.Bounded env22203 := by
  intro p hp
  have h : env22203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22195_22203 : H12AffineEnvironment.transform 21 33 env22195 = env22203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22195 == env22203) = true)

theorem identity22203 : scanCanonicalize (H12AffineFastState.compose env22203 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound22203 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,131072,262144,1024,32769,4296,33,8388608,41311,8328,64,8828321,46277,8392856,8819969,8430736,169,256,8430053,8394048,8389273]

theorem envBound22204 : H12AffineFastState.Bounded env22204 := by
  intro p hp
  have h : env22204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22203_22204 : H12AffineEnvironment.transform 15 33247 env22203 = env22204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env22203 == env22204) = true)

theorem identity22204 : scanCanonicalize (H12AffineFastState.compose env22204 (packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound22204 : packedSelected [4,7,9,11,14,16,18,20,21,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env22205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33247,131072,262144,1024,32769,4296,33,16,41311,8328,64,439729,46277,4232,431377,42112,169,256,41461,5456,649]

theorem envBound22205 : H12AffineFastState.Bounded env22205 := by
  intro p hp
  have h : env22205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22204_22205 : H12AffineEnvironment.transform 22 16 env22204 = env22205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22204 == env22205) = true)

theorem identity22205 : scanCanonicalize (H12AffineFastState.compose env22205 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22205 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env22206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,4160,33,16,41311,8192,64,439609,46157,4096,431377,41992,33,256,41341,5456,513]

theorem envBound22206 : H12AffineFastState.Bounded env22206 := by
  intro p hp
  have h : env22206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22205_22206 : H12AffineEnvironment.transform 6 8 env22205 = env22206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22205 == env22206) = true)

theorem identity22206 : scanCanonicalize (H12AffineFastState.compose env22206 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22206 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env22207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8202,131072,262144,1024,8540,4160,33,16,2,8192,64,398436,5392,4096,406604,1365,33,256,32,5456,513]

theorem envBound22207 : H12AffineFastState.Bounded env22207 := by
  intro p hp
  have h : env22207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22206_22207 : H12AffineEnvironment.transform 14 8541 env22206 = env22207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22206 == env22207) = true)

def env22208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73857,8328,64,13022592,79130,8491335,8819968,8430737,4292950,256,8462395,8492191,8487751]

theorem envBound22208 : H12AffineFastState.Bounded env22208 := by
  intro p hp
  have h : env22208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22194_22208 : H12AffineEnvironment.transform 13 5377 env22194 = env22208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22194 == env22208) = true)

def env22209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73857,8328,64,8828320,79130,8491335,8819968,8430737,98678,256,8462395,8492191,8487751]

theorem envBound22209 : H12AffineFastState.Bounded env22209 := by
  intro p hp
  have h : env22209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22208_22209 : H12AffineEnvironment.transform 21 32 env22208 = env22209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22208 == env22209) = true)

theorem identity22209 : scanCanonicalize (H12AffineFastState.compose env22209 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98630) := by decide +kernel

theorem selectedBound22209 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73857,8328,64,472294,79130,4097,463942,75223,98678,256,41341,5593,513]

theorem envBound22210 : H12AffineFastState.Bounded env22210 := by
  intro p hp
  have h : env22210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22209_22210 : H12AffineEnvironment.transform 22 98630 env22209 = env22210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98630 env22209 == env22210) = true)

def env22211 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73737,8192,64,472174,79130,4097,463942,75103,98678,256,41341,5457,513]

theorem envBound22211 : H12AffineFastState.Bounded env22211 := by
  intro p hp
  have h : env22211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22210_22211 : H12AffineEnvironment.transform 6 8 env22210 = env22211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22210 == env22211) = true)

def env22212 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,102678,32,98630,73737,8192,64,203846,79130,4097,212078,75103,98678,256,41341,5457,513]

theorem envBound22212 : H12AffineFastState.Bounded env22212 := by
  intro p hp
  have h : env22212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22211_22212 : H12AffineEnvironment.transform 17 10280 env22211 = env22212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22211 == env22212) = true)

theorem identity22212 : scanCanonicalize (H12AffineFastState.compose env22212 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 15672) := by decide +kernel

theorem selectedBound22212 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env22213 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,15672,10280,1024,32769,102678,32,98630,73737,8192,64,74110,79130,4097,65878,75103,98678,256,41341,5457,513]

theorem envBound22213 : H12AffineFastState.Bounded env22213 := by
  intro p hp
  have h : env22213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22212_22213 : H12AffineEnvironment.transform 16 15672 env22212 = env22213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 15672 env22212 == env22213) = true)

theorem identity22213 : scanCanonicalize (H12AffineFastState.compose env22213 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound22213 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22214 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,2083,15672,10280,1024,32769,39221,32,35173,10282,8192,64,10589,15673,4097,2421,11644,35157,256,41341,5457,513]

theorem envBound22214 : H12AffineFastState.Bounded env22214 := by
  intro p hp
  have h : env22214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22213_22214 : H12AffineEnvironment.transform 15 2083 env22213 = env22214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env22213 == env22214) = true)

theorem identity22214 : scanCanonicalize (H12AffineFastState.compose env22214 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound22214 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22215 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9293,2083,15672,10280,1024,9292,15736,32,11560,10282,8192,64,10589,15673,4097,2421,11644,11544,256,1328,5457,513]

theorem envBound22215 : H12AffineFastState.Bounded env22215 := by
  intro p hp
  have h : env22215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22214_22215 : H12AffineEnvironment.transform 14 9293 env22214 = env22215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env22214 == env22215) = true)

theorem identity22215 : scanCanonicalize (H12AffineFastState.compose env22215 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 3384) := by decide +kernel

theorem selectedBound22215 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22216 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3384,5377,2421,2083,4096,1296,1024,2420,4160,32,16,1298,3384,64,1125,4097,4097,2421,68,32,256,1328,5457,513]

theorem envBound22216 : H12AffineFastState.Bounded env22216 := by
  intro p hp
  have h : env22216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22215_22216 : H12AffineEnvironment.transform 12 3384 env22215 = env22216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3384 env22215 == env22216) = true)

theorem identity22216 : scanCanonicalize (H12AffineFastState.compose env22216 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound22216 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,41,5377,1124,1330,4096,1296,1024,1125,4160,32,16,1298,41,64,1125,4097,4097,1124,68,32,256,1328,5457,513]

theorem envBound22217 : H12AffineFastState.Bounded env22217 := by
  intro p hp
  have h : env22217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22216_22217 : H12AffineEnvironment.transform 10 1297 env22216 = env22217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env22216 == env22217) = true)

theorem identity22217 : scanCanonicalize (H12AffineFastState.compose env22217 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound22217 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env22218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,1280,41,1,1124,1330,1280,1296,1024,1125,1344,32,16,1298,41,64,1125,1281,1281,1124,68,32,256,1328,81,513]

theorem envBound22218 : H12AffineFastState.Bounded env22218 := by
  intro p hp
  have h : env22218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22217_22218 : H12AffineEnvironment.transform 11 1280 env22217 = env22218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env22217 == env22218) = true)

theorem identity22218 : scanCanonicalize (H12AffineFastState.compose env22218 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22218 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env22219 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1297,1280,41,1,1077,1330,1280,1296,1024,1076,1297,32,16,1298,41,17,1076,1281,1281,1077,21,32,256,1328,0,513]

theorem envBound22219 : H12AffineFastState.Bounded env22219 := by
  intro p hp
  have h : env22219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22218_22219 : H12AffineEnvironment.transform 5 17 env22218 = env22219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22218 == env22219) = true)

theorem identity22219 : scanCanonicalize (H12AffineFastState.compose env22219 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22219 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env22220 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1076,1061,41,1,1077,1047,1061,1077,1024,1076,1076,32,16,1079,41,17,1076,1060,1060,1077,21,32,37,1045,0,513]

theorem envBound22220 : H12AffineFastState.Bounded env22220 := by
  intro p hp
  have h : env22220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22219_22220 : H12AffineEnvironment.transform 7 37 env22219 = env22220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22219 == env22220) = true)

theorem identity22220 : scanCanonicalize (H12AffineFastState.compose env22220 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound22220 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env22221 : List Nat := [2,4,8,16,32,17,8,37,49,1024,1076,1061,41,1,1077,1047,1061,1077,1024,1076,1076,32,16,1079,41,17,1076,1060,1060,1077,21,32,37,1045,0,48]

theorem envBound22221 : H12AffineFastState.Bounded env22221 := by
  intro p hp
  have h : env22221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22220_22221 : H12AffineEnvironment.transform 8 49 env22220 = env22221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env22220 == env22221) = true)

def env22222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,32,98630,73737,8192,64,203847,79130,4097,212079,75103,98678,256,41341,5457,513]

theorem envBound22222 : H12AffineFastState.Bounded env22222 := by
  intro p hp
  have h : env22222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22211_22222 : H12AffineEnvironment.transform 17 10281 env22211 = env22222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22211 == env22222) = true)

theorem identity22222 : scanCanonicalize (H12AffineFastState.compose env22222 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound22222 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env22223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,343,131072,10281,1024,32769,36929,32,32785,8542,8192,64,138512,13389,4097,146744,9224,32801,256,41341,5457,513]

theorem envBound22223 : H12AffineFastState.Bounded env22223 := by
  intro p hp
  have h : env22223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22222_22223 : H12AffineEnvironment.transform 15 343 env22222 = env22223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env22222 == env22223) = true)

theorem identity22223 : scanCanonicalize (H12AffineFastState.compose env22223 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22223 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22224 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,262,131072,10281,1024,32769,36880,32,32785,8463,8192,17,138512,13340,4097,146744,9224,32801,256,41260,5376,513]

theorem envBound22224 : H12AffineFastState.Bounded env22224 := by
  intro p hp
  have h : env22224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22223_22224 : H12AffineEnvironment.transform 5 17 env22223 = env22224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22223 == env22224) = true)

theorem identity22224 : scanCanonicalize (H12AffineFastState.compose env22224 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound22224 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22225 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,32768,262,13341,10281,1024,32769,36880,32,32785,8463,8192,17,10509,13340,4097,2341,9224,32801,256,41260,5376,513]

theorem envBound22225 : H12AffineFastState.Bounded env22225 := by
  intro p hp
  have h : env22225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22224_22225 : H12AffineEnvironment.transform 16 13341 env22224 = env22225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env22224 == env22225) = true)

theorem identity22225 : scanCanonicalize (H12AffineFastState.compose env22225 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22225 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22226 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,1,262,13341,10281,1024,0,4113,32,16,8463,8192,17,10509,13340,4097,2341,9224,32,256,8493,5376,513]

theorem envBound22226 : H12AffineFastState.Bounded env22226 := by
  intro p hp
  have h : env22226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22225_22226 : H12AffineEnvironment.transform 14 1 env22225 = env22226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22225 == env22226) = true)

theorem identity22226 : scanCanonicalize (H12AffineFastState.compose env22226 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6941) := by decide +kernel

theorem selectedBound22226 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env22227 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,6941,5377,1,262,3840,4916,1024,0,4113,32,16,6674,6941,17,4624,3841,4097,2341,7957,32,256,6704,5376,513]

theorem envBound22227 : H12AffineFastState.Bounded env22227 := by
  intro p hp
  have h : env22227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22226_22227 : H12AffineEnvironment.transform 12 6941 env22226 = env22227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6941 env22226 == env22227) = true)

theorem identity22227 : scanCanonicalize (H12AffineFastState.compose env22227 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound22227 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env22228 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,4096,6941,4389,1,262,2852,4916,36,0,4113,32,16,6674,6941,17,4624,2853,4097,2341,6961,32,256,6704,4388,513]

theorem envBound22228 : H12AffineFastState.Bounded env22228 := by
  intro p hp
  have h : env22228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22227_22228 : H12AffineEnvironment.transform 9 36 env22227 = env22228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env22227 == env22228) = true)

theorem identity22228 : scanCanonicalize (H12AffineFastState.compose env22228 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound22228 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env22229 : List Nat := [2,4,8,16,32,17,8,256,512,36,2048,512,2333,805,1,262,2852,308,36,0,529,32,16,2066,2333,17,16,2853,513,2341,2353,32,256,2096,804,513]

theorem envBound22229 : H12AffineFastState.Bounded env22229 := by
  intro p hp
  have h : env22229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22228_22229 : H12AffineEnvironment.transform 11 512 env22228 = env22229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env22228 == env22229) = true)

theorem identity22229 : scanCanonicalize (H12AffineFastState.compose env22229 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound22229 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env22230 : List Nat := [2,4,8,16,32,17,8,256,512,36,821,512,552,805,1,262,17,308,36,0,529,32,16,807,552,17,16,16,513,528,516,32,256,773,804,513]

theorem envBound22230 : H12AffineFastState.Bounded env22230 := by
  intro p hp
  have h : env22230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22229_22230 : H12AffineEnvironment.transform 10 821 env22229 = env22230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env22229 == env22230) = true)

theorem identity22230 : scanCanonicalize (H12AffineFastState.compose env22230 (packedSelected [1,3,11] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound22230 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env22231 : List Nat := [2,4,8,16,32,17,8,256,292,36,17,292,268,1,1,262,17,308,36,0,309,32,16,3,268,17,16,16,293,308,288,32,256,33,0,293]

theorem envBound22231 : H12AffineFastState.Bounded env22231 := by
  intro p hp
  have h : env22231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22230_22231 : H12AffineEnvironment.transform 8 292 env22230 = env22231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env22230 == env22231) = true)

theorem identity22231 : scanCanonicalize (H12AffineFastState.compose env22231 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound22231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22232 : List Nat := [2,4,8,16,32,17,8,53,17,36,17,17,57,1,1,51,17,1,36,0,0,32,16,3,57,17,16,16,16,1,21,32,53,33,0,16]

theorem envBound22232 : H12AffineFastState.Bounded env22232 := by
  intro p hp
  have h : env22232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22231_22232 : H12AffineEnvironment.transform 7 53 env22231 = env22232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env22231 == env22232) = true)

theorem identity22232 : scanCanonicalize (H12AffineFastState.compose env22232 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22233 : List Nat := [2,4,8,16,0,17,8,21,17,4,17,17,25,1,1,19,17,1,4,0,0,0,16,3,25,17,16,16,16,1,21,0,21,1,0,16]

theorem envBound22233 : H12AffineFastState.Bounded env22233 := by
  intro p hp
  have h : env22233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22232_22233 : H12AffineEnvironment.transform 4 0 env22232 = env22233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22232 == env22233) = true)

theorem identity22233 : scanCanonicalize (H12AffineFastState.compose env22233 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22234 : List Nat := [2,4,8,0,0,1,8,5,1,4,1,1,9,1,1,3,1,1,4,0,0,0,0,3,9,1,0,0,0,1,5,0,5,1,0,0]

theorem envBound22234 : H12AffineFastState.Bounded env22234 := by
  intro p hp
  have h : env22234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22233_22234 : H12AffineEnvironment.transform 3 0 env22233 = env22234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22233 == env22234) = true)

def env22235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,98630,73736,8193,64,472175,79130,4097,463942,75102,98678,256,41341,5456,513]

theorem envBound22235 : H12AffineFastState.Bounded env22235 := by
  intro p hp
  have h : env22235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22210_22235 : H12AffineEnvironment.transform 6 9 env22210 = env22235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22210 == env22235) = true)

theorem identity22235 : scanCanonicalize (H12AffineFastState.compose env22235 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound22235 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,102678,32,98630,73736,8193,64,262516,79130,4097,270685,75102,98678,256,41341,5456,513]

theorem envBound22236 : H12AffineFastState.Bounded env22236 := by
  intro p hp
  have h : env22236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22235_22236 : H12AffineEnvironment.transform 16 79131 env22235 = env22236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env22235 == env22236) = true)

theorem identity22236 : scanCanonicalize (H12AffineFastState.compose env22236 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound22236 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9292,65536,79131,262144,1024,9293,79194,32,75018,73736,8193,64,262516,79130,4097,270685,75102,75066,256,1329,5456,513]

theorem envBound22237 : H12AffineFastState.Bounded env22237 := by
  intro p hp
  have h : env22237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22236_22237 : H12AffineEnvironment.transform 14 9292 env22236 = env22237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env22236 == env22237) = true)

theorem identity22237 : scanCanonicalize (H12AffineFastState.compose env22237 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 68915) := by decide +kernel

theorem selectedBound22237 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env22238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,9292,65536,79131,68915,1024,9293,79194,32,75018,73736,8193,64,68679,79130,4097,76910,75102,75066,256,1329,5456,513]

theorem envBound22238 : H12AffineFastState.Bounded env22238 := by
  intro p hp
  have h : env22238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22237_22238 : H12AffineEnvironment.transform 17 68915 env22237 = env22238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68915 env22237 == env22238) = true)

theorem identity22238 : scanCanonicalize (H12AffineFastState.compose env22238 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22238 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22239 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8541,65536,77834,67618,273,8540,77899,32,73755,73736,8193,64,67926,77835,4097,76159,73807,73771,256,32,4161,513]

theorem envBound22239 : H12AffineFastState.Bounded env22239 := by
  intro p hp
  have h : env22239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22238_22239 : H12AffineEnvironment.transform 9 273 env22238 = env22239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22238 == env22239) = true)

theorem identity22239 : scanCanonicalize (H12AffineFastState.compose env22239 (packedSelected [1,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound22239 : packedSelected [1,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22240 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,4096,8192,4112,8541,65536,77834,65798,273,8540,77899,32,73755,73736,8193,64,65650,77835,4097,73819,73807,73771,256,32,4161,513]

theorem envBound22240 : H12AffineFastState.Bounded env22240 := by
  intro p hp
  have h : env22240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22239_22240 : H12AffineEnvironment.transform 10 292 env22239 = env22240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env22239 == env22240) = true)

theorem identity22240 : scanCanonicalize (H12AffineFastState.compose env22240 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22240 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22241 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,4096,269,4112,80,65536,69895,65798,273,81,69958,32,65814,65797,268,64,65650,69894,4097,65878,65858,65830,256,32,4161,513]

theorem envBound22241 : H12AffineFastState.Bounded env22241 := by
  intro p hp
  have h : env22241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22240_22241 : H12AffineEnvironment.transform 12 269 env22240 = env22241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22240 == env22241) = true)

theorem identity22241 : scanCanonicalize (H12AffineFastState.compose env22241 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound22241 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env22242 : List Nat := [2,4,8,16,32,64,9,256,512,273,292,356,269,372,80,65536,65635,65798,273,81,65570,32,65814,65797,268,64,65650,65634,357,65878,65858,65830,256,32,293,513]

theorem envBound22242 : H12AffineFastState.Bounded env22242 := by
  intro p hp
  have h : env22242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22241_22242 : H12AffineEnvironment.transform 11 356 env22241 = env22242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env22241 == env22242) = true)

theorem identity22242 : scanCanonicalize (H12AffineFastState.compose env22242 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22242 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env22243 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,17,120,1,80,65536,65635,65651,100,81,65570,32,65635,65648,121,64,65650,65634,16,65571,65591,65619,117,32,80,513]

theorem envBound22243 : H12AffineFastState.Bounded env22243 := by
  intro p hp
  have h : env22243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22242_22243 : H12AffineEnvironment.transform 7 117 env22242 = env22243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22242 == env22243) = true)

theorem identity22243 : scanCanonicalize (H12AffineFastState.compose env22243 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound22243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22244 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,17,120,1,80,115,16,0,100,81,81,32,16,3,121,64,1,17,16,80,68,32,117,32,80,513]

theorem envBound22244 : H12AffineFastState.Bounded env22244 := by
  intro p hp
  have h : env22244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22243_22244 : H12AffineEnvironment.transform 15 115 env22243 = env22244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env22243 == env22244) = true)

def env22245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,8388608,73857,8328,64,8828321,79130,8491335,8819968,8430737,98679,256,8462395,8492191,8487751]

theorem envBound22245 : H12AffineFastState.Bounded env22245 := by
  intro p hp
  have h : env22245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22208_22245 : H12AffineEnvironment.transform 21 33 env22208 = env22245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22208 == env22245) = true)

theorem identity22245 : scanCanonicalize (H12AffineFastState.compose env22245 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound22245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4160,33,8388608,41431,8328,64,8828321,46156,8392721,8819968,8430737,33,256,8429933,8394185,8389137]

theorem envBound22246 : H12AffineFastState.Bounded env22246 := by
  intro p hp
  have h : env22246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22245_22246 : H12AffineEnvironment.transform 15 33110 env22245 = env22246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env22245 == env22246) = true)

def env22247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146864,1024,32769,4160,33,8388608,41431,8328,64,8423441,46156,8392721,8431792,8430737,33,256,8429933,8394185,8389137]

theorem envBound22247 : H12AffineFastState.Bounded env22247 := by
  intro p hp
  have h : env22247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22246_22247 : H12AffineEnvironment.transform 17 146864 env22246 = env22247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146864 env22246 == env22247) = true)

theorem identity22247 : scanCanonicalize (H12AffineFastState.compose env22247 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 136585) := by decide +kernel

theorem selectedBound22247 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146864,1024,32769,4160,33,136585,41431,8328,64,171416,46156,132504,179513,176408,33,256,177380,131136,137112]

theorem envBound22248 : H12AffineFastState.Bounded env22248 := by
  intro p hp
  have h : env22248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22247_22248 : H12AffineEnvironment.transform 22 136585 env22247 = env22248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136585 env22247 == env22248) = true)

theorem identity22248 : scanCanonicalize (H12AffineFastState.compose env22248 (packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22248 : packedSelected [1,3,5,8,10,12,15,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env22249 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146744,1024,32769,4160,33,136449,41311,8192,64,171280,46156,132368,179513,176408,33,256,177260,131136,136976]

theorem envBound22249 : H12AffineFastState.Bounded env22249 := by
  intro p hp
  have h : env22249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22248_22249 : H12AffineEnvironment.transform 6 8 env22248 = env22249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22248 == env22249) = true)

theorem identity22249 : scanCanonicalize (H12AffineFastState.compose env22249 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound22249 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env22250 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,13389,2421,1024,32769,4160,33,8524,41311,8192,64,43357,46156,12637,35188,34133,33,256,32801,13325,9053]

theorem envBound22250 : H12AffineFastState.Bounded env22250 := by
  intro p hp
  have h : env22250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22249_22250 : H12AffineEnvironment.transform 16 13389 env22249 = env22250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env22249 == env22250) = true)

theorem identity22250 : scanCanonicalize (H12AffineFastState.compose env22250 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22250 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env22251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13389,2421,1024,8540,4160,33,8524,2,8192,64,2048,5393,12637,10281,9224,33,256,8572,13325,9053]

theorem envBound22251 : H12AffineFastState.Bounded env22251 := by
  intro p hp
  have h : env22251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22250_22251 : H12AffineEnvironment.transform 14 8541 env22250 = env22251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22250 == env22251) = true)

theorem identity22251 : scanCanonicalize (H12AffineFastState.compose env22251 (packedSelected [1,2,3,4,5,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22251 : packedSelected [1,2,3,4,5,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5392,2421,1024,1,4160,33,17,2,349,64,2048,5393,4096,2420,1365,33,256,33,5456,512]

theorem envBound22252 : H12AffineFastState.Bounded env22252 := by
  intro p hp
  have h : env22252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22251_22252 : H12AffineEnvironment.transform 12 349 env22251 = env22252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22251 == env22252) = true)

theorem identity22252 : scanCanonicalize (H12AffineFastState.compose env22252 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3963) := by decide +kernel

theorem selectedBound22252 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22253 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3963,349,2682,0,342,2667,2421,1024,1,3899,33,17,2,349,64,2048,2666,3963,2420,1365,33,256,33,2603,512]

theorem envBound22253 : H12AffineFastState.Bounded env22253 := by
  intro p hp
  have h : env22253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22252_22253 : H12AffineEnvironment.transform 11 3963 env22252 = env22253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3963 env22252 == env22253) = true)

theorem identity22253 : scanCanonicalize (H12AffineFastState.compose env22253 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22253 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22254 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,3931,349,2650,0,342,2635,2389,1024,1,3867,1,17,2,349,64,2048,2634,3931,2388,1365,1,256,1,2571,512]

theorem envBound22254 : H12AffineFastState.Bounded env22254 := by
  intro p hp
  have h : env22254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22253_22254 : H12AffineEnvironment.transform 4 0 env22253 = env22254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22253 == env22254) = true)

theorem identity22254 : scanCanonicalize (H12AffineFastState.compose env22254 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound22254 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22255 : List Nat := [2,4,8,16,0,64,8,256,512,1024,260,1631,349,862,0,342,847,81,1024,1,1567,1,17,2,349,64,260,846,1631,80,1365,1,256,1,783,512]

theorem envBound22255 : H12AffineFastState.Bounded env22255 := by
  intro p hp
  have h : env22255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22254_22255 : H12AffineEnvironment.transform 10 260 env22254 = env22255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env22254 == env22255) = true)

theorem identity22255 : scanCanonicalize (H12AffineFastState.compose env22255 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound22255 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22256 : List Nat := [2,4,8,16,0,64,8,256,512,526,260,81,349,862,0,342,847,81,526,1,17,1,17,2,349,64,260,846,81,80,859,1,256,1,783,512]

theorem envBound22256 : H12AffineFastState.Bounded env22256 := by
  intro p hp
  have h : env22256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22255_22256 : H12AffineEnvironment.transform 9 526 env22255 = env22256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env22255 == env22256) = true)

theorem identity22256 : scanCanonicalize (H12AffineFastState.compose env22256 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22256 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env22257 : List Nat := [2,4,8,16,0,17,8,256,512,526,260,0,268,783,0,263,798,0,526,1,17,1,17,2,268,17,260,799,0,1,778,1,256,1,783,512]

theorem envBound22257 : H12AffineFastState.Bounded env22257 := by
  intro p hp
  have h : env22257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22256_22257 : H12AffineEnvironment.transform 5 17 env22256 = env22257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22256 == env22257) = true)

theorem identity22257 : scanCanonicalize (H12AffineFastState.compose env22257 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 287) := by decide +kernel

theorem selectedBound22257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22258 : List Nat := [2,4,8,16,0,17,8,256,287,273,260,0,268,16,0,263,1,0,273,1,17,1,17,2,268,17,260,0,0,1,21,1,256,1,16,287]

theorem envBound22258 : H12AffineFastState.Bounded env22258 := by
  intro p hp
  have h : env22258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22257_22258 : H12AffineEnvironment.transform 8 287 env22257 = env22258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 287 env22257 == env22258) = true)

theorem identity22258 : scanCanonicalize (H12AffineFastState.compose env22258 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound22258 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22259 : List Nat := [2,4,8,16,0,17,8,15,16,30,11,0,3,16,0,8,1,0,30,1,17,1,17,2,3,17,11,0,0,1,21,1,15,1,16,16]

theorem envBound22259 : H12AffineFastState.Bounded env22259 := by
  intro p hp
  have h : env22259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22258_22259 : H12AffineEnvironment.transform 7 15 env22258 = env22259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env22258 == env22259) = true)

theorem identity22259 : scanCanonicalize (H12AffineFastState.compose env22259 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound22259 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22260 : List Nat := [2,4,8,9,0,8,8,15,9,7,11,0,3,9,0,8,1,0,7,1,8,1,8,2,3,8,11,0,0,1,12,1,15,1,9,9]

theorem envBound22260 : H12AffineFastState.Bounded env22260 := by
  intro p hp
  have h : env22260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22259_22260 : H12AffineEnvironment.transform 3 9 env22259 = env22260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env22259 == env22260) = true)

theorem identity22260 : scanCanonicalize (H12AffineFastState.compose env22260 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound22260 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env22261 : List Nat := [2,4,1,0,0,1,1,6,0,7,2,0,3,0,0,1,1,0,7,1,1,1,1,2,3,1,2,0,0,1,5,1,6,1,0,0]

theorem envBound22261 : H12AffineFastState.Bounded env22261 := by
  intro p hp
  have h : env22261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22260_22261 : H12AffineEnvironment.transform 2 1 env22260 = env22261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env22260 == env22261) = true)

theorem identity22261 : scanCanonicalize (H12AffineFastState.compose env22261 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound22261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22262 : List Nat := [2,2,1,0,0,1,1,0,0,1,2,0,3,0,0,1,1,0,1,1,1,1,1,2,3,1,2,0,0,1,3,1,0,1,0,0]

theorem envBound22262 : H12AffineFastState.Bounded env22262 := by
  intro p hp
  have h : env22262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22261_22262 : H12AffineEnvironment.transform 1 2 env22261 = env22262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env22261 == env22262) = true)

def env22263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146865,1024,32769,4160,33,8388608,41431,8328,64,8423440,46156,8392721,8431793,8430737,33,256,8429933,8394185,8389137]

theorem envBound22263 : H12AffineFastState.Bounded env22263 := by
  intro p hp
  have h : env22263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22246_22263 : H12AffineEnvironment.transform 17 146865 env22246 = env22263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146865 env22246 == env22263) = true)

theorem identity22263 : scanCanonicalize (H12AffineFastState.compose env22263 (packedSelected [3,10,11,18,23,24,26,32] rootPS)) = affineNative (2^(22+1) ^^^ 136448) := by decide +kernel

theorem selectedBound22263 : packedSelected [3,10,11,18,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,131072,146865,1024,32769,4160,33,136448,41431,8328,64,171280,46156,132369,179633,176529,33,256,177261,131273,136977]

theorem envBound22264 : H12AffineFastState.Bounded env22264 := by
  intro p hp
  have h : env22264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22263_22264 : H12AffineEnvironment.transform 22 136448 env22263 = env22264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env22263 == env22264) = true)

theorem identity22264 : scanCanonicalize (H12AffineFastState.compose env22264 (packedSelected [0,4,7,16,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22264 : packedSelected [0,4,7,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env22265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33110,5392,10401,1024,32769,4160,33,16,41431,8328,64,34816,46156,4097,43169,42113,33,256,41341,5593,513]

theorem envBound22265 : H12AffineFastState.Bounded env22265 := by
  intro p hp
  have h : env22265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22264_22265 : H12AffineEnvironment.transform 16 5392 env22264 = env22265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22264 == env22265) = true)

theorem identity22265 : scanCanonicalize (H12AffineFastState.compose env22265 (packedSelected [1,3,4,5,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22265 : packedSelected [1,3,4,5,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env22266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,0,342,5392,10401,1024,1,4160,33,16,8663,8328,64,2048,13388,4097,10401,9345,33,256,8573,5593,513]

theorem envBound22266 : H12AffineFastState.Bounded env22266 := by
  intro p hp
  have h : env22266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22265_22266 : H12AffineEnvironment.transform 14 0 env22265 = env22266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22265 == env22266) = true)

theorem identity22266 : scanCanonicalize (H12AffineFastState.compose env22266 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22266 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,0,342,5392,2556,1024,1,4160,33,16,138,469,64,2048,5393,4097,2556,1500,33,256,32,5593,513]

theorem envBound22267 : H12AffineFastState.Bounded env22267 := by
  intro p hp
  have h : env22267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22266_22267 : H12AffineEnvironment.transform 12 349 env22266 = env22267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22266 == env22267) = true)

theorem identity22267 : scanCanonicalize (H12AffineFastState.compose env22267 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22267 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22268 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5377,0,263,5392,2477,1024,1,4113,33,16,138,388,17,2048,5393,4097,2477,1421,33,256,32,5512,513]

theorem envBound22268 : H12AffineFastState.Bounded env22268 := by
  intro p hp
  have h : env22268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22267_22268 : H12AffineEnvironment.transform 5 17 env22267 = env22268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22267 == env22268) = true)

theorem identity22268 : scanCanonicalize (H12AffineFastState.compose env22268 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22268 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22269 : List Nat := [2,4,8,16,32,17,128,256,512,52,2048,4096,268,4405,0,263,4388,2477,52,1,4113,33,16,138,388,17,2048,4389,4097,2477,441,33,256,32,4540,513]

theorem envBound22269 : H12AffineFastState.Bounded env22269 := by
  intro p hp
  have h : env22269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22268_22269 : H12AffineEnvironment.transform 9 52 env22268 = env22269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22268 == env22269) = true)

theorem identity22269 : scanCanonicalize (H12AffineFastState.compose env22269 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound22269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22270 : List Nat := [2,4,8,16,32,17,128,172,512,52,2048,4096,160,4249,0,171,4232,2049,52,1,4113,33,16,138,40,17,2048,4233,4097,2049,21,33,172,32,4112,513]

theorem envBound22270 : H12AffineFastState.Bounded env22270 := by
  intro p hp
  have h : env22270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22269_22270 : H12AffineEnvironment.transform 7 172 env22269 = env22270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env22269 == env22270) = true)

def env22271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,115735,4194304,8388608,95617,8328,64,13022593,79131,8491335,8830977,8450449,4314198,256,8484155,8492190,8508999]

end H12CloudChart1