import H12CloudChart1Data234

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env59612 : List Nat := [2,4,3,16,18,3,19,20,1,20,17,17,18,2,3,0,1,18,21,3,0,17,2,16,2,16,3,3,18,17,6,18,20,18,1,0]

theorem envBound59612 : H12AffineFastState.Bounded env59612 := by
  intro p hp
  have h : env59612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59611_59612 : H12AffineEnvironment.transform 2 3 env59611 = env59612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59611 == env59612) = true)

theorem identity59612 : scanCanonicalize (H12AffineFastState.compose env59612 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59612 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59613 : List Nat := [0,4,1,16,16,1,17,20,1,20,17,17,16,0,1,0,1,16,21,1,0,17,0,16,0,16,1,1,16,17,4,16,20,16,1,0]

theorem envBound59613 : H12AffineFastState.Bounded env59613 := by
  intro p hp
  have h : env59613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59612_59613 : H12AffineEnvironment.transform 0 0 env59612 = env59613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59612 == env59613) = true)

theorem identity59613 : scanCanonicalize (H12AffineFastState.compose env59613 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59613 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59614 : List Nat := [0,4,1,1,1,1,0,5,1,5,0,0,1,0,1,0,1,1,4,1,0,0,0,1,0,1,1,1,1,0,4,1,5,1,1,0]

theorem envBound59614 : H12AffineFastState.Bounded env59614 := by
  intro p hp
  have h : env59614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59613_59614 : H12AffineEnvironment.transform 3 1 env59613 = env59614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59613 == env59614) = true)

def env59615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3670,1288,9616,2366325,4177,77954,67411,65543,68606,256,65674,78034,10113]

theorem envBound59615 : H12AffineFastState.Bounded env59615 := by
  intro p hp
  have h : env59615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59565_59615 : H12AffineEnvironment.transform 22 9665 env59565 = env59615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59565 == env59615) = true)

def env59616 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365813,4177,77954,66899,65543,68094,256,65674,78034,9601]

theorem envBound59616 : H12AffineFastState.Bounded env59616 := by
  intro p hp
  have h : env59616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59616 : H12AffineEnvironment.transform 8 0 env59615 = env59616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59615 == env59616) = true)

theorem identity59616 : scanCanonicalize (H12AffineFastState.compose env59616 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound59616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59617 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,12670,428,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365813,4177,508,13357,12665,14464,256,12788,428,9601]

theorem envBound59617 : H12AffineFastState.Bounded env59617 := by
  intro p hp
  have h : env59617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59616_59617 : H12AffineEnvironment.transform 15 12670 env59616 = env59617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env59616 == env59617) = true)

def env59618 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,2097152,1417,65,3158,1288,16,2365813,4177,508,4525,5369,7424,256,5236,428,1]

theorem envBound59618 : H12AffineFastState.Bounded env59618 := by
  intro p hp
  have h : env59618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59617_59618 : H12AffineEnvironment.transform 12 1408 env59617 = env59618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59617 == env59618) = true)

theorem identity59618 : scanCanonicalize (H12AffineFastState.compose env59618 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound59618 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59619 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5374,428,262144,1025,2128,6652,1417,65,3158,1288,16,262281,4177,508,4525,5369,7424,256,5236,428,1]

theorem envBound59619 : H12AffineFastState.Bounded env59619 := by
  intro p hp
  have h : env59619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59618_59619 : H12AffineEnvironment.transform 20 6652 env59618 = env59619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env59618 == env59619) = true)

theorem identity59619 : scanCanonicalize (H12AffineFastState.compose env59619 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59619 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59620 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,5374,428,262144,1025,1449,5125,1417,65,431,1288,16,262281,4177,508,4525,5369,4345,256,5236,428,1]

theorem envBound59620 : H12AffineFastState.Bounded env59620 := by
  intro p hp
  have h : env59620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59619_59620 : H12AffineEnvironment.transform 10 1529 env59619 = env59620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59619 == env59620) = true)

theorem identity59620 : scanCanonicalize (H12AffineFastState.compose env59620 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59620 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59621 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,4096,1408,4176,1449,5374,428,5325,1025,1449,5125,1417,65,431,1288,16,5188,4177,508,4525,5369,4345,256,5236,428,1]

theorem envBound59621 : H12AffineFastState.Bounded env59621 := by
  intro p hp
  have h : env59621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59620_59621 : H12AffineEnvironment.transform 17 5325 env59620 = env59621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59620 == env59621) = true)

theorem identity59621 : scanCanonicalize (H12AffineFastState.compose env59621 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound59621 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59622 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,216,1408,136,1449,1062,428,1045,1025,1449,1245,1417,65,431,1288,16,1180,137,508,373,1057,33,256,1196,428,1]

theorem envBound59622 : H12AffineFastState.Bounded env59622 := by
  intro p hp
  have h : env59622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59621_59622 : H12AffineEnvironment.transform 11 216 env59621 = env59622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env59621 == env59622) = true)

theorem identity59622 : scanCanonicalize (H12AffineFastState.compose env59622 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59622 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59623 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,216,1149,136,1108,1062,81,1045,1025,1108,1245,1140,65,82,1269,16,1180,137,1,136,1057,33,253,1196,81,1]

theorem envBound59623 : H12AffineFastState.Bounded env59623 := by
  intro p hp
  have h : env59623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59622_59623 : H12AffineEnvironment.transform 7 253 env59622 = env59623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59622 == env59623) = true)

theorem identity59623 : scanCanonicalize (H12AffineFastState.compose env59623 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59623 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59624 : List Nat := [2,4,8,16,32,64,128,253,0,141,137,216,240,136,217,171,81,152,140,217,80,249,65,82,120,16,17,137,1,136,172,33,253,33,81,1]

theorem envBound59624 : H12AffineFastState.Bounded env59624 := by
  intro p hp
  have h : env59624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59623_59624 : H12AffineEnvironment.transform 9 141 env59623 = env59624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59623 == env59624) = true)

theorem identity59624 : scanCanonicalize (H12AffineFastState.compose env59624 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59624 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env59625 : List Nat := [2,4,8,16,32,1,128,188,0,141,137,153,177,136,152,171,16,152,140,152,17,184,0,19,57,16,17,137,1,136,172,33,188,33,16,1]

theorem envBound59625 : H12AffineFastState.Bounded env59625 := by
  intro p hp
  have h : env59625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59624_59625 : H12AffineEnvironment.transform 5 1 env59624 = env59625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59624 == env59625) = true)

theorem identity59625 : scanCanonicalize (H12AffineFastState.compose env59625 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59625 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59626 : List Nat := [2,4,8,16,32,1,56,4,0,53,49,33,9,48,32,19,16,32,52,32,17,0,0,19,57,16,17,49,1,48,20,33,4,33,16,1]

theorem envBound59626 : H12AffineFastState.Bounded env59626 := by
  intro p hp
  have h : env59626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59625_59626 : H12AffineEnvironment.transform 6 56 env59625 = env59626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59625 == env59626) = true)

theorem identity59626 : scanCanonicalize (H12AffineFastState.compose env59626 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59626 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env59627 : List Nat := [2,4,8,2,32,1,42,4,0,39,35,33,9,34,32,1,2,32,38,32,3,0,0,1,43,2,3,35,1,34,6,33,4,33,2,1]

theorem envBound59627 : H12AffineFastState.Bounded env59627 := by
  intro p hp
  have h : env59627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59626_59627 : H12AffineEnvironment.transform 3 2 env59626 = env59627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59626 == env59627) = true)

theorem identity59627 : scanCanonicalize (H12AffineFastState.compose env59627 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound59627 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59628 : List Nat := [2,4,8,2,9,1,3,4,0,14,10,8,9,11,9,1,2,9,15,9,3,0,0,1,2,2,3,10,1,11,6,8,4,8,2,1]

theorem envBound59628 : H12AffineFastState.Bounded env59628 := by
  intro p hp
  have h : env59628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59627_59628 : H12AffineEnvironment.transform 4 9 env59627 = env59628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env59627 == env59628) = true)

def env59629 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5375,428,262144,1025,2128,2097152,1417,64,3158,1288,17,2365813,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound59629 : H12AffineFastState.Bounded env59629 := by
  intro p hp
  have h : env59629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59617_59629 : H12AffineEnvironment.transform 12 1409 env59617 = env59629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59617 == env59629) = true)

theorem identity59629 : scanCanonicalize (H12AffineFastState.compose env59629 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59629 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59630 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5375,428,262144,1025,2128,3076,1417,64,3158,1288,17,267633,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound59630 : H12AffineFastState.Bounded env59630 := by
  intro p hp
  have h : env59630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59629_59630 : H12AffineEnvironment.transform 20 3076 env59629 = env59630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59629 == env59630) = true)

theorem identity59630 : scanCanonicalize (H12AffineFastState.compose env59630 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59630 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59631 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,5375,428,6376,1025,2128,3076,1417,64,3158,1288,17,3481,4177,508,4524,5368,7425,256,5237,428,0]

theorem envBound59631 : H12AffineFastState.Bounded env59631 := by
  intro p hp
  have h : env59631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59630_59631 : H12AffineEnvironment.transform 17 6376 env59630 = env59631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59630 == env59631) = true)

theorem identity59631 : scanCanonicalize (H12AffineFastState.compose env59631 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59631 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59632 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1409,412,2128,1331,428,2340,1025,2128,3076,1417,64,3158,1288,17,3481,413,508,96,1332,3277,256,1465,428,0]

theorem envBound59632 : H12AffineFastState.Bounded env59632 := by
  intro p hp
  have h : env59632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59631_59632 : H12AffineEnvironment.transform 11 460 env59631 = env59632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59631 == env59632) = true)

theorem identity59632 : scanCanonicalize (H12AffineFastState.compose env59632 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1261) := by decide +kernel

theorem selectedBound59632 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59633 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1261,460,1409,412,1213,1331,428,1481,1025,1213,233,1417,64,187,1288,17,372,413,508,96,1332,32,256,1465,428,0]

theorem envBound59633 : H12AffineFastState.Bounded env59633 := by
  intro p hp
  have h : env59633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59632_59633 : H12AffineEnvironment.transform 10 1261 env59632 = env59633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1261 env59632 == env59633) = true)

theorem identity59633 : scanCanonicalize (H12AffineFastState.compose env59633 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59633 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59634 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1244,460,1409,412,1164,1282,413,1481,1025,1164,216,1417,64,138,1288,17,325,413,461,81,1285,17,256,1416,413,0]

theorem envBound59634 : H12AffineFastState.Bounded env59634 := by
  intro p hp
  have h : env59634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59633_59634 : H12AffineEnvironment.transform 4 17 env59633 = env59634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59633 == env59634) = true)

theorem identity59634 : scanCanonicalize (H12AffineFastState.compose env59634 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59634 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59635 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1244,147,1246,195,1164,1117,194,1174,1025,1164,216,1238,64,138,1111,17,26,194,146,81,1114,17,95,1239,194,0]

theorem envBound59635 : H12AffineFastState.Bounded env59635 := by
  intro p hp
  have h : env59635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59634_59635 : H12AffineEnvironment.transform 7 95 env59634 = env59635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59634 == env59635) = true)

theorem identity59635 : scanCanonicalize (H12AffineFastState.compose env59635 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59635 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59636 : List Nat := [2,4,8,16,17,64,128,95,0,199,27,147,25,195,75,154,194,81,198,75,216,17,64,138,144,17,26,194,146,81,157,17,95,16,194,0]

theorem envBound59636 : H12AffineFastState.Bounded env59636 := by
  intro p hp
  have h : env59636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59635_59636 : H12AffineEnvironment.transform 9 199 env59635 = env59636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59635 == env59636) = true)

def env59637 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365812,4177,77954,66898,65543,68095,256,65674,78034,9600]

theorem envBound59637 : H12AffineFastState.Bounded env59637 := by
  intro p hp
  have h : env59637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59637 : H12AffineEnvironment.transform 8 1 env59615 = env59637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59615 == env59637) = true)

theorem identity59637 : scanCanonicalize (H12AffineFastState.compose env59637 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound59637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59638 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,5374,9260,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365812,4177,9340,4524,5369,7425,256,5236,9260,9600]

theorem envBound59638 : H12AffineFastState.Bounded env59638 := by
  intro p hp
  have h : env59638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59637_59638 : H12AffineEnvironment.transform 15 5374 env59637 = env59638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env59637 == env59638) = true)

def env59639 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,2097152,1417,65,3159,1288,16,2365812,4177,508,4524,5369,7425,256,5236,428,0]

theorem envBound59639 : H12AffineFastState.Bounded env59639 := by
  intro p hp
  have h : env59639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59638_59639 : H12AffineEnvironment.transform 12 1408 env59638 = env59639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59638 == env59639) = true)

theorem identity59639 : scanCanonicalize (H12AffineFastState.compose env59639 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound59639 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59640 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,6653,1417,65,3159,1288,16,262281,4177,508,4524,5369,7425,256,5236,428,0]

theorem envBound59640 : H12AffineFastState.Bounded env59640 := by
  intro p hp
  have h : env59640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59639_59640 : H12AffineEnvironment.transform 20 6653 env59639 = env59640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env59639 == env59640) = true)

theorem identity59640 : scanCanonicalize (H12AffineFastState.compose env59640 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59640 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59641 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,5374,428,262144,1025,1449,5125,1417,65,431,1288,16,262281,4177,508,4524,5369,4345,256,5236,428,0]

theorem envBound59641 : H12AffineFastState.Bounded env59641 := by
  intro p hp
  have h : env59641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59640_59641 : H12AffineEnvironment.transform 10 1528 env59640 = env59641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59640 == env59641) = true)

theorem identity59641 : scanCanonicalize (H12AffineFastState.compose env59641 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 5325) := by decide +kernel

theorem selectedBound59641 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59642 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,4096,1408,4176,1449,5374,428,5325,1025,1449,5125,1417,65,431,1288,16,5188,4177,508,4524,5369,4345,256,5236,428,0]

theorem envBound59642 : H12AffineFastState.Bounded env59642 := by
  intro p hp
  have h : env59642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59641_59642 : H12AffineEnvironment.transform 17 5325 env59641 = env59642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5325 env59641 == env59642) = true)

theorem identity59642 : scanCanonicalize (H12AffineFastState.compose env59642 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 216) := by decide +kernel

theorem selectedBound59642 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59643 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,216,1408,136,1449,1062,428,1045,1025,1449,1245,1417,65,431,1288,16,1180,137,508,372,1057,33,256,1196,428,0]

theorem envBound59643 : H12AffineFastState.Bounded env59643 := by
  intro p hp
  have h : env59643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59642_59643 : H12AffineEnvironment.transform 11 216 env59642 = env59643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 216 env59642 == env59643) = true)

theorem identity59643 : scanCanonicalize (H12AffineFastState.compose env59643 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59643 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59644 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,216,1148,136,1109,1062,80,1045,1025,1109,1245,1141,65,83,1268,16,1180,137,0,136,1057,33,252,1196,80,0]

theorem envBound59644 : H12AffineFastState.Bounded env59644 := by
  intro p hp
  have h : env59644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59643_59644 : H12AffineEnvironment.transform 7 252 env59643 = env59644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59643 == env59644) = true)

theorem identity59644 : scanCanonicalize (H12AffineFastState.compose env59644 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59644 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59645 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1028,136,1068,136,1029,1062,0,1045,1025,1029,1165,1061,17,3,1188,16,1180,137,0,136,1057,33,172,1196,0,0]

theorem envBound59645 : H12AffineFastState.Bounded env59645 := by
  intro p hp
  have h : env59645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59644_59645 : H12AffineEnvironment.transform 5 16 env59644 = env59645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59644 == env59645) = true)

theorem identity59645 : scanCanonicalize (H12AffineFastState.compose env59645 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59645 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59646 : List Nat := [2,4,8,16,32,16,27,55,1,1024,1028,19,1068,19,1029,1062,0,1045,1025,1029,1046,1061,17,3,1087,16,1031,18,0,19,1057,33,55,1079,0,0]

theorem envBound59646 : H12AffineFastState.Bounded env59646 := by
  intro p hp
  have h : env59646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59645_59646 : H12AffineEnvironment.transform 6 27 env59645 = env59646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59645 == env59646) = true)

theorem identity59646 : scanCanonicalize (H12AffineFastState.compose env59646 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 22) := by decide +kernel

theorem selectedBound59646 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59647 : List Nat := [2,4,8,16,32,16,27,55,1,22,18,19,58,19,19,48,0,3,23,19,0,51,17,3,41,16,17,18,0,19,55,33,55,33,0,0]

theorem envBound59647 : H12AffineFastState.Bounded env59647 := by
  intro p hp
  have h : env59647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59646_59647 : H12AffineEnvironment.transform 9 22 env59646 = env59647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 22 env59646 == env59647) = true)

theorem identity59647 : scanCanonicalize (H12AffineFastState.compose env59647 (packedSelected [3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59647 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59648 : List Nat := [2,4,8,16,17,16,27,6,1,22,18,19,11,19,19,1,0,3,23,19,0,2,17,3,24,16,17,18,0,19,6,16,6,16,0,0]

theorem envBound59648 : H12AffineFastState.Bounded env59648 := by
  intro p hp
  have h : env59648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59647_59648 : H12AffineEnvironment.transform 4 17 env59647 = env59648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59647 == env59648) = true)

theorem identity59648 : scanCanonicalize (H12AffineFastState.compose env59648 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59648 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59649 : List Nat := [2,4,8,8,9,8,3,6,1,14,10,11,11,11,11,1,0,3,15,11,0,2,9,3,0,8,9,10,0,11,6,8,6,8,0,0]

theorem envBound59649 : H12AffineFastState.Bounded env59649 := by
  intro p hp
  have h : env59649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59648_59649 : H12AffineEnvironment.transform 3 8 env59648 = env59649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59648 == env59649) = true)

theorem identity59649 : scanCanonicalize (H12AffineFastState.compose env59649 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59649 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59650 : List Nat := [2,4,1,1,0,1,3,6,1,7,3,2,2,2,2,1,0,3,6,2,0,2,0,3,0,1,0,3,0,2,6,1,6,1,0,0]

theorem envBound59650 : H12AffineFastState.Bounded env59650 := by
  intro p hp
  have h : env59650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59649_59650 : H12AffineEnvironment.transform 2 1 env59649 = env59650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59649 == env59650) = true)

theorem identity59650 : scanCanonicalize (H12AffineFastState.compose env59650 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59650 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env59651 : List Nat := [0,4,1,1,0,1,1,4,1,5,1,0,0,0,0,1,0,1,4,0,0,0,0,1,0,1,0,1,0,0,4,1,4,1,0,0]

theorem envBound59651 : H12AffineFastState.Bounded env59651 := by
  intro p hp
  have h : env59651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59650_59651 : H12AffineEnvironment.transform 0 0 env59650 = env59651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59650 == env59651) = true)

def env59652 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5374,429,262144,1025,2129,2097152,1417,64,3159,1288,17,2365812,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound59652 : H12AffineFastState.Bounded env59652 := by
  intro p hp
  have h : env59652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59638_59652 : H12AffineEnvironment.transform 12 1409 env59638 = env59652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59638 == env59652) = true)

theorem identity59652 : scanCanonicalize (H12AffineFastState.compose env59652 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59652 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59653 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5374,429,262144,1025,2129,3076,1417,64,3159,1288,17,267632,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound59653 : H12AffineFastState.Bounded env59653 := by
  intro p hp
  have h : env59653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59652_59653 : H12AffineEnvironment.transform 20 3076 env59652 = env59653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59652 == env59653) = true)

theorem identity59653 : scanCanonicalize (H12AffineFastState.compose env59653 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59653 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59654 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,5374,429,6377,1025,2129,3076,1417,64,3159,1288,17,3481,4177,509,4524,5369,7425,256,5236,429,1]

theorem envBound59654 : H12AffineFastState.Bounded env59654 := by
  intro p hp
  have h : env59654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59653_59654 : H12AffineEnvironment.transform 17 6377 env59653 = env59654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59653 == env59654) = true)

theorem identity59654 : scanCanonicalize (H12AffineFastState.compose env59654 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59654 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59655 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1409,413,2129,1331,429,2340,1025,2129,3076,1417,64,3159,1288,17,3481,412,509,97,1332,3276,256,1465,429,1]

theorem envBound59655 : H12AffineFastState.Bounded env59655 := by
  intro p hp
  have h : env59655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59654_59655 : H12AffineEnvironment.transform 11 461 env59654 = env59655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59654 == env59655) = true)

theorem identity59655 : scanCanonicalize (H12AffineFastState.compose env59655 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59655 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59656 : List Nat := [2,4,8,16,17,64,128,256,1,1024,2048,461,1409,413,2129,1282,412,2325,1025,2129,3076,1417,64,3159,1288,17,3481,412,460,80,1285,3276,256,1416,412,1]

theorem envBound59656 : H12AffineFastState.Bounded env59656 := by
  intro p hp
  have h : env59656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59655_59656 : H12AffineEnvironment.transform 4 17 env59655 = env59656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59655 == env59656) = true)

theorem identity59656 : scanCanonicalize (H12AffineFastState.compose env59656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59657 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1245,461,1409,413,1164,1282,412,1480,1025,1164,217,1417,64,138,1288,17,324,412,460,80,1285,17,256,1416,412,1]

theorem envBound59657 : H12AffineFastState.Bounded env59657 := by
  intro p hp
  have h : env59657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59656_59657 : H12AffineEnvironment.transform 10 1245 env59656 = env59657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59656 == env59657) = true)

theorem identity59657 : scanCanonicalize (H12AffineFastState.compose env59657 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59657 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59658 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1245,146,1246,194,1164,1117,195,1175,1025,1164,217,1238,64,138,1111,17,27,195,147,80,1114,17,95,1239,195,1]

theorem envBound59658 : H12AffineFastState.Bounded env59658 := by
  intro p hp
  have h : env59658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59657_59658 : H12AffineEnvironment.transform 7 95 env59657 = env59658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59657 == env59658) = true)

theorem identity59658 : scanCanonicalize (H12AffineFastState.compose env59658 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59658 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59659 : List Nat := [2,4,8,16,17,64,128,95,1,199,26,146,25,194,75,154,195,80,198,75,217,17,64,138,144,17,27,195,147,80,157,17,95,16,195,1]

theorem envBound59659 : H12AffineFastState.Bounded env59659 := by
  intro p hp
  have h : env59659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59658_59659 : H12AffineEnvironment.transform 9 199 env59658 = env59659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59658 == env59659) = true)

def env59660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,4194304,8388608,8399767,8397001,8388689,6561533,4177,77954,4260570,8463814,8465982,256,4261122,78034,8389184]

theorem envBound59660 : H12AffineFastState.Bounded env59660 := by
  intro p hp
  have h : env59660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59472_59660 : H12AffineEnvironment.transform 26 6561533 env59472 = env59660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env59472 == env59660) = true)

def env59661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,8388608,8399767,8397001,8388689,2366325,4177,77954,67410,8463814,8465982,256,65674,78034,8389184]

theorem envBound59661 : H12AffineFastState.Bounded env59661 := by
  intro p hp
  have h : env59661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59660_59661 : H12AffineEnvironment.transform 21 1416 env59660 = env59661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59660 == env59661) = true)

def env59662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9664,3671,1289,9617,2366325,4177,77954,67410,65542,68606,256,65674,78034,10112]

theorem envBound59662 : H12AffineFastState.Bounded env59662 := by
  intro p hp
  have h : env59662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59661_59662 : H12AffineEnvironment.transform 22 9664 env59661 = env59662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59661 == env59662) = true)

def env59663 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1289,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59663 : H12AffineFastState.Bounded env59663 := by
  intro p hp
  have h : env59663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59662_59663 : H12AffineEnvironment.transform 8 0 env59662 = env59663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59662 == env59663) = true)

theorem identity59663 : scanCanonicalize (H12AffineFastState.compose env59663 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 10628) := by decide +kernel

theorem selectedBound59663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59664 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,10628,1416,9664,3159,1289,9617,274673,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59664 : H12AffineFastState.Bounded env59664 := by
  intro p hp
  have h : env59664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59663_59664 : H12AffineEnvironment.transform 20 10628 env59663 = env59664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 10628 env59663 == env59664) = true)

def env59665 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,3076,1416,64,3159,1289,17,267633,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59665 : H12AffineFastState.Bounded env59665 := by
  intro p hp
  have h : env59665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59664_59665 : H12AffineEnvironment.transform 12 1408 env59664 = env59665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59664 == env59665) = true)

theorem identity59665 : scanCanonicalize (H12AffineFastState.compose env59665 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5375) := by decide +kernel

theorem selectedBound59665 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59666 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5375,429,262144,1025,2128,3076,1416,64,3159,1289,17,267633,4177,509,4525,5369,7425,256,5237,429,0]

theorem envBound59666 : H12AffineFastState.Bounded env59666 := by
  intro p hp
  have h : env59666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59665_59666 : H12AffineEnvironment.transform 15 5375 env59665 = env59666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5375 env59665 == env59666) = true)

theorem identity59666 : scanCanonicalize (H12AffineFastState.compose env59666 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59666 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59667 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,5375,429,6377,1025,2128,3076,1416,64,3159,1289,17,3480,4177,509,4525,5369,7425,256,5237,429,0]

theorem envBound59667 : H12AffineFastState.Bounded env59667 := by
  intro p hp
  have h : env59667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59666_59667 : H12AffineEnvironment.transform 17 6377 env59666 = env59667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59666 == env59667) = true)

theorem identity59667 : scanCanonicalize (H12AffineFastState.compose env59667 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59667 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59668 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,461,1408,413,2128,1330,429,2340,1025,2128,3076,1416,64,3159,1289,17,3480,412,509,96,1332,3276,256,1464,429,0]

theorem envBound59668 : H12AffineFastState.Bounded env59668 := by
  intro p hp
  have h : env59668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59667_59668 : H12AffineEnvironment.transform 11 461 env59667 = env59668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59667 == env59668) = true)

theorem identity59668 : scanCanonicalize (H12AffineFastState.compose env59668 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1260) := by decide +kernel

theorem selectedBound59668 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59669 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1260,461,1408,413,1212,1330,429,1480,1025,1212,232,1416,64,187,1289,17,372,412,509,96,1332,32,256,1464,429,0]

theorem envBound59669 : H12AffineFastState.Bounded env59669 := by
  intro p hp
  have h : env59669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59668_59669 : H12AffineEnvironment.transform 10 1260 env59668 = env59669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1260 env59668 == env59669) = true)

theorem identity59669 : scanCanonicalize (H12AffineFastState.compose env59669 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59669 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59670 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1245,461,1408,413,1165,1283,412,1480,1025,1165,217,1416,64,138,1289,17,325,412,460,81,1285,17,256,1417,412,0]

theorem envBound59670 : H12AffineFastState.Bounded env59670 := by
  intro p hp
  have h : env59670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59669_59670 : H12AffineEnvironment.transform 4 17 env59669 = env59670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59669 == env59670) = true)

theorem identity59670 : scanCanonicalize (H12AffineFastState.compose env59670 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59670 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59671 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1245,146,1247,194,1165,1116,195,1175,1025,1165,217,1239,64,138,1110,17,26,195,147,81,1114,17,95,1238,195,0]

theorem envBound59671 : H12AffineFastState.Bounded env59671 := by
  intro p hp
  have h : env59671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59670_59671 : H12AffineEnvironment.transform 7 95 env59670 = env59671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59670 == env59671) = true)

theorem identity59671 : scanCanonicalize (H12AffineFastState.compose env59671 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59671 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59672 : List Nat := [2,4,8,16,17,64,128,95,0,198,27,146,25,194,75,154,195,81,199,75,217,17,64,138,144,17,26,195,147,81,156,17,95,16,195,0]

theorem envBound59672 : H12AffineFastState.Bounded env59672 := by
  intro p hp
  have h : env59672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59671_59672 : H12AffineEnvironment.transform 9 198 env59671 = env59672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59671 == env59672) = true)

def env59673 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,3077,1416,65,3159,1289,16,267632,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59673 : H12AffineFastState.Bounded env59673 := by
  intro p hp
  have h : env59673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59664_59673 : H12AffineEnvironment.transform 12 1409 env59664 = env59673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59664 == env59673) = true)

theorem identity59673 : scanCanonicalize (H12AffineFastState.compose env59673 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59673 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59674 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1529,1409,1449,2128,65536,65706,262144,1025,2128,3077,1416,65,3159,1289,16,262281,1448,65786,66898,65542,68094,256,65674,65706,1]

theorem envBound59674 : H12AffineFastState.Bounded env59674 := by
  intro p hp
  have h : env59674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59673_59674 : H12AffineEnvironment.transform 11 1529 env59673 = env59674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env59673 == env59674) = true)

theorem identity59674 : scanCanonicalize (H12AffineFastState.compose env59674 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59674 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59675 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1448,65536,65706,262144,1025,1448,509,1416,65,431,1289,16,262281,1448,65786,66898,65542,66566,256,65674,65706,1]

theorem envBound59675 : H12AffineFastState.Bounded env59675 := by
  intro p hp
  have h : env59675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59674_59675 : H12AffineEnvironment.transform 10 1528 env59674 = env59675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59674 == env59675) = true)

theorem identity59675 : scanCanonicalize (H12AffineFastState.compose env59675 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 308) := by decide +kernel

theorem selectedBound59675 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59676 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1448,65536,65706,308,1025,1448,509,1416,65,431,1289,16,445,1448,65786,66898,65542,66566,256,65674,65706,1]

theorem envBound59676 : H12AffineFastState.Bounded env59676 := by
  intro p hp
  have h : env59676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59675_59676 : H12AffineEnvironment.transform 17 308 env59675 = env59676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 308 env59675 == env59676) = true)

theorem identity59676 : scanCanonicalize (H12AffineFastState.compose env59676 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59676 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59677 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1529,1409,1449,1448,1063,1165,308,1025,1448,509,1416,65,431,1289,16,445,1448,1245,373,1057,33,256,1197,1165,1]

theorem envBound59677 : H12AffineFastState.Bounded env59677 := by
  intro p hp
  have h : env59677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59676_59677 : H12AffineEnvironment.transform 15 1063 env59676 = env59677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59676 == env59677) = true)

theorem identity59677 : scanCanonicalize (H12AffineFastState.compose env59677 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59677 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59678 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,1028,1148,1108,1109,1063,1165,201,1025,1109,0,1141,65,82,1268,16,64,1109,1245,136,1057,33,253,1197,1165,1]

theorem envBound59678 : H12AffineFastState.Bounded env59678 := by
  intro p hp
  have h : env59678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59677_59678 : H12AffineEnvironment.transform 7 253 env59677 = env59678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59677 == env59678) = true)

theorem identity59678 : scanCanonicalize (H12AffineFastState.compose env59678 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59678 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59679 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1029,1028,1069,1029,1028,1063,1165,152,1025,1028,0,1060,16,3,1189,16,17,1028,1164,136,1057,33,172,1197,1165,1]

theorem envBound59679 : H12AffineFastState.Bounded env59679 := by
  intro p hp
  have h : env59679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59678_59679 : H12AffineEnvironment.transform 5 17 env59678 = env59679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59678 == env59679) = true)

theorem identity59679 : scanCanonicalize (H12AffineFastState.compose env59679 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 58) := by decide +kernel

theorem selectedBound59679 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59680 : List Nat := [2,4,8,16,32,17,58,22,0,1024,1029,1028,1069,1029,1028,1063,1079,34,1025,1028,0,1060,16,3,1055,16,17,1028,1078,50,1057,33,22,1047,1079,1]

theorem envBound59680 : H12AffineFastState.Bounded env59680 := by
  intro p hp
  have h : env59680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59679_59680 : H12AffineEnvironment.transform 6 58 env59679 = env59680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 58 env59679 == env59680) = true)

theorem identity59680 : scanCanonicalize (H12AffineFastState.compose env59680 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound59680 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59681 : List Nat := [2,4,8,16,32,17,58,22,0,36,33,32,9,33,32,3,19,34,37,32,0,0,16,3,59,16,17,32,18,50,5,33,22,51,19,1]

theorem envBound59681 : H12AffineFastState.Bounded env59681 := by
  intro p hp
  have h : env59681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59680_59681 : H12AffineEnvironment.transform 9 36 env59680 = env59681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env59680 == env59681) = true)

def env59682 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1289,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59682 : H12AffineFastState.Bounded env59682 := by
  intro p hp
  have h : env59682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59662_59682 : H12AffineEnvironment.transform 8 1 env59662 = env59682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59662 == env59682) = true)

theorem identity59682 : scanCanonicalize (H12AffineFastState.compose env59682 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 3076) := by decide +kernel

theorem selectedBound59682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59683 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,3076,1416,9664,3158,1289,9617,267632,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59683 : H12AffineFastState.Bounded env59683 := by
  intro p hp
  have h : env59683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59682_59683 : H12AffineEnvironment.transform 20 3076 env59682 = env59683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3076 env59682 == env59683) = true)

def env59684 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,3076,1416,64,3158,1289,17,267632,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound59684 : H12AffineFastState.Bounded env59684 := by
  intro p hp
  have h : env59684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59683_59684 : H12AffineEnvironment.transform 12 1408 env59683 = env59684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59683 == env59684) = true)

theorem identity59684 : scanCanonicalize (H12AffineFastState.compose env59684 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5374) := by decide +kernel

theorem selectedBound59684 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59685 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,262144,1025,2129,3076,1416,64,3158,1289,17,267632,4177,508,4525,5368,7425,256,5236,428,1]

theorem envBound59685 : H12AffineFastState.Bounded env59685 := by
  intro p hp
  have h : env59685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59684_59685 : H12AffineEnvironment.transform 15 5374 env59684 = env59685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5374 env59684 == env59685) = true)

theorem identity59685 : scanCanonicalize (H12AffineFastState.compose env59685 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59685 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59686 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,5374,428,6376,1025,2129,3076,1416,64,3158,1289,17,3480,4177,508,4525,5368,7425,256,5236,428,1]

theorem envBound59686 : H12AffineFastState.Bounded env59686 := by
  intro p hp
  have h : env59686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59685_59686 : H12AffineEnvironment.transform 17 6376 env59685 = env59686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59685 == env59686) = true)

theorem identity59686 : scanCanonicalize (H12AffineFastState.compose env59686 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59686 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59687 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,460,1408,412,2129,1330,428,2340,1025,2129,3076,1416,64,3158,1289,17,3480,413,508,97,1332,3277,256,1464,428,1]

theorem envBound59687 : H12AffineFastState.Bounded env59687 := by
  intro p hp
  have h : env59687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59686_59687 : H12AffineEnvironment.transform 11 460 env59686 = env59687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59686 == env59687) = true)

theorem identity59687 : scanCanonicalize (H12AffineFastState.compose env59687 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59687 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59688 : List Nat := [2,4,8,16,17,64,128,256,1,1024,2048,460,1408,412,2129,1283,413,2325,1025,2129,3076,1416,64,3158,1289,17,3480,413,461,80,1285,3277,256,1417,413,1]

theorem envBound59688 : H12AffineFastState.Bounded env59688 := by
  intro p hp
  have h : env59688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59687_59688 : H12AffineEnvironment.transform 4 17 env59687 = env59688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59687 == env59688) = true)

theorem identity59688 : scanCanonicalize (H12AffineFastState.compose env59688 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59688 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env59689 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1244,460,1408,412,1165,1283,413,1481,1025,1165,216,1416,64,138,1289,17,324,413,461,80,1285,17,256,1417,413,1]

theorem envBound59689 : H12AffineFastState.Bounded env59689 := by
  intro p hp
  have h : env59689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59688_59689 : H12AffineEnvironment.transform 10 1244 env59688 = env59689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59688 == env59689) = true)

theorem identity59689 : scanCanonicalize (H12AffineFastState.compose env59689 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59689 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59690 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1244,147,1247,195,1165,1116,194,1174,1025,1165,216,1239,64,138,1110,17,27,194,146,80,1114,17,95,1238,194,1]

theorem envBound59690 : H12AffineFastState.Bounded env59690 := by
  intro p hp
  have h : env59690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59689_59690 : H12AffineEnvironment.transform 7 95 env59689 = env59690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59689 == env59690) = true)

theorem identity59690 : scanCanonicalize (H12AffineFastState.compose env59690 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound59690 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59691 : List Nat := [2,4,8,16,17,64,128,95,1,198,26,147,25,195,75,154,194,80,199,75,216,17,64,138,144,17,27,194,146,80,156,17,95,16,194,1]

theorem envBound59691 : H12AffineFastState.Bounded env59691 := by
  intro p hp
  have h : env59691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59690_59691 : H12AffineEnvironment.transform 9 198 env59690 = env59691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env59690 == env59691) = true)

def env59692 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,3076,1416,65,3158,1289,16,267632,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59692 : H12AffineFastState.Bounded env59692 := by
  intro p hp
  have h : env59692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59683_59692 : H12AffineEnvironment.transform 12 1409 env59683 = env59692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59683 == env59692) = true)

theorem identity59692 : scanCanonicalize (H12AffineFastState.compose env59692 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59692 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59693 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1529,1409,1449,2129,65536,65706,262144,1025,2129,3076,1416,65,3158,1289,16,262281,1448,65786,66899,65542,68095,256,65674,65706,0]

theorem envBound59693 : H12AffineFastState.Bounded env59693 := by
  intro p hp
  have h : env59693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59692_59693 : H12AffineEnvironment.transform 11 1529 env59692 = env59693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env59692 == env59693) = true)

theorem identity59693 : scanCanonicalize (H12AffineFastState.compose env59693 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59693 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59694 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1448,65536,65706,262144,1025,1448,509,1416,65,431,1289,16,262281,1448,65786,66899,65542,66566,256,65674,65706,0]

theorem envBound59694 : H12AffineFastState.Bounded env59694 := by
  intro p hp
  have h : env59694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59693_59694 : H12AffineEnvironment.transform 10 1529 env59693 = env59694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59693 == env59694) = true)

theorem identity59694 : scanCanonicalize (H12AffineFastState.compose env59694 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 308) := by decide +kernel

theorem selectedBound59694 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59695 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1448,65536,65706,308,1025,1448,509,1416,65,431,1289,16,445,1448,65786,66899,65542,66566,256,65674,65706,0]

theorem envBound59695 : H12AffineFastState.Bounded env59695 := by
  intro p hp
  have h : env59695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59694_59695 : H12AffineEnvironment.transform 17 308 env59694 = env59695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 308 env59694 == env59695) = true)

theorem identity59695 : scanCanonicalize (H12AffineFastState.compose env59695 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59695 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59696 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1529,1409,1449,1448,1063,1165,308,1025,1448,509,1416,65,431,1289,16,445,1448,1245,372,1057,33,256,1197,1165,0]

theorem envBound59696 : H12AffineFastState.Bounded env59696 := by
  intro p hp
  have h : env59696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59695_59696 : H12AffineEnvironment.transform 15 1063 env59695 = env59696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59695 == env59696) = true)

theorem identity59696 : scanCanonicalize (H12AffineFastState.compose env59696 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59696 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59697 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,1029,1149,1109,1108,1063,1165,200,1025,1108,1,1140,65,83,1269,16,65,1108,1245,136,1057,33,252,1197,1165,0]

theorem envBound59697 : H12AffineFastState.Bounded env59697 := by
  intro p hp
  have h : env59697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59696_59697 : H12AffineEnvironment.transform 7 252 env59696 = env59697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59696 == env59697) = true)

theorem identity59697 : scanCanonicalize (H12AffineFastState.compose env59697 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59697 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59698 : List Nat := [2,4,8,16,32,64,128,252,1,140,137,137,241,217,216,171,1,200,141,216,1,248,65,83,121,16,65,216,81,136,173,33,252,33,1,0]

theorem envBound59698 : H12AffineFastState.Bounded env59698 := by
  intro p hp
  have h : env59698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59697_59698 : H12AffineEnvironment.transform 9 140 env59697 = env59698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59697 == env59698) = true)

theorem identity59698 : scanCanonicalize (H12AffineFastState.compose env59698 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59698 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59699 : List Nat := [2,4,8,16,32,32,128,156,1,140,137,137,145,185,184,171,1,168,141,184,1,152,33,51,25,16,33,184,49,136,173,33,156,33,1,0]

theorem envBound59699 : H12AffineFastState.Bounded env59699 := by
  intro p hp
  have h : env59699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59698_59699 : H12AffineEnvironment.transform 5 32 env59698 = env59699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59698 == env59699) = true)

theorem identity59699 : scanCanonicalize (H12AffineFastState.compose env59699 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 58) := by decide +kernel

theorem selectedBound59699 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59700 : List Nat := [2,4,8,16,32,32,58,38,1,54,51,51,43,3,2,17,1,18,55,2,1,34,33,51,25,16,33,2,49,50,23,33,38,33,1,0]

theorem envBound59700 : H12AffineFastState.Bounded env59700 := by
  intro p hp
  have h : env59700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59699_59700 : H12AffineEnvironment.transform 6 58 env59699 = env59700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 58 env59699 == env59700) = true)

theorem identity59700 : scanCanonicalize (H12AffineFastState.compose env59700 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59700 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59701 : List Nat := [2,4,8,16,11,11,17,13,1,29,24,24,0,3,2,17,1,18,28,2,1,9,10,24,25,16,10,2,26,25,23,10,13,10,1,0]

theorem envBound59701 : H12AffineFastState.Bounded env59701 := by
  intro p hp
  have h : env59701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59700_59701 : H12AffineEnvironment.transform 4 11 env59700 = env59701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59700 == env59701) = true)

theorem identity59701 : scanCanonicalize (H12AffineFastState.compose env59701 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59701 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59702 : List Nat := [2,4,8,3,11,11,2,13,1,14,11,11,0,3,2,2,1,1,15,2,1,9,10,11,10,3,10,2,9,10,4,10,13,10,1,0]

theorem envBound59702 : H12AffineFastState.Bounded env59702 := by
  intro p hp
  have h : env59702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59701_59702 : H12AffineEnvironment.transform 3 3 env59701 = env59702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59701 == env59702) = true)

theorem identity59702 : scanCanonicalize (H12AffineFastState.compose env59702 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59702 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59703 : List Nat := [2,4,0,3,3,3,2,5,1,6,3,3,0,3,2,2,1,1,7,2,1,1,2,3,2,3,2,2,1,2,4,2,5,2,1,0]

theorem envBound59703 : H12AffineFastState.Bounded env59703 := by
  intro p hp
  have h : env59703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59702_59703 : H12AffineEnvironment.transform 2 0 env59702 = env59703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59702 == env59703) = true)

theorem identity59703 : scanCanonicalize (H12AffineFastState.compose env59703 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59704 : List Nat := [0,4,0,1,1,1,0,5,1,4,1,1,0,1,0,0,1,1,5,0,1,1,0,1,0,1,0,0,1,0,4,0,5,0,1,0]

theorem envBound59704 : H12AffineFastState.Bounded env59704 := by
  intro p hp
  have h : env59704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59703_59704 : H12AffineEnvironment.transform 0 0 env59703 = env59704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59703 == env59704) = true)

def env59705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1416,9665,3670,1288,9616,2366325,4177,77954,67410,65543,68607,256,65674,78034,10113]

theorem envBound59705 : H12AffineFastState.Bounded env59705 := by
  intro p hp
  have h : env59705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59661_59705 : H12AffineEnvironment.transform 22 9665 env59661 = env59705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59661 == env59705) = true)

def env59706 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59706 : H12AffineFastState.Bounded env59706 := by
  intro p hp
  have h : env59706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59705_59706 : H12AffineEnvironment.transform 8 0 env59705 = env59706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59705 == env59706) = true)

theorem identity59706 : scanCanonicalize (H12AffineFastState.compose env59706 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound59706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59707 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,8192,1028,2128,65536,74886,262144,1025,2128,2097152,1416,9665,3158,1288,9616,2362657,1029,74966,66898,65543,68095,256,65674,74886,9601]

theorem envBound59707 : H12AffineFastState.Bounded env59707 := by
  intro p hp
  have h : env59707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59706_59707 : H12AffineEnvironment.transform 11 1108 env59706 = env59707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59706 == env59707) = true)

def env59708 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,2097152,1416,65,3158,1288,16,2362657,1029,65878,66898,65543,68095,256,65674,65798,1]

theorem envBound59708 : H12AffineFastState.Bounded env59708 := by
  intro p hp
  have h : env59708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59707_59708 : H12AffineEnvironment.transform 12 1408 env59707 = env59708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59707 == env59708) = true)

theorem identity59708 : scanCanonicalize (H12AffineFastState.compose env59708 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3496) := by decide +kernel

theorem selectedBound59708 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59709 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1408,1028,2128,65536,65798,262144,1025,2128,3496,1416,65,3158,1288,16,262281,1029,65878,66898,65543,68095,256,65674,65798,1]

theorem envBound59709 : H12AffineFastState.Bounded env59709 := by
  intro p hp
  have h : env59709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59708_59709 : H12AffineEnvironment.transform 20 3496 env59708 = env59709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3496 env59708 == env59709) = true)

theorem identity59709 : scanCanonicalize (H12AffineFastState.compose env59709 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59709 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59710 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1448,65536,65798,262144,1025,1448,80,1416,65,430,1288,16,262281,1029,65878,66898,65543,66567,256,65674,65798,1]

theorem envBound59710 : H12AffineFastState.Bounded env59710 := by
  intro p hp
  have h : env59710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59709_59710 : H12AffineEnvironment.transform 10 1528 env59709 = env59710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59709 == env59710) = true)

theorem identity59710 : scanCanonicalize (H12AffineFastState.compose env59710 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 152) := by decide +kernel

theorem selectedBound59710 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59711 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1448,65536,65798,152,1025,1448,80,1416,65,430,1288,16,17,1029,65878,66898,65543,66567,256,65674,65798,1]

theorem envBound59711 : H12AffineFastState.Bounded env59711 := by
  intro p hp
  have h : env59711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59710_59711 : H12AffineEnvironment.transform 17 152 env59710 = env59711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 152 env59710 == env59711) = true)

theorem identity59711 : scanCanonicalize (H12AffineFastState.compose env59711 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59711 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59712 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1108,1408,1028,1448,1063,1313,152,1025,1448,80,1416,65,430,1288,16,17,1029,1393,373,1056,32,256,1197,1313,1]

theorem envBound59712 : H12AffineFastState.Bounded env59712 := by
  intro p hp
  have h : env59712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59711_59712 : H12AffineEnvironment.transform 15 1063 env59711 = env59712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59711 == env59712) = true)

theorem identity59712 : scanCanonicalize (H12AffineFastState.compose env59712 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59712 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59713 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,1108,1148,1028,1108,1063,1245,152,1025,1108,80,1140,65,82,1268,16,17,1029,1165,137,1056,32,252,1197,1245,1]

theorem envBound59713 : H12AffineFastState.Bounded env59713 := by
  intro p hp
  have h : env59713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59712_59713 : H12AffineEnvironment.transform 7 252 env59712 = env59713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59712 == env59713) = true)

theorem identity59713 : scanCanonicalize (H12AffineFastState.compose env59713 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59713 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59714 : List Nat := [2,4,8,16,32,64,128,252,0,141,137,217,241,137,217,170,80,152,140,217,80,249,65,82,121,16,17,136,0,137,173,32,252,32,80,1]

theorem envBound59714 : H12AffineFastState.Bounded env59714 := by
  intro p hp
  have h : env59714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59713_59714 : H12AffineEnvironment.transform 9 141 env59713 = env59714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59713 == env59714) = true)

def env59715 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2128,65536,65799,262144,1025,2128,2097152,1416,64,3158,1288,17,2362657,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound59715 : H12AffineFastState.Bounded env59715 := by
  intro p hp
  have h : env59715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59707_59715 : H12AffineEnvironment.transform 12 1409 env59707 = env59715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59707 == env59715) = true)

theorem identity59715 : scanCanonicalize (H12AffineFastState.compose env59715 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59715 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59716 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2128,65536,65799,262144,1025,2128,68782,1416,64,3158,1288,17,328079,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound59716 : H12AffineFastState.Bounded env59716 := by
  intro p hp
  have h : env59716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59715_59716 : H12AffineEnvironment.transform 20 68782 env59715 = env59716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59715 == env59716) = true)

theorem identity59716 : scanCanonicalize (H12AffineFastState.compose env59716 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound59716 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59717 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1108,1409,1028,2128,65536,65799,3261,1025,2128,68782,1416,64,3158,1288,17,68914,1029,65879,66898,65543,68095,256,65674,65799,0]

theorem envBound59717 : H12AffineFastState.Bounded env59717 := by
  intro p hp
  have h : env59717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59716_59717 : H12AffineEnvironment.transform 17 3261 env59716 = env59717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env59716 == env59717) = true)

theorem identity59717 : scanCanonicalize (H12AffineFastState.compose env59717 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59717 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59718 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,1108,1409,1028,1164,65536,65799,97,1025,1164,65650,1416,64,138,1288,17,66030,1029,65879,66898,65543,66851,256,65674,65799,0]

theorem envBound59718 : H12AffineFastState.Bounded env59718 := by
  intro p hp
  have h : env59718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59717_59718 : H12AffineEnvironment.transform 10 1244 env59717 = env59718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59717 == env59718) = true)

theorem identity59718 : scanCanonicalize (H12AffineFastState.compose env59718 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59718 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59719 : List Nat := [2,4,8,16,32,64,128,256,0,409,325,461,24,413,277,65536,65799,97,408,277,65650,17,64,138,145,17,66030,412,65879,65739,65543,65722,256,65674,65799,0]

theorem envBound59719 : H12AffineFastState.Bounded env59719 := by
  intro p hp
  have h : env59719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59718_59719 : H12AffineEnvironment.transform 9 409 env59718 = env59719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59718 == env59719) = true)

theorem identity59719 : scanCanonicalize (H12AffineFastState.compose env59719 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59719 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59720 : List Nat := [2,4,8,16,17,64,128,256,0,409,325,461,24,413,277,65536,65799,80,408,277,65603,17,64,138,145,17,66015,412,65879,65739,65543,65675,256,65674,65799,0]

theorem envBound59720 : H12AffineFastState.Bounded env59720 := by
  intro p hp
  have h : env59720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59719_59720 : H12AffineEnvironment.transform 4 17 env59719 = env59720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59719 == env59720) = true)

theorem identity59720 : scanCanonicalize (H12AffineFastState.compose env59720 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59721 : List Nat := [2,4,8,16,17,64,128,256,0,409,325,461,24,413,277,154,413,80,408,277,217,17,64,138,145,17,325,412,461,81,157,17,256,16,413,0]

theorem envBound59721 : H12AffineFastState.Bounded env59721 := by
  intro p hp
  have h : env59721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59720_59721 : H12AffineEnvironment.transform 15 154 env59720 = env59721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59720 == env59721) = true)

theorem identity59721 : scanCanonicalize (H12AffineFastState.compose env59721 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59721 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59722 : List Nat := [2,4,8,16,17,64,128,215,0,78,146,26,24,74,194,154,74,80,79,194,217,17,64,138,145,17,146,75,26,81,157,17,215,16,74,0]

theorem envBound59722 : H12AffineFastState.Bounded env59722 := by
  intro p hp
  have h : env59722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59721_59722 : H12AffineEnvironment.transform 7 215 env59721 = env59722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59721 == env59722) = true)

def env59723 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1288,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59723 : H12AffineFastState.Bounded env59723 := by
  intro p hp
  have h : env59723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59705_59723 : H12AffineEnvironment.transform 8 1 env59705 = env59723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59705 == env59723) = true)

theorem identity59723 : scanCanonicalize (H12AffineFastState.compose env59723 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4564) := by decide +kernel

theorem selectedBound59723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59724 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,4564,4176,2129,65536,65798,262144,1025,2129,2097152,1416,5141,3159,1288,5188,2365812,4177,65878,66899,65543,68094,256,65674,65798,5204]

theorem envBound59724 : H12AffineFastState.Bounded env59724 := by
  intro p hp
  have h : env59724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59723_59724 : H12AffineEnvironment.transform 12 4564 env59723 = env59724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4564 env59723 == env59724) = true)

def env59725 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,2097152,1416,65,3159,1288,16,2362656,1029,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound59725 : H12AffineFastState.Bounded env59725 := by
  intro p hp
  have h : env59725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59724_59725 : H12AffineEnvironment.transform 11 1108 env59724 = env59725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env59724 == env59725) = true)

theorem identity59725 : scanCanonicalize (H12AffineFastState.compose env59725 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 3497) := by decide +kernel

theorem selectedBound59725 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59726 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1108,1408,1028,2129,65536,65798,262144,1025,2129,3497,1416,65,3159,1288,16,262281,1029,65878,66899,65543,68094,256,65674,65798,0]

theorem envBound59726 : H12AffineFastState.Bounded env59726 := by
  intro p hp
  have h : env59726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59725_59726 : H12AffineEnvironment.transform 20 3497 env59725 = env59726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 3497 env59725 == env59726) = true)

theorem identity59726 : scanCanonicalize (H12AffineFastState.compose env59726 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59726 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59727 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1448,65536,65798,262144,1025,1448,80,1416,65,430,1288,16,262281,1029,65878,66899,65543,66567,256,65674,65798,0]

theorem envBound59727 : H12AffineFastState.Bounded env59727 := by
  intro p hp
  have h : env59727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59726_59727 : H12AffineEnvironment.transform 10 1529 env59726 = env59727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59726 == env59727) = true)

theorem identity59727 : scanCanonicalize (H12AffineFastState.compose env59727 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 152) := by decide +kernel

theorem selectedBound59727 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59728 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1448,65536,65798,152,1025,1448,80,1416,65,430,1288,16,17,1029,65878,66899,65543,66567,256,65674,65798,0]

theorem envBound59728 : H12AffineFastState.Bounded env59728 := by
  intro p hp
  have h : env59728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59727_59728 : H12AffineEnvironment.transform 17 152 env59727 = env59728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 152 env59727 == env59728) = true)

theorem identity59728 : scanCanonicalize (H12AffineFastState.compose env59728 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59728 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59729 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1108,1408,1028,1448,1063,1313,152,1025,1448,80,1416,65,430,1288,16,17,1029,1393,372,1056,32,256,1197,1313,0]

theorem envBound59729 : H12AffineFastState.Bounded env59729 := by
  intro p hp
  have h : env59729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59728_59729 : H12AffineEnvironment.transform 15 1063 env59728 = env59729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59728 == env59729) = true)

theorem identity59729 : scanCanonicalize (H12AffineFastState.compose env59729 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59729 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59730 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,1108,1149,1028,1109,1063,1244,152,1025,1109,80,1141,65,83,1269,16,17,1029,1164,137,1056,32,253,1197,1244,0]

theorem envBound59730 : H12AffineFastState.Bounded env59730 := by
  intro p hp
  have h : env59730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59729_59730 : H12AffineEnvironment.transform 7 253 env59729 = env59730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59729 == env59730) = true)

theorem identity59730 : scanCanonicalize (H12AffineFastState.compose env59730 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59730 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59731 : List Nat := [2,4,8,16,32,17,128,172,1,1024,1028,1029,1068,1028,1028,1063,1165,152,1025,1028,1,1060,16,2,1188,16,17,1029,1164,137,1056,32,172,1197,1165,0]

theorem envBound59731 : H12AffineFastState.Bounded env59731 := by
  intro p hp
  have h : env59731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59730_59731 : H12AffineEnvironment.transform 5 17 env59730 = env59731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59730 == env59731) = true)

theorem identity59731 : scanCanonicalize (H12AffineFastState.compose env59731 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound59731 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59732 : List Nat := [2,4,8,16,18,17,128,158,1,1024,1028,1029,1054,1028,1028,1045,1165,152,1025,1028,1,1046,16,2,1174,16,17,1029,1164,137,1042,18,158,1183,1165,0]

theorem envBound59732 : H12AffineFastState.Bounded env59732 := by
  intro p hp
  have h : env59732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59731_59732 : H12AffineEnvironment.transform 4 18 env59731 = env59732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env59731 == env59732) = true)

theorem identity59732 : scanCanonicalize (H12AffineFastState.compose env59732 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 23) := by decide +kernel

theorem selectedBound59732 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59733 : List Nat := [2,4,8,16,18,17,128,158,1,23,19,18,9,19,19,2,154,152,22,19,1,1,16,2,129,16,17,18,155,137,5,18,158,136,154,0]

theorem envBound59733 : H12AffineFastState.Bounded env59733 := by
  intro p hp
  have h : env59733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59732_59733 : H12AffineEnvironment.transform 9 23 env59732 = env59733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 23 env59732 == env59733) = true)

theorem identity59733 : scanCanonicalize (H12AffineFastState.compose env59733 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59733 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59734 : List Nat := [2,4,8,3,1,2,128,141,1,4,0,1,9,0,0,2,137,139,5,0,1,1,3,2,129,3,2,1,136,137,5,1,141,136,137,0]

theorem envBound59734 : H12AffineFastState.Bounded env59734 := by
  intro p hp
  have h : env59734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59733_59734 : H12AffineEnvironment.transform 3 3 env59733 = env59734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59733 == env59734) = true)

theorem identity59734 : scanCanonicalize (H12AffineFastState.compose env59734 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59734 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59735 : List Nat := [1,4,8,0,1,1,128,141,1,4,0,1,9,0,0,1,137,136,5,0,1,1,0,1,129,0,1,1,136,137,5,1,141,136,137,0]

theorem envBound59735 : H12AffineFastState.Bounded env59735 := by
  intro p hp
  have h : env59735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59734_59735 : H12AffineEnvironment.transform 0 1 env59734 = env59735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59734 == env59735) = true)

theorem identity59735 : scanCanonicalize (H12AffineFastState.compose env59735 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59735 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59736 : List Nat := [1,4,8,0,1,1,9,4,1,4,0,1,9,0,0,1,0,1,5,0,1,1,0,1,8,0,1,1,1,0,5,1,4,1,0,0]

theorem envBound59736 : H12AffineFastState.Bounded env59736 := by
  intro p hp
  have h : env59736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59735_59736 : H12AffineEnvironment.transform 6 9 env59735 = env59736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59735 == env59736) = true)

theorem identity59736 : scanCanonicalize (H12AffineFastState.compose env59736 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59736 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59737 : List Nat := [1,4,1,0,1,1,0,4,1,4,0,1,0,0,0,1,0,1,5,0,1,1,0,1,1,0,1,1,1,0,5,1,4,1,0,0]

theorem envBound59737 : H12AffineFastState.Bounded env59737 := by
  intro p hp
  have h : env59737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59736_59737 : H12AffineEnvironment.transform 2 1 env59736 = env59737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59736 == env59737) = true)

def env59738 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2129,65536,65798,262144,1025,2129,2097152,1416,64,3159,1288,17,2362657,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound59738 : H12AffineFastState.Bounded env59738 := by
  intro p hp
  have h : env59738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59724_59738 : H12AffineEnvironment.transform 11 1109 env59724 = env59738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env59724 == env59738) = true)

theorem identity59738 : scanCanonicalize (H12AffineFastState.compose env59738 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 68782) := by decide +kernel

theorem selectedBound59738 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59739 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2129,65536,65798,262144,1025,2129,68782,1416,64,3159,1288,17,328079,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound59739 : H12AffineFastState.Bounded env59739 := by
  intro p hp
  have h : env59739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59738_59739 : H12AffineEnvironment.transform 20 68782 env59738 = env59739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 68782 env59738 == env59739) = true)

theorem identity59739 : scanCanonicalize (H12AffineFastState.compose env59739 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3261) := by decide +kernel

theorem selectedBound59739 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59740 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1109,1409,1029,2129,65536,65798,3261,1025,2129,68782,1416,64,3159,1288,17,68914,1028,65878,66899,65543,68094,256,65674,65798,1]

theorem envBound59740 : H12AffineFastState.Bounded env59740 := by
  intro p hp
  have h : env59740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59739_59740 : H12AffineEnvironment.transform 17 3261 env59739 = env59740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3261 env59739 == env59740) = true)

theorem identity59740 : scanCanonicalize (H12AffineFastState.compose env59740 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59740 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59741 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,1109,1409,1029,1164,65536,65798,96,1025,1164,65651,1416,64,138,1288,17,66031,1028,65878,66899,65543,66851,256,65674,65798,1]

theorem envBound59741 : H12AffineFastState.Bounded env59741 := by
  intro p hp
  have h : env59741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59740_59741 : H12AffineEnvironment.transform 10 1245 env59740 = env59741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59740 == env59741) = true)

theorem identity59741 : scanCanonicalize (H12AffineFastState.compose env59741 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound59741 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59742 : List Nat := [2,4,8,16,32,64,128,256,1,409,324,460,24,412,277,65536,65798,96,408,277,65651,17,64,138,145,17,66031,413,65878,65738,65543,65722,256,65674,65798,1]

theorem envBound59742 : H12AffineFastState.Bounded env59742 := by
  intro p hp
  have h : env59742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59741_59742 : H12AffineEnvironment.transform 9 409 env59741 = env59742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env59741 == env59742) = true)

theorem identity59742 : scanCanonicalize (H12AffineFastState.compose env59742 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59742 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59743 : List Nat := [2,4,8,16,17,64,128,256,1,409,324,460,24,412,277,65536,65798,81,408,277,65602,17,64,138,145,17,66014,413,65878,65738,65543,65675,256,65674,65798,1]

theorem envBound59743 : H12AffineFastState.Bounded env59743 := by
  intro p hp
  have h : env59743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59742_59743 : H12AffineEnvironment.transform 4 17 env59742 = env59743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59742 == env59743) = true)

theorem identity59743 : scanCanonicalize (H12AffineFastState.compose env59743 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound59743 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59744 : List Nat := [2,4,8,16,17,64,128,256,1,409,324,460,24,412,277,154,412,81,408,277,216,17,64,138,145,17,324,413,460,80,157,17,256,16,412,1]

theorem envBound59744 : H12AffineFastState.Bounded env59744 := by
  intro p hp
  have h : env59744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59743_59744 : H12AffineEnvironment.transform 15 154 env59743 = env59744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env59743 == env59744) = true)

theorem identity59744 : scanCanonicalize (H12AffineFastState.compose env59744 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59744 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59745 : List Nat := [2,4,8,16,17,64,128,214,1,79,146,26,24,74,195,154,74,81,78,195,216,17,64,138,145,17,146,75,26,80,157,17,214,16,74,1]

theorem envBound59745 : H12AffineFastState.Bounded env59745 := by
  intro p hp
  have h : env59745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59744_59745 : H12AffineEnvironment.transform 7 214 env59744 = env59745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59744 == env59745) = true)

theorem identity59745 : scanCanonicalize (H12AffineFastState.compose env59745 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59745 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59746 : List Nat := [2,4,8,16,17,64,89,15,1,79,75,26,24,74,26,67,74,81,78,26,1,17,64,83,72,17,75,75,26,80,68,17,15,16,74,1]

theorem envBound59746 : H12AffineFastState.Bounded env59746 := by
  intro p hp
  have h : env59746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59745_59746 : H12AffineEnvironment.transform 6 89 env59745 = env59746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59745 == env59746) = true)

theorem identity59746 : scanCanonicalize (H12AffineFastState.compose env59746 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59746 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59747 : List Nat := [2,4,8,16,17,17,8,15,1,30,26,26,24,27,26,18,27,0,31,26,1,17,17,2,25,17,26,26,26,1,21,17,15,16,27,1]

theorem envBound59747 : H12AffineFastState.Bounded env59747 := by
  intro p hp
  have h : env59747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59746_59747 : H12AffineEnvironment.transform 5 17 env59746 = env59747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59746 == env59747) = true)

def env59748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,8388608,8399767,8397001,8388689,2366324,4177,77954,67411,8463814,8465982,256,65675,78034,8389184]

theorem envBound59748 : H12AffineFastState.Bounded env59748 := by
  intro p hp
  have h : env59748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59660_59748 : H12AffineEnvironment.transform 21 1417 env59660 = env59748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59660 == env59748) = true)

def env59749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9664,3671,1289,9617,2366324,4177,77954,67411,65542,68606,256,65675,78034,10112]

theorem envBound59749 : H12AffineFastState.Bounded env59749 := by
  intro p hp
  have h : env59749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59748_59749 : H12AffineEnvironment.transform 22 9664 env59748 = env59749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59748 == env59749) = true)

def env59750 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1289,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59750 : H12AffineFastState.Bounded env59750 := by
  intro p hp
  have h : env59750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59749_59750 : H12AffineEnvironment.transform 8 0 env59749 = env59750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59749 == env59750) = true)

theorem identity59750 : scanCanonicalize (H12AffineFastState.compose env59750 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 216) := by decide +kernel

theorem selectedBound59750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59751 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,216,1417,9664,3159,1289,9617,268716,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59751 : H12AffineFastState.Bounded env59751 := by
  intro p hp
  have h : env59751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59750_59751 : H12AffineEnvironment.transform 20 216 env59750 = env59751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 216 env59750 == env59751) = true)

def env59752 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,216,1417,64,3159,1289,17,268716,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59752 : H12AffineFastState.Bounded env59752 := by
  intro p hp
  have h : env59752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59751_59752 : H12AffineEnvironment.transform 12 1408 env59751 = env59752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59751 == env59752) = true)

theorem identity59752 : scanCanonicalize (H12AffineFastState.compose env59752 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound59752 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59753 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,262144,1025,2128,216,1417,64,3159,1289,17,268716,4177,3361,7536,6181,4573,256,6312,3441,0]

theorem envBound59753 : H12AffineFastState.Bounded env59753 := by
  intro p hp
  have h : env59753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59752_59753 : H12AffineEnvironment.transform 15 6179 env59752 = env59753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env59752 == env59753) = true)

theorem identity59753 : scanCanonicalize (H12AffineFastState.compose env59753 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6376) := by decide +kernel

theorem selectedBound59753 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59754 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2128,6179,3441,6376,1025,2128,216,1417,64,3159,1289,17,324,4177,3361,7536,6181,4573,256,6312,3441,0]

theorem envBound59754 : H12AffineFastState.Bounded env59754 := by
  intro p hp
  have h : env59754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59753_59754 : H12AffineEnvironment.transform 17 6376 env59753 = env59754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6376 env59753 == env59754) = true)

theorem identity59754 : scanCanonicalize (H12AffineFastState.compose env59754 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59754 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59755 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,460,1408,412,2128,2543,3441,2340,1025,2128,216,1417,64,3159,1289,17,324,413,3361,3260,2537,17,256,2404,3441,0]

theorem envBound59755 : H12AffineFastState.Bounded env59755 := by
  intro p hp
  have h : env59755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59754_59755 : H12AffineEnvironment.transform 11 460 env59754 = env59755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59754 == env59755) = true)

theorem identity59755 : scanCanonicalize (H12AffineFastState.compose env59755 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59755 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59756 : List Nat := [2,4,8,16,17,64,128,256,0,1024,2048,460,1408,412,2128,2526,3392,2325,1025,2128,216,1417,64,3159,1289,17,324,413,3344,3213,2520,17,256,2389,3392,0]

theorem envBound59756 : H12AffineFastState.Bounded env59756 := by
  intro p hp
  have h : env59756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59755_59756 : H12AffineEnvironment.transform 4 17 env59755 = env59756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59755 == env59756) = true)

theorem identity59756 : scanCanonicalize (H12AffineFastState.compose env59756 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59756 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59757 : List Nat := [2,4,8,16,17,64,128,256,0,1024,1245,460,1408,412,1165,1283,413,1480,1025,1165,216,1417,64,138,1289,17,324,413,461,80,1285,17,256,1416,413,0]

theorem envBound59757 : H12AffineFastState.Bounded env59757 := by
  intro p hp
  have h : env59757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59756_59757 : H12AffineEnvironment.transform 10 1245 env59756 = env59757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59756 == env59757) = true)

theorem identity59757 : scanCanonicalize (H12AffineFastState.compose env59757 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59757 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59758 : List Nat := [2,4,8,16,17,64,128,95,0,1024,1245,147,1247,195,1165,1116,194,1175,1025,1165,216,1238,64,138,1110,17,27,194,146,80,1114,17,95,1239,194,0]

theorem envBound59758 : H12AffineFastState.Bounded env59758 := by
  intro p hp
  have h : env59758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59757_59758 : H12AffineEnvironment.transform 7 95 env59757 = env59758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59757 == env59758) = true)

theorem identity59758 : scanCanonicalize (H12AffineFastState.compose env59758 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59758 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59759 : List Nat := [2,4,8,16,17,64,128,95,0,199,26,147,24,195,74,155,194,80,198,74,216,17,64,138,145,17,27,194,146,80,157,17,95,16,194,0]

theorem envBound59759 : H12AffineFastState.Bounded env59759 := by
  intro p hp
  have h : env59759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59758_59759 : H12AffineEnvironment.transform 9 199 env59758 = env59759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59758 == env59759) = true)

def env59760 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,216,1417,65,3159,1289,16,268716,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59760 : H12AffineFastState.Bounded env59760 := by
  intro p hp
  have h : env59760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59751_59760 : H12AffineEnvironment.transform 12 1409 env59751 = env59760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59751 == env59760) = true)

theorem identity59760 : scanCanonicalize (H12AffineFastState.compose env59760 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2341) := by decide +kernel

theorem selectedBound59760 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59761 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2341,1409,2421,2128,65536,68726,262144,1025,2128,216,1417,65,3159,1289,16,262281,2420,68646,66899,65542,68094,256,65675,68726,1]

theorem envBound59761 : H12AffineFastState.Bounded env59761 := by
  intro p hp
  have h : env59761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59760_59761 : H12AffineEnvironment.transform 11 2341 env59760 = env59761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2341 env59760 == env59761) = true)

theorem identity59761 : scanCanonicalize (H12AffineFastState.compose env59761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59762 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1448,65536,65934,262144,1025,1448,216,1417,65,431,1289,16,262281,1164,66014,66899,65542,66566,256,65675,65934,1]

theorem envBound59762 : H12AffineFastState.Bounded env59762 := by
  intro p hp
  have h : env59762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59761_59762 : H12AffineEnvironment.transform 10 1528 env59761 = env59762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59761 == env59762) = true)

theorem identity59762 : scanCanonicalize (H12AffineFastState.compose env59762 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound59762 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59763 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1448,65536,65934,16,1025,1448,216,1417,65,431,1289,16,153,1164,66014,66899,65542,66566,256,65675,65934,1]

theorem envBound59763 : H12AffineFastState.Bounded env59763 := by
  intro p hp
  have h : env59763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59762_59763 : H12AffineEnvironment.transform 17 16 env59762 = env59763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env59762 == env59763) = true)

theorem identity59763 : scanCanonicalize (H12AffineFastState.compose env59763 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59763 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59764 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1245,1409,1165,1448,1063,1449,16,1025,1448,216,1417,65,431,1289,16,153,1164,1529,372,1057,33,256,1196,1449,1]

theorem envBound59764 : H12AffineFastState.Bounded env59764 := by
  intro p hp
  have h : env59764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59763_59764 : H12AffineEnvironment.transform 15 1063 env59763 = env59764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59763 == env59764) = true)

theorem identity59764 : scanCanonicalize (H12AffineFastState.compose env59764 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59764 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59765 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,1245,1148,1165,1109,1063,1108,16,1025,1109,216,1140,65,82,1268,16,153,1164,1028,137,1057,33,253,1196,1108,1]

theorem envBound59765 : H12AffineFastState.Bounded env59765 := by
  intro p hp
  have h : env59765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59764_59765 : H12AffineEnvironment.transform 7 253 env59764 = env59765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59764 == env59765) = true)

theorem identity59765 : scanCanonicalize (H12AffineFastState.compose env59765 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59765 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59766 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1029,1164,1069,1165,1028,1063,1029,16,1025,1028,137,1061,16,3,1189,16,153,1164,1028,137,1057,33,172,1196,1029,1]

theorem envBound59766 : H12AffineFastState.Bounded env59766 := by
  intro p hp
  have h : env59766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59765_59766 : H12AffineEnvironment.transform 5 17 env59765 = env59766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59765 == env59766) = true)

theorem identity59766 : scanCanonicalize (H12AffineFastState.compose env59766 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 58) := by decide +kernel

theorem selectedBound59766 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59767 : List Nat := [2,4,8,16,32,17,58,22,0,1024,1029,1078,1069,1079,1028,1063,1029,16,1025,1028,51,1061,16,3,1055,16,35,1078,1028,51,1057,33,22,1046,1029,1]

theorem envBound59767 : H12AffineFastState.Bounded env59767 := by
  intro p hp
  have h : env59767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59766_59767 : H12AffineEnvironment.transform 6 58 env59766 = env59767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 58 env59766 == env59767) = true)

theorem identity59767 : scanCanonicalize (H12AffineFastState.compose env59767 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound59767 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59768 : List Nat := [2,4,8,16,32,17,58,22,0,21,16,35,56,34,17,50,16,16,20,17,51,48,16,3,10,16,35,35,17,51,52,33,22,3,16,1]

theorem envBound59768 : H12AffineFastState.Bounded env59768 := by
  intro p hp
  have h : env59768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59767_59768 : H12AffineEnvironment.transform 9 21 env59767 = env59768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env59767 == env59768) = true)

theorem identity59768 : scanCanonicalize (H12AffineFastState.compose env59768 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59768 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59769 : List Nat := [2,4,8,16,16,17,10,22,0,21,16,19,8,18,17,2,16,16,20,17,3,0,16,3,10,16,19,19,17,3,4,17,22,3,16,1]

theorem envBound59769 : H12AffineFastState.Bounded env59769 := by
  intro p hp
  have h : env59769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59768_59769 : H12AffineEnvironment.transform 4 16 env59768 = env59769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59768 == env59769) = true)

theorem identity59769 : scanCanonicalize (H12AffineFastState.compose env59769 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59769 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59770 : List Nat := [2,4,2,16,16,17,0,22,0,21,16,19,2,18,17,2,16,16,20,17,3,0,16,3,0,16,19,19,17,3,4,17,22,3,16,1]

theorem envBound59770 : H12AffineFastState.Bounded env59770 := by
  intro p hp
  have h : env59770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59769_59770 : H12AffineEnvironment.transform 2 2 env59769 = env59770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59769 == env59770) = true)

theorem identity59770 : scanCanonicalize (H12AffineFastState.compose env59770 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59771 : List Nat := [0,4,0,16,16,17,0,20,0,21,16,17,0,16,17,0,16,16,20,17,1,0,16,1,0,16,17,17,17,1,4,17,20,1,16,1]

theorem envBound59771 : H12AffineFastState.Bounded env59771 := by
  intro p hp
  have h : env59771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59770_59771 : H12AffineEnvironment.transform 0 0 env59770 = env59771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59770 == env59771) = true)

theorem identity59771 : scanCanonicalize (H12AffineFastState.compose env59771 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59771 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59772 : List Nat := [0,4,0,0,0,1,0,4,0,5,0,1,0,0,1,0,0,0,4,1,1,0,0,1,0,0,1,1,1,1,4,1,4,1,0,1]

theorem envBound59772 : H12AffineFastState.Bounded env59772 := by
  intro p hp
  have h : env59772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59771_59772 : H12AffineEnvironment.transform 3 0 env59771 = env59772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59771 == env59772) = true)

def env59773 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1289,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59773 : H12AffineFastState.Bounded env59773 := by
  intro p hp
  have h : env59773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59749_59773 : H12AffineEnvironment.transform 8 1 env59749 = env59773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59749 == env59773) = true)

theorem identity59773 : scanCanonicalize (H12AffineFastState.compose env59773 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 9561) := by decide +kernel

theorem selectedBound59773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59774 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,9561,1417,9664,3158,1289,9617,277548,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59774 : H12AffineFastState.Bounded env59774 := by
  intro p hp
  have h : env59774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59773_59774 : H12AffineEnvironment.transform 20 9561 env59773 = env59774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 9561 env59773 == env59774) = true)

def env59775 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,217,1417,64,3158,1289,17,268716,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59775 : H12AffineFastState.Bounded env59775 := by
  intro p hp
  have h : env59775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59774_59775 : H12AffineEnvironment.transform 12 1408 env59774 = env59775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59774 == env59775) = true)

theorem identity59775 : scanCanonicalize (H12AffineFastState.compose env59775 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 6179) := by decide +kernel

theorem selectedBound59775 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59776 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,262144,1025,2129,217,1417,64,3158,1289,17,268716,4177,3361,7537,6181,4572,256,6312,3441,1]

theorem envBound59776 : H12AffineFastState.Bounded env59776 := by
  intro p hp
  have h : env59776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59775_59776 : H12AffineEnvironment.transform 15 6179 env59775 = env59776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6179 env59775 == env59776) = true)

theorem identity59776 : scanCanonicalize (H12AffineFastState.compose env59776 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 6377) := by decide +kernel

theorem selectedBound59776 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59777 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2129,6179,3441,6377,1025,2129,217,1417,64,3158,1289,17,325,4177,3361,7537,6181,4572,256,6312,3441,1]

theorem envBound59777 : H12AffineFastState.Bounded env59777 := by
  intro p hp
  have h : env59777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59776_59777 : H12AffineEnvironment.transform 17 6377 env59776 = env59777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6377 env59776 == env59777) = true)

theorem identity59777 : scanCanonicalize (H12AffineFastState.compose env59777 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59777 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59778 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,461,1408,413,2129,2542,3441,2340,1025,2129,217,1417,64,3158,1289,17,325,412,3361,3260,2536,17,256,2405,3441,1]

theorem envBound59778 : H12AffineFastState.Bounded env59778 := by
  intro p hp
  have h : env59778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59777_59778 : H12AffineEnvironment.transform 11 461 env59777 = env59778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59777 == env59778) = true)

theorem identity59778 : scanCanonicalize (H12AffineFastState.compose env59778 (packedSelected [4,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1261) := by decide +kernel

theorem selectedBound59778 : packedSelected [4,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59779 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1261,461,1408,413,1212,1283,412,1481,1025,1212,217,1417,64,187,1289,17,325,412,460,81,1285,17,256,1416,412,1]

theorem envBound59779 : H12AffineFastState.Bounded env59779 := by
  intro p hp
  have h : env59779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59778_59779 : H12AffineEnvironment.transform 10 1261 env59778 = env59779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1261 env59778 == env59779) = true)

theorem identity59779 : scanCanonicalize (H12AffineFastState.compose env59779 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59779 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59780 : List Nat := [2,4,8,16,17,64,128,256,1,1024,1244,461,1408,413,1165,1283,412,1481,1025,1165,217,1417,64,138,1289,17,325,412,460,81,1285,17,256,1416,412,1]

theorem envBound59780 : H12AffineFastState.Bounded env59780 := by
  intro p hp
  have h : env59780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59779_59780 : H12AffineEnvironment.transform 4 17 env59779 = env59780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59779 == env59780) = true)

theorem identity59780 : scanCanonicalize (H12AffineFastState.compose env59780 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound59780 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59781 : List Nat := [2,4,8,16,17,64,128,95,1,1024,1244,146,1247,194,1165,1116,195,1174,1025,1165,217,1238,64,138,1110,17,26,195,147,81,1114,17,95,1239,195,1]

theorem envBound59781 : H12AffineFastState.Bounded env59781 := by
  intro p hp
  have h : env59781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59780_59781 : H12AffineEnvironment.transform 7 95 env59780 = env59781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env59780 == env59781) = true)

theorem identity59781 : scanCanonicalize (H12AffineFastState.compose env59781 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound59781 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59782 : List Nat := [2,4,8,16,17,64,128,95,1,199,27,146,24,194,74,155,195,81,198,74,217,17,64,138,145,17,26,195,147,81,157,17,95,16,195,1]

theorem envBound59782 : H12AffineFastState.Bounded env59782 := by
  intro p hp
  have h : env59782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59781_59782 : H12AffineEnvironment.transform 9 199 env59781 = env59782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env59781 == env59782) = true)

def env59783 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,216,1417,65,3158,1289,16,268717,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59783 : H12AffineFastState.Bounded env59783 := by
  intro p hp
  have h : env59783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59774_59783 : H12AffineEnvironment.transform 12 1409 env59774 = env59783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59774 == env59783) = true)

theorem identity59783 : scanCanonicalize (H12AffineFastState.compose env59783 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2340) := by decide +kernel

theorem selectedBound59783 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59784 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2340,1409,2420,2129,65536,68727,262144,1025,2129,216,1417,65,3158,1289,16,262281,2421,68647,66898,65542,68095,256,65675,68727,0]

theorem envBound59784 : H12AffineFastState.Bounded env59784 := by
  intro p hp
  have h : env59784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59783_59784 : H12AffineEnvironment.transform 11 2340 env59783 = env59784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2340 env59783 == env59784) = true)

theorem identity59784 : scanCanonicalize (H12AffineFastState.compose env59784 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59784 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59785 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1448,65536,65934,262144,1025,1448,216,1417,65,431,1289,16,262281,1164,66014,66898,65542,66566,256,65675,65934,0]

theorem envBound59785 : H12AffineFastState.Bounded env59785 := by
  intro p hp
  have h : env59785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59784_59785 : H12AffineEnvironment.transform 10 1529 env59784 = env59785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59784 == env59785) = true)

theorem identity59785 : scanCanonicalize (H12AffineFastState.compose env59785 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound59785 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59786 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1448,65536,65934,16,1025,1448,216,1417,65,431,1289,16,153,1164,66014,66898,65542,66566,256,65675,65934,0]

theorem envBound59786 : H12AffineFastState.Bounded env59786 := by
  intro p hp
  have h : env59786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59785_59786 : H12AffineEnvironment.transform 17 16 env59785 = env59786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env59785 == env59786) = true)

theorem identity59786 : scanCanonicalize (H12AffineFastState.compose env59786 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59786 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59787 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1245,1409,1165,1448,1063,1449,16,1025,1448,216,1417,65,431,1289,16,153,1164,1529,373,1057,33,256,1196,1449,0]

theorem envBound59787 : H12AffineFastState.Bounded env59787 := by
  intro p hp
  have h : env59787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59786_59787 : H12AffineEnvironment.transform 15 1063 env59786 = env59787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59786 == env59787) = true)

theorem identity59787 : scanCanonicalize (H12AffineFastState.compose env59787 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59787 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59788 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,1245,1149,1165,1108,1063,1109,16,1025,1108,216,1141,65,83,1269,16,153,1164,1029,137,1057,33,252,1196,1109,0]

theorem envBound59788 : H12AffineFastState.Bounded env59788 := by
  intro p hp
  have h : env59788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59787_59788 : H12AffineEnvironment.transform 7 252 env59787 = env59788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59787 == env59788) = true)

theorem identity59788 : scanCanonicalize (H12AffineFastState.compose env59788 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59788 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59789 : List Nat := [2,4,8,16,32,64,128,252,1,141,136,80,240,0,217,170,216,16,140,217,216,248,65,83,120,16,153,1,136,137,172,33,252,33,216,0]

theorem envBound59789 : H12AffineFastState.Bounded env59789 := by
  intro p hp
  have h : env59789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59788_59789 : H12AffineEnvironment.transform 9 141 env59788 = env59789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59788 == env59789) = true)

theorem identity59789 : scanCanonicalize (H12AffineFastState.compose env59789 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59789 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59790 : List Nat := [2,4,8,16,16,64,128,204,1,141,136,80,192,0,217,154,216,16,140,217,216,200,65,83,72,16,153,1,136,137,156,17,204,17,216,0]

theorem envBound59790 : H12AffineFastState.Bounded env59790 := by
  intro p hp
  have h : env59790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59789_59790 : H12AffineEnvironment.transform 4 16 env59789 = env59790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59789 == env59790) = true)

theorem identity59790 : scanCanonicalize (H12AffineFastState.compose env59790 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 74) := by decide +kernel

theorem selectedBound59790 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59791 : List Nat := [2,4,8,16,16,64,74,6,1,71,66,80,10,0,19,80,18,16,70,19,18,2,65,83,72,16,83,1,66,67,86,17,6,17,18,0]

theorem envBound59791 : H12AffineFastState.Bounded env59791 := by
  intro p hp
  have h : env59791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59790_59791 : H12AffineEnvironment.transform 6 74 env59790 = env59791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 74 env59790 == env59791) = true)

theorem identity59791 : scanCanonicalize (H12AffineFastState.compose env59791 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59791 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59792 : List Nat := [2,4,8,9,9,64,74,6,1,71,66,73,10,0,10,73,11,9,70,10,11,2,65,74,72,9,74,1,66,67,79,8,6,8,11,0]

theorem envBound59792 : H12AffineFastState.Bounded env59792 := by
  intro p hp
  have h : env59792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59791_59792 : H12AffineEnvironment.transform 3 9 env59791 = env59792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59791 == env59792) = true)

theorem identity59792 : scanCanonicalize (H12AffineFastState.compose env59792 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59792 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59793 : List Nat := [2,4,2,3,3,64,64,6,1,71,66,67,0,0,0,67,1,3,70,0,1,2,65,64,66,3,64,1,66,67,69,2,6,2,1,0]

theorem envBound59793 : H12AffineFastState.Bounded env59793 := by
  intro p hp
  have h : env59793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59792_59793 : H12AffineEnvironment.transform 2 2 env59792 = env59793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59792 == env59793) = true)

theorem identity59793 : scanCanonicalize (H12AffineFastState.compose env59793 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59794 : List Nat := [1,4,1,0,0,64,64,5,1,68,65,64,0,0,0,64,1,0,69,0,1,1,65,64,65,0,64,1,65,64,69,1,5,1,1,0]

theorem envBound59794 : H12AffineFastState.Bounded env59794 := by
  intro p hp
  have h : env59794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59793_59794 : H12AffineEnvironment.transform 0 1 env59793 = env59794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59793 == env59794) = true)

theorem identity59794 : scanCanonicalize (H12AffineFastState.compose env59794 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59794 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59795 : List Nat := [1,4,1,0,0,1,1,5,1,5,0,1,0,0,0,1,1,0,4,0,1,1,0,1,0,0,1,1,0,1,4,1,5,1,1,0]

theorem envBound59795 : H12AffineFastState.Bounded env59795 := by
  intro p hp
  have h : env59795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59794_59795 : H12AffineEnvironment.transform 5 1 env59794 = env59795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59794 == env59795) = true)

def env59796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2640,65536,78034,262144,1025,2640,2097152,1417,9665,3670,1288,9616,2366324,4177,77954,67411,65543,68607,256,65675,78034,10113]

theorem envBound59796 : H12AffineFastState.Bounded env59796 := by
  intro p hp
  have h : env59796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59748_59796 : H12AffineEnvironment.transform 22 9665 env59748 = env59796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59748 == env59796) = true)

def env59797 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1288,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound59797 : H12AffineFastState.Bounded env59797 := by
  intro p hp
  have h : env59797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59796_59797 : H12AffineEnvironment.transform 8 0 env59796 = env59797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59796 == env59797) = true)

theorem identity59797 : scanCanonicalize (H12AffineFastState.compose env59797 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 7433) := by decide +kernel

theorem selectedBound59797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59798 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,7433,4176,2128,65536,69083,262144,1025,2128,2097152,1417,6344,3158,1288,6297,2365812,4177,69003,66899,65543,68095,256,65675,69083,6280]

theorem envBound59798 : H12AffineFastState.Bounded env59798 := by
  intro p hp
  have h : env59798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59797_59798 : H12AffineEnvironment.transform 12 7433 env59797 = env59798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7433 env59797 == env59798) = true)

def env59799 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,2097152,1417,64,3158,1288,17,2359804,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound59799 : H12AffineFastState.Bounded env59799 := by
  intro p hp
  have h : env59799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59798_59799 : H12AffineEnvironment.transform 11 2184 env59798 = env59799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env59798 == env59799) = true)

theorem identity59799 : scanCanonicalize (H12AffineFastState.compose env59799 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65650) := by decide +kernel

theorem selectedBound59799 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59800 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,262144,1025,2128,65650,1417,64,3158,1288,17,328078,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound59800 : H12AffineFastState.Bounded env59800 := by
  intro p hp
  have h : env59800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59799_59800 : H12AffineEnvironment.transform 20 65650 env59799 = env59800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65650 env59799 == env59800) = true)

theorem identity59800 : scanCanonicalize (H12AffineFastState.compose env59800 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 96) := by decide +kernel

theorem selectedBound59800 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59801 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2184,1409,2264,2128,65536,69083,96,1025,2128,65650,1417,64,3158,1288,17,66030,2265,69003,66899,65543,68095,256,65675,69083,0]

theorem envBound59801 : H12AffineFastState.Bounded env59801 := by
  intro p hp
  have h : env59801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59800_59801 : H12AffineEnvironment.transform 17 96 env59800 = env59801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96 env59800 == env59801) = true)

theorem identity59801 : scanCanonicalize (H12AffineFastState.compose env59801 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59801 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59802 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1244,1108,1409,1028,1164,65536,65799,96,1025,1164,65650,1417,64,138,1288,17,66030,1029,65879,66899,65543,66851,256,65675,65799,0]

theorem envBound59802 : H12AffineFastState.Bounded env59802 := by
  intro p hp
  have h : env59802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59801_59802 : H12AffineEnvironment.transform 10 1244 env59801 = env59802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59801 == env59802) = true)

theorem identity59802 : scanCanonicalize (H12AffineFastState.compose env59802 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59802 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59803 : List Nat := [2,4,8,16,32,64,128,256,0,408,324,460,25,412,276,65536,65799,96,409,276,65650,17,64,138,144,17,66030,413,65879,65739,65543,65723,256,65675,65799,0]

theorem envBound59803 : H12AffineFastState.Bounded env59803 := by
  intro p hp
  have h : env59803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59802_59803 : H12AffineEnvironment.transform 9 408 env59802 = env59803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59802 == env59803) = true)

theorem identity59803 : scanCanonicalize (H12AffineFastState.compose env59803 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59803 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59804 : List Nat := [2,4,8,16,17,64,128,256,0,408,324,460,25,412,276,65536,65799,81,409,276,65603,17,64,138,144,17,66015,413,65879,65739,65543,65674,256,65675,65799,0]

theorem envBound59804 : H12AffineFastState.Bounded env59804 := by
  intro p hp
  have h : env59804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59803_59804 : H12AffineEnvironment.transform 4 17 env59803 = env59804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59803 == env59804) = true)

theorem identity59804 : scanCanonicalize (H12AffineFastState.compose env59804 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59804 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59805 : List Nat := [2,4,8,16,17,64,128,256,0,408,324,460,25,412,276,155,412,81,409,276,216,17,64,138,144,17,324,413,460,80,156,17,256,16,412,0]

theorem envBound59805 : H12AffineFastState.Bounded env59805 := by
  intro p hp
  have h : env59805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59804_59805 : H12AffineEnvironment.transform 15 155 env59804 = env59805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59804 == env59805) = true)

theorem identity59805 : scanCanonicalize (H12AffineFastState.compose env59805 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound59805 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59806 : List Nat := [2,4,8,16,17,64,128,215,0,79,147,27,25,75,195,155,75,81,78,195,216,17,64,138,144,17,147,74,27,80,156,17,215,16,75,0]

theorem envBound59806 : H12AffineFastState.Bounded env59806 := by
  intro p hp
  have h : env59806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59805_59806 : H12AffineEnvironment.transform 7 215 env59805 = env59806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env59805 == env59806) = true)

def env59807 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,2097152,1417,65,3158,1288,16,2359805,2264,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound59807 : H12AffineFastState.Bounded env59807 := by
  intro p hp
  have h : env59807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59798_59807 : H12AffineEnvironment.transform 11 2185 env59798 = env59807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59798 == env59807) = true)

theorem identity59807 : scanCanonicalize (H12AffineFastState.compose env59807 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound59807 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59808 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,2185,1408,2265,2128,65536,69083,262144,1025,2128,372,1417,65,3158,1288,16,262281,2264,69003,66899,65543,68095,256,65675,69083,1]

theorem envBound59808 : H12AffineFastState.Bounded env59808 := by
  intro p hp
  have h : env59808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59807_59808 : H12AffineEnvironment.transform 20 372 env59807 = env59808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env59807 == env59808) = true)

theorem identity59808 : scanCanonicalize (H12AffineFastState.compose env59808 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59808 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59809 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1448,65536,65571,262144,1025,1448,372,1417,65,430,1288,16,262281,1312,65651,66899,65543,66567,256,65675,65571,1]

theorem envBound59809 : H12AffineFastState.Bounded env59809 := by
  intro p hp
  have h : env59809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59808_59809 : H12AffineEnvironment.transform 10 1528 env59808 = env59809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59808 == env59809) = true)

theorem identity59809 : scanCanonicalize (H12AffineFastState.compose env59809 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 445) := by decide +kernel

theorem selectedBound59809 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59810 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1448,65536,65571,445,1025,1448,372,1417,65,430,1288,16,308,1312,65651,66899,65543,66567,256,65675,65571,1]

theorem envBound59810 : H12AffineFastState.Bounded env59810 := by
  intro p hp
  have h : env59810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59809_59810 : H12AffineEnvironment.transform 17 445 env59809 = env59810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 445 env59809 == env59810) = true)

theorem identity59810 : scanCanonicalize (H12AffineFastState.compose env59810 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59810 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59811 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1393,1408,1313,1448,1063,1028,445,1025,1448,372,1417,65,430,1288,16,308,1312,1108,372,1056,32,256,1196,1028,1]

theorem envBound59811 : H12AffineFastState.Bounded env59811 := by
  intro p hp
  have h : env59811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59810_59811 : H12AffineEnvironment.transform 15 1063 env59810 = env59811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59810 == env59811) = true)

theorem identity59811 : scanCanonicalize (H12AffineFastState.compose env59811 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59811 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59812 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,1165,1148,1245,1108,1063,1028,65,1025,1108,136,1141,65,82,1268,16,200,1244,1108,136,1056,32,252,1196,1028,1]

theorem envBound59812 : H12AffineFastState.Bounded env59812 := by
  intro p hp
  have h : env59812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59811_59812 : H12AffineEnvironment.transform 7 252 env59811 = env59812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59811 == env59812) = true)

theorem identity59812 : scanCanonicalize (H12AffineFastState.compose env59812 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59812 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59813 : List Nat := [2,4,8,16,32,64,128,252,0,140,136,1,240,81,216,171,136,65,141,216,136,249,65,82,120,16,200,80,216,136,172,32,252,32,136,1]

theorem envBound59813 : H12AffineFastState.Bounded env59813 := by
  intro p hp
  have h : env59813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59812_59813 : H12AffineEnvironment.transform 9 140 env59812 = env59813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59812 == env59813) = true)

theorem identity59813 : scanCanonicalize (H12AffineFastState.compose env59813 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound59813 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59814 : List Nat := [2,4,8,16,32,64,73,53,0,69,65,1,57,81,17,98,65,65,68,17,65,48,65,82,120,16,1,80,17,65,101,32,53,32,65,1]

theorem envBound59814 : H12AffineFastState.Bounded env59814 := by
  intro p hp
  have h : env59814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59813_59814 : H12AffineEnvironment.transform 6 73 env59813 = env59814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env59813 == env59814) = true)

theorem identity59814 : scanCanonicalize (H12AffineFastState.compose env59814 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59814 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59815 : List Nat := [2,4,8,16,0,64,73,21,0,69,65,1,25,81,17,66,65,65,68,17,65,16,65,82,88,16,1,80,17,65,69,0,21,0,65,1]

theorem envBound59815 : H12AffineFastState.Bounded env59815 := by
  intro p hp
  have h : env59815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59814_59815 : H12AffineEnvironment.transform 4 0 env59814 = env59815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59814 == env59815) = true)

theorem identity59815 : scanCanonicalize (H12AffineFastState.compose env59815 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound59815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59816 : List Nat := [2,4,8,16,0,3,10,21,0,6,2,1,25,18,17,1,2,2,7,17,2,16,2,17,27,16,1,19,17,2,6,0,21,0,2,1]

theorem envBound59816 : H12AffineFastState.Bounded env59816 := by
  intro p hp
  have h : env59816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59815_59816 : H12AffineEnvironment.transform 5 3 env59815 = env59816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env59815 == env59816) = true)

theorem identity59816 : scanCanonicalize (H12AffineFastState.compose env59816 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound59816 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59817 : List Nat := [2,4,8,9,0,3,10,12,0,6,2,1,0,11,8,1,2,2,7,8,2,9,2,8,2,9,1,10,8,2,6,0,12,0,2,1]

theorem envBound59817 : H12AffineFastState.Bounded env59817 := by
  intro p hp
  have h : env59817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59816_59817 : H12AffineEnvironment.transform 3 9 env59816 = env59817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env59816 == env59817) = true)

theorem identity59817 : scanCanonicalize (H12AffineFastState.compose env59817 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59817 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59818 : List Nat := [0,4,8,9,0,1,8,12,0,4,0,1,0,9,8,1,0,0,5,8,0,9,0,8,0,9,1,8,8,0,4,0,12,0,0,1]

theorem envBound59818 : H12AffineFastState.Bounded env59818 := by
  intro p hp
  have h : env59818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59817_59818 : H12AffineEnvironment.transform 0 0 env59817 = env59818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59817 == env59818) = true)

def env59819 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59819 : H12AffineFastState.Bounded env59819 := by
  intro p hp
  have h : env59819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59796_59819 : H12AffineEnvironment.transform 8 1 env59796 = env59819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59796 == env59819) = true)

theorem identity59819 : scanCanonicalize (H12AffineFastState.compose env59819 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound59819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59820 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,8192,2264,2129,65536,75866,262144,1025,2129,2097152,1417,9665,3159,1288,9616,2359805,2265,75786,66898,65543,68094,256,65675,75866,9600]

theorem envBound59820 : H12AffineFastState.Bounded env59820 := by
  intro p hp
  have h : env59820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59819_59820 : H12AffineEnvironment.transform 11 2184 env59819 = env59820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env59819 == env59820) = true)

def env59821 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1408,2264,2129,65536,69082,262144,1025,2129,2097152,1417,65,3159,1288,16,2359805,2265,69002,66898,65543,68094,256,65675,69082,0]

theorem envBound59821 : H12AffineFastState.Bounded env59821 := by
  intro p hp
  have h : env59821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59820_59821 : H12AffineEnvironment.transform 12 1408 env59820 = env59821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59820 == env59821) = true)

theorem identity59821 : scanCanonicalize (H12AffineFastState.compose env59821 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 372) := by decide +kernel

theorem selectedBound59821 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59822 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1408,2264,2129,65536,69082,262144,1025,2129,372,1417,65,3159,1288,16,262281,2265,69002,66898,65543,68094,256,65675,69082,0]

theorem envBound59822 : H12AffineFastState.Bounded env59822 := by
  intro p hp
  have h : env59822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59821_59822 : H12AffineEnvironment.transform 20 372 env59821 = env59822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 372 env59821 == env59822) = true)

theorem identity59822 : scanCanonicalize (H12AffineFastState.compose env59822 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59822 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59823 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1448,65536,65571,262144,1025,1448,372,1417,65,430,1288,16,262281,1312,65651,66898,65543,66567,256,65675,65571,0]

theorem envBound59823 : H12AffineFastState.Bounded env59823 := by
  intro p hp
  have h : env59823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59822_59823 : H12AffineEnvironment.transform 10 1529 env59822 = env59823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59822 == env59823) = true)

theorem identity59823 : scanCanonicalize (H12AffineFastState.compose env59823 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 445) := by decide +kernel

theorem selectedBound59823 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59824 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1448,65536,65571,445,1025,1448,372,1417,65,430,1288,16,308,1312,65651,66898,65543,66567,256,65675,65571,0]

theorem envBound59824 : H12AffineFastState.Bounded env59824 := by
  intro p hp
  have h : env59824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59823_59824 : H12AffineEnvironment.transform 17 445 env59823 = env59824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 445 env59823 == env59824) = true)

theorem identity59824 : scanCanonicalize (H12AffineFastState.compose env59824 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1063) := by decide +kernel

theorem selectedBound59824 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59825 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1393,1408,1313,1448,1063,1028,445,1025,1448,372,1417,65,430,1288,16,308,1312,1108,373,1056,32,256,1196,1028,0]

theorem envBound59825 : H12AffineFastState.Bounded env59825 := by
  intro p hp
  have h : env59825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59824_59825 : H12AffineEnvironment.transform 15 1063 env59824 = env59825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1063 env59824 == env59825) = true)

theorem identity59825 : scanCanonicalize (H12AffineFastState.compose env59825 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59825 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59826 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,1164,1149,1244,1109,1063,1028,64,1025,1109,137,1140,65,83,1269,16,201,1245,1108,136,1056,32,253,1196,1028,0]

theorem envBound59826 : H12AffineFastState.Bounded env59826 := by
  intro p hp
  have h : env59826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59825_59826 : H12AffineEnvironment.transform 7 253 env59825 = env59826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59825 == env59826) = true)

theorem identity59826 : scanCanonicalize (H12AffineFastState.compose env59826 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59826 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59827 : List Nat := [2,4,8,16,32,17,128,172,1,1024,1028,1164,1068,1165,1028,1063,1028,17,1025,1028,137,1061,16,2,1188,16,152,1164,1029,136,1056,32,172,1196,1028,0]

theorem envBound59827 : H12AffineFastState.Bounded env59827 := by
  intro p hp
  have h : env59827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59826_59827 : H12AffineEnvironment.transform 5 17 env59826 = env59827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59826 == env59827) = true)

theorem identity59827 : scanCanonicalize (H12AffineFastState.compose env59827 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound59827 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env59828 : List Nat := [2,4,8,16,18,17,128,158,1,1024,1028,1164,1054,1165,1028,1045,1028,17,1025,1028,137,1047,16,2,1174,16,152,1164,1029,136,1042,18,158,1182,1028,0]

theorem envBound59828 : H12AffineFastState.Bounded env59828 := by
  intro p hp
  have h : env59828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59827_59828 : H12AffineEnvironment.transform 4 18 env59827 = env59828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env59827 == env59828) = true)

theorem identity59828 : scanCanonicalize (H12AffineFastState.compose env59828 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound59828 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59829 : List Nat := [2,4,8,16,18,17,128,158,1,20,16,152,10,153,16,1,16,17,21,16,137,3,16,2,130,16,152,152,17,136,6,18,158,138,16,0]

theorem envBound59829 : H12AffineFastState.Bounded env59829 := by
  intro p hp
  have h : env59829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59828_59829 : H12AffineEnvironment.transform 9 20 env59828 = env59829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env59828 == env59829) = true)

theorem identity59829 : scanCanonicalize (H12AffineFastState.compose env59829 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59829 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59830 : List Nat := [1,4,8,16,17,17,128,157,1,20,16,152,9,153,16,1,16,17,21,16,137,0,16,1,129,16,152,152,17,136,5,17,157,137,16,0]

theorem envBound59830 : H12AffineFastState.Bounded env59830 := by
  intro p hp
  have h : env59830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59829_59830 : H12AffineEnvironment.transform 0 1 env59829 = env59830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59829 == env59830) = true)

theorem identity59830 : scanCanonicalize (H12AffineFastState.compose env59830 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59830 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59831 : List Nat := [1,4,1,16,17,17,128,148,1,20,16,145,0,144,16,1,16,17,21,16,128,0,16,1,129,16,145,145,17,129,5,17,148,128,16,0]

theorem envBound59831 : H12AffineFastState.Bounded env59831 := by
  intro p hp
  have h : env59831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59830_59831 : H12AffineEnvironment.transform 2 1 env59830 = env59831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59830 == env59831) = true)

theorem identity59831 : scanCanonicalize (H12AffineFastState.compose env59831 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound59831 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59832 : List Nat := [1,4,1,16,17,17,0,20,1,20,16,17,0,16,16,1,16,17,21,16,0,0,16,1,1,16,17,17,17,1,5,17,20,0,16,0]

theorem envBound59832 : H12AffineFastState.Bounded env59832 := by
  intro p hp
  have h : env59832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59831_59832 : H12AffineEnvironment.transform 6 0 env59831 = env59832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env59831 == env59832) = true)

theorem identity59832 : scanCanonicalize (H12AffineFastState.compose env59832 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59832 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59833 : List Nat := [1,4,1,1,0,0,0,5,1,5,1,0,0,1,1,1,1,0,4,1,0,0,1,1,1,1,0,0,0,1,5,0,5,0,1,0]

theorem envBound59833 : H12AffineFastState.Bounded env59833 := by
  intro p hp
  have h : env59833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59832_59833 : H12AffineEnvironment.transform 3 1 env59832 = env59833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59832 == env59833) = true)

def env59834 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,2097152,1417,64,3159,1288,17,2359805,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound59834 : H12AffineFastState.Bounded env59834 := by
  intro p hp
  have h : env59834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59820_59834 : H12AffineEnvironment.transform 12 1409 env59820 = env59834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59820 == env59834) = true)

theorem identity59834 : scanCanonicalize (H12AffineFastState.compose env59834 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 65651) := by decide +kernel

theorem selectedBound59834 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59835 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,262144,1025,2129,65651,1417,64,3159,1288,17,328078,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound59835 : H12AffineFastState.Bounded env59835 := by
  intro p hp
  have h : env59835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59834_59835 : H12AffineEnvironment.transform 20 65651 env59834 = env59835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65651 env59834 == env59835) = true)

theorem identity59835 : scanCanonicalize (H12AffineFastState.compose env59835 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 97) := by decide +kernel

theorem selectedBound59835 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59836 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,2184,1409,2264,2129,65536,69083,97,1025,2129,65651,1417,64,3159,1288,17,66031,2265,69003,66898,65543,68094,256,65675,69083,1]

theorem envBound59836 : H12AffineFastState.Bounded env59836 := by
  intro p hp
  have h : env59836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59835_59836 : H12AffineEnvironment.transform 17 97 env59835 = env59836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97 env59835 == env59836) = true)

theorem identity59836 : scanCanonicalize (H12AffineFastState.compose env59836 (packedSelected [1,3,6,7,9,10,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound59836 : packedSelected [1,3,6,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59837 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,1109,1409,1029,1164,65536,65798,97,1025,1164,65651,1417,64,138,1288,17,66031,1028,65878,66898,65543,66851,256,65675,65798,1]

theorem envBound59837 : H12AffineFastState.Bounded env59837 := by
  intro p hp
  have h : env59837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59836_59837 : H12AffineEnvironment.transform 10 1245 env59836 = env59837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env59836 == env59837) = true)

theorem identity59837 : scanCanonicalize (H12AffineFastState.compose env59837 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound59837 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59838 : List Nat := [2,4,8,16,32,64,128,256,1,408,325,461,25,413,276,65536,65798,97,409,276,65651,17,64,138,144,17,66031,412,65878,65738,65543,65723,256,65675,65798,1]

theorem envBound59838 : H12AffineFastState.Bounded env59838 := by
  intro p hp
  have h : env59838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59837_59838 : H12AffineEnvironment.transform 9 408 env59837 = env59838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env59837 == env59838) = true)

theorem identity59838 : scanCanonicalize (H12AffineFastState.compose env59838 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59838 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59839 : List Nat := [2,4,8,16,17,64,128,256,1,408,325,461,25,413,276,65536,65798,80,409,276,65602,17,64,138,144,17,66014,412,65878,65738,65543,65674,256,65675,65798,1]

theorem envBound59839 : H12AffineFastState.Bounded env59839 := by
  intro p hp
  have h : env59839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59838_59839 : H12AffineEnvironment.transform 4 17 env59838 = env59839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59838 == env59839) = true)

theorem identity59839 : scanCanonicalize (H12AffineFastState.compose env59839 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound59839 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59840 : List Nat := [2,4,8,16,17,64,128,256,1,408,325,461,25,413,276,155,413,80,409,276,217,17,64,138,144,17,325,412,461,81,156,17,256,16,413,1]

theorem envBound59840 : H12AffineFastState.Bounded env59840 := by
  intro p hp
  have h : env59840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59839_59840 : H12AffineEnvironment.transform 15 155 env59839 = env59840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env59839 == env59840) = true)

theorem identity59840 : scanCanonicalize (H12AffineFastState.compose env59840 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 214) := by decide +kernel

theorem selectedBound59840 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59841 : List Nat := [2,4,8,16,17,64,128,214,1,78,147,27,25,75,194,155,75,80,79,194,217,17,64,138,144,17,147,74,27,81,156,17,214,16,75,1]

theorem envBound59841 : H12AffineFastState.Bounded env59841 := by
  intro p hp
  have h : env59841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59840_59841 : H12AffineEnvironment.transform 7 214 env59840 = env59841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 214 env59840 == env59841) = true)

theorem identity59841 : scanCanonicalize (H12AffineFastState.compose env59841 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59841 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59842 : List Nat := [2,4,8,16,17,64,89,15,1,78,74,27,25,75,27,66,75,80,79,27,0,17,64,83,73,17,74,74,27,81,69,17,15,16,75,1]

theorem envBound59842 : H12AffineFastState.Bounded env59842 := by
  intro p hp
  have h : env59842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59841_59842 : H12AffineEnvironment.transform 6 89 env59841 = env59842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59841 == env59842) = true)

theorem identity59842 : scanCanonicalize (H12AffineFastState.compose env59842 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59843 : List Nat := [2,4,8,16,17,16,9,15,1,30,26,27,25,27,27,18,27,0,31,27,0,17,16,3,25,17,26,26,27,1,21,17,15,16,27,1]

theorem envBound59843 : H12AffineFastState.Bounded env59843 := by
  intro p hp
  have h : env59843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59842_59843 : H12AffineEnvironment.transform 5 16 env59842 = env59843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59842 == env59843) = true)

def env59844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,33554432,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,33563273]

theorem envBound59844 : H12AffineFastState.Bounded env59844 := by
  intro p hp
  have h : env59844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59108_59844 : H12AffineEnvironment.transform 14 2641 env59108 = env59844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2641 env59108 == env59844) = true)

def env59845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397000,8388689,134217728,4177,77954,4260571,8463814,149237955,256,136649726,78034,8389185]

theorem envBound59845 : H12AffineFastState.Bounded env59845 := by
  intro p hp
  have h : env59845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59844_59845 : H12AffineEnvironment.transform 24 8397000 env59844 = env59845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8397000 env59844 == env59845) = true)

def env59846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397000,8388689,6561532,4177,77954,4260571,8463814,8465983,256,4261122,78034,8389185]

theorem envBound59846 : H12AffineFastState.Bounded env59846 := by
  intro p hp
  have h : env59846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59845_59846 : H12AffineEnvironment.transform 26 6561532 env59845 = env59846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561532 env59845 == env59846) = true)

def env59847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399766,8397000,8388689,2366324,4177,77954,67411,8463814,8465983,256,65674,78034,8389185]

theorem envBound59847 : H12AffineFastState.Bounded env59847 := by
  intro p hp
  have h : env59847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59846_59847 : H12AffineEnvironment.transform 21 1416 env59846 = env59847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env59846 == env59847) = true)

def env59848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3670,1288,9617,2366324,4177,77954,67411,65542,68607,256,65674,78034,10113]

theorem envBound59848 : H12AffineFastState.Bounded env59848 := by
  intro p hp
  have h : env59848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59847_59848 : H12AffineEnvironment.transform 22 9664 env59847 = env59848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59847 == env59848) = true)

def env59849 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1288,9617,2365812,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59849 : H12AffineFastState.Bounded env59849 := by
  intro p hp
  have h : env59849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59848_59849 : H12AffineEnvironment.transform 8 0 env59848 = env59849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59848 == env59849) = true)

theorem identity59849 : scanCanonicalize (H12AffineFastState.compose env59849 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59850 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,1028,1416,9664,3158,1288,9617,269680,4177,77954,66899,65542,68095,256,65674,78034,9601]

theorem envBound59850 : H12AffineFastState.Bounded env59850 := by
  intro p hp
  have h : env59850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59849_59850 : H12AffineEnvironment.transform 20 1028 env59849 = env59850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1028 env59849 == env59850) = true)

def env59851 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,1028,1416,64,3158,1288,17,269680,4177,70914,66899,65542,68095,256,65674,70994,1]

theorem envBound59851 : H12AffineFastState.Bounded env59851 := by
  intro p hp
  have h : env59851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59850_59851 : H12AffineEnvironment.transform 12 1408 env59850 = env59851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59850 == env59851) = true)

theorem identity59851 : scanCanonicalize (H12AffineFastState.compose env59851 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3577) := by decide +kernel

theorem selectedBound59851 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59852 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3577,1408,3497,2129,65536,67755,262144,1025,2129,1028,1416,64,3158,1288,17,262281,3496,67835,66899,65542,68095,256,65674,67755,1]

theorem envBound59852 : H12AffineFastState.Bounded env59852 := by
  intro p hp
  have h : env59852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59851_59852 : H12AffineEnvironment.transform 11 3577 env59851 = env59852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3577 env59851 == env59852) = true)

theorem identity59852 : scanCanonicalize (H12AffineFastState.compose env59852 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59852 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59853 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1448,65536,66898,262144,1025,1448,1028,1416,64,431,1288,17,262281,81,66818,66899,65542,66566,256,65674,66898,1]

theorem envBound59853 : H12AffineFastState.Bounded env59853 := by
  intro p hp
  have h : env59853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59852_59853 : H12AffineEnvironment.transform 10 1529 env59852 = env59853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59852 == env59853) = true)

theorem identity59853 : scanCanonicalize (H12AffineFastState.compose env59853 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66799) := by decide +kernel

theorem selectedBound59853 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59854 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1448,65536,66898,66799,1025,1448,1028,1416,64,431,1288,17,66662,81,66818,66899,65542,66566,256,65674,66898,1]

theorem envBound59854 : H12AffineFastState.Bounded env59854 := by
  intro p hp
  have h : env59854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59853_59854 : H12AffineEnvironment.transform 17 66799 env59853 = env59854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66799 env59853 == env59854) = true)

theorem identity59854 : scanCanonicalize (H12AffineFastState.compose env59854 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59854 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59855 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,0,1408,80,1448,1062,372,201,1025,1448,1028,1416,64,431,1288,17,64,81,292,373,1056,32,256,1196,372,1]

theorem envBound59855 : H12AffineFastState.Bounded env59855 := by
  intro p hp
  have h : env59855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59854_59855 : H12AffineEnvironment.transform 15 1062 env59854 = env59855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59854 == env59855) = true)

theorem identity59855 : scanCanonicalize (H12AffineFastState.compose env59855 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59855 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59856 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,0,1148,80,1108,1062,136,201,1025,1108,1028,1140,64,83,1268,17,64,81,216,137,1056,32,252,1196,136,1]

theorem envBound59856 : H12AffineFastState.Bounded env59856 := by
  intro p hp
  have h : env59856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59855_59856 : H12AffineEnvironment.transform 7 252 env59855 = env59856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59855 == env59856) = true)

theorem identity59856 : scanCanonicalize (H12AffineFastState.compose env59856 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59856 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59857 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1029,0,1069,1,1029,1062,136,152,1025,1029,1028,1061,17,2,1189,17,17,0,137,137,1056,32,173,1196,136,1]

theorem envBound59857 : H12AffineFastState.Bounded env59857 := by
  intro p hp
  have h : env59857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59856_59857 : H12AffineEnvironment.transform 5 17 env59856 = env59857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59856 == env59857) = true)

theorem identity59857 : scanCanonicalize (H12AffineFastState.compose env59857 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 39) := by decide +kernel

theorem selectedBound59857 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59858 : List Nat := [2,4,8,16,32,17,128,173,0,39,34,0,10,1,34,1,136,152,38,34,35,2,17,2,130,17,17,0,137,137,7,32,173,139,136,1]

theorem envBound59858 : H12AffineFastState.Bounded env59858 := by
  intro p hp
  have h : env59858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59857_59858 : H12AffineEnvironment.transform 9 39 env59857 = env59858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 39 env59857 == env59858) = true)

theorem identity59858 : scanCanonicalize (H12AffineFastState.compose env59858 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 59) := by decide +kernel

theorem selectedBound59858 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59859 : List Nat := [2,4,8,16,32,17,59,22,0,39,34,0,10,1,34,1,51,35,38,34,35,2,17,2,57,17,17,0,50,50,7,32,22,48,51,1]

theorem envBound59859 : H12AffineFastState.Bounded env59859 := by
  intro p hp
  have h : env59859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59858_59859 : H12AffineEnvironment.transform 6 59 env59858 = env59859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 59 env59858 == env59859) = true)

theorem identity59859 : scanCanonicalize (H12AffineFastState.compose env59859 (packedSelected [6,7] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound59859 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59860 : List Nat := [2,4,8,2,32,3,41,4,0,39,34,0,10,1,34,1,33,35,38,34,35,2,3,2,43,3,3,0,32,32,7,32,4,34,33,1]

theorem envBound59860 : H12AffineFastState.Bounded env59860 := by
  intro p hp
  have h : env59860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59859_59860 : H12AffineEnvironment.transform 3 2 env59859 = env59860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env59859 == env59860) = true)

theorem identity59860 : scanCanonicalize (H12AffineFastState.compose env59860 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59860 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59861 : List Nat := [2,4,3,2,32,3,34,4,0,39,34,0,1,1,34,1,33,35,38,34,35,2,3,2,32,3,3,0,32,32,7,32,4,34,33,1]

theorem envBound59861 : H12AffineFastState.Bounded env59861 := by
  intro p hp
  have h : env59861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59860_59861 : H12AffineEnvironment.transform 2 3 env59860 = env59861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59860 == env59861) = true)

theorem identity59861 : scanCanonicalize (H12AffineFastState.compose env59861 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59861 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59862 : List Nat := [2,4,3,2,1,3,3,4,0,6,3,0,1,1,3,1,0,2,7,3,2,2,3,2,1,3,3,0,1,1,7,1,4,3,0,1]

theorem envBound59862 : H12AffineFastState.Bounded env59862 := by
  intro p hp
  have h : env59862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59861_59862 : H12AffineEnvironment.transform 4 1 env59861 = env59862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59861 == env59862) = true)

theorem identity59862 : scanCanonicalize (H12AffineFastState.compose env59862 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59862 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59863 : List Nat := [1,4,0,1,1,0,0,4,0,5,0,0,1,1,0,1,0,1,4,0,1,1,0,1,1,0,0,0,1,1,4,1,4,0,0,1]

theorem envBound59863 : H12AffineFastState.Bounded env59863 := by
  intro p hp
  have h : env59863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59862_59863 : H12AffineEnvironment.transform 0 1 env59862 = env59863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59862 == env59863) = true)

def env59864 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,1028,1416,65,3158,1288,16,269680,4177,70915,66899,65542,68095,256,65674,70995,0]

theorem envBound59864 : H12AffineFastState.Bounded env59864 := by
  intro p hp
  have h : env59864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59850_59864 : H12AffineEnvironment.transform 12 1409 env59850 = env59864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59850 == env59864) = true)

theorem identity59864 : scanCanonicalize (H12AffineFastState.compose env59864 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59864 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59865 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,262144,1025,2129,1028,1416,65,3158,1288,16,269680,4177,2557,6573,7416,5377,256,7284,2477,0]

theorem envBound59865 : H12AffineFastState.Bounded env59865 := by
  intro p hp
  have h : env59865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59864_59865 : H12AffineEnvironment.transform 15 7422 env59864 = env59865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59864 == env59865) = true)

theorem identity59865 : scanCanonicalize (H12AffineFastState.compose env59865 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59865 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59866 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,7422,2477,3529,1025,2129,1028,1416,65,3158,1288,16,4281,4177,2557,6573,7416,5377,256,7284,2477,0]

theorem envBound59866 : H12AffineFastState.Bounded env59866 := by
  intro p hp
  have h : env59866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59865_59866 : H12AffineEnvironment.transform 17 3529 env59865 = env59866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59865 == env59866) = true)

theorem identity59866 : scanCanonicalize (H12AffineFastState.compose env59866 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59866 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59867 : List Nat := [2,4,8,16,32,64,128,256,0,1024,48,4096,1409,4176,97,5326,413,1529,1025,97,1028,1416,65,1126,1288,16,4281,4177,461,4509,5320,5377,256,5188,413,0]

theorem envBound59867 : H12AffineFastState.Bounded env59867 := by
  intro p hp
  have h : env59867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59866_59867 : H12AffineEnvironment.transform 10 48 env59866 = env59867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59866 == env59867) = true)

theorem identity59867 : scanCanonicalize (H12AffineFastState.compose env59867 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59867 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59868 : List Nat := [2,4,8,16,32,64,128,256,0,236,48,4096,365,4176,97,4130,413,277,237,97,232,356,65,138,484,16,4281,4177,461,4509,4132,4589,256,4264,413,0]

theorem envBound59868 : H12AffineFastState.Bounded env59868 := by
  intro p hp
  have h : env59868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59867_59868 : H12AffineEnvironment.transform 9 236 env59867 = env59868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59867 == env59868) = true)

theorem identity59868 : scanCanonicalize (H12AffineFastState.compose env59868 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound59868 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env59869 : List Nat := [2,4,8,16,32,64,128,256,0,236,48,461,365,413,97,495,413,277,237,97,232,356,65,138,484,16,372,412,461,80,489,32,256,357,413,0]

theorem envBound59869 : H12AffineFastState.Bounded env59869 := by
  intro p hp
  have h : env59869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59868_59869 : H12AffineEnvironment.transform 11 461 env59868 = env59869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env59868 == env59869) = true)

theorem identity59869 : scanCanonicalize (H12AffineFastState.compose env59869 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59869 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59870 : List Nat := [2,4,8,16,32,64,128,182,0,236,48,123,219,43,97,89,43,163,237,97,232,210,65,138,82,16,194,42,123,80,95,32,182,211,43,0]

theorem envBound59870 : H12AffineFastState.Bounded env59870 := by
  intro p hp
  have h : env59870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1