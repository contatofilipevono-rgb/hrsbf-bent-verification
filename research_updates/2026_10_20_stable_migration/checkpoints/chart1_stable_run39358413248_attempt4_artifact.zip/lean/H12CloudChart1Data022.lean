import H12CloudChart1Data021

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env5444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46528,493,41003,8329,445,323792,16384,16892,22641,74795,17681,256,20560,1344,512]

theorem envBound5444 : H12AffineFastState.Bounded env5444 := by
  intro p hp
  have h : env5444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5443_5444 : H12AffineEnvironment.transform 21 46528 env5443 = env5444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46528 env5443 == env5444) = true)

theorem identity5444 : scanCanonicalize (H12AffineFastState.compose env5444 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound5444 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,32768,65536,1464,262144,1024,32768,1092,41349,493,41003,8329,445,320661,16384,16892,19508,74795,17681,256,17429,1344,512]

theorem envBound5445 : H12AffineFastState.Bounded env5445 := by
  intro p hp
  have h : env5445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5444_5445 : H12AffineEnvironment.transform 11 1093 env5444 = env5445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env5444 == env5445) = true)

theorem identity5445 : scanCanonicalize (H12AffineFastState.compose env5445 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26309) := by decide +kernel

theorem selectedBound5445 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26309,65536,1464,262144,1024,26309,1092,18240,493,18158,8329,445,262736,16384,16892,19508,74795,17681,256,17429,1344,512]

theorem envBound5446 : H12AffineFastState.Bounded env5446 := by
  intro p hp
  have h : env5446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5445_5446 : H12AffineEnvironment.transform 14 26309 env5445 = env5446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26309 env5445 == env5446) = true)

theorem identity5446 : scanCanonicalize (H12AffineFastState.compose env5446 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25798) := by decide +kernel

theorem selectedBound5446 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1093,8192,16384,26309,25798,1464,262144,1024,26309,1092,18240,493,18158,8329,445,262736,16384,16892,19508,16621,17681,256,17429,1344,512]

theorem envBound5447 : H12AffineFastState.Bounded env5447 := by
  intro p hp
  have h : env5447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5446_5447 : H12AffineEnvironment.transform 15 25798 env5446 = env5447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25798 env5446 == env5447) = true)

def env5448 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,1093,8192,16384,26173,25662,1344,262144,1024,26173,1092,18240,277,17942,8305,325,262736,16384,16644,19508,16405,17681,256,17429,1344,512]

theorem envBound5448 : H12AffineFastState.Bounded env5448 := by
  intro p hp
  have h : env5448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5447_5448 : H12AffineEnvironment.transform 6 120 env5447 = env5448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env5447 == env5448) = true)

def env5449 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,1093,8192,16384,26172,25663,1345,262144,1024,26172,1092,18240,276,17943,8304,324,262736,16384,16645,19508,16404,17681,256,17429,1344,512]

theorem envBound5449 : H12AffineFastState.Bounded env5449 := by
  intro p hp
  have h : env5449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5447_5449 : H12AffineEnvironment.transform 6 121 env5447 = env5449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env5447 == env5449) = true)

theorem identity5449 : scanCanonicalize (H12AffineFastState.compose env5449 (packedSelected [0,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5449 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env5450 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1093,8192,16384,26172,25663,1093,262144,1024,26172,1092,17988,16,17943,8304,64,262736,16384,16385,19508,16404,17429,4,17429,1092,512]

theorem envBound5450 : H12AffineFastState.Bounded env5450 := by
  intro p hp
  have h : env5450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5449_5450 : H12AffineEnvironment.transform 7 4 env5449 = env5450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5449 == env5450) = true)

theorem identity5450 : scanCanonicalize (H12AffineFastState.compose env5450 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 16411) := by decide +kernel

theorem selectedBound5450 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5451 : List Nat := [2,4,8,16,32,64,121,4,512,1024,2048,1093,8192,16384,26172,25663,1093,16411,1024,26172,1092,17988,16,17943,8304,64,16971,16384,16385,19508,16404,17429,4,17429,1092,512]

theorem envBound5451 : H12AffineFastState.Bounded env5451 := by
  intro p hp
  have h : env5451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5450_5451 : H12AffineEnvironment.transform 17 16411 env5450 = env5451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16411 env5450 == env5451) = true)

theorem identity5451 : scanCanonicalize (H12AffineFastState.compose env5451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound5451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5452 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,16384,26172,25663,1045,16411,1024,26172,1044,17940,16,17943,8224,16,16923,16384,16385,19508,16404,17429,4,17429,1044,512]

theorem envBound5452 : H12AffineFastState.Bounded env5452 := by
  intro p hp
  have h : env5452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5451_5452 : H12AffineEnvironment.transform 5 16 env5451 = env5452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5451 == env5452) = true)

theorem identity5452 : scanCanonicalize (H12AffineFastState.compose env5452 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 11805) := by decide +kernel

theorem selectedBound5452 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env5453 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1045,8192,11805,2081,2594,1045,11782,1024,2081,1044,10249,16,10250,8224,16,11270,11805,11804,8745,11785,10760,4,10760,1044,512]

theorem envBound5453 : H12AffineFastState.Bounded env5453 := by
  intro p hp
  have h : env5453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5452_5453 : H12AffineEnvironment.transform 13 11805 env5452 = env5453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11805 env5452 == env5453) = true)

theorem identity5453 : scanCanonicalize (H12AffineFastState.compose env5453 (packedSelected [0,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound5453 : packedSelected [0,2,3,12] rootPS < 2^1333 := by decide +kernel

def env5454 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1044,1045,8192,8713,1077,1590,1045,8722,1024,1077,1044,9245,16,9246,8224,16,8210,8713,8712,8745,8733,9756,4,9756,1044,512]

theorem envBound5454 : H12AffineFastState.Bounded env5454 := by
  intro p hp
  have h : env5454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5453_5454 : H12AffineEnvironment.transform 10 1044 env5453 = env5454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env5453 == env5454) = true)

theorem identity5454 : scanCanonicalize (H12AffineFastState.compose env5454 (packedSelected [0,8] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5454 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env5455 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1044,1045,1063,1582,1077,1590,1045,1589,1024,1077,1044,58,16,57,1031,16,1077,1582,1583,1550,1594,571,4,571,1044,512]

theorem envBound5455 : H12AffineFastState.Bounded env5455 := by
  intro p hp
  have h : env5455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5454_5455 : H12AffineEnvironment.transform 12 1063 env5454 = env5455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5454 == env5455) = true)

theorem identity5455 : scanCanonicalize (H12AffineFastState.compose env5455 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound5455 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env5456 : List Nat := [2,4,8,16,32,16,41,4,512,558,570,571,521,0,539,24,571,27,558,539,570,58,16,57,553,16,539,0,1,32,20,571,4,571,570,512]

theorem envBound5456 : H12AffineFastState.Bounded env5456 := by
  intro p hp
  have h : env5456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5455_5456 : H12AffineEnvironment.transform 9 558 env5455 = env5456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env5455 == env5456) = true)

theorem identity5456 : scanCanonicalize (H12AffineFastState.compose env5456 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5456 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5457 : List Nat := [2,4,8,16,1,16,8,4,512,527,539,538,521,0,539,24,538,27,527,539,539,27,16,24,520,16,539,0,1,1,20,538,4,538,539,512]

theorem envBound5457 : H12AffineFastState.Bounded env5457 := by
  intro p hp
  have h : env5457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5456_5457 : H12AffineEnvironment.transform 4 1 env5456 = env5457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5456 == env5457) = true)

theorem identity5457 : scanCanonicalize (H12AffineFastState.compose env5457 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound5457 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5458 : List Nat := [2,4,8,16,1,16,8,4,26,21,1,0,19,0,1,24,0,27,21,1,1,27,16,24,18,16,1,0,1,1,20,0,4,0,1,26]

theorem envBound5458 : H12AffineFastState.Bounded env5458 := by
  intro p hp
  have h : env5458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5457_5458 : H12AffineEnvironment.transform 8 26 env5457 = env5458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env5457 == env5458) = true)

theorem identity5458 : scanCanonicalize (H12AffineFastState.compose env5458 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5458 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5459 : List Nat := [2,4,8,10,1,10,8,4,0,15,1,0,9,0,1,2,0,1,15,1,1,1,10,2,8,10,1,0,1,1,14,0,4,0,1,0]

theorem envBound5459 : H12AffineFastState.Bounded env5459 := by
  intro p hp
  have h : env5459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5458_5459 : H12AffineEnvironment.transform 3 10 env5458 = env5459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5458 == env5459) = true)

def env5460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,46529,492,41003,8329,444,323792,16384,16892,22641,74795,17681,256,20560,1345,513]

theorem envBound5460 : H12AffineFastState.Bounded env5460 := by
  intro p hp
  have h : env5460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5443_5460 : H12AffineEnvironment.transform 21 46529 env5443 = env5460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46529 env5443 == env5460) = true)

theorem identity5460 : scanCanonicalize (H12AffineFastState.compose env5460 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound5460 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5461 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,46481,444,41003,8329,444,323712,16384,16812,22561,74795,17681,256,20480,1297,513]

theorem envBound5461 : H12AffineFastState.Bounded env5461 := by
  intro p hp
  have h : env5461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5460_5461 : H12AffineEnvironment.transform 5 16 env5460 = env5461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5460 == env5461) = true)

theorem identity5461 : scanCanonicalize (H12AffineFastState.compose env5461 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5461 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5462 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4097,46229,184,41003,8329,184,323712,16384,16552,22561,74795,17429,4,20480,1045,513]

theorem envBound5462 : H12AffineFastState.Bounded env5462 := by
  intro p hp
  have h : env5462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5461_5462 : H12AffineEnvironment.transform 7 4 env5461 = env5462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5461 == env5462) = true)

theorem identity5462 : scanCanonicalize (H12AffineFastState.compose env5462 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25663) := by decide +kernel

theorem selectedBound5462 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env5463 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4265,262144,1024,32768,4097,46229,184,41003,8329,184,323712,16384,16552,22561,16404,17429,4,20480,1045,513]

theorem envBound5463 : H12AffineFastState.Bounded env5463 := by
  intro p hp
  have h : env5463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5462_5463 : H12AffineEnvironment.transform 15 25663 env5462 = env5463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25663 env5462 == env5463) = true)

theorem identity5463 : scanCanonicalize (H12AffineFastState.compose env5463 (packedSelected [1,2,5,10,11,13,23] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound5463 : packedSelected [1,2,5,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env5464 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,25663,4265,2080,1024,32768,4097,46229,184,41003,8329,184,63648,16384,16552,22561,16404,17429,4,20480,1045,513]

theorem envBound5464 : H12AffineFastState.Bounded env5464 := by
  intro p hp
  have h : env5464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5463_5464 : H12AffineEnvironment.transform 17 2080 env5463 = env5464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env5463 == env5464) = true)

theorem identity5464 : scanCanonicalize (H12AffineFastState.compose env5464 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5464 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env5465 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,32768,25663,4097,2080,1024,32768,4097,46141,16,41003,8225,16,63496,16384,16384,22561,16404,17429,4,20480,1045,513]

theorem envBound5465 : H12AffineFastState.Bounded env5465 := by
  intro p hp
  have h : env5465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5464_5465 : H12AffineEnvironment.transform 6 40 env5464 = env5465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5464 == env5465) = true)

theorem identity5465 : scanCanonicalize (H12AffineFastState.compose env5465 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 27154) := by decide +kernel

theorem selectedBound5465 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env5466 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,4096,8192,16384,27154,25663,4097,2080,1024,27154,4097,24111,16,19001,8225,16,4634,16384,16384,22561,16404,17429,4,20480,1045,513]

theorem envBound5466 : H12AffineFastState.Bounded env5466 := by
  intro p hp
  have h : env5466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5465_5466 : H12AffineEnvironment.transform 14 27154 env5465 = env5466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27154 env5465 == env5466) = true)

theorem identity5466 : scanCanonicalize (H12AffineFastState.compose env5466 (packedSelected [1,3,5,6,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5466 : packedSelected [1,3,5,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env5467 : List Nat := [2,4,8,16,32,16,40,4,32,1024,2048,4096,8192,16384,26674,25663,4097,2080,1024,26674,4097,23567,16,18457,8225,16,4154,16384,16384,22561,16404,17429,4,20480,1045,33]

theorem envBound5467 : H12AffineFastState.Bounded env5467 := by
  intro p hp
  have h : env5467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5466_5467 : H12AffineEnvironment.transform 8 32 env5466 = env5467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5466 == env5467) = true)

theorem identity5467 : scanCanonicalize (H12AffineFastState.compose env5467 (packedSelected [5,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound5467 : packedSelected [5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env5468 : List Nat := [2,4,8,16,32,16,40,4,32,1024,2048,1044,8192,16384,26674,25663,1045,2080,1024,26674,1045,18459,16,18457,8225,16,1070,16384,16384,19509,16404,17429,4,17428,1045,33]

theorem envBound5468 : H12AffineFastState.Bounded env5468 := by
  intro p hp
  have h : env5468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5467_5468 : H12AffineEnvironment.transform 11 1044 env5467 = env5468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env5467 == env5468) = true)

def env5469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,12644668,257,20561,4239488,8389612]

theorem envBound5469 : H12AffineFastState.Bounded env5469 := by
  intro p hp
  have h : env5469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5441_5469 : H12AffineEnvironment.transform 18 1025 env5441 = env5469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5441 == env5469) = true)

theorem identity5469 : scanCanonicalize (H12AffineFastState.compose env5469 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61741) := by decide +kernel

theorem selectedBound5469 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,61741,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,8388625,257,20561,16813,8389612]

theorem envBound5470 : H12AffineFastState.Bounded env5470 := by
  intro p hp
  have h : env5470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5469_5470 : H12AffineEnvironment.transform 21 61741 env5469 = env5470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61741 env5469 == env5470) = true)

def env5471 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61741,8388608,41003,8329,8388609,323713,16384,16812,22560,74794,8388625,257,20481,16813,8389564]

theorem envBound5471 : H12AffineFastState.Bounded env5471 := by
  intro p hp
  have h : env5471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5470_5471 : H12AffineEnvironment.transform 5 16 env5470 = env5471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5470 == env5471) = true)

theorem identity5471 : scanCanonicalize (H12AffineFastState.compose env5471 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5471 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,61741,444,41003,8329,445,323713,16384,16812,22560,74794,429,257,20481,16813,512]

theorem envBound5472 : H12AffineFastState.Bounded env5472 := by
  intro p hp
  have h : env5472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5471_5472 : H12AffineEnvironment.transform 22 444 env5471 = env5472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5471 == env5472) = true)

theorem identity5472 : scanCanonicalize (H12AffineFastState.compose env5472 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound5472 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5473 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1025,32768,4097,41348,444,41003,8329,445,303144,4265,4357,2185,74794,429,257,168,4356,512]

theorem envBound5473 : H12AffineFastState.Bounded env5473 := by
  intro p hp
  have h : env5473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5472_5473 : H12AffineEnvironment.transform 13 4265 env5472 = env5473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env5472 == env5473) = true)

theorem identity5473 : scanCanonicalize (H12AffineFastState.compose env5473 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound5473 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,65536,4525,262144,1025,13884,4097,6072,444,5655,8329,445,267796,4265,4357,2185,74794,429,257,168,4356,512]

theorem envBound5474 : H12AffineFastState.Bounded env5474 := by
  intro p hp
  have h : env5474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5473_5474 : H12AffineEnvironment.transform 14 13884 env5473 = env5474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env5473 == env5474) = true)

theorem identity5474 : scanCanonicalize (H12AffineFastState.compose env5474 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound5474 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8234,4525,262144,1025,13884,4097,6072,444,5655,8329,445,267796,4265,4357,2185,1024,429,257,168,4356,512]

theorem envBound5475 : H12AffineFastState.Bounded env5475 := by
  intro p hp
  have h : env5475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5474_5475 : H12AffineEnvironment.transform 15 8234 env5474 = env5475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env5474 == env5475) = true)

theorem identity5475 : scanCanonicalize (H12AffineFastState.compose env5475 (packedSelected [0,1,5,8,18,23,24,27] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5475 : packedSelected [0,1,5,8,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env5476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8234,4525,2081,1025,13884,4097,6072,444,5655,8329,445,7733,4265,4357,2185,1024,429,257,168,4356,512]

theorem envBound5476 : H12AffineFastState.Bounded env5476 := by
  intro p hp
  have h : env5476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5475_5476 : H12AffineEnvironment.transform 17 2081 env5475 = env5476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5475 == env5476) = true)

theorem identity5476 : scanCanonicalize (H12AffineFastState.compose env5476 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1802) := by decide +kernel

theorem selectedBound5476 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env5477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1802,8192,1955,8502,8234,1703,2081,1025,8502,1803,178,444,285,8329,445,2367,1955,1551,2185,1024,429,257,168,1550,512]

theorem envBound5477 : H12AffineFastState.Bounded env5477 := by
  intro p hp
  have h : env5477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5476_5477 : H12AffineEnvironment.transform 11 1802 env5476 = env5477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1802 env5476 == env5477) = true)

theorem identity5477 : scanCanonicalize (H12AffineFastState.compose env5477 (packedSelected [0,4,7,9,13,17,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5477 : packedSelected [0,4,7,9,13,17,18,23] rootPS < 2^1333 := by decide +kernel

def env5478 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1802,8192,1803,8502,8234,1551,2081,1025,8502,1803,26,276,285,8225,277,2367,1803,1551,2081,1024,261,257,0,1550,512]

theorem envBound5478 : H12AffineFastState.Bounded env5478 := by
  intro p hp
  have h : env5478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5477_5478 : H12AffineEnvironment.transform 6 40 env5477 = env5478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5477 == env5478) = true)

theorem identity5478 : scanCanonicalize (H12AffineFastState.compose env5478 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound5478 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5479 : List Nat := [2,4,8,16,32,16,40,62,512,1024,2048,1588,8192,1589,8200,8234,1551,2081,1025,8200,1589,26,42,35,8225,43,2049,1589,1551,2081,1024,59,63,0,1550,512]

theorem envBound5479 : H12AffineFastState.Bounded env5479 := by
  intro p hp
  have h : env5479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5478_5479 : H12AffineEnvironment.transform 7 62 env5478 = env5479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env5478 == env5479) = true)

theorem identity5479 : scanCanonicalize (H12AffineFastState.compose env5479 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound5479 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env5480 : List Nat := [2,4,8,16,32,16,40,62,512,1024,2048,1588,51,1589,59,25,1551,2081,1025,59,1589,26,42,35,18,43,2049,1589,1551,2081,1024,59,63,0,1550,512]

theorem envBound5480 : H12AffineFastState.Bounded env5480 := by
  intro p hp
  have h : env5480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5479_5480 : H12AffineEnvironment.transform 12 51 env5479 = env5480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env5479 == env5480) = true)

theorem identity5480 : scanCanonicalize (H12AffineFastState.compose env5480 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 570) := by decide +kernel

theorem selectedBound5480 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env5481 : List Nat := [2,4,8,16,32,16,40,62,512,1024,570,1588,51,1589,59,25,1551,539,1025,59,1589,26,42,35,18,43,571,1589,1551,539,1024,59,63,0,1550,512]

theorem envBound5481 : H12AffineFastState.Bounded env5481 := by
  intro p hp
  have h : env5481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5480_5481 : H12AffineEnvironment.transform 10 570 env5480 = env5481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 570 env5480 == env5481) = true)

theorem identity5481 : scanCanonicalize (H12AffineFastState.compose env5481 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5481 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5482 : List Nat := [2,4,8,16,26,16,18,4,512,1024,512,1550,9,1551,1,25,1551,539,1025,1,1551,26,16,25,18,17,513,1551,1551,539,1024,1,5,0,1550,512]

theorem envBound5482 : H12AffineFastState.Bounded env5482 := by
  intro p hp
  have h : env5482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5481_5482 : H12AffineEnvironment.transform 4 26 env5481 = env5482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5481 == env5482) = true)

theorem identity5482 : scanCanonicalize (H12AffineFastState.compose env5482 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5482 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5483 : List Nat := [2,4,2,16,16,16,18,4,512,1024,512,1540,3,1541,1,19,1541,529,1025,1,1541,16,16,19,18,17,513,1541,1541,529,1024,1,5,0,1540,512]

theorem envBound5483 : H12AffineFastState.Bounded env5483 := by
  intro p hp
  have h : env5483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5482_5483 : H12AffineEnvironment.transform 2 2 env5482 = env5483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5482 == env5483) = true)

theorem identity5483 : scanCanonicalize (H12AffineFastState.compose env5483 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5483 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5484 : List Nat := [2,4,2,0,0,0,2,4,512,1024,512,1540,3,1541,1,3,1541,513,1025,1,1541,0,0,3,2,1,513,1541,1541,513,1024,1,5,0,1540,512]

theorem envBound5484 : H12AffineFastState.Bounded env5484 := by
  intro p hp
  have h : env5484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5483_5484 : H12AffineEnvironment.transform 3 0 env5483 = env5484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5483 == env5484) = true)

theorem identity5484 : scanCanonicalize (H12AffineFastState.compose env5484 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5484 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5485 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,3,1029,1,3,1029,1,1025,1,1029,0,0,3,2,1,1,1029,1029,1,1024,1,5,0,1028,0]

theorem envBound5485 : H12AffineFastState.Bounded env5485 := by
  intro p hp
  have h : env5485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5484_5485 : H12AffineEnvironment.transform 8 0 env5484 = env5485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5484 == env5485) = true)

def leafEnv5485 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1028,3,1029,1,3,1029,1,1025,1,1029,0,0,3,1025,2,1,1,1,1029,1029,1,1024,1,5,0,5,3,1028,0,1,1029,0]

def active5485 : List Nat := [0,1,9]

def tree5485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5485 : H12WitnessSearch.Good tree5485 := H12GlobalWitnessIndex.good

theorem leafIdentity5485 : H12AffineFastState.composeSystem env5485 rootObs = leafEnv5485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5485 rootObs == leafEnv5485) = true)

theorem terminalChecked5485 : H12PackedTerminal.terminalCheckFast leafEnv5485 active5485 tree5485 = true := by decide +kernel

def env5486 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,61741,8388608,41003,8329,8388608,323712,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5486 : H12AffineFastState.Bounded env5486 := by
  intro p hp
  have h : env5486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5470_5486 : H12AffineEnvironment.transform 5 17 env5470 = env5486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5470 == env5486) = true)

def env5487 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,262144,1025,8352,4097,20877,8388608,139,8329,8388608,282656,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5487 : H12AffineFastState.Bounded env5487 := by
  intro p hp
  have h : env5487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5486_5487 : H12AffineEnvironment.transform 14 8352 env5486 = env5487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5486 == env5487) = true)

theorem identity5487 : scanCanonicalize (H12AffineFastState.compose env5487 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 96526) := by decide +kernel

theorem selectedBound5487 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5488 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96526,1025,8352,4097,20877,8388608,139,8329,8388608,76078,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5488 : H12AffineFastState.Bounded env5488 := by
  intro p hp
  have h : env5488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5487_5488 : H12AffineEnvironment.transform 17 96526 env5487 = env5488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96526 env5487 == env5488) = true)

theorem identity5488 : scanCanonicalize (H12AffineFastState.compose env5488 (packedSelected [0,1,3,9,13,17,22,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 20925) := by decide +kernel

theorem selectedBound5488 : packedSelected [0,1,3,9,13,17,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env5489 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,65536,4524,96526,1025,8352,4097,20877,20925,139,8329,20925,76078,16384,16813,22561,74794,20908,257,20480,16813,20992]

theorem envBound5489 : H12AffineFastState.Bounded env5489 := by
  intro p hp
  have h : env5489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5488_5489 : H12AffineEnvironment.transform 22 20925 env5488 = env5489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20925 env5488 == env5489) = true)

theorem identity5489 : scanCanonicalize (H12AffineFastState.compose env5489 (packedSelected [0,4,7,11,13,17,18,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound5489 : packedSelected [0,4,7,11,13,17,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env5490 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8352,29063,4524,2185,1025,8352,4097,20877,20925,139,8329,20925,22697,16384,16813,22561,21933,20908,257,20480,16813,20992]

theorem envBound5490 : H12AffineFastState.Bounded env5490 := by
  intro p hp
  have h : env5490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5489_5490 : H12AffineEnvironment.transform 15 29063 env5489 = env5490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env5489 == env5490) = true)

theorem identity5490 : scanCanonicalize (H12AffineFastState.compose env5490 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 10122) := by decide +kernel

theorem selectedBound5490 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env5491 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,10122,8352,5645,4524,2185,1025,8352,4097,13831,13879,139,8329,13879,16163,10122,9767,16299,12839,13862,257,14218,9767,13706]

theorem envBound5491 : H12AffineFastState.Bounded env5491 := by
  intro p hp
  have h : env5491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5490_5491 : H12AffineEnvironment.transform 13 10122 env5490 = env5491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10122 env5490 == env5491) = true)

theorem identity5491 : scanCanonicalize (H12AffineFastState.compose env5491 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound5491 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env5492 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,9783,8352,5645,4113,2185,1025,8352,4097,13831,13879,139,8329,13879,16030,9783,9767,15894,12839,13862,188,13879,9767,13367]

theorem envBound5492 : H12AffineFastState.Bounded env5492 := by
  intro p hp
  have h : env5492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5491_5492 : H12AffineEnvironment.transform 7 189 env5491 = env5492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5491 == env5492) = true)

theorem identity5492 : scanCanonicalize (H12AffineFastState.compose env5492 (packedSelected [0,1,2,5,6,7,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound5492 : packedSelected [0,1,2,5,6,7,10,13] rootPS < 2^1333 := by decide +kernel

def env5493 : List Nat := [2,4,8,16,32,17,128,189,512,1024,696,4096,8192,9783,8352,5645,4113,561,1025,8352,4097,13831,13879,139,8329,13879,13350,9783,9767,13486,12839,13862,188,13879,9767,13367]

theorem envBound5493 : H12AffineFastState.Bounded env5493 := by
  intro p hp
  have h : env5493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5492_5493 : H12AffineEnvironment.transform 10 696 env5492 = env5493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env5492 == env5493) = true)

theorem identity5493 : scanCanonicalize (H12AffineFastState.compose env5493 (packedSelected [0,1,2,3,6,7,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound5493 : packedSelected [0,1,2,3,6,7,12,15] rootPS < 2^1333 := by decide +kernel

def env5494 : List Nat := [2,4,8,16,32,17,128,189,512,1024,696,1583,8192,9783,8352,34,1598,561,1025,8352,1582,8232,8216,139,8329,8216,8713,9783,9767,8833,9224,8201,188,8216,9767,8728]

theorem envBound5494 : H12AffineFastState.Bounded env5494 := by
  intro p hp
  have h : env5494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5493_5494 : H12AffineEnvironment.transform 11 1583 env5493 = env5494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env5493 == env5494) = true)

theorem identity5494 : scanCanonicalize (H12AffineFastState.compose env5494 (packedSelected [0,1,2,5,6,7,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound5494 : packedSelected [0,1,2,5,6,7,10,17] rootPS < 2^1333 := by decide +kernel

def env5495 : List Nat := [2,4,8,16,32,17,128,189,512,1024,696,1583,177,1670,17,34,1598,561,1025,17,1582,153,169,139,56,169,696,1670,1686,560,1209,184,188,169,1686,681]

theorem envBound5495 : H12AffineFastState.Bounded env5495 := by
  intro p hp
  have h : env5495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5494_5495 : H12AffineEnvironment.transform 12 177 env5494 = env5495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env5494 == env5495) = true)

theorem identity5495 : scanCanonicalize (H12AffineFastState.compose env5495 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound5495 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env5496 : List Nat := [2,4,8,16,32,17,50,15,512,1024,522,1583,3,1588,17,34,1598,561,1025,17,1582,43,27,57,56,27,522,1588,1572,560,1035,10,14,27,1572,539]

theorem envBound5496 : H12AffineFastState.Bounded env5496 := by
  intro p hp
  have h : env5496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5495_5496 : H12AffineEnvironment.transform 6 50 env5495 = env5496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env5495 == env5496) = true)

theorem identity5496 : scanCanonicalize (H12AffineFastState.compose env5496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5497 : List Nat := [2,4,8,0,32,1,34,15,512,1024,522,1583,3,1572,1,34,1582,545,1025,1,1582,43,11,41,40,11,522,1572,1572,544,1035,10,14,11,1572,523]

theorem envBound5497 : H12AffineFastState.Bounded env5497 := by
  intro p hp
  have h : env5497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5496_5497 : H12AffineEnvironment.transform 3 0 env5496 = env5497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5496 == env5497) = true)

theorem identity5497 : scanCanonicalize (H12AffineFastState.compose env5497 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5497 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5498 : List Nat := [2,4,8,0,11,1,9,15,512,1024,522,1540,3,1551,1,9,1541,522,1025,1,1541,0,11,2,3,11,522,1551,1551,523,1035,10,14,11,1551,523]

theorem envBound5498 : H12AffineFastState.Bounded env5498 := by
  intro p hp
  have h : env5498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5497_5498 : H12AffineEnvironment.transform 4 11 env5497 = env5498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5497 == env5498) = true)

theorem identity5498 : scanCanonicalize (H12AffineFastState.compose env5498 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5498 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5499 : List Nat := [2,4,3,0,0,1,2,4,512,1024,513,1540,3,1540,1,2,1541,513,1025,1,1541,0,0,2,3,0,513,1540,1540,512,1024,1,5,0,1540,512]

theorem envBound5499 : H12AffineFastState.Bounded env5499 := by
  intro p hp
  have h : env5499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5498_5499 : H12AffineEnvironment.transform 2 3 env5498 = env5499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5498 == env5499) = true)

theorem identity5499 : scanCanonicalize (H12AffineFastState.compose env5499 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5500 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,3,1028,1,2,1029,1,1025,1,1029,0,0,2,3,0,1,1028,1028,0,1024,1,5,0,1028,0]

theorem envBound5500 : H12AffineFastState.Bounded env5500 := by
  intro p hp
  have h : env5500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5499_5500 : H12AffineEnvironment.transform 8 0 env5499 = env5500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5499 == env5500) = true)

def leafEnv5500 : List Nat := [2,4,3,0,0,1,2,4,0,1024,1,1028,3,1028,1,2,1029,1,1025,1,1029,0,0,2,1025,3,1,0,1,1028,1028,0,1024,1,5,0,5,3,1028,0,1,1028,0]

def active5500 : List Nat := [0,1,9]

def tree5500 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5500 : H12WitnessSearch.Good tree5500 := H12GlobalWitnessIndex.good

theorem leafIdentity5500 : H12AffineFastState.composeSystem env5500 rootObs = leafEnv5500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5500 rootObs == leafEnv5500) = true)

theorem terminalChecked5500 : H12PackedTerminal.terminalCheckFast leafEnv5500 active5500 tree5500 = true := by decide +kernel

def env5501 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,262144,1025,8353,4097,20876,8388608,138,8329,8388608,282657,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5501 : H12AffineFastState.Bounded env5501 := by
  intro p hp
  have h : env5501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5486_5501 : H12AffineEnvironment.transform 14 8353 env5486 = env5501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5486 == env5501) = true)

theorem identity5501 : scanCanonicalize (H12AffineFastState.compose env5501 (packedSelected [3,5,8,10,17,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 96267) := by decide +kernel

theorem selectedBound5501 : packedSelected [3,5,8,10,17,21,28,31] rootPS < 2^1333 := by decide +kernel

def env5502 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,65536,4524,96267,1025,8353,4097,20876,8388608,138,8329,8388608,75818,16384,16813,22561,74794,8388625,257,20480,16813,8389565]

theorem envBound5502 : H12AffineFastState.Bounded env5502 := by
  intro p hp
  have h : env5502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5501_5502 : H12AffineEnvironment.transform 17 96267 env5501 = env5502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96267 env5501 == env5502) = true)

theorem identity5502 : scanCanonicalize (H12AffineFastState.compose env5502 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 28714) := by decide +kernel

theorem selectedBound5502 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env5503 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8353,28714,4524,2081,1025,8353,4097,20876,8388608,138,8329,8388608,22528,16384,16813,22561,21504,8388625,257,20480,16813,8389565]

theorem envBound5503 : H12AffineFastState.Bounded env5503 := by
  intro p hp
  have h : env5503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5502_5503 : H12AffineEnvironment.transform 15 28714 env5502 = env5503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28714 env5502 == env5503) = true)

theorem identity5503 : scanCanonicalize (H12AffineFastState.compose env5503 (packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound5503 : packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS < 2^1333 := by decide +kernel

def env5504 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,7847,8353,11917,4524,2081,1025,8353,4097,3883,8388608,138,8329,8388608,1703,7847,7946,1670,2727,8388625,257,3751,7946,8389565]

theorem envBound5504 : H12AffineFastState.Bounded env5504 := by
  intro p hp
  have h : env5504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5503_5504 : H12AffineEnvironment.transform 13 7847 env5503 = env5504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env5503 == env5504) = true)

theorem identity5504 : scanCanonicalize (H12AffineFastState.compose env5504 (packedSelected [4,9,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5504 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env5505 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,7847,8353,11917,4265,2081,1025,8353,4097,3630,8388608,138,8329,8388608,1703,7847,7695,1670,2727,8388625,4,3751,7695,8389304]

theorem envBound5505 : H12AffineFastState.Bounded env5505 := by
  intro p hp
  have h : env5505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5504_5505 : H12AffineEnvironment.transform 7 5 env5504 = env5505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5504 == env5505) = true)

theorem identity5505 : scanCanonicalize (H12AffineFastState.compose env5505 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5505 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env5506 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7695,8201,11813,4097,2081,1025,8201,4097,3630,8388608,34,8225,8388608,1551,7695,7695,1582,2575,8388625,4,3599,7695,8389136]

theorem envBound5506 : H12AffineFastState.Bounded env5506 := by
  intro p hp
  have h : env5506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5505_5506 : H12AffineEnvironment.transform 6 40 env5505 = env5506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5505 == env5506) = true)

theorem identity5506 : scanCanonicalize (H12AffineFastState.compose env5506 (packedSelected [2,6] rootPS)) = affineNative (2^(22+1) ^^^ 3589) := by decide +kernel

theorem selectedBound5506 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env5507 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,4096,8192,7695,8201,11813,4097,2081,1025,8201,4097,3630,3589,34,8225,3589,1551,7695,7695,1582,2575,3604,4,3599,7695,3093]

theorem envBound5507 : H12AffineFastState.Bounded env5507 := by
  intro p hp
  have h : env5507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5506_5507 : H12AffineEnvironment.transform 22 3589 env5506 = env5507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 3589 env5506 == env5507) = true)

theorem identity5507 : scanCanonicalize (H12AffineFastState.compose env5507 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5507 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5508 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1588,8192,2107,8201,11813,1589,2081,1025,8201,1589,3630,3589,34,8225,3589,1551,2107,2107,1582,2575,3604,4,3599,2107,3093]

theorem envBound5508 : H12AffineFastState.Bounded env5508 := by
  intro p hp
  have h : env5508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5507_5508 : H12AffineEnvironment.transform 11 1588 env5507 = env5508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5507 == env5508) = true)

theorem identity5508 : scanCanonicalize (H12AffineFastState.compose env5508 (packedSelected [1,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5508 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env5509 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1038,1588,8192,1077,8201,8747,1589,1071,1025,8201,1589,544,523,34,8225,523,1551,1077,1077,1582,1537,538,4,513,1077,27]

theorem envBound5509 : H12AffineFastState.Bounded env5509 := by
  intro p hp
  have h : env5509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5508_5509 : H12AffineEnvironment.transform 10 1038 env5508 = env5509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env5508 == env5509) = true)

theorem identity5509 : scanCanonicalize (H12AffineFastState.compose env5509 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1542) := by decide +kernel

theorem selectedBound5509 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5510 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1038,1588,1542,1077,1551,1069,1589,1071,1025,1551,1589,544,523,34,1575,523,1551,1077,1077,1582,1537,538,4,513,1077,27]

theorem envBound5510 : H12AffineFastState.Bounded env5510 := by
  intro p hp
  have h : env5510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5509_5510 : H12AffineEnvironment.transform 12 1542 env5509 = env5510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1542 env5509 == env5510) = true)

theorem identity5510 : scanCanonicalize (H12AffineFastState.compose env5510 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound5510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5511 : List Nat := [2,4,8,16,32,17,40,5,512,564,570,0,50,513,59,537,1,539,565,59,1,544,523,34,19,523,59,513,513,26,53,538,4,513,513,27]

theorem envBound5511 : H12AffineFastState.Bounded env5511 := by
  intro p hp
  have h : env5511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5510_5511 : H12AffineEnvironment.transform 9 564 env5510 = env5511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env5510 == env5511) = true)

theorem identity5511 : scanCanonicalize (H12AffineFastState.compose env5511 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound5511 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env5512 : List Nat := [2,4,8,11,32,10,40,5,512,559,545,0,41,513,32,514,1,512,558,32,1,544,523,34,8,523,32,513,513,1,46,513,4,513,513,0]

theorem envBound5512 : H12AffineFastState.Bounded env5512 := by
  intro p hp
  have h : env5512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5511_5512 : H12AffineEnvironment.transform 3 11 env5511 = env5512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env5511 == env5512) = true)

def env5513 : List Nat := [2,4,8,11,32,10,40,5,0,47,33,0,41,1,32,2,1,0,46,32,1,32,11,34,8,11,32,1,1,1,46,1,4,1,1,0]

theorem envBound5513 : H12AffineFastState.Bounded env5513 := by
  intro p hp
  have h : env5513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5512_5513 : H12AffineEnvironment.transform 8 0 env5512 = env5513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5512 == env5513) = true)

def env5514 : List Nat := [2,4,8,11,32,10,40,5,1,46,32,0,41,0,32,3,1,1,47,32,1,33,10,34,8,10,32,0,0,1,46,0,4,0,0,0]

theorem envBound5514 : H12AffineFastState.Bounded env5514 := by
  intro p hp
  have h : env5514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5512_5514 : H12AffineEnvironment.transform 8 1 env5512 = env5514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5512 == env5514) = true)

theorem identity5514 : scanCanonicalize (H12AffineFastState.compose env5514 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5515 : List Nat := [2,4,6,5,32,4,38,5,1,32,32,0,39,0,32,3,1,1,33,32,1,33,4,34,6,4,32,0,0,1,32,0,4,0,0,0]

theorem envBound5515 : H12AffineFastState.Bounded env5515 := by
  intro p hp
  have h : env5515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5514_5515 : H12AffineEnvironment.transform 2 6 env5514 = env5515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5514 == env5515) = true)

theorem identity5515 : scanCanonicalize (H12AffineFastState.compose env5515 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5515 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5516 : List Nat := [2,1,3,0,32,1,35,0,1,32,32,0,34,0,32,3,1,1,33,32,1,33,1,34,3,1,32,0,0,1,32,0,1,0,0,0]

theorem envBound5516 : H12AffineFastState.Bounded env5516 := by
  intro p hp
  have h : env5516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5515_5516 : H12AffineEnvironment.transform 1 1 env5515 = env5516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5515 == env5516) = true)

def leafEnv5516 : List Nat := [2,1,3,0,32,1,35,0,1,32,32,0,34,0,32,3,1,1,33,32,1,33,1,34,33,3,1,1,32,0,0,1,32,0,1,0,0,34,0,0,1,1,0]

def active5516 : List Nat := [0,4]

def tree5516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5516 : H12WitnessSearch.Good tree5516 := H12GlobalWitnessIndex.good

theorem leafIdentity5516 : H12AffineFastState.composeSystem env5516 rootObs = leafEnv5516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5516 rootObs == leafEnv5516) = true)

theorem terminalChecked5516 : H12PackedTerminal.terminalCheckFast leafEnv5516 active5516 tree5516 = true := by decide +kernel

def env5517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914001,2942160,16385,16893,2641009,598058,14737724,525568,2638928,6332544,8914925]

theorem envBound5517 : H12AffineFastState.Bounded env5517 := by
  intro p hp
  have h : env5517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5323_5517 : H12AffineEnvironment.transform 25 8914001 env5323 = env5517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env5323 == env5517) = true)

def env5518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849104,16385,16893,547953,598058,12644668,525568,545872,4239488,8914925]

theorem envBound5518 : H12AffineFastState.Bounded env5518 := by
  intro p hp
  have h : env5518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5517_5518 : H12AffineEnvironment.transform 20 4096 env5517 = env5518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5517 == env5518) = true)

def env5519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323792,16385,16893,22641,74794,12644668,256,20560,4239488,8389613]

theorem envBound5519 : H12AffineFastState.Bounded env5519 := by
  intro p hp
  have h : env5519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5518_5519 : H12AffineEnvironment.transform 18 1024 env5518 = env5519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5518 == env5519) = true)

theorem identity5519 : scanCanonicalize (H12AffineFastState.compose env5519 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 20804) := by decide +kernel

theorem selectedBound5519 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,20804,41003,8329,20757,323792,16385,16893,22641,74794,4235384,256,20560,4239488,21161]

theorem envBound5520 : H12AffineFastState.Bounded env5520 := by
  intro p hp
  have h : env5520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5519_5520 : H12AffineEnvironment.transform 22 20804 env5519 = env5520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20804 env5519 == env5520) = true)

def env5521 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,20756,41003,8329,20757,323712,16385,16813,22561,74794,4235304,256,20480,4239488,21161]

theorem envBound5521 : H12AffineFastState.Bounded env5521 := by
  intro p hp
  have h : env5521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5520_5521 : H12AffineEnvironment.transform 5 16 env5520 = env5521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5520 == env5521) = true)

theorem identity5521 : scanCanonicalize (H12AffineFastState.compose env5521 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4265) := by decide +kernel

theorem selectedBound5521 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5522 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,4194304,445,41003,8329,444,303145,4264,4356,2184,74794,4235304,256,169,4239488,512]

theorem envBound5522 : H12AffineFastState.Bounded env5522 := by
  intro p hp
  have h : env5522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5521_5522 : H12AffineEnvironment.transform 13 4265 env5521 = env5522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env5521 == env5522) = true)

theorem identity5522 : scanCanonicalize (H12AffineFastState.compose env5522 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound5522 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5523 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,65536,4525,262144,1024,32768,4096,41348,445,41003,8329,444,303145,4264,4356,2184,74794,428,256,169,4356,512]

theorem envBound5523 : H12AffineFastState.Bounded env5523 := by
  intro p hp
  have h : env5523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5522_5523 : H12AffineEnvironment.transform 21 41348 env5522 = env5523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env5522 == env5523) = true)

theorem identity5523 : scanCanonicalize (H12AffineFastState.compose env5523 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound5523 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5524 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,65536,4525,262144,1024,13884,4096,6072,445,5655,8329,444,267797,4264,4356,2184,74794,428,256,169,4356,512]

theorem envBound5524 : H12AffineFastState.Bounded env5524 := by
  intro p hp
  have h : env5524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5523_5524 : H12AffineEnvironment.transform 14 13884 env5523 = env5524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env5523 == env5524) = true)

theorem identity5524 : scanCanonicalize (H12AffineFastState.compose env5524 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound5524 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5525 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,13884,8235,4525,262144,1024,13884,4096,6072,445,5655,8329,444,267797,4264,4356,2184,1025,428,256,169,4356,512]

theorem envBound5525 : H12AffineFastState.Bounded env5525 := by
  intro p hp
  have h : env5525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5524_5525 : H12AffineEnvironment.transform 15 8235 env5524 = env5525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env5524 == env5525) = true)

def env5526 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20757,41003,8329,20757,323713,16385,16812,22560,74794,4235305,256,20481,4239488,21161]

theorem envBound5526 : H12AffineFastState.Bounded env5526 := by
  intro p hp
  have h : env5526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5520_5526 : H12AffineEnvironment.transform 5 17 env5520 = env5526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5520 == env5526) = true)

def env5527 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20741,41003,8329,20741,323713,16385,16812,22560,74794,4235305,256,20481,4239488,21161]

theorem envBound5527 : H12AffineFastState.Bounded env5527 := by
  intro p hp
  have h : env5527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5526_5527 : H12AffineEnvironment.transform 3 0 env5526 = env5527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5526 == env5527) = true)

theorem identity5527 : scanCanonicalize (H12AffineFastState.compose env5527 (packedSelected [2,7,11,13,18,20,21,27] rootPS)) = affineNative (2^(21+1) ^^^ 362894) := by decide +kernel

theorem selectedBound5527 : packedSelected [2,7,11,13,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5528 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,362894,20741,41003,8329,20741,323713,16385,16812,22560,74794,338343,256,20481,342286,21161]

theorem envBound5528 : H12AffineFastState.Bounded env5528 := by
  intro p hp
  have h : env5528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5527_5528 : H12AffineEnvironment.transform 21 362894 env5527 = env5528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362894 env5527 == env5528) = true)

def env5529 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4096,362790,20741,41003,8225,20741,323625,16385,16644,22560,74794,338191,256,20481,342286,20993]

theorem envBound5529 : H12AffineFastState.Bounded env5529 := by
  intro p hp
  have h : env5529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5528_5529 : H12AffineEnvironment.transform 6 40 env5528 = env5529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5528 == env5529) = true)

theorem identity5529 : scanCanonicalize (H12AffineFastState.compose env5529 (packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS)) = affineNative (2^(17+1) ^^^ 100615) := by decide +kernel

theorem selectedBound5529 : packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env5530 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,100615,1024,32768,4096,33,20741,41003,8225,20741,96558,16385,16644,22560,74794,40968,256,20481,45065,20993]

theorem envBound5530 : H12AffineFastState.Bounded env5530 := by
  intro p hp
  have h : env5530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5529_5530 : H12AffineEnvironment.transform 17 100615 env5529 = env5530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100615 env5529 == env5530) = true)

theorem identity5530 : scanCanonicalize (H12AffineFastState.compose env5530 (packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 32802) := by decide +kernel

theorem selectedBound5530 : packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS < 2^1333 := by decide +kernel

def env5531 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,32802,4356,2341,1024,32768,4096,33,20741,41003,8225,20741,63756,16385,16644,22560,41992,40968,256,20481,45065,20993]

theorem envBound5531 : H12AffineFastState.Bounded env5531 := by
  intro p hp
  have h : env5531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5530_5531 : H12AffineEnvironment.transform 15 32802 env5530 = env5531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32802 env5530 == env5531) = true)

theorem identity5531 : scanCanonicalize (H12AffineFastState.compose env5531 (packedSelected [3,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 7173) := by decide +kernel

theorem selectedBound5531 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env5532 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,7173,7207,4356,2341,1024,7173,4096,33,20741,15406,8225,20741,25865,16385,16644,22560,14349,15373,256,20481,11276,20993]

theorem envBound5532 : H12AffineFastState.Bounded env5532 := by
  intro p hp
  have h : env5532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5531_5532 : H12AffineEnvironment.transform 14 7173 env5531 = env5532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7173 env5531 == env5532) = true)

theorem identity5532 : scanCanonicalize (H12AffineFastState.compose env5532 (packedSelected [0,4,6,7,9,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 8707) := by decide +kernel

theorem selectedBound5532 : packedSelected [0,4,6,7,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5533 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,8707,7173,7207,4356,2341,1024,7173,4096,33,13062,15406,8225,13062,1802,8706,8967,14883,14349,15373,256,12802,11276,12290]

theorem envBound5533 : H12AffineFastState.Bounded env5533 := by
  intro p hp
  have h : env5533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5532_5533 : H12AffineEnvironment.transform 13 8707 env5532 = env5533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8707 env5532 == env5533) = true)

theorem identity5533 : scanCanonicalize (H12AffineFastState.compose env5533 (packedSelected [0,4,5,6,7,8,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5533 : packedSelected [0,4,5,6,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env5534 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,4096,8192,8707,7173,7207,4097,2080,1024,7173,4096,33,12803,15406,8225,12803,1551,8706,8706,14883,14349,15373,5,12802,11276,12290]

theorem envBound5534 : H12AffineFastState.Bounded env5534 := by
  intro p hp
  have h : env5534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5533_5534 : H12AffineEnvironment.transform 7 5 env5533 = env5534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5533 == env5534) = true)

theorem identity5534 : scanCanonicalize (H12AffineFastState.compose env5534 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound5534 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5535 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1573,8192,8707,2592,2562,1572,2080,1024,2592,1573,33,9254,10763,8225,9254,1551,8706,8706,11270,11816,10792,5,9255,11276,9767]

theorem envBound5535 : H12AffineFastState.Bounded env5535 := by
  intro p hp
  have h : env5535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5534_5535 : H12AffineEnvironment.transform 11 1573 env5534 = env5535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env5534 == env5535) = true)

theorem identity5535 : scanCanonicalize (H12AffineFastState.compose env5535 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound5535 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5536 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1573,1062,1573,2592,2562,1572,2080,1024,2592,1573,33,0,3629,1031,0,1551,1572,1572,2080,2574,3598,5,1,2090,513]

theorem envBound5536 : H12AffineFastState.Bounded env5536 := by
  intro p hp
  have h : env5536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5535_5536 : H12AffineEnvironment.transform 12 1062 env5535 = env5536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env5535 == env5536) = true)

theorem identity5536 : scanCanonicalize (H12AffineFastState.compose env5536 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound5536 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env5537 : List Nat := [2,4,8,0,32,1,40,5,4,1024,2048,1057,1062,1057,2084,2054,1056,2080,1024,2084,1057,33,0,3113,1031,0,1035,1056,1056,2080,2058,3082,5,1,2090,5]

theorem envBound5537 : H12AffineFastState.Bounded env5537 := by
  intro p hp
  have h : env5537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5536_5537 : H12AffineEnvironment.transform 8 4 env5536 = env5537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env5536 == env5537) = true)

theorem identity5537 : scanCanonicalize (H12AffineFastState.compose env5537 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1035) := by decide +kernel

theorem selectedBound5537 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env5538 : List Nat := [2,4,8,0,32,1,40,5,4,1024,1035,1057,1062,1057,1071,1037,1056,1067,1024,1071,1057,33,0,34,1031,0,1035,1056,1056,1067,1025,1,5,1,1057,5]

theorem envBound5538 : H12AffineFastState.Bounded env5538 := by
  intro p hp
  have h : env5538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5537_5538 : H12AffineEnvironment.transform 10 1035 env5537 = env5538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1035 env5537 == env5538) = true)

theorem identity5538 : scanCanonicalize (H12AffineFastState.compose env5538 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5538 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env5539 : List Nat := [2,4,8,0,11,1,3,5,4,1024,1035,1034,1037,1034,1028,1037,1035,1024,1024,1028,1034,10,0,9,1031,0,1035,1035,1035,1024,1025,1,5,1,1034,5]

theorem envBound5539 : H12AffineFastState.Bounded env5539 := by
  intro p hp
  have h : env5539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5538_5539 : H12AffineEnvironment.transform 4 11 env5538 = env5539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5538 == env5539) = true)

theorem identity5539 : scanCanonicalize (H12AffineFastState.compose env5539 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5539 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5540 : List Nat := [2,1,8,0,11,1,3,0,1,1024,1035,1034,1032,1034,1025,1032,1035,1024,1024,1025,1034,10,0,9,1026,0,1035,1035,1035,1024,1025,1,0,1,1034,0]

theorem envBound5540 : H12AffineFastState.Bounded env5540 := by
  intro p hp
  have h : env5540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5539_5540 : H12AffineEnvironment.transform 1 1 env5539 = env5540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5539 == env5540) = true)

theorem identity5540 : scanCanonicalize (H12AffineFastState.compose env5540 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound5540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5541 : List Nat := [2,1,8,0,11,1,3,0,1,10,1,0,2,0,11,2,1,10,10,11,0,10,0,9,8,0,1,1,1,10,11,1,0,1,0,0]

theorem envBound5541 : H12AffineFastState.Bounded env5541 := by
  intro p hp
  have h : env5541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5540_5541 : H12AffineEnvironment.transform 9 10 env5540 = env5541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env5540 == env5541) = true)

def leafEnv5541 : List Nat := [2,1,8,0,11,1,3,0,1,10,1,0,2,0,11,2,1,10,10,11,0,10,0,9,11,8,1,0,1,1,1,10,11,1,0,1,1,8,0,0,1,0,0]

def active5541 : List Nat := [0,2]

def tree5541 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5541 : H12WitnessSearch.Good tree5541 := H12GlobalWitnessIndex.good

theorem leafIdentity5541 : H12AffineFastState.composeSystem env5541 rootObs = leafEnv5541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5541 rootObs == leafEnv5541) = true)

theorem terminalChecked5541 : H12PackedTerminal.terminalCheckFast leafEnv5541 active5541 tree5541 = true := by decide +kernel

def env5542 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,362791,20741,41003,8224,20741,323624,16385,16645,22560,74794,338190,256,20481,342286,20992]

theorem envBound5542 : H12AffineFastState.Bounded env5542 := by
  intro p hp
  have h : env5542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5528_5542 : H12AffineEnvironment.transform 6 41 env5528 = env5542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5528 == env5542) = true)

theorem identity5542 : scanCanonicalize (H12AffineFastState.compose env5542 (packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS)) = affineNative (2^(17+1) ^^^ 43308) := by decide +kernel

theorem selectedBound5542 : packedSelected [3,4,5,9,10,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env5543 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,43308,1024,32768,4096,73739,20741,41003,8224,20741,22788,16385,16645,22560,74794,98338,256,20481,102434,20992]

theorem envBound5543 : H12AffineFastState.Bounded env5543 := by
  intro p hp
  have h : env5543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5542_5543 : H12AffineEnvironment.transform 17 43308 env5542 = env5543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43308 env5542 == env5543) = true)

theorem identity5543 : scanCanonicalize (H12AffineFastState.compose env5543 (packedSelected [6,11,12,13,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 28932) := by decide +kernel

theorem selectedBound5543 : packedSelected [6,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env5544 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,28932,4357,43308,1024,32768,4096,20751,20741,41003,8224,20741,22788,16385,16645,22560,21806,61734,256,20481,57638,20992]

theorem envBound5544 : H12AffineFastState.Bounded env5544 := by
  intro p hp
  have h : env5544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5543_5544 : H12AffineEnvironment.transform 15 28932 env5543 = env5544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28932 env5543 == env5544) = true)

theorem identity5544 : scanCanonicalize (H12AffineFastState.compose env5544 (packedSelected [2,3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5544 : packedSelected [2,3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env5545 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,16384,32768,28672,4097,43048,1024,32768,4096,20491,20481,41003,8224,20481,22528,16385,16385,22560,21546,61474,4,20481,57378,20992]

theorem envBound5545 : H12AffineFastState.Bounded env5545 := by
  intro p hp
  have h : env5545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5544_5545 : H12AffineEnvironment.transform 7 4 env5544 = env5545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5544 == env5545) = true)

theorem identity5545 : scanCanonicalize (H12AffineFastState.compose env5545 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5545 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5546 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,1550,32768,13838,4097,43048,1024,32768,4096,5637,5647,41003,8224,5647,7694,1551,1551,7726,4644,46636,4,5647,42540,5134]

theorem envBound5546 : H12AffineFastState.Bounded env5546 := by
  intro p hp
  have h : env5546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5545_5546 : H12AffineEnvironment.transform 13 1550 env5545 = env5546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1550 env5545 == env5546) = true)

theorem identity5546 : scanCanonicalize (H12AffineFastState.compose env5546 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 8227) := by decide +kernel

theorem selectedBound5546 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5547 : List Nat := [2,4,8,0,32,1,41,4,512,1024,2048,4096,8192,1550,8227,13838,4097,2059,1024,8227,4096,5637,5647,8,8224,5647,7694,1551,1551,7726,4644,5647,4,5647,1551,5134]

theorem envBound5547 : H12AffineFastState.Bounded env5547 := by
  intro p hp
  have h : env5547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5546_5547 : H12AffineEnvironment.transform 14 8227 env5546 = env5547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8227 env5546 == env5547) = true)

theorem identity5547 : scanCanonicalize (H12AffineFastState.compose env5547 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5547 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env5548 : List Nat := [2,4,8,0,10,1,3,4,512,1024,2048,4096,8192,1550,8201,13838,4097,2059,1024,8201,4096,5637,5647,8,8202,5647,7694,1551,1551,7684,4622,5647,4,5647,1551,5134]

theorem envBound5548 : H12AffineFastState.Bounded env5548 := by
  intro p hp
  have h : env5548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5547_5548 : H12AffineEnvironment.transform 4 10 env5547 = env5548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5547 == env5548) = true)

theorem identity5548 : scanCanonicalize (H12AffineFastState.compose env5548 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound5548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5549 : List Nat := [2,4,8,0,10,1,3,4,512,1024,2048,4096,2563,1550,2570,7181,4097,2059,1024,2570,4096,5637,5647,8,2569,5647,7694,1551,1551,7684,4622,5647,4,5647,1551,5134]

theorem envBound5549 : H12AffineFastState.Bounded env5549 := by
  intro p hp
  have h : env5549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5548_5549 : H12AffineEnvironment.transform 12 2563 env5548 = env5549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env5548 == env5549) = true)

theorem identity5549 : scanCanonicalize (H12AffineFastState.compose env5549 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound5549 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env5550 : List Nat := [2,4,8,0,10,1,3,4,512,517,2048,4096,2563,11,2570,6664,4097,2059,517,2570,4096,4096,4106,8,2569,4106,6155,10,10,6145,4622,4106,4,4106,10,4619]

theorem envBound5550 : H12AffineFastState.Bounded env5550 := by
  intro p hp
  have h : env5550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5549_5550 : H12AffineEnvironment.transform 9 517 env5549 = env5550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env5549 == env5550) = true)

theorem identity5550 : scanCanonicalize (H12AffineFastState.compose env5550 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5550 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5551 : List Nat := [2,4,8,0,10,1,3,4,512,517,523,4096,8,11,1,4099,4097,512,517,1,4096,4096,4106,8,2,4106,4608,10,10,4618,4622,4106,4,4106,10,4619]

theorem envBound5551 : H12AffineFastState.Bounded env5551 := by
  intro p hp
  have h : env5551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5550_5551 : H12AffineEnvironment.transform 10 523 env5550 = env5551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5550 == env5551) = true)

theorem identity5551 : scanCanonicalize (H12AffineFastState.compose env5551 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound5551 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5552 : List Nat := [2,4,8,0,10,1,3,4,512,517,523,0,8,11,1,3,1,512,517,1,0,0,10,8,2,10,512,10,10,522,526,10,4,10,10,523]

theorem envBound5552 : H12AffineFastState.Bounded env5552 := by
  intro p hp
  have h : env5552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5551_5552 : H12AffineEnvironment.transform 11 0 env5551 = env5552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env5551 == env5552) = true)

theorem identity5552 : scanCanonicalize (H12AffineFastState.compose env5552 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5552 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5553 : List Nat := [2,4,3,0,1,1,3,4,512,517,512,0,3,0,1,3,1,512,517,1,0,0,1,3,2,1,512,1,1,513,517,1,4,1,1,512]

theorem envBound5553 : H12AffineFastState.Bounded env5553 := by
  intro p hp
  have h : env5553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5552_5553 : H12AffineEnvironment.transform 2 3 env5552 = env5553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5552 == env5553) = true)

theorem identity5553 : scanCanonicalize (H12AffineFastState.compose env5553 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5554 : List Nat := [2,4,3,0,1,1,3,4,1,4,1,0,3,0,1,3,1,1,4,1,0,0,1,3,2,1,1,1,1,0,4,1,4,1,1,1]

theorem envBound5554 : H12AffineFastState.Bounded env5554 := by
  intro p hp
  have h : env5554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5553_5554 : H12AffineEnvironment.transform 8 1 env5553 = env5554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5553 == env5554) = true)

def env5555 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,20740,41003,8329,20740,323713,16385,16812,22560,74794,4235305,256,20481,4239488,21161]

theorem envBound5555 : H12AffineFastState.Bounded env5555 := by
  intro p hp
  have h : env5555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5526_5555 : H12AffineEnvironment.transform 3 1 env5526 = env5555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5526 == env5555) = true)

theorem identity5555 : scanCanonicalize (H12AffineFastState.compose env5555 (packedSelected [2,7,11,13,18,20,21,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound5555 : packedSelected [2,7,11,13,18,20,21,27] rootPS < 2^1333 := by decide +kernel

def env5556 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,2445,1024,32768,4096,4194304,20740,41003,8329,20740,63756,16385,16812,22560,74794,4235305,256,20481,4239488,21161]

theorem envBound5556 : H12AffineFastState.Bounded env5556 := by
  intro p hp
  have h : env5556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5555_5556 : H12AffineEnvironment.transform 17 2445 env5555 = env5556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env5555 == env5556) = true)

def env5557 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,2341,1024,32768,4096,4194304,20740,41003,8225,20740,63756,16385,16644,22560,74794,4235305,256,20481,4239400,20993]

theorem envBound5557 : H12AffineFastState.Bounded env5557 := by
  intro p hp
  have h : env5557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5556_5557 : H12AffineEnvironment.transform 6 40 env5556 = env5557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5556 == env5557) = true)

theorem identity5557 : scanCanonicalize (H12AffineFastState.compose env5557 (packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound5557 : packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env5558 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,53283,4356,2341,1024,32768,4096,4194304,20740,41003,8225,20740,63756,16385,16644,22560,62473,4235305,256,20481,4239400,20993]

theorem envBound5558 : H12AffineFastState.Bounded env5558 := by
  intro p hp
  have h : env5558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5557_5558 : H12AffineEnvironment.transform 15 53283 env5557 = env5558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env5557 == env5558) = true)

theorem identity5558 : scanCanonicalize (H12AffineFastState.compose env5558 (packedSelected [2,3,4,5,9,10,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 20772) := by decide +kernel

theorem selectedBound5558 : packedSelected [2,3,4,5,9,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env5559 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,32768,53283,4356,2341,1024,32768,4096,20772,20740,41003,8225,20740,63756,16385,16644,22560,62473,61709,256,20481,57612,20993]

theorem envBound5559 : H12AffineFastState.Bounded env5559 := by
  intro p hp
  have h : env5559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5558_5559 : H12AffineEnvironment.transform 21 20772 env5558 = env5559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20772 env5558 == env5559) = true)

theorem identity5559 : scanCanonicalize (H12AffineFastState.compose env5559 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 13100) := by decide +kernel

theorem selectedBound5559 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env5560 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,4096,8192,16384,13100,25359,4356,2341,1024,13100,4096,20772,20740,4871,8225,20740,18976,16385,16644,22560,18213,16929,256,20481,21024,20993]

theorem envBound5560 : H12AffineFastState.Bounded env5560 := by
  intro p hp
  have h : env5560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5559_5560 : H12AffineEnvironment.transform 14 13100 env5559 = env5560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13100 env5559 == env5560) = true)

theorem identity5560 : scanCanonicalize (H12AffineFastState.compose env5560 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound5560 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env5561 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,2048,8192,16384,11052,25359,2308,2341,1024,11052,2048,18724,18692,2823,8225,18692,18976,16385,16644,16416,18213,16929,256,18433,18976,18945]

theorem envBound5561 : H12AffineFastState.Bounded env5561 := by
  intro p hp
  have h : env5561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5560_5561 : H12AffineEnvironment.transform 11 2048 env5560 = env5561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env5560 == env5561) = true)

theorem identity5561 : scanCanonicalize (H12AffineFastState.compose env5561 (packedSelected [0,1,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 1825) := by decide +kernel

theorem selectedBound5561 : packedSelected [0,1,7,8,10] rootPS < 2^1333 := by decide +kernel

def env5562 : List Nat := [2,4,8,1,32,0,40,256,512,1024,2048,2048,8192,1825,11052,9262,2308,2341,1024,11052,2048,3589,3621,2823,8225,3621,3329,1824,1573,1793,4,1280,256,3872,3329,3360]

theorem envBound5562 : H12AffineFastState.Bounded env5562 := by
  intro p hp
  have h : env5562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5561_5562 : H12AffineEnvironment.transform 13 1825 env5561 = env5562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1825 env5561 == env5562) = true)

theorem identity5562 : scanCanonicalize (H12AffineFastState.compose env5562 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1803) := by decide +kernel

theorem selectedBound5562 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5563 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1803,1803,8192,1825,9255,9262,1551,1582,1024,9255,1803,270,302,1036,8225,302,522,1824,1573,1793,4,1280,256,43,522,555]

theorem envBound5563 : H12AffineFastState.Bounded env5563 := by
  intro p hp
  have h : env5563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5562_5563 : H12AffineEnvironment.transform 10 1803 env5562 = env5563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1803 env5562 == env5563) = true)

theorem identity5563 : scanCanonicalize (H12AffineFastState.compose env5563 (packedSelected [0,2,5,6,7,8,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 1289) := by decide +kernel

theorem selectedBound5563 : packedSelected [0,2,5,6,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env5564 : List Nat := [2,4,8,1,32,0,40,256,512,1024,1803,1803,1289,1825,302,295,1551,1582,1024,302,1803,270,302,1036,1320,302,522,1824,1573,1793,4,1280,256,43,522,555]

theorem envBound5564 : H12AffineFastState.Bounded env5564 := by
  intro p hp
  have h : env5564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5563_5564 : H12AffineEnvironment.transform 12 1289 env5563 = env5564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env5563 == env5564) = true)

def env5565 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,2340,1024,32768,4096,4194304,20740,41003,8224,20740,63756,16385,16645,22560,74794,4235305,256,20481,4239401,20992]

theorem envBound5565 : H12AffineFastState.Bounded env5565 := by
  intro p hp
  have h : env5565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5556_5565 : H12AffineEnvironment.transform 6 41 env5556 = env5565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5556 == env5565) = true)

theorem identity5565 : scanCanonicalize (H12AffineFastState.compose env5565 (packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound5565 : packedSelected [0,3,4,5,7,10,13,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env5566 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28680,65536,4357,2340,1024,28680,4096,4194304,20740,20515,8224,20740,2308,16385,16645,22560,74794,4214817,256,20481,4210721,20992]

theorem envBound5566 : H12AffineFastState.Bounded env5566 := by
  intro p hp
  have h : env5566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5565_5566 : H12AffineEnvironment.transform 14 28680 env5565 = env5566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env5565 == env5566) = true)

theorem identity5566 : scanCanonicalize (H12AffineFastState.compose env5566 (packedSelected [0,7,9,13,17,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 73738) := by decide +kernel

theorem selectedBound5566 : packedSelected [0,7,9,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env5567 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28680,65536,4357,2340,1024,28680,4096,73738,20740,20515,8224,20740,2308,16385,16645,22560,74794,94251,256,20481,90155,20992]

theorem envBound5567 : H12AffineFastState.Bounded env5567 := by
  intro p hp
  have h : env5567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5566_5567 : H12AffineEnvironment.transform 21 73738 env5566 = env5567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73738 env5566 == env5567) = true)

theorem identity5567 : scanCanonicalize (H12AffineFastState.compose env5567 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 41) := by decide +kernel

theorem selectedBound5567 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5568 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,16384,28680,41,4357,2340,1024,28680,4096,8227,20740,20515,8224,20740,2308,16385,16645,22560,9219,28674,256,20481,24578,20992]

theorem envBound5568 : H12AffineFastState.Bounded env5568 := by
  intro p hp
  have h : env5568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5567_5568 : H12AffineEnvironment.transform 15 41 env5567 = env5568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env5567 == env5568) = true)

theorem identity5568 : scanCanonicalize (H12AffineFastState.compose env5568 (packedSelected [2,3,5,10,11,13,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound5568 : packedSelected [2,3,5,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5569 : List Nat := [2,4,8,1,32,0,41,256,512,1024,2048,4096,8192,4357,8461,41,4357,2340,1024,8461,4096,8227,1,294,8224,1,2308,4356,4096,2341,9219,8455,256,260,12551,773]

theorem envBound5569 : H12AffineFastState.Bounded env5569 := by
  intro p hp
  have h : env5569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5568_5569 : H12AffineEnvironment.transform 13 4357 env5568 = env5569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env5568 == env5569) = true)

def env5570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,12644668,257,20561,4239488,8389612]

theorem envBound5570 : H12AffineFastState.Bounded env5570 := by
  intro p hp
  have h : env5570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5518_5570 : H12AffineEnvironment.transform 18 1025 env5518 = env5570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5518 == env5570) = true)

theorem identity5570 : scanCanonicalize (H12AffineFastState.compose env5570 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound5570 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1092,8192,16384,32768,65536,1465,262144,1025,32768,1092,4194304,8388608,41003,8329,8388688,320661,16385,16893,19508,74795,12641656,257,17429,4236484,8389612]

theorem envBound5571 : H12AffineFastState.Bounded env5571 := by
  intro p hp
  have h : env5571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5570_5571 : H12AffineEnvironment.transform 11 1092 env5570 = env5571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env5570 == env5571) = true)

def env5572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1044,8192,16384,32768,65536,1465,262144,1025,32768,1044,4194304,8388608,41003,8329,8388608,320661,16385,16813,19508,74795,12641576,257,17429,4236436,8389564]

theorem envBound5572 : H12AffineFastState.Bounded env5572 := by
  intro p hp
  have h : env5572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5571_5572 : H12AffineEnvironment.transform 5 16 env5571 = env5572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5571 == env5572) = true)

def env5573 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,65536,1029,262144,1025,32768,1044,4194304,8388608,41003,8329,8388608,320661,16385,16401,19508,74795,12641428,189,17429,4236436,8389120]

theorem envBound5573 : H12AffineFastState.Bounded env5573 := by
  intro p hp
  have h : env5573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5572_5573 : H12AffineEnvironment.transform 7 188 env5572 = env5573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env5572 == env5573) = true)

theorem identity5573 : scanCanonicalize (H12AffineFastState.compose env5573 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50319) := by decide +kernel

theorem selectedBound5573 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5574 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1044,4194304,8388608,41003,8329,8388608,320661,16385,16401,19508,57508,12641428,189,17429,4236436,8389120]

theorem envBound5574 : H12AffineFastState.Bounded env5574 := by
  intro p hp
  have h : env5574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5573_5574 : H12AffineEnvironment.transform 15 50319 env5573 = env5574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50319 env5573 == env5574) = true)

def env5575 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1044,4194304,4235392,41003,8329,4235392,320661,16385,16401,19508,57508,17428,189,17429,4236436,4235904]

theorem envBound5575 : H12AffineFastState.Bounded env5575 := by
  intro p hp
  have h : env5575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5574_5575 : H12AffineEnvironment.transform 22 4235392 env5574 = env5575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235392 env5574 == env5575) = true)

theorem identity5575 : scanCanonicalize (H12AffineFastState.compose env5575 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5575 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env5576 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50319,1029,262144,1025,32768,1029,4194304,4235392,41003,8329,4235392,320644,16385,16384,19493,57508,17413,172,17412,4236421,4235904]

theorem envBound5576 : H12AffineFastState.Bounded env5576 := by
  intro p hp
  have h : env5576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5575_5576 : H12AffineEnvironment.transform 3 1 env5575 = env5576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5575 == env5576) = true)

theorem identity5576 : scanCanonicalize (H12AffineFastState.compose env5576 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound5576 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5577 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,16384,32768,50319,1029,262144,1025,32768,1029,41000,168,41003,8329,168,320644,16385,16384,19493,57508,17413,172,17412,1197,680]

theorem envBound5577 : H12AffineFastState.Bounded env5577 := by
  intro p hp
  have h : env5577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5576_5577 : H12AffineEnvironment.transform 21 41000 env5576 = env5577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env5576 == env5577) = true)

theorem identity5577 : scanCanonicalize (H12AffineFastState.compose env5577 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound5577 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env5578 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1029,8192,1676,32768,33283,1029,262144,1025,32768,1029,41000,168,41003,8329,168,303624,1677,1676,2729,42536,649,172,648,1197,680]

theorem envBound5578 : H12AffineFastState.Bounded env5578 := by
  intro p hp
  have h : env5578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5577_5578 : H12AffineEnvironment.transform 13 1676 env5577 = env5578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env5577 == env5578) = true)

theorem identity5578 : scanCanonicalize (H12AffineFastState.compose env5578 (packedSelected [1,3,4,9,11,20,23] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5578 : packedSelected [1,3,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env5579 : List Nat := [2,4,8,1,32,1,128,173,0,1024,2048,1029,8192,1164,32768,32771,1029,262144,1025,32768,1029,41000,168,41003,8329,168,303112,1165,1164,2217,42024,137,172,136,1197,168]

theorem envBound5579 : H12AffineFastState.Bounded env5579 := by
  intro p hp
  have h : env5579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5578_5579 : H12AffineEnvironment.transform 8 0 env5578 = env5579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5578 == env5579) = true)

theorem identity5579 : scanCanonicalize (H12AffineFastState.compose env5579 (packedSelected [0,2,6,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 41088) := by decide +kernel

theorem selectedBound5579 : packedSelected [0,2,6,10,12,13] rootPS < 2^1333 := by decide +kernel

def env5580 : List Nat := [2,4,8,1,32,1,128,173,0,1024,2048,1029,8192,1164,32768,32771,1029,41088,1025,32768,1029,41000,168,41003,8329,168,136,1165,1164,2217,42024,137,172,136,1197,168]

theorem envBound5580 : H12AffineFastState.Bounded env5580 := by
  intro p hp
  have h : env5580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5579_5580 : H12AffineEnvironment.transform 17 41088 env5579 = env5580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41088 env5579 == env5580) = true)

theorem identity5580 : scanCanonicalize (H12AffineFastState.compose env5580 (packedSelected [0,2,3,4,6,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5580 : packedSelected [0,2,3,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env5581 : List Nat := [2,4,8,1,32,1,128,173,0,1024,2048,1029,1063,1164,32768,32771,1029,33959,1025,32768,1029,33807,168,33804,1198,168,136,1165,1164,2217,32783,137,172,136,1197,168]

theorem envBound5581 : H12AffineFastState.Bounded env5581 := by
  intro p hp
  have h : env5581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5580_5581 : H12AffineEnvironment.transform 12 1063 env5580 = env5581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5580 == env5581) = true)

theorem identity5581 : scanCanonicalize (H12AffineFastState.compose env5581 (packedSelected [0,2,4,5,6,7,8,9,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound5581 : packedSelected [0,2,4,5,6,7,8,9,17,20] rootPS < 2^1333 := by decide +kernel

def env5582 : List Nat := [2,4,8,1,32,1,128,173,0,1024,2048,1029,1063,1164,1071,1068,1029,136,1025,1071,1029,32,168,35,1198,168,136,1165,1164,2217,1056,137,172,136,1197,168]

theorem envBound5582 : H12AffineFastState.Bounded env5582 := by
  intro p hp
  have h : env5582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5581_5582 : H12AffineEnvironment.transform 14 1071 env5581 = env5582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env5581 == env5582) = true)

theorem identity5582 : scanCanonicalize (H12AffineFastState.compose env5582 (packedSelected [0,2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5582 : packedSelected [0,2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env5583 : List Nat := [2,4,8,1,32,1,128,173,0,15,2048,10,40,131,32,35,10,136,14,32,10,32,168,35,161,168,136,130,131,2217,47,137,172,136,162,168]

theorem envBound5583 : H12AffineFastState.Bounded env5583 := by
  intro p hp
  have h : env5583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5582_5583 : H12AffineEnvironment.transform 9 15 env5582 = env5583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5582 == env5583) = true)

theorem identity5583 : scanCanonicalize (H12AffineFastState.compose env5583 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound5583 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env5584 : List Nat := [2,4,8,1,32,1,128,173,0,15,42,10,40,131,32,35,10,136,14,32,10,32,168,35,161,168,136,130,131,131,47,137,172,136,162,168]

theorem envBound5584 : H12AffineFastState.Bounded env5584 := by
  intro p hp
  have h : env5584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5583_5584 : H12AffineEnvironment.transform 10 42 env5583 = env5584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env5583 == env5584) = true)

theorem identity5584 : scanCanonicalize (H12AffineFastState.compose env5584 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound5584 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5585 : List Nat := [2,4,8,1,32,1,3,46,0,15,42,10,40,0,32,35,10,11,14,32,10,32,43,35,34,43,11,1,0,0,47,10,47,11,33,43]

theorem envBound5585 : H12AffineFastState.Bounded env5585 := by
  intro p hp
  have h : env5585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5584_5585 : H12AffineEnvironment.transform 6 3 env5584 = env5585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env5584 == env5585) = true)

theorem identity5585 : scanCanonicalize (H12AffineFastState.compose env5585 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5585 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5586 : List Nat := [2,4,8,1,10,1,3,4,0,15,0,10,2,0,10,9,10,11,14,10,10,10,1,9,8,1,11,1,0,0,5,10,5,11,11,1]

theorem envBound5586 : H12AffineFastState.Bounded env5586 := by
  intro p hp
  have h : env5586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5585_5586 : H12AffineEnvironment.transform 4 10 env5585 = env5586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5585 == env5586) = true)

theorem identity5586 : scanCanonicalize (H12AffineFastState.compose env5586 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5587 : List Nat := [2,4,2,1,0,1,3,4,0,5,0,0,2,0,0,3,0,1,4,0,0,0,1,3,2,1,1,1,0,0,5,0,5,1,1,1]

theorem envBound5587 : H12AffineFastState.Bounded env5587 := by
  intro p hp
  have h : env5587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5586_5587 : H12AffineEnvironment.transform 2 2 env5586 = env5587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5586 == env5587) = true)

theorem identity5587 : scanCanonicalize (H12AffineFastState.compose env5587 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5587 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5588 : List Nat := [2,0,2,1,0,1,3,0,0,1,0,0,2,0,0,3,0,1,0,0,0,0,1,3,2,1,1,1,0,0,1,0,1,1,1,1]

theorem envBound5588 : H12AffineFastState.Bounded env5588 := by
  intro p hp
  have h : env5588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5587_5588 : H12AffineEnvironment.transform 1 0 env5587 = env5588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5587 == env5588) = true)

def env5589 : List Nat := [2,4,8,16,32,16,128,188,512,1024,2048,1044,8192,16384,32768,50319,1029,262144,1025,32768,1044,4194304,4235393,41003,8329,4235393,320661,16385,16401,19508,57508,17429,189,17429,4236436,4235905]

theorem envBound5589 : H12AffineFastState.Bounded env5589 := by
  intro p hp
  have h : env5589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5574_5589 : H12AffineEnvironment.transform 22 4235393 env5574 = env5589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235393 env5574 == env5589) = true)

theorem identity5589 : scanCanonicalize (H12AffineFastState.compose env5589 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound5589 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5590 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,32768,50231,1029,262144,1025,32768,1044,4194304,4235321,41003,8241,4235321,320557,16385,16401,19508,57372,17429,5,17429,4236332,4235833]

theorem envBound5590 : H12AffineFastState.Bounded env5590 := by
  intro p hp
  have h : env5590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5589_5590 : H12AffineEnvironment.transform 6 56 env5589 = env5590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env5589 == env5590) = true)

theorem identity5590 : scanCanonicalize (H12AffineFastState.compose env5590 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound5590 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5591 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,8217,25646,1029,262144,1025,8217,1044,4194304,4194336,50,8241,4194336,279604,16385,16401,19508,16389,17429,5,17429,4195381,4194848]

theorem envBound5591 : H12AffineFastState.Bounded env5591 := by
  intro p hp
  have h : env5591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5590_5591 : H12AffineEnvironment.transform 14 8217 env5590 = env5591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env5590 == env5591) = true)

theorem identity5591 : scanCanonicalize (H12AffineFastState.compose env5591 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,15] rootPS)) = affineNative (2^(17+1) ^^^ 26134) := by decide +kernel

theorem selectedBound5591 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env5592 : List Nat := [2,4,8,16,32,16,56,4,512,1024,2048,1044,8192,16384,8217,25646,1029,26134,1025,8217,1044,4194304,4194336,50,8241,4194336,8738,16385,16401,19508,16389,17429,5,17429,4195381,4194848]

theorem envBound5592 : H12AffineFastState.Bounded env5592 := by
  intro p hp
  have h : env5592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5591_5592 : H12AffineEnvironment.transform 17 26134 env5591 = env5592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26134 env5591 == env5592) = true)

theorem identity5592 : scanCanonicalize (H12AffineFastState.compose env5592 (packedSelected [4,9,13,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5592 : packedSelected [4,9,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5593 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,16384,8200,25646,1029,26119,1025,8200,1029,4194304,4194336,35,8224,4194336,8738,16385,16384,19493,16389,17412,5,17412,4195364,4194848]

theorem envBound5593 : H12AffineFastState.Bounded env5593 := by
  intro p hp
  have h : env5593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5592_5593 : H12AffineEnvironment.transform 3 1 env5592 = env5593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5592 == env5593) = true)

theorem identity5593 : scanCanonicalize (H12AffineFastState.compose env5593 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 10755) := by decide +kernel

theorem selectedBound5593 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env5594 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,16384,8200,25646,1029,26119,1025,8200,1029,10755,10787,35,8224,10787,8738,16385,16384,19493,16389,17412,5,17412,11815,10275]

theorem envBound5594 : H12AffineFastState.Bounded env5594 := by
  intro p hp
  have h : env5594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5593_5594 : H12AffineEnvironment.transform 21 10755 env5593 = env5594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10755 env5593 == env5594) = true)

theorem identity5594 : scanCanonicalize (H12AffineFastState.compose env5594 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(13+1) ^^^ 11271) := by decide +kernel

theorem selectedBound5594 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env5595 : List Nat := [2,4,8,1,32,1,41,4,512,1024,2048,1029,8192,11271,8200,2089,1029,2560,1025,8200,1029,10755,10787,35,8224,10787,8738,11270,11271,8226,11266,10243,5,10243,11815,10275]

theorem envBound5595 : H12AffineFastState.Bounded env5595 := by
  intro p hp
  have h : env5595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5594_5595 : H12AffineEnvironment.transform 13 11271 env5594 = env5595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11271 env5594 == env5595) = true)

theorem identity5595 : scanCanonicalize (H12AffineFastState.compose env5595 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound5595 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env5596 : List Nat := [2,4,8,1,32,1,41,4,512,36,2048,33,8192,10275,8200,2089,33,2560,37,8200,33,10755,10787,35,8224,10787,8738,10274,10275,8226,10278,10243,5,10243,10755,10275]

theorem envBound5596 : H12AffineFastState.Bounded env5596 := by
  intro p hp
  have h : env5596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5595_5596 : H12AffineEnvironment.transform 9 36 env5595 = env5596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env5595 == env5596) = true)

theorem identity5596 : scanCanonicalize (H12AffineFastState.compose env5596 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound5596 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env5597 : List Nat := [2,4,8,1,32,1,41,4,512,36,11,33,8192,8232,8200,34,33,523,37,8200,33,8712,8744,35,8224,8744,8738,8233,8232,8226,8237,8200,5,8200,8712,8232]

theorem envBound5597 : H12AffineFastState.Bounded env5597 := by
  intro p hp
  have h : env5597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5596_5597 : H12AffineEnvironment.transform 10 11 env5596 = env5597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env5596 == env5597) = true)

theorem identity5597 : scanCanonicalize (H12AffineFastState.compose env5597 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound5597 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env5598 : List Nat := [2,4,8,1,32,1,41,4,33,36,11,33,8192,8232,8200,34,33,42,37,8200,33,8233,8201,35,8224,8201,8195,8233,8232,8226,8237,8200,5,8200,8233,8232]

theorem envBound5598 : H12AffineFastState.Bounded env5598 := by
  intro p hp
  have h : env5598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5597_5598 : H12AffineEnvironment.transform 8 33 env5597 = env5598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5597 == env5598) = true)

theorem identity5598 : scanCanonicalize (H12AffineFastState.compose env5598 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound5598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5599 : List Nat := [2,4,8,1,32,1,41,4,33,36,11,33,2,42,10,34,33,42,37,10,33,43,11,35,34,11,1,43,42,32,47,10,5,10,43,42]

theorem envBound5599 : H12AffineFastState.Bounded env5599 := by
  intro p hp
  have h : env5599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5598_5599 : H12AffineEnvironment.transform 12 2 env5598 = env5599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env5598 == env5599) = true)

theorem identity5599 : scanCanonicalize (H12AffineFastState.compose env5599 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5600 : List Nat := [2,4,3,1,32,1,34,4,33,36,0,33,2,33,1,34,33,33,37,1,33,32,0,35,34,0,1,32,33,32,36,1,5,1,32,33]

theorem envBound5600 : H12AffineFastState.Bounded env5600 := by
  intro p hp
  have h : env5600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5599_5600 : H12AffineEnvironment.transform 2 3 env5599 = env5600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5599 == env5600) = true)

theorem identity5600 : scanCanonicalize (H12AffineFastState.compose env5600 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5600 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5601 : List Nat := [2,4,3,1,1,1,3,4,0,5,0,0,2,0,1,3,0,0,4,1,0,1,0,2,3,0,1,1,0,1,5,1,5,1,1,0]

theorem envBound5601 : H12AffineFastState.Bounded env5601 := by
  intro p hp
  have h : env5601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5600_5601 : H12AffineEnvironment.transform 4 1 env5600 = env5601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5600 == env5601) = true)

def env5602 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1044,4194304,8388608,41003,8329,8388608,320661,16385,16400,19508,74795,12641429,188,17429,4236436,8389121]

theorem envBound5602 : H12AffineFastState.Bounded env5602 := by
  intro p hp
  have h : env5602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5572_5602 : H12AffineEnvironment.transform 7 189 env5572 = env5602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env5572 == env5602) = true)

theorem identity5602 : scanCanonicalize (H12AffineFastState.compose env5602 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound5602 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env5603 : List Nat := [2,4,8,16,32,16,128,189,512,1024,2048,1044,8192,16384,32768,65536,1028,262144,1025,32768,1044,4194304,4194353,41003,8329,4194353,320661,16385,16400,19508,74795,58532,188,17429,4236436,4194864]

theorem envBound5603 : H12AffineFastState.Bounded env5603 := by
  intro p hp
  have h : env5603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5602_5603 : H12AffineEnvironment.transform 22 4194353 env5602 = env5603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env5602 == env5603) = true)

def env5604 : List Nat := [2,4,8,0,32,0,128,173,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41003,8329,4194337,320645,16385,16384,19492,74795,58532,172,17413,4236420,4194848]

theorem envBound5604 : H12AffineFastState.Bounded env5604 := by
  intro p hp
  have h : env5604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5603_5604 : H12AffineEnvironment.transform 3 0 env5603 = env5604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5603 == env5604) = true)

theorem identity5604 : scanCanonicalize (H12AffineFastState.compose env5604 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5604 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5605 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,65536,1028,262144,1025,32768,1028,4194304,4194337,41003,8225,4194337,320557,16385,16384,19492,74795,58380,4,17413,4236332,4194848]

theorem envBound5605 : H12AffineFastState.Bounded env5605 := by
  intro p hp
  have h : env5605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5604_5605 : H12AffineEnvironment.transform 6 40 env5604 = env5605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5604 == env5605) = true)

theorem identity5605 : scanCanonicalize (H12AffineFastState.compose env5605 (packedSelected [2,3,5,7,10,11,18,20,27] rootPS)) = affineNative (2^(17+1) ^^^ 117767) := by decide +kernel

theorem selectedBound5605 : packedSelected [2,3,5,7,10,11,18,20,27] rootPS < 2^1333 := by decide +kernel

def env5606 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,8192,16384,32768,65536,1028,117767,1025,32768,1028,4194304,4194337,41003,8225,4194337,75818,16385,16384,19492,74795,58380,4,17413,4236332,4194848]

theorem envBound5606 : H12AffineFastState.Bounded env5606 := by
  intro p hp
  have h : env5606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5605_5606 : H12AffineEnvironment.transform 17 117767 env5605 = env5606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 117767 env5605 == env5606) = true)

theorem identity5606 : scanCanonicalize (H12AffineFastState.compose env5606 (packedSelected [0,4,7,9,11,12,13,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound5606 : packedSelected [0,4,7,9,11,12,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5607 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,65536,1028,117767,1025,32768,1028,4194304,4194337,34818,2056,4194337,65539,16385,16384,19492,68610,52261,4,17413,4230149,4194848]

theorem envBound5607 : H12AffineFastState.Bounded env5607 := by
  intro p hp
  have h : env5607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5606_5607 : H12AffineEnvironment.transform 12 2089 env5606 = env5607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env5606 == env5607) = true)

theorem identity5607 : scanCanonicalize (H12AffineFastState.compose env5607 (packedSelected [0,1,3,5,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 98339) := by decide +kernel

theorem selectedBound5607 : packedSelected [0,1,3,5,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env5608 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,65536,1028,117767,1025,32768,1028,98339,98306,34818,2056,98306,65539,16385,16384,19492,68610,52261,4,17413,68646,98819]

theorem envBound5608 : H12AffineFastState.Bounded env5608 := by
  intro p hp
  have h : env5608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5607_5608 : H12AffineEnvironment.transform 21 98339 env5607 = env5608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98339 env5607 == env5608) = true)

theorem identity5608 : scanCanonicalize (H12AffineFastState.compose env5608 (packedSelected [2,4,6,7,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 1543) := by decide +kernel

theorem selectedBound5608 : packedSelected [2,4,6,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env5609 : List Nat := [2,4,8,0,32,0,40,5,512,1024,2048,1028,2089,16384,32768,1543,1028,51712,1025,32768,1028,34340,34309,34818,2056,34309,1540,16385,16384,19492,2565,52261,4,17413,2593,33796]

theorem envBound5609 : H12AffineFastState.Bounded env5609 := by
  intro p hp
  have h : env5609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5608_5609 : H12AffineEnvironment.transform 15 1543 env5608 = env5609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1543 env5608 == env5609) = true)

theorem identity5609 : scanCanonicalize (H12AffineFastState.compose env5609 (packedSelected [0,1,3,6,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5609 : packedSelected [0,1,3,6,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env5610 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,16384,32768,1543,1028,51712,1025,32768,1028,34319,34309,34818,2056,34309,1540,16385,16384,19471,2565,52238,4,17413,2570,33796]

theorem envBound5610 : H12AffineFastState.Bounded env5610 := by
  intro p hp
  have h : env5610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5609_5610 : H12AffineEnvironment.transform 4 11 env5609 = env5610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5609 == env5610) = true)

theorem identity5610 : scanCanonicalize (H12AffineFastState.compose env5610 (packedSelected [0,1,3,9,11,17] rootPS)) = affineNative (2^(13+1) ^^^ 1038) := by decide +kernel

theorem selectedBound5610 : packedSelected [0,1,3,9,11,17] rootPS < 2^1333 := by decide +kernel

def env5611 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,1038,32768,1543,1028,36366,1025,32768,1028,34319,34309,34818,2056,34309,1540,1039,1038,2049,2565,34816,4,11,2570,33796]

theorem envBound5611 : H12AffineFastState.Bounded env5611 := by
  intro p hp
  have h : env5611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5610_5611 : H12AffineEnvironment.transform 13 1038 env5610 = env5611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1038 env5610 == env5611) = true)

theorem identity5611 : scanCanonicalize (H12AffineFastState.compose env5611 (packedSelected [1,2,4,5,6,9] rootPS)) = affineNative (2^(14+1) ^^^ 1540) := by decide +kernel

theorem selectedBound5611 : packedSelected [1,2,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env5612 : List Nat := [2,4,8,0,11,0,3,5,512,1024,2048,1028,2050,1038,1540,1543,1028,2058,1025,1540,1028,11,1,3590,2056,1,1540,1039,1038,2049,2565,3588,4,11,2570,512]

theorem envBound5612 : H12AffineFastState.Bounded env5612 := by
  intro p hp
  have h : env5612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5611_5612 : H12AffineEnvironment.transform 14 1540 env5611 = env5612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1540 env5611 == env5612) = true)

theorem identity5612 : scanCanonicalize (H12AffineFastState.compose env5612 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound5612 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env5613 : List Nat := [2,4,8,0,11,0,3,5,512,1024,523,1028,521,1038,1540,1543,1028,513,1025,1540,1028,11,1,1037,515,1,1540,1039,1038,522,14,1039,4,11,1,512]

theorem envBound5613 : H12AffineFastState.Bounded env5613 := by
  intro p hp
  have h : env5613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5612_5613 : H12AffineEnvironment.transform 10 523 env5612 = env5613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env5612 == env5613) = true)

def env5614 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,65536,1028,262144,1025,32768,1029,4194304,4194336,41003,8329,4194336,320644,16385,16385,19493,74795,58532,173,17412,4236421,4194849]

theorem envBound5614 : H12AffineFastState.Bounded env5614 := by
  intro p hp
  have h : env5614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5603_5614 : H12AffineEnvironment.transform 3 1 env5603 = env5614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5603 == env5614) = true)

theorem identity5614 : scanCanonicalize (H12AffineFastState.compose env5614 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 25734) := by decide +kernel

theorem selectedBound5614 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env5615 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,262144,1025,32768,1029,4194304,4194336,41003,8329,4194336,320644,16385,16385,19493,16557,58532,173,17412,4236421,4194849]

theorem envBound5615 : H12AffineFastState.Bounded env5615 := by
  intro p hp
  have h : env5615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5614_5615 : H12AffineEnvironment.transform 15 25734 env5614 = env5615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25734 env5614 == env5615) = true)

theorem identity5615 : scanCanonicalize (H12AffineFastState.compose env5615 (packedSelected [1,5,8,13,18,21,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5615 : packedSelected [1,5,8,13,18,21,23,24] rootPS < 2^1333 := by decide +kernel

def env5616 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,2081,1025,32768,1029,4194304,4194336,41003,8329,4194336,60581,16385,16385,19493,16557,58532,173,17412,4236421,4194849]

theorem envBound5616 : H12AffineFastState.Bounded env5616 := by
  intro p hp
  have h : env5616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5615_5616 : H12AffineEnvironment.transform 17 2081 env5615 = env5616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5615 == env5616) = true)

theorem identity5616 : scanCanonicalize (H12AffineFastState.compose env5616 (packedSelected [1,2,6,8,11,17,21] rootPS)) = affineNative (2^(21+1) ^^^ 9870) := by decide +kernel

theorem selectedBound5616 : packedSelected [1,2,6,8,11,17,21] rootPS < 2^1333 := by decide +kernel

def env5617 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,32768,25734,1028,2081,1025,32768,1029,9870,9902,41003,8329,9902,60581,16385,16385,19493,16557,58532,173,17412,33291,9391]

theorem envBound5617 : H12AffineFastState.Bounded env5617 := by
  intro p hp
  have h : env5617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5616_5617 : H12AffineEnvironment.transform 21 9870 env5616 = env5617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9870 env5616 == env5617) = true)

theorem identity5617 : scanCanonicalize (H12AffineFastState.compose env5617 (packedSelected [3,4,5,7,9,10,13,17,27] rootPS)) = affineNative (2^(14+1) ^^^ 1702) := by decide +kernel

theorem selectedBound5617 : packedSelected [3,4,5,7,9,10,13,17,27] rootPS < 2^1333 := by decide +kernel

def env5618 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,8192,16384,1702,25734,1028,2081,1025,1702,1029,9870,9902,9869,8329,9902,27139,16385,16385,19493,16557,25090,173,17412,1197,9391]

theorem envBound5618 : H12AffineFastState.Bounded env5618 := by
  intro p hp
  have h : env5618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5617_5618 : H12AffineEnvironment.transform 14 1702 env5617 = env5618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1702 env5617 == env5618) = true)

theorem identity5618 : scanCanonicalize (H12AffineFastState.compose env5618 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1063) := by decide +kernel

theorem selectedBound5618 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env5619 : List Nat := [2,4,8,1,32,1,128,172,512,1024,2048,1029,1063,16384,1702,16545,1028,2081,1025,1702,1029,681,649,682,1198,649,20004,16385,16385,19493,16557,17957,173,17412,1197,136]

theorem envBound5619 : H12AffineFastState.Bounded env5619 := by
  intro p hp
  have h : env5619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5618_5619 : H12AffineEnvironment.transform 12 1063 env5618 = env5619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1063 env5618 == env5619) = true)

theorem identity5619 : scanCanonicalize (H12AffineFastState.compose env5619 (packedSelected [3,6,8,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5619 : packedSelected [3,6,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env5620 : List Nat := [2,4,8,1,32,1,128,172,137,1024,2048,1029,1063,16384,1071,16545,1028,2081,1025,1071,1029,32,0,35,1198,0,19629,16385,16385,19493,16557,17580,173,17412,1197,136]

theorem envBound5620 : H12AffineFastState.Bounded env5620 := by
  intro p hp
  have h : env5620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5619_5620 : H12AffineEnvironment.transform 8 137 env5619 = env5620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5619 == env5620) = true)

theorem identity5620 : scanCanonicalize (H12AffineFastState.compose env5620 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 2090) := by decide +kernel

theorem selectedBound5620 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5621 : List Nat := [2,4,8,1,32,1,128,172,137,1024,2048,1029,1063,2090,1071,2187,1028,2081,1025,1071,1029,32,0,35,1198,0,1159,2091,2091,1039,2183,3206,173,3118,1197,136]

theorem envBound5621 : H12AffineFastState.Bounded env5621 := by
  intro p hp
  have h : env5621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5620_5621 : H12AffineEnvironment.transform 13 2090 env5620 = env5621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2090 env5620 == env5621) = true)

theorem identity5621 : scanCanonicalize (H12AffineFastState.compose env5621 (packedSelected [4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1067) := by decide +kernel

theorem selectedBound5621 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env5622 : List Nat := [2,4,8,1,32,1,128,172,137,1024,1067,1029,1063,1025,1071,1184,1028,1034,1025,1071,1029,32,0,35,1198,0,1159,1024,1024,1039,1196,173,173,5,1197,136]

theorem envBound5622 : H12AffineFastState.Bounded env5622 := by
  intro p hp
  have h : env5622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5621_5622 : H12AffineEnvironment.transform 10 1067 env5621 = env5622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1067 env5621 == env5622) = true)

theorem identity5622 : scanCanonicalize (H12AffineFastState.compose env5622 (packedSelected [1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound5622 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env5623 : List Nat := [2,4,8,1,32,1,13,33,4,1024,1067,1029,1063,1025,1071,1069,1028,1034,1025,1071,1029,32,0,35,1059,0,1034,1024,1024,1039,1057,32,32,5,1056,5]

theorem envBound5623 : H12AffineFastState.Bounded env5623 := by
  intro p hp
  have h : env5623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5622_5623 : H12AffineEnvironment.transform 6 13 env5622 = env5623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env5622 == env5623) = true)

theorem identity5623 : scanCanonicalize (H12AffineFastState.compose env5623 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5623 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5624 : List Nat := [2,4,8,1,32,1,13,33,4,14,37,11,41,15,33,35,10,4,15,33,11,32,0,35,45,0,4,14,14,1,47,32,32,5,46,5]

theorem envBound5624 : H12AffineFastState.Bounded env5624 := by
  intro p hp
  have h : env5624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5623_5624 : H12AffineEnvironment.transform 9 14 env5623 = env5624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5623 == env5624) = true)

theorem identity5624 : scanCanonicalize (H12AffineFastState.compose env5624 (packedSelected [3,4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound5624 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env5625 : List Nat := [2,4,6,1,32,1,3,33,4,0,37,5,39,1,33,35,4,4,1,33,5,32,0,35,35,0,4,0,0,1,33,32,32,5,32,5]

theorem envBound5625 : H12AffineFastState.Bounded env5625 := by
  intro p hp
  have h : env5625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5624_5625 : H12AffineEnvironment.transform 2 6 env5624 = env5625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env5624 == env5625) = true)

theorem identity5625 : scanCanonicalize (H12AffineFastState.compose env5625 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound5625 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env5626 : List Nat := [2,4,6,1,5,1,3,4,4,0,0,5,2,1,4,6,4,4,1,4,5,5,0,6,6,0,4,0,0,1,4,5,5,5,5,5]

theorem envBound5626 : H12AffineFastState.Bounded env5626 := by
  intro p hp
  have h : env5626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5625_5626 : H12AffineEnvironment.transform 4 5 env5625 = env5626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env5625 == env5626) = true)

def leafEnv5626 : List Nat := [2,4,6,1,5,1,3,4,4,0,0,5,2,1,4,6,4,4,1,4,5,5,0,6,4,6,1,0,4,0,0,1,4,5,5,5,4,3,5,5,1,0,0]

def active5626 : List Nat := [0,1]

def tree5626 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5626 : H12WitnessSearch.Good tree5626 := H12GlobalWitnessIndex.good

theorem leafIdentity5626 : H12AffineFastState.composeSystem env5626 rootObs = leafEnv5626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5626 rootObs == leafEnv5626) = true)

theorem terminalChecked5626 : H12PackedTerminal.terminalCheckFast leafEnv5626 active5626 tree5626 = true := by decide +kernel

def env5627 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,8388608,41003,8329,8388609,320661,16385,16812,19508,74795,12641577,257,17429,4236437,8389565]

theorem envBound5627 : H12AffineFastState.Bounded env5627 := by
  intro p hp
  have h : env5627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5571_5627 : H12AffineEnvironment.transform 5 17 env5571 = env5627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5571 == env5627) = true)

theorem identity5627 : scanCanonicalize (H12AffineFastState.compose env5627 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound5627 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,4194304,445,41003,8329,444,320661,16385,16812,19508,74795,4252820,257,17429,4236437,512]

theorem envBound5628 : H12AffineFastState.Bounded env5628 := by
  intro p hp
  have h : env5628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5627_5628 : H12AffineEnvironment.transform 22 445 env5627 = env5628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env5627 == env5628) = true)

theorem identity5628 : scanCanonicalize (H12AffineFastState.compose env5628 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound5628 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,32768,65536,1465,262144,1025,32768,1045,41349,445,41003,8329,444,320661,16385,16812,19508,74795,17681,257,17429,1296,512]

theorem envBound5629 : H12AffineFastState.Bounded env5629 := by
  intro p hp
  have h : env5629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5628_5629 : H12AffineEnvironment.transform 21 41349 env5628 = env5629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env5628 == env5629) = true)

theorem identity5629 : scanCanonicalize (H12AffineFastState.compose env5629 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound5629 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5630 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,65536,1465,262144,1025,26260,1045,18193,445,18111,8329,444,262657,16385,16812,19508,74795,17681,257,17429,1296,512]

theorem envBound5630 : H12AffineFastState.Bounded env5630 := by
  intro p hp
  have h : env5630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5629_5630 : H12AffineEnvironment.transform 14 26260 env5629 = env5630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env5629 == env5630) = true)

theorem identity5630 : scanCanonicalize (H12AffineFastState.compose env5630 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 25751) := by decide +kernel

theorem selectedBound5630 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25751,1465,262144,1025,26260,1045,18193,445,18111,8329,444,262657,16385,16812,19508,16572,17681,257,17429,1296,512]

theorem envBound5631 : H12AffineFastState.Bounded env5631 := by
  intro p hp
  have h : env5631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5630_5631 : H12AffineEnvironment.transform 15 25751 env5630 = env5631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25751 env5630 == env5631) = true)

theorem identity5631 : scanCanonicalize (H12AffineFastState.compose env5631 (packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound5631 : packedSelected [0,1,3,8,10,12,13,15,17,18,23,27,28] rootPS < 2^1333 := by decide +kernel

def env5632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,16384,26260,25751,1465,2341,1025,26260,1045,18193,445,18111,8329,444,2852,16385,16812,19508,16572,17681,257,17429,1296,512]

theorem envBound5632 : H12AffineFastState.Bounded env5632 := by
  intro p hp
  have h : env5632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5631_5632 : H12AffineEnvironment.transform 17 2341 env5631 = env5632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env5631 == env5632) = true)

theorem identity5632 : scanCanonicalize (H12AffineFastState.compose env5632 (packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound5632 : packedSelected [1,3,4,7,9,12,13,15,17,27] rootPS < 2^1333 := by decide +kernel

def env5633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1045,8192,1841,8613,9126,1465,2341,1025,8613,1045,32,445,398,8329,444,2852,1840,1693,2821,1933,544,257,804,1296,512]

theorem envBound5633 : H12AffineFastState.Bounded env5633 := by
  intro p hp
  have h : env5633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5632_5633 : H12AffineEnvironment.transform 13 1841 env5632 = env5633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env5632 == env5633) = true)

theorem identity5633 : scanCanonicalize (H12AffineFastState.compose env5633 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5633 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env5634 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1045,8192,1841,8460,8975,1296,2341,1025,8460,1045,32,276,295,8224,277,2852,1840,1588,2821,1828,544,257,804,1296,512]

theorem envBound5634 : H12AffineFastState.Bounded env5634 := by
  intro p hp
  have h : env5634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5633_5634 : H12AffineEnvironment.transform 6 41 env5633 = env5634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5633 == env5634) = true)

theorem identity5634 : scanCanonicalize (H12AffineFastState.compose env5634 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5634 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5635 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1045,8192,1588,8201,8714,1045,2080,1025,8201,1045,32,17,34,8224,16,2593,1589,1588,2560,1569,544,4,545,1045,512]

theorem envBound5635 : H12AffineFastState.Bounded env5635 := by
  intro p hp
  have h : env5635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5634_5635 : H12AffineEnvironment.transform 7 5 env5634 = env5635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5634 == env5635) = true)

theorem identity5635 : scanCanonicalize (H12AffineFastState.compose env5635 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5635 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5636 : List Nat := [2,4,8,16,32,17,41,5,0,1024,2048,1045,8192,1076,8201,8202,1045,2080,1025,8201,1045,32,17,34,8224,16,2081,1077,1076,2048,1057,32,4,33,1045,0]

theorem envBound5636 : H12AffineFastState.Bounded env5636 := by
  intro p hp
  have h : env5636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5635_5636 : H12AffineEnvironment.transform 8 0 env5635 = env5636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5635 == env5636) = true)

theorem identity5636 : scanCanonicalize (H12AffineFastState.compose env5636 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 3111) := by decide +kernel

theorem selectedBound5636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5637 : List Nat := [2,4,8,16,32,17,41,5,0,1024,2048,1045,3111,1076,3118,3117,1045,2080,1025,3118,1045,32,17,34,3079,16,2081,1077,1076,2048,1057,32,4,33,1045,0]

theorem envBound5637 : H12AffineFastState.Bounded env5637 := by
  intro p hp
  have h : env5637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5636_5637 : H12AffineEnvironment.transform 12 3111 env5636 = env5637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3111 env5636 == env5637) = true)

theorem identity5637 : scanCanonicalize (H12AffineFastState.compose env5637 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound5637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5638 : List Nat := [2,4,8,16,32,17,41,5,0,47,2048,58,2056,27,2049,2050,58,2080,46,2049,58,32,17,34,2088,16,2081,26,27,2048,14,32,4,33,58,0]

theorem envBound5638 : H12AffineFastState.Bounded env5638 := by
  intro p hp
  have h : env5638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5637_5638 : H12AffineEnvironment.transform 9 47 env5637 = env5638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env5637 == env5638) = true)

theorem identity5638 : scanCanonicalize (H12AffineFastState.compose env5638 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound5638 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5639 : List Nat := [2,4,8,16,26,17,19,5,0,21,2048,0,2056,27,2049,2050,0,2074,20,2049,0,26,17,24,2066,16,2075,26,27,2048,14,26,4,27,0,0]

theorem envBound5639 : H12AffineFastState.Bounded env5639 := by
  intro p hp
  have h : env5639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5638_5639 : H12AffineEnvironment.transform 4 26 env5638 = env5639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env5638 == env5639) = true)

theorem identity5639 : scanCanonicalize (H12AffineFastState.compose env5639 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound5639 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env5640 : List Nat := [2,4,8,16,26,17,19,5,0,21,27,0,19,27,26,25,0,1,20,26,0,26,17,24,9,16,0,26,27,27,14,26,4,27,0,0]

theorem envBound5640 : H12AffineFastState.Bounded env5640 := by
  intro p hp
  have h : env5640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5639_5640 : H12AffineEnvironment.transform 10 27 env5639 = env5640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env5639 == env5640) = true)

def env5641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849105,16385,16893,547952,598058,12644669,525568,545873,4239489,8914925]

theorem envBound5641 : H12AffineFastState.Bounded env5641 := by
  intro p hp
  have h : env5641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5517_5641 : H12AffineEnvironment.transform 20 4097 env5517 = env5641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5517 == env5641) = true)

def env5642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,12644669,256,20561,4239489,8389613]

theorem envBound5642 : H12AffineFastState.Bounded env5642 := by
  intro p hp
  have h : env5642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5641_5642 : H12AffineEnvironment.transform 18 1024 env5641 = env5642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5641 == env5642) = true)

theorem identity5642 : scanCanonicalize (H12AffineFastState.compose env5642 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 61908) := by decide +kernel

theorem selectedBound5642 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,61908,8388608,41003,8329,8388689,323793,16385,16893,22640,74794,8388841,256,20561,16725,8389613]

theorem envBound5643 : H12AffineFastState.Bounded env5643 := by
  intro p hp
  have h : env5643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5642_5643 : H12AffineEnvironment.transform 21 61908 env5642 = env5643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 61908 env5642 == env5643) = true)

def env5644 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,61828,8388608,41003,8329,8388609,323713,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5644 : H12AffineFastState.Bounded env5644 := by
  intro p hp
  have h : env5644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5643_5644 : H12AffineEnvironment.transform 5 16 env5643 = env5644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5643 == env5644) = true)

def env5645 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,262144,1024,8352,4097,20772,8388608,139,8329,8388609,282657,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5645 : H12AffineFastState.Bounded env5645 := by
  intro p hp
  have h : env5645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5644_5645 : H12AffineEnvironment.transform 14 8352 env5644 = env5645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env5644 == env5645) = true)

theorem identity5645 : scanCanonicalize (H12AffineFastState.compose env5645 (packedSelected [0,9,13,17,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 96679) := by decide +kernel

theorem selectedBound5645 : packedSelected [0,9,13,17,22,27] rootPS < 2^1333 := by decide +kernel

def env5646 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,96679,1024,8352,4097,20772,8388608,139,8329,8388609,76166,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5646 : H12AffineFastState.Bounded env5646 := by
  intro p hp
  have h : env5646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5645_5646 : H12AffineEnvironment.transform 17 96679 env5645 = env5646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96679 env5645 == env5646) = true)

theorem identity5646 : scanCanonicalize (H12AffineFastState.compose env5646 (packedSelected [0,1,3,4,7,11,13,17,18,22,23,24,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 73874) := by decide +kernel

theorem selectedBound5646 : packedSelected [0,1,3,4,7,11,13,17,18,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5647 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8352,65536,4525,96679,1024,8352,4097,20772,73874,139,8329,73875,76166,16385,16813,22560,74794,73771,256,20481,16645,74543]

theorem envBound5647 : H12AffineFastState.Bounded env5647 := by
  intro p hp
  have h : env5647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5646_5647 : H12AffineEnvironment.transform 22 73874 env5646 = env5647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73874 env5646 == env5647) = true)

theorem identity5647 : scanCanonicalize (H12AffineFastState.compose env5647 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 4264) := by decide +kernel

theorem selectedBound5647 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env5648 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8352,65536,4525,76047,1024,8352,4097,396,73874,139,8329,73875,76166,4265,4357,2184,74794,73771,256,169,4525,74543]

theorem envBound5648 : H12AffineFastState.Bounded env5648 := by
  intro p hp
  have h : env5648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5647_5648 : H12AffineEnvironment.transform 13 4264 env5647 = env5648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env5647 == env5648) = true)

theorem identity5648 : scanCanonicalize (H12AffineFastState.compose env5648 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 11148) := by decide +kernel

theorem selectedBound5648 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env5649 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,8352,11148,4525,643,1024,8352,4097,396,2846,139,8329,2847,522,4265,4357,2184,4006,2983,256,169,4525,2211]

theorem envBound5649 : H12AffineFastState.Bounded env5649 := by
  intro p hp
  have h : env5649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5648_5649 : H12AffineEnvironment.transform 15 11148 env5648 = env5649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11148 env5648 == env5649) = true)

theorem identity5649 : scanCanonicalize (H12AffineFastState.compose env5649 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 7475) := by decide +kernel

theorem selectedBound5649 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env5650 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7475,4264,7571,5823,4525,643,1024,7571,4097,396,2846,139,7610,2847,522,4265,4357,2184,4006,2983,256,169,4525,2211]

theorem envBound5650 : H12AffineFastState.Bounded env5650 := by
  intro p hp
  have h : env5650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5649_5650 : H12AffineEnvironment.transform 12 7475 env5649 = env5650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7475 env5649 == env5650) = true)

theorem identity5650 : scanCanonicalize (H12AffineFastState.compose env5650 (packedSelected [0,1,3,5,7,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1598) := by decide +kernel

theorem selectedBound5650 : packedSelected [0,1,3,5,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env5651 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1598,2829,1686,2989,129,1939,643,1024,2989,1599,396,2846,139,2948,2847,522,1687,1851,2184,4006,2983,256,169,1939,2211]

theorem envBound5651 : H12AffineFastState.Bounded env5651 := by
  intro p hp
  have h : env5651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5650_5651 : H12AffineEnvironment.transform 11 1598 env5650 = env5651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1598 env5650 == env5651) = true)

theorem identity5651 : scanCanonicalize (H12AffineFastState.compose env5651 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound5651 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,799,1598,18,1686,178,129,1939,643,1024,178,1599,396,1,139,155,0,522,1687,1851,919,1209,184,256,169,1939,956]

theorem envBound5652 : H12AffineFastState.Bounded env5652 := by
  intro p hp
  have h : env5652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5651_5652 : H12AffineEnvironment.transform 10 799 env5651 = env5652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env5651 == env5652) = true)

theorem identity5652 : scanCanonicalize (H12AffineFastState.compose env5652 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5652 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5653 : List Nat := [2,4,8,0,32,0,128,256,512,1024,783,1582,2,1670,162,129,1923,643,1024,162,1583,396,1,139,139,0,522,1671,1835,903,1193,168,256,169,1923,940]

theorem envBound5653 : H12AffineFastState.Bounded env5653 := by
  intro p hp
  have h : env5653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5652_5653 : H12AffineEnvironment.transform 3 0 env5652 = env5653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5652 == env5653) = true)

theorem identity5653 : scanCanonicalize (H12AffineFastState.compose env5653 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5653 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env5654 : List Nat := [2,4,8,0,11,0,128,256,512,1024,783,1541,2,1670,137,129,1923,643,1024,137,1540,396,1,139,139,0,522,1671,1792,903,1154,131,256,130,1923,903]

theorem envBound5654 : H12AffineFastState.Bounded env5654 := by
  intro p hp
  have h : env5654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5653_5654 : H12AffineEnvironment.transform 4 11 env5653 = env5654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5653 == env5654) = true)

theorem identity5654 : scanCanonicalize (H12AffineFastState.compose env5654 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound5654 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env5655 : List Nat := [2,4,8,0,11,0,128,141,512,1024,642,1541,2,1670,137,129,1550,643,1024,137,1540,1,1,139,139,0,522,1671,1677,522,1154,131,141,130,1550,522]

theorem envBound5655 : H12AffineFastState.Bounded env5655 := by
  intro p hp
  have h : env5655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5654_5655 : H12AffineEnvironment.transform 7 141 env5654 = env5655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env5654 == env5655) = true)

theorem identity5655 : scanCanonicalize (H12AffineFastState.compose env5655 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound5655 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5656 : List Nat := [2,4,8,0,11,0,128,141,137,1024,11,1164,2,1039,137,129,1159,10,1024,137,1165,1,1,139,139,0,131,1038,1028,131,1154,131,141,130,1159,131]

theorem envBound5656 : H12AffineFastState.Bounded env5656 := by
  intro p hp
  have h : env5656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5655_5656 : H12AffineEnvironment.transform 8 137 env5655 = env5656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env5655 == env5656) = true)

theorem identity5656 : scanCanonicalize (H12AffineFastState.compose env5656 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound5656 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env5657 : List Nat := [2,4,8,0,11,0,2,15,11,1024,11,1038,2,1039,11,3,1029,10,1024,11,1039,1,1,9,9,0,1,1038,1028,1,1024,1,15,0,1029,1]

theorem envBound5657 : H12AffineFastState.Bounded env5657 := by
  intro p hp
  have h : env5657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5656_5657 : H12AffineEnvironment.transform 6 2 env5656 = env5657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env5656 == env5657) = true)

theorem identity5657 : scanCanonicalize (H12AffineFastState.compose env5657 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5658 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,2,1029,1,3,1029,0,1024,1,1029,1,1,3,3,0,1,1028,1028,1,1024,1,5,0,1029,1]

theorem envBound5658 : H12AffineFastState.Bounded env5658 := by
  intro p hp
  have h : env5658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5657_5658 : H12AffineEnvironment.transform 2 2 env5657 = env5658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5657 == env5658) = true)

def leafEnv5658 : List Nat := [2,4,2,0,1,0,2,5,1,1024,1,1028,2,1029,1,3,1029,0,1024,1,1029,1,1,3,1024,3,1,0,1,1028,1028,1,1024,1,5,0,4,3,1029,1,1,1028,0]

def active5658 : List Nat := [0,1,9]

def tree5658 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5658 : H12WitnessSearch.Good tree5658 := H12GlobalWitnessIndex.good

theorem leafIdentity5658 : H12AffineFastState.composeSystem env5658 rootObs = leafEnv5658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5658 rootObs == leafEnv5658) = true)

theorem terminalChecked5658 : H12PackedTerminal.terminalCheckFast leafEnv5658 active5658 tree5658 = true := by decide +kernel

def env5659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,262144,1024,8353,4097,20773,8388608,138,8329,8388609,282656,16385,16813,22560,74794,8388793,256,20481,16645,8389565]

theorem envBound5659 : H12AffineFastState.Bounded env5659 := by
  intro p hp
  have h : env5659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5644_5659 : H12AffineEnvironment.transform 14 8353 env5644 = env5659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env5644 == env5659) = true)

theorem identity5659 : scanCanonicalize (H12AffineFastState.compose env5659 (packedSelected [0,9,13,17,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 284825) := by decide +kernel

theorem selectedBound5659 : packedSelected [0,9,13,17,22,27] rootPS < 2^1333 := by decide +kernel

def env5660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,65536,4525,262144,1024,8353,4097,20773,284825,138,8329,284824,282656,16385,16813,22560,74794,284704,256,20481,16645,285476]

theorem envBound5660 : H12AffineFastState.Bounded env5660 := by
  intro p hp
  have h : env5660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5659_5660 : H12AffineEnvironment.transform 22 284825 env5659 = env5660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284825 env5659 == env5660) = true)

theorem identity5660 : scanCanonicalize (H12AffineFastState.compose env5660 (packedSelected [0,1,3,4,7,13,17,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 28715) := by decide +kernel

theorem selectedBound5660 : packedSelected [0,1,3,4,7,13,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env5661 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8353,28715,4525,262144,1024,8353,4097,20773,284825,138,8329,284824,282656,16385,16813,22560,21505,284704,256,20481,16645,285476]

theorem envBound5661 : H12AffineFastState.Bounded env5661 := by
  intro p hp
  have h : env5661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5660_5661 : H12AffineEnvironment.transform 15 28715 env5660 = env5661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28715 env5660 == env5661) = true)

theorem identity5661 : scanCanonicalize (H12AffineFastState.compose env5661 (packedSelected [17,21] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5661 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env5662 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,8353,28715,4265,262144,1024,8353,4097,20513,284825,138,8329,284824,282656,16385,16553,22560,21505,284704,4,20481,16385,285216]

theorem envBound5662 : H12AffineFastState.Bounded env5662 := by
  intro p hp
  have h : env5662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5661_5662 : H12AffineEnvironment.transform 7 4 env5661 = env5662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5661 == env5662) = true)

theorem identity5662 : scanCanonicalize (H12AffineFastState.compose env5662 (packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound5662 : packedSelected [1,2,3,4,5,6,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env5663 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,7695,8353,11812,4265,262144,1024,8353,4097,3630,263830,138,8329,263831,265775,7694,7846,1583,2574,263727,4,3598,7694,263215]

theorem envBound5663 : H12AffineFastState.Bounded env5663 := by
  intro p hp
  have h : env5663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5662_5663 : H12AffineEnvironment.transform 13 7695 env5662 = env5663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env5662 == env5663) = true)

theorem identity5663 : scanCanonicalize (H12AffineFastState.compose env5663 (packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5663 : packedSelected [0,2,3,4,5,6,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env5664 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,7695,8353,11812,4265,2081,1024,8353,4097,3630,3767,138,8329,3766,1550,7694,7846,1583,2574,3598,4,3598,7694,3086]

theorem envBound5664 : H12AffineFastState.Bounded env5664 := by
  intro p hp
  have h : env5664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5663_5664 : H12AffineEnvironment.transform 17 2081 env5663 = env5664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5663 == env5664) = true)

theorem identity5664 : scanCanonicalize (H12AffineFastState.compose env5664 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound5664 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env5665 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,2195,8192,1692,8353,11812,2106,2081,1024,8353,2194,3630,3767,138,8329,3766,1550,1693,1589,1583,2574,3598,4,3598,1693,3086]

theorem envBound5665 : H12AffineFastState.Bounded env5665 := by
  intro p hp
  have h : env5665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5664_5665 : H12AffineEnvironment.transform 11 2195 env5664 = env5665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env5664 == env5665) = true)

theorem identity5665 : scanCanonicalize (H12AffineFastState.compose env5665 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound5665 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env5666 : List Nat := [2,4,8,16,32,16,40,4,512,1024,2048,2107,8192,1588,8201,11812,2106,2081,1024,8201,2106,3630,3615,34,8225,3614,1550,1589,1589,1583,2574,3598,4,3598,1589,3086]

theorem envBound5666 : H12AffineFastState.Bounded env5666 := by
  intro p hp
  have h : env5666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5665_5666 : H12AffineEnvironment.transform 6 40 env5665 = env5666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env5665 == env5666) = true)

theorem identity5666 : scanCanonicalize (H12AffineFastState.compose env5666 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound5666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5667 : List Nat := [2,4,8,16,27,16,19,4,512,1024,2048,2048,8192,1551,8201,11807,2049,2074,1024,8201,2049,3605,3615,25,8218,3614,1550,1550,1550,1556,2574,3598,4,3598,1550,3086]

theorem envBound5667 : H12AffineFastState.Bounded env5667 := by
  intro p hp
  have h : env5667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5666_5667 : H12AffineEnvironment.transform 4 27 env5666 = env5667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env5666 == env5667) = true)

theorem identity5667 : scanCanonicalize (H12AffineFastState.compose env5667 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound5667 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env5668 : List Nat := [2,4,8,16,27,16,19,4,512,1024,2048,2048,1030,1551,1039,2585,2049,2074,1024,1039,2049,3605,3615,25,1052,3614,1550,1550,1550,1556,2574,3598,4,3598,1550,3086]

theorem envBound5668 : H12AffineFastState.Bounded env5668 := by
  intro p hp
  have h : env5668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5667_5668 : H12AffineEnvironment.transform 12 1030 env5667 = env5668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env5667 == env5668) = true)

theorem identity5668 : scanCanonicalize (H12AffineFastState.compose env5668 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5668 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5669 : List Nat := [2,4,8,16,27,16,19,4,1,1024,2048,2048,1030,1038,1039,2072,2049,2074,1024,1039,2049,3092,3102,25,1052,3103,1039,1039,1039,1045,2063,3087,4,3087,1039,3086]

theorem envBound5669 : H12AffineFastState.Bounded env5669 := by
  intro p hp
  have h : env5669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5668_5669 : H12AffineEnvironment.transform 8 1 env5668 = env5669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5668 == env5669) = true)

theorem identity5669 : scanCanonicalize (H12AffineFastState.compose env5669 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5670 : List Nat := [2,4,8,16,27,16,19,4,1,14,2048,2048,8,0,1,2072,2049,2074,14,1,2049,2074,2064,25,18,2065,1,1,1,27,2063,2049,4,2049,1,2048]

theorem envBound5670 : H12AffineFastState.Bounded env5670 := by
  intro p hp
  have h : env5670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5669_5670 : H12AffineEnvironment.transform 9 14 env5669 = env5670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5669 == env5670) = true)

def env5671 : List Nat := [2,4,8,16,27,16,19,4,1,14,0,0,8,0,1,24,1,26,14,1,1,26,16,25,18,17,1,1,1,27,15,1,4,1,1,0]

theorem envBound5671 : H12AffineFastState.Bounded env5671 := by
  intro p hp
  have h : env5671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5670_5671 : H12AffineEnvironment.transform 10 0 env5670 = env5671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env5670 == env5671) = true)

theorem identity5671 : scanCanonicalize (H12AffineFastState.compose env5671 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound5671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5672 : List Nat := [2,4,8,4,15,4,7,4,1,14,0,0,8,0,1,12,1,14,14,1,1,14,4,13,6,5,1,1,1,15,15,1,4,1,1,0]

theorem envBound5672 : H12AffineFastState.Bounded env5672 := by
  intro p hp
  have h : env5672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5671_5672 : H12AffineEnvironment.transform 3 4 env5671 = env5672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env5671 == env5672) = true)

theorem identity5672 : scanCanonicalize (H12AffineFastState.compose env5672 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound5672 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env5673 : List Nat := [2,0,8,0,11,0,3,0,1,10,0,0,8,0,1,8,1,10,10,1,1,10,0,9,2,1,1,1,1,11,11,1,0,1,1,0]

theorem envBound5673 : H12AffineFastState.Bounded env5673 := by
  intro p hp
  have h : env5673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5672_5673 : H12AffineEnvironment.transform 1 0 env5672 = env5673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env5672 == env5673) = true)

def leafEnv5673 : List Nat := [2,0,8,0,11,0,3,0,1,10,0,0,8,0,1,8,1,10,10,1,1,10,0,9,11,2,1,1,1,1,1,11,11,1,0,1,0,2,1,0,1,0,0]

def active5673 : List Nat := [0,2]

def tree5673 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5673 : H12WitnessSearch.Good tree5673 := H12GlobalWitnessIndex.good

theorem leafIdentity5673 : H12AffineFastState.composeSystem env5673 rootObs = leafEnv5673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5673 rootObs == leafEnv5673) = true)

theorem terminalChecked5673 : H12PackedTerminal.terminalCheckFast leafEnv5673 active5673 tree5673 = true := by decide +kernel

def env5674 : List Nat := [2,4,8,16,27,16,19,4,1,14,1,1,8,0,1,25,0,27,14,1,0,27,17,25,18,16,1,1,1,27,14,0,4,0,1,1]

theorem envBound5674 : H12AffineFastState.Bounded env5674 := by
  intro p hp
  have h : env5674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5670_5674 : H12AffineEnvironment.transform 10 1 env5670 = env5674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env5670 == env5674) = true)

def env5675 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61829,8388608,41003,8329,8388608,323712,16385,16812,22561,74794,8388792,256,20480,16644,8389564]

theorem envBound5675 : H12AffineFastState.Bounded env5675 := by
  intro p hp
  have h : env5675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5643_5675 : H12AffineEnvironment.transform 5 17 env5643 = env5675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5643 == env5675) = true)

theorem identity5675 : scanCanonicalize (H12AffineFastState.compose env5675 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound5675 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env5676 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,61829,444,41003,8329,444,323712,16385,16812,22561,74794,260,256,20480,16644,512]

theorem envBound5676 : H12AffineFastState.Bounded env5676 := by
  intro p hp
  have h : env5676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5675_5676 : H12AffineEnvironment.transform 22 444 env5675 = env5676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env5675 == env5676) = true)

theorem identity5676 : scanCanonicalize (H12AffineFastState.compose env5676 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound5676 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env5677 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1024,32768,4097,41349,444,41003,8329,444,303232,4097,4524,2081,74794,260,256,0,4356,512]

theorem envBound5677 : H12AffineFastState.Bounded env5677 := by
  intro p hp
  have h : env5677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5676_5677 : H12AffineEnvironment.transform 13 4096 env5676 = env5677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env5676 == env5677) = true)

theorem identity5677 : scanCanonicalize (H12AffineFastState.compose env5677 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound5677 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env5678 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,65536,4524,262144,1024,13972,4097,5905,444,5823,8329,444,267796,4097,4524,2081,74794,260,256,0,4356,512]

theorem envBound5678 : H12AffineFastState.Bounded env5678 := by
  intro p hp
  have h : env5678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5677_5678 : H12AffineEnvironment.transform 14 13972 env5677 = env5678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env5677 == env5678) = true)

theorem identity5678 : scanCanonicalize (H12AffineFastState.compose env5678 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound5678 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env5679 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,262144,1024,13972,4097,5905,444,5823,8329,444,267796,4097,4524,2081,1192,260,256,0,4356,512]

theorem envBound5679 : H12AffineFastState.Bounded env5679 := by
  intro p hp
  have h : env5679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5678_5679 : H12AffineEnvironment.transform 15 8322 env5678 = env5679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env5678 == env5679) = true)

theorem identity5679 : scanCanonicalize (H12AffineFastState.compose env5679 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound5679 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env5680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,13972,8322,4524,2081,1024,13972,4097,5905,444,5823,8329,444,7733,4097,4524,2081,1192,260,256,0,4356,512]

theorem envBound5680 : H12AffineFastState.Bounded env5680 := by
  intro p hp
  have h : env5680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5679_5680 : H12AffineEnvironment.transform 17 2081 env5679 = env5680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env5679 == env5680) = true)

theorem identity5680 : scanCanonicalize (H12AffineFastState.compose env5680 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5680 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1692,8192,1692,8200,8322,1840,2081,1024,8200,1693,397,444,35,8329,444,2217,1693,1840,2081,1192,260,256,0,1944,512]

theorem envBound5681 : H12AffineFastState.Bounded env5681 := by
  intro p hp
  have h : env5681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5680_5681 : H12AffineEnvironment.transform 11 1692 env5680 = env5681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5680 == env5681) = true)

theorem identity5681 : scanCanonicalize (H12AffineFastState.compose env5681 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound5681 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env5682 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1692,8192,1692,8200,8322,1693,2081,1024,8200,1693,32,17,35,8329,17,2217,1693,1693,2081,1192,169,173,0,1589,512]

theorem envBound5682 : H12AffineFastState.Bounded env5682 := by
  intro p hp
  have h : env5682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5681_5682 : H12AffineEnvironment.transform 7 173 env5681 = env5682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env5681 == env5682) = true)

theorem identity5682 : scanCanonicalize (H12AffineFastState.compose env5682 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound5682 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5683 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,8192,1692,8200,8322,1693,643,1024,8200,1693,32,17,35,8329,17,523,1693,1693,643,1192,169,173,0,1589,512]

theorem envBound5683 : H12AffineFastState.Bounded env5683 := by
  intro p hp
  have h : env5683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5682_5683 : H12AffineEnvironment.transform 10 674 env5682 = env5683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env5682 == env5683) = true)

theorem identity5683 : scanCanonicalize (H12AffineFastState.compose env5683 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound5683 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env5684 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,35,1692,43,161,1693,643,1024,43,1693,32,17,35,170,17,523,1693,1693,643,1192,169,173,0,1589,512]

theorem envBound5684 : H12AffineFastState.Bounded env5684 := by
  intro p hp
  have h : env5684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5683_5684 : H12AffineEnvironment.transform 12 35 env5683 = env5684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env5683 == env5684) = true)

theorem identity5684 : scanCanonicalize (H12AffineFastState.compose env5684 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound5684 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env5685 : List Nat := [2,4,8,16,32,17,25,52,512,1024,571,1541,35,1541,43,56,1540,538,1024,43,1540,32,17,35,51,17,523,1540,1540,538,1073,48,52,0,1589,512]

theorem envBound5685 : H12AffineFastState.Bounded env5685 := by
  intro p hp
  have h : env5685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5684_5685 : H12AffineEnvironment.transform 6 25 env5684 = env5685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env5684 == env5685) = true)

theorem identity5685 : scanCanonicalize (H12AffineFastState.compose env5685 (packedSelected [2,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5685 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env5686 : List Nat := [2,4,3,16,32,17,18,52,512,1024,560,1541,35,1541,32,51,1540,529,1024,32,1540,32,17,35,51,17,512,1540,1540,529,1073,48,52,0,1589,512]

theorem envBound5686 : H12AffineFastState.Bounded env5686 := by
  intro p hp
  have h : env5686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5685_5686 : H12AffineEnvironment.transform 2 3 env5685 = env5686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5685 == env5686) = true)

theorem identity5686 : scanCanonicalize (H12AffineFastState.compose env5686 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5686 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env5687 : List Nat := [2,4,3,16,1,17,18,21,512,1024,529,1541,2,1541,1,18,1540,529,1024,1,1540,1,17,2,18,17,512,1540,1540,529,1040,17,21,0,1556,512]

theorem envBound5687 : H12AffineFastState.Bounded env5687 := by
  intro p hp
  have h : env5687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5686_5687 : H12AffineEnvironment.transform 4 1 env5686 = env5687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5686 == env5687) = true)

theorem identity5687 : scanCanonicalize (H12AffineFastState.compose env5687 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound5687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5688 : List Nat := [2,4,3,16,1,17,18,21,1,1024,16,1028,2,1028,1,18,1029,16,1024,1,1029,1,17,2,18,17,1,1029,1029,16,1040,17,21,0,1045,1]

theorem envBound5688 : H12AffineFastState.Bounded env5688 := by
  intro p hp
  have h : env5688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5687_5688 : H12AffineEnvironment.transform 8 1 env5687 = env5688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env5687 == env5688) = true)

theorem identity5688 : scanCanonicalize (H12AffineFastState.compose env5688 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound5688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5689 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,2,1028,1,2,1029,0,1024,1,1029,1,1,2,2,1,1,1029,1029,0,1024,1,5,0,1029,1]

theorem envBound5689 : H12AffineFastState.Bounded env5689 := by
  intro p hp
  have h : env5689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5688_5689 : H12AffineEnvironment.transform 3 0 env5688 = env5689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env5688 == env5689) = true)

def leafEnv5689 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1028,2,1028,1,2,1029,0,1024,1,1029,1,1,2,1024,2,1,1,1,1029,1029,0,1024,1,5,0,4,3,1029,1,1,1029,0]

def active5689 : List Nat := [0,1,9]

def tree5689 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5689 : H12WitnessSearch.Good tree5689 := H12GlobalWitnessIndex.good

theorem leafIdentity5689 : H12AffineFastState.composeSystem env5689 rootObs = leafEnv5689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5689 rootObs == leafEnv5689) = true)

theorem terminalChecked5689 : H12PackedTerminal.terminalCheckFast leafEnv5689 active5689 tree5689 = true := by decide +kernel

end H12CloudChart1