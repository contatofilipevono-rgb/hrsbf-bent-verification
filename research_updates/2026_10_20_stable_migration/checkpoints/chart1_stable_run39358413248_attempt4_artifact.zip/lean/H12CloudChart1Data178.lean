import H12CloudChart1Data177

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity45117 : scanCanonicalize (H12AffineFastState.compose env45117 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45117 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45118 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5377,0,262,13388,10360,1024,1,12573,33,8525,83,8273,64,10509,13340,4097,10361,9224,112,256,113,13324,513]

theorem envBound45118 : H12AffineFastState.Bounded env45118 := by
  intro p hp
  have h : env45118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45117_45118 : H12AffineEnvironment.transform 6 89 env45117 = env45118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45117 == env45118) = true)

theorem identity45118 : scanCanonicalize (H12AffineFastState.compose env45118 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45118 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45119 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5377,0,262,5440,2420,1024,1,4113,33,65,83,349,64,2049,5392,4097,2421,1284,112,256,113,5376,513]

theorem envBound45119 : H12AffineFastState.Bounded env45119 := by
  intro p hp
  have h : env45119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45118_45119 : H12AffineEnvironment.transform 12 268 env45118 = env45119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45118 == env45119) = true)

theorem identity45119 : scanCanonicalize (H12AffineFastState.compose env45119 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45119 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45120 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4113,33,16,2,268,17,2049,5392,4097,2340,1284,33,256,32,5376,513]

theorem envBound45120 : H12AffineFastState.Bounded env45120 := by
  intro p hp
  have h : env45120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45119_45120 : H12AffineEnvironment.transform 5 17 env45119 = env45120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45119 == env45120) = true)

theorem identity45120 : scanCanonicalize (H12AffineFastState.compose env45120 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45121 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,268,4112,0,262,4096,2341,273,1,4113,33,16,2,268,17,2049,4097,4097,2340,21,33,256,32,4113,513]

theorem envBound45121 : H12AffineFastState.Bounded env45121 := by
  intro p hp
  have h : env45121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45120_45121 : H12AffineEnvironment.transform 9 273 env45120 = env45121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45120 == env45121) = true)

theorem identity45121 : scanCanonicalize (H12AffineFastState.compose env45121 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45121 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45122 : List Nat := [2,4,8,16,32,17,8,37,512,52,2048,4096,41,4112,0,35,4096,2048,52,1,4113,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4113,513]

theorem envBound45122 : H12AffineFastState.Bounded env45122 := by
  intro p hp
  have h : env45122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45121_45122 : H12AffineEnvironment.transform 7 37 env45121 = env45122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45121 == env45122) = true)

theorem identity45122 : scanCanonicalize (H12AffineFastState.compose env45122 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound45122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45123 : List Nat := [2,4,8,16,32,17,8,37,48,52,2048,4096,41,4112,0,35,4096,2048,52,1,4113,33,16,2,41,17,2049,4097,4097,2049,21,33,37,32,4113,49]

theorem envBound45123 : H12AffineFastState.Bounded env45123 := by
  intro p hp
  have h : env45123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45122_45123 : H12AffineEnvironment.transform 8 48 env45122 = env45123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env45122 == env45123) = true)

theorem identity45123 : scanCanonicalize (H12AffineFastState.compose env45123 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45123 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45124 : List Nat := [2,4,8,16,32,17,8,37,48,52,0,4096,41,4112,0,35,4096,0,52,1,4113,33,16,2,41,17,1,4097,4097,1,21,33,37,32,4113,49]

theorem envBound45124 : H12AffineFastState.Bounded env45124 := by
  intro p hp
  have h : env45124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45123_45124 : H12AffineEnvironment.transform 10 0 env45123 = env45124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45123 == env45124) = true)

theorem identity45124 : scanCanonicalize (H12AffineFastState.compose env45124 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound45124 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45125 : List Nat := [2,4,8,16,32,17,8,37,48,52,0,17,41,1,0,35,17,0,52,1,0,33,16,2,41,17,1,16,16,1,21,33,37,32,0,49]

theorem envBound45125 : H12AffineFastState.Bounded env45125 := by
  intro p hp
  have h : env45125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45124_45125 : H12AffineEnvironment.transform 11 17 env45124 = env45125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45124 == env45125) = true)

def env45126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91587,4194304,8388608,119893,8328,64,12981332,79131,8466579,8830977,8409157,4314199,256,8484154,8492191,8484755]

theorem envBound45126 : H12AffineFastState.Bounded env45126 := by
  intro p hp
  have h : env45126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45015_45126 : H12AffineEnvironment.transform 23 119893 env45015 = env45126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119893 env45015 == env45126) = true)

def env45127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981332,79131,8466579,8819969,8389957,4292951,256,8462394,8492191,8462995]

theorem envBound45127 : H12AffineFastState.Bounded env45127 := by
  intro p hp
  have h : env45127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45126_45127 : H12AffineEnvironment.transform 13 5376 env45126 = env45127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45126 == env45127) = true)

def env45128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787060,79131,8466579,8819969,8389957,98679,256,8462394,8492191,8462995]

theorem envBound45128 : H12AffineFastState.Bounded env45128 := by
  intro p hp
  have h : env45128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45127_45128 : H12AffineEnvironment.transform 21 32 env45127 = env45128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env45127 == env45128) = true)

theorem identity45128 : scanCanonicalize (H12AffineFastState.compose env45128 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45128 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,78019,32,8388608,73736,8328,64,8787060,79131,8466579,8795228,8389957,73770,256,8462394,8467906,8462995]

theorem envBound45129 : H12AffineFastState.Bounded env45129 := by
  intro p hp
  have h : env45129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45128_45129 : H12AffineEnvironment.transform 14 8541 env45128 = env45129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45128 == env45129) = true)

def env45130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,78019,32,8388608,73736,8328,64,8535252,79131,8466579,8527100,8389957,73770,256,8462394,8467906,8462995]

theorem envBound45130 : H12AffineFastState.Bounded env45130 := by
  intro p hp
  have h : env45130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45129_45130 : H12AffineEnvironment.transform 17 10400 env45129 = env45130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env45129 == env45130) = true)

theorem identity45130 : scanCanonicalize (H12AffineFastState.compose env45130 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound45130 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10400,1024,8540,78019,32,16,73736,8328,64,146628,79131,77955,138476,1365,73770,256,73770,79314,74371]

theorem envBound45131 : H12AffineFastState.Bounded env45131 := by
  intro p hp
  have h : env45131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45130_45131 : H12AffineEnvironment.transform 22 16 env45130 = env45131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env45130 == env45131) = true)

theorem identity45131 : scanCanonicalize (H12AffineFastState.compose env45131 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound45131 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,70862,10400,1024,8540,78019,32,16,73736,8328,64,75786,79131,77955,67618,1365,73770,256,73770,79314,74371]

theorem envBound45132 : H12AffineFastState.Bounded env45132 := by
  intro p hp
  have h : env45132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45131_45132 : H12AffineEnvironment.transform 16 70862 env45131 = env45132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env45131 == env45132) = true)

theorem identity45132 : scanCanonicalize (H12AffineFastState.compose env45132 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound45132 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env45133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,13388,10400,1024,8540,4161,32,16,138,8328,64,2184,5529,4097,10400,1365,168,256,168,5456,513]

theorem envBound45133 : H12AffineFastState.Bounded env45133 := by
  intro p hp
  have h : env45133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45132_45133 : H12AffineEnvironment.transform 15 8322 env45132 = env45133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env45132 == env45133) = true)

theorem identity45133 : scanCanonicalize (H12AffineFastState.compose env45133 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45133 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1100,5376,1297,1230,4096,3308,1024,1296,4161,32,16,138,1220,64,2184,5529,4097,3308,1365,168,256,168,5456,513]

theorem envBound45134 : H12AffineFastState.Bounded env45134 := by
  intro p hp
  have h : env45134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45133_45134 : H12AffineEnvironment.transform 12 1100 env45133 = env45134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45133 == env45134) = true)

theorem identity45134 : scanCanonicalize (H12AffineFastState.compose env45134 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound45134 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,1100,2184,1297,1230,3464,3308,1024,1296,3529,32,16,138,1220,64,2184,2065,3465,3308,1365,168,256,168,2264,513]

theorem envBound45135 : H12AffineFastState.Bounded env45135 := by
  intro p hp
  have h : env45135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45134_45135 : H12AffineEnvironment.transform 11 3464 env45134 = env45135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env45134 == env45135) = true)

theorem identity45135 : scanCanonicalize (H12AffineFastState.compose env45135 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45135 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env45136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1417,1100,137,1297,1230,1417,1261,1024,1296,1480,32,16,138,1220,64,137,16,1416,1261,1365,168,256,168,217,513]

theorem envBound45136 : H12AffineFastState.Bounded env45136 := by
  intro p hp
  have h : env45136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45135_45136 : H12AffineEnvironment.transform 10 1 env45135 = env45136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45135 == env45136) = true)

theorem identity45136 : scanCanonicalize (H12AffineFastState.compose env45136 (packedSelected [1,4,8,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45136 : packedSelected [1,4,8,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env45137 : List Nat := [2,4,8,16,32,64,128,117,512,1024,1,1276,1100,137,1124,1230,1276,1261,1024,1125,1213,32,16,138,1220,64,137,16,1277,1261,1056,168,117,168,217,513]

theorem envBound45137 : H12AffineFastState.Bounded env45137 := by
  intro p hp
  have h : env45137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45136_45137 : H12AffineEnvironment.transform 7 117 env45136 = env45137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45136 == env45137) = true)

theorem identity45137 : scanCanonicalize (H12AffineFastState.compose env45137 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45137 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env45138 : List Nat := [2,4,8,16,32,64,89,117,512,1024,1,1061,1100,80,1124,1047,1061,1076,1024,1125,1124,32,16,83,1053,64,80,16,1060,1076,1056,113,117,113,0,513]

theorem envBound45138 : H12AffineFastState.Bounded env45138 := by
  intro p hp
  have h : env45138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45137_45138 : H12AffineEnvironment.transform 6 89 env45137 = env45138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45137 == env45138) = true)

theorem identity45138 : scanCanonicalize (H12AffineFastState.compose env45138 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45138 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45139 : List Nat := [2,4,8,16,32,64,89,117,512,100,1,65,40,80,0,115,65,80,100,1,0,32,16,83,121,64,80,16,64,80,68,113,117,113,0,513]

theorem envBound45139 : H12AffineFastState.Bounded env45139 := by
  intro p hp
  have h : env45139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45138_45139 : H12AffineEnvironment.transform 9 100 env45138 = env45139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45138 == env45139) = true)

theorem identity45139 : scanCanonicalize (H12AffineFastState.compose env45139 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45139 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45140 : List Nat := [2,4,8,1,32,64,72,100,512,100,1,65,40,65,0,98,65,65,100,1,0,32,1,66,104,64,65,1,64,65,68,96,100,96,0,513]

theorem envBound45140 : H12AffineFastState.Bounded env45140 := by
  intro p hp
  have h : env45140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45139_45140 : H12AffineEnvironment.transform 3 1 env45139 = env45140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45139 == env45140) = true)

theorem identity45140 : scanCanonicalize (H12AffineFastState.compose env45140 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45140 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45141 : List Nat := [2,4,8,1,1,64,72,69,512,69,1,65,9,65,0,67,65,65,69,1,0,1,1,66,73,64,65,1,64,65,68,65,69,65,0,513]

theorem envBound45141 : H12AffineFastState.Bounded env45141 := by
  intro p hp
  have h : env45141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45140_45141 : H12AffineEnvironment.transform 4 1 env45140 = env45141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45140 == env45141) = true)

theorem identity45141 : scanCanonicalize (H12AffineFastState.compose env45141 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound45141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45142 : List Nat := [2,4,8,1,1,0,8,5,512,5,1,1,9,1,0,3,1,1,5,1,0,1,1,2,9,0,1,1,0,1,4,1,5,1,0,513]

theorem envBound45142 : H12AffineFastState.Bounded env45142 := by
  intro p hp
  have h : env45142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45141_45142 : H12AffineEnvironment.transform 5 0 env45141 = env45142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45141 == env45142) = true)

theorem identity45142 : scanCanonicalize (H12AffineFastState.compose env45142 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45143 : List Nat := [2,1,8,1,1,0,8,0,512,0,1,1,9,1,0,3,1,1,0,1,0,1,1,2,9,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound45143 : H12AffineFastState.Bounded env45143 := by
  intro p hp
  have h : env45143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45142_45143 : H12AffineEnvironment.transform 1 1 env45142 = env45143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45142 == env45143) = true)

theorem identity45143 : scanCanonicalize (H12AffineFastState.compose env45143 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound45143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45144 : List Nat := [2,1,1,1,1,0,1,0,512,0,1,1,0,1,0,3,1,1,0,1,0,1,1,2,0,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound45144 : H12AffineFastState.Bounded env45144 := by
  intro p hp
  have h : env45144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45143_45144 : H12AffineEnvironment.transform 2 1 env45143 = env45144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env45143 == env45144) = true)

theorem identity45144 : scanCanonicalize (H12AffineFastState.compose env45144 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45144 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45145 : List Nat := [1,1,1,1,1,0,1,0,512,0,1,1,0,1,0,0,1,1,0,1,0,1,1,1,0,0,1,1,0,1,1,1,0,1,0,513]

theorem envBound45145 : H12AffineFastState.Bounded env45145 := by
  intro p hp
  have h : env45145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45144_45145 : H12AffineEnvironment.transform 0 1 env45144 = env45145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45144 == env45145) = true)

def env45146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,32,8388608,73736,8328,64,8535253,79131,8466579,8527101,8389957,73770,256,8462394,8467906,8462995]

theorem envBound45146 : H12AffineFastState.Bounded env45146 := by
  intro p hp
  have h : env45146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45129_45146 : H12AffineEnvironment.transform 17 10401 env45129 = env45146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env45129 == env45146) = true)

def env45147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,32,136448,73736,8328,64,10709,79131,206227,2557,135237,73770,256,210234,204994,210835]

theorem envBound45147 : H12AffineFastState.Bounded env45147 := by
  intro p hp
  have h : env45147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45146_45147 : H12AffineEnvironment.transform 22 136448 env45146 = env45147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136448 env45146 == env45147) = true)

theorem identity45147 : scanCanonicalize (H12AffineFastState.compose env45147 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound45147 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env45148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79250,10401,1024,8540,78019,32,73874,73736,8328,64,10709,79131,4097,2557,75223,73770,256,168,5456,513]

theorem envBound45148 : H12AffineFastState.Bounded env45148 := by
  intro p hp
  have h : env45148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45147_45148 : H12AffineEnvironment.transform 16 79250 env45147 = env45148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env45147 == env45148) = true)

theorem identity45148 : scanCanonicalize (H12AffineFastState.compose env45148 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45148 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,79131,10280,1024,8540,77898,32,73755,73736,8193,64,10588,79131,4097,2420,75102,73770,256,33,5456,513]

theorem envBound45149 : H12AffineFastState.Bounded env45149 := by
  intro p hp
  have h : env45149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45148_45149 : H12AffineEnvironment.transform 6 9 env45148 = env45149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45148 == env45149) = true)

theorem identity45149 : scanCanonicalize (H12AffineFastState.compose env45149 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound45149 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45150 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,343,13388,10280,1024,8540,12573,32,8524,8543,8193,64,10588,13388,4097,2420,9225,8573,256,33,5456,513]

theorem envBound45150 : H12AffineFastState.Bounded env45150 := by
  intro p hp
  have h : env45150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45149_45150 : H12AffineEnvironment.transform 15 343 env45149 = env45150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env45149 == env45150) = true)

theorem identity45150 : scanCanonicalize (H12AffineFastState.compose env45150 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45150 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45151 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5392,2420,1024,0,4161,32,16,3,349,64,2048,5392,4097,2420,1365,33,256,33,5456,513]

theorem envBound45151 : H12AffineFastState.Bounded env45151 := by
  intro p hp
  have h : env45151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45150_45151 : H12AffineEnvironment.transform 12 348 env45150 = env45151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45150 == env45151) = true)

theorem identity45151 : scanCanonicalize (H12AffineFastState.compose env45151 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound45151 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45152 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1646,4096,348,5376,1,343,5392,1818,1024,0,4161,32,16,3,349,64,1646,5392,4097,1818,1365,33,256,33,5456,513]

theorem envBound45152 : H12AffineFastState.Bounded env45152 := by
  intro p hp
  have h : env45152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45151_45152 : H12AffineEnvironment.transform 10 1646 env45151 = env45152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env45151 == env45152) = true)

theorem identity45152 : scanCanonicalize (H12AffineFastState.compose env45152 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45152 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45153 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1646,4096,41,5237,1,34,5221,1647,1024,0,4161,32,16,3,40,64,1646,5221,4097,1647,1056,33,117,33,5157,513]

theorem envBound45153 : H12AffineFastState.Bounded env45153 := by
  intro p hp
  have h : env45153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45152_45153 : H12AffineEnvironment.transform 7 117 env45152 = env45153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45152 == env45153) = true)

theorem identity45153 : scanCanonicalize (H12AffineFastState.compose env45153 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound45153 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env45154 : List Nat := [2,4,8,16,32,64,9,117,512,575,81,4096,41,4682,1,34,4698,80,575,0,4161,32,16,3,40,64,81,4698,4097,80,543,33,117,33,4634,513]

theorem envBound45154 : H12AffineFastState.Bounded env45154 := by
  intro p hp
  have h : env45154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45153_45154 : H12AffineEnvironment.transform 9 575 env45153 = env45154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env45153 == env45154) = true)

theorem identity45154 : scanCanonicalize (H12AffineFastState.compose env45154 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound45154 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45155 : List Nat := [2,4,8,16,32,64,9,117,43,20,81,4096,41,4193,1,34,4209,80,20,0,4161,32,16,3,40,64,81,4209,4097,80,52,33,117,33,4145,42]

theorem envBound45155 : H12AffineFastState.Bounded env45155 := by
  intro p hp
  have h : env45155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45154_45155 : H12AffineEnvironment.transform 8 43 env45154 = env45155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env45154 == env45155) = true)

theorem identity45155 : scanCanonicalize (H12AffineFastState.compose env45155 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound45155 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45156 : List Nat := [2,4,8,9,32,64,9,108,43,13,72,4096,41,4193,1,34,4200,73,13,0,4161,32,9,3,40,64,72,4200,4097,73,45,33,108,33,4136,42]

theorem envBound45156 : H12AffineFastState.Bounded env45156 := by
  intro p hp
  have h : env45156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45155_45156 : H12AffineEnvironment.transform 3 9 env45155 = env45156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env45155 == env45156) = true)

def env45157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,78019,32,136449,73736,8328,64,10708,79131,206226,2556,135236,73770,256,210235,204995,210834]

theorem envBound45157 : H12AffineFastState.Bounded env45157 := by
  intro p hp
  have h : env45157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45146_45157 : H12AffineEnvironment.transform 22 136449 env45146 = env45157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136449 env45146 == env45157) = true)

theorem identity45157 : scanCanonicalize (H12AffineFastState.compose env45157 (packedSelected [2,3,4,5,6,7,10,12,14,15,22,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound45157 : packedSelected [2,3,4,5,6,7,10,12,14,15,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env45158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,137,65536,131072,2421,1024,136,69911,32,136449,66012,348,64,2048,70863,197702,2556,135236,66046,256,201967,196887,202310]

theorem envBound45158 : H12AffineFastState.Bounded env45158 := by
  intro p hp
  have h : env45158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45157_45158 : H12AffineEnvironment.transform 12 468 env45157 = env45158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env45157 == env45158) = true)

theorem identity45158 : scanCanonicalize (H12AffineFastState.compose env45158 (packedSelected [2,5,6,9,11,12,14,15,19,22,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45158 : packedSelected [2,5,6,9,11,12,14,15,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env45159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,65536,131072,2421,1024,0,69911,32,136449,65876,348,64,2048,70727,197702,2420,135236,65910,256,201831,196887,202310]

theorem envBound45159 : H12AffineFastState.Bounded env45159 := by
  intro p hp
  have h : env45159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45158_45159 : H12AffineEnvironment.transform 6 8 env45158 = env45159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45158 == env45159) = true)

theorem identity45159 : scanCanonicalize (H12AffineFastState.compose env45159 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 69667) := by decide +kernel

theorem selectedBound45159 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env45160 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,65536,69667,2421,1024,0,69911,32,66850,65876,348,64,2048,70727,5221,2420,65639,65910,256,1092,4404,1637]

theorem envBound45160 : H12AffineFastState.Bounded env45160 := by
  intro p hp
  have h : env45160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45159_45160 : H12AffineEnvironment.transform 16 69667 env45159 = env45160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69667 env45159 == env45160) = true)

theorem identity45160 : scanCanonicalize (H12AffineFastState.compose env45160 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound45160 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env45161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,34,4097,2421,1024,0,4405,32,1280,374,348,64,2048,5221,5221,2420,69,340,256,1092,4404,1637]

theorem envBound45161 : H12AffineFastState.Bounded env45161 := by
  intro p hp
  have h : env45161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45160_45161 : H12AffineEnvironment.transform 15 34 env45160 = env45161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env45160 == env45161) = true)

def env45162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,8388608,98645,8328,64,8787061,79131,8466579,8819969,8389957,98678,256,8462394,8492191,8462995]

theorem envBound45162 : H12AffineFastState.Bounded env45162 := by
  intro p hp
  have h : env45162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45127_45162 : H12AffineEnvironment.transform 21 33 env45127 = env45162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45127 == env45162) = true)

theorem identity45162 : scanCanonicalize (H12AffineFastState.compose env45162 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound45162 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,78019,33,41293,98645,8328,64,439608,79131,102878,406604,41992,98678,256,98679,79314,99294]

theorem envBound45163 : H12AffineFastState.Bounded env45163 := by
  intro p hp
  have h : env45163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45162_45163 : H12AffineEnvironment.transform 22 41293 env45162 = env45163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env45162 == env45163) = true)

theorem identity45163 : scanCanonicalize (H12AffineFastState.compose env45163 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound45163 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,78019,33,41293,98645,8328,64,203846,79131,102878,236850,41992,98678,256,98679,79314,99294]

theorem envBound45164 : H12AffineFastState.Bounded env45164 := by
  intro p hp
  have h : env45164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45163_45164 : H12AffineEnvironment.transform 17 108926 env45163 = env45164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env45163 == env45164) = true)

def env45165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,65536,131072,67618,1024,8541,78019,33,17,73737,8328,64,203846,79131,77954,212078,1364,73770,256,73771,79314,74370]

theorem envBound45165 : H12AffineFastState.Bounded env45165 := by
  intro p hp
  have h : env45165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45164_45165 : H12AffineEnvironment.transform 14 8540 env45164 = env45165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45164 == env45165) = true)

theorem identity45165 : scanCanonicalize (H12AffineFastState.compose env45165 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound45165 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env45166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8540,398,131072,2476,1024,8541,12621,33,17,8583,8328,64,138696,13461,12556,146912,1364,8612,256,8613,13404,8972]

theorem envBound45166 : H12AffineFastState.Bounded env45166 := by
  intro p hp
  have h : env45166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45165_45166 : H12AffineEnvironment.transform 15 398 env45165 = env45166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env45165 == env45166) = true)

theorem identity45166 : scanCanonicalize (H12AffineFastState.compose env45166 (packedSelected [21] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound45166 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,216,398,131072,2476,1024,217,4297,33,17,3,268,64,138696,5393,4232,138340,1364,32,256,33,5592,648]

theorem envBound45167 : H12AffineFastState.Bounded env45167 := by
  intro p hp
  have h : env45167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45166_45167 : H12AffineEnvironment.transform 12 388 env45166 = env45167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env45166 == env45167) = true)

theorem identity45167 : scanCanonicalize (H12AffineFastState.compose env45167 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45167 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45168 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,262,131072,2340,1024,81,4161,33,17,3,268,64,138560,5393,4096,138340,1364,32,256,33,5456,512]

theorem envBound45168 : H12AffineFastState.Bounded env45168 := by
  intro p hp
  have h : env45168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45167_45168 : H12AffineEnvironment.transform 6 8 env45167 = env45168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45167 == env45168) = true)

theorem identity45168 : scanCanonicalize (H12AffineFastState.compose env45168 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5472) := by decide +kernel

theorem selectedBound45168 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45169 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,262,5472,2340,1024,81,4161,33,17,3,268,64,2080,5393,4096,2308,1364,32,256,33,5456,512]

theorem envBound45169 : H12AffineFastState.Bounded env45169 := by
  intro p hp
  have h : env45169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45168_45169 : H12AffineEnvironment.transform 16 5472 env45168 = env45169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5472 env45168 == env45169) = true)

theorem identity45169 : scanCanonicalize (H12AffineFastState.compose env45169 (packedSelected [0,4,10] rootPS)) = affineNative (2^(11+1) ^^^ 1889) := by decide +kernel

theorem selectedBound45169 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env45170 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1889,268,609,80,262,513,2340,1024,81,1824,33,17,3,268,64,2080,624,1889,2308,1364,32,256,33,561,512]

theorem envBound45170 : H12AffineFastState.Bounded env45170 := by
  intro p hp
  have h : env45170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45169_45170 : H12AffineEnvironment.transform 11 1889 env45169 = env45170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1889 env45169 == env45170) = true)

theorem identity45170 : scanCanonicalize (H12AffineFastState.compose env45170 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45170 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env45171 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,1857,268,577,80,262,513,2308,1024,81,1792,1,17,3,268,64,2048,592,1857,2308,1364,0,256,1,529,512]

theorem envBound45171 : H12AffineFastState.Bounded env45171 := by
  intro p hp
  have h : env45171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45170_45171 : H12AffineEnvironment.transform 4 0 env45170 = env45171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45170 == env45171) = true)

theorem identity45171 : scanCanonicalize (H12AffineFastState.compose env45171 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45171 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45172 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,1809,268,529,0,262,513,2308,1024,1,1792,1,17,3,268,16,2048,512,1809,2308,1284,0,256,1,529,512]

theorem envBound45172 : H12AffineFastState.Bounded env45172 := by
  intro p hp
  have h : env45172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45171_45172 : H12AffineEnvironment.transform 5 16 env45171 = env45172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45171 == env45172) = true)

theorem identity45172 : scanCanonicalize (H12AffineFastState.compose env45172 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound45172 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45173 : List Nat := [2,4,8,16,0,16,8,256,512,273,2048,512,268,529,0,262,513,2308,273,1,529,1,17,3,268,16,2048,512,512,2308,21,0,256,1,529,512]

theorem envBound45173 : H12AffineFastState.Bounded env45173 := by
  intro p hp
  have h : env45173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45172_45173 : H12AffineEnvironment.transform 9 273 env45172 = env45173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env45172 == env45173) = true)

theorem identity45173 : scanCanonicalize (H12AffineFastState.compose env45173 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45173 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45174 : List Nat := [2,4,8,16,0,16,8,256,512,273,522,512,268,529,0,262,513,782,273,1,529,1,17,3,268,16,522,512,512,782,21,0,256,1,529,512]

theorem envBound45174 : H12AffineFastState.Bounded env45174 := by
  intro p hp
  have h : env45174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45173_45174 : H12AffineEnvironment.transform 10 522 env45173 = env45174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45173 == env45174) = true)

theorem identity45174 : scanCanonicalize (H12AffineFastState.compose env45174 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound45174 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45175 : List Nat := [2,4,8,16,0,16,8,256,27,273,17,27,268,10,0,262,26,277,273,1,10,1,17,3,268,16,17,27,27,277,21,0,256,1,10,27]

theorem envBound45175 : H12AffineFastState.Bounded env45175 := by
  intro p hp
  have h : env45175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45174_45175 : H12AffineEnvironment.transform 8 27 env45174 = env45175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env45174 == env45175) = true)

theorem identity45175 : scanCanonicalize (H12AffineFastState.compose env45175 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45175 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45176 : List Nat := [2,4,8,16,0,16,8,4,27,21,17,27,8,10,0,2,26,17,21,1,10,1,17,3,8,16,17,27,27,17,21,0,4,1,10,27]

theorem envBound45176 : H12AffineFastState.Bounded env45176 := by
  intro p hp
  have h : env45176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45175_45176 : H12AffineEnvironment.transform 7 4 env45175 = env45176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45175 == env45176) = true)

theorem identity45176 : scanCanonicalize (H12AffineFastState.compose env45176 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound45176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45177 : List Nat := [2,4,8,4,0,4,8,4,15,1,5,15,8,10,0,2,14,5,1,1,10,1,5,3,8,4,5,15,15,5,1,0,4,1,10,15]

theorem envBound45177 : H12AffineFastState.Bounded env45177 := by
  intro p hp
  have h : env45177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45176_45177 : H12AffineEnvironment.transform 3 4 env45176 = env45177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env45176 == env45177) = true)

theorem identity45177 : scanCanonicalize (H12AffineFastState.compose env45177 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45178 : List Nat := [2,3,8,3,0,3,8,3,8,1,2,8,8,10,0,2,9,2,1,1,10,1,2,3,8,3,2,8,8,2,1,0,3,1,10,8]

theorem envBound45178 : H12AffineFastState.Bounded env45178 := by
  intro p hp
  have h : env45178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45177_45178 : H12AffineEnvironment.transform 1 3 env45177 = env45178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45177 == env45178) = true)

def env45179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67619,1024,8540,78019,33,16,73736,8328,64,203846,79131,77955,212079,1365,73771,256,73770,79314,74371]

theorem envBound45179 : H12AffineFastState.Bounded env45179 := by
  intro p hp
  have h : env45179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45164_45179 : H12AffineEnvironment.transform 14 8541 env45164 = env45179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45164 == env45179) = true)

theorem identity45179 : scanCanonicalize (H12AffineFastState.compose env45179 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound45179 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env45180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,13460,67619,1024,8540,78019,33,16,73736,8328,64,75986,79131,77955,67835,1365,73771,256,73770,79314,74371]

theorem envBound45180 : H12AffineFastState.Bounded env45180 := by
  intro p hp
  have h : env45180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45179_45180 : H12AffineEnvironment.transform 16 13460 env45179 = env45180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env45179 == env45180) = true)

theorem identity45180 : scanCanonicalize (H12AffineFastState.compose env45180 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound45180 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env45181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,65536,5392,67619,1024,216,69959,33,16,65932,268,64,67926,70815,69895,67835,1365,65967,256,65966,70742,66311]

theorem envBound45181 : H12AffineFastState.Bounded env45181 := by
  intro p hp
  have h : env45181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45180_45181 : H12AffineEnvironment.transform 12 388 env45180 = env45181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env45180 == env45181) = true)

theorem identity45181 : scanCanonicalize (H12AffineFastState.compose env45181 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound45181 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45182 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5376,0,65536,5392,67619,1024,1,69959,33,16,65877,268,64,67926,70726,69895,67618,1365,65910,256,65911,70742,66311]

theorem envBound45182 : H12AffineFastState.Bounded env45182 := by
  intro p hp
  have h : env45182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45181_45182 : H12AffineEnvironment.transform 6 89 env45181 = env45182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45181 == env45182) = true)

theorem identity45182 : scanCanonicalize (H12AffineFastState.compose env45182 (packedSelected [0,1,2,6,7,8,10,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound45182 : packedSelected [0,1,2,6,7,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env45183 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3328,349,2048,0,65536,2064,67619,1024,1,68679,33,16,65877,268,64,67926,67910,68615,67618,1365,65910,256,65911,67926,66311]

theorem envBound45183 : H12AffineFastState.Bounded env45183 := by
  intro p hp
  have h : env45183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45182_45183 : H12AffineEnvironment.transform 11 3328 env45182 = env45183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env45182 == env45183) = true)

theorem identity45183 : scanCanonicalize (H12AffineFastState.compose env45183 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound45183 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env45184 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,3328,349,2048,0,343,2064,2420,1024,1,3344,33,16,2,268,64,2049,2065,3408,2421,1365,33,256,32,2049,592]

theorem envBound45184 : H12AffineFastState.Bounded env45184 := by
  intro p hp
  have h : env45184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45183_45184 : H12AffineEnvironment.transform 15 343 env45183 = env45184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env45183 == env45184) = true)

theorem identity45184 : scanCanonicalize (H12AffineFastState.compose env45184 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45184 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45185 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,2404,349,2048,0,343,2064,2420,100,1,2420,33,16,2,268,64,2049,2065,2356,2421,305,33,256,32,2049,592]

theorem envBound45185 : H12AffineFastState.Bounded env45185 := by
  intro p hp
  have h : env45185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45184_45185 : H12AffineEnvironment.transform 9 100 env45184 = env45185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45184 == env45185) = true)

theorem identity45185 : scanCanonicalize (H12AffineFastState.compose env45185 (packedSelected [3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45185 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env45186 : List Nat := [2,4,8,16,32,64,89,117,512,100,2048,2065,40,2048,0,34,2064,2049,100,1,2049,33,16,2,121,64,2049,2065,2113,2048,68,33,117,32,2049,592]

theorem envBound45186 : H12AffineFastState.Bounded env45186 := by
  intro p hp
  have h : env45186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45185_45186 : H12AffineEnvironment.transform 7 117 env45185 = env45186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45185 == env45186) = true)

theorem identity45186 : scanCanonicalize (H12AffineFastState.compose env45186 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45186 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45187 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2065,40,2048,0,34,2064,2049,53,1,2049,33,16,2,40,17,2049,2065,2064,2048,21,33,36,32,2049,513]

theorem envBound45187 : H12AffineFastState.Bounded env45187 := by
  intro p hp
  have h : env45187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45186_45187 : H12AffineEnvironment.transform 5 17 env45186 = env45187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45186 == env45187) = true)

theorem identity45187 : scanCanonicalize (H12AffineFastState.compose env45187 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45187 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45188 : List Nat := [2,4,8,16,27,17,8,31,512,14,2048,2065,19,2048,0,25,2064,2049,14,1,2049,26,16,2,19,17,2049,2065,2064,2048,21,26,31,27,2049,513]

theorem envBound45188 : H12AffineFastState.Bounded env45188 := by
  intro p hp
  have h : env45188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45187_45188 : H12AffineEnvironment.transform 4 27 env45187 = env45188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45187 == env45188) = true)

def env45189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98644,8328,64,12981332,79131,8466579,8819968,8389956,4292950,256,8462395,8492191,8462994]

theorem envBound45189 : H12AffineFastState.Bounded env45189 := by
  intro p hp
  have h : env45189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45126_45189 : H12AffineEnvironment.transform 13 5377 env45126 = env45189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45126 == env45189) = true)

def env45190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,32,8388608,98644,8328,64,8787060,79131,8466579,8819968,8389956,98678,256,8462395,8492191,8462994]

theorem envBound45190 : H12AffineFastState.Bounded env45190 := by
  intro p hp
  have h : env45190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45189_45190 : H12AffineEnvironment.transform 21 32 env45189 = env45190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env45189 == env45190) = true)

def env45191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,8388608,98644,8192,64,8787060,79131,8466459,8819968,8389956,98678,256,8462395,8492055,8462874]

theorem envBound45191 : H12AffineFastState.Bounded env45191 := by
  intro p hp
  have h : env45191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45190_45191 : H12AffineEnvironment.transform 6 8 env45190 = env45191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45190 == env45191) = true)

def env45192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,16,98644,8192,64,398436,79131,77835,431376,1364,98678,256,73771,103431,74250]

theorem envBound45192 : H12AffineFastState.Bounded env45192 := by
  intro p hp
  have h : env45192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45191_45192 : H12AffineEnvironment.transform 22 16 env45191 = env45192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env45191 == env45192) = true)

theorem identity45192 : scanCanonicalize (H12AffineFastState.compose env45192 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45192 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,32,16,73737,8192,64,398436,79131,77835,406605,1364,73771,256,73771,79194,74250]

theorem envBound45193 : H12AffineFastState.Bounded env45193 := by
  intro p hp
  have h : env45193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45192_45193 : H12AffineEnvironment.transform 14 8541 env45192 = env45193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45192 == env45193) = true)

theorem identity45193 : scanCanonicalize (H12AffineFastState.compose env45193 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound45193 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10361,1024,8540,77898,32,16,73737,8192,64,146461,79131,77835,138292,1364,73771,256,73771,79194,74250]

theorem envBound45194 : H12AffineFastState.Bounded env45194 := by
  intro p hp
  have h : env45194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45193_45194 : H12AffineEnvironment.transform 17 10361 env45193 = env45194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env45193 == env45194) = true)

theorem identity45194 : scanCanonicalize (H12AffineFastState.compose env45194 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound45194 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env45195 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,79131,10361,1024,8540,77898,32,16,73737,8192,64,67846,79131,77835,76079,1364,73771,256,73771,79194,74250]

theorem envBound45195 : H12AffineFastState.Bounded env45195 := by
  intro p hp
  have h : env45195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45194_45195 : H12AffineEnvironment.transform 16 79131 env45194 = env45195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env45194 == env45195) = true)

theorem identity45195 : scanCanonicalize (H12AffineFastState.compose env45195 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound45195 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env45196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,115,13672,10361,1024,8540,12345,32,16,8314,8192,64,2421,13672,12408,10588,1364,8280,256,8280,13609,8825]

theorem envBound45196 : H12AffineFastState.Bounded env45196 := by
  intro p hp
  have h : env45196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45195_45196 : H12AffineEnvironment.transform 15 115 env45195 = env45196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env45195 == env45196) = true)

theorem identity45196 : scanCanonicalize (H12AffineFastState.compose env45196 (packedSelected [0,3,5,7,10,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45196 : packedSelected [0,3,5,7,10,11,16] rootPS < 2^1333 := by decide +kernel

def env45197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,8192,5377,8541,115,13672,8313,1024,8540,12345,32,16,8314,8192,64,373,13672,12408,8540,1364,8280,256,8280,13609,8825]

theorem envBound45197 : H12AffineFastState.Bounded env45197 := by
  intro p hp
  have h : env45197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45196_45197 : H12AffineEnvironment.transform 10 0 env45196 = env45197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45196 == env45197) = true)

theorem identity45197 : scanCanonicalize (H12AffineFastState.compose env45197 (packedSelected [0,3,5,7,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 4136) := by decide +kernel

theorem selectedBound45197 : packedSelected [0,3,5,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,4096,4136,5377,4469,115,1344,4177,1024,4468,17,32,16,4178,4136,64,373,1344,80,4468,1364,4208,256,4208,1281,4689]

theorem envBound45198 : H12AffineFastState.Bounded env45198 := by
  intro p hp
  have h : env45198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45197_45198 : H12AffineEnvironment.transform 12 4136 env45197 = env45198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4136 env45197 == env45198) = true)

theorem identity45198 : scanCanonicalize (H12AffineFastState.compose env45198 (packedSelected [2,3,4,5,6,9,10,14,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound45198 : packedSelected [2,3,4,5,6,9,10,14,18,20] rootPS < 2^1333 := by decide +kernel

def env45199 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,293,269,1060,80,115,1344,372,1024,81,17,32,16,375,269,64,373,1344,80,81,1364,341,256,341,1281,884]

theorem envBound45199 : H12AffineFastState.Bounded env45199 := by
  intro p hp
  have h : env45199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45198_45199 : H12AffineEnvironment.transform 11 293 env45198 = env45199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env45198 == env45199) = true)

theorem identity45199 : scanCanonicalize (H12AffineFastState.compose env45199 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45199 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45200 : List Nat := [2,4,8,16,32,64,8,117,512,1024,0,80,120,1060,80,115,1077,1,1024,81,17,32,16,2,120,64,0,1077,80,81,1057,32,117,32,1140,513]

theorem envBound45200 : H12AffineFastState.Bounded env45200 := by
  intro p hp
  have h : env45200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45199_45200 : H12AffineEnvironment.transform 7 117 env45199 = env45200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45199 == env45200) = true)

theorem identity45200 : scanCanonicalize (H12AffineFastState.compose env45200 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound45200 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45201 : List Nat := [2,4,8,16,32,64,8,117,512,101,0,80,120,65,80,115,80,1,101,81,17,32,16,2,120,64,0,80,80,81,68,32,117,32,17,513]

theorem envBound45201 : H12AffineFastState.Bounded env45201 := by
  intro p hp
  have h : env45201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45200_45201 : H12AffineEnvironment.transform 9 101 env45200 = env45201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env45200 == env45201) = true)

theorem identity45201 : scanCanonicalize (H12AffineFastState.compose env45201 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound45201 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45202 : List Nat := [2,4,8,16,32,64,8,117,16,101,0,80,120,65,80,115,80,1,101,81,17,32,16,2,120,64,0,80,80,81,68,32,117,32,17,17]

theorem envBound45202 : H12AffineFastState.Bounded env45202 := by
  intro p hp
  have h : env45202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45201_45202 : H12AffineEnvironment.transform 8 16 env45201 = env45202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env45201 == env45202) = true)

theorem identity45202 : scanCanonicalize (H12AffineFastState.compose env45202 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45202 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env45203 : List Nat := [2,4,8,16,17,64,8,68,16,84,0,80,73,65,80,66,80,1,84,81,17,17,16,2,73,64,0,80,80,81,68,17,68,17,17,17]

theorem envBound45203 : H12AffineFastState.Bounded env45203 := by
  intro p hp
  have h : env45203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45202_45203 : H12AffineEnvironment.transform 4 17 env45202 = env45203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45202 == env45203) = true)

def env45204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,17,98644,8192,64,398437,79131,77834,431377,1365,98678,256,73770,103430,74251]

theorem envBound45204 : H12AffineFastState.Bounded env45204 := by
  intro p hp
  have h : env45204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45191_45204 : H12AffineEnvironment.transform 22 17 env45191 = env45204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env45191 == env45204) = true)

theorem identity45204 : scanCanonicalize (H12AffineFastState.compose env45204 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound45204 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,77898,32,17,98644,8192,64,171281,79131,77834,138341,1365,98678,256,73770,103430,74251]

theorem envBound45205 : H12AffineFastState.Bounded env45205 := by
  intro p hp
  have h : env45205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45204_45205 : H12AffineEnvironment.transform 17 35188 env45204 = env45205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env45204 == env45205) = true)

theorem identity45205 : scanCanonicalize (H12AffineFastState.compose env45205 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45205 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,131072,35188,1024,32769,4160,32,17,41310,8192,64,171281,5393,4096,138341,1365,41340,256,32,46092,513]

theorem envBound45206 : H12AffineFastState.Bounded env45206 := by
  intro p hp
  have h : env45206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45205_45206 : H12AffineEnvironment.transform 15 8202 env45205 = env45206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45205 == env45206) = true)

theorem identity45206 : scanCanonicalize (H12AffineFastState.compose env45206 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12637) := by decide +kernel

theorem selectedBound45206 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env45207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,12637,35188,1024,32769,4160,32,17,41310,8192,64,44108,5393,4096,11576,1365,41340,256,32,46092,513]

theorem envBound45207 : H12AffineFastState.Bounded env45207 := by
  intro p hp
  have h : env45207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45206_45207 : H12AffineEnvironment.transform 16 12637 env45206 = env45207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12637 env45206 == env45207) = true)

theorem identity45207 : scanCanonicalize (H12AffineFastState.compose env45207 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound45207 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env45208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1094,5393,35188,1024,32769,4160,32,17,34066,1100,64,34816,5393,4096,2420,1365,34096,256,32,36928,513]

theorem envBound45208 : H12AffineFastState.Bounded env45208 := by
  intro p hp
  have h : env45208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45207_45208 : H12AffineEnvironment.transform 12 1100 env45207 = env45208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env45207 == env45208) = true)

theorem identity45208 : scanCanonicalize (H12AffineFastState.compose env45208 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound45208 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45209 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,512,1100,1793,32768,1094,1809,35188,1024,32769,576,32,17,34066,1100,64,34816,1809,512,2420,1365,34096,256,32,33344,513]

theorem envBound45209 : H12AffineFastState.Bounded env45209 := by
  intro p hp
  have h : env45209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45208_45209 : H12AffineEnvironment.transform 11 512 env45208 = env45209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env45208 == env45209) = true)

theorem identity45209 : scanCanonicalize (H12AffineFastState.compose env45209 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound45209 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45210 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,512,1100,1793,1296,1094,1809,3172,1024,1297,576,32,17,2,1100,64,3344,1809,512,2420,1365,32,256,32,1872,513]

theorem envBound45210 : H12AffineFastState.Bounded env45210 := by
  intro p hp
  have h : env45210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45209_45210 : H12AffineEnvironment.transform 14 1296 env45209 = env45210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env45209 == env45210) = true)

theorem identity45210 : scanCanonicalize (H12AffineFastState.compose env45210 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound45210 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45211 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,512,121,820,293,115,804,2129,53,292,576,32,17,2,121,64,2341,804,512,2420,352,32,256,32,869,513]

theorem envBound45211 : H12AffineFastState.Bounded env45211 := by
  intro p hp
  have h : env45211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45210_45211 : H12AffineEnvironment.transform 9 53 env45210 = env45211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45210 == env45211) = true)

def env45212 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,8388608,98644,8193,64,8787060,79131,8466458,8819968,8389956,98678,256,8462395,8492054,8462875]

theorem envBound45212 : H12AffineFastState.Bounded env45212 := by
  intro p hp
  have h : env45212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45190_45212 : H12AffineEnvironment.transform 6 9 env45190 = env45212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45190 == env45212) = true)

def env45213 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,16,98644,8193,64,398436,79131,77834,431376,1364,98678,256,73771,103430,74251]

theorem envBound45213 : H12AffineFastState.Bounded env45213 := by
  intro p hp
  have h : env45213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45212_45213 : H12AffineEnvironment.transform 22 16 env45212 = env45213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env45212 == env45213) = true)

theorem identity45213 : scanCanonicalize (H12AffineFastState.compose env45213 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45213 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45214 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398436,5393,4096,431376,1364,41340,256,33,46092,513]

theorem envBound45214 : H12AffineFastState.Bounded env45214 := by
  intro p hp
  have h : env45214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45213_45214 : H12AffineEnvironment.transform 15 8202 env45213 = env45214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45213 == env45214) = true)

theorem identity45214 : scanCanonicalize (H12AffineFastState.compose env45214 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45214 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45215 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398436,5393,4096,406605,1364,33,256,33,5457,513]

theorem envBound45215 : H12AffineFastState.Bounded env45215 := by
  intro p hp
  have h : env45215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45214_45215 : H12AffineEnvironment.transform 14 8541 env45214 = env45215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45214 == env45215) = true)

theorem identity45215 : scanCanonicalize (H12AffineFastState.compose env45215 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45215 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45216 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,32,16,3,8193,16,398388,5393,4096,406557,1284,33,256,33,5377,513]

theorem envBound45216 : H12AffineFastState.Bounded env45216 := by
  intro p hp
  have h : env45216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45215_45216 : H12AffineEnvironment.transform 5 16 env45215 = env45216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45215 == env45216) = true)

theorem identity45216 : scanCanonicalize (H12AffineFastState.compose env45216 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound45216 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45217 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,10281,1024,8460,4113,32,16,3,8193,16,146461,5393,4096,138292,1284,33,256,33,5377,513]

theorem envBound45217 : H12AffineFastState.Bounded env45217 := by
  intro p hp
  have h : env45217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45216_45217 : H12AffineEnvironment.transform 17 10281 env45216 = env45217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env45216 == env45217) = true)

theorem identity45217 : scanCanonicalize (H12AffineFastState.compose env45217 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45217 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45218 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,131072,2341,1024,0,4113,32,16,3,269,16,138513,5393,4096,138292,1284,33,256,33,5377,513]

theorem envBound45218 : H12AffineFastState.Bounded env45218 := by
  intro p hp
  have h : env45218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45217_45218 : H12AffineEnvironment.transform 12 268 env45217 = env45218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45217 == env45218) = true)

theorem identity45218 : scanCanonicalize (H12AffineFastState.compose env45218 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45218 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45219 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4113,1,262,131072,2341,272,0,4113,32,16,3,269,16,137217,4097,4096,137508,20,33,256,33,4113,513]

theorem envBound45219 : H12AffineFastState.Bounded env45219 := by
  intro p hp
  have h : env45219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45218_45219 : H12AffineEnvironment.transform 9 272 env45218 = env45219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45218 == env45219) = true)

theorem identity45219 : scanCanonicalize (H12AffineFastState.compose env45219 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound45219 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45220 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4113,1,262,4097,2341,272,0,4113,32,16,3,269,16,2048,4097,4096,2341,20,33,256,33,4113,513]

theorem envBound45220 : H12AffineFastState.Bounded env45220 := by
  intro p hp
  have h : env45220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45219_45220 : H12AffineEnvironment.transform 16 4097 env45219 = env45220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env45219 == env45220) = true)

theorem identity45220 : scanCanonicalize (H12AffineFastState.compose env45220 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45221 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,1,35,4097,2048,53,0,4113,32,16,3,40,16,2048,4097,4096,2048,20,33,37,33,4113,513]

theorem envBound45221 : H12AffineFastState.Bounded env45221 := by
  intro p hp
  have h : env45221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45220_45221 : H12AffineEnvironment.transform 7 37 env45220 = env45221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45220 == env45221) = true)

theorem identity45221 : scanCanonicalize (H12AffineFastState.compose env45221 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound45221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45222 : List Nat := [2,4,8,16,32,16,9,37,512,53,529,4096,41,4113,1,35,4097,529,53,0,4113,32,16,3,40,16,529,4097,4096,529,20,33,37,33,4113,513]

theorem envBound45222 : H12AffineFastState.Bounded env45222 := by
  intro p hp
  have h : env45222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45221_45222 : H12AffineEnvironment.transform 10 529 env45221 = env45222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env45221 == env45222) = true)

theorem identity45222 : scanCanonicalize (H12AffineFastState.compose env45222 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound45222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45223 : List Nat := [2,4,8,16,32,16,9,37,512,53,529,570,41,555,1,35,571,529,53,0,555,32,16,3,40,16,529,571,570,529,20,33,37,33,555,513]

theorem envBound45223 : H12AffineFastState.Bounded env45223 := by
  intro p hp
  have h : env45223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45222_45223 : H12AffineEnvironment.transform 11 570 env45222 = env45223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env45222 == env45223) = true)

def env45224 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,32,17,98644,8193,64,398437,79131,77835,431377,1365,98678,256,73770,103431,74250]

theorem envBound45224 : H12AffineFastState.Bounded env45224 := by
  intro p hp
  have h : env45224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45212_45224 : H12AffineEnvironment.transform 22 17 env45212 = env45224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env45212 == env45224) = true)

theorem identity45224 : scanCanonicalize (H12AffineFastState.compose env45224 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45224 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45225 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1024,32769,77899,32,17,98644,8193,64,146509,79131,77835,179513,1365,98678,256,73770,103431,74250]

theorem envBound45225 : H12AffineFastState.Bounded env45225 := by
  intro p hp
  have h : env45225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45224_45225 : H12AffineEnvironment.transform 17 10280 env45224 = env45225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45224 == env45225) = true)

def env45226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,8388608,98644,8328,64,8787061,79131,8466579,8819968,8389956,98679,256,8462395,8492191,8462994]

theorem envBound45226 : H12AffineFastState.Bounded env45226 := by
  intro p hp
  have h : env45226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45189_45226 : H12AffineEnvironment.transform 21 33 env45189 = env45226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env45189 == env45226) = true)

theorem identity45226 : scanCanonicalize (H12AffineFastState.compose env45226 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound45226 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,33,16,98644,8328,64,398437,79131,77955,431376,1364,98679,256,73771,103567,74370]

theorem envBound45227 : H12AffineFastState.Bounded env45227 := by
  intro p hp
  have h : env45227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45226_45227 : H12AffineEnvironment.transform 22 16 env45226 = env45227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env45226 == env45227) = true)

def env45228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,16,98644,8192,64,398437,79131,77835,431376,1364,98679,256,73771,103431,74250]

theorem envBound45228 : H12AffineFastState.Bounded env45228 := by
  intro p hp
  have h : env45228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45227_45228 : H12AffineEnvironment.transform 6 8 env45227 = env45228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45227 == env45228) = true)

theorem identity45228 : scanCanonicalize (H12AffineFastState.compose env45228 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45228 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,33,16,73737,8192,64,398437,79131,77835,406605,1364,73770,256,73771,79194,74250]

theorem envBound45229 : H12AffineFastState.Bounded env45229 := by
  intro p hp
  have h : env45229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45228_45229 : H12AffineEnvironment.transform 14 8541 env45228 = env45229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45228 == env45229) = true)

theorem identity45229 : scanCanonicalize (H12AffineFastState.compose env45229 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound45229 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,138293,1024,8540,77898,33,16,73737,8192,64,2128,79131,77835,10360,1364,73770,256,73771,79194,74250]

theorem envBound45230 : H12AffineFastState.Bounded env45230 := by
  intro p hp
  have h : env45230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45229_45230 : H12AffineEnvironment.transform 17 138293 env45229 = env45230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env45229 == env45230) = true)

theorem identity45230 : scanCanonicalize (H12AffineFastState.compose env45230 (packedSelected [0,7,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound45230 : packedSelected [0,7,11,15,20] rootPS < 2^1333 := by decide +kernel

def env45231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,1094,131072,138293,1024,8540,13324,33,16,9295,8192,64,2128,12637,13389,10360,1364,9324,256,9325,12572,9804]

theorem envBound45231 : H12AffineFastState.Bounded env45231 := by
  intro p hp
  have h : env45231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45230_45231 : H12AffineEnvironment.transform 15 1094 env45230 = env45231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env45230 == env45231) = true)

theorem identity45231 : scanCanonicalize (H12AffineFastState.compose env45231 (packedSelected [0,2,4,5,6,7,9,12,14,15,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound45231 : packedSelected [0,2,4,5,6,7,9,12,14,15,19,24] rootPS < 2^1333 := by decide +kernel

def env45232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,1125,1094,131072,138293,1024,1124,4404,33,16,375,1336,64,2128,5221,4469,3392,1364,340,256,341,5156,884]

theorem envBound45232 : H12AffineFastState.Bounded env45232 := by
  intro p hp
  have h : env45232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45231_45232 : H12AffineEnvironment.transform 12 1336 env45231 = env45232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env45231 == env45232) = true)

theorem identity45232 : scanCanonicalize (H12AffineFastState.compose env45232 (packedSelected [2,4,6,9,11,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45232 : packedSelected [2,4,6,9,11,14,16] rootPS < 2^1333 := by decide +kernel

def env45233 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1125,1094,131072,138293,1024,1124,4161,33,16,2,1101,64,2128,5221,4096,3125,1057,33,117,32,5156,513]

theorem envBound45233 : H12AffineFastState.Bounded env45233 := by
  intro p hp
  have h : env45233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45232_45233 : H12AffineEnvironment.transform 7 117 env45232 = env45233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45232 == env45233) = true)

theorem identity45233 : scanCanonicalize (H12AffineFastState.compose env45233 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 4176) := by decide +kernel

theorem selectedBound45233 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45234 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1125,1094,4176,3173,1024,1124,4161,33,16,2,1101,64,2128,5221,4096,3125,1057,33,117,32,5156,513]

theorem envBound45234 : H12AffineFastState.Bounded env45234 := by
  intro p hp
  have h : env45234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45233_45234 : H12AffineEnvironment.transform 16 4176 env45233 = env45234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4176 env45233 == env45234) = true)

theorem identity45234 : scanCanonicalize (H12AffineFastState.compose env45234 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound45234 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45235 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,1101,1124,1125,1094,64,3173,1024,1124,81,33,16,2,1101,64,2128,1141,16,3125,1057,33,117,32,1076,513]

theorem envBound45235 : H12AffineFastState.Bounded env45235 := by
  intro p hp
  have h : env45235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45234_45235 : H12AffineEnvironment.transform 11 16 env45234 = env45235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45234 == env45235) = true)

theorem identity45235 : scanCanonicalize (H12AffineFastState.compose env45235 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45235 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env45236 : List Nat := [2,4,8,16,32,64,8,117,512,100,2048,16,41,0,1,34,64,2049,100,0,81,33,16,2,41,64,2128,17,16,2129,69,33,117,32,80,513]

theorem envBound45236 : H12AffineFastState.Bounded env45236 := by
  intro p hp
  have h : env45236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45235_45236 : H12AffineEnvironment.transform 9 100 env45235 = env45236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45235 == env45236) = true)

theorem identity45236 : scanCanonicalize (H12AffineFastState.compose env45236 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound45236 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45237 : List Nat := [2,4,8,16,32,64,8,117,512,100,81,16,41,0,1,34,64,80,100,0,81,33,16,2,41,64,1,17,16,0,69,33,117,32,80,513]

theorem envBound45237 : H12AffineFastState.Bounded env45237 := by
  intro p hp
  have h : env45237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45236_45237 : H12AffineEnvironment.transform 10 81 env45236 = env45237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env45236 == env45237) = true)

def env45238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,33,16,98644,8193,64,398437,79131,77834,431376,1364,98679,256,73771,103430,74251]

theorem envBound45238 : H12AffineFastState.Bounded env45238 := by
  intro p hp
  have h : env45238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45227_45238 : H12AffineEnvironment.transform 6 9 env45227 = env45238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45227 == env45238) = true)

theorem identity45238 : scanCanonicalize (H12AffineFastState.compose env45238 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45238 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env45239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398437,5393,4096,431376,1364,41341,256,33,46092,513]

theorem envBound45239 : H12AffineFastState.Bounded env45239 := by
  intro p hp
  have h : env45239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45238_45239 : H12AffineEnvironment.transform 15 8202 env45238 = env45239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45238 == env45239) = true)

theorem identity45239 : scanCanonicalize (H12AffineFastState.compose env45239 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45239 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env45240 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398437,5393,4096,406605,1364,32,256,33,5457,513]

theorem envBound45240 : H12AffineFastState.Bounded env45240 := by
  intro p hp
  have h : env45240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45239_45240 : H12AffineEnvironment.transform 14 8541 env45239 = env45240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45239 == env45240) = true)

theorem identity45240 : scanCanonicalize (H12AffineFastState.compose env45240 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45240 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45241 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,262144,1024,8460,4113,33,16,3,8193,16,398389,5393,4096,406557,1284,32,256,33,5377,513]

theorem envBound45241 : H12AffineFastState.Bounded env45241 := by
  intro p hp
  have h : env45241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45240_45241 : H12AffineEnvironment.transform 5 16 env45240 = env45241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45240 == env45241) = true)

theorem identity45241 : scanCanonicalize (H12AffineFastState.compose env45241 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138293) := by decide +kernel

theorem selectedBound45241 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env45242 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,138293,1024,8460,4113,33,16,3,8193,16,2048,5393,4096,10280,1284,32,256,33,5377,513]

theorem envBound45242 : H12AffineFastState.Bounded env45242 := by
  intro p hp
  have h : env45242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45241_45242 : H12AffineEnvironment.transform 17 138293 env45241 = env45242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138293 env45241 == env45242) = true)

theorem identity45242 : scanCanonicalize (H12AffineFastState.compose env45242 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound45242 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45243 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,13341,10280,1024,8460,4113,33,16,3,8193,16,2048,5393,4096,10280,1284,32,256,33,5377,513]

theorem envBound45243 : H12AffineFastState.Bounded env45243 := by
  intro p hp
  have h : env45243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45242_45243 : H12AffineEnvironment.transform 16 13341 env45242 = env45243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env45242 == env45243) = true)

theorem identity45243 : scanCanonicalize (H12AffineFastState.compose env45243 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45243 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45244 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1024,0,4113,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound45244 : H12AffineFastState.Bounded env45244 := by
  intro p hp
  have h : env45244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45243_45244 : H12AffineEnvironment.transform 12 268 env45243 = env45244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45243 == env45244) = true)

theorem identity45244 : scanCanonicalize (H12AffineFastState.compose env45244 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45245 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5172,2049,1024,0,4113,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound45245 : H12AffineFastState.Bounded env45245 := by
  intro p hp
  have h : env45245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45244_45245 : H12AffineEnvironment.transform 7 37 env45244 = env45245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45244 == env45245) = true)

def env45246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound45246 : H12AffineFastState.Bounded env45246 := by
  intro p hp
  have h : env45246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45013_45246 : H12AffineEnvironment.transform 18 1025 env45013 = env45246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env45013 == env45246) = true)

theorem identity45246 : scanCanonicalize (H12AffineFastState.compose env45246 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10650947) := by decide +kernel

theorem selectedBound45246 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env45247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10650947,8328,64,6636867,8585679,10507600,8830976,2294099,12836994,257,213486,237642,2238084]

theorem envBound45247 : H12AffineFastState.Bounded env45247 := by
  intro p hp
  have h : env45247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45246_45247 : H12AffineEnvironment.transform 23 10650947 env45246 = env45247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10650947 env45246 == env45247) = true)

def env45248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180224,2114883,8328,64,6636867,115151,2266448,262144,2294099,4268162,257,213486,237642,2238084]

theorem envBound45248 : H12AffineFastState.Bounded env45248 := by
  intro p hp
  have h : env45248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45247_45248 : H12AffineEnvironment.transform 22 180224 env45247 = env45248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env45247 == env45248) = true)

def env45249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,169235,8328,64,4691219,115151,17664,262144,119043,4268162,257,213486,237642,63188]

theorem envBound45249 : H12AffineFastState.Bounded env45249 := by
  intro p hp
  have h : env45249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45248_45249 : H12AffineEnvironment.transform 20 184400 env45248 = env45249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env45248 == env45249) = true)

def env45250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,169235,8328,64,245139,115151,17664,262144,119043,329730,257,213486,237642,63188]

theorem envBound45250 : H12AffineFastState.Bounded env45250 := by
  intro p hp
  have h : env45250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45249_45250 : H12AffineEnvironment.transform 21 272512 env45249 = env45250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45249 == env45250) = true)

theorem identity45250 : scanCanonicalize (H12AffineFastState.compose env45250 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound45250 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184400,272512,180224,169235,8328,64,158028,5392,17664,262144,1500,318685,257,169265,160917,63188]

theorem envBound45251 : H12AffineFastState.Bounded env45251 := by
  intro p hp
  have h : env45251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45250_45251 : H12AffineEnvironment.transform 15 54495 env45250 = env45251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env45250 == env45251) = true)

theorem identity45251 : scanCanonicalize (H12AffineFastState.compose env45251 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound45251 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env45252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,262144,1025,29908,140421,272512,144597,156102,8328,64,158028,5392,17664,262144,1500,272392,257,156132,160917,513]

theorem envBound45252 : H12AffineFastState.Bounded env45252 := by
  intro p hp
  have h : env45252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45251_45252 : H12AffineEnvironment.transform 14 29909 env45251 = env45252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env45251 == env45252) = true)

theorem identity45252 : scanCanonicalize (H12AffineFastState.compose env45252 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound45252 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env45253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,2557,1025,29908,140421,8573,144597,156102,8328,64,158028,5392,17664,2557,1500,8693,257,156132,160917,513]

theorem envBound45253 : H12AffineFastState.Bounded env45253 := by
  intro p hp
  have h : env45253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45252_45253 : H12AffineEnvironment.transform 17 2557 env45252 = env45253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env45252 == env45253) = true)

theorem identity45253 : scanCanonicalize (H12AffineFastState.compose env45253 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound45253 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env45254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,8202,131072,2557,1025,1,140421,8573,144597,136467,8328,64,138649,5392,12757,2557,1500,8693,257,136497,131136,513]

theorem envBound45254 : H12AffineFastState.Bounded env45254 := by
  intro p hp
  have h : env45254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45253_45254 : H12AffineEnvironment.transform 13 13525 env45253 = env45254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env45253 == env45254) = true)

theorem identity45254 : scanCanonicalize (H12AffineFastState.compose env45254 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45254 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env45255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5513,0,342,131072,2557,1025,1,132569,33,136585,136467,468,64,138649,5392,4233,2557,1500,169,257,136497,131136,513]

theorem envBound45255 : H12AffineFastState.Bounded env45255 := by
  intro p hp
  have h : env45255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45254_45255 : H12AffineEnvironment.transform 12 348 env45254 = env45255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45254 == env45255) = true)

theorem identity45255 : scanCanonicalize (H12AffineFastState.compose env45255 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound45255 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env45256 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,4113,0,342,131072,2557,409,1,131137,33,135185,135307,468,64,137217,4232,4233,2557,68,169,257,135337,131136,513]

theorem envBound45256 : H12AffineFastState.Bounded env45256 := by
  intro p hp
  have h : env45256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45255_45256 : H12AffineEnvironment.transform 9 408 env45255 = env45256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env45255 == env45256) = true)

theorem identity45256 : scanCanonicalize (H12AffineFastState.compose env45256 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound45256 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45257 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,348,4113,0,342,4096,2557,409,1,4161,33,17,139,468,64,2049,4232,4233,2557,68,169,257,169,4160,513]

theorem envBound45257 : H12AffineFastState.Bounded env45257 := by
  intro p hp
  have h : env45257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45256_45257 : H12AffineEnvironment.transform 16 4096 env45256 = env45257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env45256 == env45257) = true)

theorem identity45257 : scanCanonicalize (H12AffineFastState.compose env45257 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 2471) := by decide +kernel

theorem selectedBound45257 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45258 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,2471,348,2486,0,342,2471,2557,409,1,2534,33,17,139,468,64,2049,2351,2350,2557,68,169,257,169,2535,513]

theorem envBound45258 : H12AffineFastState.Bounded env45258 := by
  intro p hp
  have h : env45258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45257_45258 : H12AffineEnvironment.transform 11 2471 env45257 = env45258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2471 env45257 == env45258) = true)

theorem identity45258 : scanCanonicalize (H12AffineFastState.compose env45258 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45258 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45259 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2351,348,2366,0,342,2351,2421,273,1,2414,33,17,3,348,64,2049,2351,2350,2421,68,33,257,33,2415,513]

theorem envBound45259 : H12AffineFastState.Bounded env45259 := by
  intro p hp
  have h : env45259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45258_45259 : H12AffineEnvironment.transform 6 8 env45258 = env45259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45258 == env45259) = true)

theorem identity45259 : scanCanonicalize (H12AffineFastState.compose env45259 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound45259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45260 : List Nat := [2,4,8,16,32,64,8,100,512,116,2048,2123,56,2138,0,50,2123,2065,117,1,2058,33,17,3,56,64,2049,2123,2122,2065,68,33,101,33,2059,513]

theorem envBound45260 : H12AffineFastState.Bounded env45260 := by
  intro p hp
  have h : env45260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45259_45260 : H12AffineEnvironment.transform 7 100 env45259 = env45260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env45259 == env45260) = true)

theorem identity45260 : scanCanonicalize (H12AffineFastState.compose env45260 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 617) := by decide +kernel

theorem selectedBound45260 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45261 : List Nat := [2,4,8,16,32,64,8,100,512,116,617,546,56,563,0,50,546,632,117,1,611,33,17,3,56,64,616,546,547,632,68,33,101,33,610,513]

theorem envBound45261 : H12AffineFastState.Bounded env45261 := by
  intro p hp
  have h : env45261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45260_45261 : H12AffineEnvironment.transform 10 617 env45260 = env45261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 617 env45260 == env45261) = true)

theorem identity45261 : scanCanonicalize (H12AffineFastState.compose env45261 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound45261 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45262 : List Nat := [2,4,8,16,32,10,8,46,512,62,547,546,56,563,0,50,546,562,63,1,553,33,17,3,56,10,546,546,547,562,14,33,47,33,552,513]

theorem envBound45262 : H12AffineFastState.Bounded env45262 := by
  intro p hp
  have h : env45262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45261_45262 : H12AffineEnvironment.transform 5 10 env45261 = env45262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env45261 == env45262) = true)

theorem identity45262 : scanCanonicalize (H12AffineFastState.compose env45262 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45262 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env45263 : List Nat := [2,4,2,16,32,0,2,36,512,52,547,546,50,563,0,50,546,562,53,1,547,33,17,3,50,0,546,546,547,562,4,33,37,33,546,513]

theorem envBound45263 : H12AffineFastState.Bounded env45263 := by
  intro p hp
  have h : env45263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45262_45263 : H12AffineEnvironment.transform 2 2 env45262 = env45263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45262 == env45263) = true)

theorem identity45263 : scanCanonicalize (H12AffineFastState.compose env45263 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45263 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45264 : List Nat := [2,4,2,1,32,0,2,36,512,37,547,546,35,546,0,35,546,547,36,1,547,33,0,3,35,0,546,546,547,547,4,33,37,33,546,513]

theorem envBound45264 : H12AffineFastState.Bounded env45264 := by
  intro p hp
  have h : env45264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45263_45264 : H12AffineEnvironment.transform 3 1 env45263 = env45264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45263 == env45264) = true)

theorem identity45264 : scanCanonicalize (H12AffineFastState.compose env45264 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound45264 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45265 : List Nat := [2,4,2,1,32,0,2,36,37,37,6,7,35,7,0,35,7,6,36,1,6,33,0,3,35,0,7,7,6,6,4,33,37,33,7,36]

theorem envBound45265 : H12AffineFastState.Bounded env45265 := by
  intro p hp
  have h : env45265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45264_45265 : H12AffineEnvironment.transform 8 37 env45264 = env45265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env45264 == env45265) = true)

theorem identity45265 : scanCanonicalize (H12AffineFastState.compose env45265 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45265 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45266 : List Nat := [2,4,2,1,6,0,2,2,3,3,6,7,5,7,0,5,7,6,2,1,6,7,0,3,5,0,7,7,6,6,4,7,3,7,7,2]

theorem envBound45266 : H12AffineFastState.Bounded env45266 := by
  intro p hp
  have h : env45266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45265_45266 : H12AffineEnvironment.transform 4 6 env45265 = env45266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45265 == env45266) = true)

theorem identity45266 : scanCanonicalize (H12AffineFastState.compose env45266 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45266 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env45267 : List Nat := [2,3,2,1,1,0,2,2,3,3,1,0,2,0,0,2,0,1,2,1,1,0,0,3,2,0,0,0,1,1,3,0,3,0,0,2]

theorem envBound45267 : H12AffineFastState.Bounded env45267 := by
  intro p hp
  have h : env45267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45266_45267 : H12AffineEnvironment.transform 1 3 env45266 = env45267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45266 == env45267) = true)

def env45268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,169235,8328,64,245138,115151,17664,262144,119043,329731,257,213486,237642,63188]

theorem envBound45268 : H12AffineFastState.Bounded env45268 := by
  intro p hp
  have h : env45268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45249_45268 : H12AffineEnvironment.transform 21 272513 env45249 = env45268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45249 == env45268) = true)

theorem identity45268 : scanCanonicalize (H12AffineFastState.compose env45268 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound45268 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,115870,272513,120014,98781,8328,64,43356,115151,17664,262144,119043,329731,257,21792,46212,63188]

theorem envBound45269 : H12AffineFastState.Bounded env45269 := by
  intro p hp
  have h : env45269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45268_45269 : H12AffineEnvironment.transform 16 70862 env45268 = env45269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env45268 == env45269) = true)

theorem identity45269 : scanCanonicalize (H12AffineFastState.compose env45269 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound45269 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env45270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,76158,1025,32769,115870,66047,120014,98781,8328,64,43356,115151,17664,76158,119043,8573,257,21792,46212,63188]

theorem envBound45270 : H12AffineFastState.Bounded env45270 := by
  intro p hp
  have h : env45270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45269_45270 : H12AffineEnvironment.transform 17 76158 env45269 = env45270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env45269 == env45270) = true)

def env45271 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,115734,65911,119878,98645,8192,64,43356,115015,17664,76158,119043,8573,257,21792,46092,63068]

theorem envBound45271 : H12AffineFastState.Bounded env45271 := by
  intro p hp
  have h : env45271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45270_45271 : H12AffineEnvironment.transform 6 8 env45270 = env45271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45270 == env45271) = true)

theorem identity45271 : scanCanonicalize (H12AffineFastState.compose env45271 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound45271 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45272 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,70726,76158,1025,29788,77899,65911,73755,95496,8192,64,23809,79130,17664,76158,75102,8573,257,21792,16465,513]

theorem envBound45272 : H12AffineFastState.Bounded env45272 := by
  intro p hp
  have h : env45272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45271_45272 : H12AffineEnvironment.transform 14 29789 env45271 = env45272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env45271 == env45272) = true)

theorem identity45272 : scanCanonicalize (H12AffineFastState.compose env45272 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound45272 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env45273 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21591,16401,32041,1025,29788,25628,21792,29772,8543,8192,64,23809,24909,17664,32041,28937,8573,257,21792,16465,513]

theorem envBound45273 : H12AffineFastState.Bounded env45273 := by
  intro p hp
  have h : env45273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45272_45273 : H12AffineEnvironment.transform 15 21591 env45272 = env45273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env45272 == env45273) = true)

theorem identity45273 : scanCanonicalize (H12AffineFastState.compose env45273 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21591,16401,23668,1025,21761,17729,21792,21777,2,349,64,23809,16400,17664,23668,20564,32,257,21792,16465,513]

theorem envBound45274 : H12AffineFastState.Bounded env45274 := by
  intro p hp
  have h : env45274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45273_45274 : H12AffineEnvironment.transform 12 349 env45273 = env45274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45273 == env45274) = true)

theorem identity45274 : scanCanonicalize (H12AffineFastState.compose env45274 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45274 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env45275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,2421,1025,0,4160,33,16,2,349,64,2048,5393,4097,2421,1365,32,257,33,5456,513]

theorem envBound45275 : H12AffineFastState.Bounded env45275 := by
  intro p hp
  have h : env45275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45274_45275 : H12AffineEnvironment.transform 13 5377 env45274 = env45275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45274 == env45275) = true)

theorem identity45275 : scanCanonicalize (H12AffineFastState.compose env45275 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound45275 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45276 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5236,1,35,5221,2048,1025,0,4160,33,16,2,40,64,2048,5220,4097,2048,1056,32,116,33,5157,513]

theorem envBound45276 : H12AffineFastState.Bounded env45276 := by
  intro p hp
  have h : env45276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45275_45276 : H12AffineEnvironment.transform 7 117 env45275 = env45276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env45275 == env45276) = true)

theorem identity45276 : scanCanonicalize (H12AffineFastState.compose env45276 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45276 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45277 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1025,0,4113,33,16,2,40,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound45277 : H12AffineFastState.Bounded env45277 := by
  intro p hp
  have h : env45277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45276_45277 : H12AffineEnvironment.transform 5 17 env45276 = env45277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45276 == env45277) = true)

def env45278 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,40,1045,1,35,1028,2048,1025,0,33,33,16,2,40,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound45278 : H12AffineFastState.Bounded env45278 := by
  intro p hp
  have h : env45278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45277_45278 : H12AffineEnvironment.transform 11 48 env45277 = env45278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45277 == env45278) = true)

theorem identity45278 : scanCanonicalize (H12AffineFastState.compose env45278 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45279 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,40,1045,1,35,1028,0,1025,0,33,33,16,2,40,17,0,1029,49,0,1056,32,37,33,1045,513]

theorem envBound45279 : H12AffineFastState.Bounded env45279 := by
  intro p hp
  have h : env45279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45278_45279 : H12AffineEnvironment.transform 10 0 env45278 = env45279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45278 == env45279) = true)

def env45280 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,40,33,1,35,48,0,53,0,33,33,16,2,40,17,0,49,49,0,20,32,37,33,33,513]

theorem envBound45280 : H12AffineFastState.Bounded env45280 := by
  intro p hp
  have h : env45280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45279_45280 : H12AffineEnvironment.transform 9 52 env45279 = env45280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45279 == env45280) = true)

theorem identity45280 : scanCanonicalize (H12AffineFastState.compose env45280 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45280 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45281 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,40,33,1,35,48,0,53,0,33,33,16,2,40,17,0,49,49,0,20,32,37,33,33,10]

theorem envBound45281 : H12AffineFastState.Bounded env45281 := by
  intro p hp
  have h : env45281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45280_45281 : H12AffineEnvironment.transform 8 11 env45280 = env45281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45280 == env45281) = true)

def leafEnv45281 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,40,33,1,35,48,0,53,0,33,33,16,2,21,40,1,17,0,49,49,0,20,32,37,33,5,35,33,10,1,33,0]

def active45281 : List Nat := [0,1,2,3,4]

def tree45281 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45281 : H12WitnessSearch.Good tree45281 := H12GlobalWitnessIndex.good

theorem leafIdentity45281 : H12AffineFastState.composeSystem env45281 rootObs = leafEnv45281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45281 rootObs == leafEnv45281) = true)

theorem terminalChecked45281 : H12PackedTerminal.terminalCheckFast leafEnv45281 active45281 tree45281 = true := by decide +kernel

def env45282 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,40,32,1,35,49,0,52,0,33,33,16,2,40,17,0,48,49,0,21,32,37,33,32,513]

theorem envBound45282 : H12AffineFastState.Bounded env45282 := by
  intro p hp
  have h : env45282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45279_45282 : H12AffineEnvironment.transform 9 53 env45279 = env45282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45279 == env45282) = true)

theorem identity45282 : scanCanonicalize (H12AffineFastState.compose env45282 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45283 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,9,1,1,2,16,0,21,0,0,0,16,2,9,17,0,17,16,0,21,1,4,0,1,513]

theorem envBound45283 : H12AffineFastState.Bounded env45283 := by
  intro p hp
  have h : env45283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45282_45283 : H12AffineEnvironment.transform 4 1 env45282 = env45283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45282 == env45283) = true)

def leafEnv45283 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,9,1,1,2,16,0,21,0,0,0,16,2,20,9,1,17,0,17,16,0,21,1,4,0,5,2,1,513,1,0,0]

def active45283 : List Nat := [0,1,2,3,8]

def tree45283 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45283 : H12WitnessSearch.Good tree45283 := H12GlobalWitnessIndex.good

theorem leafIdentity45283 : H12AffineFastState.composeSystem env45283 rootObs = leafEnv45283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45283 rootObs == leafEnv45283) = true)

theorem terminalChecked45283 : H12PackedTerminal.terminalCheckFast leafEnv45283 active45283 tree45283 = true := by decide +kernel

def env45284 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,40,1044,1,35,1029,2048,1025,0,32,33,16,2,40,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound45284 : H12AffineFastState.Bounded env45284 := by
  intro p hp
  have h : env45284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45277_45284 : H12AffineEnvironment.transform 11 49 env45277 = env45284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env45277 == env45284) = true)

theorem identity45284 : scanCanonicalize (H12AffineFastState.compose env45284 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound45284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45285 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,40,1044,1,35,1029,1076,1025,0,32,33,16,2,40,17,1076,1028,48,1076,1056,32,37,33,1044,513]

theorem envBound45285 : H12AffineFastState.Bounded env45285 := by
  intro p hp
  have h : env45285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45284_45285 : H12AffineEnvironment.transform 10 1076 env45284 = env45285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env45284 == env45285) = true)

def env45286 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,40,32,1,35,49,0,53,0,32,33,16,2,40,17,0,48,48,0,20,32,37,33,32,513]

theorem envBound45286 : H12AffineFastState.Bounded env45286 := by
  intro p hp
  have h : env45286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45285_45286 : H12AffineEnvironment.transform 9 52 env45285 = env45286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env45285 == env45286) = true)

theorem identity45286 : scanCanonicalize (H12AffineFastState.compose env45286 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45287 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,40,32,1,35,49,0,53,0,32,33,16,2,40,17,0,48,48,0,20,32,37,33,32,10]

theorem envBound45287 : H12AffineFastState.Bounded env45287 := by
  intro p hp
  have h : env45287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45286_45287 : H12AffineEnvironment.transform 8 11 env45286 = env45287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45286 == env45287) = true)

def leafEnv45287 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,40,32,1,35,49,0,53,0,32,33,16,2,21,40,1,17,0,48,48,0,20,32,37,33,5,35,32,10,1,32,0]

def active45287 : List Nat := [0,1,2,3,4]

def tree45287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45287 : H12WitnessSearch.Good tree45287 := H12GlobalWitnessIndex.good

theorem leafIdentity45287 : H12AffineFastState.composeSystem env45287 rootObs = leafEnv45287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45287 rootObs == leafEnv45287) = true)

theorem terminalChecked45287 : H12PackedTerminal.terminalCheckFast leafEnv45287 active45287 tree45287 = true := by decide +kernel

def env45288 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,40,33,1,35,48,1,52,0,32,33,16,2,40,17,1,49,48,1,21,32,37,33,33,513]

theorem envBound45288 : H12AffineFastState.Bounded env45288 := by
  intro p hp
  have h : env45288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45285_45288 : H12AffineEnvironment.transform 9 53 env45285 = env45288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env45285 == env45288) = true)

theorem identity45288 : scanCanonicalize (H12AffineFastState.compose env45288 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45288 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45289 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,9,0,1,2,17,1,21,0,1,0,16,2,9,17,1,16,17,1,21,1,4,0,0,513]

theorem envBound45289 : H12AffineFastState.Bounded env45289 := by
  intro p hp
  have h : env45289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45288_45289 : H12AffineEnvironment.transform 4 1 env45288 = env45289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45288 == env45289) = true)

def leafEnv45289 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,9,0,1,2,17,1,21,0,1,0,16,2,20,9,1,17,1,16,17,1,21,1,4,0,5,2,0,513,1,1,0]

def active45289 : List Nat := [0,1,2,3,8]

def tree45289 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood45289 : H12WitnessSearch.Good tree45289 := H12GlobalWitnessIndex.good

theorem leafIdentity45289 : H12AffineFastState.composeSystem env45289 rootObs = leafEnv45289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env45289 rootObs == leafEnv45289) = true)

theorem terminalChecked45289 : H12PackedTerminal.terminalCheckFast leafEnv45289 active45289 tree45289 = true := by decide +kernel

def env45290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,76158,1025,32769,115735,65910,119879,98644,8193,64,43356,115014,17664,76158,119043,8573,257,21792,46093,63069]

theorem envBound45290 : H12AffineFastState.Bounded env45290 := by
  intro p hp
  have h : env45290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45270_45290 : H12AffineEnvironment.transform 6 9 env45270 = env45290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45270 == env45290) = true)

theorem identity45290 : scanCanonicalize (H12AffineFastState.compose env45290 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound45290 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env45291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,70727,76158,1025,0,82966,65910,87110,65877,8193,64,10589,82247,17664,76158,86274,8573,257,21792,13324,30300]

theorem envBound45291 : H12AffineFastState.Bounded env45291 := by
  intro p hp
  have h : env45291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45290_45291 : H12AffineEnvironment.transform 14 1 env45290 = env45291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env45290 == env45291) = true)

theorem identity45291 : scanCanonicalize (H12AffineFastState.compose env45291 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound45291 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env45292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29822,24633,23808,1025,0,12392,29960,8248,29995,8193,64,10589,13625,17664,23808,9596,8573,257,21792,13324,30300]

theorem envBound45292 : H12AffineFastState.Bounded env45292 := by
  intro p hp
  have h : env45292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45291_45292 : H12AffineEnvironment.transform 15 29822 env45291 = env45292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env45291 == env45292) = true)

theorem identity45292 : scanCanonicalize (H12AffineFastState.compose env45292 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound45292 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,1,8494,13673,2128,1025,0,12392,8280,8248,8315,8193,64,10589,13625,4176,2128,9596,8573,257,112,13324,8972]

theorem envBound45293 : H12AffineFastState.Bounded env45293 := by
  intro p hp
  have h : env45293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45292_45293 : H12AffineEnvironment.transform 13 5456 env45292 = env45293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env45292 == env45293) = true)

theorem identity45293 : scanCanonicalize (H12AffineFastState.compose env45293 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45293 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env45294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,1,35,5220,2128,1025,0,4453,341,309,374,268,64,2128,5172,4176,2128,1137,112,257,112,5377,513]

theorem envBound45294 : H12AffineFastState.Bounded env45294 := by
  intro p hp
  have h : env45294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45293_45294 : H12AffineEnvironment.transform 12 269 env45293 = env45294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45293 == env45294) = true)

theorem identity45294 : scanCanonicalize (H12AffineFastState.compose env45294 (packedSelected [0,2,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 372) := by decide +kernel

theorem selectedBound45294 : packedSelected [0,2,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env45295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,372,4096,269,5456,1,35,5220,292,1025,0,4453,341,309,374,268,64,292,5172,4176,292,1137,112,257,112,5377,513]

theorem envBound45295 : H12AffineFastState.Bounded env45295 := by
  intro p hp
  have h : env45295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45294_45295 : H12AffineEnvironment.transform 10 372 env45294 = env45295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env45294 == env45295) = true)

def env45296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,169234,8328,64,4691218,115151,17665,262144,119042,4268162,257,213486,237642,63189]

theorem envBound45296 : H12AffineFastState.Bounded env45296 := by
  intro p hp
  have h : env45296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45248_45296 : H12AffineEnvironment.transform 20 184401 env45248 = env45296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env45248 == env45296) = true)

def env45297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,169234,8328,64,245138,115151,17665,262144,119042,329730,257,213486,237642,63189]

theorem envBound45297 : H12AffineFastState.Bounded env45297 := by
  intro p hp
  have h : env45297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45296_45297 : H12AffineEnvironment.transform 21 272512 env45296 = env45297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env45296 == env45297) = true)

theorem identity45297 : scanCanonicalize (H12AffineFastState.compose env45297 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound45297 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272512,180224,169234,8328,64,171416,57797,17665,262144,61704,272392,257,156132,163904,63189]

theorem envBound45298 : H12AffineFastState.Bounded env45298 := by
  intro p hp
  have h : env45298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45297_45298 : H12AffineEnvironment.transform 15 8202 env45297 = env45298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env45297 == env45298) = true)

def env45299 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272392,180224,169234,8192,64,171280,57677,17665,262144,61704,272392,257,156012,163904,63069]

theorem envBound45299 : H12AffineFastState.Bounded env45299 := by
  intro p hp
  have h : env45299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45298_45299 : H12AffineEnvironment.transform 6 8 env45298 = env45299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45298 == env45299) = true)

def env45300 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272392,16,21762,8192,64,23808,57677,17665,262144,61704,272392,257,41340,16464,63069]

theorem envBound45300 : H12AffineFastState.Bounded env45300 := by
  intro p hp
  have h : env45300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45299_45300 : H12AffineEnvironment.transform 16 49168 env45299 = env45300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45299 == env45300) = true)

theorem identity45300 : scanCanonicalize (H12AffineFastState.compose env45300 (packedSelected [0,1,9,19,22,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45300 : packedSelected [0,1,9,19,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45301 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,262144,1025,32769,4161,264532,16,21762,348,64,23808,49169,17665,262144,53332,264532,257,32800,16464,55041]

theorem envBound45301 : H12AffineFastState.Bounded env45301 := by
  intro p hp
  have h : env45301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45300_45301 : H12AffineEnvironment.transform 12 348 env45300 = env45301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45300 == env45301) = true)

theorem identity45301 : scanCanonicalize (H12AffineFastState.compose env45301 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45301 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env45302 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49168,35189,1025,32769,4161,32801,16,21762,348,64,23808,49169,17665,35189,53332,32801,257,32800,16464,55041]

theorem envBound45302 : H12AffineFastState.Bounded env45302 := by
  intro p hp
  have h : env45302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45301_45302 : H12AffineEnvironment.transform 17 35189 env45301 = env45302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45301 == env45302) = true)

theorem identity45302 : scanCanonicalize (H12AffineFastState.compose env45302 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound45302 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45303 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,5392,23669,1025,21761,4161,21793,16,21762,348,64,23808,5393,17665,23669,1364,21793,257,21792,16464,513]

theorem envBound45303 : H12AffineFastState.Bounded env45303 := by
  intro p hp
  have h : env45303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45302_45303 : H12AffineEnvironment.transform 14 21760 env45302 = env45303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env45302 == env45303) = true)

theorem identity45303 : scanCanonicalize (H12AffineFastState.compose env45303 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45303 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45304 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,262,5392,23589,1025,21761,4113,21793,16,21762,268,16,23808,5393,17665,23589,1284,21793,257,21792,16384,513]

theorem envBound45304 : H12AffineFastState.Bounded env45304 := by
  intro p hp
  have h : env45304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45303_45304 : H12AffineEnvironment.transform 5 16 env45303 = env45304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45303 == env45304) = true)

theorem identity45304 : scanCanonicalize (H12AffineFastState.compose env45304 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound45304 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env45305 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2065,268,16384,19729,262,3329,17460,1025,19728,2048,19760,16,19731,268,16,17681,3328,17665,17460,1284,19760,257,19761,16384,513]

theorem envBound45305 : H12AffineFastState.Bounded env45305 := by
  intro p hp
  have h : env45305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45304_45305 : H12AffineEnvironment.transform 11 2065 env45304 = env45305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env45304 == env45305) = true)

theorem identity45305 : scanCanonicalize (H12AffineFastState.compose env45305 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 3124) := by decide +kernel

theorem selectedBound45305 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45306 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2065,268,3124,293,262,3329,2048,1025,292,2048,260,16,295,268,16,2341,3328,2357,2048,1284,260,257,261,3124,513]

theorem envBound45306 : H12AffineFastState.Bounded env45306 := by
  intro p hp
  have h : env45306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45305_45306 : H12AffineEnvironment.transform 13 3124 env45305 = env45306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3124 env45305 == env45306) = true)

theorem identity45306 : scanCanonicalize (H12AffineFastState.compose env45306 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45306 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45307 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,2065,40,3124,1,34,3109,2048,1025,0,2048,32,16,3,40,16,2049,3108,2065,2048,1056,32,37,33,3124,513]

theorem envBound45307 : H12AffineFastState.Bounded env45307 := by
  intro p hp
  have h : env45307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45306_45307 : H12AffineEnvironment.transform 7 36 env45306 = env45307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45306 == env45307) = true)

theorem identity45307 : scanCanonicalize (H12AffineFastState.compose env45307 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45308 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,16,40,1077,1,34,1060,1,1025,0,1,32,16,3,40,16,0,1061,16,1,1056,32,37,33,1077,513]

theorem envBound45308 : H12AffineFastState.Bounded env45308 := by
  intro p hp
  have h : env45308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45307_45308 : H12AffineEnvironment.transform 10 1 env45307 = env45308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45307 == env45308) = true)

theorem identity45308 : scanCanonicalize (H12AffineFastState.compose env45308 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound45308 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45309 : List Nat := [2,4,8,16,32,16,8,36,512,575,1,16,40,522,1,34,539,1,574,0,1,32,16,3,40,16,0,538,16,1,543,32,37,33,522,513]

theorem envBound45309 : H12AffineFastState.Bounded env45309 := by
  intro p hp
  have h : env45309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45308_45309 : H12AffineEnvironment.transform 9 575 env45308 = env45309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env45308 == env45309) = true)

theorem identity45309 : scanCanonicalize (H12AffineFastState.compose env45309 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound45309 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45310 : List Nat := [2,4,8,12,32,12,8,36,512,547,1,12,40,522,1,34,519,1,546,0,1,32,12,3,40,12,0,518,12,1,515,32,37,33,522,513]

theorem envBound45310 : H12AffineFastState.Bounded env45310 := by
  intro p hp
  have h : env45310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45309_45310 : H12AffineEnvironment.transform 3 12 env45309 = env45310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env45309 == env45310) = true)

theorem identity45310 : scanCanonicalize (H12AffineFastState.compose env45310 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound45310 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45311 : List Nat := [2,4,8,12,32,12,8,36,43,8,1,12,40,33,1,34,44,1,9,0,1,32,12,3,40,12,0,45,12,1,40,32,37,33,33,42]

theorem envBound45311 : H12AffineFastState.Bounded env45311 := by
  intro p hp
  have h : env45311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45310_45311 : H12AffineEnvironment.transform 8 43 env45310 = env45311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env45310 == env45311) = true)

theorem identity45311 : scanCanonicalize (H12AffineFastState.compose env45311 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound45311 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45312 : List Nat := [2,4,8,12,14,12,8,10,5,8,1,12,6,15,1,12,2,1,9,0,1,14,12,3,6,12,0,3,12,1,6,14,11,15,15,4]

theorem envBound45312 : H12AffineFastState.Bounded env45312 := by
  intro p hp
  have h : env45312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45311_45312 : H12AffineEnvironment.transform 4 14 env45311 = env45312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env45311 == env45312) = true)

theorem identity45312 : scanCanonicalize (H12AffineFastState.compose env45312 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound45312 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45313 : List Nat := [2,4,6,2,0,2,6,4,5,6,1,2,6,1,1,2,2,1,7,0,1,0,2,3,6,2,0,3,2,1,6,0,5,1,1,4]

theorem envBound45313 : H12AffineFastState.Bounded env45313 := by
  intro p hp
  have h : env45313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45312_45313 : H12AffineEnvironment.transform 2 6 env45312 = env45313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env45312 == env45313) = true)

def env45314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272392,17,21763,8192,64,23809,57677,17665,262144,61704,272392,257,41341,16465,63069]

theorem envBound45314 : H12AffineFastState.Bounded env45314 := by
  intro p hp
  have h : env45314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45299_45314 : H12AffineEnvironment.transform 16 49169 env45299 = env45314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45299 == env45314) = true)

theorem identity45314 : scanCanonicalize (H12AffineFastState.compose env45314 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound45314 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10280,1025,32769,4160,32,17,21763,8192,64,23809,57677,17665,10280,61704,32,257,41341,16465,63069]

theorem envBound45315 : H12AffineFastState.Bounded env45315 := by
  intro p hp
  have h : env45315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45314_45315 : H12AffineEnvironment.transform 17 10280 env45314 = env45315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env45314 == env45315) = true)

theorem identity45315 : scanCanonicalize (H12AffineFastState.compose env45315 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound45315 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,5393,10280,1025,21761,4160,32,17,21763,8192,64,23809,13389,17665,10280,9224,32,257,29821,16465,9053]

theorem envBound45316 : H12AffineFastState.Bounded env45316 := by
  intro p hp
  have h : env45316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45315_45316 : H12AffineEnvironment.transform 14 21760 env45315 = env45316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env45315 == env45316) = true)

theorem identity45316 : scanCanonicalize (H12AffineFastState.compose env45316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound45316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,8202,5393,10280,1025,0,4160,32,17,2,8192,64,2048,13389,4096,10280,9224,32,257,8572,5456,9053]

theorem envBound45317 : H12AffineFastState.Bounded env45317 := by
  intro p hp
  have h : env45317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45316_45317 : H12AffineEnvironment.transform 13 5377 env45316 = env45317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env45316 == env45317) = true)

theorem identity45317 : scanCanonicalize (H12AffineFastState.compose env45317 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45317 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env45318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5377,1,34,5393,2048,1025,0,4160,32,17,2,40,64,2048,5221,4096,2048,1056,32,257,340,5456,885]

theorem envBound45318 : H12AffineFastState.Bounded env45318 := by
  intro p hp
  have h : env45318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45317_45318 : H12AffineEnvironment.transform 12 40 env45317 = env45318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45317 == env45318) = true)

theorem identity45318 : scanCanonicalize (H12AffineFastState.compose env45318 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound45318 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45319 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,1,34,5221,2048,1025,0,4160,32,17,2,40,64,2048,5221,4096,2048,1056,32,117,32,5156,513]

theorem envBound45319 : H12AffineFastState.Bounded env45319 := by
  intro p hp
  have h : env45319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45318_45319 : H12AffineEnvironment.transform 7 116 env45318 = env45319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env45318 == env45319) = true)

theorem identity45319 : scanCanonicalize (H12AffineFastState.compose env45319 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound45319 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45320 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,4096,40,4112,1,34,4096,2048,100,0,4160,32,17,2,40,64,2048,4096,4096,2048,69,32,117,32,4161,513]

theorem envBound45320 : H12AffineFastState.Bounded env45320 := by
  intro p hp
  have h : env45320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45319_45320 : H12AffineEnvironment.transform 9 101 env45319 = env45320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env45319 == env45320) = true)

theorem identity45320 : scanCanonicalize (H12AffineFastState.compose env45320 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound45320 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45321 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,16,40,0,1,34,16,2048,100,0,80,32,17,2,40,64,2048,16,16,2048,69,32,117,32,81,513]

theorem envBound45321 : H12AffineFastState.Bounded env45321 := by
  intro p hp
  have h : env45321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45320_45321 : H12AffineEnvironment.transform 11 16 env45320 = env45321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45320 == env45321) = true)

theorem identity45321 : scanCanonicalize (H12AffineFastState.compose env45321 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound45321 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45322 : List Nat := [2,4,8,16,32,64,8,116,512,101,48,16,40,0,1,34,16,48,100,0,80,32,17,2,40,64,48,16,16,48,69,32,117,32,81,513]

theorem envBound45322 : H12AffineFastState.Bounded env45322 := by
  intro p hp
  have h : env45322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45321_45322 : H12AffineEnvironment.transform 10 48 env45321 = env45322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env45321 == env45322) = true)

def env45323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272393,180224,169234,8193,64,171281,57676,17665,262144,61704,272392,257,156013,163904,63068]

theorem envBound45323 : H12AffineFastState.Bounded env45323 := by
  intro p hp
  have h : env45323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45298_45323 : H12AffineEnvironment.transform 6 9 env45298 = env45323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45298 == env45323) = true)

def env45324 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272393,16,21762,8193,64,23809,57676,17665,262144,61704,272392,257,41341,16464,63068]

theorem envBound45324 : H12AffineFastState.Bounded env45324 := by
  intro p hp
  have h : env45324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45323_45324 : H12AffineEnvironment.transform 16 49168 env45323 = env45324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env45323 == env45324) = true)

theorem identity45324 : scanCanonicalize (H12AffineFastState.compose env45324 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45324 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45325 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8202,24908,262144,1025,8541,4161,272393,16,21762,8193,64,23809,16400,17665,262144,20564,272392,257,33,16464,22272]

theorem envBound45325 : H12AffineFastState.Bounded env45325 := by
  intro p hp
  have h : env45325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45324_45325 : H12AffineEnvironment.transform 14 8540 env45324 = env45325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45324 == env45325) = true)

theorem identity45325 : scanCanonicalize (H12AffineFastState.compose env45325 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45325 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env45326 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13388,262144,1025,8541,4161,272393,16,2,8193,64,2049,5392,4097,262144,1364,272392,257,33,5456,512]

theorem envBound45326 : H12AffineFastState.Bounded env45326 := by
  intro p hp
  have h : env45326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45325_45326 : H12AffineEnvironment.transform 13 5376 env45325 = env45326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45325 == env45326) = true)

theorem identity45326 : scanCanonicalize (H12AffineFastState.compose env45326 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2308) := by decide +kernel

theorem selectedBound45326 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45327 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,13388,2308,1025,8541,4161,8461,16,2,8193,64,2049,5392,4097,2308,1364,8460,257,33,5456,512]

theorem envBound45327 : H12AffineFastState.Bounded env45327 := by
  intro p hp
  have h : env45327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45326_45327 : H12AffineEnvironment.transform 17 2308 env45326 = env45327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2308 env45326 == env45327) = true)

theorem identity45327 : scanCanonicalize (H12AffineFastState.compose env45327 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound45327 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env45328 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,9,5376,341,3,5189,2308,1025,340,4161,260,16,2,8,64,2049,5392,4097,2308,1364,261,257,33,5456,512]

theorem envBound45328 : H12AffineFastState.Bounded env45328 := by
  intro p hp
  have h : env45328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45327_45328 : H12AffineEnvironment.transform 12 9 env45327 = env45328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env45327 == env45328) = true)

theorem identity45328 : scanCanonicalize (H12AffineFastState.compose env45328 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45328 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env45329 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5376,260,3,5140,2308,1025,261,4112,260,16,2,8,17,2049,5392,4097,2308,1285,261,257,33,5377,512]

theorem envBound45329 : H12AffineFastState.Bounded env45329 := by
  intro p hp
  have h : env45329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45328_45329 : H12AffineEnvironment.transform 5 17 env45328 = env45329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45328 == env45329) = true)

theorem identity45329 : scanCanonicalize (H12AffineFastState.compose env45329 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2324) := by decide +kernel

theorem selectedBound45329 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env45330 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2324,9,3092,260,3,3328,2308,1025,261,2308,260,16,2,8,17,2049,3076,2325,2308,1285,261,257,33,3093,512]

theorem envBound45330 : H12AffineFastState.Bounded env45330 := by
  intro p hp
  have h : env45330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45329_45330 : H12AffineEnvironment.transform 11 2324 env45329 = env45330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2324 env45329 == env45330) = true)

theorem identity45330 : scanCanonicalize (H12AffineFastState.compose env45330 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45330 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45331 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,2064,9,3092,0,3,3076,2048,1025,1,2048,0,16,2,8,17,2049,3076,2065,2048,1025,1,5,33,3093,512]

theorem envBound45331 : H12AffineFastState.Bounded env45331 := by
  intro p hp
  have h : env45331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45330_45331 : H12AffineEnvironment.transform 7 4 env45330 = env45331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45330 == env45331) = true)

theorem identity45331 : scanCanonicalize (H12AffineFastState.compose env45331 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound45331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45332 : List Nat := [2,4,8,16,32,17,9,4,512,1024,33,49,9,1077,0,3,1061,33,1025,1,33,0,16,2,8,17,32,1061,48,33,1025,1,5,33,1076,512]

theorem envBound45332 : H12AffineFastState.Bounded env45332 := by
  intro p hp
  have h : env45332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45331_45332 : H12AffineEnvironment.transform 10 33 env45331 = env45332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env45331 == env45332) = true)

theorem identity45332 : scanCanonicalize (H12AffineFastState.compose env45332 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound45332 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45333 : List Nat := [2,4,8,16,32,17,9,4,11,1024,33,49,9,1077,0,3,1061,33,1025,1,33,0,16,2,8,17,32,1061,48,33,1025,1,5,33,1076,11]

theorem envBound45333 : H12AffineFastState.Bounded env45333 := by
  intro p hp
  have h : env45333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45332_45333 : H12AffineEnvironment.transform 8 11 env45332 = env45333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env45332 == env45333) = true)

theorem identity45333 : scanCanonicalize (H12AffineFastState.compose env45333 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 44) := by decide +kernel

theorem selectedBound45333 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45334 : List Nat := [2,4,8,16,32,17,9,4,11,44,33,49,9,25,0,3,9,33,45,1,33,0,16,2,8,17,32,9,48,33,45,1,5,33,24,11]

theorem envBound45334 : H12AffineFastState.Bounded env45334 := by
  intro p hp
  have h : env45334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45333_45334 : H12AffineEnvironment.transform 9 44 env45333 = env45334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 44 env45333 == env45334) = true)

theorem identity45334 : scanCanonicalize (H12AffineFastState.compose env45334 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound45334 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45335 : List Nat := [2,4,8,8,32,9,9,4,11,44,33,41,9,1,0,3,9,33,45,1,33,0,8,2,8,9,32,9,40,33,45,1,5,33,0,11]

theorem envBound45335 : H12AffineFastState.Bounded env45335 := by
  intro p hp
  have h : env45335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45334_45335 : H12AffineEnvironment.transform 3 8 env45334 = env45335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env45334 == env45335) = true)

theorem identity45335 : scanCanonicalize (H12AffineFastState.compose env45335 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound45335 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45336 : List Nat := [2,4,8,8,5,9,9,4,11,9,4,12,9,1,0,3,9,4,8,1,4,0,8,2,8,9,5,9,13,4,8,1,5,4,0,11]

theorem envBound45336 : H12AffineFastState.Bounded env45336 := by
  intro p hp
  have h : env45336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45335_45336 : H12AffineEnvironment.transform 4 5 env45335 = env45336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env45335 == env45336) = true)

theorem identity45336 : scanCanonicalize (H12AffineFastState.compose env45336 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45336 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45337 : List Nat := [2,1,8,8,0,9,9,1,11,9,1,9,9,1,0,3,9,1,8,1,1,0,8,2,8,9,0,9,8,1,8,1,0,1,0,11]

theorem envBound45337 : H12AffineFastState.Bounded env45337 := by
  intro p hp
  have h : env45337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45336_45337 : H12AffineEnvironment.transform 1 1 env45336 = env45337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45336 == env45337) = true)

def env45338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272393,17,21763,8193,64,23808,57676,17665,262144,61704,272392,257,41340,16465,63068]

theorem envBound45338 : H12AffineFastState.Bounded env45338 := by
  intro p hp
  have h : env45338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45323_45338 : H12AffineEnvironment.transform 16 49169 env45323 = env45338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env45323 == env45338) = true)

theorem identity45338 : scanCanonicalize (H12AffineFastState.compose env45338 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound45338 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env45339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,35189,1025,32769,4160,41340,17,21763,8193,64,23808,57676,17665,35189,61704,41341,257,41340,16465,63068]

theorem envBound45339 : H12AffineFastState.Bounded env45339 := by
  intro p hp
  have h : env45339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45338_45339 : H12AffineEnvironment.transform 17 35189 env45338 = env45339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env45338 == env45339) = true)

theorem identity45339 : scanCanonicalize (H12AffineFastState.compose env45339 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound45339 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env45340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38161,35189,1025,32769,4160,41340,17,3,8193,64,2048,46156,4097,35189,41992,41341,257,41340,5457,41820]

theorem envBound45340 : H12AffineFastState.Bounded env45340 := by
  intro p hp
  have h : env45340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45339_45340 : H12AffineEnvironment.transform 13 5376 env45339 = env45340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env45339 == env45340) = true)

theorem identity45340 : scanCanonicalize (H12AffineFastState.compose env45340 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound45340 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env45341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1296,8202,4097,3173,1025,1297,4160,9324,17,3,8193,64,2048,12636,4097,3173,8472,9325,257,9324,5457,9804]

theorem envBound45341 : H12AffineFastState.Bounded env45341 := by
  intro p hp
  have h : env45341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45340_45341 : H12AffineEnvironment.transform 14 1296 env45340 = env45341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env45340 == env45341) = true)

theorem identity45341 : scanCanonicalize (H12AffineFastState.compose env45341 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7261) := by decide +kernel

theorem selectedBound45341 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env45342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7261,5376,1296,7255,4097,3173,1025,1297,4160,6193,17,3,7260,64,2048,3329,4097,3173,7493,6192,257,6193,5457,6673]

theorem envBound45342 : H12AffineFastState.Bounded env45342 := by
  intro p hp
  have h : env45342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45341_45342 : H12AffineEnvironment.transform 12 7261 env45341 = env45342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7261 env45341 == env45342) = true)

theorem identity45342 : scanCanonicalize (H12AffineFastState.compose env45342 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound45342 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,4096,5133,5376,1296,5127,4097,1077,1025,1297,4160,4193,17,3,5132,64,80,1361,4097,1077,5397,4192,257,4193,5457,4673]

theorem envBound45343 : H12AffineFastState.Bounded env45343 := by
  intro p hp
  have h : env45343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45342_45343 : H12AffineEnvironment.transform 10 80 env45342 = env45343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env45342 == env45343) = true)

theorem identity45343 : scanCanonicalize (H12AffineFastState.compose env45343 (packedSelected [0,1,2,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound45343 : packedSelected [0,1,2,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env45344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,65,1100,1345,1296,1094,64,1077,1025,1297,1,32,17,3,1101,64,80,1361,64,1077,1364,33,257,32,1296,512]

theorem envBound45344 : H12AffineFastState.Bounded env45344 := by
  intro p hp
  have h : env45344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45343_45344 : H12AffineEnvironment.transform 11 65 env45343 = env45344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env45343 == env45344) = true)

theorem identity45344 : scanCanonicalize (H12AffineFastState.compose env45344 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound45344 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env45345 : List Nat := [2,4,8,16,32,64,9,256,512,304,80,65,380,113,32,374,64,261,305,33,1,32,17,3,381,64,80,97,64,261,100,33,257,32,32,512]

theorem envBound45345 : H12AffineFastState.Bounded env45345 := by
  intro p hp
  have h : env45345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45344_45345 : H12AffineEnvironment.transform 9 304 env45344 = env45345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env45344 == env45345) = true)

theorem identity45345 : scanCanonicalize (H12AffineFastState.compose env45345 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45345 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45346 : List Nat := [2,4,8,16,32,64,9,5,512,53,80,65,121,113,32,115,64,0,52,33,1,32,17,3,120,64,80,97,64,0,100,33,4,32,32,512]

theorem envBound45346 : H12AffineFastState.Bounded env45346 := by
  intro p hp
  have h : env45346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45345_45346 : H12AffineEnvironment.transform 7 5 env45345 = env45346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45345 == env45346) = true)

theorem identity45346 : scanCanonicalize (H12AffineFastState.compose env45346 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45346 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45347 : List Nat := [2,4,8,16,0,64,9,5,512,21,80,65,89,81,0,83,64,0,20,1,1,0,17,3,88,64,80,65,64,0,68,1,4,0,0,512]

theorem envBound45347 : H12AffineFastState.Bounded env45347 := by
  intro p hp
  have h : env45347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45346_45347 : H12AffineEnvironment.transform 4 0 env45346 = env45347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45346 == env45347) = true)

def env45348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,169234,8328,64,245139,115151,17665,262144,119042,329731,257,213486,237642,63189]

theorem envBound45348 : H12AffineFastState.Bounded env45348 := by
  intro p hp
  have h : env45348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45296_45348 : H12AffineEnvironment.transform 21 272513 env45296 = env45348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env45296 == env45348) = true)

theorem identity45348 : scanCanonicalize (H12AffineFastState.compose env45348 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound45348 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env45349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272513,73755,95497,8328,64,23944,115151,17665,262144,119042,329731,257,41461,16465,63189]

theorem envBound45349 : H12AffineFastState.Bounded env45349 := by
  intro p hp
  have h : env45349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45348_45349 : H12AffineEnvironment.transform 16 122907 env45348 = env45349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env45348 == env45349) = true)

def env45350 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272473,73755,95497,8272,64,23888,114967,17665,262144,119042,329731,257,41261,16465,62989]

theorem envBound45350 : H12AffineFastState.Bounded env45350 := by
  intro p hp
  have h : env45350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45349_45350 : H12AffineEnvironment.transform 6 88 env45349 = env45350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45349 == env45350) = true)

theorem identity45350 : scanCanonicalize (H12AffineFastState.compose env45350 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound45350 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45351 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,65536,79131,262144,1025,21761,77898,272473,73755,95497,8272,64,23888,70679,17665,262144,66562,329731,257,29741,16465,8973]

theorem envBound45351 : H12AffineFastState.Bounded env45351 := by
  intro p hp
  have h : env45351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45350_45351 : H12AffineEnvironment.transform 14 21760 env45350 = env45351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env45350 == env45351) = true)

theorem identity45351 : scanCanonicalize (H12AffineFastState.compose env45351 (packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound45351 : packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env45352 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,65536,79131,97327,1025,21761,77898,87158,73755,95497,8272,64,23888,70679,17665,97327,66562,29740,257,29741,16465,8973]

theorem envBound45352 : H12AffineFastState.Bounded env45352 := by
  intro p hp
  have h : env45352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45351_45352 : H12AffineEnvironment.transform 17 97327 env45351 = env45352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env45351 == env45352) = true)

theorem identity45352 : scanCanonicalize (H12AffineFastState.compose env45352 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound45352 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env45353 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21760,262,13341,32041,1025,21761,12620,21872,8477,29711,8272,64,23888,5393,17665,32041,1284,29740,257,29741,16465,8973]

theorem envBound45353 : H12AffineFastState.Bounded env45353 := by
  intro p hp
  have h : env45353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45352_45353 : H12AffineEnvironment.transform 15 262 env45352 = env45353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env45352 == env45353) = true)

theorem identity45353 : scanCanonicalize (H12AffineFastState.compose env45353 (packedSelected [2,11,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound45353 : packedSelected [2,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env45354 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1084,16384,21760,262,4129,22805,1025,21761,5488,21872,1313,20531,1132,64,23888,5393,17665,22805,1284,20496,257,20497,16465,1841]

theorem envBound45354 : H12AffineFastState.Bounded env45354 := by
  intro p hp
  have h : env45354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45353_45354 : H12AffineEnvironment.transform 12 1084 env45353 = env45354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env45353 == env45354) = true)

theorem identity45354 : scanCanonicalize (H12AffineFastState.compose env45354 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound45354 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45355 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1084,4145,1329,262,4129,2340,1025,1328,5488,1345,1313,2,1132,64,3425,5393,5424,2340,1284,33,257,32,4192,1841]

theorem envBound45355 : H12AffineFastState.Bounded env45355 := by
  intro p hp
  have h : env45355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45354_45355 : H12AffineEnvironment.transform 13 4145 env45354 = env45355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env45354 == env45355) = true)

theorem identity45355 : scanCanonicalize (H12AffineFastState.compose env45355 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 353) := by decide +kernel

theorem selectedBound45355 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env45356 : List Nat := [2,4,8,16,32,64,88,256,512,353,2048,4096,349,4145,80,262,4129,2340,352,81,4113,32,64,2,269,64,2048,4208,4177,2340,101,33,257,32,4192,592]

theorem envBound45356 : H12AffineFastState.Bounded env45356 := by
  intro p hp
  have h : env45356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45355_45356 : H12AffineEnvironment.transform 9 353 env45355 = env45356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 353 env45355 == env45356) = true)

theorem identity45356 : scanCanonicalize (H12AffineFastState.compose env45356 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound45356 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45357 : List Nat := [2,4,8,16,32,64,88,4,512,101,2048,4096,89,4145,80,2,4129,2080,100,81,4113,32,64,2,9,64,2048,4208,4177,2080,101,33,5,32,4192,592]

theorem envBound45357 : H12AffineFastState.Bounded env45357 := by
  intro p hp
  have h : env45357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45356_45357 : H12AffineEnvironment.transform 7 4 env45356 = env45357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env45356 == env45357) = true)

theorem identity45357 : scanCanonicalize (H12AffineFastState.compose env45357 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45357 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45358 : List Nat := [2,4,8,16,0,64,88,4,512,69,2048,4096,89,4113,80,2,4097,2048,68,81,4113,0,64,2,9,64,2048,4176,4177,2048,69,1,5,0,4160,592]

theorem envBound45358 : H12AffineFastState.Bounded env45358 := by
  intro p hp
  have h : env45358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45357_45358 : H12AffineEnvironment.transform 4 0 env45357 = env45358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45357 == env45358) = true)

theorem identity45358 : scanCanonicalize (H12AffineFastState.compose env45358 (packedSelected [1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound45358 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env45359 : List Nat := [2,4,8,16,0,64,88,4,512,69,2048,2113,89,2128,80,2,2112,2048,68,81,2128,0,64,2,9,64,2048,2065,2064,2048,69,1,5,0,2049,592]

theorem envBound45359 : H12AffineFastState.Bounded env45359 := by
  intro p hp
  have h : env45359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45358_45359 : H12AffineEnvironment.transform 11 2113 env45358 = env45359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env45358 == env45359) = true)

theorem identity45359 : scanCanonicalize (H12AffineFastState.compose env45359 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45359 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45360 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2065,9,2048,0,2,2064,2048,20,1,2048,0,16,2,9,16,2048,2065,2064,2048,21,1,5,0,2049,512]

theorem envBound45360 : H12AffineFastState.Bounded env45360 := by
  intro p hp
  have h : env45360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45359_45360 : H12AffineEnvironment.transform 5 16 env45359 = env45360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45359 == env45360) = true)

theorem identity45360 : scanCanonicalize (H12AffineFastState.compose env45360 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound45360 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45361 : List Nat := [2,4,8,16,0,16,8,4,512,21,4,21,9,4,0,2,20,4,20,1,4,0,16,2,9,16,4,21,20,4,21,1,5,0,5,512]

theorem envBound45361 : H12AffineFastState.Bounded env45361 := by
  intro p hp
  have h : env45361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45360_45361 : H12AffineEnvironment.transform 10 4 env45360 = env45361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env45360 == env45361) = true)

def env45362 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272472,73755,95497,8273,64,23889,114966,17665,262144,119042,329731,257,41260,16465,62988]

theorem envBound45362 : H12AffineFastState.Bounded env45362 := by
  intro p hp
  have h : env45362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45349_45362 : H12AffineEnvironment.transform 6 89 env45349 = env45362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env45349 == env45362) = true)

theorem identity45362 : scanCanonicalize (H12AffineFastState.compose env45362 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound45362 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env45363 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57677,262144,1025,32769,12572,272472,8525,29791,8273,64,23889,49216,17665,262144,53332,264533,257,41260,16465,62988]

theorem envBound45363 : H12AffineFastState.Bounded env45363 := by
  intro p hp
  have h : env45363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45362_45363 : H12AffineEnvironment.transform 15 342 env45362 = env45363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env45362 == env45363) = true)

theorem identity45363 : scanCanonicalize (H12AffineFastState.compose env45363 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 64888) := by decide +kernel

theorem selectedBound45363 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env45364 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57677,64888,1025,32769,12572,54560,8525,29791,8273,64,23889,49216,17665,64888,53332,62509,257,41260,16465,62988]

theorem envBound45364 : H12AffineFastState.Bounded env45364 := by
  intro p hp
  have h : env45364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45363_45364 : H12AffineEnvironment.transform 17 64888 env45363 = env45364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64888 env45363 == env45364) = true)

theorem identity45364 : scanCanonicalize (H12AffineFastState.compose env45364 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound45364 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env45365 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,32768,342,49168,56357,1025,32769,4161,54560,16,21762,268,64,23889,49216,17665,56357,53332,54640,257,32881,16465,55121]

theorem envBound45365 : H12AffineFastState.Bounded env45365 := by
  intro p hp
  have h : env45365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45364_45365 : H12AffineEnvironment.transform 12 349 env45364 = env45365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env45364 == env45365) = true)

theorem identity45365 : scanCanonicalize (H12AffineFastState.compose env45365 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound45365 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env45366 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,16384,21761,342,5393,2340,1025,21760,4161,33,16,21762,268,64,23889,5441,17665,2340,1365,113,257,21872,16465,592]

theorem envBound45366 : H12AffineFastState.Bounded env45366 := by
  intro p hp
  have h : env45366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45365_45366 : H12AffineEnvironment.transform 14 21761 env45365 = env45366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env45365 == env45366) = true)

theorem identity45366 : scanCanonicalize (H12AffineFastState.compose env45366 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound45366 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env45367 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,80,342,5393,2340,1025,81,4161,33,16,83,268,64,2048,5441,4176,2340,1365,113,257,33,5376,592]

theorem envBound45367 : H12AffineFastState.Bounded env45367 := by
  intro p hp
  have h : env45367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45366_45367 : H12AffineEnvironment.transform 13 5457 env45366 = env45367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env45366 == env45367) = true)

theorem identity45367 : scanCanonicalize (H12AffineFastState.compose env45367 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45367 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env45368 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1025,0,4112,33,16,2,268,17,2048,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound45368 : H12AffineFastState.Bounded env45368 := by
  intro p hp
  have h : env45368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45367_45368 : H12AffineEnvironment.transform 5 17 env45367 = env45368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45367 == env45368) = true)

theorem identity45368 : scanCanonicalize (H12AffineFastState.compose env45368 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45368 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45369 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,1,34,5172,2049,1025,0,4112,33,16,2,41,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound45369 : H12AffineFastState.Bounded env45369 := by
  intro p hp
  have h : env45369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45368_45369 : H12AffineEnvironment.transform 7 37 env45368 = env45369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45368 == env45369) = true)

def env45370 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,1,34,1028,2049,1025,0,32,33,16,2,41,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound45370 : H12AffineFastState.Bounded env45370 := by
  intro p hp
  have h : env45370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45369_45370 : H12AffineEnvironment.transform 11 48 env45369 = env45370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env45369 == env45370) = true)

theorem identity45370 : scanCanonicalize (H12AffineFastState.compose env45370 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound45370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45371 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,48,41,561,1,34,544,2049,549,0,32,33,16,2,41,17,2048,545,49,2049,517,32,36,33,561,513]

end H12CloudChart1