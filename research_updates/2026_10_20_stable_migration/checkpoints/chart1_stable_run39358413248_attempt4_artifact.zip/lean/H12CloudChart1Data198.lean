import H12CloudChart1Data197

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans50155_50156 : H12AffineEnvironment.transform 11 2065 env50155 = env50156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env50155 == env50156) = true)

theorem identity50156 : scanCanonicalize (H12AffineFastState.compose env50156 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50156 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50157 : List Nat := [2,4,8,16,32,48,8,37,512,21,2048,2065,40,2049,0,34,2097,2080,21,1,2081,1,17,34,40,49,2048,2097,2097,2048,21,0,37,0,2081,512]

theorem envBound50157 : H12AffineFastState.Bounded env50157 := by
  intro p hp
  have h : env50157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50156_50157 : H12AffineEnvironment.transform 5 48 env50156 = env50157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50156 == env50157) = true)

def env50158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,144492,17,21762,8193,65,215367,115014,17664,10280,119042,201830,256,98678,90202,63068]

theorem envBound50158 : H12AffineFastState.Bounded env50158 := by
  intro p hp
  have h : env50158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50147_50158 : H12AffineEnvironment.transform 6 9 env50147 = env50158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50147 == env50158) = true)

theorem identity50158 : scanCanonicalize (H12AffineFastState.compose env50158 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50158 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50159 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4160,144492,17,21762,8193,65,215367,90138,17664,10280,94302,201830,256,73770,90202,22272]

theorem envBound50159 : H12AffineFastState.Bounded env50159 := by
  intro p hp
  have h : env50159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50158_50159 : H12AffineEnvironment.transform 14 8540 env50158 = env50159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50158 == env50159) = true)

theorem identity50159 : scanCanonicalize (H12AffineFastState.compose env50159 (packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 24681) := by decide +kernel

theorem selectedBound50159 : packedSelected [0,7,8,9,12,14,15,18,19,20,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env50160 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24681,10509,1024,8541,4160,21509,17,21762,8193,65,76078,90138,17664,10280,94302,95247,256,73770,90202,22272]

theorem envBound50160 : H12AffineFastState.Bounded env50160 := by
  intro p hp
  have h : env50160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50159_50160 : H12AffineEnvironment.transform 16 24681 env50159 = env50160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24681 env50159 == env50160) = true)

theorem identity50160 : scanCanonicalize (H12AffineFastState.compose env50160 (packedSelected [1,2,4,5,6,7,8,11,14,18,22,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50160 : packedSelected [1,2,4,5,6,7,8,11,14,18,22,24,27] rootPS < 2^1333 := by decide +kernel

def env50161 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8233,65536,24681,10360,1024,8232,4160,21509,17,21623,8193,65,75867,90138,17525,10280,94302,95247,117,73770,90202,22133]

theorem envBound50161 : H12AffineFastState.Bounded env50161 := by
  intro p hp
  have h : env50161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50160_50161 : H12AffineEnvironment.transform 7 117 env50160 = env50161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50160 == env50161) = true)

theorem identity50161 : scanCanonicalize (H12AffineFastState.compose env50161 (packedSelected [0,1,2,3,5,6,7,8,11,14,23] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound50161 : packedSelected [0,1,2,3,5,6,7,8,11,14,23] rootPS < 2^1333 := by decide +kernel

def env50162 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,16384,1124,65536,17444,3125,1024,1125,4160,21509,17,21623,1100,65,68630,83031,17525,3173,87059,86082,117,66663,82967,22133]

theorem envBound50162 : H12AffineFastState.Bounded env50162 := by
  intro p hp
  have h : env50162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50161_50162 : H12AffineEnvironment.transform 12 1101 env50161 = env50162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env50161 == env50162) = true)

theorem identity50162 : scanCanonicalize (H12AffineFastState.compose env50162 (packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 20531) := by decide +kernel

theorem selectedBound50162 : packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env50163 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,16384,1124,20531,17444,3125,1024,1125,4160,21509,17,21623,1100,65,23589,5220,17525,3173,1056,113,117,21588,5156,22133]

theorem envBound50163 : H12AffineFastState.Bounded env50163 := by
  intro p hp
  have h : env50163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50162_50163 : H12AffineEnvironment.transform 15 20531 env50162 = env50163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20531 env50162 == env50163) = true)

theorem identity50163 : scanCanonicalize (H12AffineFastState.compose env50163 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound50163 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env50164 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,1101,4112,1124,35,5172,3125,1024,1125,4160,1045,17,1127,1100,65,3125,5220,5221,3173,1056,113,117,1092,5156,1637]

theorem envBound50164 : H12AffineFastState.Bounded env50164 := by
  intro p hp
  have h : env50164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50163_50164 : H12AffineEnvironment.transform 13 4112 env50163 = env50164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env50163 == env50164) = true)

theorem identity50164 : scanCanonicalize (H12AffineFastState.compose env50164 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50164 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env50165 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,1085,4112,1044,35,5172,3125,1024,1045,4144,1045,17,1047,1084,49,3125,5140,5141,3093,1056,1,5,1076,5156,1557]

theorem envBound50165 : H12AffineFastState.Bounded env50165 := by
  intro p hp
  have h : env50165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50164_50165 : H12AffineEnvironment.transform 5 48 env50164 = env50165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50164 == env50165) = true)

theorem identity50165 : scanCanonicalize (H12AffineFastState.compose env50165 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50165 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50166 : List Nat := [2,4,8,16,32,48,9,5,512,52,2048,4096,9,4112,32,35,4096,2049,52,33,4144,33,17,35,8,49,2049,4128,4129,2081,20,1,5,0,4112,545]

theorem envBound50166 : H12AffineFastState.Bounded env50166 := by
  intro p hp
  have h : env50166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50165_50166 : H12AffineEnvironment.transform 9 52 env50165 = env50166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50165 == env50166) = true)

theorem identity50166 : scanCanonicalize (H12AffineFastState.compose env50166 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound50166 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50167 : List Nat := [2,4,8,16,32,48,9,5,512,52,2048,528,9,512,32,35,528,2049,52,33,544,33,17,35,8,49,2049,560,561,2081,20,1,5,0,512,545]

theorem envBound50167 : H12AffineFastState.Bounded env50167 := by
  intro p hp
  have h : env50167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50166_50167 : H12AffineEnvironment.transform 11 528 env50166 = env50167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env50166 == env50167) = true)

theorem identity50167 : scanCanonicalize (H12AffineFastState.compose env50167 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound50167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50168 : List Nat := [2,4,8,16,32,48,9,5,512,52,42,528,9,512,32,35,528,43,52,33,544,33,17,35,8,49,43,560,561,11,20,1,5,0,512,545]

theorem envBound50168 : H12AffineFastState.Bounded env50168 := by
  intro p hp
  have h : env50168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50167_50168 : H12AffineEnvironment.transform 10 42 env50167 = env50168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env50167 == env50168) = true)

theorem identity50168 : scanCanonicalize (H12AffineFastState.compose env50168 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound50168 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env50169 : List Nat := [2,4,8,16,32,48,9,5,59,52,42,43,9,59,32,35,43,43,52,33,27,33,17,35,8,49,43,11,10,11,20,1,5,0,59,26]

theorem envBound50169 : H12AffineFastState.Bounded env50169 := by
  intro p hp
  have h : env50169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50168_50169 : H12AffineEnvironment.transform 8 59 env50168 = env50169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env50168 == env50169) = true)

theorem identity50169 : scanCanonicalize (H12AffineFastState.compose env50169 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound50169 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env50170 : List Nat := [2,4,2,16,32,48,3,5,49,52,32,33,3,49,32,35,33,33,52,33,17,33,17,35,2,49,33,1,0,1,20,1,5,0,49,16]

theorem envBound50170 : H12AffineFastState.Bounded env50170 := by
  intro p hp
  have h : env50170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50169_50170 : H12AffineEnvironment.transform 2 2 env50169 = env50170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env50169 == env50170) = true)

theorem identity50170 : scanCanonicalize (H12AffineFastState.compose env50170 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound50170 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50171 : List Nat := [2,0,2,16,32,48,3,1,49,48,32,33,3,49,32,35,33,33,48,33,17,33,17,35,2,49,33,1,0,1,16,1,1,0,49,16]

theorem envBound50171 : H12AffineFastState.Bounded env50171 := by
  intro p hp
  have h : env50171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50170_50171 : H12AffineEnvironment.transform 1 0 env50170 = env50171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env50170 == env50171) = true)

theorem identity50171 : scanCanonicalize (H12AffineFastState.compose env50171 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50172 : List Nat := [1,0,1,16,32,48,0,1,49,48,32,33,0,49,32,32,33,33,48,33,17,33,17,32,1,49,33,1,0,1,16,1,1,0,49,16]

theorem envBound50172 : H12AffineFastState.Bounded env50172 := by
  intro p hp
  have h : env50172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50171_50172 : H12AffineEnvironment.transform 0 1 env50171 = env50172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50171 == env50172) = true)

theorem identity50172 : scanCanonicalize (H12AffineFastState.compose env50172 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50172 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env50173 : List Nat := [1,0,1,16,0,16,0,1,17,16,0,1,0,17,0,0,1,1,16,1,17,1,17,0,1,17,1,1,0,1,16,1,1,0,17,16]

theorem envBound50173 : H12AffineFastState.Bounded env50173 := by
  intro p hp
  have h : env50173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50172_50173 : H12AffineEnvironment.transform 4 0 env50172 = env50173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50172 == env50173) = true)

theorem identity50173 : scanCanonicalize (H12AffineFastState.compose env50173 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50174 : List Nat := [1,0,1,1,0,1,0,1,0,1,0,1,0,0,0,0,1,1,1,1,0,1,0,0,1,0,1,1,0,1,1,1,1,0,0,1]

theorem envBound50174 : H12AffineFastState.Bounded env50174 := by
  intro p hp
  have h : env50174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50173_50174 : H12AffineEnvironment.transform 3 1 env50173 = env50174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50173 == env50174) = true)

def env50175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,21763,8328,65,4291883,115151,17664,10281,119042,4268163,256,98814,90203,63189]

theorem envBound50175 : H12AffineFastState.Bounded env50175 := by
  intro p hp
  have h : env50175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50145_50175 : H12AffineEnvironment.transform 20 4161 env50145 = env50175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50145 == env50175) = true)

theorem identity50175 : scanCanonicalize (H12AffineFastState.compose env50175 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138476,1024,29909,4161,4194304,16,21763,8328,65,4291883,79131,17664,10281,75222,4268163,256,95530,90203,513]

theorem envBound50176 : H12AffineFastState.Bounded env50176 := by
  intro p hp
  have h : env50176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50175_50176 : H12AffineEnvironment.transform 14 29908 env50175 = env50176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50175 == env50176) = true)

def env50177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,138476,1024,8661,4161,4194304,16,3,8328,65,4270123,79131,4096,10281,75222,4268163,256,73770,79195,513]

theorem envBound50177 : H12AffineFastState.Bounded env50177 := by
  intro p hp
  have h : env50177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50176_50177 : H12AffineEnvironment.transform 13 5376 env50176 = env50177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50176 == env50177) = true)

theorem identity50177 : scanCanonicalize (H12AffineFastState.compose env50177 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound50177 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,13509,10281,1024,8661,4161,4194304,16,3,8328,65,4270123,79131,4096,10281,75222,4268163,256,73770,79195,513]

theorem envBound50178 : H12AffineFastState.Bounded env50178 := by
  intro p hp
  have h : env50178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50177_50178 : H12AffineEnvironment.transform 16 13509 env50177 = env50178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env50177 == env50178) = true)

theorem identity50178 : scanCanonicalize (H12AffineFastState.compose env50178 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50178 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env50179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13509,10281,1024,8661,4161,4194304,16,3,8328,65,4196384,5392,4096,10281,1501,4194440,256,33,5456,513]

theorem envBound50179 : H12AffineFastState.Bounded env50179 := by
  intro p hp
  have h : env50179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50178_50179 : H12AffineEnvironment.transform 15 8203 env50178 = env50179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50178 == env50179) = true)

theorem identity50179 : scanCanonicalize (H12AffineFastState.compose env50179 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound50179 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8203,13509,10281,1024,8661,4161,249,16,3,8328,65,2265,5392,4096,10281,1501,113,256,33,5456,513]

theorem envBound50180 : H12AffineFastState.Bounded env50180 := by
  intro p hp
  have h : env50180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50179_50180 : H12AffineEnvironment.transform 21 249 env50179 = env50180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env50179 == env50180) = true)

theorem identity50180 : scanCanonicalize (H12AffineFastState.compose env50180 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound50180 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,1,478,5392,2556,1024,0,4161,249,16,3,349,65,2265,5392,4096,2556,1501,113,256,33,5456,513]

theorem envBound50181 : H12AffineFastState.Bounded env50181 := by
  intro p hp
  have h : env50181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50180_50181 : H12AffineEnvironment.transform 12 469 env50180 = env50181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env50180 == env50181) = true)

theorem identity50181 : scanCanonicalize (H12AffineFastState.compose env50181 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50181 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env50182 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,1,399,5392,2477,1024,0,4112,168,16,3,268,16,2184,5392,4096,2477,1420,32,256,33,5377,513]

theorem envBound50182 : H12AffineFastState.Bounded env50182 := by
  intro p hp
  have h : env50182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50181_50182 : H12AffineEnvironment.transform 5 17 env50181 = env50182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50181 == env50182) = true)

theorem identity50182 : scanCanonicalize (H12AffineFastState.compose env50182 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound50182 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50183 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2232,388,3512,1,399,3496,2477,1024,0,2216,168,16,3,268,16,2184,3496,2232,2477,1420,32,256,33,3513,513]

theorem envBound50183 : H12AffineFastState.Bounded env50183 := by
  intro p hp
  have h : env50183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50182_50183 : H12AffineEnvironment.transform 11 2232 env50182 = env50183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env50182 == env50183) = true)

theorem identity50183 : scanCanonicalize (H12AffineFastState.compose env50183 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound50183 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env50184 : List Nat := [2,4,8,16,32,17,128,256,512,921,2048,2232,388,2593,1,399,2609,2477,921,0,2216,168,16,3,268,16,2184,2609,2232,2477,533,32,256,33,2592,513]

theorem envBound50184 : H12AffineFastState.Bounded env50184 := by
  intro p hp
  have h : env50184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50183_50184 : H12AffineEnvironment.transform 9 921 env50183 = env50184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env50183 == env50184) = true)

theorem identity50184 : scanCanonicalize (H12AffineFastState.compose env50184 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound50184 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50185 : List Nat := [2,4,8,16,32,17,41,256,512,816,2048,2065,301,2593,1,294,2609,2308,816,0,2049,1,16,3,268,16,2081,2609,2065,2308,533,32,256,33,2592,513]

theorem envBound50185 : H12AffineFastState.Bounded env50185 := by
  intro p hp
  have h : env50185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50184_50185 : H12AffineEnvironment.transform 6 41 env50184 = env50185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env50184 == env50185) = true)

theorem identity50185 : scanCanonicalize (H12AffineFastState.compose env50185 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound50185 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env50186 : List Nat := [2,4,8,16,32,17,41,256,277,37,2048,2065,301,2356,1,294,2340,2308,37,0,2049,1,16,3,268,16,2081,2340,2065,2308,256,32,256,33,2357,276]

theorem envBound50186 : H12AffineFastState.Bounded env50186 := by
  intro p hp
  have h : env50186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50185_50186 : H12AffineEnvironment.transform 8 277 env50185 = env50186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50185 == env50186) = true)

theorem identity50186 : scanCanonicalize (H12AffineFastState.compose env50186 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound50186 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env50187 : List Nat := [2,4,8,16,17,17,24,256,277,20,2048,2065,284,2309,1,279,2325,2308,20,0,2049,1,16,3,268,16,2064,2325,2065,2308,256,17,256,16,2308,276]

theorem envBound50187 : H12AffineFastState.Bounded env50187 := by
  intro p hp
  have h : env50187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50186_50187 : H12AffineEnvironment.transform 4 17 env50186 = env50187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env50186 == env50187) = true)

theorem identity50187 : scanCanonicalize (H12AffineFastState.compose env50187 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50187 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env50188 : List Nat := [2,4,8,16,17,17,24,21,0,20,2048,2065,9,2064,1,2,2048,2065,20,0,2049,1,16,3,25,16,2064,2048,2065,2065,21,17,21,16,2065,1]

theorem envBound50188 : H12AffineFastState.Bounded env50188 := by
  intro p hp
  have h : env50188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50187_50188 : H12AffineEnvironment.transform 7 21 env50187 = env50188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50187 == env50188) = true)

theorem identity50188 : scanCanonicalize (H12AffineFastState.compose env50188 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound50188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50189 : List Nat := [2,4,8,16,17,17,24,21,0,20,17,0,9,1,1,2,17,0,20,0,16,1,16,3,25,16,1,17,0,0,21,17,21,16,0,1]

theorem envBound50189 : H12AffineFastState.Bounded env50189 := by
  intro p hp
  have h : env50189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50188_50189 : H12AffineEnvironment.transform 10 17 env50188 = env50189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env50188 == env50189) = true)

theorem identity50189 : scanCanonicalize (H12AffineFastState.compose env50189 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50189 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env50190 : List Nat := [2,4,8,1,0,0,9,4,0,5,0,0,9,1,1,2,0,0,5,0,1,1,1,3,8,1,1,0,0,0,4,0,4,1,0,1]

theorem envBound50190 : H12AffineFastState.Bounded env50190 := by
  intro p hp
  have h : env50190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50189_50190 : H12AffineEnvironment.transform 3 1 env50189 = env50190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50189 == env50190) = true)

def env50191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,138476,1024,8660,4161,4194304,16,2,8328,65,4270122,79131,4097,10281,75222,4268163,256,73771,79194,513]

theorem envBound50191 : H12AffineFastState.Bounded env50191 := by
  intro p hp
  have h : env50191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50176_50191 : H12AffineEnvironment.transform 13 5377 env50176 = env50191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50176 == env50191) = true)

theorem identity50191 : scanCanonicalize (H12AffineFastState.compose env50191 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound50191 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10401,1024,8660,4161,4194304,16,2,8328,65,4270122,79131,4097,10281,75222,4268163,256,73771,79194,513]

theorem envBound50192 : H12AffineFastState.Bounded env50192 := by
  intro p hp
  have h : env50192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50191_50192 : H12AffineEnvironment.transform 16 13389 env50191 = env50192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env50191 == env50192) = true)

theorem identity50192 : scanCanonicalize (H12AffineFastState.compose env50192 (packedSelected [0,1,2,6,8,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound50192 : packedSelected [0,1,2,6,8,14,19,27] rootPS < 2^1333 := by decide +kernel

def env50193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10401,1024,8660,4161,73770,16,2,8328,65,2048,79131,4097,10281,75222,169,256,73771,79194,513]

theorem envBound50193 : H12AffineFastState.Bounded env50193 := by
  intro p hp
  have h : env50193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50192_50193 : H12AffineEnvironment.transform 21 73770 env50192 = env50193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env50192 == env50193) = true)

theorem identity50193 : scanCanonicalize (H12AffineFastState.compose env50193 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50193 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8203,13389,10401,1024,8660,4161,33,16,2,8328,65,2048,5392,4097,10281,1501,169,256,32,5457,513]

theorem envBound50194 : H12AffineFastState.Bounded env50194 := by
  intro p hp
  have h : env50194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50193_50194 : H12AffineEnvironment.transform 15 8203 env50193 = env50194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50193 == env50194) = true)

theorem identity50194 : scanCanonicalize (H12AffineFastState.compose env50194 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50194 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,217,263,5441,2477,1024,216,4161,33,16,2,388,65,2048,5392,4097,2341,1501,169,256,32,5457,513]

theorem envBound50195 : H12AffineFastState.Bounded env50195 := by
  intro p hp
  have h : env50195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50194_50195 : H12AffineEnvironment.transform 12 268 env50194 = env50195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50194 == env50195) = true)

theorem identity50195 : scanCanonicalize (H12AffineFastState.compose env50195 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50195 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50196 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,5441,2341,1024,80,4161,33,16,2,268,65,2048,5392,4097,2341,1365,33,256,32,5457,513]

theorem envBound50196 : H12AffineFastState.Bounded env50196 := by
  intro p hp
  have h : env50196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50195_50196 : H12AffineEnvironment.transform 6 8 env50195 = env50196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50195 == env50196) = true)

theorem identity50196 : scanCanonicalize (H12AffineFastState.compose env50196 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50196 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50197 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5237,81,115,5173,2129,1024,80,4161,33,16,2,120,65,2048,5220,4097,2129,1057,33,116,32,5157,513]

theorem envBound50197 : H12AffineFastState.Bounded env50197 := by
  intro p hp
  have h : env50197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50196_50197 : H12AffineEnvironment.transform 7 116 env50196 = env50197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50196 == env50197) = true)

theorem identity50197 : scanCanonicalize (H12AffineFastState.compose env50197 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50197 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env50198 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4112,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound50198 : H12AffineFastState.Bounded env50198 := by
  intro p hp
  have h : env50198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50197_50198 : H12AffineEnvironment.transform 5 17 env50197 = env50198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50197 == env50198) = true)

def env50199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,8388608,2114883,8328,65,14773626,115150,10507601,8398904,10600786,4268162,256,8487407,8478794,10544773]

theorem envBound50199 : H12AffineFastState.Bounded env50199 := by
  intro p hp
  have h : env50199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50101_50199 : H12AffineEnvironment.transform 17 190521 env50101 = env50199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env50101 == env50199) = true)

def env50200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101328,2114883,8328,65,4291882,115150,17665,2111592,119042,4268162,256,2199999,2191386,63189]

theorem envBound50200 : H12AffineFastState.Bounded env50200 := by
  intro p hp
  have h : env50200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50199_50200 : H12AffineEnvironment.transform 22 2101328 env50199 = env50200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env50199 == env50200) = true)

def env50201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,16,21763,8328,65,4291882,115150,17665,10280,119042,4268162,256,98815,90202,63189]

theorem envBound50201 : H12AffineFastState.Bounded env50201 := by
  intro p hp
  have h : env50201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50200_50201 : H12AffineEnvironment.transform 20 4160 env50200 = env50201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50200 == env50201) = true)

theorem identity50201 : scanCanonicalize (H12AffineFastState.compose env50201 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound50201 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190521,1024,32769,4160,4194304,16,21763,8328,65,4237812,5392,17665,10280,1500,4256860,256,21793,46212,63189]

theorem envBound50202 : H12AffineFastState.Bounded env50202 := by
  intro p hp
  have h : env50202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50201_50202 : H12AffineEnvironment.transform 15 54494 env50201 = env50202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env50201 == env50202) = true)

def env50203 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190521,1024,32769,4160,4194304,16,21763,8192,65,4237692,5392,17665,10280,1364,4256860,256,21793,46092,63069]

theorem envBound50203 : H12AffineFastState.Bounded env50203 := by
  intro p hp
  have h : env50203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50202_50203 : H12AffineEnvironment.transform 6 8 env50202 = env50203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50202 == env50203) = true)

theorem identity50203 : scanCanonicalize (H12AffineFastState.compose env50203 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound50203 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10281,1024,32769,4160,4194304,16,21763,8192,65,4237692,5392,17665,10280,1364,4256860,256,21793,46092,63069]

theorem envBound50204 : H12AffineFastState.Bounded env50204 := by
  intro p hp
  have h : env50204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50203_50204 : H12AffineEnvironment.transform 16 49168 env50203 = env50204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env50203 == env50204) = true)

theorem identity50204 : scanCanonicalize (H12AffineFastState.compose env50204 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50204 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env50205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,46157,10281,1024,32769,4160,4194304,16,8542,8192,65,4237692,5392,12636,10280,1364,4227073,256,8572,46092,33280]

theorem envBound50205 : H12AffineFastState.Bounded env50205 := by
  intro p hp
  have h : env50205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50204_50205 : H12AffineEnvironment.transform 13 13405 env50204 = env50205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50204 == env50205) = true)

theorem identity50205 : scanCanonicalize (H12AffineFastState.compose env50205 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound50205 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env50206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,46157,10281,1024,32769,4160,33,16,8542,8192,65,43357,5392,12636,10280,1364,32800,256,8572,46092,33280]

theorem envBound50206 : H12AffineFastState.Bounded env50206 := by
  intro p hp
  have h : env50206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50205_50206 : H12AffineEnvironment.transform 21 33 env50205 = env50206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env50205 == env50206) = true)

theorem identity50206 : scanCanonicalize (H12AffineFastState.compose env50206 (packedSelected [0,1,2,3,6,7,8,10,11,16,18,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound50206 : packedSelected [0,1,2,3,6,7,8,10,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env50207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,80,8283,13341,10281,1024,81,4160,33,16,8542,8192,65,10509,5392,12636,10280,1364,112,256,8572,13404,592]

theorem envBound50207 : H12AffineFastState.Bounded env50207 := by
  intro p hp
  have h : env50207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50206_50207 : H12AffineEnvironment.transform 14 80 env50206 = env50207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env50206 == env50207) = true)

theorem identity50207 : scanCanonicalize (H12AffineFastState.compose env50207 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50207 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env50208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5457,80,343,5393,2341,1024,81,4160,33,16,82,268,65,2049,5392,4176,2340,1364,112,256,112,5456,592]

theorem envBound50208 : H12AffineFastState.Bounded env50208 := by
  intro p hp
  have h : env50208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50207_50208 : H12AffineEnvironment.transform 12 268 env50207 = env50208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50207 == env50208) = true)

theorem identity50208 : scanCanonicalize (H12AffineFastState.compose env50208 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50208 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50209 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,268,4160,80,343,4096,2341,273,81,4160,33,16,82,268,65,2049,4097,4176,2340,69,112,256,112,4161,592]

theorem envBound50209 : H12AffineFastState.Bounded env50209 := by
  intro p hp
  have h : env50209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50208_50209 : H12AffineEnvironment.transform 9 273 env50208 = env50209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50208 == env50209) = true)

theorem identity50209 : scanCanonicalize (H12AffineFastState.compose env50209 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50209 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env50210 : List Nat := [2,4,8,16,32,64,8,4,512,21,2048,4096,8,4160,80,83,4096,2081,21,81,4160,33,16,82,8,65,2049,4097,4176,2080,69,112,4,112,4161,592]

theorem envBound50210 : H12AffineFastState.Bounded env50210 := by
  intro p hp
  have h : env50210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50209_50210 : H12AffineEnvironment.transform 7 4 env50209 = env50210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50209 == env50210) = true)

theorem identity50210 : scanCanonicalize (H12AffineFastState.compose env50210 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound50210 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env50211 : List Nat := [2,4,8,16,32,64,8,4,512,21,2048,97,8,33,80,83,97,2081,21,81,33,33,16,82,8,65,2049,96,49,2080,69,112,4,112,32,592]

theorem envBound50211 : H12AffineFastState.Bounded env50211 := by
  intro p hp
  have h : env50211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50210_50211 : H12AffineEnvironment.transform 11 97 env50210 = env50211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env50210 == env50211) = true)

theorem identity50211 : scanCanonicalize (H12AffineFastState.compose env50211 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50212 : List Nat := [2,4,8,16,32,17,8,4,512,21,2048,48,8,33,1,2,48,2081,21,0,33,33,16,3,8,16,2049,49,49,2080,20,33,4,33,32,513]

theorem envBound50212 : H12AffineFastState.Bounded env50212 := by
  intro p hp
  have h : env50212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50211_50212 : H12AffineEnvironment.transform 5 17 env50211 = env50212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50211 == env50212) = true)

theorem identity50212 : scanCanonicalize (H12AffineFastState.compose env50212 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound50212 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50213 : List Nat := [2,4,8,16,32,17,8,4,512,21,512,48,8,33,1,2,48,545,21,0,33,33,16,3,8,16,513,49,49,544,20,33,4,33,32,513]

theorem envBound50213 : H12AffineFastState.Bounded env50213 := by
  intro p hp
  have h : env50213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50212_50213 : H12AffineEnvironment.transform 10 512 env50212 = env50213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env50212 == env50213) = true)

theorem identity50213 : scanCanonicalize (H12AffineFastState.compose env50213 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound50213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50214 : List Nat := [2,4,8,16,32,17,8,4,49,21,49,48,8,33,1,2,48,16,21,0,33,33,16,3,8,16,48,49,49,17,20,33,4,33,32,48]

theorem envBound50214 : H12AffineFastState.Bounded env50214 := by
  intro p hp
  have h : env50214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50213_50214 : H12AffineEnvironment.transform 8 49 env50213 = env50214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50213 == env50214) = true)

theorem identity50214 : scanCanonicalize (H12AffineFastState.compose env50214 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50214 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50215 : List Nat := [2,4,8,16,16,17,8,4,1,21,1,0,8,17,1,2,0,16,21,0,17,17,16,3,8,16,0,1,1,17,20,17,4,17,16,0]

theorem envBound50215 : H12AffineFastState.Bounded env50215 := by
  intro p hp
  have h : env50215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50214_50215 : H12AffineEnvironment.transform 4 16 env50214 = env50215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50214 == env50215) = true)

theorem identity50215 : scanCanonicalize (H12AffineFastState.compose env50215 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50216 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,0,8,1,1,2,0,0,5,0,1,1,0,3,8,0,0,1,1,1,4,1,4,1,0,0]

theorem envBound50216 : H12AffineFastState.Bounded env50216 := by
  intro p hp
  have h : env50216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50215_50216 : H12AffineEnvironment.transform 3 0 env50215 = env50216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50215 == env50216) = true)

def env50217 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4160,4194304,16,21763,8193,65,4237693,5392,17665,10280,1365,4256860,256,21793,46093,63068]

theorem envBound50217 : H12AffineFastState.Bounded env50217 := by
  intro p hp
  have h : env50217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50202_50217 : H12AffineEnvironment.transform 6 9 env50202 = env50217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50202 == env50217) = true)

theorem identity50217 : scanCanonicalize (H12AffineFastState.compose env50217 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound50217 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50218 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4160,4194304,16,21763,8193,65,4237693,5392,17665,10280,1365,4256860,256,21793,46093,63068]

theorem envBound50218 : H12AffineFastState.Bounded env50218 := by
  intro p hp
  have h : env50218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50217_50218 : H12AffineEnvironment.transform 16 24909 env50217 = env50218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env50217 == env50218) = true)

theorem identity50218 : scanCanonicalize (H12AffineFastState.compose env50218 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound50218 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env50219 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,24909,35188,1024,32769,4160,8492,16,21763,8193,65,34897,5392,17665,10280,1365,54640,256,21793,46093,63068]

theorem envBound50219 : H12AffineFastState.Bounded env50219 := by
  intro p hp
  have h : env50219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50218_50219 : H12AffineEnvironment.transform 21 8492 env50218 = env50219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env50218 == env50219) = true)

theorem identity50219 : scanCanonicalize (H12AffineFastState.compose env50219 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound50219 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env50220 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30042,24909,10361,1024,8460,4160,8492,16,21763,8193,65,10588,5392,17665,10280,1365,29821,256,21793,5376,22353]

theorem envBound50220 : H12AffineFastState.Bounded env50220 := by
  intro p hp
  have h : env50220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50219_50220 : H12AffineEnvironment.transform 14 8461 env50219 = env50220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env50219 == env50220) = true)

theorem identity50220 : scanCanonicalize (H12AffineFastState.compose env50220 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50220 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50221 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8461,342,5441,10361,1024,8460,4160,8492,16,8463,8193,65,10588,5392,12557,10280,1365,113,256,8493,5376,9053]

theorem envBound50221 : H12AffineFastState.Bounded env50221 := by
  intro p hp
  have h : env50221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50220_50221 : H12AffineEnvironment.transform 13 13324 env50220 = env50221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50220 == env50221) = true)

theorem identity50221 : scanCanonicalize (H12AffineFastState.compose env50221 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound50221 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env50222 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5180,48,5425,342,5441,7237,1024,5424,4160,5392,16,5427,5181,65,7520,5392,1329,7188,1365,113,256,5393,5376,5985]

theorem envBound50222 : H12AffineFastState.Bounded env50222 := by
  intro p hp
  have h : env50222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50221_50222 : H12AffineEnvironment.transform 12 5180 env50221 = env50222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env50221 == env50222) = true)

theorem identity50222 : scanCanonicalize (H12AffineFastState.compose env50222 (packedSelected [0,1,2,3,4,5,6,8,10,11,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound50222 : packedSelected [0,1,2,3,4,5,6,8,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50223 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,593,1645,48,1888,342,1808,3604,1024,1889,529,1857,16,1890,1644,65,3889,1857,1329,3653,1365,113,256,1856,1873,1328]

theorem envBound50223 : H12AffineFastState.Bounded env50223 := by
  intro p hp
  have h : env50223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50222_50223 : H12AffineEnvironment.transform 11 593 env50222 = env50223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env50222 == env50223) = true)

theorem identity50223 : scanCanonicalize (H12AffineFastState.compose env50223 (packedSelected [0,1,3,4,5,8,11,12,16] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound50223 : packedSelected [0,1,3,4,5,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env50224 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,593,861,48,592,342,544,2852,304,593,529,625,16,594,860,65,2561,625,1,2933,101,113,256,624,609,0]

theorem envBound50224 : H12AffineFastState.Bounded env50224 := by
  intro p hp
  have h : env50224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50223_50224 : H12AffineEnvironment.transform 9 304 env50223 = env50224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env50223 == env50224) = true)

theorem identity50224 : scanCanonicalize (H12AffineFastState.compose env50224 (packedSelected [1,3,4,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound50224 : packedSelected [1,3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env50225 : List Nat := [2,4,8,16,32,48,9,256,512,304,2048,545,813,48,544,294,544,2852,304,545,529,513,16,546,812,49,2561,513,1,2821,21,1,256,512,529,0]

theorem envBound50225 : H12AffineFastState.Bounded env50225 := by
  intro p hp
  have h : env50225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50224_50225 : H12AffineEnvironment.transform 5 48 env50224 = env50225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env50224 == env50225) = true)

theorem identity50225 : scanCanonicalize (H12AffineFastState.compose env50225 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound50225 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50226 : List Nat := [2,4,8,16,32,48,9,256,32,304,2048,1,269,48,0,294,0,2308,304,1,49,33,16,2,268,49,2081,33,1,2341,21,1,256,32,49,0]

theorem envBound50226 : H12AffineFastState.Bounded env50226 := by
  intro p hp
  have h : env50226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50225_50226 : H12AffineEnvironment.transform 8 32 env50225 = env50226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env50225 == env50226) = true)

theorem identity50226 : scanCanonicalize (H12AffineFastState.compose env50226 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50226 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50227 : List Nat := [2,4,8,16,1,17,9,256,1,273,2048,1,269,17,0,263,0,2308,273,1,16,0,16,2,268,16,2048,0,1,2308,21,1,256,1,16,0]

theorem envBound50227 : H12AffineFastState.Bounded env50227 := by
  intro p hp
  have h : env50227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50226_50227 : H12AffineEnvironment.transform 4 1 env50226 = env50227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50226 == env50227) = true)

theorem identity50227 : scanCanonicalize (H12AffineFastState.compose env50227 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound50227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50228 : List Nat := [2,4,8,16,1,17,9,20,1,5,2048,1,25,17,0,19,0,2064,5,1,16,0,16,2,24,16,2048,0,1,2064,21,1,20,1,16,0]

theorem envBound50228 : H12AffineFastState.Bounded env50228 := by
  intro p hp
  have h : env50228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50227_50228 : H12AffineEnvironment.transform 7 20 env50227 = env50228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env50227 == env50228) = true)

theorem identity50228 : scanCanonicalize (H12AffineFastState.compose env50228 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50229 : List Nat := [2,4,8,10,1,11,9,14,1,5,2048,1,3,11,0,9,0,2058,5,1,10,0,10,2,2,10,2048,0,1,2058,15,1,14,1,10,0]

theorem envBound50229 : H12AffineFastState.Bounded env50229 := by
  intro p hp
  have h : env50229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50228_50229 : H12AffineEnvironment.transform 3 10 env50228 = env50229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50228 == env50229) = true)

theorem identity50229 : scanCanonicalize (H12AffineFastState.compose env50229 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50229 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50230 : List Nat := [2,4,3,1,1,0,2,5,1,5,2048,1,3,0,0,2,0,2049,5,1,1,0,1,2,2,1,2048,0,1,2049,4,1,5,1,1,0]

theorem envBound50230 : H12AffineFastState.Bounded env50230 := by
  intro p hp
  have h : env50230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50229_50230 : H12AffineEnvironment.transform 2 3 env50229 = env50230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50229 == env50230) = true)

theorem identity50230 : scanCanonicalize (H12AffineFastState.compose env50230 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50230 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env50231 : List Nat := [2,4,3,1,1,0,2,5,1,5,1,1,3,0,0,2,0,0,5,1,1,0,1,2,2,1,1,0,1,0,4,1,5,1,1,0]

theorem envBound50231 : H12AffineFastState.Bounded env50231 := by
  intro p hp
  have h : env50231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50230_50231 : H12AffineEnvironment.transform 10 1 env50230 = env50231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50230 == env50231) = true)

def env50232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,17,21762,8328,65,4291882,115150,17665,10281,119042,4268162,256,98814,90203,63189]

theorem envBound50232 : H12AffineFastState.Bounded env50232 := by
  intro p hp
  have h : env50232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50200_50232 : H12AffineEnvironment.transform 20 4161 env50200 = env50232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50200 == env50232) = true)

theorem identity50232 : scanCanonicalize (H12AffineFastState.compose env50232 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201830) := by decide +kernel

theorem selectedBound50232 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,201830,17,21762,8328,65,158028,115150,17665,10281,119042,144612,256,98814,90203,63189]

theorem envBound50233 : H12AffineFastState.Bounded env50233 := by
  intro p hp
  have h : env50233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50232_50233 : H12AffineEnvironment.transform 21 201830 env50232 = env50233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201830 env50232 == env50233) = true)

theorem identity50233 : scanCanonicalize (H12AffineFastState.compose env50233 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50233 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,138477,1024,29909,4161,201830,17,21762,8328,65,158028,79130,17665,10281,75222,144612,256,95530,90203,513]

theorem envBound50234 : H12AffineFastState.Bounded env50234 := by
  intro p hp
  have h : env50234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50233_50234 : H12AffineEnvironment.transform 14 29908 env50233 = env50234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50233 == env50234) = true)

theorem identity50234 : scanCanonicalize (H12AffineFastState.compose env50234 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50234 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,90139,97526,1024,29909,4161,29821,17,21762,8328,65,67927,79130,17665,10281,75222,87295,256,95530,90203,513]

theorem envBound50235 : H12AffineFastState.Bounded env50235 := by
  intro p hp
  have h : env50235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50234_50235 : H12AffineEnvironment.transform 16 90139 env50234 = env50235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50234 == env50235) = true)

theorem identity50235 : scanCanonicalize (H12AffineFastState.compose env50235 (packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound50235 : packedSelected [3,4,5,8,9,11,12,14,17,18,20,23,28,32,41] rootPS < 2^1333 := by decide +kernel

def env50236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,65536,79251,76158,1024,8541,4161,8693,17,138,8328,65,67927,79130,4233,10281,75222,65911,256,73890,79315,513]

theorem envBound50236 : H12AffineFastState.Bounded env50236 := by
  intro p hp
  have h : env50236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50235_50236 : H12AffineEnvironment.transform 13 5512 env50235 = env50236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env50235 == env50236) = true)

theorem identity50236 : scanCanonicalize (H12AffineFastState.compose env50236 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50236 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env50237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8540,8203,5528,2421,1024,8541,4161,8693,17,138,8328,65,10588,5393,4233,10281,1501,8572,256,169,5592,513]

theorem envBound50237 : H12AffineFastState.Bounded env50237 := by
  intro p hp
  have h : env50237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50236_50237 : H12AffineEnvironment.transform 15 8203 env50236 = env50237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50236 == env50237) = true)

theorem identity50237 : scanCanonicalize (H12AffineFastState.compose env50237 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound50237 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5512,509,170,5528,2421,1024,508,4161,340,17,138,41,65,2557,5393,4233,2184,1501,477,256,169,5592,513]

theorem envBound50238 : H12AffineFastState.Bounded env50238 := by
  intro p hp
  have h : env50238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50237_50238 : H12AffineEnvironment.transform 12 161 env50237 = env50238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env50237 == env50238) = true)

theorem identity50238 : scanCanonicalize (H12AffineFastState.compose env50238 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound50238 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env50239 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,121,5456,293,114,5440,2421,1024,292,4161,340,17,82,41,65,2341,5393,4177,2128,1285,261,256,113,5376,513]

theorem envBound50239 : H12AffineFastState.Bounded env50239 := by
  intro p hp
  have h : env50239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50238_50239 : H12AffineEnvironment.transform 6 88 env50238 = env50239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env50238 == env50239) = true)

theorem identity50239 : scanCanonicalize (H12AffineFastState.compose env50239 (packedSelected [5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50239 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env50240 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,121,5157,80,114,5173,2048,1024,81,4161,33,17,82,41,65,2128,5220,4177,2128,1136,112,117,113,5237,513]

theorem envBound50240 : H12AffineFastState.Bounded env50240 := by
  intro p hp
  have h : env50240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50239_50240 : H12AffineEnvironment.transform 7 117 env50239 = env50240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50239 == env50240) = true)

def env50241 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,0,34,5173,2048,1024,1,4113,33,17,2,41,17,2048,5172,4097,2048,1056,32,37,33,5157,513]

theorem envBound50241 : H12AffineFastState.Bounded env50241 := by
  intro p hp
  have h : env50241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50240_50241 : H12AffineEnvironment.transform 5 16 env50240 = env50241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50240 == env50241) = true)

def env50242 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,0,34,1029,2048,1024,1,33,33,17,2,41,17,2048,1028,49,2048,1056,32,37,33,1045,513]

theorem envBound50242 : H12AffineFastState.Bounded env50242 := by
  intro p hp
  have h : env50242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50241_50242 : H12AffineEnvironment.transform 11 48 env50241 = env50242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50241 == env50242) = true)

theorem identity50242 : scanCanonicalize (H12AffineFastState.compose env50242 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound50242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50243 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,48,41,1045,0,34,1029,1044,1024,1,33,33,17,2,41,17,1044,1028,49,1044,1056,32,37,33,1045,513]

theorem envBound50243 : H12AffineFastState.Bounded env50243 := by
  intro p hp
  have h : env50243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50242_50243 : H12AffineEnvironment.transform 10 1044 env50242 = env50243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env50242 == env50243) = true)

def env50244 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,48,41,33,0,34,49,32,52,1,33,33,17,2,41,17,32,48,49,32,20,32,37,33,33,513]

theorem envBound50244 : H12AffineFastState.Bounded env50244 := by
  intro p hp
  have h : env50244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50243_50244 : H12AffineEnvironment.transform 9 52 env50243 = env50244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50243 == env50244) = true)

def env50245 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,41,32,0,34,48,33,53,1,33,33,17,2,41,17,33,49,49,33,21,32,37,33,32,513]

theorem envBound50245 : H12AffineFastState.Bounded env50245 := by
  intro p hp
  have h : env50245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50243_50245 : H12AffineEnvironment.transform 9 53 env50243 = env50245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50243 == env50245) = true)

theorem identity50245 : scanCanonicalize (H12AffineFastState.compose env50245 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound50245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50246 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,48,41,32,0,34,48,33,53,1,33,33,17,2,41,17,33,49,49,33,21,32,37,33,32,43]

theorem envBound50246 : H12AffineFastState.Bounded env50246 := by
  intro p hp
  have h : env50246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50245_50246 : H12AffineEnvironment.transform 8 42 env50245 = env50246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env50245 == env50246) = true)

def leafEnv50246 : List Nat := [2,4,8,16,32,16,8,37,42,53,33,48,41,32,0,34,48,33,53,1,33,33,17,2,21,41,1,17,33,49,49,33,21,32,37,33,4,34,32,43,1,33,0]

def active50246 : List Nat := [0,1,2,3,4]

def tree50246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50246 : H12WitnessSearch.Good tree50246 := H12GlobalWitnessIndex.good

theorem leafIdentity50246 : H12AffineFastState.composeSystem env50246 rootObs = leafEnv50246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50246 rootObs == leafEnv50246) = true)

theorem terminalChecked50246 : H12PackedTerminal.terminalCheckFast leafEnv50246 active50246 tree50246 = true := by decide +kernel

def env50247 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,0,34,1028,2048,1024,1,32,33,17,2,41,17,2048,1029,48,2048,1056,32,37,33,1044,513]

theorem envBound50247 : H12AffineFastState.Bounded env50247 := by
  intro p hp
  have h : env50247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50241_50247 : H12AffineEnvironment.transform 11 49 env50241 = env50247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50241 == env50247) = true)

theorem identity50247 : scanCanonicalize (H12AffineFastState.compose env50247 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound50247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50248 : List Nat := [2,4,8,16,32,16,8,37,512,1024,32,49,41,1044,0,34,1028,32,1024,1,32,33,17,2,41,17,32,1029,48,32,1056,32,37,33,1044,513]

theorem envBound50248 : H12AffineFastState.Bounded env50248 := by
  intro p hp
  have h : env50248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50247_50248 : H12AffineEnvironment.transform 10 32 env50247 = env50248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env50247 == env50248) = true)

def env50249 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,41,32,0,34,48,32,52,1,32,33,17,2,41,17,32,49,48,32,20,32,37,33,32,513]

theorem envBound50249 : H12AffineFastState.Bounded env50249 := by
  intro p hp
  have h : env50249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50248_50249 : H12AffineEnvironment.transform 9 52 env50248 = env50249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50248 == env50249) = true)

def env50250 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,49,41,33,0,34,49,32,53,1,32,33,17,2,41,17,32,48,48,32,21,32,37,33,33,513]

theorem envBound50250 : H12AffineFastState.Bounded env50250 := by
  intro p hp
  have h : env50250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50248_50250 : H12AffineEnvironment.transform 9 53 env50248 = env50250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50248 == env50250) = true)

theorem identity50250 : scanCanonicalize (H12AffineFastState.compose env50250 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound50250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50251 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,49,41,33,0,34,49,32,53,1,32,33,17,2,41,17,32,48,48,32,21,32,37,33,33,42]

theorem envBound50251 : H12AffineFastState.Bounded env50251 := by
  intro p hp
  have h : env50251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50250_50251 : H12AffineEnvironment.transform 8 43 env50250 = env50251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env50250 == env50251) = true)

def leafEnv50251 : List Nat := [2,4,8,16,32,16,8,37,43,53,32,49,41,33,0,34,49,32,53,1,32,33,17,2,21,41,1,17,32,48,48,32,21,32,37,33,4,34,33,42,1,32,0]

def active50251 : List Nat := [0,1,2,3,4]

def tree50251 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50251 : H12WitnessSearch.Good tree50251 := H12GlobalWitnessIndex.good

theorem leafIdentity50251 : H12AffineFastState.composeSystem env50251 rootObs = leafEnv50251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50251 rootObs == leafEnv50251) = true)

theorem terminalChecked50251 : H12PackedTerminal.terminalCheckFast leafEnv50251 active50251 tree50251 = true := by decide +kernel

def env50252 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,35,5173,2048,1024,0,4112,33,17,3,41,16,2049,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound50252 : H12AffineFastState.Bounded env50252 := by
  intro p hp
  have h : env50252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50240_50252 : H12AffineEnvironment.transform 5 17 env50240 = env50252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50240 == env50252) = true)

theorem identity50252 : scanCanonicalize (H12AffineFastState.compose env50252 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50253 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,4096,40,4113,1,35,4097,2048,52,0,4112,33,17,3,41,16,2049,4097,4096,2049,21,33,36,32,4112,513]

theorem envBound50253 : H12AffineFastState.Bounded env50253 := by
  intro p hp
  have h : env50253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50252_50253 : H12AffineEnvironment.transform 9 52 env50252 = env50253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50252 == env50253) = true)

theorem identity50253 : scanCanonicalize (H12AffineFastState.compose env50253 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound50253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50254 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,32,40,49,1,35,33,2048,52,0,48,33,17,3,41,16,2049,33,32,2049,21,33,36,32,48,513]

theorem envBound50254 : H12AffineFastState.Bounded env50254 := by
  intro p hp
  have h : env50254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50253_50254 : H12AffineEnvironment.transform 11 32 env50253 = env50254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env50253 == env50254) = true)

theorem identity50254 : scanCanonicalize (H12AffineFastState.compose env50254 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound50254 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50255 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,40,49,1,35,33,49,52,0,48,33,17,3,41,16,48,33,32,48,21,33,36,32,48,513]

theorem envBound50255 : H12AffineFastState.Bounded env50255 := by
  intro p hp
  have h : env50255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50254_50255 : H12AffineEnvironment.transform 10 49 env50254 = env50255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env50254 == env50255) = true)

def leafEnv50255 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,32,40,49,1,35,33,49,52,0,48,33,17,3,21,41,1,16,48,33,32,48,21,33,36,32,4,34,48,513,1,49,0]

def active50255 : List Nat := [0,1,2,3,4,8]

def tree50255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50255 : H12WitnessSearch.Good tree50255 := H12GlobalWitnessIndex.good

theorem leafIdentity50255 : H12AffineFastState.composeSystem env50255 rootObs = leafEnv50255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50255 rootObs == leafEnv50255) = true)

theorem terminalChecked50255 : H12PackedTerminal.terminalCheckFast leafEnv50255 active50255 tree50255 = true := by decide +kernel

def env50256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,2097152,4194304,2101329,2114883,8328,65,4291883,115150,17664,2111593,119043,4268162,256,2199998,2191387,63188]

theorem envBound50256 : H12AffineFastState.Bounded env50256 := by
  intro p hp
  have h : env50256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50199_50256 : H12AffineEnvironment.transform 22 2101329 env50199 = env50256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env50199 == env50256) = true)

def env50257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,4194304,17,21763,8328,65,4291883,115150,17664,10281,119043,4268162,256,98814,90203,63188]

theorem envBound50257 : H12AffineFastState.Bounded env50257 := by
  intro p hp
  have h : env50257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50256_50257 : H12AffineEnvironment.transform 20 4160 env50256 = env50257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50256 == env50257) = true)

theorem identity50257 : scanCanonicalize (H12AffineFastState.compose env50257 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254130) := by decide +kernel

theorem selectedBound50257 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254130,17,21763,8328,65,171417,115150,17664,10281,119043,180272,256,98814,90203,63188]

theorem envBound50258 : H12AffineFastState.Bounded env50258 := by
  intro p hp
  have h : env50258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50257_50258 : H12AffineEnvironment.transform 21 254130 env50257 = env50258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254130 env50257 == env50258) = true)

def env50259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254010,17,21763,8192,65,171281,115014,17664,10281,119043,180272,256,98678,90203,63068]

theorem envBound50259 : H12AffineFastState.Bounded env50259 := by
  intro p hp
  have h : env50259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50258_50259 : H12AffineEnvironment.transform 6 8 env50258 = env50259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50258 == env50259) = true)

theorem identity50259 : scanCanonicalize (H12AffineFastState.compose env50259 (packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 115015) := by decide +kernel

theorem selectedBound50259 : packedSelected [3,7,8,11,12,14,15,20,24,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env50260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,115015,76158,1024,32769,4160,8573,17,21763,8192,65,89174,115014,17664,10281,119043,65911,256,98678,90203,63068]

theorem envBound50260 : H12AffineFastState.Bounded env50260 := by
  intro p hp
  have h : env50260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50259_50260 : H12AffineEnvironment.transform 16 115015 env50259 = env50260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115015 env50259 == env50260) = true)

theorem identity50260 : scanCanonicalize (H12AffineFastState.compose env50260 (packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound50260 : packedSelected [4,7,9,10,12,18,23,27,31,41] rootPS < 2^1333 := by decide +kernel

def env50261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5393,64808,1024,32769,4160,8573,17,21763,8192,65,34816,5392,17664,10281,1365,54561,256,21792,46093,63068]

theorem envBound50261 : H12AffineFastState.Bounded env50261 := by
  intro p hp
  have h : env50261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50260_50261 : H12AffineEnvironment.transform 15 54358 env50260 = env50261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env50260 == env50261) = true)

theorem identity50261 : scanCanonicalize (H12AffineFastState.compose env50261 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50261 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env50262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,5393,23668,1024,8541,4160,8573,17,21763,8192,65,10588,5392,17664,10281,1365,29821,256,21792,5457,22272]

theorem envBound50262 : H12AffineFastState.Bounded env50262 := by
  intro p hp
  have h : env50262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50261_50262 : H12AffineEnvironment.transform 14 8540 env50261 = env50262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50261 == env50262) = true)

theorem identity50262 : scanCanonicalize (H12AffineFastState.compose env50262 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50262 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50263 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,2421,1024,8541,4160,8573,17,2,8192,65,10588,5392,4097,10281,1365,8572,256,33,5457,513]

theorem envBound50263 : H12AffineFastState.Bounded env50263 := by
  intro p hp
  have h : env50263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50262_50263 : H12AffineEnvironment.transform 13 5377 env50262 = env50263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50262 == env50263) = true)

theorem identity50263 : scanCanonicalize (H12AffineFastState.compose env50263 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50263 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,5393,2421,1024,81,4160,113,17,2,268,65,2128,5392,4097,2341,1365,112,256,33,5457,513]

theorem envBound50264 : H12AffineFastState.Bounded env50264 := by
  intro p hp
  have h : env50264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50263_50264 : H12AffineEnvironment.transform 12 268 env50263 = env50264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50263 == env50264) = true)

theorem identity50264 : scanCanonicalize (H12AffineFastState.compose env50264 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50264 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50265 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5393,2341,1024,1,4112,33,17,2,268,17,2048,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound50265 : H12AffineFastState.Bounded env50265 := by
  intro p hp
  have h : env50265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50264_50265 : H12AffineEnvironment.transform 5 16 env50264 = env50265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50264 == env50265) = true)

theorem identity50265 : scanCanonicalize (H12AffineFastState.compose env50265 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50265 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50266 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,0,35,5173,2049,1024,1,4112,33,17,2,40,17,2048,5172,4097,2049,1057,32,36,33,5157,513]

theorem envBound50266 : H12AffineFastState.Bounded env50266 := by
  intro p hp
  have h : env50266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50265_50266 : H12AffineEnvironment.transform 7 36 env50265 = env50266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50265 == env50266) = true)

def env50267 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,0,35,1029,2049,1024,1,32,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,513]

theorem envBound50267 : H12AffineFastState.Bounded env50267 := by
  intro p hp
  have h : env50267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50266_50267 : H12AffineEnvironment.transform 11 48 env50266 = env50267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env50266 == env50267) = true)

theorem identity50267 : scanCanonicalize (H12AffineFastState.compose env50267 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50267 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50268 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,48,40,1045,0,35,1029,2049,1024,1,32,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1045,49]

theorem envBound50268 : H12AffineFastState.Bounded env50268 := by
  intro p hp
  have h : env50268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50267_50268 : H12AffineEnvironment.transform 8 48 env50267 = env50268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50267 == env50268) = true)

def env50269 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,40,33,0,35,49,2049,52,1,32,33,17,2,40,17,2048,48,49,2049,21,32,36,33,33,49]

theorem envBound50269 : H12AffineFastState.Bounded env50269 := by
  intro p hp
  have h : env50269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50268_50269 : H12AffineEnvironment.transform 9 52 env50268 = env50269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50268 == env50269) = true)

def env50270 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,40,32,0,35,48,2049,53,1,32,33,17,2,40,17,2048,49,49,2049,20,32,36,33,32,49]

theorem envBound50270 : H12AffineFastState.Bounded env50270 := by
  intro p hp
  have h : env50270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50268_50270 : H12AffineEnvironment.transform 9 53 env50268 = env50270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env50268 == env50270) = true)

theorem identity50270 : scanCanonicalize (H12AffineFastState.compose env50270 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50271 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,43,40,32,0,35,43,2049,46,1,32,33,10,2,40,10,2048,42,42,2049,15,32,36,33,32,42]

theorem envBound50271 : H12AffineFastState.Bounded env50271 := by
  intro p hp
  have h : env50271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50270_50271 : H12AffineEnvironment.transform 3 11 env50270 = env50271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50270 == env50271) = true)

def leafEnv50271 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,43,40,32,0,35,43,2049,46,1,32,33,10,2,15,40,1,10,2048,42,42,2049,15,32,36,33,4,35,32,42,1,32,0]

def active50271 : List Nat := [0,1,2,4,10]

def tree50271 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50271 : H12WitnessSearch.Good tree50271 := H12GlobalWitnessIndex.good

theorem leafIdentity50271 : H12AffineFastState.composeSystem env50271 rootObs = leafEnv50271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50271 rootObs == leafEnv50271) = true)

theorem terminalChecked50271 : H12PackedTerminal.terminalCheckFast leafEnv50271 active50271 tree50271 = true := by decide +kernel

def env50272 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,0,35,1028,2049,1024,1,33,33,17,2,40,17,2048,1029,48,2049,1057,32,36,33,1044,513]

theorem envBound50272 : H12AffineFastState.Bounded env50272 := by
  intro p hp
  have h : env50272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50266_50272 : H12AffineEnvironment.transform 11 49 env50266 = env50272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env50266 == env50272) = true)

theorem identity50272 : scanCanonicalize (H12AffineFastState.compose env50272 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound50272 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50273 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,49,40,528,0,35,512,2049,516,1,33,33,17,2,40,17,2048,513,48,2049,549,32,36,33,528,513]

theorem envBound50273 : H12AffineFastState.Bounded env50273 := by
  intro p hp
  have h : env50273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50272_50273 : H12AffineEnvironment.transform 9 516 env50272 = env50273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env50272 == env50273) = true)

def env50274 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,40,32,0,35,48,2049,52,1,33,33,17,2,40,17,2048,49,48,2049,21,32,36,33,32,49]

theorem envBound50274 : H12AffineFastState.Bounded env50274 := by
  intro p hp
  have h : env50274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50273_50274 : H12AffineEnvironment.transform 8 48 env50273 = env50274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50273 == env50274) = true)

def env50275 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,40,33,0,35,49,2049,53,1,33,33,17,2,40,17,2048,48,48,2049,20,32,36,33,33,48]

theorem envBound50275 : H12AffineFastState.Bounded env50275 := by
  intro p hp
  have h : env50275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50273_50275 : H12AffineEnvironment.transform 8 49 env50273 = env50275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50273 == env50275) = true)

theorem identity50275 : scanCanonicalize (H12AffineFastState.compose env50275 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50275 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50276 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,42,40,33,0,35,42,2049,46,1,33,33,10,2,40,10,2048,43,43,2049,15,32,36,33,33,43]

theorem envBound50276 : H12AffineFastState.Bounded env50276 := by
  intro p hp
  have h : env50276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50275_50276 : H12AffineEnvironment.transform 3 11 env50275 = env50276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50275 == env50276) = true)

def leafEnv50276 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,42,40,33,0,35,42,2049,46,1,33,33,10,2,15,40,1,10,2048,43,43,2049,15,32,36,33,4,35,33,43,1,33,0]

def active50276 : List Nat := [0,1,2,4,10]

def tree50276 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50276 : H12WitnessSearch.Good tree50276 := H12GlobalWitnessIndex.good

theorem leafIdentity50276 : H12AffineFastState.composeSystem env50276 rootObs = leafEnv50276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50276 rootObs == leafEnv50276) = true)

theorem terminalChecked50276 : H12PackedTerminal.terminalCheckFast leafEnv50276 active50276 tree50276 = true := by decide +kernel

def env50277 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,254011,17,21763,8193,65,171280,115015,17664,10281,119043,180272,256,98679,90203,63069]

theorem envBound50277 : H12AffineFastState.Bounded env50277 := by
  intro p hp
  have h : env50277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50258_50277 : H12AffineEnvironment.transform 6 9 env50258 = env50277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50258 == env50277) = true)

theorem identity50277 : scanCanonicalize (H12AffineFastState.compose env50277 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50277 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50278 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149861,1024,8541,4160,213351,17,21763,8193,65,146508,90139,17664,10281,94303,156012,256,73771,90203,22273]

theorem envBound50278 : H12AffineFastState.Bounded env50278 := by
  intro p hp
  have h : env50278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50277_50278 : H12AffineEnvironment.transform 14 8540 env50277 = env50278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50277 == env50278) = true)

theorem identity50278 : scanCanonicalize (H12AffineFastState.compose env50278 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound50278 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50279 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,79131,97406,1024,8541,4160,29820,17,21763,8193,65,67927,90139,17664,10281,94303,87159,256,73771,90203,22273]

theorem envBound50279 : H12AffineFastState.Bounded env50279 := by
  intro p hp
  have h : env50279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50278_50279 : H12AffineEnvironment.transform 16 79131 env50278 = env50279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env50278 == env50279) = true)

theorem identity50279 : scanCanonicalize (H12AffineFastState.compose env50279 (packedSelected [0,4,8,10,12,14,15,16,18,22,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound50279 : packedSelected [0,4,8,10,12,14,15,16,18,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env50280 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,292,65536,71011,89094,1024,293,4160,21508,17,21763,121,65,67927,82019,17664,2129,86055,87159,256,65619,81955,22273]

theorem envBound50280 : H12AffineFastState.Bounded env50280 := by
  intro p hp
  have h : env50280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50279_50280 : H12AffineEnvironment.transform 12 120 env50279 = env50280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env50279 == env50280) = true)

theorem identity50280 : scanCanonicalize (H12AffineFastState.compose env50280 (packedSelected [6,9,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50280 : packedSelected [6,9,22] rootPS < 2^1333 := by decide +kernel

def env50281 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,0,65536,70727,89094,1024,1,4160,21508,17,21543,121,65,67699,82019,17444,2129,86055,87159,36,65619,81955,22053]

theorem envBound50281 : H12AffineFastState.Bounded env50281 := by
  intro p hp
  have h : env50281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50280_50281 : H12AffineEnvironment.transform 7 36 env50280 = env50281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50280 == env50281) = true)

theorem identity50281 : scanCanonicalize (H12AffineFastState.compose env50281 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21511) := by decide +kernel

theorem selectedBound50281 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env50282 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,16384,0,21511,16448,2049,1024,1,4160,21508,17,21543,121,65,23668,5220,17444,2129,1056,112,36,21588,5156,22053]

theorem envBound50282 : H12AffineFastState.Bounded env50282 := by
  intro p hp
  have h : env50282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50281_50282 : H12AffineEnvironment.transform 15 21511 env50281 = env50282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21511 env50281 == env50282) = true)

def env50283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,21762,8328,65,4291883,115150,17664,10280,119043,4268162,256,98815,90202,63188]

theorem envBound50283 : H12AffineFastState.Bounded env50283 := by
  intro p hp
  have h : env50283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50256_50283 : H12AffineEnvironment.transform 20 4161 env50256 = env50283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50256 == env50283) = true)

theorem identity50283 : scanCanonicalize (H12AffineFastState.compose env50283 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,4194304,16,21762,8328,65,4218145,57796,17664,10280,61705,4194440,256,41461,16464,63188]

theorem envBound50284 : H12AffineFastState.Bounded env50284 := by
  intro p hp
  have h : env50284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50283_50284 : H12AffineEnvironment.transform 15 8202 env50283 = env50284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50283 == env50284) = true)

def env50285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,4194304,16,21762,8192,65,4218145,57676,17664,10280,61705,4194304,256,41341,16464,63068]

theorem envBound50285 : H12AffineFastState.Bounded env50285 := by
  intro p hp
  have h : env50285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50284_50285 : H12AffineEnvironment.transform 6 8 env50284 = env50285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50284 == env50285) = true)

theorem identity50285 : scanCanonicalize (H12AffineFastState.compose env50285 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound50285 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1024,32769,4161,4194304,16,21762,8192,65,4218145,57676,17664,10280,61705,4194304,256,41341,16464,63068]

theorem envBound50286 : H12AffineFastState.Bounded env50286 := by
  intro p hp
  have h : env50286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50285_50286 : H12AffineEnvironment.transform 16 49168 env50285 = env50286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env50285 == env50286) = true)

theorem identity50286 : scanCanonicalize (H12AffineFastState.compose env50286 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound50286 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env50287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1024,32769,4161,62589,16,21762,8192,65,43356,57676,17664,10280,61705,62589,256,41341,16464,63068]

theorem envBound50287 : H12AffineFastState.Bounded env50287 := by
  intro p hp
  have h : env50287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50286_50287 : H12AffineEnvironment.transform 21 62589 env50286 = env50287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env50286 == env50287) = true)

theorem identity50287 : scanCanonicalize (H12AffineFastState.compose env50287 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound50287 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,46157,10281,1024,32769,4161,32800,16,8543,8192,65,43356,38161,12637,10280,34132,32800,256,41341,13325,33281]

theorem envBound50288 : H12AffineFastState.Bounded env50288 := by
  intro p hp
  have h : env50288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50287_50288 : H12AffineEnvironment.transform 13 13405 env50287 = env50288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env50287 == env50288) = true)

theorem identity50288 : scanCanonicalize (H12AffineFastState.compose env50288 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50288 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env50289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8202,5392,10281,1024,8540,4161,8573,16,8543,8192,65,2049,13388,12637,10280,9225,8573,256,32,13325,9052]

theorem envBound50289 : H12AffineFastState.Bounded env50289 := by
  intro p hp
  have h : env50289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50288_50289 : H12AffineEnvironment.transform 14 8541 env50288 = env50289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50288 == env50289) = true)

theorem identity50289 : scanCanonicalize (H12AffineFastState.compose env50289 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound50289 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,0,8192,9309,8541,8202,1296,10281,1024,8540,65,8573,16,8543,8192,65,2049,9292,8541,10280,9225,8573,256,32,9229,9052]

theorem envBound50290 : H12AffineFastState.Bounded env50290 := by
  intro p hp
  have h : env50290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50289_50290 : H12AffineEnvironment.transform 11 0 env50289 = env50290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env50289 == env50290) = true)

theorem identity50290 : scanCanonicalize (H12AffineFastState.compose env50290 (packedSelected [2,4,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50290 : packedSelected [2,4,9,12,15] rootPS < 2^1333 := by decide +kernel

def env50291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,0,41,1140,372,35,1296,2048,1024,373,65,340,16,374,41,65,2049,1125,372,2049,1056,340,256,32,1060,885]

theorem envBound50291 : H12AffineFastState.Bounded env50291 := by
  intro p hp
  have h : env50291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50290_50291 : H12AffineEnvironment.transform 12 41 env50290 = env50291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50290 == env50291) = true)

theorem identity50291 : scanCanonicalize (H12AffineFastState.compose env50291 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 330) := by decide +kernel

theorem selectedBound50291 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env50292 : List Nat := [2,4,8,16,32,64,8,256,512,330,2048,0,41,318,372,35,90,2048,330,373,65,340,16,374,41,65,2049,303,372,2049,362,340,256,32,366,885]

theorem envBound50292 : H12AffineFastState.Bounded env50292 := by
  intro p hp
  have h : env50292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50291_50292 : H12AffineEnvironment.transform 9 330 env50291 = env50292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 330 env50291 == env50292) = true)

def env50293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,4194304,16,21762,8193,65,4218145,57677,17664,10280,61705,4194305,256,41340,16464,63069]

theorem envBound50293 : H12AffineFastState.Bounded env50293 := by
  intro p hp
  have h : env50293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50284_50293 : H12AffineEnvironment.transform 6 9 env50284 = env50293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50284 == env50293) = true)

theorem identity50293 : scanCanonicalize (H12AffineFastState.compose env50293 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound50293 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35188,1024,32769,4161,4194304,16,21762,8193,65,4218145,57677,17664,10280,61705,4194305,256,41340,16464,63069]

theorem envBound50294 : H12AffineFastState.Bounded env50294 := by
  intro p hp
  have h : env50294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50293_50294 : H12AffineEnvironment.transform 16 24909 env50293 = env50294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env50293 == env50294) = true)

theorem identity50294 : scanCanonicalize (H12AffineFastState.compose env50294 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound50294 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env50295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24909,35188,1024,32769,4161,41341,16,21762,8193,65,64604,57677,17664,10280,61705,41340,256,41340,16464,63069]

theorem envBound50295 : H12AffineFastState.Bounded env50295 := by
  intro p hp
  have h : env50295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50294_50295 : H12AffineEnvironment.transform 21 41341 env50294 = env50295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env50294 == env50295) = true)

theorem identity50295 : scanCanonicalize (H12AffineFastState.compose env50295 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound50295 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50296 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,16384,32768,2,16709,35188,1024,32769,4161,33141,16,21762,9,65,56404,49477,17664,2080,53505,33140,256,33140,16464,54869]

theorem envBound50296 : H12AffineFastState.Bounded env50296 := by
  intro p hp
  have h : env50296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50295_50296 : H12AffineEnvironment.transform 12 8 env50295 = env50296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env50295 == env50296) = true)

theorem identity50296 : scanCanonicalize (H12AffineFastState.compose env50296 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound50296 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env50297 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,32768,2,5393,35188,1024,32769,4161,33141,16,342,9,65,34816,38161,4436,2080,34133,33140,256,33140,5124,33281]

theorem envBound50297 : H12AffineFastState.Bounded env50297 := by
  intro p hp
  have h : env50297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50296_50297 : H12AffineEnvironment.transform 13 5204 env50296 = env50297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env50296 == env50297) = true)

theorem identity50297 : scanCanonicalize (H12AffineFastState.compose env50297 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50297 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,0,2,5393,2420,1024,1,4161,373,16,342,9,65,2048,5393,4436,2080,1365,372,256,372,5124,513]

theorem envBound50298 : H12AffineFastState.Bounded env50298 := by
  intro p hp
  have h : env50298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50297_50298 : H12AffineEnvironment.transform 14 0 env50297 = env50298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50297 == env50298) = true)

theorem identity50298 : scanCanonicalize (H12AffineFastState.compose env50298 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound50298 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50299 : List Nat := [2,4,8,16,32,64,9,256,512,68,2048,4096,8,4112,0,2,4437,2420,68,1,4161,373,16,342,9,65,2048,4437,4436,2080,273,372,256,372,4160,513]

theorem envBound50299 : H12AffineFastState.Bounded env50299 := by
  intro p hp
  have h : env50299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50298_50299 : H12AffineEnvironment.transform 9 68 env50298 = env50299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env50298 == env50299) = true)

def env50300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound50300 : H12AffineFastState.Bounded env50300 := by
  intro p hp
  have h : env50300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50099_50300 : H12AffineEnvironment.transform 18 1025 env50099 = env50300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env50099 == env50300) = true)

theorem identity50300 : scanCanonicalize (H12AffineFastState.compose env50300 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2444795) := by decide +kernel

theorem selectedBound50300 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2444795,16777216,8328,65,23236090,18973836,333994,2330107,19188202,23160257,257,17074518,17066226,19263036]

theorem envBound50301 : H12AffineFastState.Bounded env50301 := by
  intro p hp
  have h : env50301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50300_50301 : H12AffineEnvironment.transform 22 2444795 env50300 = env50301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2444795 env50300 == env50301) = true)

def env50302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,16777216,8328,65,16959642,18973836,333994,2330107,19188202,16851105,257,17074518,17066226,19263036]

theorem envBound50302 : H12AffineFastState.Bounded env50302 := by
  intro p hp
  have h : env50302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50301_50302 : H12AffineEnvironment.transform 21 2114912 env50301 = env50302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env50301 == env50302) = true)

def env50303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431208,8328,65,2609266,302180,333994,2330107,119042,2373705,257,2199998,2191386,63188]

theorem envBound50303 : H12AffineFastState.Bounded env50303 := by
  intro p hp
  have h : env50303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50302_50303 : H12AffineEnvironment.transform 23 2431208 env50302 = env50303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431208 env50302 == env50303) = true)

def env50304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329896,8328,65,507954,302180,333994,236987,119042,272393,257,98814,90202,63188]

theorem envBound50304 : H12AffineFastState.Bounded env50304 := by
  intro p hp
  have h : env50304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50303_50304 : H12AffineEnvironment.transform 20 4160 env50303 = env50304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50303 == env50304) = true)

theorem identity50304 : scanCanonicalize (H12AffineFastState.compose env50304 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound50304 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4160,21792,351675,329896,8328,65,472295,288945,333994,223598,75223,272393,257,95531,90202,513]

theorem envBound50305 : H12AffineFastState.Bounded env50305 := by
  intro p hp
  have h : env50305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50304_50305 : H12AffineEnvironment.transform 14 29909 env50304 = env50305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env50304 == env50305) = true)

def env50306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,4160,21792,351539,329760,8192,65,472175,288825,333858,223598,75103,272393,257,95531,90202,513]

theorem envBound50306 : H12AffineFastState.Bounded env50306 := by
  intro p hp
  have h : env50306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50305_50306 : H12AffineEnvironment.transform 6 8 env50305 = env50306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50305 == env50306) = true)

theorem identity50306 : scanCanonicalize (H12AffineFastState.compose env50306 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50306 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50307 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,90139,262144,1025,29788,4160,21792,351539,329760,8192,65,283764,288825,333858,2421,75103,272393,257,95531,90202,513]

theorem envBound50307 : H12AffineFastState.Bounded env50307 := by
  intro p hp
  have h : env50307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50306_50307 : H12AffineEnvironment.transform 16 90139 env50306 = env50307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50306 == env50307) = true)

theorem identity50307 : scanCanonicalize (H12AffineFastState.compose env50307 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound50307 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,23,32] rootPS < 2^1333 := by decide +kernel

def env50308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1076,65536,69746,262144,1025,1077,4160,9545,339290,329760,8192,65,271389,268368,333858,2421,75103,272393,257,66882,69683,513]

theorem envBound50308 : H12AffineFastState.Bounded env50308 := by
  intro p hp
  have h : env50308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50307_50308 : H12AffineEnvironment.transform 13 12393 env50307 = env50308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env50307 == env50308) = true)

theorem identity50308 : scanCanonicalize (H12AffineFastState.compose env50308 (packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 2129) := by decide +kernel

theorem selectedBound50308 : packedSelected [0,2,4,6,9,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env50309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1076,65536,69746,2129,1025,1077,4160,9545,75019,65649,8192,65,11340,4097,69747,2421,75103,8280,257,66882,69683,513]

theorem envBound50309 : H12AffineFastState.Bounded env50309 := by
  intro p hp
  have h : env50309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50308_50309 : H12AffineEnvironment.transform 17 2129 env50308 = env50309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2129 env50308 == env50309) = true)

theorem identity50309 : scanCanonicalize (H12AffineFastState.compose env50309 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound50309 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12393,1076,9498,13672,2129,1025,1077,4160,9545,17,9579,8192,65,11340,4097,13673,2421,69,8280,257,8280,13609,513]

theorem envBound50310 : H12AffineFastState.Bounded env50310 := by
  intro p hp
  have h : env50310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50309_50310 : H12AffineEnvironment.transform 15 9498 env50309 = env50310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env50309 == env50310) = true)

theorem identity50310 : scanCanonicalize (H12AffineFastState.compose env50310 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound50310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1385,5376,1076,115,4097,2129,1025,1077,4160,32,17,2,1385,65,2341,4097,4096,2421,69,1329,257,1329,4160,513]

theorem envBound50311 : H12AffineFastState.Bounded env50311 := by
  intro p hp
  have h : env50311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50310_50311 : H12AffineEnvironment.transform 12 1385 env50310 = env50311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env50310 == env50311) = true)

theorem identity50311 : scanCanonicalize (H12AffineFastState.compose env50311 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound50311 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env50312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1329,4096,1385,5376,1076,115,4097,1376,1025,1077,4160,32,17,2,1385,65,1044,4097,4096,1092,69,1329,257,1329,4160,513]

theorem envBound50312 : H12AffineFastState.Bounded env50312 := by
  intro p hp
  have h : env50312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50311_50312 : H12AffineEnvironment.transform 10 1329 env50311 = env50312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env50311 == env50312) = true)

def env50313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,4160,21792,351538,329761,8193,65,472174,288824,333859,223598,75102,272393,257,95531,90202,513]

theorem envBound50313 : H12AffineFastState.Bounded env50313 := by
  intro p hp
  have h : env50313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50305_50313 : H12AffineEnvironment.transform 6 9 env50305 = env50313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50305 == env50313) = true)

theorem identity50313 : scanCanonicalize (H12AffineFastState.compose env50313 (packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound50313 : packedSelected [0,1,2,3,5,6,8,10,14,15,16,17,18,19,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env50314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21840,65536,131072,262144,1025,21841,4160,21792,351538,329761,269,65,464226,280884,333859,215138,66642,264453,257,87079,82262,513]

theorem envBound50314 : H12AffineFastState.Bounded env50314 := by
  intro p hp
  have h : env50314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50313_50314 : H12AffineEnvironment.transform 12 268 env50313 = env50314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env50313 == env50314) = true)

theorem identity50314 : scanCanonicalize (H12AffineFastState.compose env50314 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50314 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env50315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,65536,131072,262144,1025,80,4160,33,329779,329761,269,65,464226,269365,333859,204131,66642,264453,257,65830,70743,513]

theorem envBound50315 : H12AffineFastState.Bounded env50315 := by
  intro p hp
  have h : env50315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50314_50315 : H12AffineEnvironment.transform 13 5377 env50314 = env50315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50314 == env50315) = true)

theorem identity50315 : scanCanonicalize (H12AffineFastState.compose env50315 (packedSelected [0,7,16] rootPS)) = affineNative (2^(17+1) ^^^ 204082) := by decide +kernel

theorem selectedBound50315 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env50316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,65536,131072,204082,1025,80,4160,33,136449,136467,269,65,2128,196871,132369,204131,66642,201783,257,65830,70743,513]

theorem envBound50316 : H12AffineFastState.Bounded env50316 := by
  intro p hp
  have h : env50316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50315_50316 : H12AffineEnvironment.transform 17 204082 env50315 = env50316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204082 env50315 == env50316) = true)

theorem identity50316 : scanCanonicalize (H12AffineFastState.compose env50316 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound50316 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env50317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,65536,5392,67618,1025,80,4160,33,17,3,269,65,2128,70679,4097,67699,66642,65831,257,65830,70743,513]

theorem envBound50317 : H12AffineFastState.Bounded env50317 := by
  intro p hp
  have h : env50317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50316_50317 : H12AffineEnvironment.transform 16 5392 env50316 = env50317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50316 == env50317) = true)

theorem identity50317 : scanCanonicalize (H12AffineFastState.compose env50317 (packedSelected [0,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 5654) := by decide +kernel

theorem selectedBound50317 : packedSelected [0,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50318 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,5654,5392,7732,1025,80,4160,33,17,3,269,65,2128,513,4097,7781,4676,5937,257,5936,577,513]

theorem envBound50318 : H12AffineFastState.Bounded env50318 := by
  intro p hp
  have h : env50318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50317_50318 : H12AffineEnvironment.transform 15 5654 env50317 = env50318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5654 env50317 == env50318) = true)

theorem identity50318 : scanCanonicalize (H12AffineFastState.compose env50318 (packedSelected [2,4,7,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50318 : packedSelected [2,4,7,10,12] rootPS < 2^1333 := by decide +kernel

def env50319 : List Nat := [2,4,8,16,32,64,9,256,512,21,2048,4096,268,4372,81,4611,4357,6689,20,80,4160,33,17,3,269,65,2128,513,4097,6768,4676,4900,257,4901,577,513]

theorem envBound50319 : H12AffineFastState.Bounded env50319 := by
  intro p hp
  have h : env50319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50318_50319 : H12AffineEnvironment.transform 9 21 env50318 = env50319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50318 == env50319) = true)

theorem identity50319 : scanCanonicalize (H12AffineFastState.compose env50319 (packedSelected [2,3,4,5,7,15] rootPS)) = affineNative (2^(11+1) ^^^ 773) := by decide +kernel

theorem selectedBound50319 : packedSelected [2,3,4,5,7,15] rootPS < 2^1333 := by decide +kernel

def env50320 : List Nat := [2,4,8,16,32,64,9,256,512,21,2048,773,268,529,81,262,512,2340,20,80,837,33,17,3,269,65,2128,513,772,2421,321,33,257,32,577,513]

theorem envBound50320 : H12AffineFastState.Bounded env50320 := by
  intro p hp
  have h : env50320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50319_50320 : H12AffineEnvironment.transform 11 773 env50319 = env50320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env50319 == env50320) = true)

theorem identity50320 : scanCanonicalize (H12AffineFastState.compose env50320 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound50320 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50321 : List Nat := [2,4,8,16,32,64,9,256,277,21,2048,16,268,260,81,262,277,2340,20,80,80,33,17,3,269,65,2128,276,17,2421,321,33,257,32,340,276]

theorem envBound50321 : H12AffineFastState.Bounded env50321 := by
  intro p hp
  have h : env50321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50320_50321 : H12AffineEnvironment.transform 8 277 env50320 = env50321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50320 == env50321) = true)

theorem identity50321 : scanCanonicalize (H12AffineFastState.compose env50321 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound50321 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50322 : List Nat := [2,4,8,16,32,64,9,256,277,21,341,16,268,260,81,262,277,113,20,80,80,33,17,3,269,65,261,276,17,32,321,33,257,32,340,276]

theorem envBound50322 : H12AffineFastState.Bounded env50322 := by
  intro p hp
  have h : env50322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50321_50322 : H12AffineEnvironment.transform 10 341 env50321 = env50322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env50321 == env50322) = true)

theorem identity50322 : scanCanonicalize (H12AffineFastState.compose env50322 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound50322 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50323 : List Nat := [2,4,8,16,32,64,9,101,112,21,48,16,105,97,81,99,112,113,20,80,80,33,17,3,104,65,96,113,17,32,36,33,100,32,49,113]

theorem envBound50323 : H12AffineFastState.Bounded env50323 := by
  intro p hp
  have h : env50323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50322_50323 : H12AffineEnvironment.transform 7 101 env50322 = env50323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env50322 == env50323) = true)

theorem identity50323 : scanCanonicalize (H12AffineFastState.compose env50323 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound50323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50324 : List Nat := [2,4,8,16,32,33,9,4,17,21,48,16,8,0,48,2,17,16,20,49,49,33,17,3,9,32,1,16,17,32,36,33,5,32,49,16]

theorem envBound50324 : H12AffineFastState.Bounded env50324 := by
  intro p hp
  have h : env50324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50323_50324 : H12AffineEnvironment.transform 5 33 env50323 = env50324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env50323 == env50324) = true)

theorem identity50324 : scanCanonicalize (H12AffineFastState.compose env50324 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound50324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50325 : List Nat := [2,4,8,16,27,26,9,4,17,21,11,16,8,0,11,2,17,16,20,10,10,26,17,3,9,27,1,16,17,27,31,26,5,27,10,16]

theorem envBound50325 : H12AffineFastState.Bounded env50325 := by
  intro p hp
  have h : env50325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50324_50325 : H12AffineEnvironment.transform 4 27 env50324 = env50325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env50324 == env50325) = true)

theorem identity50325 : scanCanonicalize (H12AffineFastState.compose env50325 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound50325 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50326 : List Nat := [2,4,8,11,0,1,9,4,10,14,11,11,8,0,11,2,10,11,15,10,10,1,10,3,9,0,1,11,10,0,4,1,5,0,10,11]

theorem envBound50326 : H12AffineFastState.Bounded env50326 := by
  intro p hp
  have h : env50326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50325_50326 : H12AffineEnvironment.transform 3 11 env50325 = env50326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env50325 == env50326) = true)

theorem identity50326 : scanCanonicalize (H12AffineFastState.compose env50326 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50326 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env50327 : List Nat := [2,4,3,0,0,1,2,4,1,5,0,0,3,0,0,2,1,0,4,1,1,1,1,3,2,0,1,0,1,0,4,1,5,0,1,0]

theorem envBound50327 : H12AffineFastState.Bounded env50327 := by
  intro p hp
  have h : env50327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50326_50327 : H12AffineEnvironment.transform 2 3 env50326 = env50327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50326 == env50327) = true)

def env50328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329897,8328,65,507955,302180,333994,236986,119042,272392,257,98815,90203,63188]

theorem envBound50328 : H12AffineFastState.Bounded env50328 := by
  intro p hp
  have h : env50328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50303_50328 : H12AffineEnvironment.transform 20 4161 env50303 = env50328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50303 == env50328) = true)

theorem identity50328 : scanCanonicalize (H12AffineFastState.compose env50328 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound50328 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,4161,21793,120014,98781,8328,65,215367,5392,102878,236986,119042,41340,257,98815,90203,63188]

theorem envBound50329 : H12AffineFastState.Bounded env50329 := by
  intro p hp
  have h : env50329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50328_50329 : H12AffineEnvironment.transform 17 35188 env50328 = env50329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env50328 == env50329) = true)

def env50330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,131072,10400,1025,8661,4161,21793,95514,73737,8328,65,215367,5392,77834,212078,94422,168,257,73771,90203,22272]

theorem envBound50330 : H12AffineFastState.Bounded env50330 := by
  intro p hp
  have h : env50330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50329_50330 : H12AffineEnvironment.transform 14 8660 env50329 = env50330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env50329 == env50330) = true)

theorem identity50330 : scanCanonicalize (H12AffineFastState.compose env50330 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50331 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1025,8540,4161,21793,95514,73737,8193,65,215367,5392,77834,212078,94303,33,257,73771,90203,22272]

theorem envBound50331 : H12AffineFastState.Bounded env50331 := by
  intro p hp
  have h : env50331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50330_50331 : H12AffineEnvironment.transform 6 9 env50330 = env50331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50330 == env50331) = true)

theorem identity50331 : scanCanonicalize (H12AffineFastState.compose env50331 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound50331 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env50332 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,24860,10281,1025,8540,4161,21793,95514,73737,8193,65,75867,5392,77834,89458,94303,33,257,73771,90203,22272]

theorem envBound50332 : H12AffineFastState.Bounded env50332 := by
  intro p hp
  have h : env50332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50331_50332 : H12AffineEnvironment.transform 16 24860 env50331 = env50332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env50331 == env50332) = true)

theorem identity50332 : scanCanonicalize (H12AffineFastState.compose env50332 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound50332 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env50333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29962,24860,10281,1025,8540,4161,21793,16,21763,8193,65,23889,5392,17664,10360,1365,33,257,21793,5457,22272]

theorem envBound50333 : H12AffineFastState.Bounded env50333 := by
  intro p hp
  have h : env50333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50332_50333 : H12AffineEnvironment.transform 15 29962 env50332 = env50333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env50332 == env50333) = true)

theorem identity50333 : scanCanonicalize (H12AffineFastState.compose env50333 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound50333 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env50334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8541,262,5392,10281,1025,8540,4161,8493,16,8463,8193,65,10589,5392,12556,10360,1365,33,257,8493,5457,8972]

theorem envBound50334 : H12AffineFastState.Bounded env50334 := by
  intro p hp
  have h : env50334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50333_50334 : H12AffineEnvironment.transform 13 13324 env50333 = env50334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env50333 == env50334) = true)

theorem identity50334 : scanCanonicalize (H12AffineFastState.compose env50334 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 6200) := by decide +kernel

theorem selectedBound50334 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env50335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6200,3124,6501,262,5392,4113,1025,6500,4161,6421,16,6455,6201,65,4453,5392,2356,4160,1365,33,257,6421,5457,6964]

theorem envBound50335 : H12AffineFastState.Bounded env50335 := by
  intro p hp
  have h : env50335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50334_50335 : H12AffineEnvironment.transform 12 6200 env50334 = env50335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6200 env50334 == env50335) = true)

theorem identity50335 : scanCanonicalize (H12AffineFastState.compose env50335 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50335 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env50336 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,6200,3124,6453,262,5392,4113,1025,6452,4113,6421,16,6455,6201,17,4405,5392,2356,4112,1285,33,257,6421,5377,6964]

theorem envBound50336 : H12AffineFastState.Bounded env50336 := by
  intro p hp
  have h : env50336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50335_50336 : H12AffineEnvironment.transform 5 16 env50335 = env50336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50335 == env50336) = true)

theorem identity50336 : scanCanonicalize (H12AffineFastState.compose env50336 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50336 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env50337 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,6200,3124,6160,35,5173,4113,1025,6161,4113,6192,16,6162,6201,17,4112,5173,2065,4112,1056,33,36,6192,5156,6673]

theorem envBound50337 : H12AffineFastState.Bounded env50337 := by
  intro p hp
  have h : env50337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50336_50337 : H12AffineEnvironment.transform 7 37 env50336 = env50337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50336 == env50337) = true)

theorem identity50337 : scanCanonicalize (H12AffineFastState.compose env50337 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound50337 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env50338 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,2080,24,3124,48,35,3093,2097,1025,49,2097,16,16,50,25,17,2096,3093,2065,2096,1056,33,36,16,3076,561]

theorem envBound50338 : H12AffineFastState.Bounded env50338 := by
  intro p hp
  have h : env50338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50337_50338 : H12AffineEnvironment.transform 11 2080 env50337 = env50338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env50337 == env50338) = true)

theorem identity50338 : scanCanonicalize (H12AffineFastState.compose env50338 (packedSelected [2,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50338 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env50339 : List Nat := [2,4,8,16,16,16,9,21,512,1024,2048,2064,24,3076,0,19,3093,2049,1025,1,2049,16,16,2,25,17,2048,3093,2065,2048,1040,17,20,16,3076,513]

theorem envBound50339 : H12AffineFastState.Bounded env50339 := by
  intro p hp
  have h : env50339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50338_50339 : H12AffineEnvironment.transform 4 16 env50338 = env50339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50338 == env50339) = true)

theorem identity50339 : scanCanonicalize (H12AffineFastState.compose env50339 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50340 : List Nat := [2,4,8,16,16,16,9,21,512,21,2048,2064,24,2065,0,19,2048,2049,20,1,2049,16,16,2,25,17,2048,2048,2065,2048,5,17,20,16,2065,513]

theorem envBound50340 : H12AffineFastState.Bounded env50340 := by
  intro p hp
  have h : env50340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50339_50340 : H12AffineEnvironment.transform 9 21 env50339 = env50340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50339 == env50340) = true)

theorem identity50340 : scanCanonicalize (H12AffineFastState.compose env50340 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound50340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50341 : List Nat := [2,4,3,16,16,16,2,21,512,21,2048,2064,19,2065,0,19,2048,2049,20,1,2049,16,16,2,18,17,2048,2048,2065,2048,5,17,20,16,2065,513]

theorem envBound50341 : H12AffineFastState.Bounded env50341 := by
  intro p hp
  have h : env50341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50340_50341 : H12AffineEnvironment.transform 2 3 env50340 = env50341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env50340 == env50341) = true)

def env50342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,131072,10401,1025,8660,4161,21793,95515,73736,8328,65,215367,5392,77835,212079,94423,169,257,73770,90203,22273]

theorem envBound50342 : H12AffineFastState.Bounded env50342 := by
  intro p hp
  have h : env50342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50329_50342 : H12AffineEnvironment.transform 14 8661 env50329 = env50342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env50329 == env50342) = true)

theorem identity50342 : scanCanonicalize (H12AffineFastState.compose env50342 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound50342 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,131072,10401,1025,8660,4161,21793,17,21762,8328,65,146509,5392,17665,149861,1501,169,257,21792,5457,22273]

theorem envBound50343 : H12AffineFastState.Bounded env50343 := by
  intro p hp
  have h : env50343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50342_50343 : H12AffineEnvironment.transform 15 29962 env50342 = env50343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env50342 == env50343) = true)

theorem identity50343 : scanCanonicalize (H12AffineFastState.compose env50343 (packedSelected [0,4,6,9,14,16,27] rootPS)) = affineNative (2^(16+1) ^^^ 13540) := by decide +kernel

theorem selectedBound50343 : packedSelected [0,4,6,9,14,16,27] rootPS < 2^1333 := by decide +kernel

def env50344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29962,13540,10401,1025,8660,4161,21793,17,21762,8328,65,2217,5392,17665,32129,1501,169,257,21792,5457,22273]

theorem envBound50344 : H12AffineFastState.Bounded env50344 := by
  intro p hp
  have h : env50344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50343_50344 : H12AffineEnvironment.transform 16 13540 env50343 = env50344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13540 env50343 == env50344) = true)

def env50345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2114912,2444795,2431209,8328,65,2609267,302181,333994,2330107,119043,2373704,257,2199999,2191387,63189]

theorem envBound50345 : H12AffineFastState.Bounded env50345 := by
  intro p hp
  have h : env50345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50302_50345 : H12AffineEnvironment.transform 23 2431209 env50302 = env50345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431209 env50302 == env50345) = true)

def env50346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21792,351675,329897,8328,65,507955,302181,333994,236987,119043,272392,257,98815,90203,63189]

theorem envBound50346 : H12AffineFastState.Bounded env50346 := by
  intro p hp
  have h : env50346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50345_50346 : H12AffineEnvironment.transform 20 4160 env50345 = env50346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50345 == env50346) = true)

theorem identity50346 : scanCanonicalize (H12AffineFastState.compose env50346 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound50346 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,21792,73755,95497,8328,65,245139,57797,91402,236987,119043,21928,257,98815,90203,63189]

theorem envBound50347 : H12AffineFastState.Bounded env50347 := by
  intro p hp
  have h : env50347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50346_50347 : H12AffineEnvironment.transform 17 32160 env50346 = env50347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env50346 == env50347) = true)

def env50348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10400,1025,32769,4160,32,73755,73737,8328,65,245139,46277,77834,236987,99331,168,257,98815,79195,41941]

theorem envBound50348 : H12AffineFastState.Bounded env50348 := by
  intro p hp
  have h : env50348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50347_50348 : H12AffineEnvironment.transform 13 5376 env50347 = env50348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50347 == env50348) = true)

theorem identity50348 : scanCanonicalize (H12AffineFastState.compose env50348 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50348 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1025,32769,4160,32,73755,73737,8193,65,245018,46156,77834,236850,99331,33,257,98678,79195,41820]

theorem envBound50349 : H12AffineFastState.Bounded env50349 := by
  intro p hp
  have h : env50349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50348_50349 : H12AffineEnvironment.transform 6 9 env50348 = env50349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50348 == env50349) = true)

theorem identity50349 : scanCanonicalize (H12AffineFastState.compose env50349 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound50349 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env50350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,13340,10281,1025,32769,4160,32,73755,73737,8193,65,100614,46156,77834,108846,99331,33,257,98678,79195,41820]

theorem envBound50350 : H12AffineFastState.Bounded env50350 := by
  intro p hp
  have h : env50350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50349_50350 : H12AffineEnvironment.transform 16 13340 env50349 = env50350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env50349 == env50350) = true)

theorem identity50350 : scanCanonicalize (H12AffineFastState.compose env50350 (packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50350 : packedSelected [0,1,2,3,6,7,8,10,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env50351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,13340,10281,1025,8541,4160,32,73755,73737,8193,65,75866,5392,77834,67698,75103,33,257,73770,79195,512]

theorem envBound50351 : H12AffineFastState.Bounded env50351 := by
  intro p hp
  have h : env50351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50350_50351 : H12AffineEnvironment.transform 14 8540 env50350 = env50351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50350 == env50351) = true)

theorem identity50351 : scanCanonicalize (H12AffineFastState.compose env50351 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound50351 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50352 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,2420,65536,7220,1,1025,2421,4160,32,67635,67617,2089,65,65650,5392,71714,67698,68983,33,257,67586,73075,512]

theorem envBound50352 : H12AffineFastState.Bounded env50352 := by
  intro p hp
  have h : env50352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50351_50352 : H12AffineEnvironment.transform 12 2088 env50351 = env50352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env50351 == env50352) = true)

theorem identity50352 : scanCanonicalize (H12AffineFastState.compose env50352 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 4114) := by decide +kernel

theorem selectedBound50352 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env50353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2088,5376,2420,4114,7220,1,1025,2421,4160,32,6177,6195,2089,65,4192,5392,2096,6240,7525,33,257,6160,3425,512]

theorem envBound50353 : H12AffineFastState.Bounded env50353 := by
  intro p hp
  have h : env50353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50352_50353 : H12AffineEnvironment.transform 15 4114 env50352 = env50353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4114 env50352 == env50353) = true)

theorem identity50353 : scanCanonicalize (H12AffineFastState.compose env50353 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound50353 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env50354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,33,4096,9,5376,341,4114,5141,1,1025,340,4160,32,4096,4114,8,65,4192,5392,17,4161,5444,33,257,4145,1344,512]

theorem envBound50354 : H12AffineFastState.Bounded env50354 := by
  intro p hp
  have h : env50354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50353_50354 : H12AffineEnvironment.transform 10 33 env50353 = env50354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env50353 == env50354) = true)

theorem identity50354 : scanCanonicalize (H12AffineFastState.compose env50354 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50354 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env50355 : List Nat := [2,4,8,16,32,64,9,256,512,21,33,4096,9,4373,341,4114,4096,1,20,340,4160,32,4096,4114,8,65,4192,4357,17,4161,4433,33,257,4145,341,512]

theorem envBound50355 : H12AffineFastState.Bounded env50355 := by
  intro p hp
  have h : env50355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50354_50355 : H12AffineEnvironment.transform 9 21 env50354 = env50355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50354 == env50355) = true)

theorem identity50355 : scanCanonicalize (H12AffineFastState.compose env50355 (packedSelected [0,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound50355 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env50356 : List Nat := [2,4,8,16,32,64,9,256,512,21,33,309,9,32,341,295,309,1,20,340,373,32,309,295,8,65,341,48,17,372,100,33,257,260,341,512]

theorem envBound50356 : H12AffineFastState.Bounded env50356 := by
  intro p hp
  have h : env50356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50355_50356 : H12AffineEnvironment.transform 11 309 env50355 = env50356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env50355 == env50356) = true)

theorem identity50356 : scanCanonicalize (H12AffineFastState.compose env50356 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound50356 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env50357 : List Nat := [2,4,8,16,32,64,9,85,512,21,33,96,9,32,0,114,96,1,20,1,32,32,96,114,8,65,0,48,17,33,100,33,84,81,0,512]

theorem envBound50357 : H12AffineFastState.Bounded env50357 := by
  intro p hp
  have h : env50357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50356_50357 : H12AffineEnvironment.transform 7 85 env50356 = env50357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env50356 == env50357) = true)

theorem identity50357 : scanCanonicalize (H12AffineFastState.compose env50357 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound50357 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50358 : List Nat := [2,4,8,16,32,49,9,36,512,21,33,17,9,32,0,3,17,1,20,1,32,32,17,3,8,48,0,48,17,33,21,33,37,32,0,512]

theorem envBound50358 : H12AffineFastState.Bounded env50358 := by
  intro p hp
  have h : env50358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50357_50358 : H12AffineEnvironment.transform 5 49 env50357 = env50358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env50357 == env50358) = true)

theorem identity50358 : scanCanonicalize (H12AffineFastState.compose env50358 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50358 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50359 : List Nat := [2,4,8,16,32,49,9,36,1,21,33,17,9,32,0,3,17,1,20,1,32,32,17,3,8,48,0,48,17,33,21,33,37,32,0,1]

theorem envBound50359 : H12AffineFastState.Bounded env50359 := by
  intro p hp
  have h : env50359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50358_50359 : H12AffineEnvironment.transform 8 1 env50358 = env50359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50358 == env50359) = true)

theorem identity50359 : scanCanonicalize (H12AffineFastState.compose env50359 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50359 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env50360 : List Nat := [2,4,8,16,16,1,9,20,1,21,17,17,9,16,0,3,17,1,20,1,16,16,17,3,8,0,0,0,17,17,21,17,21,16,0,1]

theorem envBound50360 : H12AffineFastState.Bounded env50360 := by
  intro p hp
  have h : env50360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50359_50360 : H12AffineEnvironment.transform 4 16 env50359 = env50360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50359 == env50360) = true)

theorem identity50360 : scanCanonicalize (H12AffineFastState.compose env50360 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50360 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50361 : List Nat := [2,4,8,0,0,1,9,4,1,5,1,1,9,0,0,3,1,1,4,1,0,0,1,3,8,0,0,0,1,1,5,1,5,0,0,1]

theorem envBound50361 : H12AffineFastState.Bounded env50361 := by
  intro p hp
  have h : env50361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50360_50361 : H12AffineEnvironment.transform 3 0 env50360 = env50361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50360 == env50361) = true)

theorem identity50361 : scanCanonicalize (H12AffineFastState.compose env50361 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound50361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50362 : List Nat := [2,1,8,0,0,1,9,1,1,0,1,1,9,0,0,3,1,1,1,1,0,0,1,3,8,0,0,0,1,1,0,1,0,0,0,1]

theorem envBound50362 : H12AffineFastState.Bounded env50362 := by
  intro p hp
  have h : env50362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50361_50362 : H12AffineEnvironment.transform 1 1 env50361 = env50362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env50361 == env50362) = true)

theorem identity50362 : scanCanonicalize (H12AffineFastState.compose env50362 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound50362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50363 : List Nat := [2,1,0,0,0,1,1,1,1,0,1,1,1,0,0,3,1,1,1,1,0,0,1,3,0,0,0,0,1,1,0,1,0,0,0,1]

theorem envBound50363 : H12AffineFastState.Bounded env50363 := by
  intro p hp
  have h : env50363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50362_50363 : H12AffineEnvironment.transform 2 0 env50362 = env50363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env50362 == env50363) = true)

theorem identity50363 : scanCanonicalize (H12AffineFastState.compose env50363 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound50363 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env50364 : List Nat := [1,1,0,0,0,1,1,1,1,0,1,1,1,0,0,0,1,1,1,1,0,0,1,0,0,0,0,0,1,1,0,1,0,0,0,1]

theorem envBound50364 : H12AffineFastState.Bounded env50364 := by
  intro p hp
  have h : env50364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50363_50364 : H12AffineEnvironment.transform 0 1 env50363 = env50364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env50363 == env50364) = true)

def env50365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10401,1025,32769,4160,33,73755,73736,8328,65,245139,46276,77835,236987,99330,169,257,98815,79194,41940]

theorem envBound50365 : H12AffineFastState.Bounded env50365 := by
  intro p hp
  have h : env50365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50347_50365 : H12AffineEnvironment.transform 13 5377 env50347 = env50365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50347 == env50365) = true)

theorem identity50365 : scanCanonicalize (H12AffineFastState.compose env50365 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound50365 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10401,1025,32769,4160,33,73755,73736,8328,65,108675,46276,77835,100523,99330,169,257,98815,79194,41940]

theorem envBound50366 : H12AffineFastState.Bounded env50366 := by
  intro p hp
  have h : env50366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50365_50366 : H12AffineEnvironment.transform 16 5392 env50365 = env50366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env50365 == env50366) = true)

theorem identity50366 : scanCanonicalize (H12AffineFastState.compose env50366 (packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50366 : packedSelected [3,5,8,10,12,15,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env50367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,5392,10401,1025,8541,4160,33,73755,73736,8328,65,68063,5528,77835,76279,75102,169,257,73891,79194,648]

theorem envBound50367 : H12AffineFastState.Bounded env50367 := by
  intro p hp
  have h : env50367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50366_50367 : H12AffineEnvironment.transform 14 8540 env50366 = env50367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50366 == env50367) = true)

theorem identity50367 : scanCanonicalize (H12AffineFastState.compose env50367 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound50367 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8323,5392,10401,1025,8541,4160,33,152,139,8328,65,10588,5528,4232,2420,1501,169,257,32,5593,648]

theorem envBound50368 : H12AffineFastState.Bounded env50368 := by
  intro p hp
  have h : env50368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50367_50368 : H12AffineEnvironment.transform 15 8323 env50367 = env50368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env50367 == env50368) = true)

theorem identity50368 : scanCanonicalize (H12AffineFastState.compose env50368 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50368 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50369 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8202,5392,10280,1025,8541,4160,33,17,2,8193,65,10588,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound50369 : H12AffineFastState.Bounded env50369 := by
  intro p hp
  have h : env50369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50368_50369 : H12AffineEnvironment.transform 6 9 env50368 = env50369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50368 == env50369) = true)

theorem identity50369 : scanCanonicalize (H12AffineFastState.compose env50369 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50369 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,263,5392,2341,1025,80,4160,33,17,2,268,65,2129,5393,4097,2420,1364,32,257,32,5456,513]

theorem envBound50370 : H12AffineFastState.Bounded env50370 := by
  intro p hp
  have h : env50370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50369_50370 : H12AffineEnvironment.transform 12 269 env50369 = env50370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50369 == env50370) = true)

theorem identity50370 : scanCanonicalize (H12AffineFastState.compose env50370 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound50370 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env50371 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,269,4145,81,263,4128,2341,305,80,4160,33,17,2,268,65,2129,4129,4097,2420,100,32,257,32,4192,513]

theorem envBound50371 : H12AffineFastState.Bounded env50371 := by
  intro p hp
  have h : env50371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50370_50371 : H12AffineEnvironment.transform 9 304 env50370 = env50371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env50370 == env50371) = true)

theorem identity50371 : scanCanonicalize (H12AffineFastState.compose env50371 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound50371 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50372 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,772,269,821,81,263,804,2341,305,80,836,33,17,2,268,65,2129,805,773,2420,100,32,257,32,868,513]

theorem envBound50372 : H12AffineFastState.Bounded env50372 := by
  intro p hp
  have h : env50372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50371_50372 : H12AffineEnvironment.transform 11 772 env50371 = env50372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env50371 == env50372) = true)

theorem identity50372 : scanCanonicalize (H12AffineFastState.compose env50372 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50372 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env50373 : List Nat := [2,4,8,16,32,16,9,256,512,304,2048,772,269,821,1,263,804,2341,305,0,788,33,17,2,268,17,2049,805,773,2340,52,32,257,32,820,513]

theorem envBound50373 : H12AffineFastState.Bounded env50373 := by
  intro p hp
  have h : env50373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50372_50373 : H12AffineEnvironment.transform 5 16 env50372 = env50373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50372 == env50373) = true)

theorem identity50373 : scanCanonicalize (H12AffineFastState.compose env50373 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50374 : List Nat := [2,4,8,16,32,16,9,4,512,52,2048,512,9,561,1,3,544,2081,53,0,528,33,17,2,8,17,2049,545,513,2080,52,32,5,32,560,513]

theorem envBound50374 : H12AffineFastState.Bounded env50374 := by
  intro p hp
  have h : env50374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50373_50374 : H12AffineEnvironment.transform 7 4 env50373 = env50374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50373 == env50374) = true)

theorem identity50374 : scanCanonicalize (H12AffineFastState.compose env50374 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound50374 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50375 : List Nat := [2,4,8,16,32,16,9,4,512,52,17,512,9,561,1,3,544,48,53,0,528,33,17,2,8,17,16,545,513,49,52,32,5,32,560,513]

theorem envBound50375 : H12AffineFastState.Bounded env50375 := by
  intro p hp
  have h : env50375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50374_50375 : H12AffineEnvironment.transform 10 17 env50374 = env50375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env50374 == env50375) = true)

theorem identity50375 : scanCanonicalize (H12AffineFastState.compose env50375 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound50375 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50376 : List Nat := [2,4,8,16,32,16,9,4,48,52,17,48,9,1,1,3,16,48,53,0,32,33,17,2,8,17,16,17,49,49,52,32,5,32,0,49]

theorem envBound50376 : H12AffineFastState.Bounded env50376 := by
  intro p hp
  have h : env50376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50375_50376 : H12AffineEnvironment.transform 8 48 env50375 = env50376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50375 == env50376) = true)

theorem identity50376 : scanCanonicalize (H12AffineFastState.compose env50376 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50376 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env50377 : List Nat := [2,4,8,16,0,16,9,4,16,20,17,16,9,1,1,3,16,16,21,0,0,1,17,2,8,17,16,17,17,17,20,0,5,0,0,17]

theorem envBound50377 : H12AffineFastState.Bounded env50377 := by
  intro p hp
  have h : env50377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50376_50377 : H12AffineEnvironment.transform 4 0 env50376 = env50377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50376 == env50377) = true)

theorem identity50377 : scanCanonicalize (H12AffineFastState.compose env50377 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50378 : List Nat := [2,4,8,0,0,0,9,4,0,4,1,0,9,1,1,3,0,0,5,0,0,1,1,2,8,1,0,1,1,1,4,0,5,0,0,1]

theorem envBound50378 : H12AffineFastState.Bounded env50378 := by
  intro p hp
  have h : env50378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50377_50378 : H12AffineEnvironment.transform 3 0 env50377 = env50378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50377 == env50378) = true)

def env50379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21793,351674,329896,8328,65,507954,302181,333994,236986,119043,272393,257,98814,90202,63189]

theorem envBound50379 : H12AffineFastState.Bounded env50379 := by
  intro p hp
  have h : env50379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50345_50379 : H12AffineEnvironment.transform 20 4161 env50345 = env50379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50345 == env50379) = true)

def env50380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1025,32769,4161,21793,95514,73736,8328,65,256146,46277,77834,236986,119043,169,257,98814,90202,63189]

theorem envBound50380 : H12AffineFastState.Bounded env50380 := by
  intro p hp
  have h : env50380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50379_50380 : H12AffineEnvironment.transform 17 10400 env50379 = env50380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env50379 == env50380) = true)

theorem identity50380 : scanCanonicalize (H12AffineFastState.compose env50380 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound50380 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env50381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1025,29909,4161,21793,95514,73736,8328,65,203846,16401,77834,223598,75223,169,257,95530,90202,513]

theorem envBound50381 : H12AffineFastState.Bounded env50381 := by
  intro p hp
  have h : env50381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50380_50381 : H12AffineEnvironment.transform 14 29908 env50380 = env50381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env50380 == env50381) = true)

def env50382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10400,1025,8661,4161,33,73754,73736,8328,65,203846,5393,77834,212078,75223,169,257,73770,79194,513]

theorem envBound50382 : H12AffineFastState.Bounded env50382 := by
  intro p hp
  have h : env50382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50381_50382 : H12AffineEnvironment.transform 13 5376 env50381 = env50382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env50381 == env50382) = true)

theorem identity50382 : scanCanonicalize (H12AffineFastState.compose env50382 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50382 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10281,1025,8540,4161,33,73754,73736,8193,65,203846,5393,77834,212078,75102,32,257,73770,79194,513]

theorem envBound50383 : H12AffineFastState.Bounded env50383 := by
  intro p hp
  have h : env50383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50382_50383 : H12AffineEnvironment.transform 6 9 env50382 = env50383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50382 == env50383) = true)

theorem identity50383 : scanCanonicalize (H12AffineFastState.compose env50383 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50383 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env50384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10281,1025,8540,4161,33,16,2,8193,65,146508,5393,4096,138340,1364,32,257,32,5456,513]

theorem envBound50384 : H12AffineFastState.Bounded env50384 := by
  intro p hp
  have h : env50384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50383_50384 : H12AffineEnvironment.transform 15 8202 env50383 = env50384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50383 == env50384) = true)

theorem identity50384 : scanCanonicalize (H12AffineFastState.compose env50384 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound50384 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13388,10281,1025,8540,4161,33,16,2,8193,65,2048,5393,4096,10280,1364,32,257,32,5456,513]

theorem envBound50385 : H12AffineFastState.Bounded env50385 := by
  intro p hp
  have h : env50385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50384_50385 : H12AffineEnvironment.transform 16 13388 env50384 = env50385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env50384 == env50385) = true)

theorem identity50385 : scanCanonicalize (H12AffineFastState.compose env50385 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound50385 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,292,115,5173,2128,1025,293,4161,33,16,2,120,65,2048,5393,4096,2129,1364,32,257,32,5456,513]

theorem envBound50386 : H12AffineFastState.Bounded env50386 := by
  intro p hp
  have h : env50386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50385_50386 : H12AffineEnvironment.transform 12 121 env50385 = env50386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env50385 == env50386) = true)

theorem identity50386 : scanCanonicalize (H12AffineFastState.compose env50386 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound50386 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,121,1297,292,115,1060,2128,1025,293,80,33,16,2,120,65,2048,1280,17,2129,1364,32,257,32,1345,513]

theorem envBound50387 : H12AffineFastState.Bounded env50387 := by
  intro p hp
  have h : env50387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50386_50387 : H12AffineEnvironment.transform 11 17 env50386 = env50387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env50386 == env50387) = true)

def env50388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,4161,32,73755,73736,8328,65,203846,5392,77834,212079,75223,169,257,73771,79195,513]

theorem envBound50388 : H12AffineFastState.Bounded env50388 := by
  intro p hp
  have h : env50388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50381_50388 : H12AffineEnvironment.transform 13 5377 env50381 = env50388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50381 == env50388) = true)

theorem identity50388 : scanCanonicalize (H12AffineFastState.compose env50388 (packedSelected [0,3,5,7,12,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound50388 : packedSelected [0,3,5,7,12,14,18,19] rootPS < 2^1333 := by decide +kernel

def env50389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,13389,10400,1025,8660,4161,32,73755,73736,8328,65,75787,5392,77834,67618,75223,169,257,73771,79195,513]

theorem envBound50389 : H12AffineFastState.Bounded env50389 := by
  intro p hp
  have h : env50389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50388_50389 : H12AffineEnvironment.transform 16 13389 env50388 = env50389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env50388 == env50389) = true)

theorem identity50389 : scanCanonicalize (H12AffineFastState.compose env50389 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound50389 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8403,13389,10400,1025,8660,4161,32,200,219,8328,65,2264,5392,4313,10481,1284,169,257,248,5512,513]

theorem envBound50390 : H12AffineFastState.Bounded env50390 := by
  intro p hp
  have h : env50390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50389_50390 : H12AffineEnvironment.transform 15 8403 env50389 = env50390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env50389 == env50390) = true)

theorem identity50390 : scanCanonicalize (H12AffineFastState.compose env50390 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50390 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50391 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8322,13340,10400,1025,8581,4112,32,153,138,8328,16,2185,5392,4232,10400,1284,169,257,169,5512,513]

theorem envBound50391 : H12AffineFastState.Bounded env50391 := by
  intro p hp
  have h : env50391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50390_50391 : H12AffineEnvironment.transform 5 17 env50390 = env50391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50390 == env50391) = true)

theorem identity50391 : scanCanonicalize (H12AffineFastState.compose env50391 (packedSelected [1,2,4,6,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 6548) := by decide +kernel

theorem selectedBound50391 : packedSelected [1,2,4,6,8,9,10] rootPS < 2^1333 := by decide +kernel

def env50392 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6548,5377,6160,6422,3464,4404,1025,6161,4112,32,153,138,6428,16,2185,5392,4232,4404,1284,169,257,169,5512,513]

theorem envBound50392 : H12AffineFastState.Bounded env50392 := by
  intro p hp
  have h : env50392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50391_50392 : H12AffineEnvironment.transform 12 6548 env50391 = env50392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6548 env50391 == env50392) = true)

theorem identity50392 : scanCanonicalize (H12AffineFastState.compose env50392 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound50392 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env50393 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,6429,5377,6160,6422,3329,4404,1025,6161,4112,32,16,3,6428,16,2048,5392,4097,4404,1284,32,257,32,5377,513]

theorem envBound50393 : H12AffineFastState.Bounded env50393 := by
  intro p hp
  have h : env50393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50392_50393 : H12AffineEnvironment.transform 6 9 env50392 = env50393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50392 == env50393) = true)

theorem identity50393 : scanCanonicalize (H12AffineFastState.compose env50393 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound50393 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50394 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2064,269,3345,0,262,3329,2340,1025,1,2048,32,16,3,268,16,2048,3328,2065,2340,1284,32,257,32,3345,513]

theorem envBound50394 : H12AffineFastState.Bounded env50394 := by
  intro p hp
  have h : env50394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50393_50394 : H12AffineEnvironment.transform 11 2064 env50393 = env50394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env50393 == env50394) = true)

theorem identity50394 : scanCanonicalize (H12AffineFastState.compose env50394 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50395 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,17,269,1296,0,262,1280,293,1025,1,1,32,16,3,268,16,1,1281,16,293,1284,32,257,32,1296,513]

theorem envBound50395 : H12AffineFastState.Bounded env50395 := by
  intro p hp
  have h : env50395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50394_50395 : H12AffineEnvironment.transform 10 1 env50394 = env50395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50394 == env50395) = true)

theorem identity50395 : scanCanonicalize (H12AffineFastState.compose env50395 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50395 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50396 : List Nat := [2,4,8,16,32,17,9,256,512,273,1,17,269,1,0,262,17,293,272,1,1,32,16,3,268,16,1,16,16,293,21,32,257,32,1,513]

theorem envBound50396 : H12AffineFastState.Bounded env50396 := by
  intro p hp
  have h : env50396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50395_50396 : H12AffineEnvironment.transform 9 273 env50395 = env50396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50395 == env50396) = true)

theorem identity50396 : scanCanonicalize (H12AffineFastState.compose env50396 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50396 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50397 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,41,1,0,34,17,1,52,1,1,32,16,3,40,16,1,16,16,1,21,32,37,32,1,513]

theorem envBound50397 : H12AffineFastState.Bounded env50397 := by
  intro p hp
  have h : env50397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50396_50397 : H12AffineEnvironment.transform 7 36 env50396 = env50397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50396 == env50397) = true)

theorem identity50397 : scanCanonicalize (H12AffineFastState.compose env50397 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50398 : List Nat := [2,4,8,16,32,17,9,36,16,53,1,17,41,1,0,34,17,1,52,1,1,32,16,3,40,16,1,16,16,1,21,32,37,32,1,17]

theorem envBound50398 : H12AffineFastState.Bounded env50398 := by
  intro p hp
  have h : env50398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50397_50398 : H12AffineEnvironment.transform 8 16 env50397 = env50398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50397 == env50398) = true)

theorem identity50398 : scanCanonicalize (H12AffineFastState.compose env50398 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound50398 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50399 : List Nat := [2,4,8,16,11,17,9,15,16,30,1,17,2,1,0,9,17,1,31,1,1,11,16,3,3,16,1,16,16,1,21,11,14,11,1,17]

theorem envBound50399 : H12AffineFastState.Bounded env50399 := by
  intro p hp
  have h : env50399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50398_50399 : H12AffineEnvironment.transform 4 11 env50398 = env50399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env50398 == env50399) = true)

def env50400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1025,32769,4161,21793,95515,73737,8328,65,256147,46276,77835,236986,119043,168,257,98814,90202,63189]

theorem envBound50400 : H12AffineFastState.Bounded env50400 := by
  intro p hp
  have h : env50400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50379_50400 : H12AffineEnvironment.transform 17 10401 env50379 = env50400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env50379 == env50400) = true)

theorem identity50400 : scanCanonicalize (H12AffineFastState.compose env50400 (packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound50400 : packedSelected [0,3,5,8,9,10,11,12,14,15,18,22,23,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env50401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,5529,10401,1025,32769,4161,21793,95515,73737,8328,65,130314,46276,77835,100387,119043,168,257,98814,90202,63189]

theorem envBound50401 : H12AffineFastState.Bounded env50401 := by
  intro p hp
  have h : env50401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50400_50401 : H12AffineEnvironment.transform 16 5529 env50400 = env50401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env50400 == env50401) = true)

theorem identity50401 : scanCanonicalize (H12AffineFastState.compose env50401 (packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50401 : packedSelected [0,1,3,4,7,10,11,16,18,19,20,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env50402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,5529,10401,1025,8541,4161,21793,95515,73737,8328,65,89174,5528,77835,76159,94303,168,257,73890,90202,22409]

theorem envBound50402 : H12AffineFastState.Bounded env50402 := by
  intro p hp
  have h : env50402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50401_50402 : H12AffineEnvironment.transform 14 8540 env50401 = env50402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50401 == env50402) = true)

theorem identity50402 : scanCanonicalize (H12AffineFastState.compose env50402 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound50402 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30083,5529,10401,1025,8541,4161,21793,152,21898,8328,65,10709,5528,17800,23804,1500,168,257,21793,5593,22409]

theorem envBound50403 : H12AffineFastState.Bounded env50403 := by
  intro p hp
  have h : env50403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50402_50403 : H12AffineEnvironment.transform 15 30083 env50402 = env50403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env50402 == env50403) = true)

theorem identity50403 : scanCanonicalize (H12AffineFastState.compose env50403 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50403 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50404 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,5393,10281,1025,8541,4161,21793,16,21762,8192,65,10589,5392,17664,23668,1364,32,257,21793,5457,22273]

theorem envBound50404 : H12AffineFastState.Bounded env50404 := by
  intro p hp
  have h : env50404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50403_50404 : H12AffineEnvironment.transform 6 8 env50403 = env50404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50403 == env50404) = true)

theorem identity50404 : scanCanonicalize (H12AffineFastState.compose env50404 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound50404 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env50405 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13609,8540,34,5393,10281,1025,8541,4161,8200,16,8235,8192,65,10589,5392,12329,10589,1364,32,257,8200,5457,8744]

theorem envBound50405 : H12AffineFastState.Bounded env50405 := by
  intro p hp
  have h : env50405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50404_50405 : H12AffineEnvironment.transform 13 13609 env50404 = env50405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env50404 == env50405) = true)

theorem identity50405 : scanCanonicalize (H12AffineFastState.compose env50405 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound50405 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env50406 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,8192,11357,8540,34,3173,10281,1025,8541,2357,8200,16,8235,8192,65,10589,3172,10589,10589,1364,32,257,8200,3109,8744]

theorem envBound50406 : H12AffineFastState.Bounded env50406 := by
  intro p hp
  have h : env50406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50405_50406 : H12AffineEnvironment.transform 11 2420 env50405 = env50406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env50405 == env50406) = true)

theorem identity50406 : scanCanonicalize (H12AffineFastState.compose env50406 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50406 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env50407 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2420,349,3328,1,34,3173,2420,1025,0,2357,341,16,374,349,65,2048,3172,2048,2048,1364,32,257,341,3109,885]

theorem envBound50407 : H12AffineFastState.Bounded env50407 := by
  intro p hp
  have h : env50407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50406_50407 : H12AffineEnvironment.transform 12 349 env50406 = env50407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50406 == env50407) = true)

theorem identity50407 : scanCanonicalize (H12AffineFastState.compose env50407 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound50407 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50408 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2049,40,3189,1,34,3173,2049,1025,0,2112,32,16,3,40,65,2048,3172,2048,2048,1057,32,116,32,3109,512]

theorem envBound50408 : H12AffineFastState.Bounded env50408 := by
  intro p hp
  have h : env50408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50407_50408 : H12AffineEnvironment.transform 7 117 env50407 = env50408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env50407 == env50408) = true)

theorem identity50408 : scanCanonicalize (H12AffineFastState.compose env50408 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound50408 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50409 : List Nat := [2,4,8,16,32,64,8,117,512,1024,608,609,40,1557,1,34,1541,609,1025,0,544,32,16,3,40,65,608,1540,608,608,1057,32,116,32,1605,512]

theorem envBound50409 : H12AffineFastState.Bounded env50409 := by
  intro p hp
  have h : env50409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50408_50409 : H12AffineEnvironment.transform 10 608 env50408 = env50409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env50408 == env50409) = true)

theorem identity50409 : scanCanonicalize (H12AffineFastState.compose env50409 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50409 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1