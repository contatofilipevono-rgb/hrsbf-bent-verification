import H12CloudChart1Data084

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound21504 : packedSelected [3,5,8,11,17,18,23,28,32] rootPS < 2^1333 := by decide +kernel

def env21505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,24908,35325,1025,32769,12572,41341,8524,41431,8328,64,10589,13389,17664,2557,9345,29821,257,21792,46213,9052]

theorem envBound21505 : H12AffineFastState.Bounded env21505 := by
  intro p hp
  have h : env21505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21504_21505 : H12AffineEnvironment.transform 17 35325 env21504 = env21505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env21504 == env21505) = true)

theorem identity21505 : scanCanonicalize (H12AffineFastState.compose env21505 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound21505 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,479,16537,35325,1025,32769,4297,32936,153,32770,349,64,2184,5528,17664,2557,1364,21928,257,21792,38224,649]

theorem envBound21506 : H12AffineFastState.Bounded env21506 := by
  intro p hp
  have h : env21506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21505_21506 : H12AffineEnvironment.transform 12 469 env21505 = env21506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env21505 == env21506) = true)

theorem identity21506 : scanCanonicalize (H12AffineFastState.compose env21506 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound21506 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env21507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,479,16537,23804,1025,21760,4297,21929,153,21763,349,64,2184,5528,17664,2557,1364,21928,257,21792,16465,649]

theorem envBound21507 : H12AffineFastState.Bounded env21507 := by
  intro p hp
  have h : env21507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21506_21507 : H12AffineEnvironment.transform 14 21761 env21506 = env21507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env21506 == env21507) = true)

theorem identity21507 : scanCanonicalize (H12AffineFastState.compose env21507 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21507 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,479,5392,2421,1025,137,4297,32,153,138,349,64,2184,5528,4233,2557,1364,33,257,169,5592,649]

theorem envBound21508 : H12AffineFastState.Bounded env21508 := by
  intro p hp
  have h : env21508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21507_21508 : H12AffineEnvironment.transform 13 5513 env21507 = env21508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21507 == env21508) = true)

theorem identity21508 : scanCanonicalize (H12AffineFastState.compose env21508 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound21508 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21509 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,41,5237,136,35,5356,2185,1025,137,4297,32,153,138,161,64,2184,5220,4233,2049,1192,33,253,169,5156,649]

theorem envBound21509 : H12AffineFastState.Bounded env21509 := by
  intro p hp
  have h : env21509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21508_21509 : H12AffineEnvironment.transform 7 252 env21508 = env21509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env21508 == env21509) = true)

theorem identity21509 : scanCanonicalize (H12AffineFastState.compose env21509 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound21509 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21510 : List Nat := [2,4,8,16,32,64,128,252,512,1024,217,4096,41,5237,136,35,5356,80,1025,137,4297,32,153,138,161,64,81,5220,4233,216,1192,33,253,169,5156,649]

theorem envBound21510 : H12AffineFastState.Bounded env21510 := by
  intro p hp
  have h : env21510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21509_21510 : H12AffineEnvironment.transform 10 217 env21509 = env21510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env21509 == env21510) = true)

theorem identity21510 : scanCanonicalize (H12AffineFastState.compose env21510 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21510 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env21511 : List Nat := [2,4,8,16,32,17,128,173,512,1024,136,4096,41,5156,136,35,5309,1,1025,137,4248,32,153,138,161,17,0,5173,4233,137,1192,33,172,169,5156,649]

theorem envBound21511 : H12AffineFastState.Bounded env21511 := by
  intro p hp
  have h : env21511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21510_21511 : H12AffineEnvironment.transform 5 17 env21510 = env21511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21510 == env21511) = true)

theorem identity21511 : scanCanonicalize (H12AffineFastState.compose env21511 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound21511 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env21512 : List Nat := [2,4,8,16,32,17,128,173,512,1024,136,153,41,1213,136,35,1060,1,1025,137,1,32,153,138,161,17,0,1196,16,137,1192,33,172,169,1213,649]

theorem envBound21512 : H12AffineFastState.Bounded env21512 := by
  intro p hp
  have h : env21512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21511_21512 : H12AffineEnvironment.transform 11 153 env21511 = env21512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env21511 == env21512) = true)

theorem identity21512 : scanCanonicalize (H12AffineFastState.compose env21512 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21512 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env21513 : List Nat := [2,4,8,16,32,17,128,173,512,21,136,153,41,168,136,35,49,1,20,137,1,32,153,138,161,17,0,185,16,137,189,33,172,169,168,649]

theorem envBound21513 : H12AffineFastState.Bounded env21513 := by
  intro p hp
  have h : env21513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21512_21513 : H12AffineEnvironment.transform 9 21 env21512 = env21513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21512 == env21513) = true)

def env21514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2177098,2098513,17664,2461974,2102685,2411677,257,21792,46213,2175562]

theorem envBound21514 : H12AffineFastState.Bounded env21514 := by
  intro p hp
  have h : env21514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21501_21514 : H12AffineEnvironment.transform 21 272513 env21501 = env21514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21501 == env21514) = true)

theorem identity21514 : scanCanonicalize (H12AffineFastState.compose env21514 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound21514 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272513,73755,98781,8328,64,2049,79130,17664,303453,75222,392406,257,21792,46213,513]

theorem envBound21515 : H12AffineFastState.Bounded env21515 := by
  intro p hp
  have h : env21515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21514_21515 : H12AffineEnvironment.transform 20 77899 env21514 = env21515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env21514 == env21515) = true)

theorem identity21515 : scanCanonicalize (H12AffineFastState.compose env21515 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound21515 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env21516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1025,32769,77899,73891,73755,98781,8328,64,2049,79130,17664,108927,75222,62708,257,21792,46213,513]

theorem envBound21516 : H12AffineFastState.Bounded env21516 := by
  intro p hp
  have h : env21516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21515_21516 : H12AffineEnvironment.transform 17 67618 env21515 = env21516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env21515 == env21516) = true)

theorem identity21516 : scanCanonicalize (H12AffineFastState.compose env21516 (packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21516 : packedSelected [1,3,7,14,15,16,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env21517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,66047,65863,98781,468,64,2049,70726,17664,100387,66698,54696,257,21792,38361,513]

theorem envBound21517 : H12AffineFastState.Bounded env21517 := by
  intro p hp
  have h : env21517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21516_21517 : H12AffineEnvironment.transform 12 348 env21516 = env21517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21516 == env21517) = true)

def env21518 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,65911,65863,98645,348,64,2049,70726,17664,100387,66562,54560,257,21792,38225,513]

theorem envBound21518 : H12AffineFastState.Bounded env21518 := by
  intro p hp
  have h : env21518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21517_21518 : H12AffineEnvironment.transform 6 8 env21517 = env21518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21517 == env21518) = true)

theorem identity21518 : scanCanonicalize (H12AffineFastState.compose env21518 (packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound21518 : packedSelected [1,2,3,4,6,7,8,9,10,12,15,24,27] rootPS < 2^1333 := by decide +kernel

def env21519 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33030,49216,35108,1025,32769,36881,32881,32833,83,348,64,2049,38208,17664,2341,34052,54560,257,21792,38225,513]

theorem envBound21519 : H12AffineFastState.Bounded env21519 := by
  intro p hp
  have h : env21519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21518_21519 : H12AffineEnvironment.transform 15 33030 env21518 = env21519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env21518 == env21519) = true)

theorem identity21519 : scanCanonicalize (H12AffineFastState.compose env21519 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21519 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env21520 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,32768,33030,38160,35108,1025,32769,36881,32881,32833,83,348,64,2049,38208,4176,2341,34052,32880,257,112,38225,513]

theorem envBound21520 : H12AffineFastState.Bounded env21520 := by
  intro p hp
  have h : env21520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21519_21520 : H12AffineEnvironment.transform 13 5456 env21519 = env21520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21519 == env21520) = true)

theorem identity21520 : scanCanonicalize (H12AffineFastState.compose env21520 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21520 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21521 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,32768,33030,38160,35108,1025,32769,36881,32800,32784,2,269,17,2049,38161,4097,2341,34052,32801,257,33,38144,513]

theorem envBound21521 : H12AffineFastState.Bounded env21521 := by
  intro p hp
  have h : env21521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21520_21521 : H12AffineEnvironment.transform 5 17 env21520 = env21521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21520 == env21521) = true)

theorem identity21521 : scanCanonicalize (H12AffineFastState.compose env21521 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound21521 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env21522 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,269,5377,32768,33030,38160,33844,1025,32769,36881,32800,32784,2,269,17,1297,38161,4097,1077,34052,32801,257,33,38144,513]

theorem envBound21522 : H12AffineFastState.Bounded env21522 := by
  intro p hp
  have h : env21522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21521_21522 : H12AffineEnvironment.transform 10 1296 env21521 = env21522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env21521 == env21522) = true)

theorem identity21522 : scanCanonicalize (H12AffineFastState.compose env21522 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21522 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21523 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1296,4096,269,5377,0,262,5392,1076,1025,1,4113,32,16,2,269,17,1297,5393,4097,1077,1284,33,257,33,5376,513]

theorem envBound21523 : H12AffineFastState.Bounded env21523 := by
  intro p hp
  have h : env21523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21522_21523 : H12AffineEnvironment.transform 14 0 env21522 = env21523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21522 == env21523) = true)

theorem identity21523 : scanCanonicalize (H12AffineFastState.compose env21523 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21523 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21524 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,4096,41,5157,0,34,5172,1076,1025,1,4113,32,16,2,41,17,1077,5173,4097,1077,1056,33,37,33,5156,513]

theorem envBound21524 : H12AffineFastState.Bounded env21524 := by
  intro p hp
  have h : env21524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21523_21524 : H12AffineEnvironment.transform 7 36 env21523 = env21524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21523 == env21524) = true)

theorem identity21524 : scanCanonicalize (H12AffineFastState.compose env21524 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21524 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21525 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,4096,41,4113,0,34,4096,0,53,1,4113,32,16,2,41,17,1,4097,4097,1,20,33,37,33,4112,513]

theorem envBound21525 : H12AffineFastState.Bounded env21525 := by
  intro p hp
  have h : env21525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21524_21525 : H12AffineEnvironment.transform 9 52 env21524 = env21525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21524 == env21525) = true)

theorem identity21525 : scanCanonicalize (H12AffineFastState.compose env21525 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21525 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21526 : List Nat := [2,4,8,16,32,17,8,36,1,52,0,4096,41,4113,0,34,4096,0,53,1,4113,32,16,2,41,17,1,4097,4097,1,20,33,37,33,4112,0]

theorem envBound21526 : H12AffineFastState.Bounded env21526 := by
  intro p hp
  have h : env21526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21525_21526 : H12AffineEnvironment.transform 8 1 env21525 = env21526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21525 == env21526) = true)

theorem identity21526 : scanCanonicalize (H12AffineFastState.compose env21526 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 11) := by decide +kernel

theorem selectedBound21526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21527 : List Nat := [2,4,8,16,32,17,8,36,1,52,0,11,41,26,0,34,11,0,53,1,26,32,16,2,41,17,1,10,10,1,20,33,37,33,27,0]

theorem envBound21527 : H12AffineFastState.Bounded env21527 := by
  intro p hp
  have h : env21527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21526_21527 : H12AffineEnvironment.transform 11 11 env21526 = env21527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 11 env21526 == env21527) = true)

theorem identity21527 : scanCanonicalize (H12AffineFastState.compose env21527 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound21527 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21528 : List Nat := [2,4,8,10,32,11,8,36,1,46,0,11,41,0,0,34,11,0,47,1,0,32,10,2,41,11,1,10,10,1,14,33,37,33,1,0]

theorem envBound21528 : H12AffineFastState.Bounded env21528 := by
  intro p hp
  have h : env21528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21527_21528 : H12AffineEnvironment.transform 3 10 env21527 = env21528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env21527 == env21528) = true)

def env21529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,67618,1025,32769,69911,65910,65863,98644,349,64,2049,70726,17664,100387,66563,54561,257,21792,38224,513]

theorem envBound21529 : H12AffineFastState.Bounded env21529 := by
  intro p hp
  have h : env21529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21517_21529 : H12AffineEnvironment.transform 6 9 env21517 = env21529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21517 == env21529) = true)

theorem identity21529 : scanCanonicalize (H12AffineFastState.compose env21529 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21529 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,33111,49169,35189,1025,32769,36928,32801,32784,3,349,64,2049,38161,17664,2420,34132,54561,257,21792,38224,513]

theorem envBound21530 : H12AffineFastState.Bounded env21530 := by
  intro p hp
  have h : env21530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21529_21530 : H12AffineEnvironment.transform 15 33111 env21529 = env21530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21529 == env21530) = true)

theorem identity21530 : scanCanonicalize (H12AffineFastState.compose env21530 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound21530 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21531 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,342,16400,2420,1025,0,4161,32,17,3,349,64,2049,5392,17664,2420,1365,21792,257,21792,5457,513]

theorem envBound21531 : H12AffineFastState.Bounded env21531 := by
  intro p hp
  have h : env21531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21530_21531 : H12AffineEnvironment.transform 14 1 env21530 = env21531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env21530 == env21531) = true)

theorem identity21531 : scanCanonicalize (H12AffineFastState.compose env21531 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound21531 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21532 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,6161,1,342,6145,2420,1025,0,4161,32,17,3,349,64,2049,5392,7441,2420,1365,3377,257,3377,5457,513]

theorem envBound21532 : H12AffineFastState.Bounded env21532 := by
  intro p hp
  have h : env21532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21531_21532 : H12AffineEnvironment.transform 13 6161 env21531 = env21532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env21531 == env21532) = true)

theorem identity21532 : scanCanonicalize (H12AffineFastState.compose env21532 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1313) := by decide +kernel

theorem selectedBound21532 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env21533 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1313,4096,348,5424,1,342,5408,1109,1025,0,4161,32,17,3,349,64,1312,5392,4144,1109,1365,16,257,16,5457,513]

theorem envBound21533 : H12AffineFastState.Bounded env21533 := by
  intro p hp
  have h : env21533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21532_21533 : H12AffineEnvironment.transform 10 1313 env21532 = env21533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1313 env21532 == env21533) = true)

theorem identity21533 : scanCanonicalize (H12AffineFastState.compose env21533 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound21533 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env21534 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1141,4096,8,5220,1,2,5236,1109,1025,0,4161,32,17,3,9,64,1140,5188,4144,1109,1025,16,85,16,5125,513]

theorem envBound21534 : H12AffineFastState.Bounded env21534 := by
  intro p hp
  have h : env21534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21533_21534 : H12AffineEnvironment.transform 7 84 env21533 = env21534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env21533 == env21534) = true)

theorem identity21534 : scanCanonicalize (H12AffineFastState.compose env21534 (packedSelected [2,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound21534 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env21535 : List Nat := [2,4,8,16,32,64,9,84,512,1024,1141,1109,8,49,1,2,33,1109,1025,0,1044,32,17,3,9,64,1140,17,1125,1109,1025,16,85,16,80,513]

theorem envBound21535 : H12AffineFastState.Bounded env21535 := by
  intro p hp
  have h : env21535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21534_21535 : H12AffineEnvironment.transform 11 1109 env21534 = env21535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env21534 == env21535) = true)

theorem identity21535 : scanCanonicalize (H12AffineFastState.compose env21535 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound21535 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21536 : List Nat := [2,4,8,16,32,64,9,84,512,533,608,576,8,49,1,2,33,576,532,0,513,32,17,3,9,64,609,17,624,576,532,16,85,16,80,513]

theorem envBound21536 : H12AffineFastState.Bounded env21536 := by
  intro p hp
  have h : env21536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21535_21536 : H12AffineEnvironment.transform 9 533 env21535 = env21536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env21535 == env21536) = true)

theorem identity21536 : scanCanonicalize (H12AffineFastState.compose env21536 (packedSelected [0,1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21536 : packedSelected [0,1,2,8] rootPS < 2^1333 := by decide +kernel

def env21537 : List Nat := [2,4,8,0,32,64,9,68,512,517,608,576,8,33,1,2,33,576,516,0,513,32,1,3,9,64,609,1,608,576,516,0,69,0,64,513]

theorem envBound21537 : H12AffineFastState.Bounded env21537 := by
  intro p hp
  have h : env21537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21536_21537 : H12AffineEnvironment.transform 3 0 env21536 = env21537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21536 == env21537) = true)

theorem identity21537 : scanCanonicalize (H12AffineFastState.compose env21537 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21537 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21538 : List Nat := [2,4,8,0,32,64,9,68,33,36,65,97,8,33,1,2,33,97,37,0,32,32,1,3,9,64,64,1,65,97,37,0,69,0,64,32]

theorem envBound21538 : H12AffineFastState.Bounded env21538 := by
  intro p hp
  have h : env21538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21537_21538 : H12AffineEnvironment.transform 8 33 env21537 = env21538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21537 == env21538) = true)

theorem identity21538 : scanCanonicalize (H12AffineFastState.compose env21538 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound21538 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21539 : List Nat := [2,4,8,0,32,32,9,36,33,36,33,1,8,33,1,2,33,1,37,0,32,32,1,3,9,32,32,1,33,1,37,0,37,0,32,32]

theorem envBound21539 : H12AffineFastState.Bounded env21539 := by
  intro p hp
  have h : env21539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21538_21539 : H12AffineEnvironment.transform 5 32 env21538 = env21539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env21538 == env21539) = true)

theorem identity21539 : scanCanonicalize (H12AffineFastState.compose env21539 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21539 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21540 : List Nat := [2,4,8,0,0,0,9,4,1,4,1,1,8,1,1,2,1,1,5,0,0,0,1,3,9,0,0,1,1,1,5,0,5,0,0,0]

theorem envBound21540 : H12AffineFastState.Bounded env21540 := by
  intro p hp
  have h : env21540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21539_21540 : H12AffineEnvironment.transform 4 0 env21539 = env21540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21539 == env21540) = true)

def env21541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6623435,2098512,17665,2461975,2102685,6349853,257,21792,46213,2175562]

theorem envBound21541 : H12AffineFastState.Bounded env21541 := by
  intro p hp
  have h : env21541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21500_21541 : H12AffineEnvironment.transform 22 2101329 env21500 = env21541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env21500 == env21541) = true)

def env21542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2177099,2098512,17665,2461975,2102685,2411677,257,21792,46213,2175562]

theorem envBound21542 : H12AffineFastState.Bounded env21542 := by
  intro p hp
  have h : env21542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21541_21542 : H12AffineEnvironment.transform 21 272512 env21541 = env21542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env21541 == env21542) = true)

theorem identity21542 : scanCanonicalize (H12AffineFastState.compose env21542 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound21542 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38296,262144,1025,32769,2097152,272512,2101329,21762,8328,64,2157717,2098512,17665,2377161,2102685,2411677,257,21792,46213,2156180]

theorem envBound21543 : H12AffineFastState.Bounded env21543 := by
  intro p hp
  have h : env21543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21542_21543 : H12AffineEnvironment.transform 15 54494 env21542 = env21543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env21542 == env21543) = true)

def env21544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,2097152,272512,2101249,21762,8328,16,2157717,2098432,17665,2377113,2102685,2411677,257,21792,46213,2156180]

theorem envBound21544 : H12AffineFastState.Bounded env21544 := by
  intro p hp
  have h : env21544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21543_21544 : H12AffineEnvironment.transform 5 16 env21543 = env21544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21543 == env21544) = true)

theorem identity21544 : scanCanonicalize (H12AffineFastState.compose env21544 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound21544 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env21545 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,58517,272512,62612,21762,8328,16,2048,57749,17665,303372,61704,272392,257,21792,46213,513]

theorem envBound21545 : H12AffineFastState.Bounded env21545 := by
  intro p hp
  have h : env21545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21544_21545 : H12AffineEnvironment.transform 20 58517 env21544 = env21545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env21544 == env21545) = true)

theorem identity21545 : scanCanonicalize (H12AffineFastState.compose env21545 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound21545 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env21546 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,23589,1025,32769,58517,29861,62612,21762,8328,16,2048,57749,17665,64809,61704,29741,257,21792,46213,513]

theorem envBound21546 : H12AffineFastState.Bounded env21546 := by
  intro p hp
  have h : env21546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21545_21546 : H12AffineEnvironment.transform 17 23589 env21545 = env21546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env21545 == env21546) = true)

theorem identity21546 : scanCanonicalize (H12AffineFastState.compose env21546 (packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21546 : packedSelected [0,1,2,3,4,5,6,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env21547 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33166,38296,2341,1025,32769,45461,8613,41364,2,8328,16,2048,46229,4097,43049,41992,8493,257,32,46213,513]

theorem envBound21547 : H12AffineFastState.Bounded env21547 := by
  intro p hp
  have h : env21547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21546_21547 : H12AffineEnvironment.transform 13 5376 env21546 = env21547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21546 == env21547) = true)

theorem identity21547 : scanCanonicalize (H12AffineFastState.compose env21547 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound21547 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env21548 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,0,398,5528,2341,1025,1,12693,8613,8596,2,8328,16,2048,13461,4097,10281,9224,8493,257,32,13445,513]

theorem envBound21548 : H12AffineFastState.Bounded env21548 := by
  intro p hp
  have h : env21548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21547_21548 : H12AffineEnvironment.transform 14 0 env21547 = env21548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env21547 == env21548) = true)

theorem identity21548 : scanCanonicalize (H12AffineFastState.compose env21548 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21548 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21549 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,0,398,5528,2341,1025,1,4113,33,16,2,268,16,2048,5393,4097,2477,1420,169,257,32,5377,513]

theorem envBound21549 : H12AffineFastState.Bounded env21549 := by
  intro p hp
  have h : env21549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21548_21549 : H12AffineEnvironment.transform 12 388 env21548 = env21549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21548 == env21549) = true)

theorem identity21549 : scanCanonicalize (H12AffineFastState.compose env21549 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21549 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21550 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1025,1,4113,33,16,2,268,16,2048,5393,4097,2341,1284,33,257,32,5377,513]

theorem envBound21550 : H12AffineFastState.Bounded env21550 := by
  intro p hp
  have h : env21550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21549_21550 : H12AffineEnvironment.transform 6 8 env21549 = env21550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21549 == env21550) = true)

theorem identity21550 : scanCanonicalize (H12AffineFastState.compose env21550 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound21550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21551 : List Nat := [2,4,8,16,32,16,8,256,512,256,2048,4096,268,4096,0,262,4112,2341,257,1,4113,33,16,2,268,16,2048,4113,4097,2341,4,33,257,32,4097,513]

theorem envBound21551 : H12AffineFastState.Bounded env21551 := by
  intro p hp
  have h : env21551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21550_21551 : H12AffineEnvironment.transform 9 256 env21550 = env21551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env21550 == env21551) = true)

theorem identity21551 : scanCanonicalize (H12AffineFastState.compose env21551 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound21551 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21552 : List Nat := [2,4,8,16,32,16,8,256,308,256,2048,4096,268,4096,0,262,4112,2341,257,1,4113,33,16,2,268,16,2048,4113,4097,2341,4,33,257,32,4097,309]

theorem envBound21552 : H12AffineFastState.Bounded env21552 := by
  intro p hp
  have h : env21552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21551_21552 : H12AffineEnvironment.transform 8 308 env21551 = env21552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env21551 == env21552) = true)

theorem identity21552 : scanCanonicalize (H12AffineFastState.compose env21552 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound21552 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21553 : List Nat := [2,4,8,16,32,16,8,256,308,256,2048,1,268,1,0,262,17,2341,257,1,16,33,16,2,268,16,2048,16,0,2341,4,33,257,32,0,309]

theorem envBound21553 : H12AffineFastState.Bounded env21553 := by
  intro p hp
  have h : env21553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21552_21553 : H12AffineEnvironment.transform 11 1 env21552 = env21553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env21552 == env21553) = true)

def env21554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,262144,1025,32769,2097152,272512,2101248,21762,8328,17,2157717,2098433,17665,2377112,2102685,2411677,257,21792,46213,2156180]

theorem envBound21554 : H12AffineFastState.Bounded env21554 := by
  intro p hp
  have h : env21554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21543_21554 : H12AffineEnvironment.transform 5 17 env21543 = env21554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21543 == env21554) = true)

theorem identity21554 : scanCanonicalize (H12AffineFastState.compose env21554 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21554 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env21555 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,262144,1025,32769,2097152,272392,2101248,21762,8192,17,2157597,2098433,17665,2376976,2102549,2411541,257,21792,46093,2156060]

theorem envBound21555 : H12AffineFastState.Bounded env21555 := by
  intro p hp
  have h : env21555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21554_21555 : H12AffineEnvironment.transform 6 8 env21554 = env21555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21554 == env21555) = true)

theorem identity21555 : scanCanonicalize (H12AffineFastState.compose env21555 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound21555 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env21556 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,262144,1025,32769,25629,272392,29725,21762,8192,17,34816,24860,17665,270605,28936,305160,257,21792,46093,33281]

theorem envBound21556 : H12AffineFastState.Bounded env21556 := by
  intro p hp
  have h : env21556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21555_21556 : H12AffineEnvironment.transform 20 25629 env21555 = env21556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env21555 == env21556) = true)

theorem identity21556 : scanCanonicalize (H12AffineFastState.compose env21556 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound21556 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env21557 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,38160,32040,1025,32769,25629,21792,29725,21762,8192,17,34816,24860,17665,23589,28936,54560,257,21792,46093,33281]

theorem envBound21557 : H12AffineFastState.Bounded env21557 := by
  intro p hp
  have h : env21557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21556_21557 : H12AffineEnvironment.transform 17 32040 env21556 = env21557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env21556 == env21557) = true)

theorem identity21557 : scanCanonicalize (H12AffineFastState.compose env21557 (packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound21557 : packedSelected [3,4,5,9,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env21558 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29962,13341,32040,1025,8460,25629,21792,29725,21762,8192,17,10509,24860,17665,23589,28936,29741,257,21792,5376,8972]

theorem envBound21558 : H12AffineFastState.Bounded env21558 := by
  intro p hp
  have h : env21558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21557_21558 : H12AffineEnvironment.transform 14 8461 env21557 = env21558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env21557 == env21558) = true)

def env21559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2177098,2098512,17665,2461975,2102685,2411676,257,21792,46213,2175562]

theorem envBound21559 : H12AffineFastState.Bounded env21559 := by
  intro p hp
  have h : env21559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21541_21559 : H12AffineEnvironment.transform 21 272513 env21541 = env21559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env21541 == env21559) = true)

theorem identity21559 : scanCanonicalize (H12AffineFastState.compose env21559 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound21559 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21560 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115870,272513,120015,98780,8328,64,64724,115150,17665,284041,119043,329730,257,21792,46213,63188]

theorem envBound21560 : H12AffineFastState.Bounded env21560 := by
  intro p hp
  have h : env21560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21559_21560 : H12AffineEnvironment.transform 20 115870 env21559 = env21560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env21559 == env21560) = true)

def env21561 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115870,272513,119967,98700,8328,16,64644,115102,17665,284041,119043,329730,257,21792,46213,63108]

theorem envBound21561 : H12AffineFastState.Bounded env21561 := by
  intro p hp
  have h : env21561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21560_21561 : H12AffineEnvironment.transform 5 16 env21560 = env21561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21560 == env21561) = true)

theorem identity21561 : scanCanonicalize (H12AffineFastState.compose env21561 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 122147) := by decide +kernel

theorem selectedBound21561 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21562 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,122147,1025,32769,115870,128418,119967,98700,8328,16,64644,115102,17665,100522,119043,54561,257,21792,46213,63108]

theorem envBound21562 : H12AffineFastState.Bounded env21562 := by
  intro p hp
  have h : env21562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21561_21562 : H12AffineEnvironment.transform 17 122147 env21561 = env21562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 122147 env21561 == env21562) = true)

theorem identity21562 : scanCanonicalize (H12AffineFastState.compose env21562 (packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21562 : packedSelected [4,5,7,8,9,17,19,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env21563 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,24860,64809,1025,32769,58516,54696,62613,41350,8328,16,64644,57748,17665,43168,61705,54561,257,21792,46213,63108]

theorem envBound21563 : H12AffineFastState.Bounded env21563 := by
  intro p hp
  have h : env21563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21562_21563 : H12AffineEnvironment.transform 15 8202 env21562 = env21563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21562 == env21563) = true)

theorem identity21563 : scanCanonicalize (H12AffineFastState.compose env21563 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound21563 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env21564 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8202,24860,2476,1025,29828,4113,8493,16,21763,8328,16,2049,5393,17665,23589,1420,8612,257,21792,16384,513]

theorem envBound21564 : H12AffineFastState.Bounded env21564 := by
  intro p hp
  have h : env21564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21563_21564 : H12AffineEnvironment.transform 14 29829 env21563 = env21564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env21563 == env21564) = true)

theorem identity21564 : scanCanonicalize (H12AffineFastState.compose env21564 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21564 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21565 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,21897,262,16400,2476,1025,21896,4113,33,16,21763,388,16,2049,5393,17665,23589,1420,168,257,21792,16384,513]

theorem envBound21565 : H12AffineFastState.Bounded env21565 := by
  intro p hp
  have h : env21565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21564_21565 : H12AffineEnvironment.transform 12 268 env21564 = env21565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21564 == env21565) = true)

theorem identity21565 : scanCanonicalize (H12AffineFastState.compose env21565 (packedSelected [0,2,5,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound21565 : packedSelected [0,2,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env21566 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,444,268,16384,17461,262,16400,2476,1025,17460,429,33,16,17599,388,16,2049,1197,17665,19865,1420,168,257,17564,16384,513]

theorem envBound21566 : H12AffineFastState.Bounded env21566 := by
  intro p hp
  have h : env21566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21565_21566 : H12AffineEnvironment.transform 11 444 env21565 = env21566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env21565 == env21566) = true)

theorem identity21566 : scanCanonicalize (H12AffineFastState.compose env21566 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound21566 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21567 : List Nat := [2,4,8,16,32,16,128,256,512,393,2048,444,268,16384,16828,262,16400,2476,392,16829,429,33,16,16694,388,16,2049,292,16520,18448,5,168,257,16661,16384,513]

theorem envBound21567 : H12AffineFastState.Bounded env21567 := by
  intro p hp
  have h : env21567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21566_21567 : H12AffineEnvironment.transform 9 393 env21566 = env21567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env21566 == env21567) = true)

theorem identity21567 : scanCanonicalize (H12AffineFastState.compose env21567 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(13+1) ^^^ 2608) := by decide +kernel

theorem selectedBound21567 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env21568 : List Nat := [2,4,8,16,32,16,128,256,512,393,2048,444,268,2608,2956,262,2592,2476,392,2957,429,33,16,2822,388,16,2049,292,2744,544,5,168,257,2853,2608,513]

theorem envBound21568 : H12AffineFastState.Bounded env21568 := by
  intro p hp
  have h : env21568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21567_21568 : H12AffineEnvironment.transform 13 2608 env21567 = env21568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2608 env21567 == env21568) = true)

theorem identity21568 : scanCanonicalize (H12AffineFastState.compose env21568 (packedSelected [0,1,5,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound21568 : packedSelected [0,1,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env21569 : List Nat := [2,4,8,16,32,16,128,256,512,393,396,444,268,956,512,262,940,32,392,513,429,33,16,650,388,16,397,292,820,544,5,168,257,681,956,513]

theorem envBound21569 : H12AffineFastState.Bounded env21569 := by
  intro p hp
  have h : env21569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21568_21569 : H12AffineEnvironment.transform 10 396 env21568 = env21569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env21568 == env21569) = true)

theorem identity21569 : scanCanonicalize (H12AffineFastState.compose env21569 (packedSelected [4,6,7,14] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound21569 : packedSelected [4,6,7,14] rootPS < 2^1333 := by decide +kernel

def env21570 : List Nat := [2,4,8,16,32,16,128,256,0,393,396,444,268,444,0,262,428,32,392,1,429,33,16,138,388,16,397,292,308,32,5,168,257,169,444,1]

theorem envBound21570 : H12AffineFastState.Bounded env21570 := by
  intro p hp
  have h : env21570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21569_21570 : H12AffineEnvironment.transform 8 0 env21569 = env21570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21569 == env21570) = true)

theorem identity21570 : scanCanonicalize (H12AffineFastState.compose env21570 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound21570 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21571 : List Nat := [2,4,8,16,32,16,128,188,0,53,48,0,176,0,0,186,16,32,52,1,17,33,16,138,56,16,49,152,136,32,5,168,189,169,0,1]

theorem envBound21571 : H12AffineFastState.Bounded env21571 := by
  intro p hp
  have h : env21571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21570_21571 : H12AffineEnvironment.transform 7 188 env21570 = env21571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env21570 == env21571) = true)

theorem identity21571 : scanCanonicalize (H12AffineFastState.compose env21571 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound21571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21572 : List Nat := [2,4,8,16,32,16,41,21,0,53,48,0,25,0,0,19,16,32,52,1,17,33,16,35,56,16,49,49,33,32,5,1,20,0,0,1]

theorem envBound21572 : H12AffineFastState.Bounded env21572 := by
  intro p hp
  have h : env21572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21571_21572 : H12AffineEnvironment.transform 6 41 env21571 = env21572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env21571 == env21572) = true)

theorem identity21572 : scanCanonicalize (H12AffineFastState.compose env21572 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21572 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21573 : List Nat := [2,4,8,16,1,16,8,21,0,20,17,0,25,0,0,19,16,1,21,1,17,0,16,2,25,16,16,16,0,1,5,1,20,0,0,1]

theorem envBound21573 : H12AffineFastState.Bounded env21573 := by
  intro p hp
  have h : env21573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21572_21573 : H12AffineEnvironment.transform 4 1 env21572 = env21573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21572 == env21573) = true)

def env21574 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115870,272513,119966,98701,8328,17,64645,115103,17665,284041,119043,329730,257,21792,46213,63109]

theorem envBound21574 : H12AffineFastState.Bounded env21574 := by
  intro p hp
  have h : env21574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21560_21574 : H12AffineEnvironment.transform 5 17 env21560 = env21574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21560 == env21574) = true)

theorem identity21574 : scanCanonicalize (H12AffineFastState.compose env21574 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound21574 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21575 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,64809,1025,32769,115870,54696,119966,98701,8328,17,64645,115103,17665,43168,119043,128299,257,21792,46213,63109]

theorem envBound21575 : H12AffineFastState.Bounded env21575 := by
  intro p hp
  have h : env21575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21574_21575 : H12AffineEnvironment.transform 17 64809 env21574 = env21575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env21574 == env21575) = true)

theorem identity21575 : scanCanonicalize (H12AffineFastState.compose env21575 (packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound21575 : packedSelected [0,3,5,8,9,17,18,19,22,23,26,27,28] rootPS < 2^1333 := by decide +kernel

def env21576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,24861,64809,1025,32769,58516,54696,62612,41351,8328,17,64645,57749,17665,43168,61705,54561,257,21792,46213,63109]

theorem envBound21576 : H12AffineFastState.Bounded env21576 := by
  intro p hp
  have h : env21576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21575_21576 : H12AffineEnvironment.transform 15 8202 env21575 = env21576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env21575 == env21576) = true)

theorem identity21576 : scanCanonicalize (H12AffineFastState.compose env21576 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21576 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env21577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8202,13460,43168,1025,32769,45341,32801,41245,41351,8328,17,43276,46108,4232,43168,42112,32936,257,169,46213,41740]

theorem envBound21577 : H12AffineFastState.Bounded env21577 := by
  intro p hp
  have h : env21577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21576_21577 : H12AffineEnvironment.transform 13 5513 env21576 = env21577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21576 == env21577) = true)

theorem identity21577 : scanCanonicalize (H12AffineFastState.compose env21577 (packedSelected [1,2,3,5,6,7,8,9,10,14,15,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 2712) := by decide +kernel

theorem selectedBound21577 : packedSelected [1,2,3,5,6,7,8,9,10,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env21578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,2712,8202,13460,8760,1025,2713,15237,2745,11141,11039,8328,17,9108,16004,4232,8760,11800,2608,257,169,15901,10644]

theorem envBound21578 : H12AffineFastState.Bounded env21578 := by
  intro p hp
  have h : env21578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21577_21578 : H12AffineEnvironment.transform 14 2712 env21577 = env21578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2712 env21577 == env21578) = true)

theorem identity21578 : scanCanonicalize (H12AffineFastState.compose env21578 (packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 2876) := by decide +kernel

theorem selectedBound21578 : packedSelected [0,1,6,7,8,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env21579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2876,5513,2712,2870,8104,2308,1025,2713,4281,2745,185,35,2996,17,2216,5560,4232,2308,1316,2608,257,169,5409,680]

theorem envBound21579 : H12AffineFastState.Bounded env21579 := by
  intro p hp
  have h : env21579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21578_21579 : H12AffineEnvironment.transform 12 2876 env21578 = env21579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2876 env21578 == env21579) = true)

theorem identity21579 : scanCanonicalize (H12AffineFastState.compose env21579 (packedSelected [2,6,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21579 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env21580 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,2844,5513,2712,2838,8072,2308,1025,2713,4249,2713,153,3,2964,17,2184,5528,4232,2308,1284,2576,257,137,5377,648]

theorem envBound21580 : H12AffineFastState.Bounded env21580 := by
  intro p hp
  have h : env21580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21579_21580 : H12AffineEnvironment.transform 4 0 env21579 = env21580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21579 == env21580) = true)

theorem identity21580 : scanCanonicalize (H12AffineFastState.compose env21580 (packedSelected [0,1,2,6,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound21580 : packedSelected [0,1,2,6,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env21581 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,1541,2844,908,2712,2838,2445,2308,1025,2713,1692,2713,153,3,2964,17,2184,925,1677,2308,1284,2576,257,137,772,648]

theorem envBound21581 : H12AffineFastState.Bounded env21581 := by
  intro p hp
  have h : env21581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21580_21581 : H12AffineEnvironment.transform 11 1541 env21580 = env21581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env21580 == env21581) = true)

theorem identity21581 : scanCanonicalize (H12AffineFastState.compose env21581 (packedSelected [0,2,3,4,5,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound21581 : packedSelected [0,2,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env21582 : List Nat := [2,4,8,16,0,17,128,256,512,1024,529,1541,269,908,137,263,924,789,1025,136,1692,136,153,3,389,17,665,925,1677,789,1284,1,257,137,772,648]

theorem envBound21582 : H12AffineFastState.Bounded env21582 := by
  intro p hp
  have h : env21582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21581_21582 : H12AffineEnvironment.transform 10 529 env21581 = env21582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env21581 == env21582) = true)

theorem identity21582 : scanCanonicalize (H12AffineFastState.compose env21582 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 393) := by decide +kernel

theorem selectedBound21582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21583 : List Nat := [2,4,8,16,0,17,128,256,512,393,529,908,269,908,137,263,924,789,392,136,789,136,153,3,389,17,665,925,772,789,141,1,257,137,772,648]

theorem envBound21583 : H12AffineFastState.Bounded env21583 := by
  intro p hp
  have h : env21583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21582_21583 : H12AffineEnvironment.transform 9 393 env21582 = env21583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 393 env21582 == env21583) = true)

theorem identity21583 : scanCanonicalize (H12AffineFastState.compose env21583 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound21583 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21584 : List Nat := [2,4,8,16,0,17,24,256,512,273,529,788,269,788,17,263,772,789,272,16,789,16,1,3,285,17,513,773,772,789,21,1,257,17,772,528]

theorem envBound21584 : H12AffineFastState.Bounded env21584 := by
  intro p hp
  have h : env21584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21583_21584 : H12AffineEnvironment.transform 6 24 env21583 = env21584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env21583 == env21584) = true)

theorem identity21584 : scanCanonicalize (H12AffineFastState.compose env21584 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21584 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env21585 : List Nat := [2,4,8,1,0,0,9,256,512,256,512,773,269,773,0,263,772,772,257,1,772,1,1,3,268,0,513,773,772,772,4,1,257,0,772,513]

theorem envBound21585 : H12AffineFastState.Bounded env21585 := by
  intro p hp
  have h : env21585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21584_21585 : H12AffineEnvironment.transform 3 1 env21584 = env21585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21584 == env21585) = true)

theorem identity21585 : scanCanonicalize (H12AffineFastState.compose env21585 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21586 : List Nat := [2,4,8,1,0,0,9,256,1,256,1,260,269,260,0,263,261,261,257,1,261,1,1,3,268,0,0,260,261,261,4,1,257,0,261,0]

theorem envBound21586 : H12AffineFastState.Bounded env21586 := by
  intro p hp
  have h : env21586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21585_21586 : H12AffineEnvironment.transform 8 1 env21585 = env21586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21585 == env21586) = true)

def env21587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254784,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound21587 : H12AffineFastState.Bounded env21587 := by
  intro p hp
  have h : env21587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21010_21587 : H12AffineEnvironment.transform 25 65 env21010 = env21587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env21010 == env21587) = true)

def env21588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound21588 : H12AffineFastState.Bounded env21588 := by
  intro p hp
  have h : env21588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21587_21588 : H12AffineEnvironment.transform 26 30393344 env21587 = env21588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env21587 == env21588) = true)

def env21589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound21589 : H12AffineFastState.Bounded env21589 := by
  intro p hp
  have h : env21589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21588_21589 : H12AffineEnvironment.transform 18 1024 env21588 = env21589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21588 == env21589) = true)

theorem identity21589 : scanCanonicalize (H12AffineFastState.compose env21589 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493479) := by decide +kernel

theorem selectedBound21589 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env21590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493479,8328,65,14797863,493738,10507601,8830976,10979382,4680167,256,8898698,8857903,10924001]

theorem envBound21590 : H12AffineFastState.Bounded env21590 := by
  intro p hp
  have h : env21590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21589_21590 : H12AffineEnvironment.transform 23 2493479 env21589 = env21590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493479 env21589 == env21590) = true)

def env21591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797863,115150,10507601,8423780,10600786,4268163,256,8487406,8478795,10544773]

theorem envBound21591 : H12AffineFastState.Bounded env21591 := by
  intro p hp
  have h : env21591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21590_21591 : H12AffineEnvironment.transform 17 149860 env21590 = env21591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env21590 == env21591) = true)

def env21592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,8388608,21763,8328,65,12704871,115150,8406289,8423780,8507666,4268163,256,8487406,8478795,8451781]

theorem envBound21592 : H12AffineFastState.Bounded env21592 := by
  intro p hp
  have h : env21592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21591_21592 : H12AffineEnvironment.transform 20 4160 env21591 = env21592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21591 == env21592) = true)

def env21593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363552,21763,8328,65,215367,115150,4378673,4332612,4408370,4268163,256,4396238,4453739,4350949]

theorem envBound21593 : H12AffineFastState.Bounded env21593 := by
  intro p hp
  have h : env21593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21592_21593 : H12AffineEnvironment.transform 22 4363552 env21592 = env21593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env21592 == env21593) = true)

theorem identity21593 : scanCanonicalize (H12AffineFastState.compose env21593 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound21593 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,16,21763,8328,65,215367,115150,17665,35188,119042,243123,256,98814,90203,63189]

theorem envBound21594 : H12AffineFastState.Bounded env21594 := by
  intro p hp
  have h : env21594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21593_21594 : H12AffineEnvironment.transform 21 169264 env21593 = env21594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env21593 == env21594) = true)

def env21595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,16,21763,8192,65,215367,115014,17665,35188,119042,243003,256,98678,90203,63069]

theorem envBound21595 : H12AffineFastState.Bounded env21595 := by
  intro p hp
  have h : env21595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21594_21595 : H12AffineEnvironment.transform 6 8 env21594 = env21595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21594 == env21595) = true)

theorem identity21595 : scanCanonicalize (H12AffineFastState.compose env21595 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound21595 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21596 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56436,1024,32769,4160,32,16,21763,8192,65,121943,115014,17665,35188,119042,73771,256,98678,90203,63069]

theorem envBound21596 : H12AffineFastState.Bounded env21596 := by
  intro p hp
  have h : env21596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21595_21596 : H12AffineEnvironment.transform 16 38160 env21595 = env21596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env21595 == env21596) = true)

theorem identity21596 : scanCanonicalize (H12AffineFastState.compose env21596 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound21596 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env21597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,65536,38160,35109,1024,32769,4160,32,16,82,8192,65,100614,103447,4176,35188,99411,73771,256,98678,79114,41740]

theorem envBound21597 : H12AffineFastState.Bounded env21597 := by
  intro p hp
  have h : env21597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21596_21597 : H12AffineEnvironment.transform 13 5457 env21596 = env21597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env21596 == env21597) = true)

theorem identity21597 : scanCanonicalize (H12AffineFastState.compose env21597 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound21597 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env21598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,32768,40970,38160,35109,1024,32769,4160,32,16,82,8192,65,10508,13341,4176,35188,9305,32801,256,8572,38144,41740]

theorem envBound21598 : H12AffineFastState.Bounded env21598 := by
  intro p hp
  have h : env21598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21597_21598 : H12AffineEnvironment.transform 15 40970 env21597 = env21598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env21597 == env21598) = true)

theorem identity21598 : scanCanonicalize (H12AffineFastState.compose env21598 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21598 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env21599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8541,343,13389,10360,1024,8540,4160,32,16,82,8192,65,10508,13341,4176,10281,9305,8572,256,8572,13405,593]

theorem envBound21599 : H12AffineFastState.Bounded env21599 := by
  intro p hp
  have h : env21599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21598_21599 : H12AffineEnvironment.transform 14 8541 env21598 = env21599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21598 == env21599) = true)

theorem identity21599 : scanCanonicalize (H12AffineFastState.compose env21599 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6477) := by decide +kernel

theorem selectedBound21599 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6477,5457,6160,343,3328,4405,1024,6161,4160,32,16,82,6477,65,4161,3408,4176,4452,7444,6193,256,6193,3344,593]

theorem envBound21600 : H12AffineFastState.Bounded env21600 := by
  intro p hp
  have h : env21600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21599_21600 : H12AffineEnvironment.transform 12 6477 env21599 = env21600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6477 env21599 == env21600) = true)

theorem identity21600 : scanCanonicalize (H12AffineFastState.compose env21600 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound21600 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env21601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,269,3345,80,343,3328,2421,1024,81,2048,32,16,82,269,65,2049,3408,2064,2340,1364,113,256,113,3344,593]

theorem envBound21601 : H12AffineFastState.Bounded env21601 := by
  intro p hp
  have h : env21601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21600_21601 : H12AffineEnvironment.transform 11 2112 env21600 = env21601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env21600 == env21601) = true)

theorem identity21601 : scanCanonicalize (H12AffineFastState.compose env21601 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21601 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21602 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2112,269,2420,80,343,2405,2421,101,81,2048,32,16,82,269,65,2049,2357,2064,2340,305,113,256,113,2421,593]

theorem envBound21602 : H12AffineFastState.Bounded env21602 := by
  intro p hp
  have h : env21602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21601_21602 : H12AffineEnvironment.transform 9 101 env21601 = env21602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21601 == env21602) = true)

theorem identity21602 : scanCanonicalize (H12AffineFastState.compose env21602 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21602 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env21603 : List Nat := [2,4,8,16,32,64,8,36,512,101,2048,2112,41,2128,80,115,2113,2129,101,81,2048,32,16,82,41,65,2049,2065,2064,2048,21,113,36,113,2129,593]

theorem envBound21603 : H12AffineFastState.Bounded env21603 := by
  intro p hp
  have h : env21603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21602_21603 : H12AffineEnvironment.transform 7 36 env21602 = env21603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21602 == env21603) = true)

theorem identity21603 : scanCanonicalize (H12AffineFastState.compose env21603 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound21603 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21604 : List Nat := [2,4,8,16,32,64,8,36,512,101,81,17,41,1,80,115,16,0,101,81,81,32,16,82,41,65,80,64,65,81,21,113,36,113,0,593]

theorem envBound21604 : H12AffineFastState.Bounded env21604 := by
  intro p hp
  have h : env21604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21603_21604 : H12AffineEnvironment.transform 10 81 env21603 = env21604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env21603 == env21604) = true)

theorem identity21604 : scanCanonicalize (H12AffineFastState.compose env21604 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21604 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env21605 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,17,41,1,1,34,16,0,52,0,0,32,16,3,41,16,1,17,16,0,21,32,36,32,0,512]

theorem envBound21605 : H12AffineFastState.Bounded env21605 := by
  intro p hp
  have h : env21605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21604_21605 : H12AffineEnvironment.transform 5 17 env21604 = env21605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21604 == env21605) = true)

theorem identity21605 : scanCanonicalize (H12AffineFastState.compose env21605 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound21605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21606 : List Nat := [2,4,8,16,32,17,8,36,17,52,0,17,41,1,1,34,16,0,52,0,0,32,16,3,41,16,1,17,16,0,21,32,36,32,0,17]

theorem envBound21606 : H12AffineFastState.Bounded env21606 := by
  intro p hp
  have h : env21606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21605_21606 : H12AffineEnvironment.transform 8 17 env21605 = env21606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env21605 == env21606) = true)

theorem identity21606 : scanCanonicalize (H12AffineFastState.compose env21606 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound21606 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21607 : List Nat := [2,4,6,16,32,17,6,36,17,52,0,17,39,1,1,34,16,0,52,0,0,32,16,3,39,16,1,17,16,0,21,32,36,32,0,17]

theorem envBound21607 : H12AffineFastState.Bounded env21607 := by
  intro p hp
  have h : env21607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21606_21607 : H12AffineEnvironment.transform 2 6 env21606 = env21607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env21606 == env21607) = true)

theorem identity21607 : scanCanonicalize (H12AffineFastState.compose env21607 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21608 : List Nat := [2,4,6,16,16,17,6,20,17,4,0,17,23,1,1,18,16,0,4,0,0,16,16,3,23,16,1,17,16,0,21,16,20,16,0,17]

theorem envBound21608 : H12AffineFastState.Bounded env21608 := by
  intro p hp
  have h : env21608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21607_21608 : H12AffineEnvironment.transform 4 16 env21607 = env21608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21607 == env21608) = true)

theorem identity21608 : scanCanonicalize (H12AffineFastState.compose env21608 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21608 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21609 : List Nat := [2,4,6,0,0,1,6,4,1,4,0,1,7,1,1,2,0,0,4,0,0,0,0,3,7,0,1,1,0,0,5,0,4,0,0,1]

theorem envBound21609 : H12AffineFastState.Bounded env21609 := by
  intro p hp
  have h : env21609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21608_21609 : H12AffineEnvironment.transform 3 0 env21608 = env21609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21608 == env21609) = true)

def env21610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169264,16,21763,8193,65,215367,115015,17665,35188,119042,243002,256,98679,90203,63068]

theorem envBound21610 : H12AffineFastState.Bounded env21610 := by
  intro p hp
  have h : env21610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21594_21610 : H12AffineEnvironment.transform 6 9 env21594 = env21610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21594 == env21610) = true)

theorem identity21610 : scanCanonicalize (H12AffineFastState.compose env21610 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound21610 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,32040,1024,32769,4160,41340,16,21763,8193,65,97547,115015,17665,35188,119042,98678,256,98679,90203,63068]

theorem envBound21611 : H12AffineFastState.Bounded env21611 := by
  intro p hp
  have h : env21611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21610_21611 : H12AffineEnvironment.transform 16 13388 env21610 = env21611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env21610 == env21611) = true)

theorem identity21611 : scanCanonicalize (H12AffineFastState.compose env21611 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21611 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env21612 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,32768,65536,13388,31756,1024,32769,4160,41048,16,21543,8193,65,97327,114787,17445,34896,118822,98386,36,98387,90203,63068]

theorem envBound21612 : H12AffineFastState.Bounded env21612 := by
  intro p hp
  have h : env21612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21611_21612 : H12AffineEnvironment.transform 7 36 env21611 = env21612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21611 == env21612) = true)

theorem identity21612 : scanCanonicalize (H12AffineFastState.compose env21612 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound21612 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env21613 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,32768,41051,13388,31756,1024,32769,4160,41048,16,21543,8193,65,56436,24632,17445,34896,28797,8201,36,8200,49152,63068]

theorem envBound21613 : H12AffineFastState.Bounded env21613 := by
  intro p hp
  have h : env21613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21612_21613 : H12AffineEnvironment.transform 15 41051 env21612 = env21613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env21612 == env21613) = true)

theorem identity21613 : scanCanonicalize (H12AffineFastState.compose env21613 (packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound21613 : packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env21614 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8312,35,13388,31756,1024,8313,4160,32,16,21543,8193,65,31756,24632,17445,10280,28797,8201,36,8200,24696,22052]

theorem envBound21614 : H12AffineFastState.Bounded env21614 := by
  intro p hp
  have h : env21614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21613_21614 : H12AffineEnvironment.transform 14 8312 env21613 = env21614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env21613 == env21614) = true)

theorem identity21614 : scanCanonicalize (H12AffineFastState.compose env21614 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound21614 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env21615 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,16384,81,35,5221,23589,1024,80,4160,32,16,21543,40,65,23589,16401,17445,2049,20564,32,36,33,16465,22052]

theorem envBound21615 : H12AffineFastState.Bounded env21615 := by
  intro p hp
  have h : env21615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21614_21615 : H12AffineEnvironment.transform 12 41 env21614 = env21615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21614 == env21615) = true)

theorem identity21615 : scanCanonicalize (H12AffineFastState.compose env21615 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound21615 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env21616 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,41,2049,81,35,5221,5156,1024,80,4160,32,16,7206,40,65,5156,2064,3108,2049,6229,32,36,33,2128,7717]

theorem envBound21616 : H12AffineFastState.Bounded env21616 := by
  intro p hp
  have h : env21616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21615_21616 : H12AffineEnvironment.transform 13 2049 env21615 = env21616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env21615 == env21616) = true)

theorem identity21616 : scanCanonicalize (H12AffineFastState.compose env21616 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21616 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env21617 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,2049,0,35,5172,5156,1024,1,4113,32,16,7206,40,16,5156,2064,3108,2049,6148,32,36,33,2049,7717]

theorem envBound21617 : H12AffineFastState.Bounded env21617 := by
  intro p hp
  have h : env21617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21616_21617 : H12AffineEnvironment.transform 5 17 env21616 = env21617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21616 == env21617) = true)

theorem identity21617 : scanCanonicalize (H12AffineFastState.compose env21617 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound21617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21618 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,16,41,2049,0,35,1060,1076,1024,1,1,32,16,3126,40,16,1076,2064,3108,2049,2068,32,36,33,2049,3637]

theorem envBound21618 : H12AffineFastState.Bounded env21618 := by
  intro p hp
  have h : env21618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21617_21618 : H12AffineEnvironment.transform 11 16 env21617 = env21618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21617 == env21618) = true)

theorem identity21618 : scanCanonicalize (H12AffineFastState.compose env21618 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21618 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21619 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,16,41,1,0,35,1060,1076,1024,1,1,32,16,1078,40,16,1076,16,1060,1,20,32,36,33,1,1589]

theorem envBound21619 : H12AffineFastState.Bounded env21619 := by
  intro p hp
  have h : env21619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21618_21619 : H12AffineEnvironment.transform 10 0 env21618 = env21619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21618 == env21619) = true)

theorem identity21619 : scanCanonicalize (H12AffineFastState.compose env21619 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21619 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21620 : List Nat := [2,4,8,16,32,17,9,36,33,1024,0,16,41,1,0,35,1060,1076,1024,1,1,32,16,1078,40,16,1076,16,1060,1,20,32,36,33,1,1044]

theorem envBound21620 : H12AffineFastState.Bounded env21620 := by
  intro p hp
  have h : env21620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21619_21620 : H12AffineEnvironment.transform 8 33 env21619 = env21620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21619 == env21620) = true)

theorem identity21620 : scanCanonicalize (H12AffineFastState.compose env21620 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound21620 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21621 : List Nat := [2,4,8,16,32,17,9,36,33,53,0,16,41,1,0,35,17,1,53,1,1,32,16,3,40,16,1,16,17,1,20,32,36,33,1,33]

theorem envBound21621 : H12AffineFastState.Bounded env21621 := by
  intro p hp
  have h : env21621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21620_21621 : H12AffineEnvironment.transform 9 53 env21620 = env21621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env21620 == env21621) = true)

theorem identity21621 : scanCanonicalize (H12AffineFastState.compose env21621 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21622 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,16,9,1,0,3,17,1,21,1,1,0,16,3,8,16,1,16,17,1,20,0,4,1,1,1]

theorem envBound21622 : H12AffineFastState.Bounded env21622 := by
  intro p hp
  have h : env21622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21621_21622 : H12AffineEnvironment.transform 4 0 env21621 = env21622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21621 == env21622) = true)

theorem identity21622 : scanCanonicalize (H12AffineFastState.compose env21622 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound21622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21623 : List Nat := [2,4,7,16,0,17,6,4,1,21,0,16,6,1,0,3,17,1,21,1,1,0,16,3,7,16,1,16,17,1,20,0,4,1,1,1]

theorem envBound21623 : H12AffineFastState.Bounded env21623 := by
  intro p hp
  have h : env21623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21622_21623 : H12AffineEnvironment.transform 2 7 env21622 = env21623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env21622 == env21623) = true)

theorem identity21623 : scanCanonicalize (H12AffineFastState.compose env21623 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21623 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21624 : List Nat := [2,4,7,0,0,1,6,4,1,5,0,0,6,1,0,3,1,1,5,1,1,0,0,3,7,0,1,0,1,1,4,0,4,1,1,1]

theorem envBound21624 : H12AffineFastState.Bounded env21624 := by
  intro p hp
  have h : env21624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21623_21624 : H12AffineEnvironment.transform 3 0 env21623 = env21624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21623 == env21624) = true)

def env21625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363553,21763,8328,65,215366,115150,4378672,4332613,4408371,4268163,256,4396239,4453738,4350948]

theorem envBound21625 : H12AffineFastState.Bounded env21625 := by
  intro p hp
  have h : env21625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21592_21625 : H12AffineEnvironment.transform 22 4363553 env21592 = env21625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env21592 == env21625) = true)

def env21626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169400,153,21763,8328,65,215366,115150,17800,35325,119179,243003,256,98679,90322,63068]

theorem envBound21626 : H12AffineFastState.Bounded env21626 := by
  intro p hp
  have h : env21626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21625_21626 : H12AffineEnvironment.transform 21 169400 env21625 = env21626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env21625 == env21626) = true)

def env21627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21928,153,21763,8328,65,100694,115150,17800,35325,119179,95531,256,98679,90322,63068]

theorem envBound21627 : H12AffineFastState.Bounded env21627 := by
  intro p hp
  have h : env21627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21626_21627 : H12AffineEnvironment.transform 16 49168 env21626 = env21627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env21626 == env21627) = true)

theorem identity21627 : scanCanonicalize (H12AffineFastState.compose env21627 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21627 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,13509,32161,1024,29908,4160,21928,153,21763,8328,65,97667,79131,17800,32040,75102,95531,256,95650,90322,649]

theorem envBound21628 : H12AffineFastState.Bounded env21628 := by
  intro p hp
  have h : env21628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21627_21628 : H12AffineEnvironment.transform 14 29909 env21627 = env21628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21627 == env21628) = true)

theorem identity21628 : scanCanonicalize (H12AffineFastState.compose env21628 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21628 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32041,1024,29788,4160,21792,17,21763,8192,65,97547,79131,17664,32040,75102,95531,256,95530,90202,513]

theorem envBound21629 : H12AffineFastState.Bounded env21629 := by
  intro p hp
  have h : env21629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21628_21629 : H12AffineEnvironment.transform 6 8 env21628 = env21629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21628 == env21629) = true)

theorem identity21629 : scanCanonicalize (H12AffineFastState.compose env21629 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound21629 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,13389,32041,1024,29788,4160,21792,17,21763,8192,65,10589,24909,17664,32040,28936,8573,256,8572,13324,513]

theorem envBound21630 : H12AffineFastState.Bounded env21630 := by
  intro p hp
  have h : env21630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21629_21630 : H12AffineEnvironment.transform 15 21590 env21629 = env21630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env21629 == env21630) = true)

theorem identity21630 : scanCanonicalize (H12AffineFastState.compose env21630 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound21630 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,13389,2421,1024,0,4160,8572,17,8543,8192,65,10589,5393,12636,2420,1364,8573,256,8572,13324,513]

theorem envBound21631 : H12AffineFastState.Bounded env21631 := by
  intro p hp
  have h : env21631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21630_21631 : H12AffineEnvironment.transform 13 13404 env21630 = env21631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env21630 == env21631) = true)

theorem identity21631 : scanCanonicalize (H12AffineFastState.compose env21631 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21632 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,8202,13341,2341,1024,0,4112,8492,17,8463,8192,17,10509,5393,12556,2340,1284,8493,256,8492,13324,513]

theorem envBound21632 : H12AffineFastState.Bounded env21632 := by
  intro p hp
  have h : env21632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21631_21632 : H12AffineEnvironment.transform 5 16 env21631 = env21632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21631 == env21632) = true)

theorem identity21632 : scanCanonicalize (H12AffineFastState.compose env21632 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound21632 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21633 : List Nat := [2,4,8,16,32,16,8,256,512,1024,821,4096,8192,13324,1,8202,13341,528,1024,0,4112,8492,17,8463,8192,17,8760,5393,12556,529,1284,8493,256,8492,13324,513]

theorem envBound21633 : H12AffineFastState.Bounded env21633 := by
  intro p hp
  have h : env21633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21632_21633 : H12AffineEnvironment.transform 10 821 env21632 = env21633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env21632 == env21633) = true)

theorem identity21633 : scanCanonicalize (H12AffineFastState.compose env21633 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound21633 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env21634 : List Nat := [2,4,8,16,32,16,8,256,512,1024,821,4096,1305,4373,1,1299,4356,528,1024,0,4112,1077,17,1046,1305,17,1825,5393,5141,529,1284,1076,256,1077,4373,513]

theorem envBound21634 : H12AffineFastState.Bounded env21634 := by
  intro p hp
  have h : env21634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21633_21634 : H12AffineEnvironment.transform 12 1305 env21633 = env21634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env21633 == env21634) = true)

theorem identity21634 : scanCanonicalize (H12AffineFastState.compose env21634 (packedSelected [7,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21634 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env21635 : List Nat := [2,4,8,16,32,16,8,256,512,21,821,4096,268,4373,1,262,4356,528,21,0,4112,32,17,3,268,17,820,4356,4096,529,273,33,256,32,4373,513]

theorem envBound21635 : H12AffineFastState.Bounded env21635 := by
  intro p hp
  have h : env21635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21634_21635 : H12AffineEnvironment.transform 9 21 env21634 = env21635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21634 == env21635) = true)

theorem identity21635 : scanCanonicalize (H12AffineFastState.compose env21635 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound21635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21636 : List Nat := [2,4,8,16,32,16,8,53,512,21,512,4096,57,4128,1,51,4145,528,21,0,4112,32,17,3,57,17,513,4145,4096,529,36,33,53,32,4128,513]

theorem envBound21636 : H12AffineFastState.Bounded env21636 := by
  intro p hp
  have h : env21636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21635_21636 : H12AffineEnvironment.transform 7 53 env21635 = env21636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env21635 == env21636) = true)

theorem identity21636 : scanCanonicalize (H12AffineFastState.compose env21636 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound21636 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21637 : List Nat := [2,4,8,16,32,16,8,53,1,21,1,4096,57,4128,1,51,4145,17,21,0,4112,32,17,3,57,17,0,4145,4096,16,36,33,53,32,4128,0]

theorem envBound21637 : H12AffineFastState.Bounded env21637 := by
  intro p hp
  have h : env21637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21636_21637 : H12AffineEnvironment.transform 8 1 env21636 = env21637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21636 == env21637) = true)

theorem identity21637 : scanCanonicalize (H12AffineFastState.compose env21637 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21637 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21638 : List Nat := [2,4,8,16,17,16,8,4,1,21,1,4096,8,4113,1,2,4096,17,21,0,4112,17,17,3,8,17,0,4096,4096,16,21,16,4,17,4113,0]

theorem envBound21638 : H12AffineFastState.Bounded env21638 := by
  intro p hp
  have h : env21638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21637_21638 : H12AffineEnvironment.transform 4 17 env21637 = env21638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21637 == env21638) = true)

theorem identity21638 : scanCanonicalize (H12AffineFastState.compose env21638 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound21638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21639 : List Nat := [2,4,8,16,17,16,8,4,1,21,1,0,8,17,1,2,0,17,21,0,16,17,17,3,8,17,0,0,0,16,21,16,4,17,17,0]

theorem envBound21639 : H12AffineFastState.Bounded env21639 := by
  intro p hp
  have h : env21639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21638_21639 : H12AffineEnvironment.transform 11 0 env21638 = env21639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env21638 == env21639) = true)

theorem identity21639 : scanCanonicalize (H12AffineFastState.compose env21639 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21640 : List Nat := [2,4,3,16,17,16,3,4,1,21,1,0,3,17,1,2,0,17,21,0,16,17,17,3,3,17,0,0,0,16,21,16,4,17,17,0]

theorem envBound21640 : H12AffineFastState.Bounded env21640 := by
  intro p hp
  have h : env21640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21639_21640 : H12AffineEnvironment.transform 2 3 env21639 = env21640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21639 == env21640) = true)

theorem identity21640 : scanCanonicalize (H12AffineFastState.compose env21640 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21640 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env21641 : List Nat := [2,4,3,1,0,1,3,4,1,4,1,0,3,0,1,2,0,0,4,0,1,0,0,3,3,0,0,0,0,1,4,1,4,0,0,0]

theorem envBound21641 : H12AffineFastState.Bounded env21641 := by
  intro p hp
  have h : env21641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21640_21641 : H12AffineEnvironment.transform 3 1 env21640 = env21641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21640 == env21641) = true)

def env21642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21929,153,21763,8328,65,100695,115150,17800,35325,119179,95530,256,98679,90322,63068]

theorem envBound21642 : H12AffineFastState.Bounded env21642 := by
  intro p hp
  have h : env21642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21626_21642 : H12AffineEnvironment.transform 16 49169 env21626 = env21642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21626 == env21642) = true)

theorem identity21642 : scanCanonicalize (H12AffineFastState.compose env21642 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound21642 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13388,32040,1024,29788,4160,21929,153,21763,8328,65,97546,79251,17800,32160,75222,95530,256,95530,90322,513]

theorem envBound21643 : H12AffineFastState.Bounded env21643 := by
  intro p hp
  have h : env21643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21642_21643 : H12AffineEnvironment.transform 14 29789 env21642 = env21643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env21642 == env21643) = true)

theorem identity21643 : scanCanonicalize (H12AffineFastState.compose env21643 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound21643 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env21644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,21591,13388,32040,1024,29788,4160,21929,153,21763,8328,65,10589,25028,17800,32160,29057,8573,256,8573,13445,513]

theorem envBound21644 : H12AffineFastState.Bounded env21644 := by
  intro p hp
  have h : env21644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21643_21644 : H12AffineEnvironment.transform 15 21591 env21643 = env21644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env21643 == env21644) = true)

theorem identity21644 : scanCanonicalize (H12AffineFastState.compose env21644 (packedSelected [1,5,7,8,14,18,20,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound21644 : packedSelected [1,5,7,8,14,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env21645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21896,21591,5529,23805,1024,21897,4160,21929,153,21763,349,65,2184,16401,17800,23669,20564,168,256,168,5456,513]

theorem envBound21645 : H12AffineFastState.Bounded env21645 := by
  intro p hp
  have h : env21645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21644_21645 : H12AffineEnvironment.transform 12 469 env21644 = env21645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env21644 == env21645) = true)

theorem identity21645 : scanCanonicalize (H12AffineFastState.compose env21645 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21645 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env21646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,21591,5392,23668,1024,21760,4160,21792,16,21763,349,65,2049,16401,17665,23669,20564,33,256,33,5456,513]

theorem envBound21646 : H12AffineFastState.Bounded env21646 := by
  intro p hp
  have h : env21646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21645_21646 : H12AffineEnvironment.transform 6 9 env21645 = env21646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21645 == env21646) = true)

theorem identity21646 : scanCanonicalize (H12AffineFastState.compose env21646 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound21646 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env21647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4112,1297,1095,5392,3172,1024,1296,4160,1328,16,1299,349,65,2049,4097,5393,3173,68,33,256,33,5456,513]

theorem envBound21647 : H12AffineFastState.Bounded env21647 := by
  intro p hp
  have h : env21647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21646_21647 : H12AffineEnvironment.transform 13 4112 env21646 = env21647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env21646 == env21647) = true)

theorem identity21647 : scanCanonicalize (H12AffineFastState.compose env21647 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21647 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21648 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,1,343,4096,2420,272,0,4160,32,16,3,349,65,2049,4097,4097,2421,68,33,256,33,4160,513]

theorem envBound21648 : H12AffineFastState.Bounded env21648 := by
  intro p hp
  have h : env21648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21647_21648 : H12AffineEnvironment.transform 9 272 env21647 = env21648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21647 == env21648) = true)

theorem identity21648 : scanCanonicalize (H12AffineFastState.compose env21648 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound21648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21649 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,81,348,65,1,343,81,2420,272,0,17,32,16,3,349,65,2049,80,80,2421,68,33,256,33,17,513]

theorem envBound21649 : H12AffineFastState.Bounded env21649 := by
  intro p hp
  have h : env21649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21648_21649 : H12AffineEnvironment.transform 11 81 env21648 = env21649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env21648 == env21649) = true)

theorem identity21649 : scanCanonicalize (H12AffineFastState.compose env21649 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound21649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21650 : List Nat := [2,4,8,16,32,64,9,256,80,272,2048,81,348,65,1,343,81,2420,272,0,17,32,16,3,349,65,2049,80,80,2421,68,33,256,33,17,81]

theorem envBound21650 : H12AffineFastState.Bounded env21650 := by
  intro p hp
  have h : env21650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21649_21650 : H12AffineEnvironment.transform 8 80 env21649 = env21650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env21649 == env21650) = true)

theorem identity21650 : scanCanonicalize (H12AffineFastState.compose env21650 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21650 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21651 : List Nat := [2,4,8,16,32,16,9,256,0,272,2048,1,268,17,1,263,1,2340,272,0,17,32,16,3,269,17,2049,0,0,2341,20,33,256,33,17,1]

theorem envBound21651 : H12AffineFastState.Bounded env21651 := by
  intro p hp
  have h : env21651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21650_21651 : H12AffineEnvironment.transform 5 16 env21650 = env21651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21650 == env21651) = true)

theorem identity21651 : scanCanonicalize (H12AffineFastState.compose env21651 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21651 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21652 : List Nat := [2,4,8,16,32,16,9,256,0,272,293,1,268,17,1,263,1,1,272,0,17,32,16,3,269,17,292,0,0,0,20,33,256,33,17,1]

theorem envBound21652 : H12AffineFastState.Bounded env21652 := by
  intro p hp
  have h : env21652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21651_21652 : H12AffineEnvironment.transform 10 293 env21651 = env21652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21651 == env21652) = true)

theorem identity21652 : scanCanonicalize (H12AffineFastState.compose env21652 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21653 : List Nat := [2,4,8,16,0,16,9,256,0,272,261,1,268,17,1,263,1,1,272,0,17,0,16,3,269,17,260,0,0,0,20,1,256,1,17,1]

theorem envBound21653 : H12AffineFastState.Bounded env21653 := by
  intro p hp
  have h : env21653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21652_21653 : H12AffineEnvironment.transform 4 0 env21652 = env21653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21652 == env21653) = true)

theorem identity21653 : scanCanonicalize (H12AffineFastState.compose env21653 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21653 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21654 : List Nat := [2,4,8,16,0,16,9,20,0,4,17,1,24,17,1,19,1,1,4,0,17,0,16,3,25,17,16,0,0,0,20,1,20,1,17,1]

theorem envBound21654 : H12AffineFastState.Bounded env21654 := by
  intro p hp
  have h : env21654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21653_21654 : H12AffineEnvironment.transform 7 20 env21653 = env21654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21653 == env21654) = true)

theorem identity21654 : scanCanonicalize (H12AffineFastState.compose env21654 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21655 : List Nat := [2,4,8,1,0,1,9,5,0,4,0,1,9,0,1,2,1,1,4,0,0,0,1,3,8,0,1,0,0,0,5,1,5,1,0,1]

theorem envBound21655 : H12AffineFastState.Bounded env21655 := by
  intro p hp
  have h : env21655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21654_21655 : H12AffineEnvironment.transform 3 1 env21654 = env21655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21654 == env21655) = true)

def env21656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,169401,152,21763,8328,65,215366,115150,17801,35324,119178,243002,256,98678,90323,63069]

theorem envBound21656 : H12AffineFastState.Bounded env21656 := by
  intro p hp
  have h : env21656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21625_21656 : H12AffineEnvironment.transform 21 169401 env21625 = env21656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env21625 == env21656) = true)

def env21657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1024,32769,4160,21929,152,21763,8328,65,100694,115150,17801,35324,119178,95530,256,98678,90323,63069]

theorem envBound21657 : H12AffineFastState.Bounded env21657 := by
  intro p hp
  have h : env21657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21656_21657 : H12AffineEnvironment.transform 16 49168 env21656 = env21657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env21656 == env21657) = true)

theorem identity21657 : scanCanonicalize (H12AffineFastState.compose env21657 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound21657 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,35188,1024,32769,4160,169,152,3,8328,65,100694,103630,4233,35324,99466,73770,256,98678,79315,41821]

theorem envBound21658 : H12AffineFastState.Bounded env21658 := by
  intro p hp
  have h : env21658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21657_21658 : H12AffineEnvironment.transform 13 5376 env21657 = env21658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env21657 == env21658) = true)

theorem identity21658 : scanCanonicalize (H12AffineFastState.compose env21658 (packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound21658 : packedSelected [0,1,5,8,9,18,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env21659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,33111,38160,35188,1024,32769,4160,169,152,3,8328,65,2049,5529,4233,35324,1501,41341,256,33,46212,41821]

theorem envBound21659 : H12AffineFastState.Bounded env21659 := by
  intro p hp
  have h : env21659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21658_21659 : H12AffineEnvironment.transform 15 33111 env21658 = env21659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env21658 == env21659) = true)

def env21660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4160,21928,152,21763,8328,65,100695,115150,17801,35324,119178,95531,256,98678,90323,63069]

theorem envBound21660 : H12AffineFastState.Bounded env21660 := by
  intro p hp
  have h : env21660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21656_21660 : H12AffineEnvironment.transform 16 49169 env21656 = env21660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21656 == env21660) = true)

theorem identity21660 : scanCanonicalize (H12AffineFastState.compose env21660 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound21660 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,38296,35189,1024,32769,4160,33,152,138,8328,65,100695,103495,4096,35324,99331,73890,256,98678,79194,41940]

theorem envBound21661 : H12AffineFastState.Bounded env21661 := by
  intro p hp
  have h : env21661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21660_21661 : H12AffineEnvironment.transform 13 5513 env21660 = env21661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env21660 == env21661) = true)

theorem identity21661 : scanCanonicalize (H12AffineFastState.compose env21661 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound21661 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env21662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,13509,10280,1024,8540,4160,33,152,138,8328,65,75786,79130,4096,10401,75102,73890,256,73771,79194,649]

theorem envBound21662 : H12AffineFastState.Bounded env21662 := by
  intro p hp
  have h : env21662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21661_21662 : H12AffineEnvironment.transform 14 8541 env21661 = env21662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env21661 == env21662) = true)

theorem identity21662 : scanCanonicalize (H12AffineFastState.compose env21662 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound21662 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env21663 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,65536,13340,10280,1024,8540,4160,33,65,83,8273,65,75786,79130,4096,10360,75102,73851,256,73771,79194,592]

theorem envBound21663 : H12AffineFastState.Bounded env21663 := by
  intro p hp
  have h : env21663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21662_21663 : H12AffineEnvironment.transform 6 89 env21662 = env21663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env21662 == env21663) = true)

theorem identity21663 : scanCanonicalize (H12AffineFastState.compose env21663 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound21663 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env21664 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,342,13340,10280,1024,8540,4160,33,65,83,8273,65,10588,13388,4096,10360,9224,8493,256,8573,13324,592]

theorem envBound21664 : H12AffineFastState.Bounded env21664 := by
  intro p hp
  have h : env21664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21663_21664 : H12AffineEnvironment.transform 15 342 env21663 = env21664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env21663 == env21664) = true)

theorem identity21664 : scanCanonicalize (H12AffineFastState.compose env21664 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound21664 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env21665 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5456,1,342,5440,2420,1024,0,4160,33,65,83,269,65,2048,5392,4096,2340,1364,113,256,33,5456,592]

theorem envBound21665 : H12AffineFastState.Bounded env21665 := by
  intro p hp
  have h : env21665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21664_21665 : H12AffineEnvironment.transform 12 348 env21664 = env21665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env21664 == env21665) = true)

theorem identity21665 : scanCanonicalize (H12AffineFastState.compose env21665 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound21665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21666 : List Nat := [2,4,8,16,32,64,89,256,512,4,2048,4096,348,4436,1,342,4420,2420,4,0,4160,33,65,83,269,65,2048,4372,4096,2340,336,113,256,33,4436,592]

theorem envBound21666 : H12AffineFastState.Bounded env21666 := by
  intro p hp
  have h : env21666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21665_21666 : H12AffineEnvironment.transform 9 4 env21665 = env21666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env21665 == env21666) = true)

theorem identity21666 : scanCanonicalize (H12AffineFastState.compose env21666 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound21666 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env21667 : List Nat := [2,4,8,16,32,64,89,256,512,4,325,4096,348,4436,1,342,4420,49,4,0,4160,33,65,83,269,65,325,4372,4096,97,336,113,256,33,4436,592]

theorem envBound21667 : H12AffineFastState.Bounded env21667 := by
  intro p hp
  have h : env21667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21666_21667 : H12AffineEnvironment.transform 10 325 env21666 = env21667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env21666 == env21667) = true)

theorem identity21667 : scanCanonicalize (H12AffineFastState.compose env21667 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound21667 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21668 : List Nat := [2,4,8,16,32,64,89,256,512,4,325,373,348,33,1,342,49,49,4,0,309,33,65,83,269,65,325,97,373,97,336,113,256,33,33,592]

theorem envBound21668 : H12AffineFastState.Bounded env21668 := by
  intro p hp
  have h : env21668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21667_21668 : H12AffineEnvironment.transform 11 373 env21667 = env21668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env21667 == env21668) = true)

theorem identity21668 : scanCanonicalize (H12AffineFastState.compose env21668 (packedSelected [6,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21668 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env21669 : List Nat := [2,4,8,16,0,64,89,256,512,4,325,341,348,1,1,342,17,17,4,0,277,1,65,83,269,65,325,65,341,65,336,81,256,1,1,592]

theorem envBound21669 : H12AffineFastState.Bounded env21669 := by
  intro p hp
  have h : env21669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21668_21669 : H12AffineEnvironment.transform 4 0 env21668 = env21669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21668 == env21669) = true)

theorem identity21669 : scanCanonicalize (H12AffineFastState.compose env21669 (packedSelected [1,8,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21669 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env21670 : List Nat := [2,4,8,16,0,16,9,256,512,4,277,261,268,1,1,262,17,17,4,0,277,1,17,3,269,17,277,17,261,17,256,1,256,1,1,512]

theorem envBound21670 : H12AffineFastState.Bounded env21670 := by
  intro p hp
  have h : env21670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21669_21670 : H12AffineEnvironment.transform 5 16 env21669 = env21670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21669 == env21670) = true)

theorem identity21670 : scanCanonicalize (H12AffineFastState.compose env21670 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21670 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21671 : List Nat := [2,4,8,16,0,16,9,256,260,4,277,261,268,1,1,262,17,17,4,0,277,1,17,3,269,17,277,17,261,17,256,1,256,1,1,260]

theorem envBound21671 : H12AffineFastState.Bounded env21671 := by
  intro p hp
  have h : env21671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21670_21671 : H12AffineEnvironment.transform 8 260 env21670 = env21671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21670 == env21671) = true)

theorem identity21671 : scanCanonicalize (H12AffineFastState.compose env21671 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21672 : List Nat := [2,4,8,16,0,16,9,20,16,4,1,17,24,1,1,18,17,17,4,0,1,1,17,3,25,17,1,17,17,17,20,1,20,1,1,16]

theorem envBound21672 : H12AffineFastState.Bounded env21672 := by
  intro p hp
  have h : env21672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21671_21672 : H12AffineEnvironment.transform 7 20 env21671 = env21672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21671 == env21672) = true)

theorem identity21672 : scanCanonicalize (H12AffineFastState.compose env21672 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound21672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21673 : List Nat := [2,4,6,16,0,16,7,20,16,4,1,17,22,1,1,18,17,17,4,0,1,1,17,3,23,17,1,17,17,17,20,1,20,1,1,16]

theorem envBound21673 : H12AffineFastState.Bounded env21673 := by
  intro p hp
  have h : env21673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21672_21673 : H12AffineEnvironment.transform 2 6 env21672 = env21673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env21672 == env21673) = true)

theorem identity21673 : scanCanonicalize (H12AffineFastState.compose env21673 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21673 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21674 : List Nat := [2,4,6,0,0,0,7,4,0,4,1,1,6,1,1,2,1,1,4,0,1,1,1,3,7,1,1,1,1,1,4,1,4,1,1,0]

theorem envBound21674 : H12AffineFastState.Bounded env21674 := by
  intro p hp
  have h : env21674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21673_21674 : H12AffineEnvironment.transform 3 0 env21673 = env21674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21673 == env21674) = true)

def env21675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,8388608,21762,8328,65,12704870,115150,8406288,8423780,8507667,4268163,256,8487406,8478795,8451780]

theorem envBound21675 : H12AffineFastState.Bounded env21675 := by
  intro p hp
  have h : env21675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21591_21675 : H12AffineEnvironment.transform 20 4161 env21591 = env21675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21591 == env21675) = true)

def env21676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363552,21762,8328,65,215366,115150,4378672,4332612,4408371,4268163,256,4396238,4453739,4350948]

theorem envBound21676 : H12AffineFastState.Bounded env21676 := by
  intro p hp
  have h : env21676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21675_21676 : H12AffineEnvironment.transform 22 4363552 env21675 = env21676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env21675 == env21676) = true)

theorem identity21676 : scanCanonicalize (H12AffineFastState.compose env21676 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156133) := by decide +kernel

theorem selectedBound21676 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156133,62661,21762,8328,65,215366,115150,45525,32161,75222,213350,256,95531,103566,513]

theorem envBound21677 : H12AffineFastState.Bounded env21677 := by
  intro p hp
  have h : env21677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21676_21677 : H12AffineEnvironment.transform 21 156133 env21676 = env21677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156133 env21676 == env21677) = true)

def env21678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156013,62541,21762,8192,65,215366,115014,45405,32041,75102,213350,256,95531,103430,513]

theorem envBound21678 : H12AffineFastState.Bounded env21678 := by
  intro p hp
  have h : env21678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21677_21678 : H12AffineEnvironment.transform 6 8 env21677 = env21678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21677 == env21678) = true)

theorem identity21678 : scanCanonicalize (H12AffineFastState.compose env21678 (packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound21678 : packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env21679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35189,1024,32769,4161,41340,62541,21762,8192,65,100695,115014,45405,32041,75102,98679,256,95531,103430,513]

theorem envBound21679 : H12AffineFastState.Bounded env21679 := by
  intro p hp
  have h : env21679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21678_21679 : H12AffineEnvironment.transform 16 49169 env21678 = env21679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env21678 == env21679) = true)

theorem identity21679 : scanCanonicalize (H12AffineFastState.compose env21679 (packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 62810) := by decide +kernel

theorem selectedBound21679 : packedSelected [0,2,3,5,6,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env21680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62810,49169,35189,1024,32769,4161,41340,62541,21762,8192,65,31757,13340,45405,32041,53252,29741,256,32881,24924,513]

theorem envBound21680 : H12AffineFastState.Bounded env21680 := by
  intro p hp
  have h : env21680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21679_21680 : H12AffineEnvironment.transform 15 62810 env21679 = env21680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62810 env21679 == env21680) = true)

theorem identity21680 : scanCanonicalize (H12AffineFastState.compose env21680 (packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound21680 : packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env21681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,262,13389,32041,1024,29789,4161,21792,17,21762,8192,65,31757,13340,17665,32041,9304,29741,256,29741,24924,513]

theorem envBound21681 : H12AffineFastState.Bounded env21681 := by
  intro p hp
  have h : env21681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21680_21681 : H12AffineEnvironment.transform 14 29788 env21680 = env21681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env21680 == env21681) = true)

theorem identity21681 : scanCanonicalize (H12AffineFastState.compose env21681 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound21681 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,8460,262,13389,10361,1024,8461,4161,112,17,82,8192,65,10589,13340,4177,10361,9304,8573,256,8573,13324,513]

theorem envBound21682 : H12AffineFastState.Bounded env21682 := by
  intro p hp
  have h : env21682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21681_21682 : H12AffineEnvironment.transform 13 5456 env21681 = env21682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env21681 == env21682) = true)

theorem identity21682 : scanCanonicalize (H12AffineFastState.compose env21682 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound21682 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env21683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6476,5456,6208,262,3329,4405,1024,6209,4161,112,17,82,6476,65,4113,3408,4177,4405,7444,6193,256,6193,3392,513]

theorem envBound21683 : H12AffineFastState.Bounded env21683 := by
  intro p hp
  have h : env21683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21682_21683 : H12AffineEnvironment.transform 12 6476 env21682 = env21683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env21682 == env21683) = true)

theorem identity21683 : scanCanonicalize (H12AffineFastState.compose env21683 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound21683 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21684 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,6476,4404,6208,262,2405,4405,100,6209,4161,112,17,82,6476,65,4113,2356,4177,4405,6512,6193,256,6193,2340,513]

theorem envBound21684 : H12AffineFastState.Bounded env21684 := by
  intro p hp
  have h : env21684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21683_21684 : H12AffineEnvironment.transform 9 100 env21683 = env21684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env21683 == env21684) = true)

theorem identity21684 : scanCanonicalize (H12AffineFastState.compose env21684 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound21684 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env21685 : List Nat := [2,4,8,16,32,64,8,256,512,100,1,4096,4429,4404,4161,262,356,4405,100,4160,4161,112,17,82,4429,65,4113,309,4177,4405,4465,4144,256,4144,293,513]

theorem envBound21685 : H12AffineFastState.Bounded env21685 := by
  intro p hp
  have h : env21685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21684_21685 : H12AffineEnvironment.transform 10 1 env21684 = env21685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21684 == env21685) = true)

theorem identity21685 : scanCanonicalize (H12AffineFastState.compose env21685 (packedSelected [1,4,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound21685 : packedSelected [1,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env21686 : List Nat := [2,4,8,16,32,64,8,256,512,100,1,16,349,292,81,262,356,293,100,80,81,112,17,82,349,65,1,309,65,293,353,32,256,32,293,513]

theorem envBound21686 : H12AffineFastState.Bounded env21686 := by
  intro p hp
  have h : env21686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21685_21686 : H12AffineEnvironment.transform 11 16 env21685 = env21686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env21685 == env21686) = true)

def env21687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,156012,62540,21762,8193,65,215366,115015,45404,32040,75103,213350,256,95531,103431,513]

theorem envBound21687 : H12AffineFastState.Bounded env21687 := by
  intro p hp
  have h : env21687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21677_21687 : H12AffineEnvironment.transform 6 9 env21677 = env21687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21677 == env21687) = true)

theorem identity21687 : scanCanonicalize (H12AffineFastState.compose env21687 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound21687 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,76159,1024,32769,4161,65911,62540,21762,8193,65,10589,115015,45404,32040,75103,8573,256,95531,103431,513]

theorem envBound21688 : H12AffineFastState.Bounded env21688 := by
  intro p hp
  have h : env21688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21687_21688 : H12AffineEnvironment.transform 16 90139 env21687 = env21688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env21687 == env21688) = true)

theorem identity21688 : scanCanonicalize (H12AffineFastState.compose env21688 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound21688 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env21689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,65536,90139,76159,1024,29004,4161,65911,1281,21762,8193,65,10589,77834,16401,32040,75103,8573,256,95531,91466,513]

theorem envBound21689 : H12AffineFastState.Bounded env21689 := by
  intro p hp
  have h : env21689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21688_21689 : H12AffineEnvironment.transform 14 29005 env21688 = env21689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env21688 == env21689) = true)

theorem identity21689 : scanCanonicalize (H12AffineFastState.compose env21689 (packedSelected [1,4,5,8,9,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21689 : packedSelected [1,4,5,8,9,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env21690 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,28777,65536,90139,75867,1024,28776,4161,65619,1061,21542,8193,65,10361,77834,16401,31756,74875,8281,36,95247,91246,513]

theorem envBound21690 : H12AffineFastState.Bounded env21690 := by
  intro p hp
  have h : env21690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21689_21690 : H12AffineEnvironment.transform 7 36 env21689 = env21690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21689 == env21690) = true)

theorem identity21690 : scanCanonicalize (H12AffineFastState.compose env21690 (packedSelected [0,3,5,7,10,15,17,20,41] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound21690 : packedSelected [0,3,5,7,10,15,17,20,41] rootPS < 2^1333 := by decide +kernel

def env21691 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,28777,20530,12329,30825,1024,28776,4161,20577,1061,21542,8193,65,10361,24632,16401,31756,29769,8281,36,9277,13404,513]

theorem envBound21691 : H12AffineFastState.Bounded env21691 := by
  intro p hp
  have h : env21691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21690_21691 : H12AffineEnvironment.transform 15 20530 env21690 = env21691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env21690 == env21691) = true)

theorem identity21691 : scanCanonicalize (H12AffineFastState.compose env21691 (packedSelected [0,3,5,7,10,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21691 : packedSelected [0,3,5,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env21692 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,8192,16384,28777,20530,12329,30825,101,28776,4161,20577,64,20547,8193,65,10361,24632,16401,30825,28716,8281,36,8280,12345,513]

theorem envBound21692 : H12AffineFastState.Bounded env21692 := by
  intro p hp
  have h : env21692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21691_21692 : H12AffineEnvironment.transform 9 101 env21691 = env21692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21691 == env21692) = true)

theorem identity21692 : scanCanonicalize (H12AffineFastState.compose env21692 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21692 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21693 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,16384,28729,20530,12329,30777,53,28728,4113,20529,16,20499,8193,17,10281,24632,16401,30777,28716,8201,36,8200,12345,513]

theorem envBound21693 : H12AffineFastState.Bounded env21693 := by
  intro p hp
  have h : env21693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21692_21693 : H12AffineEnvironment.transform 5 16 env21692 = env21693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21692 == env21693) = true)

theorem identity21693 : scanCanonicalize (H12AffineFastState.compose env21693 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 8761) := by decide +kernel

theorem selectedBound21693 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env21694 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,8761,4608,12811,12329,6656,53,4609,4113,12808,16,12842,8193,17,10281,513,8744,6656,4629,8201,36,8200,12345,513]

theorem envBound21694 : H12AffineFastState.Bounded env21694 := by
  intro p hp
  have h : env21694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21693_21694 : H12AffineEnvironment.transform 13 8761 env21693 = env21694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8761 env21693 == env21694) = true)

theorem identity21694 : scanCanonicalize (H12AffineFastState.compose env21694 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 6713) := by decide +kernel

theorem selectedBound21694 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env21695 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,6713,6144,4608,2098,2576,6656,53,4609,4113,2097,16,2067,6712,17,4624,513,6161,6656,4629,6704,36,6705,2560,513]

theorem envBound21695 : H12AffineFastState.Bounded env21695 := by
  intro p hp
  have h : env21695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21694_21695 : H12AffineEnvironment.transform 12 6713 env21694 = env21695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6713 env21694 == env21695) = true)

theorem identity21695 : scanCanonicalize (H12AffineFastState.compose env21695 (packedSelected [0,4,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound21695 : packedSelected [0,4,5,8,12] rootPS < 2^1333 := by decide +kernel

def env21696 : List Nat := [2,4,8,16,32,16,9,36,512,53,17,4096,4648,4113,4608,35,513,4625,53,4609,4113,32,16,2,4649,17,4624,513,4096,4625,4629,4641,36,4640,529,513]

theorem envBound21696 : H12AffineFastState.Bounded env21696 := by
  intro p hp
  have h : env21696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21695_21696 : H12AffineEnvironment.transform 10 17 env21695 = env21696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env21695 == env21696) = true)

theorem identity21696 : scanCanonicalize (H12AffineFastState.compose env21696 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound21696 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env21697 : List Nat := [2,4,8,16,32,16,9,36,512,53,17,1,553,16,513,35,513,528,53,512,16,32,16,2,552,17,529,513,1,528,532,544,36,545,529,513]

theorem envBound21697 : H12AffineFastState.Bounded env21697 := by
  intro p hp
  have h : env21697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21696_21697 : H12AffineEnvironment.transform 11 1 env21696 = env21697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env21696 == env21697) = true)

theorem identity21697 : scanCanonicalize (H12AffineFastState.compose env21697 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound21697 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21698 : List Nat := [2,4,8,16,32,16,9,36,17,53,17,1,56,16,16,35,16,1,53,17,16,32,16,2,57,17,0,16,1,1,5,49,36,48,0,16]

theorem envBound21698 : H12AffineFastState.Bounded env21698 := by
  intro p hp
  have h : env21698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21697_21698 : H12AffineEnvironment.transform 8 17 env21697 = env21698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env21697 == env21698) = true)

theorem identity21698 : scanCanonicalize (H12AffineFastState.compose env21698 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21698 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21699 : List Nat := [2,4,8,0,32,0,9,36,1,37,1,1,40,0,0,35,0,1,37,1,0,32,0,2,41,1,0,0,1,1,5,33,36,32,0,0]

theorem envBound21699 : H12AffineFastState.Bounded env21699 := by
  intro p hp
  have h : env21699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21698_21699 : H12AffineEnvironment.transform 3 0 env21698 = env21699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21698 == env21699) = true)

theorem identity21699 : scanCanonicalize (H12AffineFastState.compose env21699 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound21699 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21700 : List Nat := [2,4,3,0,32,0,2,36,1,37,1,1,35,0,0,35,0,1,37,1,0,32,0,2,34,1,0,0,1,1,5,33,36,32,0,0]

theorem envBound21700 : H12AffineFastState.Bounded env21700 := by
  intro p hp
  have h : env21700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21699_21700 : H12AffineEnvironment.transform 2 3 env21699 = env21700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env21699 == env21700) = true)

def env21701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363553,21762,8328,65,215367,115150,4378673,4332613,4408370,4268163,256,4396239,4453738,4350949]

theorem envBound21701 : H12AffineFastState.Bounded env21701 := by
  intro p hp
  have h : env21701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21675_21701 : H12AffineEnvironment.transform 22 4363553 env21675 = env21701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env21675 == env21701) = true)

theorem identity21701 : scanCanonicalize (H12AffineFastState.compose env21701 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21701 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149860,1024,29908,4161,4194304,4350452,21762,8328,65,215367,79131,4334820,4332613,4408370,4268163,256,4396239,4391359,4350949]

theorem envBound21702 : H12AffineFastState.Bounded env21702 := by
  intro p hp
  have h : env21702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21701_21702 : H12AffineEnvironment.transform 14 29909 env21701 = env21702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21701 == env21702) = true)

def env21703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149860,1024,29908,4161,32,156116,21762,8328,65,215367,79131,140484,138341,214034,73891,256,201967,197023,156613]

theorem envBound21703 : H12AffineFastState.Bounded env21703 := by
  intro p hp
  have h : env21703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21702_21703 : H12AffineEnvironment.transform 21 32 env21702 = env21703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env21702 == env21703) = true)

def env21704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,149860,1024,29908,4161,33,156117,21762,8328,65,215367,79131,140485,138340,214035,73890,256,201966,197022,156612]

theorem envBound21704 : H12AffineFastState.Bounded env21704 := by
  intro p hp
  have h : env21704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21702_21704 : H12AffineEnvironment.transform 21 33 env21702 = env21704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env21702 == env21704) = true)

theorem identity21704 : scanCanonicalize (H12AffineFastState.compose env21704 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound21704 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env21705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,131072,146744,1024,136,4161,33,136585,8542,8328,65,212251,79131,140485,138340,208975,73890,256,201966,197022,137112]

theorem envBound21705 : H12AffineFastState.Bounded env21705 := by
  intro p hp
  have h : env21705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21704_21705 : H12AffineEnvironment.transform 13 13404 env21704 = env21705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env21704 == env21705) = true)

theorem identity21705 : scanCanonicalize (H12AffineFastState.compose env21705 (packedSelected [2,3,4,6,9,11,15,17,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 2200) := by decide +kernel

theorem selectedBound21705 : packedSelected [2,3,4,6,9,11,15,17,19,24,26] rootPS < 2^1333 := by decide +kernel

def env21706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,65536,2200,13728,1024,136,4161,33,7441,8542,8328,65,79235,79131,11357,5372,80087,73890,256,72822,67846,7936]

theorem envBound21706 : H12AffineFastState.Bounded env21706 := by
  intro p hp
  have h : env21706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21705_21706 : H12AffineEnvironment.transform 16 2200 env21705 = env21706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2200 env21705 == env21706) = true)

theorem identity21706 : scanCanonicalize (H12AffineFastState.compose env21706 (packedSelected [0,1,5,8,9,11,12,15,16,18,20,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound21706 : packedSelected [0,1,5,8,9,11,12,15,16,18,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env21707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4404,137,65536,2200,4296,1024,136,4161,33,7441,1078,1504,65,69867,69747,2357,5372,73151,67018,256,72822,67846,7936]

theorem envBound21707 : H12AffineFastState.Bounded env21707 := by
  intro p hp
  have h : env21707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21706_21707 : H12AffineEnvironment.transform 12 1384 env21706 = env21707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env21706 == env21707) = true)

theorem identity21707 : scanCanonicalize (H12AffineFastState.compose env21707 (packedSelected [0,1,2,3,5,6,7,8,9,10,11,12,15,17,18,19,22,23] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound21707 : packedSelected [0,1,2,3,5,6,7,8,9,10,11,12,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env21708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,152,1384,428,137,65536,2200,80,1024,136,217,33,3465,1078,1504,65,65651,65771,2357,1124,68903,67018,256,68846,67846,3992]

theorem envBound21708 : H12AffineFastState.Bounded env21708 := by
  intro p hp
  have h : env21708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21707_21708 : H12AffineEnvironment.transform 11 152 env21707 = env21708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env21707 == env21708) = true)

theorem identity21708 : scanCanonicalize (H12AffineFastState.compose env21708 (packedSelected [0,2,5,6,7,8,9,11,12,17,22,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound21708 : packedSelected [0,2,5,6,7,8,9,11,12,17,22,24,28] rootPS < 2^1333 := by decide +kernel

def env21709 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,152,41,428,137,65536,2200,80,321,136,217,33,2248,375,161,65,65651,65771,2357,293,67686,65675,256,68015,67846,2777]

theorem envBound21709 : H12AffineFastState.Bounded env21709 := by
  intro p hp
  have h : env21709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21708_21709 : H12AffineEnvironment.transform 9 321 env21708 = env21709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env21708 == env21709) = true)

theorem identity21709 : scanCanonicalize (H12AffineFastState.compose env21709 (packedSelected [1,3,5,8,10,14,15,16,19] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound21709 : packedSelected [1,3,5,8,10,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env21710 : List Nat := [2,4,8,16,32,64,128,256,512,321,508,152,41,428,137,65536,356,80,321,136,217,33,308,375,161,65,65651,65771,201,293,65946,65675,256,65619,65786,805]

theorem envBound21710 : H12AffineFastState.Bounded env21710 := by
  intro p hp
  have h : env21710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21709_21710 : H12AffineEnvironment.transform 10 508 env21709 = env21710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env21709 == env21710) = true)

def env21711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797863,115151,10507601,8423781,10600787,4268162,256,8487407,8478794,10544772]

theorem envBound21711 : H12AffineFastState.Bounded env21711 := by
  intro p hp
  have h : env21711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21590_21711 : H12AffineEnvironment.transform 17 149861 env21590 = env21711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env21590 == env21711) = true)

def env21712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,8388608,21762,8328,65,12704871,115151,8406289,8423781,8507667,4268162,256,8487407,8478794,8451780]

theorem envBound21712 : H12AffineFastState.Bounded env21712 := by
  intro p hp
  have h : env21712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21711_21712 : H12AffineEnvironment.transform 20 4160 env21711 = env21712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env21711 == env21712) = true)

def env21713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363552,21762,8328,65,215367,115151,4378673,4332613,4408371,4268162,256,4396239,4453738,4350948]

theorem envBound21713 : H12AffineFastState.Bounded env21713 := by
  intro p hp
  have h : env21713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21712_21713 : H12AffineEnvironment.transform 22 4363552 env21712 = env21713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env21712 == env21713) = true)

theorem identity21713 : scanCanonicalize (H12AffineFastState.compose env21713 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound21713 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,213487,120015,21762,8328,65,215367,115151,102878,89514,1500,156013,256,21792,46213,74251]

theorem envBound21714 : H12AffineFastState.Bounded env21714 := by
  intro p hp
  have h : env21714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21713_21714 : H12AffineEnvironment.transform 21 213487 env21713 = env21714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env21713 == env21714) = true)

def env21715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10401,1024,32769,4160,73771,120015,21762,8328,65,75907,115151,102878,89514,1500,169,256,21792,46213,74251]

theorem envBound21715 : H12AffineFastState.Bounded env21715 := by
  intro p hp
  have h : env21715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21714_21715 : H12AffineEnvironment.transform 16 25028 env21714 = env21715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env21714 == env21715) = true)

theorem identity21715 : scanCanonicalize (H12AffineFastState.compose env21715 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound21715 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env21716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,65536,25028,10401,1024,30112,4160,73771,74094,21762,8328,65,75907,78958,91263,89514,1500,169,256,21792,16676,74251]

theorem envBound21716 : H12AffineFastState.Bounded env21716 := by
  intro p hp
  have h : env21716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21715_21716 : H12AffineEnvironment.transform 14 30113 env21715 = env21716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env21715 == env21716) = true)

theorem identity21716 : scanCanonicalize (H12AffineFastState.compose env21716 (packedSelected [0,1,6,10,11,19,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound21716 : packedSelected [0,1,6,10,11,19,27,28,32] rootPS < 2^1333 := by decide +kernel

def env21717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,429,65536,5576,10401,1024,428,4160,73771,74094,8462,8328,65,75907,78958,69747,76198,1500,169,256,8492,13608,74251]

theorem envBound21717 : H12AffineFastState.Bounded env21717 := by
  intro p hp
  have h : env21717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21716_21717 : H12AffineEnvironment.transform 13 13324 env21716 = env21717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env21716 == env21717) = true)

theorem identity21717 : scanCanonicalize (H12AffineFastState.compose env21717 (packedSelected [1,4,5,8,9,14,16,17,18,19,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound21717 : packedSelected [1,4,5,8,9,14,16,17,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,120,5236,429,65536,5576,2265,1024,428,4160,65619,65814,374,240,65,67835,70678,69747,68062,1500,169,256,340,5456,66163]

theorem envBound21718 : H12AffineFastState.Bounded env21718 := by
  intro p hp
  have h : env21718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21717_21718 : H12AffineEnvironment.transform 12 120 env21717 = env21718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env21717 == env21718) = true)

theorem identity21718 : scanCanonicalize (H12AffineFastState.compose env21718 (packedSelected [17] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21718 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env21719 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,120,5236,216,65536,5309,2265,1024,217,4160,65619,65635,3,240,65,67835,70678,69747,67755,1193,169,117,33,5157,66163]

theorem envBound21719 : H12AffineFastState.Bounded env21719 := by
  intro p hp
  have h : env21719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21718_21719 : H12AffineEnvironment.transform 7 117 env21718 = env21719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21718 == env21719) = true)

theorem identity21719 : scanCanonicalize (H12AffineFastState.compose env21719 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound21719 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env21720 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,120,5236,216,250,5309,2265,1024,217,4160,169,153,3,240,65,2049,5356,4233,2129,1193,169,117,33,5157,649]

theorem envBound21720 : H12AffineFastState.Bounded env21720 := by
  intro p hp
  have h : env21720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21719_21720 : H12AffineEnvironment.transform 15 250 env21719 = env21720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env21719 == env21720) = true)

theorem identity21720 : scanCanonicalize (H12AffineFastState.compose env21720 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21720 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env21721 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5236,81,115,5172,2128,1024,80,4160,32,16,3,121,65,2049,5221,4096,2129,1056,32,117,33,5157,512]

theorem envBound21721 : H12AffineFastState.Bounded env21721 := by
  intro p hp
  have h : env21721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21720_21721 : H12AffineEnvironment.transform 6 9 env21720 = env21721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21720 == env21721) = true)

theorem identity21721 : scanCanonicalize (H12AffineFastState.compose env21721 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21721 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env21722 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,9,5125,32,2,5172,2081,1024,33,4145,32,16,3,8,48,2049,5140,4096,2080,1056,32,4,33,5157,512]

theorem envBound21722 : H12AffineFastState.Bounded env21722 := by
  intro p hp
  have h : env21722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21721_21722 : H12AffineEnvironment.transform 5 49 env21721 = env21722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21721 == env21722) = true)

theorem identity21722 : scanCanonicalize (H12AffineFastState.compose env21722 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21722 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env21723 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,9,5125,1,2,5141,2048,1024,0,4112,1,16,3,8,17,2049,5140,4096,2049,1025,1,4,0,5124,512]

theorem envBound21723 : H12AffineFastState.Bounded env21723 := by
  intro p hp
  have h : env21723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21722_21723 : H12AffineEnvironment.transform 4 1 env21722 = env21723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21722 == env21723) = true)

def env21724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10400,1024,32769,4160,73770,120015,21762,8328,65,75906,115151,102878,89514,1500,168,256,21792,46213,74251]

theorem envBound21724 : H12AffineFastState.Bounded env21724 := by
  intro p hp
  have h : env21724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21714_21724 : H12AffineEnvironment.transform 16 25029 env21714 = env21724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env21714 == env21724) = true)

theorem identity21724 : scanCanonicalize (H12AffineFastState.compose env21724 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound21724 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env21725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,25029,10400,1024,29908,4160,73770,73754,21762,8328,65,75906,79130,91403,89514,1500,168,256,21792,16464,74251]

theorem envBound21725 : H12AffineFastState.Bounded env21725 := by
  intro p hp
  have h : env21725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21724_21725 : H12AffineEnvironment.transform 14 29909 env21724 = env21725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env21724 == env21725) = true)

theorem identity21725 : scanCanonicalize (H12AffineFastState.compose env21725 (packedSelected [0,1,2,5,6,10,11,12,14,15,16,20,23,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21725 : packedSelected [0,1,2,5,6,10,11,12,14,15,16,20,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env21726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,25029,10400,1024,29908,4160,33,17,21762,8328,65,2185,5393,17664,32161,1500,168,256,21792,16464,512]

theorem envBound21726 : H12AffineFastState.Bounded env21726 := by
  intro p hp
  have h : env21726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21725_21726 : H12AffineEnvironment.transform 15 8203 env21725 = env21726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21725 == env21726) = true)

theorem identity21726 : scanCanonicalize (H12AffineFastState.compose env21726 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound21726 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env21727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2325,8192,16384,28096,8203,25029,10400,1024,28097,2389,33,17,19479,8328,65,2185,3076,17664,25780,1500,168,256,19509,16464,512]

theorem envBound21727 : H12AffineFastState.Bounded env21727 := by
  intro p hp
  have h : env21727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21726_21727 : H12AffineEnvironment.transform 11 2325 env21726 = env21727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env21726 == env21727) = true)

theorem identity21727 : scanCanonicalize (H12AffineFastState.compose env21727 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound21727 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env21728 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,8192,16384,27829,8203,24752,10400,1024,27828,2080,33,17,19479,8328,65,2185,3076,17525,25780,1193,168,117,19509,16464,512]

theorem envBound21728 : H12AffineFastState.Bounded env21728 := by
  intro p hp
  have h : env21728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21727_21728 : H12AffineEnvironment.transform 7 117 env21727 = env21728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env21727 == env21728) = true)

theorem identity21728 : scanCanonicalize (H12AffineFastState.compose env21728 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 10401) := by decide +kernel

theorem selectedBound21728 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env21729 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,8192,10401,1044,8203,2065,10400,1024,1045,2080,33,17,9398,8328,65,2185,3076,11476,3093,1193,168,117,9364,10481,512]

theorem envBound21729 : H12AffineFastState.Bounded env21729 := by
  intro p hp
  have h : env21729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21728_21729 : H12AffineEnvironment.transform 13 10401 env21728 = env21729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10401 env21728 == env21729) = true)

theorem identity21729 : scanCanonicalize (H12AffineFastState.compose env21729 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound21729 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env21730 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,2144,88,2297,1044,83,2065,2296,1024,1045,2080,33,17,1262,208,65,2185,3076,3212,3093,1193,168,117,1228,2217,512]

theorem envBound21730 : H12AffineFastState.Bounded env21730 := by
  intro p hp
  have h : env21730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21729_21730 : H12AffineEnvironment.transform 12 88 env21729 = env21730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env21729 == env21730) = true)

theorem identity21730 : scanCanonicalize (H12AffineFastState.compose env21730 (packedSelected [0,1,3,4,5,6,7,8,9,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound21730 : packedSelected [0,1,3,4,5,6,7,8,9,11,12,18] rootPS < 2^1333 := by decide +kernel

def env21731 : List Nat := [2,4,8,16,32,64,128,117,512,1024,113,17,88,136,1044,83,96,137,1024,1045,81,33,17,1262,208,65,248,1141,1277,1124,1193,168,117,1228,216,512]

theorem envBound21731 : H12AffineFastState.Bounded env21731 := by
  intro p hp
  have h : env21731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21730_21731 : H12AffineEnvironment.transform 10 113 env21730 = env21731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env21730 == env21731) = true)

theorem identity21731 : scanCanonicalize (H12AffineFastState.compose env21731 (packedSelected [1,2,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21731 : packedSelected [1,2,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env21732 : List Nat := [2,4,8,16,32,64,8,117,512,1024,113,17,88,0,1044,83,96,1,1024,1045,81,33,17,1126,88,65,112,1141,1141,1124,1057,32,117,1092,80,512]

theorem envBound21732 : H12AffineFastState.Bounded env21732 := by
  intro p hp
  have h : env21732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21731_21732 : H12AffineEnvironment.transform 6 8 env21731 = env21732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21731 == env21732) = true)

theorem identity21732 : scanCanonicalize (H12AffineFastState.compose env21732 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound21732 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env21733 : List Nat := [2,4,8,16,32,64,8,117,512,101,113,17,88,0,113,83,96,1,101,112,81,33,17,3,88,65,112,16,16,1,68,32,117,33,80,512]

theorem envBound21733 : H12AffineFastState.Bounded env21733 := by
  intro p hp
  have h : env21733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21732_21733 : H12AffineEnvironment.transform 9 101 env21732 = env21733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env21732 == env21733) = true)

theorem identity21733 : scanCanonicalize (H12AffineFastState.compose env21733 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21733 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21734 : List Nat := [2,4,8,16,32,17,8,36,512,52,32,17,9,0,32,2,49,1,52,33,0,33,17,3,9,16,33,16,16,1,21,32,36,33,1,512]

theorem envBound21734 : H12AffineFastState.Bounded env21734 := by
  intro p hp
  have h : env21734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21733_21734 : H12AffineEnvironment.transform 5 17 env21733 = env21734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21733 == env21734) = true)

theorem identity21734 : scanCanonicalize (H12AffineFastState.compose env21734 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21734 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env21735 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,0,0,2,17,1,20,1,0,1,17,3,9,16,1,16,16,1,21,0,4,1,1,512]

theorem envBound21735 : H12AffineFastState.Bounded env21735 := by
  intro p hp
  have h : env21735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21734_21735 : H12AffineEnvironment.transform 4 0 env21734 = env21735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21734 == env21735) = true)

theorem identity21735 : scanCanonicalize (H12AffineFastState.compose env21735 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound21735 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21736 : List Nat := [2,4,8,16,0,17,8,4,31,20,0,17,9,0,0,2,17,1,20,1,0,1,17,3,9,16,1,16,16,1,21,0,4,1,1,31]

theorem envBound21736 : H12AffineFastState.Bounded env21736 := by
  intro p hp
  have h : env21736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21735_21736 : H12AffineEnvironment.transform 8 31 env21735 = env21736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env21735 == env21736) = true)

def env21737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363553,21762,8328,65,215366,115151,4378672,4332612,4408370,4268162,256,4396238,4453739,4350949]

theorem envBound21737 : H12AffineFastState.Bounded env21737 := by
  intro p hp
  have h : env21737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21712_21737 : H12AffineEnvironment.transform 22 4363553 env21712 = env21737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env21712 == env21737) = true)

theorem identity21737 : scanCanonicalize (H12AffineFastState.compose env21737 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound21737 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149861,1024,32769,4160,4194304,4363553,21762,8328,65,171417,5392,4378672,4332612,4362477,4256861,256,4374545,4334004,4350949]

theorem envBound21738 : H12AffineFastState.Bounded env21738 := by
  intro p hp
  have h : env21738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21737_21738 : H12AffineEnvironment.transform 15 54495 env21737 = env21738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env21737 == env21738) = true)

def env21739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149861,1024,32769,4160,169400,153,21762,8328,65,171417,5392,17800,35324,1365,156133,256,21929,46092,63069]

theorem envBound21739 : H12AffineFastState.Bounded env21739 := by
  intro p hp
  have h : env21739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21738_21739 : H12AffineEnvironment.transform 21 169400 env21738 = env21739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env21738 == env21739) = true)

theorem identity21739 : scanCanonicalize (H12AffineFastState.compose env21739 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound21739 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,30163,131072,149861,1024,8461,4160,144564,153,21762,8328,65,146581,5392,17800,10480,1365,156133,256,21929,5376,22353]

theorem envBound21740 : H12AffineFastState.Bounded env21740 := by
  intro p hp
  have h : env21740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21739_21740 : H12AffineEnvironment.transform 14 8460 env21739 = env21740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env21739 == env21740) = true)

theorem identity21740 : scanCanonicalize (H12AffineFastState.compose env21740 (packedSelected [0,1,9,10,11,15,16,18,19,20,22,23,27,28,32,38] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21740 : packedSelected [0,1,9,10,11,15,16,18,19,20,22,23,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env21741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8460,8283,131072,138477,1024,8461,4160,144564,153,138,8328,65,146581,5392,4096,10480,1365,144493,256,33,5376,729]

theorem envBound21741 : H12AffineFastState.Bounded env21741 := by
  intro p hp
  have h : env21741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21740_21741 : H12AffineEnvironment.transform 13 5512 env21740 = env21741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21740 == env21741) = true)

theorem identity21741 : scanCanonicalize (H12AffineFastState.compose env21741 (packedSelected [3,10,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21741 : packedSelected [3,10,19,24] rootPS < 2^1333 := by decide +kernel

def env21742 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,8203,131072,138429,1024,8461,4112,144564,153,138,8328,17,146581,5392,4096,10400,1285,144445,256,33,5376,649]

theorem envBound21742 : H12AffineFastState.Bounded env21742 := by
  intro p hp
  have h : env21742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21741_21742 : H12AffineEnvironment.transform 5 16 env21741 = env21742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21741 == env21742) = true)

theorem identity21742 : scanCanonicalize (H12AffineFastState.compose env21742 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21742 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env21743 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,136,399,131072,138429,1024,137,4112,136496,153,138,268,17,138513,5392,4096,2340,1285,136633,256,33,5376,649]

theorem envBound21743 : H12AffineFastState.Bounded env21743 := by
  intro p hp
  have h : env21743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21742_21743 : H12AffineEnvironment.transform 12 388 env21742 = env21743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21742 == env21743) = true)

def env21744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,149861,1024,32769,4160,169401,152,21762,8328,65,171417,5392,17801,35325,1364,156132,256,21928,46093,63068]

theorem envBound21744 : H12AffineFastState.Bounded env21744 := by
  intro p hp
  have h : env21744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21738_21744 : H12AffineEnvironment.transform 21 169401 env21738 = env21744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env21738 == env21744) = true)

theorem identity21744 : scanCanonicalize (H12AffineFastState.compose env21744 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 16537) := by decide +kernel

theorem selectedBound21744 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env21745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16537,2556,1024,32769,4160,54560,152,21762,8328,65,56576,5392,17801,35325,1364,8573,256,21928,46093,63068]

theorem envBound21745 : H12AffineFastState.Bounded env21745 := by
  intro p hp
  have h : env21745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21744_21745 : H12AffineEnvironment.transform 16 16537 env21744 = env21745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env21744 == env21745) = true)

theorem identity21745 : scanCanonicalize (H12AffineFastState.compose env21745 (packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound21745 : packedSelected [0,3,4,7,10,16,17,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env21746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8322,16537,2556,1024,29788,4160,8573,152,21762,8328,65,10589,5392,17801,32160,1364,8573,256,21928,16464,513]

theorem envBound21746 : H12AffineFastState.Bounded env21746 := by
  intro p hp
  have h : env21746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21745_21746 : H12AffineEnvironment.transform 14 29789 env21745 = env21746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env21745 == env21746) = true)

theorem identity21746 : scanCanonicalize (H12AffineFastState.compose env21746 (packedSelected [2,6,11,32] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound21746 : packedSelected [2,6,11,32] rootPS < 2^1333 := by decide +kernel

def env21747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21760,479,16537,2556,1024,21761,4160,32,152,21762,469,65,2048,5392,17801,23805,1364,32,256,21928,16464,513]

theorem envBound21747 : H12AffineFastState.Bounded env21747 := by
  intro p hp
  have h : env21747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21746_21747 : H12AffineEnvironment.transform 12 349 env21746 = env21747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env21746 == env21747) = true)

theorem identity21747 : scanCanonicalize (H12AffineFastState.compose env21747 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound21747 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,136,479,5393,2556,1024,137,4160,32,152,138,469,65,2048,5392,4097,2421,1364,32,256,32,5592,513]

theorem envBound21748 : H12AffineFastState.Bounded env21748 := by
  intro p hp
  have h : env21748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21747_21748 : H12AffineEnvironment.transform 13 5512 env21747 = env21748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env21747 == env21748) = true)

theorem identity21748 : scanCanonicalize (H12AffineFastState.compose env21748 (packedSelected [0,3,7,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound21748 : packedSelected [0,3,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,509,4096,349,5512,136,479,5393,1,1024,137,4160,32,152,138,469,65,509,5392,4097,136,1364,32,256,32,5592,513]

theorem envBound21749 : H12AffineFastState.Bounded env21749 := by
  intro p hp
  have h : env21749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21748_21749 : H12AffineEnvironment.transform 10 509 env21748 = env21749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env21748 == env21749) = true)

theorem identity21749 : scanCanonicalize (H12AffineFastState.compose env21749 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound21749 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env21750 : List Nat := [2,4,8,16,32,64,128,256,512,272,509,4096,349,4248,136,479,4097,1,272,137,4160,32,152,138,469,65,509,4096,4097,136,68,32,256,32,4296,513]

theorem envBound21750 : H12AffineFastState.Bounded env21750 := by
  intro p hp
  have h : env21750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21749_21750 : H12AffineEnvironment.transform 9 272 env21749 = env21750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21749 == env21750) = true)

def env21751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,8388608,21763,8328,65,12704870,115151,8406288,8423781,8507666,4268162,256,8487407,8478794,8451781]

theorem envBound21751 : H12AffineFastState.Bounded env21751 := by
  intro p hp
  have h : env21751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21711_21751 : H12AffineEnvironment.transform 20 4161 env21711 = env21751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env21711 == env21751) = true)

def env21752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363552,21763,8328,65,215366,115151,4378672,4332613,4408370,4268162,256,4396239,4453738,4350949]

theorem envBound21752 : H12AffineFastState.Bounded env21752 := by
  intro p hp
  have h : env21752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21751_21752 : H12AffineEnvironment.transform 22 4363552 env21751 = env21752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env21751 == env21752) = true)

theorem identity21752 : scanCanonicalize (H12AffineFastState.compose env21752 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound21752 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env21753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243002,73754,21763,8328,65,215366,115151,91402,108927,61704,169400,256,41461,16464,120543]

theorem envBound21753 : H12AffineFastState.Bounded env21753 := by
  intro p hp
  have h : env21753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21752_21753 : H12AffineEnvironment.transform 21 243002 env21752 = env21753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env21752 == env21753) = true)

def env21754 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243002,73754,21763,8272,65,215366,114967,91402,108927,61704,169312,256,41261,16464,120327]

theorem envBound21754 : H12AffineFastState.Bounded env21754 := by
  intro p hp
  have h : env21754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21753_21754 : H12AffineEnvironment.transform 6 88 env21753 = env21754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env21753 == env21754) = true)

theorem identity21754 : scanCanonicalize (H12AffineFastState.compose env21754 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 103446) := by decide +kernel

theorem selectedBound21754 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env21755 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,103446,122227,1024,32769,4161,8492,73754,21763,8272,65,56656,114967,91402,108927,61704,65910,256,41261,16464,120327]

theorem envBound21755 : H12AffineFastState.Bounded env21755 := by
  intro p hp
  have h : env21755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21754_21755 : H12AffineEnvironment.transform 16 103446 env21754 = env21755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103446 env21754 == env21755) = true)

theorem identity21755 : scanCanonicalize (H12AffineFastState.compose env21755 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound21755 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env21756 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54278,16400,2421,1024,32769,4161,8492,62492,21763,8272,65,56656,5393,45324,32121,61704,54640,256,41261,16464,513]

theorem envBound21756 : H12AffineFastState.Bounded env21756 := by
  intro p hp
  have h : env21756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21755_21756 : H12AffineEnvironment.transform 15 54278 env21755 = env21756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env21755 == env21756) = true)

theorem identity21756 : scanCanonicalize (H12AffineFastState.compose env21756 (packedSelected [3,5,8,17,18,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound21756 : packedSelected [3,5,8,17,18,23,28] rootPS < 2^1333 := by decide +kernel

def env21757 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,32768,33111,5441,2421,1024,32769,4161,8492,41293,82,8272,65,34817,5393,45324,10280,42073,32801,256,41261,5377,513]

theorem envBound21757 : H12AffineFastState.Bounded env21757 := by
  intro p hp
  have h : env21757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21756_21757 : H12AffineEnvironment.transform 13 5457 env21756 = env21757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env21756 == env21757) = true)

theorem identity21757 : scanCanonicalize (H12AffineFastState.compose env21757 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound21757 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env21758 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8540,8203,5441,2421,1024,8541,4161,8492,17,82,8272,65,10589,5393,4176,10280,1285,8573,256,113,5377,513]

theorem envBound21758 : H12AffineFastState.Bounded env21758 := by
  intro p hp
  have h : env21758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21757_21758 : H12AffineEnvironment.transform 14 8540 env21757 = env21758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env21757 == env21758) = true)

theorem identity21758 : scanCanonicalize (H12AffineFastState.compose env21758 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound21758 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env21759 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,1385,5457,1077,1378,5441,2421,1024,1076,4161,1093,17,82,1337,65,3124,5393,4176,3393,1285,1044,256,113,5377,513]

theorem envBound21759 : H12AffineFastState.Bounded env21759 := by
  intro p hp
  have h : env21759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21758_21759 : H12AffineEnvironment.transform 12 1385 env21758 = env21759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env21758 == env21759) = true)

theorem identity21759 : scanCanonicalize (H12AffineFastState.compose env21759 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound21759 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21760 : List Nat := [2,4,8,16,32,64,88,256,512,52,2048,4096,349,4453,1,342,4469,2421,52,0,4161,113,17,82,269,65,2048,4389,4176,2421,305,32,256,113,4405,513]

theorem envBound21760 : H12AffineFastState.Bounded env21760 := by
  intro p hp
  have h : env21760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21759_21760 : H12AffineEnvironment.transform 9 52 env21759 = env21760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env21759 == env21760) = true)

theorem identity21760 : scanCanonicalize (H12AffineFastState.compose env21760 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21760 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21761 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4404,1,263,4388,2340,52,0,4112,32,17,3,269,16,2048,4389,4097,2340,305,32,256,32,4405,513]

theorem envBound21761 : H12AffineFastState.Bounded env21761 := by
  intro p hp
  have h : env21761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21760_21761 : H12AffineEnvironment.transform 5 17 env21760 = env21761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21760 == env21761) = true)

def env21762 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,243002,73754,21763,8273,65,215366,114966,91402,108927,61704,169313,256,41260,16464,120326]

theorem envBound21762 : H12AffineFastState.Bounded env21762 := by
  intro p hp
  have h : env21762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1